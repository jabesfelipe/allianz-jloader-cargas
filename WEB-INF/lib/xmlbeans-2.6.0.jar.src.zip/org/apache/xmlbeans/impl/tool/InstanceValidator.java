/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstanceValidator
/*     */ {
/*     */   public static void printUsage() {
/*  37 */     System.out.println("Validates the specified instance against the specified schema.");
/*  38 */     System.out.println("Contrast with the svalidate tool, which validates using a stream.");
/*  39 */     System.out.println("Usage: validate [-dl] [-nopvr] [-noupa] [-license] schema.xsd instance.xml");
/*  40 */     System.out.println("Options:");
/*  41 */     System.out.println("    -dl - permit network downloads for imports and includes (default is off)");
/*  42 */     System.out.println("    -noupa - do not enforce the unique particle attribution rule");
/*  43 */     System.out.println("    -nopvr - do not enforce the particle valid (restriction) rule");
/*  44 */     System.out.println("    -strict - performs strict(er) validation");
/*  45 */     System.out.println("    -partial - allow partial schema type system");
/*  46 */     System.out.println("    -license - prints license information");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  51 */     System.exit(extraMain(args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int extraMain(String[] args) {
/*     */     SchemaTypeSystem schemaTypeSystem;
/*     */     SchemaTypeLoader schemaTypeLoader1;
/*  61 */     Set flags = new HashSet();
/*  62 */     flags.add("h");
/*  63 */     flags.add("help");
/*  64 */     flags.add("usage");
/*  65 */     flags.add("license");
/*  66 */     flags.add("version");
/*  67 */     flags.add("dl");
/*  68 */     flags.add("noupa");
/*  69 */     flags.add("nopvr");
/*  70 */     flags.add("strict");
/*  71 */     flags.add("partial");
/*     */     
/*  73 */     CommandLine cl = new CommandLine(args, flags, Collections.EMPTY_SET);
/*     */     
/*  75 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null || args.length < 1) {
/*     */       
/*  77 */       printUsage();
/*  78 */       return 0;
/*     */     } 
/*     */     
/*  81 */     String[] badopts = cl.getBadOpts();
/*  82 */     if (badopts.length > 0) {
/*     */       
/*  84 */       for (int k = 0; k < badopts.length; k++)
/*  85 */         System.out.println("Unrecognized option: " + badopts[k]); 
/*  86 */       printUsage();
/*  87 */       return 0;
/*     */     } 
/*     */     
/*  90 */     if (cl.getOpt("license") != null) {
/*     */       
/*  92 */       CommandLine.printLicense();
/*  93 */       return 0;
/*     */     } 
/*     */     
/*  96 */     if (cl.getOpt("version") != null) {
/*     */       
/*  98 */       CommandLine.printVersion();
/*  99 */       return 0;
/*     */     } 
/*     */     
/* 102 */     if ((cl.args()).length == 0)
/*     */     {
/* 104 */       return 0;
/*     */     }
/*     */     
/* 107 */     boolean dl = (cl.getOpt("dl") != null);
/* 108 */     boolean nopvr = (cl.getOpt("nopvr") != null);
/* 109 */     boolean noupa = (cl.getOpt("noupa") != null);
/* 110 */     boolean strict = (cl.getOpt("strict") != null);
/* 111 */     boolean partial = (cl.getOpt("partial") != null);
/*     */     
/* 113 */     File[] schemaFiles = cl.filesEndingWith(".xsd");
/* 114 */     File[] instanceFiles = cl.filesEndingWith(".xml");
/* 115 */     File[] jarFiles = cl.filesEndingWith(".jar");
/*     */     
/* 117 */     List sdocs = new ArrayList();
/*     */ 
/*     */     
/* 120 */     for (int i = 0; i < schemaFiles.length; i++) {
/*     */ 
/*     */       
/*     */       try {
/* 124 */         sdocs.add(XmlObject.Factory.parse(schemaFiles[i], (new XmlOptions()).setLoadLineNumbers().setLoadMessageDigest()));
/*     */ 
/*     */       
/*     */       }
/* 128 */       catch (Exception e) {
/*     */         
/* 130 */         System.err.println(schemaFiles[i] + " not loadable: " + e);
/*     */       } 
/*     */     } 
/*     */     
/* 134 */     XmlObject[] schemas = sdocs.<XmlObject>toArray(new XmlObject[0]);
/*     */     
/* 136 */     SchemaTypeLoader sLoader = null;
/* 137 */     Collection compErrors = new ArrayList();
/* 138 */     XmlOptions schemaOptions = new XmlOptions();
/* 139 */     schemaOptions.setErrorListener(compErrors);
/* 140 */     if (dl)
/* 141 */       schemaOptions.setCompileDownloadUrls(); 
/* 142 */     if (nopvr)
/* 143 */       schemaOptions.setCompileNoPvrRule(); 
/* 144 */     if (noupa)
/* 145 */       schemaOptions.setCompileNoUpaRule(); 
/* 146 */     if (partial) {
/* 147 */       schemaOptions.put("COMPILE_PARTIAL_TYPESYSTEM");
/*     */     }
/* 149 */     if (jarFiles != null && jarFiles.length > 0) {
/* 150 */       sLoader = XmlBeans.typeLoaderForResource(XmlBeans.resourceLoaderForPath(jarFiles));
/*     */     }
/* 152 */     int returnCode = 0;
/*     */ 
/*     */     
/*     */     try {
/* 156 */       if (schemas != null && schemas.length > 0) {
/* 157 */         schemaTypeSystem = XmlBeans.compileXsd(schemas, sLoader, schemaOptions);
/*     */       }
/* 159 */     } catch (Exception e) {
/*     */       
/* 161 */       if (compErrors.isEmpty() || !(e instanceof org.apache.xmlbeans.XmlException))
/*     */       {
/* 163 */         e.printStackTrace(System.err);
/*     */       }
/* 165 */       System.out.println("Schema invalid:" + (partial ? " couldn't recover from errors" : ""));
/* 166 */       for (Iterator iterator = compErrors.iterator(); iterator.hasNext();) {
/* 167 */         System.out.println(iterator.next());
/*     */       }
/* 169 */       returnCode = 10;
/* 170 */       return returnCode;
/*     */     } 
/*     */ 
/*     */     
/* 174 */     if (partial && !compErrors.isEmpty()) {
/*     */       
/* 176 */       returnCode = 11;
/* 177 */       System.out.println("Schema invalid: partial schema type system recovered");
/* 178 */       for (Iterator iterator = compErrors.iterator(); iterator.hasNext();) {
/* 179 */         System.out.println(iterator.next());
/*     */       }
/*     */     } 
/* 182 */     if (schemaTypeSystem == null) {
/* 183 */       schemaTypeLoader1 = XmlBeans.getContextTypeLoader();
/*     */     }
/* 185 */     for (int j = 0; j < instanceFiles.length; j++) {
/*     */       XmlObject xobj;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 191 */         xobj = schemaTypeLoader1.parse(instanceFiles[j], null, (new XmlOptions()).setLoadLineNumbers("LOAD_LINE_NUMBERS_END_ELEMENT"));
/*     */       
/*     */       }
/* 194 */       catch (Exception e) {
/*     */         
/* 196 */         System.err.println(instanceFiles[j] + " not loadable: " + e);
/* 197 */         e.printStackTrace(System.err);
/*     */       } 
/*     */ 
/*     */       
/* 201 */       Collection errors = new ArrayList();
/*     */       
/* 203 */       if (xobj.schemaType() == XmlObject.type) {
/*     */         
/* 205 */         System.out.println(instanceFiles[j] + " NOT valid.  ");
/* 206 */         System.out.println("  Document type not found.");
/*     */       }
/* 208 */       else if (xobj.validate(strict ? (new XmlOptions()).setErrorListener(errors).setValidateStrict() : (new XmlOptions()).setErrorListener(errors))) {
/*     */ 
/*     */         
/* 211 */         System.out.println(instanceFiles[j] + " valid.");
/*     */       } else {
/*     */         
/* 214 */         returnCode = 1;
/* 215 */         System.out.println(instanceFiles[j] + " NOT valid.");
/* 216 */         for (Iterator it = errors.iterator(); it.hasNext();)
/*     */         {
/* 218 */           System.out.println(it.next());
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 223 */     return returnCode;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\InstanceValidator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */