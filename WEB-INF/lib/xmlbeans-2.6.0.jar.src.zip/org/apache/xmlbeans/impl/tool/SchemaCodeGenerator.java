/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.Filer;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.SystemProperties;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.util.FilerImpl;
/*     */ import repackage.Repackager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaCodeGenerator
/*     */ {
/*     */   public static void saveTypeSystem(SchemaTypeSystem system, File classesDir, File sourceFile, Repackager repackager, XmlOptions options) throws IOException {
/*  64 */     FilerImpl filerImpl = new FilerImpl(classesDir, null, repackager, false, false);
/*  65 */     system.save((Filer)filerImpl);
/*     */   }
/*     */ 
/*     */   
/*     */   static void deleteObsoleteFiles(File rootDir, File srcDir, Set seenFiles) {
/*  70 */     if (!rootDir.isDirectory() || !srcDir.isDirectory())
/*  71 */       throw new IllegalArgumentException(); 
/*  72 */     String absolutePath = srcDir.getAbsolutePath();
/*     */     
/*  74 */     if (absolutePath.length() <= 5)
/*     */       return; 
/*  76 */     if (absolutePath.startsWith("/home/") && (absolutePath.indexOf("/", 6) >= absolutePath.length() - 1 || absolutePath.indexOf("/", 6) < 0)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     File[] files = srcDir.listFiles();
/*  84 */     for (int i = 0; i < files.length; i++) {
/*     */       
/*  86 */       if (files[i].isDirectory()) {
/*  87 */         deleteObsoleteFiles(rootDir, files[i], seenFiles);
/*  88 */       } else if (!seenFiles.contains(files[i])) {
/*     */ 
/*     */ 
/*     */         
/*  92 */         deleteXmlBeansFile(files[i]);
/*  93 */         deleteDirRecursively(rootDir, files[i].getParentFile());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void deleteXmlBeansFile(File file) {
/* 100 */     if (file.getName().endsWith(".java")) {
/* 101 */       file.delete();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void deleteDirRecursively(File root, File dir) {
/* 106 */     String[] list = dir.list();
/* 107 */     while (list != null && list.length == 0 && !dir.equals(root)) {
/*     */       
/* 109 */       dir.delete();
/* 110 */       dir = dir.getParentFile();
/* 111 */       list = dir.list();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static File createTempDir() throws IOException {
/*     */     
/* 121 */     try { File tmpDirFile = new File(SystemProperties.getProperty("java.io.tmpdir"));
/* 122 */       tmpDirFile.mkdirs(); }
/* 123 */     catch (Exception e) { e.printStackTrace(); }
/*     */     
/* 125 */     File tmpFile = File.createTempFile("xbean", null);
/* 126 */     String path = tmpFile.getAbsolutePath();
/* 127 */     if (!path.endsWith(".tmp"))
/* 128 */       throw new IOException("Error: createTempFile did not create a file ending with .tmp"); 
/* 129 */     path = path.substring(0, path.length() - 4);
/* 130 */     File tmpSrcDir = null;
/*     */     
/* 132 */     for (int count = 0; count < 100; count++) {
/*     */       
/* 134 */       String name = path + ".d" + ((count == 0) ? "" : Integer.toString(count++));
/*     */       
/* 136 */       tmpSrcDir = new File(name);
/*     */       
/* 138 */       if (!tmpSrcDir.exists()) {
/*     */         
/* 140 */         boolean created = tmpSrcDir.mkdirs();
/* 141 */         assert created : "Could not create " + tmpSrcDir.getAbsolutePath();
/*     */         break;
/*     */       } 
/*     */     } 
/* 145 */     tmpFile.deleteOnExit();
/*     */     
/* 147 */     return tmpSrcDir;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void tryHardToDelete(File dir) {
/* 152 */     tryToDelete(dir);
/* 153 */     if (dir.exists()) {
/* 154 */       tryToDeleteLater(dir);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void tryToDelete(File dir) {
/* 159 */     if (dir.exists()) {
/*     */       
/* 161 */       if (dir.isDirectory()) {
/*     */         
/* 163 */         String[] list = dir.list();
/* 164 */         if (list != null)
/* 165 */           for (int i = 0; i < list.length; i++)
/* 166 */             tryToDelete(new File(dir, list[i]));  
/*     */       } 
/* 168 */       if (!dir.delete())
/*     */         return; 
/*     */     } 
/*     */   }
/*     */   
/* 173 */   private static Set deleteFileQueue = new HashSet();
/* 174 */   private static int triesRemaining = 0;
/*     */   
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   private static boolean tryNowThatItsLater() {
/*     */     List files;
/* 180 */     synchronized (deleteFileQueue) {
/*     */       
/* 182 */       files = new ArrayList(deleteFileQueue);
/* 183 */       deleteFileQueue.clear();
/*     */     } 
/*     */     
/* 186 */     List retry = new ArrayList();
/*     */     
/* 188 */     for (Iterator i = files.iterator(); i.hasNext(); ) {
/*     */       
/* 190 */       File file = i.next();
/* 191 */       tryToDelete(file);
/* 192 */       if (file.exists()) {
/* 193 */         retry.add(file);
/*     */       }
/*     */     } 
/* 196 */     synchronized (deleteFileQueue) {
/*     */       
/* 198 */       if (triesRemaining > 0) {
/* 199 */         triesRemaining--;
/*     */       }
/* 201 */       if (triesRemaining <= 0 || retry.size() == 0) {
/* 202 */         triesRemaining = 0;
/*     */       } else {
/* 204 */         deleteFileQueue.addAll(retry);
/*     */       } 
/* 206 */       return (triesRemaining <= 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void giveUp() {
/* 212 */     synchronized (deleteFileQueue) {
/*     */       
/* 214 */       deleteFileQueue.clear();
/* 215 */       triesRemaining = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void tryToDeleteLater(File dir) {
/* 221 */     synchronized (deleteFileQueue) {
/*     */       
/* 223 */       deleteFileQueue.add(dir);
/* 224 */       if (triesRemaining == 0)
/*     */       {
/* 226 */         new Thread()
/*     */           {
/*     */ 
/*     */ 
/*     */             
/*     */             public void run()
/*     */             {
/*     */               try {
/*     */                 while (true) {
/* 235 */                   if (SchemaCodeGenerator.tryNowThatItsLater())
/*     */                     return; 
/* 237 */                   Thread.sleep(3000L);
/*     */                 }
/*     */               
/* 240 */               } catch (InterruptedException e) {
/*     */                 
/* 242 */                 SchemaCodeGenerator.giveUp();
/*     */                 return;
/*     */               } 
/*     */             }
/*     */           };
/*     */       }
/* 248 */       if (triesRemaining < 10)
/* 249 */         triesRemaining = 10; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\SchemaCodeGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */