package org.apache.xmlbeans.impl.tool;

import java.util.Map;
import org.apache.xmlbeans.SchemaTypeSystem;

public interface SchemaCompilerExtension {
  void schemaCompilerExtension(SchemaTypeSystem paramSchemaTypeSystem, Map paramMap);
  
  String getExtensionName();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\SchemaCompilerExtension.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */