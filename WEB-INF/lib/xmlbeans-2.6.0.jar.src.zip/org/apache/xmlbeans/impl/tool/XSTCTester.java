/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.xmlbeans.SystemProperties;
/*     */ import org.apache.xmlbeans.XmlCalendar;
/*     */ import org.apache.xmlbeans.XmlError;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.FileDesc;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.TestsDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XSTCTester
/*     */ {
/*     */   public static void printUsage() {
/*  44 */     System.out.println("Usage: xstc [-showpass] [-errcode] foo_LTGfmt.xml ...");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/*  49 */     Set flags = new HashSet();
/*  50 */     flags.add("h");
/*  51 */     flags.add("help");
/*  52 */     flags.add("usage");
/*  53 */     flags.add("version");
/*  54 */     flags.add("showpass");
/*  55 */     flags.add("errcode");
/*     */     
/*  57 */     long start = System.currentTimeMillis();
/*     */     
/*  59 */     CommandLine cl = new CommandLine(args, flags, Collections.EMPTY_SET);
/*  60 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null) {
/*     */       
/*  62 */       printUsage();
/*  63 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  67 */     if (cl.getOpt("version") != null) {
/*     */       
/*  69 */       CommandLine.printVersion();
/*  70 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  74 */     String[] badopts = cl.getBadOpts();
/*  75 */     if (badopts.length > 0) {
/*     */       
/*  77 */       for (int j = 0; j < badopts.length; j++)
/*  78 */         System.out.println("Unrecognized option: " + badopts[j]); 
/*  79 */       printUsage();
/*  80 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  84 */     if ((cl.args()).length == 0) {
/*  85 */       printUsage();
/*     */       
/*     */       return;
/*     */     } 
/*  89 */     boolean showpass = (cl.getOpt("showpass") != null);
/*  90 */     boolean errcode = (cl.getOpt("errcode") != null);
/*     */     
/*  92 */     File[] allFiles = cl.getFiles();
/*  93 */     Collection ltgFiles = new ArrayList();
/*  94 */     Harness harness = new XMLBeanXSTCHarness();
/*     */     
/*  96 */     for (int i = 0; i < allFiles.length; i++) {
/*     */       
/*  98 */       if (allFiles[i].getName().indexOf("LTG") >= 0) {
/*  99 */         ltgFiles.add(allFiles[i]);
/*     */       }
/*     */     } 
/* 102 */     File resultsFile = new File("out.html");
/* 103 */     PrintWriter writer = new PrintWriter(new FileWriter(resultsFile));
/* 104 */     writer.println("<html>");
/* 105 */     writer.println("<style>td {border-bottom: 1px solid black} xmp {white-space: normal; word-wrap: break-word; word-break: break-all} </style>");
/* 106 */     writer.println("<body>");
/*     */     
/* 108 */     writer.println("<script language='JavaScript' type='text/javascript'>");
/* 109 */     writer.println("var w;");
/* 110 */     writer.println("function openWindow(schema, instance) {");
/* 111 */     writer.println("  if (w == null) {");
/* 112 */     writer.println("    w = window.open('about:blank', 'xstc');");
/* 113 */     writer.println("  }");
/* 114 */     writer.println("  if (w.closed) {");
/* 115 */     writer.println("    w = window.open('about:blank', 'xstc');");
/* 116 */     writer.println("  }");
/* 117 */     writer.println("  w.document.open();");
/* 118 */     writer.println("  w.document.write(\"<frameset rows=*,*><frame src='\" + schema + \"'><frame src='\" + instance + \"'></frameset>\");");
/* 119 */     writer.println("  w.document.close();");
/* 120 */     writer.println("  w.focus();");
/* 121 */     writer.println("}");
/* 122 */     writer.println("</script>");
/*     */     
/* 124 */     writer.println("<h1>XML Schema Test Collection Results</h1>");
/* 125 */     writer.println("<p>Run on " + new XmlCalendar(new Date()) + "</p>");
/* 126 */     writer.println("<p>Values in schema or instance valid columns are results from compiling or validating respectively.");
/* 127 */     writer.println("Red or orange background mean the test failed.</p>");
/* 128 */     writer.println("<table style='border: 1px solid black' cellpadding=0 cellspacing=0>");
/* 129 */     writer.println("<tr><td witdh=10%>id</td><td width=70%>Description</td><td width=10%>sch v</td><td width=10%>ins v</td></tr>");
/* 130 */     int failures = 0;
/* 131 */     int cases = 0;
/* 132 */     for (Iterator iterator = ltgFiles.iterator(); iterator.hasNext(); ) {
/*     */       
/* 134 */       File ltgFile = iterator.next();
/* 135 */       System.out.println("Processing test cases in " + ltgFile);
/* 136 */       Collection ltgErrors = new ArrayList();
/* 137 */       TestCase[] testCases = parseLTGFile(ltgFile, ltgErrors);
/* 138 */       Collection results = new ArrayList();
/* 139 */       if (testCases != null) for (int k = 0; k < testCases.length; k++) {
/*     */           
/* 141 */           TestCaseResult result = new TestCaseResult();
/* 142 */           result.testCase = testCases[k];
/* 143 */           harness.runTestCase(result);
/* 144 */           cases++;
/* 145 */           if (!result.succeeded(errcode)) {
/* 146 */             failures++;
/* 147 */           } else if (!showpass) {
/*     */             continue;
/* 149 */           }  results.add(result); continue;
/*     */         }  
/* 151 */       writer.println("<tr><td colspan=4 bgcolor=skyblue>" + ltgFile + "</td></tr>");
/* 152 */       if (!ltgErrors.isEmpty()) {
/*     */         
/* 154 */         writer.println("<tr><td>Errors within the LTG file:");
/* 155 */         writer.println("<xmp>");
/* 156 */         for (Iterator iterator1 = ltgErrors.iterator(); iterator1.hasNext();)
/* 157 */           writer.println(iterator1.next()); 
/* 158 */         writer.println("</xmp>");
/* 159 */         writer.println("</td></tr>");
/*     */ 
/*     */       
/*     */       }
/* 163 */       else if (results.size() == 0) {
/* 164 */         writer.println("<tr><td colspan=4 bgcolor=green>Nothing to report</td></tr>");
/*     */       } 
/* 166 */       if (results == null)
/*     */         continue; 
/* 168 */       for (Iterator j = results.iterator(); j.hasNext();)
/*     */       {
/* 170 */         summarizeResultAsHTMLTableRows(j.next(), writer, errcode);
/*     */       }
/*     */     } 
/* 173 */     writer.println("<tr><td colspan=4>Summary: " + failures + " failures out of " + cases + " cases run.</td></tr>");
/* 174 */     writer.println("</table>");
/* 175 */     writer.close();
/*     */     
/* 177 */     long finish = System.currentTimeMillis();
/* 178 */     System.out.println("Time run tests: " + ((finish - start) / 1000.0D) + " seconds");
/*     */ 
/*     */     
/* 181 */     System.out.println("Results output to " + resultsFile);
/* 182 */     if (SystemProperties.getProperty("os.name").toLowerCase().indexOf("windows") >= 0) {
/* 183 */       Runtime.getRuntime().exec("cmd /c start iexplore \"" + resultsFile.getAbsolutePath() + "\"");
/*     */     } else {
/* 185 */       Runtime.getRuntime().exec("mozilla file://" + resultsFile.getAbsolutePath());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class TestCase
/*     */   {
/*     */     private File ltgFile;
/*     */     private String id;
/*     */     private String origin;
/*     */     private String description;
/*     */     private File schemaFile;
/*     */     private File instanceFile;
/*     */     private File resourceFile;
/*     */     private boolean svExpected;
/*     */     private boolean ivExpected;
/*     */     private boolean rvExpected;
/*     */     private String errorCode;
/*     */     
/*     */     public File getLtgFile() {
/* 204 */       return this.ltgFile;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getId() {
/* 209 */       return this.id;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getOrigin() {
/* 214 */       return this.origin;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 219 */       return this.description;
/*     */     }
/*     */ 
/*     */     
/*     */     public File getSchemaFile() {
/* 224 */       return this.schemaFile;
/*     */     }
/*     */ 
/*     */     
/*     */     public File getInstanceFile() {
/* 229 */       return this.instanceFile;
/*     */     }
/*     */ 
/*     */     
/*     */     public File getResourceFile() {
/* 234 */       return this.resourceFile;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSvExpected() {
/* 239 */       return this.svExpected;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isIvExpected() {
/* 244 */       return this.ivExpected;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRvExpected() {
/* 249 */       return this.rvExpected;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getErrorCode() {
/* 254 */       return this.errorCode;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class TestCaseResult
/*     */   {
/*     */     private XSTCTester.TestCase testCase;
/*     */     private boolean svActual;
/* 263 */     private Collection svMessages = new ArrayList();
/*     */     private boolean ivActual;
/* 265 */     private Collection ivMessages = new ArrayList();
/*     */     
/*     */     private boolean crash;
/*     */     
/*     */     public XSTCTester.TestCase getTestCase() {
/* 270 */       return this.testCase;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSvActual() {
/* 275 */       return this.svActual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setSvActual(boolean svActual) {
/* 280 */       this.svActual = svActual;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isIvActual() {
/* 285 */       return this.ivActual;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setIvActual(boolean ivActual) {
/* 290 */       this.ivActual = ivActual;
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection getSvMessages() {
/* 295 */       return Collections.unmodifiableCollection(this.svMessages);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addSvMessages(Collection svMessages) {
/* 300 */       this.svMessages.addAll(svMessages);
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection getIvMessages() {
/* 305 */       return Collections.unmodifiableCollection(this.ivMessages);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addIvMessages(Collection ivMessages) {
/* 310 */       this.ivMessages.addAll(ivMessages);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setCrash(boolean crash) {
/* 315 */       this.crash = crash;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCrash() {
/* 320 */       return this.crash;
/*     */     }
/*     */     
/*     */     public boolean succeeded(boolean errcode) {
/*     */       int i;
/* 325 */       boolean success = (!this.crash && isIvActual() == this.testCase.isIvExpected() && isSvActual() == this.testCase.isSvExpected());
/*     */ 
/*     */       
/* 328 */       if (errcode && this.testCase.getErrorCode() != null)
/* 329 */         i = success & ((XSTCTester.errorReported(this.testCase.getErrorCode(), this.svMessages) || XSTCTester.errorReported(this.testCase.getErrorCode(), this.ivMessages)) ? 1 : 0); 
/* 330 */       return i;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String makeHTMLLink(File file, boolean value) {
/* 342 */     if (file == null)
/* 343 */       return "&nbsp;"; 
/* 344 */     URI uri = file.getAbsoluteFile().toURI();
/* 345 */     return "<a href=\"" + uri + "\" target=_blank>" + Boolean.toString(value) + "</a>";
/*     */   }
/*     */   
/* 348 */   private static final Pattern leadingSpace = Pattern.compile("^\\s+", 8);
/*     */ 
/*     */   
/*     */   public static String makeHTMLDescription(TestCase testCase) {
/* 352 */     StringBuffer sb = new StringBuffer();
/* 353 */     sb.append("<a class=noline href='javascript:openWindow(\"");
/* 354 */     if (testCase.getSchemaFile() == null) {
/* 355 */       sb.append("about:No schema");
/*     */     } else {
/* 357 */       sb.append(testCase.getSchemaFile().getAbsolutePath().replaceAll("\\\\", "\\\\\\\\"));
/*     */     } 
/* 359 */     sb.append("\", \"");
/* 360 */     if (testCase.getInstanceFile() == null) {
/* 361 */       sb.append("about:No instance");
/*     */     } else {
/* 363 */       sb.append(testCase.getInstanceFile().getAbsolutePath().replaceAll("\\\\", "\\\\\\\\"));
/* 364 */     }  sb.append("\")'><xmp>");
/* 365 */     sb.append(leadingSpace.matcher(testCase.getDescription()).replaceAll(""));
/* 366 */     sb.append("</xmp></a>");
/* 367 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static void summarizeResultAsHTMLTableRows(TestCaseResult result, PrintWriter out, boolean errcode) {
/*     */     String sLinks;
/* 372 */     TestCase testCase = result.getTestCase();
/*     */     
/* 374 */     boolean errorRow = (errcode && testCase.getErrorCode() != null);
/* 375 */     boolean messagesRow = (!result.getIvMessages().isEmpty() || !result.getSvMessages().isEmpty());
/*     */     
/* 377 */     boolean sRight = (testCase.getSchemaFile() == null || testCase.isSvExpected() == result.isSvActual());
/* 378 */     boolean iRight = (testCase.getInstanceFile() == null || testCase.isIvExpected() == result.isIvActual());
/* 379 */     boolean codeRight = true;
/* 380 */     if (errorRow) {
/* 381 */       codeRight = (errorReported(testCase.getErrorCode(), result.svMessages) || errorReported(testCase.getErrorCode(), result.ivMessages));
/*     */     }
/* 383 */     out.println(result.isCrash() ? "<tr bgcolor=black color=white>" : "<tr>");
/* 384 */     int idRowSpan = 1 + (errorRow ? 1 : 0) + (messagesRow ? 1 : 0);
/* 385 */     out.println("<td rowspan=" + idRowSpan + " valign=top>" + testCase.getId() + "</td>");
/* 386 */     out.println("<td valign=top>" + makeHTMLDescription(testCase) + "</td>");
/*     */     
/* 388 */     if (testCase.getResourceFile() == null) {
/* 389 */       sLinks = makeHTMLLink(testCase.getSchemaFile(), result.isSvActual());
/*     */     } else {
/* 391 */       sLinks = makeHTMLLink(testCase.getSchemaFile(), result.isSvActual()) + "<br>" + makeHTMLLink(testCase.getResourceFile(), result.isSvActual());
/*     */     } 
/* 393 */     out.println((sRight ? "<td valign=top>" : (result.isSvActual() ? "<td bgcolor=orange valign=top>" : "<td bgcolor=red valign=top>")) + sLinks + "</td>");
/* 394 */     out.println((iRight ? "<td valign=top>" : (result.isIvActual() ? "<td bgcolor=orange valign=top>" : "<td bgcolor=red valign=top>")) + makeHTMLLink(testCase.getInstanceFile(), result.isIvActual()) + "</td>");
/* 395 */     out.println("</tr>");
/* 396 */     if (errorRow) {
/*     */       
/* 398 */       out.println("<tr>");
/* 399 */       out.println((codeRight ? "<td colspan=4 valid=top>" : "<td colspan=4 bgcolor=orange valign=top>") + "expected error: " + testCase.getErrorCode() + "</td>");
/* 400 */       out.println("</tr>");
/*     */     } 
/* 402 */     if (messagesRow) {
/*     */       
/* 404 */       if (!result.succeeded(errcode)) {
/* 405 */         out.println("<tr><td colspan=4 bgcolor=yellow><xmp>");
/*     */       } else {
/* 407 */         out.println("<tr><td colspan=4><xmp>");
/* 408 */       }  Iterator j; for (j = result.getSvMessages().iterator(); j.hasNext();)
/* 409 */         out.println(j.next()); 
/* 410 */       for (j = result.getIvMessages().iterator(); j.hasNext();)
/* 411 */         out.println(j.next()); 
/* 412 */       out.println("</xmp></tr></td>");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static TestCase[] parseLTGFile(File ltgFile, Collection outerErrors) {
/* 418 */     Collection errors = new ArrayList();
/*     */     
/*     */     try {
/* 421 */       XmlOptions ltgOptions = new XmlOptions();
/* 422 */       ltgOptions.setLoadSubstituteNamespaces(Collections.singletonMap("", "http://www.bea.com/2003/05/xmlbean/ltgfmt"));
/* 423 */       ltgOptions.setErrorListener(errors);
/* 424 */       ltgOptions.setLoadLineNumbers();
/* 425 */       TestsDocument doc = TestsDocument.Factory.parse(ltgFile, ltgOptions);
/* 426 */       if (!doc.validate(ltgOptions)) {
/* 427 */         throw new Exception("Document " + ltgFile + " not valid.");
/*     */       }
/* 429 */       org.apache.xmlbeans.impl.xb.ltgfmt.TestCase[] testCases = doc.getTests().getTestArray();
/*     */       
/* 431 */       Collection result = new ArrayList();
/* 432 */       for (int i = 0; i < testCases.length; i++) {
/*     */         
/* 434 */         TestCase newCase = new TestCase();
/* 435 */         newCase.ltgFile = ltgFile;
/* 436 */         newCase.id = testCases[i].getId();
/* 437 */         newCase.origin = testCases[i].getOrigin();
/* 438 */         newCase.description = testCases[i].getDescription();
/* 439 */         FileDesc[] filedescs = testCases[i].getFiles().getFileArray();
/* 440 */         testCases[i].getOrigin();
/* 441 */         for (int j = 0; j < filedescs.length; j++) {
/*     */           
/* 443 */           String dir = filedescs[j].getFolder();
/* 444 */           String filename = filedescs[j].getFileName();
/* 445 */           File theFile = new File(ltgFile.getParentFile(), dir + "/" + filename);
/* 446 */           if (!theFile.exists() || !theFile.isFile() || !theFile.canRead()) {
/*     */             
/* 448 */             outerErrors.add(XmlError.forObject("Can't read file " + theFile, (XmlObject)filedescs[j]).toString());
/*     */           }
/*     */           else {
/*     */             
/* 452 */             switch (filedescs[j].getRole().intValue()) {
/*     */               
/*     */               case 2:
/* 455 */                 if (newCase.instanceFile != null)
/* 456 */                   outerErrors.add(XmlError.forObject("More than one instance file speicifed - ignoring all but last", (XmlObject)filedescs[j]).toString()); 
/* 457 */                 newCase.instanceFile = theFile;
/* 458 */                 newCase.ivExpected = filedescs[j].getValidity();
/*     */                 break;
/*     */               
/*     */               case 1:
/* 462 */                 if (newCase.schemaFile != null)
/* 463 */                   outerErrors.add(XmlError.forObject("More than one schema file speicifed - ignoring all but last", (XmlObject)filedescs[j]).toString()); 
/* 464 */                 newCase.schemaFile = theFile;
/* 465 */                 newCase.svExpected = filedescs[j].getValidity();
/*     */                 break;
/*     */               
/*     */               case 3:
/* 469 */                 if (newCase.resourceFile != null)
/* 470 */                   outerErrors.add(XmlError.forObject("More than one resource file speicifed - ignoring all but last", (XmlObject)filedescs[j]).toString()); 
/* 471 */                 newCase.resourceFile = theFile;
/* 472 */                 newCase.rvExpected = filedescs[j].getValidity();
/*     */                 break;
/*     */               
/*     */               default:
/* 476 */                 throw new XmlException(XmlError.forObject("Unexpected file role", filedescs[j]));
/*     */             } 
/*     */             
/* 479 */             if (filedescs[j].getCode() != null)
/* 480 */               newCase.errorCode = filedescs[j].getCode().getID(); 
/*     */           } 
/* 482 */         }  result.add(newCase);
/*     */       } 
/* 484 */       return result.<TestCase>toArray(new TestCase[result.size()]);
/*     */     }
/* 486 */     catch (Exception e) {
/*     */       
/* 488 */       if (errors.isEmpty())
/* 489 */       { outerErrors.add(e.getMessage()); }
/* 490 */       else { for (Iterator i = errors.iterator(); i.hasNext();)
/* 491 */           outerErrors.add(i.next().toString());  }
/* 492 */        return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean errorReported(String errorCode, Collection set) {
/* 498 */     if (errorCode == null || set == null || set.size() == 0) {
/* 499 */       return false;
/*     */     }
/* 501 */     for (Iterator i = set.iterator(); i.hasNext();) {
/*     */       
/* 503 */       if (errorCode.equals(((XmlError)i.next()).getErrorCode())) {
/* 504 */         return true;
/*     */       }
/*     */     } 
/* 507 */     return false;
/*     */   }
/*     */   
/*     */   public static interface Harness {
/*     */     void runTestCase(XSTCTester.TestCaseResult param1TestCaseResult);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\XSTCTester.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */