/*    */ package org.apache.xmlbeans.impl.tool;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Extension
/*    */ {
/*    */   private Class className;
/* 28 */   private List params = new ArrayList();
/*    */   
/*    */   public Class getClassName() {
/* 31 */     return this.className;
/*    */   }
/*    */   
/*    */   public void setClassName(Class className) {
/* 35 */     this.className = className;
/*    */   }
/*    */   public List getParams() {
/* 38 */     return this.params;
/*    */   }
/*    */   
/*    */   public Param createParam() {
/* 42 */     Param p = new Param();
/* 43 */     this.params.add(p);
/* 44 */     return p;
/*    */   }
/*    */ 
/*    */   
/*    */   public class Param
/*    */   {
/*    */     private String name;
/*    */     private String value;
/*    */     private final Extension this$0;
/*    */     
/*    */     public String getName() {
/* 55 */       return this.name;
/*    */     }
/*    */     
/*    */     public void setName(String name) {
/* 59 */       this.name = name;
/*    */     }
/*    */     
/*    */     public String getValue() {
/* 63 */       return this.value;
/*    */     }
/*    */     
/*    */     public void setValue(String value) {
/* 67 */       this.value = value;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\Extension.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */