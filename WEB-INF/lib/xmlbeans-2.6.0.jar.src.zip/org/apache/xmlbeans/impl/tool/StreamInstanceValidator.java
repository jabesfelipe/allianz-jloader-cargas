/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlError;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.validator.ValidatingXMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamInstanceValidator
/*     */ {
/*  42 */   private static final XMLInputFactory XML_INPUT_FACTORY = XMLInputFactory.newInstance();
/*     */ 
/*     */   
/*     */   public static void printUsage() {
/*  46 */     System.out.println("Validates the specified instance against the specified schema.");
/*  47 */     System.out.println("A streaming validation useful for validating very large instance ");
/*  48 */     System.out.println("documents with less memory. Contrast with the validate tool.");
/*  49 */     System.out.println("Usage: svalidate [-dl] [-nopvr] [-noupa] [-license] schema.xsd instance.xml");
/*  50 */     System.out.println("Options:");
/*  51 */     System.out.println("    -dl - permit network downloads for imports and includes (default is off)");
/*  52 */     System.out.println("    -noupa - do not enforce the unique particle attribution rule");
/*  53 */     System.out.println("    -nopvr - do not enforce the particle valid (restriction) rule");
/*  54 */     System.out.println("    -license - prints license information");
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*     */     SchemaTypeSystem schemaTypeSystem;
/*  59 */     Set flags = new HashSet();
/*  60 */     flags.add("h");
/*  61 */     flags.add("help");
/*  62 */     flags.add("usage");
/*  63 */     flags.add("license");
/*  64 */     flags.add("version");
/*  65 */     flags.add("dl");
/*  66 */     flags.add("noupr");
/*  67 */     flags.add("noupa");
/*     */     
/*  69 */     CommandLine cl = new CommandLine(args, flags, Collections.EMPTY_SET);
/*  70 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null || args.length < 1) {
/*     */       
/*  72 */       printUsage();
/*  73 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  77 */     String[] badopts = cl.getBadOpts();
/*  78 */     if (badopts.length > 0) {
/*     */       
/*  80 */       for (int j = 0; j < badopts.length; j++)
/*  81 */         System.out.println("Unrecognized option: " + badopts[j]); 
/*  82 */       printUsage();
/*  83 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  87 */     if (cl.getOpt("license") != null) {
/*  88 */       CommandLine.printLicense();
/*  89 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  93 */     if (cl.getOpt("version") != null) {
/*     */       
/*  95 */       CommandLine.printVersion();
/*  96 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 100 */     if ((cl.args()).length == 0) {
/* 101 */       printUsage();
/*     */       
/*     */       return;
/*     */     } 
/* 105 */     boolean dl = (cl.getOpt("dl") != null);
/* 106 */     boolean nopvr = (cl.getOpt("nopvr") != null);
/* 107 */     boolean noupa = (cl.getOpt("noupa") != null);
/*     */     
/* 109 */     File[] schemaFiles = cl.filesEndingWith(".xsd");
/* 110 */     File[] instanceFiles = cl.filesEndingWith(".xml");
/* 111 */     File[] jarFiles = cl.filesEndingWith(".jar");
/*     */     
/* 113 */     List sdocs = new ArrayList();
/*     */     
/* 115 */     XmlOptions options = (new XmlOptions()).setLoadLineNumbers();
/* 116 */     for (int i = 0; i < schemaFiles.length; i++) {
/*     */       try {
/* 118 */         sdocs.add(XmlObject.Factory.parse(schemaFiles[i], options.setLoadMessageDigest()));
/*     */ 
/*     */       
/*     */       }
/* 122 */       catch (Exception e) {
/* 123 */         System.err.println(schemaFiles[i] + " not loadable: " + e);
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     XmlObject[] schemas = sdocs.<XmlObject>toArray(new XmlObject[0]);
/*     */     
/* 129 */     SchemaTypeLoader sLoader = null;
/* 130 */     Collection compErrors = new ArrayList();
/* 131 */     XmlOptions schemaOptions = new XmlOptions();
/* 132 */     schemaOptions.setErrorListener(compErrors);
/* 133 */     if (dl)
/* 134 */       schemaOptions.setCompileDownloadUrls(); 
/* 135 */     if (nopvr)
/* 136 */       schemaOptions.setCompileNoPvrRule(); 
/* 137 */     if (noupa) {
/* 138 */       schemaOptions.setCompileNoUpaRule();
/*     */     }
/* 140 */     if (jarFiles != null && jarFiles.length > 0) {
/* 141 */       sLoader = XmlBeans.typeLoaderForResource(XmlBeans.resourceLoaderForPath(jarFiles));
/*     */     }
/*     */     try {
/* 144 */       if (schemas != null && schemas.length > 0) {
/* 145 */         schemaTypeSystem = XmlBeans.compileXsd(schemas, sLoader, schemaOptions);
/*     */       }
/* 147 */     } catch (Exception e) {
/* 148 */       if (compErrors.isEmpty() || !(e instanceof org.apache.xmlbeans.XmlException)) {
/* 149 */         e.printStackTrace(System.err);
/*     */       }
/* 151 */       System.out.println("Schema invalid");
/* 152 */       for (Iterator iterator = compErrors.iterator(); iterator.hasNext();) {
/* 153 */         System.out.println(iterator.next());
/*     */       }
/*     */       return;
/*     */     } 
/* 157 */     validateFiles(instanceFiles, (SchemaTypeLoader)schemaTypeSystem, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateFiles(File[] instanceFiles, SchemaTypeLoader sLoader, XmlOptions options) {
/* 165 */     ValidatingXMLStreamReader vsr = new ValidatingXMLStreamReader();
/* 166 */     Collection errors = new ArrayList();
/*     */     
/* 168 */     for (int i = 0; i < instanceFiles.length; i++) {
/* 169 */       File file = instanceFiles[i];
/* 170 */       String path = file.getPath();
/* 171 */       long time = 0L;
/*     */       
/* 173 */       errors.clear();
/*     */       
/*     */       try {
/* 176 */         FileInputStream fis = new FileInputStream(file);
/* 177 */         XMLStreamReader rdr = XML_INPUT_FACTORY.createXMLStreamReader(path, fis);
/*     */ 
/*     */ 
/*     */         
/* 181 */         while (!rdr.isStartElement()) {
/* 182 */           rdr.next();
/*     */         }
/*     */         
/* 185 */         time = System.currentTimeMillis();
/* 186 */         vsr.init(rdr, true, null, sLoader, options, errors);
/*     */         
/* 188 */         while (vsr.hasNext()) {
/* 189 */           vsr.next();
/*     */         }
/*     */         
/* 192 */         time = System.currentTimeMillis() - time;
/* 193 */         vsr.close();
/* 194 */         fis.close();
/*     */       }
/* 196 */       catch (XMLStreamException xse) {
/* 197 */         Location loc = xse.getLocation();
/* 198 */         XmlError e = XmlError.forLocation(xse.getMessage(), path, loc.getLineNumber(), loc.getColumnNumber(), loc.getCharacterOffset());
/*     */ 
/*     */ 
/*     */         
/* 202 */         errors.add(e);
/*     */       }
/* 204 */       catch (Exception e) {
/* 205 */         System.err.println("error for file: " + file + ": " + e);
/* 206 */         e.printStackTrace(System.err);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 211 */       if (errors.isEmpty()) {
/* 212 */         System.out.println(file + " valid. (" + time + " ms)");
/*     */       } else {
/* 214 */         System.out.println(file + " NOT valid (" + time + " ms):");
/* 215 */         for (Iterator it = errors.iterator(); it.hasNext(); ) {
/* 216 */           XmlError err = it.next();
/* 217 */           System.out.println(stringFromError(err, path));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String stringFromError(XmlError err, String path) {
/* 227 */     String s = XmlError.severityAsString(err.getSeverity()) + ": " + path + ":" + err.getLine() + ":" + err.getColumn() + " " + err.getMessage() + " ";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     return s;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\StreamInstanceValidator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */