/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.FormChoice;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.IncludeDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.NamedAttributeGroup;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.NamedGroup;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelAttribute;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelComplexType;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelElement;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.TopLevelSimpleType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FactorImports
/*     */ {
/*     */   public static void printUsage() {
/*  54 */     System.out.println("Refactors a directory of XSD files to remove name conflicts.");
/*  55 */     System.out.println("Usage: sfactor [-import common.xsd] [-out outputdir] inputdir");
/*  56 */     System.out.println("    -import common.xsd - The XSD file to contain redundant ");
/*  57 */     System.out.println("                         definitions for importing.");
/*  58 */     System.out.println("    -out outputdir - The directory into which to place XSD ");
/*  59 */     System.out.println("                     files resulting from refactoring, ");
/*  60 */     System.out.println("                     plus a commonly imported common.xsd.");
/*  61 */     System.out.println("    inputdir - The directory containing the XSD files with");
/*  62 */     System.out.println("               redundant definitions.");
/*  63 */     System.out.println("    -license - Print license information.");
/*  64 */     System.out.println();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/*  70 */     Set flags = new HashSet();
/*  71 */     flags.add("h");
/*  72 */     flags.add("help");
/*  73 */     flags.add("usage");
/*  74 */     flags.add("license");
/*  75 */     flags.add("version");
/*     */     
/*  77 */     CommandLine cl = new CommandLine(args, flags, Arrays.asList(new String[] { "import", "out" }));
/*  78 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null || args.length < 1) {
/*     */       
/*  80 */       printUsage();
/*  81 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  85 */     String[] badopts = cl.getBadOpts();
/*  86 */     if (badopts.length > 0) {
/*     */       
/*  88 */       for (int j = 0; j < badopts.length; j++)
/*  89 */         System.out.println("Unrecognized option: " + badopts[j]); 
/*  90 */       printUsage();
/*  91 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  95 */     if (cl.getOpt("license") != null) {
/*     */       
/*  97 */       CommandLine.printLicense();
/*  98 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 102 */     if (cl.getOpt("version") != null) {
/*     */       
/* 104 */       CommandLine.printVersion();
/* 105 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 109 */     args = cl.args();
/* 110 */     if (args.length != 1) {
/*     */       
/* 112 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 116 */     String commonName = cl.getOpt("import");
/* 117 */     if (commonName == null) {
/* 118 */       commonName = "common.xsd";
/*     */     }
/* 120 */     String out = cl.getOpt("out");
/* 121 */     if (out == null) {
/*     */       
/* 123 */       System.out.println("Using output directory 'out'");
/* 124 */       out = "out";
/*     */     } 
/* 126 */     File outdir = new File(out);
/* 127 */     File basedir = new File(args[0]);
/*     */ 
/*     */     
/* 130 */     File[] files = cl.getFiles();
/* 131 */     Map schemaDocs = new HashMap();
/* 132 */     Set elementNames = new HashSet();
/* 133 */     Set attributeNames = new HashSet();
/* 134 */     Set typeNames = new HashSet();
/* 135 */     Set modelGroupNames = new HashSet();
/* 136 */     Set attrGroupNames = new HashSet();
/*     */     
/* 138 */     Set dupeElementNames = new HashSet();
/* 139 */     Set dupeAttributeNames = new HashSet();
/* 140 */     Set dupeTypeNames = new HashSet();
/* 141 */     Set dupeModelGroupNames = new HashSet();
/* 142 */     Set dupeAttrGroupNames = new HashSet();
/* 143 */     Set dupeNamespaces = new HashSet();
/*     */     
/* 145 */     for (int i = 0; i < files.length; i++) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 150 */         SchemaDocument doc = SchemaDocument.Factory.parse(files[i]);
/* 151 */         schemaDocs.put(doc, files[i]);
/*     */ 
/*     */         
/* 154 */         if (doc.getSchema().sizeOfImportArray() > 0 || doc.getSchema().sizeOfIncludeArray() > 0) {
/* 155 */           System.out.println("warning: " + files[i] + " contains imports or includes that are being ignored.");
/*     */         }
/*     */         
/* 158 */         String targetNamespace = doc.getSchema().getTargetNamespace();
/* 159 */         if (targetNamespace == null) {
/* 160 */           targetNamespace = "";
/*     */         }
/* 162 */         TopLevelComplexType[] ct = doc.getSchema().getComplexTypeArray();
/* 163 */         for (int j = 0; j < ct.length; j++) {
/* 164 */           noteName(ct[j].getName(), targetNamespace, typeNames, dupeTypeNames, dupeNamespaces);
/*     */         }
/* 166 */         TopLevelSimpleType[] st = doc.getSchema().getSimpleTypeArray();
/* 167 */         for (int k = 0; k < st.length; k++) {
/* 168 */           noteName(st[k].getName(), targetNamespace, typeNames, dupeTypeNames, dupeNamespaces);
/*     */         }
/* 170 */         TopLevelElement[] el = doc.getSchema().getElementArray();
/* 171 */         for (int m = 0; m < el.length; m++) {
/* 172 */           noteName(el[m].getName(), targetNamespace, elementNames, dupeElementNames, dupeNamespaces);
/*     */         }
/* 174 */         TopLevelAttribute[] at = doc.getSchema().getAttributeArray();
/* 175 */         for (int n = 0; n < at.length; n++) {
/* 176 */           noteName(at[n].getName(), targetNamespace, attributeNames, dupeAttributeNames, dupeNamespaces);
/*     */         }
/* 178 */         NamedGroup[] gr = doc.getSchema().getGroupArray();
/* 179 */         for (int i1 = 0; i1 < gr.length; i1++) {
/* 180 */           noteName(gr[i1].getName(), targetNamespace, modelGroupNames, dupeModelGroupNames, dupeNamespaces);
/*     */         }
/* 182 */         NamedAttributeGroup[] ag = doc.getSchema().getAttributeGroupArray();
/* 183 */         for (int i2 = 0; i2 < ag.length; i2++) {
/* 184 */           noteName(ag[i2].getName(), targetNamespace, attrGroupNames, dupeAttrGroupNames, dupeNamespaces);
/*     */         }
/*     */       }
/* 187 */       catch (XmlException e) {
/*     */         
/* 189 */         System.out.println("warning: " + files[i] + " is not a schema file - " + e.getError().toString());
/*     */       }
/* 191 */       catch (IOException e) {
/*     */         
/* 193 */         System.err.println("Unable to load " + files[i] + " - " + e.getMessage());
/* 194 */         System.exit(1);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 199 */     if (schemaDocs.size() == 0) {
/*     */       
/* 201 */       System.out.println("No schema files found.");
/* 202 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 206 */     if (dupeTypeNames.size() + dupeElementNames.size() + dupeAttributeNames.size() + dupeModelGroupNames.size() + dupeAttrGroupNames.size() == 0) {
/*     */ 
/*     */       
/* 209 */       System.out.println("No duplicate names found.");
/* 210 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 215 */     Map commonDocs = new HashMap();
/* 216 */     Map commonFiles = new HashMap();
/* 217 */     int count = (dupeNamespaces.size() == 1) ? 0 : 1;
/* 218 */     for (Iterator iterator = dupeNamespaces.iterator(); iterator.hasNext(); ) {
/*     */       
/* 220 */       String namespace = iterator.next();
/* 221 */       SchemaDocument commonDoc = SchemaDocument.Factory.parse("<xs:schema xmlns:xs='http://www.w3.org/2001/XMLSchema'/>");
/*     */ 
/*     */       
/* 224 */       if (namespace.length() > 0)
/* 225 */         commonDoc.getSchema().setTargetNamespace(namespace); 
/* 226 */       commonDoc.getSchema().setElementFormDefault(FormChoice.QUALIFIED);
/* 227 */       commonDocs.put(namespace, commonDoc);
/* 228 */       commonFiles.put(commonDoc, commonFileFor(commonName, namespace, count++, outdir));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     for (Iterator iterator3 = schemaDocs.keySet().iterator(); iterator3.hasNext(); ) {
/*     */       
/* 236 */       SchemaDocument doc = iterator3.next();
/*     */ 
/*     */       
/* 239 */       String targetNamespace = doc.getSchema().getTargetNamespace();
/* 240 */       if (targetNamespace == null) {
/* 241 */         targetNamespace = "";
/*     */       }
/* 243 */       SchemaDocument commonDoc = (SchemaDocument)commonDocs.get(targetNamespace);
/*     */       
/* 245 */       boolean needImport = false;
/*     */       
/* 247 */       TopLevelComplexType[] ct = doc.getSchema().getComplexTypeArray();
/* 248 */       for (int j = ct.length - 1; j >= 0; j--) {
/*     */         
/* 250 */         if (isDuplicate(ct[j].getName(), targetNamespace, dupeTypeNames)) {
/*     */           
/* 252 */           if (isFirstDuplicate(ct[j].getName(), targetNamespace, typeNames, dupeTypeNames))
/* 253 */             commonDoc.getSchema().addNewComplexType().set((XmlObject)ct[j]); 
/* 254 */           needImport = true;
/* 255 */           doc.getSchema().removeComplexType(j);
/*     */         } 
/*     */       } 
/* 258 */       TopLevelSimpleType[] st = doc.getSchema().getSimpleTypeArray();
/* 259 */       for (int k = 0; k < st.length; k++) {
/*     */         
/* 261 */         if (isDuplicate(st[k].getName(), targetNamespace, dupeTypeNames)) {
/*     */           
/* 263 */           if (isFirstDuplicate(st[k].getName(), targetNamespace, typeNames, dupeTypeNames))
/* 264 */             commonDoc.getSchema().addNewSimpleType().set((XmlObject)st[k]); 
/* 265 */           needImport = true;
/* 266 */           doc.getSchema().removeSimpleType(k);
/*     */         } 
/*     */       } 
/* 269 */       TopLevelElement[] el = doc.getSchema().getElementArray();
/* 270 */       for (int m = 0; m < el.length; m++) {
/*     */         
/* 272 */         if (isDuplicate(el[m].getName(), targetNamespace, dupeElementNames)) {
/*     */           
/* 274 */           if (isFirstDuplicate(el[m].getName(), targetNamespace, elementNames, dupeElementNames))
/* 275 */             commonDoc.getSchema().addNewElement().set((XmlObject)el[m]); 
/* 276 */           needImport = true;
/* 277 */           doc.getSchema().removeElement(m);
/*     */         } 
/*     */       } 
/* 280 */       TopLevelAttribute[] at = doc.getSchema().getAttributeArray();
/* 281 */       for (int n = 0; n < at.length; n++) {
/*     */         
/* 283 */         if (isDuplicate(at[n].getName(), targetNamespace, dupeAttributeNames)) {
/*     */           
/* 285 */           if (isFirstDuplicate(at[n].getName(), targetNamespace, attributeNames, dupeAttributeNames))
/* 286 */             commonDoc.getSchema().addNewElement().set((XmlObject)at[n]); 
/* 287 */           needImport = true;
/* 288 */           doc.getSchema().removeElement(n);
/*     */         } 
/*     */       } 
/* 291 */       NamedGroup[] gr = doc.getSchema().getGroupArray();
/* 292 */       for (int i1 = 0; i1 < gr.length; i1++) {
/*     */         
/* 294 */         if (isDuplicate(gr[i1].getName(), targetNamespace, dupeModelGroupNames)) {
/*     */           
/* 296 */           if (isFirstDuplicate(gr[i1].getName(), targetNamespace, modelGroupNames, dupeModelGroupNames))
/* 297 */             commonDoc.getSchema().addNewElement().set((XmlObject)gr[i1]); 
/* 298 */           needImport = true;
/* 299 */           doc.getSchema().removeElement(i1);
/*     */         } 
/*     */       } 
/* 302 */       NamedAttributeGroup[] ag = doc.getSchema().getAttributeGroupArray();
/* 303 */       for (int i2 = 0; i2 < ag.length; i2++) {
/*     */         
/* 305 */         if (isDuplicate(ag[i2].getName(), targetNamespace, dupeAttrGroupNames)) {
/*     */           
/* 307 */           if (isFirstDuplicate(ag[i2].getName(), targetNamespace, attrGroupNames, dupeAttrGroupNames))
/* 308 */             commonDoc.getSchema().addNewElement().set((XmlObject)ag[i2]); 
/* 309 */           needImport = true;
/* 310 */           doc.getSchema().removeElement(i2);
/*     */         } 
/*     */       } 
/* 313 */       if (needImport) {
/*     */         
/* 315 */         IncludeDocument.Include newInclude = doc.getSchema().addNewInclude();
/* 316 */         File inputFile = (File)schemaDocs.get(doc);
/* 317 */         File outputFile = outputFileFor(inputFile, basedir, outdir);
/* 318 */         File commonFile = (File)commonFiles.get(commonDoc);
/* 319 */         if (targetNamespace != null) {
/* 320 */           newInclude.setSchemaLocation(relativeURIFor(outputFile, commonFile));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 325 */     if (!outdir.isDirectory() && !outdir.mkdirs()) {
/*     */       
/* 327 */       System.err.println("Unable to makedir " + outdir);
/* 328 */       System.exit(1);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 333 */     for (Iterator iterator2 = schemaDocs.keySet().iterator(); iterator2.hasNext(); ) {
/*     */       
/* 335 */       SchemaDocument doc = iterator2.next();
/* 336 */       File inputFile = (File)schemaDocs.get(doc);
/* 337 */       File outputFile = outputFileFor(inputFile, basedir, outdir);
/* 338 */       if (outputFile == null) {
/* 339 */         System.out.println("Cannot copy " + inputFile); continue;
/*     */       } 
/* 341 */       doc.save(outputFile, (new XmlOptions()).setSavePrettyPrint().setSaveAggresiveNamespaces());
/*     */     } 
/*     */     
/* 344 */     for (Iterator iterator1 = commonFiles.keySet().iterator(); iterator1.hasNext(); ) {
/*     */       
/* 346 */       SchemaDocument doc = iterator1.next();
/* 347 */       File outputFile = (File)commonFiles.get(doc);
/* 348 */       doc.save(outputFile, (new XmlOptions()).setSavePrettyPrint().setSaveAggresiveNamespaces());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static File outputFileFor(File file, File baseDir, File outdir) {
/* 355 */     URI base = baseDir.getAbsoluteFile().toURI();
/* 356 */     URI abs = file.getAbsoluteFile().toURI();
/* 357 */     URI rel = base.relativize(abs);
/* 358 */     if (rel.isAbsolute()) {
/*     */       
/* 360 */       System.out.println("Cannot relativize " + file);
/* 361 */       return null;
/*     */     } 
/*     */     
/* 364 */     URI outbase = outdir.toURI();
/* 365 */     URI out = CodeGenUtil.resolve(outbase, rel);
/* 366 */     return new File(out);
/*     */   }
/*     */ 
/*     */   
/*     */   private static URI commonAncestor(URI first, URI second) {
/* 371 */     String firstStr = first.toString();
/* 372 */     String secondStr = second.toString();
/* 373 */     int len = firstStr.length();
/* 374 */     if (secondStr.length() < len)
/* 375 */       len = secondStr.length(); 
/*     */     int i;
/* 377 */     for (i = 0; i < len; i++) {
/*     */       
/* 379 */       if (firstStr.charAt(i) != secondStr.charAt(i))
/*     */         break; 
/*     */     } 
/* 382 */     i--;
/* 383 */     if (i >= 0)
/* 384 */       i = firstStr.lastIndexOf('/', i); 
/* 385 */     if (i < 0) {
/* 386 */       return null;
/*     */     }
/*     */     try {
/* 389 */       return new URI(firstStr.substring(0, i));
/*     */     }
/* 391 */     catch (URISyntaxException e) {
/*     */       
/* 393 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String relativeURIFor(File source, File target) {
/* 400 */     URI base = source.getAbsoluteFile().toURI();
/* 401 */     URI abs = target.getAbsoluteFile().toURI();
/*     */     
/* 403 */     URI commonBase = commonAncestor(base, abs);
/* 404 */     if (commonBase == null) {
/* 405 */       return abs.toString();
/*     */     }
/* 407 */     URI baserel = commonBase.relativize(base);
/* 408 */     URI targetrel = commonBase.relativize(abs);
/* 409 */     if (baserel.isAbsolute() || targetrel.isAbsolute())
/* 410 */       return abs.toString(); 
/* 411 */     String prefix = "";
/* 412 */     String sourceRel = baserel.toString();
/* 413 */     for (int i = 0; i < sourceRel.length(); ) {
/*     */       
/* 415 */       i = sourceRel.indexOf('/', i);
/* 416 */       if (i < 0)
/*     */         break; 
/* 418 */       prefix = prefix + "../";
/* 419 */       i++;
/*     */     } 
/* 421 */     return prefix + targetrel.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static File commonFileFor(String commonName, String namespace, int i, File outdir) {
/* 426 */     String name = commonName;
/* 427 */     if (i > 0) {
/*     */       
/* 429 */       int index = commonName.lastIndexOf('.');
/* 430 */       if (index < 0)
/* 431 */         index = commonName.length(); 
/* 432 */       name = commonName.substring(0, index) + i + commonName.substring(index);
/*     */     } 
/* 434 */     return new File(outdir, name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void noteName(String name, String targetNamespace, Set seen, Set dupes, Set dupeNamespaces) {
/* 440 */     if (name == null)
/*     */       return; 
/* 442 */     QName qName = new QName(targetNamespace, name);
/* 443 */     if (seen.contains(qName)) {
/*     */       
/* 445 */       dupes.add(qName);
/* 446 */       dupeNamespaces.add(targetNamespace);
/*     */     } else {
/*     */       
/* 449 */       seen.add(qName);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isFirstDuplicate(String name, String targetNamespace, Set notseen, Set dupes) {
/* 455 */     if (name == null)
/* 456 */       return false; 
/* 457 */     QName qName = new QName(targetNamespace, name);
/* 458 */     if (dupes.contains(qName) && notseen.contains(qName)) {
/*     */       
/* 460 */       notseen.remove(qName);
/* 461 */       return true;
/*     */     } 
/* 463 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isDuplicate(String name, String targetNamespace, Set dupes) {
/* 468 */     if (name == null)
/* 469 */       return false; 
/* 470 */     QName qName = new QName(targetNamespace, name);
/* 471 */     return dupes.contains(qName);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\FactorImports.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */