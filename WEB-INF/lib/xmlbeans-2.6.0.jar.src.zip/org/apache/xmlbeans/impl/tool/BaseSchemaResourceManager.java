/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.DigestInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.impl.common.IOUtil;
/*     */ import org.apache.xmlbeans.impl.util.HexBin;
/*     */ import org.apache.xmlbeans.impl.xb.xsdownload.DownloadedSchemaEntry;
/*     */ import org.apache.xmlbeans.impl.xb.xsdownload.DownloadedSchemasDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseSchemaResourceManager
/*     */   extends SchemaImportResolver
/*     */ {
/*  48 */   private static final String USER_AGENT = "XMLBeans/" + XmlBeans.getVersion() + " (" + XmlBeans.getTitle() + ")";
/*     */   
/*     */   private String _defaultCopyDirectory;
/*     */   private DownloadedSchemasDocument _importsDoc;
/*  52 */   private Map _resourceForFilename = new HashMap();
/*  53 */   private Map _resourceForURL = new HashMap();
/*  54 */   private Map _resourceForNamespace = new HashMap();
/*  55 */   private Map _resourceForDigest = new HashMap();
/*  56 */   private Map _resourceForCacheEntry = new HashMap();
/*  57 */   private Set _redownloadSet = new HashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void init() {
/*  66 */     if (fileExists(getIndexFilename())) {
/*     */       
/*     */       try {
/*     */         
/*  70 */         this._importsDoc = DownloadedSchemasDocument.Factory.parse(inputStreamForFile(getIndexFilename()));
/*     */       }
/*  72 */       catch (IOException e) {
/*     */         
/*  74 */         this._importsDoc = null;
/*     */       }
/*  76 */       catch (Exception e) {
/*     */         
/*  78 */         throw (IllegalStateException)(new IllegalStateException("Problem reading xsdownload.xml: please fix or delete this file")).initCause(e);
/*     */       } 
/*     */     }
/*  81 */     if (this._importsDoc == null) {
/*     */       
/*     */       try {
/*     */         
/*  85 */         this._importsDoc = DownloadedSchemasDocument.Factory.parse("<dls:downloaded-schemas xmlns:dls='http://www.bea.com/2003/01/xmlbean/xsdownload' defaultDirectory='" + getDefaultSchemaDir() + "'/>");
/*     */ 
/*     */       
/*     */       }
/*  89 */       catch (Exception e) {
/*     */         
/*  91 */         throw (IllegalStateException)(new IllegalStateException()).initCause(e);
/*     */       } 
/*     */     }
/*     */     
/*  95 */     String defaultDir = this._importsDoc.getDownloadedSchemas().getDefaultDirectory();
/*  96 */     if (defaultDir == null)
/*  97 */       defaultDir = getDefaultSchemaDir(); 
/*  98 */     this._defaultCopyDirectory = defaultDir;
/*     */ 
/*     */     
/* 101 */     DownloadedSchemaEntry[] entries = this._importsDoc.getDownloadedSchemas().getEntryArray();
/* 102 */     for (int i = 0; i < entries.length; i++)
/*     */     {
/* 104 */       updateResource(entries[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void writeCache() throws IOException {
/* 110 */     InputStream input = this._importsDoc.newInputStream((new XmlOptions()).setSavePrettyPrint());
/* 111 */     writeInputStreamToFile(input, getIndexFilename());
/*     */   }
/*     */ 
/*     */   
/*     */   public final void processAll(boolean sync, boolean refresh, boolean imports) {
/* 116 */     if (refresh) {
/*     */       
/* 118 */       this._redownloadSet = new HashSet();
/*     */     }
/*     */     else {
/*     */       
/* 122 */       this._redownloadSet = null;
/*     */     } 
/*     */     
/* 125 */     String[] allFilenames = getAllXSDFilenames();
/*     */     
/* 127 */     if (sync) {
/* 128 */       syncCacheWithLocalXsdFiles(allFilenames, false);
/*     */     }
/* 130 */     SchemaResource[] starters = (SchemaResource[])this._resourceForFilename.values().toArray((Object[])new SchemaResource[0]);
/*     */ 
/*     */     
/* 133 */     if (refresh) {
/* 134 */       redownloadEntries(starters);
/*     */     }
/* 136 */     if (imports) {
/* 137 */       resolveImports((SchemaImportResolver.SchemaResource[])starters);
/*     */     }
/* 139 */     this._redownloadSet = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void process(String[] uris, String[] filenames, boolean sync, boolean refresh, boolean imports) {
/* 144 */     if (refresh) {
/*     */       
/* 146 */       this._redownloadSet = new HashSet();
/*     */     }
/*     */     else {
/*     */       
/* 150 */       this._redownloadSet = null;
/*     */     } 
/*     */     
/* 153 */     if (filenames.length > 0) {
/* 154 */       syncCacheWithLocalXsdFiles(filenames, true);
/* 155 */     } else if (sync) {
/* 156 */       syncCacheWithLocalXsdFiles(getAllXSDFilenames(), false);
/*     */     } 
/* 158 */     Set starterset = new HashSet();
/*     */     int i;
/* 160 */     for (i = 0; i < uris.length; i++) {
/*     */       
/* 162 */       SchemaResource resource = (SchemaResource)lookupResource((String)null, uris[i]);
/* 163 */       if (resource != null) {
/* 164 */         starterset.add(resource);
/*     */       }
/*     */     } 
/* 167 */     for (i = 0; i < filenames.length; i++) {
/*     */       
/* 169 */       SchemaResource resource = (SchemaResource)this._resourceForFilename.get(filenames);
/* 170 */       if (resource != null) {
/* 171 */         starterset.add(resource);
/*     */       }
/*     */     } 
/* 174 */     SchemaResource[] starters = starterset.<SchemaResource>toArray(new SchemaResource[0]);
/*     */ 
/*     */     
/* 177 */     if (refresh) {
/* 178 */       redownloadEntries(starters);
/*     */     }
/* 180 */     if (imports) {
/* 181 */       resolveImports((SchemaImportResolver.SchemaResource[])starters);
/*     */     }
/* 183 */     this._redownloadSet = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void syncCacheWithLocalXsdFiles(String[] filenames, boolean deleteOnlyMentioned) {
/* 196 */     Set seenResources = new HashSet();
/* 197 */     Set vanishedResources = new HashSet();
/*     */     
/* 199 */     for (int i = 0; i < filenames.length; i++) {
/*     */       
/* 201 */       String filename = filenames[i];
/*     */ 
/*     */       
/* 204 */       SchemaResource resource = (SchemaResource)this._resourceForFilename.get(filename);
/* 205 */       if (resource != null) {
/*     */         
/* 207 */         if (fileExists(filename)) {
/* 208 */           seenResources.add(resource);
/*     */         } else {
/* 210 */           vanishedResources.add(resource);
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 216 */       String digest = null;
/*     */       
/*     */       try {
/* 219 */         digest = shaDigestForFile(filename);
/* 220 */         resource = (SchemaResource)this._resourceForDigest.get(digest);
/* 221 */         if (resource != null) {
/*     */           
/* 223 */           String oldFilename = resource.getFilename();
/* 224 */           if (!fileExists(oldFilename)) {
/*     */             
/* 226 */             warning("File " + filename + " is a rename of " + oldFilename);
/* 227 */             resource.setFilename(filename);
/* 228 */             seenResources.add(resource);
/* 229 */             if (this._resourceForFilename.get(oldFilename) == resource)
/* 230 */               this._resourceForFilename.remove(oldFilename); 
/* 231 */             if (this._resourceForFilename.containsKey(filename)) {
/* 232 */               this._resourceForFilename.put(filename, resource);
/*     */             }
/*     */             continue;
/*     */           } 
/*     */         } 
/* 237 */       } catch (IOException e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 243 */       DownloadedSchemaEntry newEntry = addNewEntry();
/* 244 */       newEntry.setFilename(filename);
/* 245 */       warning("Caching information on new local file " + filename);
/* 246 */       if (digest != null) {
/* 247 */         newEntry.setSha1(digest);
/*     */       }
/* 249 */       seenResources.add(updateResource(newEntry));
/*     */       continue;
/*     */     } 
/* 252 */     if (deleteOnlyMentioned) {
/* 253 */       deleteResourcesInSet(vanishedResources, true);
/*     */     } else {
/* 255 */       deleteResourcesInSet(seenResources, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void redownloadEntries(SchemaResource[] resources) {
/* 264 */     for (int i = 0; i < resources.length; i++)
/*     */     {
/* 266 */       redownloadResource(resources[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void deleteResourcesInSet(Set seenResources, boolean setToDelete) {
/* 272 */     Set seenCacheEntries = new HashSet();
/* 273 */     for (Iterator i = seenResources.iterator(); i.hasNext(); ) {
/*     */       
/* 275 */       SchemaResource resource = i.next();
/* 276 */       seenCacheEntries.add(resource._cacheEntry);
/*     */     } 
/*     */     
/* 279 */     DownloadedSchemasDocument.DownloadedSchemas downloadedSchemas = this._importsDoc.getDownloadedSchemas();
/* 280 */     for (int j = 0; j < downloadedSchemas.sizeOfEntryArray(); j++) {
/*     */       
/* 282 */       DownloadedSchemaEntry cacheEntry = downloadedSchemas.getEntryArray(j);
/*     */       
/* 284 */       if (seenCacheEntries.contains(cacheEntry) == setToDelete) {
/*     */         
/* 286 */         SchemaResource resource = (SchemaResource)this._resourceForCacheEntry.get(cacheEntry);
/* 287 */         warning("Removing obsolete cache entry for " + resource.getFilename());
/*     */         
/* 289 */         if (resource != null) {
/*     */           
/* 291 */           this._resourceForCacheEntry.remove(cacheEntry);
/*     */           
/* 293 */           if (resource == this._resourceForFilename.get(resource.getFilename())) {
/* 294 */             this._resourceForFilename.remove(resource.getFilename());
/*     */           }
/* 296 */           if (resource == this._resourceForDigest.get(resource.getSha1())) {
/* 297 */             this._resourceForDigest.remove(resource.getSha1());
/*     */           }
/* 299 */           if (resource == this._resourceForNamespace.get(resource.getNamespace())) {
/* 300 */             this._resourceForNamespace.remove(resource.getNamespace());
/*     */           }
/*     */           
/* 303 */           String[] urls = resource.getSchemaLocationArray();
/* 304 */           for (int k = 0; k < urls.length; k++) {
/*     */             
/* 306 */             if (resource == this._resourceForURL.get(urls[k])) {
/* 307 */               this._resourceForURL.remove(urls[k]);
/*     */             }
/*     */           } 
/*     */         } 
/* 311 */         downloadedSchemas.removeEntry(j);
/* 312 */         j--;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private SchemaResource updateResource(DownloadedSchemaEntry entry) {
/* 320 */     String filename = entry.getFilename();
/* 321 */     if (filename == null) {
/* 322 */       return null;
/*     */     }
/* 324 */     SchemaResource resource = new SchemaResource(entry);
/* 325 */     this._resourceForCacheEntry.put(entry, resource);
/*     */     
/* 327 */     if (!this._resourceForFilename.containsKey(filename)) {
/* 328 */       this._resourceForFilename.put(filename, resource);
/*     */     }
/*     */     
/* 331 */     String digest = resource.getSha1();
/* 332 */     if (digest != null)
/*     */     {
/* 334 */       if (!this._resourceForDigest.containsKey(digest)) {
/* 335 */         this._resourceForDigest.put(digest, resource);
/*     */       }
/*     */     }
/*     */     
/* 339 */     String namespace = resource.getNamespace();
/* 340 */     if (namespace != null)
/*     */     {
/* 342 */       if (!this._resourceForNamespace.containsKey(namespace)) {
/* 343 */         this._resourceForNamespace.put(namespace, resource);
/*     */       }
/*     */     }
/*     */     
/* 347 */     String[] urls = resource.getSchemaLocationArray();
/* 348 */     for (int j = 0; j < urls.length; j++) {
/*     */       
/* 350 */       if (!this._resourceForURL.containsKey(urls[j])) {
/* 351 */         this._resourceForURL.put(urls[j], resource);
/*     */       }
/*     */     } 
/* 354 */     return resource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static DigestInputStream digestInputStream(InputStream input) {
/*     */     MessageDigest sha;
/*     */     try {
/* 362 */       sha = MessageDigest.getInstance("SHA");
/*     */     }
/* 364 */     catch (NoSuchAlgorithmException e) {
/*     */       
/* 366 */       throw (IllegalStateException)(new IllegalStateException()).initCause(e);
/*     */     } 
/*     */     
/* 369 */     DigestInputStream str = new DigestInputStream(input, sha);
/*     */     
/* 371 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   private DownloadedSchemaEntry addNewEntry() {
/* 376 */     return this._importsDoc.getDownloadedSchemas().addNewEntry();
/*     */   }
/*     */   
/*     */   private class SchemaResource implements SchemaImportResolver.SchemaResource {
/*     */     DownloadedSchemaEntry _cacheEntry;
/*     */     
/*     */     SchemaResource(DownloadedSchemaEntry entry) {
/* 383 */       this._cacheEntry = entry;
/*     */     }
/*     */ 
/*     */     
/*     */     private final BaseSchemaResourceManager this$0;
/*     */     
/*     */     public void setFilename(String filename) {
/* 390 */       this._cacheEntry.setFilename(filename);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getFilename() {
/* 395 */       return this._cacheEntry.getFilename();
/*     */     }
/*     */ 
/*     */     
/*     */     public SchemaDocument.Schema getSchema() {
/* 400 */       if (!BaseSchemaResourceManager.this.fileExists(getFilename())) {
/* 401 */         BaseSchemaResourceManager.this.redownloadResource(this);
/*     */       }
/*     */       
/*     */       try {
/* 405 */         return SchemaDocument.Factory.parse(BaseSchemaResourceManager.this.inputStreamForFile(getFilename())).getSchema();
/*     */       }
/* 407 */       catch (Exception e) {
/*     */         
/* 409 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSha1() {
/* 415 */       return this._cacheEntry.getSha1();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getNamespace() {
/* 420 */       return this._cacheEntry.getNamespace();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setNamespace(String namespace) {
/* 425 */       this._cacheEntry.setNamespace(namespace);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSchemaLocation() {
/* 430 */       if (this._cacheEntry.sizeOfSchemaLocationArray() > 0)
/* 431 */         return this._cacheEntry.getSchemaLocationArray(0); 
/* 432 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getSchemaLocationArray() {
/* 437 */       return this._cacheEntry.getSchemaLocationArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 442 */       return getFilename().hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 447 */       return (this == obj || getFilename().equals(((SchemaResource)obj).getFilename()));
/*     */     }
/*     */ 
/*     */     
/*     */     public void addSchemaLocation(String schemaLocation) {
/* 452 */       this._cacheEntry.addSchemaLocation(schemaLocation);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaImportResolver.SchemaResource lookupResource(String nsURI, String schemaLocation) {
/* 466 */     SchemaResource result = fetchFromCache(nsURI, schemaLocation);
/* 467 */     if (result != null) {
/*     */       
/* 469 */       if (this._redownloadSet != null)
/*     */       {
/* 471 */         redownloadResource(result);
/*     */       }
/* 473 */       return result;
/*     */     } 
/*     */     
/* 476 */     if (schemaLocation == null) {
/*     */       
/* 478 */       warning("No cached schema for namespace '" + nsURI + "', and no url specified");
/* 479 */       return null;
/*     */     } 
/*     */     
/* 482 */     result = copyOrIdentifyDuplicateURL(schemaLocation, nsURI);
/* 483 */     if (this._redownloadSet != null)
/* 484 */       this._redownloadSet.add(result); 
/* 485 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SchemaResource fetchFromCache(String nsURI, String schemaLocation) {
/* 492 */     if (schemaLocation != null) {
/*     */       
/* 494 */       SchemaResource result = (SchemaResource)this._resourceForURL.get(schemaLocation);
/* 495 */       if (result != null) {
/* 496 */         return result;
/*     */       }
/*     */     } 
/* 499 */     if (nsURI != null) {
/*     */       
/* 501 */       SchemaResource result = (SchemaResource)this._resourceForNamespace.get(nsURI);
/* 502 */       if (result != null) {
/* 503 */         return result;
/*     */       }
/*     */     } 
/* 506 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private String uniqueFilenameForURI(String schemaLocation) throws IOException, URISyntaxException {
/* 511 */     String localFilename = (new URI(schemaLocation)).getRawPath();
/* 512 */     int i = localFilename.lastIndexOf('/');
/* 513 */     if (i >= 0)
/* 514 */       localFilename = localFilename.substring(i + 1); 
/* 515 */     if (localFilename.endsWith(".xsd"))
/* 516 */       localFilename = localFilename.substring(0, localFilename.length() - 4); 
/* 517 */     if (localFilename.length() == 0) {
/* 518 */       localFilename = "schema";
/*     */     }
/*     */ 
/*     */     
/* 522 */     String candidateFilename = localFilename;
/* 523 */     int suffix = 1;
/* 524 */     while (suffix < 1000) {
/*     */       
/* 526 */       String candidate = this._defaultCopyDirectory + "/" + candidateFilename + ".xsd";
/* 527 */       if (!fileExists(candidate))
/* 528 */         return candidate; 
/* 529 */       suffix++;
/* 530 */       candidateFilename = localFilename + suffix;
/*     */     } 
/*     */     
/* 533 */     throw new IOException("Problem with filename " + localFilename + ".xsd");
/*     */   }
/*     */ 
/*     */   
/*     */   private void redownloadResource(SchemaResource resource) {
/* 538 */     if (this._redownloadSet != null) {
/*     */       
/* 540 */       if (this._redownloadSet.contains(resource))
/*     */         return; 
/* 542 */       this._redownloadSet.add(resource);
/*     */     } 
/*     */     
/* 545 */     String filename = resource.getFilename();
/* 546 */     String schemaLocation = resource.getSchemaLocation();
/* 547 */     String digest = null;
/*     */ 
/*     */     
/* 550 */     if (schemaLocation == null || filename == null) {
/*     */       return;
/*     */     }
/* 553 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/*     */ 
/*     */     
/*     */     try {
/* 557 */       URL url = new URL(schemaLocation);
/* 558 */       URLConnection conn = url.openConnection();
/* 559 */       conn.addRequestProperty("User-Agent", USER_AGENT);
/* 560 */       conn.addRequestProperty("Accept", "application/xml, text/xml, */*");
/* 561 */       DigestInputStream input = digestInputStream(conn.getInputStream());
/* 562 */       IOUtil.copyCompletely(input, buffer);
/* 563 */       digest = HexBin.bytesToString(input.getMessageDigest().digest());
/*     */     }
/* 565 */     catch (Exception e) {
/*     */       
/* 567 */       warning("Could not copy remote resource " + schemaLocation + ":" + e.getMessage());
/*     */       
/*     */       return;
/*     */     } 
/* 571 */     if (digest.equals(resource.getSha1()) && fileExists(filename)) {
/*     */       
/* 573 */       warning("Resource " + filename + " is unchanged from " + schemaLocation + ".");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 579 */       InputStream source = new ByteArrayInputStream(buffer.toByteArray());
/* 580 */       writeInputStreamToFile(source, filename);
/*     */     }
/* 582 */     catch (IOException e) {
/*     */       
/* 584 */       warning("Could not write to file " + filename + " for " + schemaLocation + ":" + e.getMessage());
/*     */       
/*     */       return;
/*     */     } 
/* 588 */     warning("Refreshed " + filename + " from " + schemaLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SchemaResource copyOrIdentifyDuplicateURL(String schemaLocation, String namespace) {
/*     */     String targetFilename, digest;
/*     */     try {
/* 599 */       targetFilename = uniqueFilenameForURI(schemaLocation);
/*     */     }
/* 601 */     catch (URISyntaxException e) {
/*     */       
/* 603 */       warning("Invalid URI '" + schemaLocation + "':" + e.getMessage());
/* 604 */       return null;
/*     */     }
/* 606 */     catch (IOException e) {
/*     */       
/* 608 */       warning("Could not create local file for " + schemaLocation + ":" + e.getMessage());
/* 609 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 614 */       URL url = new URL(schemaLocation);
/* 615 */       DigestInputStream input = digestInputStream(url.openStream());
/* 616 */       writeInputStreamToFile(input, targetFilename);
/* 617 */       digest = HexBin.bytesToString(input.getMessageDigest().digest());
/*     */     }
/* 619 */     catch (Exception e) {
/*     */       
/* 621 */       warning("Could not copy remote resource " + schemaLocation + ":" + e.getMessage());
/* 622 */       return null;
/*     */     } 
/*     */     
/* 625 */     SchemaResource result = (SchemaResource)this._resourceForDigest.get(digest);
/* 626 */     if (result != null) {
/*     */       
/* 628 */       deleteFile(targetFilename);
/* 629 */       result.addSchemaLocation(schemaLocation);
/* 630 */       if (!this._resourceForURL.containsKey(schemaLocation))
/* 631 */         this._resourceForURL.put(schemaLocation, result); 
/* 632 */       return result;
/*     */     } 
/*     */     
/* 635 */     warning("Downloaded " + schemaLocation + " to " + targetFilename);
/*     */     
/* 637 */     DownloadedSchemaEntry newEntry = addNewEntry();
/* 638 */     newEntry.setFilename(targetFilename);
/* 639 */     newEntry.setSha1(digest);
/* 640 */     if (namespace != null)
/* 641 */       newEntry.setNamespace(namespace); 
/* 642 */     newEntry.addSchemaLocation(schemaLocation);
/* 643 */     return updateResource(newEntry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportActualNamespace(SchemaImportResolver.SchemaResource rresource, String actualNamespace) {
/* 651 */     SchemaResource resource = (SchemaResource)rresource;
/* 652 */     String oldNamespace = resource.getNamespace();
/* 653 */     if (oldNamespace != null && this._resourceForNamespace.get(oldNamespace) == resource)
/* 654 */       this._resourceForNamespace.remove(oldNamespace); 
/* 655 */     if (!this._resourceForNamespace.containsKey(actualNamespace))
/* 656 */       this._resourceForNamespace.put(actualNamespace, resource); 
/* 657 */     resource.setNamespace(actualNamespace);
/*     */   }
/*     */ 
/*     */   
/*     */   private String shaDigestForFile(String filename) throws IOException {
/* 662 */     DigestInputStream str = digestInputStream(inputStreamForFile(filename));
/*     */     
/* 664 */     byte[] dummy = new byte[4096]; int i;
/* 665 */     for (i = 1; i > 0; i = str.read(dummy));
/*     */     
/* 667 */     str.close();
/*     */     
/* 669 */     return HexBin.bytesToString(str.getMessageDigest().digest());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIndexFilename() {
/* 676 */     return "./xsdownload.xml";
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getDefaultSchemaDir() {
/* 681 */     return "./schema";
/*     */   }
/*     */   
/*     */   protected abstract void warning(String paramString);
/*     */   
/*     */   protected abstract boolean fileExists(String paramString);
/*     */   
/*     */   protected abstract InputStream inputStreamForFile(String paramString) throws IOException;
/*     */   
/*     */   protected abstract void writeInputStreamToFile(InputStream paramInputStream, String paramString) throws IOException;
/*     */   
/*     */   protected abstract void deleteFile(String paramString);
/*     */   
/*     */   protected abstract String[] getAllXSDFilenames();
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\BaseSchemaResourceManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */