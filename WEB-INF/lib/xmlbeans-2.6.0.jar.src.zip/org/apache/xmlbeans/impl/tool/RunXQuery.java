/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunXQuery
/*     */ {
/*     */   public static void printUsage() {
/*  26 */     System.out.println("Run an XQuery against an XML instance");
/*  27 */     System.out.println("Usage:");
/*  28 */     System.out.println("xquery [-verbose] [-pretty] [-q <query> | -qf query.xq] [file.xml]*");
/*  29 */     System.out.println(" -q <query> to specify a query on the command-line");
/*  30 */     System.out.println(" -qf <query> to specify a file containing a query");
/*  31 */     System.out.println(" -pretty pretty-prints the results");
/*  32 */     System.out.println(" -license prints license information");
/*  33 */     System.out.println(" the query is run on each XML file specified");
/*  34 */     System.out.println("");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/*  39 */     Set flags = new HashSet();
/*  40 */     flags.add("h");
/*  41 */     flags.add("help");
/*  42 */     flags.add("usage");
/*  43 */     flags.add("license");
/*  44 */     flags.add("version");
/*  45 */     flags.add("verbose");
/*  46 */     flags.add("pretty");
/*     */     
/*  48 */     CommandLine cl = new CommandLine(args, flags, Arrays.asList(new String[] { "q", "qf" }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null) {
/*     */       
/*  55 */       printUsage();
/*  56 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  60 */     String[] badopts = cl.getBadOpts();
/*  61 */     if (badopts.length > 0) {
/*     */       
/*  63 */       for (int j = 0; j < badopts.length; j++)
/*  64 */         System.out.println("Unrecognized option: " + badopts[j]); 
/*  65 */       printUsage();
/*  66 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  70 */     if (cl.getOpt("license") != null) {
/*     */       
/*  72 */       CommandLine.printLicense();
/*  73 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  77 */     if (cl.getOpt("version") != null) {
/*     */       
/*  79 */       CommandLine.printVersion();
/*  80 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  84 */     args = cl.args();
/*     */     
/*  86 */     if (args.length == 0) {
/*     */       
/*  88 */       printUsage();
/*  89 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  93 */     boolean verbose = (cl.getOpt("verbose") != null);
/*  94 */     boolean pretty = (cl.getOpt("pretty") != null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     String query = cl.getOpt("q");
/* 101 */     String queryfile = cl.getOpt("qf");
/*     */     
/* 103 */     if (query == null && queryfile == null) {
/*     */       
/* 105 */       System.err.println("No query specified");
/* 106 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 110 */     if (query != null && queryfile != null) {
/*     */       
/* 112 */       System.err.println("Specify -qf or -q, not both.");
/* 113 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 119 */       if (queryfile != null)
/*     */       {
/* 121 */         File queryFile = new File(queryfile);
/* 122 */         FileInputStream is = new FileInputStream(queryFile);
/* 123 */         InputStreamReader r = new InputStreamReader(is);
/*     */         
/* 125 */         StringBuffer sb = new StringBuffer();
/*     */ 
/*     */         
/*     */         while (true) {
/* 129 */           int ch = r.read();
/*     */           
/* 131 */           if (ch < 0) {
/*     */             break;
/*     */           }
/* 134 */           sb.append((char)ch);
/*     */         } 
/*     */         
/* 137 */         r.close();
/* 138 */         is.close();
/*     */         
/* 140 */         query = sb.toString();
/*     */       }
/*     */     
/* 143 */     } catch (Throwable e) {
/*     */       
/* 145 */       System.err.println("Cannot read query file: " + e.getMessage());
/* 146 */       System.exit(1);
/*     */       
/*     */       return;
/*     */     } 
/* 150 */     if (verbose) {
/*     */       
/* 152 */       System.out.println("Compile Query:");
/* 153 */       System.out.println(query);
/* 154 */       System.out.println();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 159 */       query = XmlBeans.compileQuery(query);
/*     */     }
/* 161 */     catch (Exception e) {
/*     */       
/* 163 */       System.err.println("Error compiling query: " + e.getMessage());
/* 164 */       System.exit(1);
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 172 */     File[] files = cl.getFiles();
/*     */     
/* 174 */     for (int i = 0; i < files.length; i++) {
/*     */       XmlObject x;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 180 */         if (verbose) {
/*     */           
/* 182 */           InputStream is = new FileInputStream(files[i]);
/*     */ 
/*     */           
/*     */           while (true) {
/* 186 */             int ch = is.read();
/*     */             
/* 188 */             if (ch < 0) {
/*     */               break;
/*     */             }
/* 191 */             System.out.write(ch);
/*     */           } 
/*     */           
/* 194 */           is.close();
/*     */           
/* 196 */           System.out.println();
/*     */         } 
/*     */         
/* 199 */         x = XmlObject.Factory.parse(files[i]);
/*     */       }
/* 201 */       catch (Throwable e) {
/*     */         
/* 203 */         System.err.println("Error parsing instance: " + e.getMessage());
/* 204 */         System.exit(1);
/*     */         
/*     */         return;
/*     */       } 
/* 208 */       if (verbose) {
/*     */         
/* 210 */         System.out.println("Executing Query...");
/* 211 */         System.err.println();
/*     */       } 
/*     */       
/* 214 */       XmlObject[] result = null;
/*     */ 
/*     */       
/*     */       try {
/* 218 */         result = x.execQuery(query);
/*     */       }
/* 220 */       catch (Throwable e) {
/*     */         
/* 222 */         System.err.println("Error executing query: " + e.getMessage());
/* 223 */         System.exit(1);
/*     */         
/*     */         return;
/*     */       } 
/* 227 */       if (verbose)
/*     */       {
/* 229 */         System.out.println("Query Result:");
/*     */       }
/*     */       
/* 232 */       XmlOptions opts = new XmlOptions();
/* 233 */       opts.setSaveOuter();
/* 234 */       if (pretty) {
/* 235 */         opts.setSavePrettyPrint();
/*     */       }
/* 237 */       for (int j = 0; j < result.length; j++) {
/*     */         
/* 239 */         result[j].save(System.out, opts);
/* 240 */         System.out.println();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\RunXQuery.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */