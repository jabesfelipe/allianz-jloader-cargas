/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.xmlbeans.impl.common.IOUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaResourceManager
/*     */   extends BaseSchemaResourceManager
/*     */ {
/*     */   private File _directory;
/*     */   
/*     */   public static void printUsage() {
/*  37 */     System.out.println("Maintains \"xsdownload.xml\", an index of locally downloaded .xsd files");
/*  38 */     System.out.println("usage: sdownload [-dir directory] [-refresh] [-recurse] [-sync] [url/file...]");
/*  39 */     System.out.println("");
/*  40 */     System.out.println("URLs that are specified are downloaded if they aren't already cached.");
/*  41 */     System.out.println("In addition:");
/*  42 */     System.out.println("  -dir specifies the directory for the xsdownload.xml file (default .).");
/*  43 */     System.out.println("  -sync synchronizes the index to any local .xsd files in the tree.");
/*  44 */     System.out.println("  -recurse recursively downloads imported and included .xsd files.");
/*  45 */     System.out.println("  -refresh redownloads all indexed .xsd files.");
/*  46 */     System.out.println("If no files or URLs are specified, all indexed files are relevant.");
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/*     */     SchemaResourceManager mgr;
/*  51 */     if (args.length == 0) {
/*     */       
/*  53 */       printUsage();
/*  54 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  58 */     Set flags = new HashSet();
/*  59 */     flags.add("h");
/*  60 */     flags.add("help");
/*  61 */     flags.add("usage");
/*  62 */     flags.add("license");
/*  63 */     flags.add("version");
/*  64 */     flags.add("sync");
/*  65 */     flags.add("refresh");
/*  66 */     flags.add("recurse");
/*     */     
/*  68 */     Set opts = new HashSet();
/*  69 */     opts.add("dir");
/*  70 */     CommandLine cl = new CommandLine(args, flags, opts);
/*  71 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null) {
/*     */       
/*  73 */       printUsage();
/*  74 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  78 */     String[] badopts = cl.getBadOpts();
/*  79 */     if (badopts.length > 0) {
/*     */       
/*  81 */       for (int k = 0; k < badopts.length; k++)
/*  82 */         System.out.println("Unrecognized option: " + badopts[k]); 
/*  83 */       printUsage();
/*  84 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  88 */     if (cl.getOpt("license") != null) {
/*     */       
/*  90 */       CommandLine.printLicense();
/*  91 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/*  95 */     if (cl.getOpt("version") != null) {
/*     */       
/*  97 */       CommandLine.printVersion();
/*  98 */       System.exit(0);
/*     */       
/*     */       return;
/*     */     } 
/* 102 */     args = cl.args();
/*     */     
/* 104 */     boolean sync = (cl.getOpt("sync") != null);
/* 105 */     boolean refresh = (cl.getOpt("refresh") != null);
/* 106 */     boolean imports = (cl.getOpt("recurse") != null);
/* 107 */     String dir = cl.getOpt("dir");
/* 108 */     if (dir == null)
/* 109 */       dir = "."; 
/* 110 */     File directory = new File(dir);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 115 */       mgr = new SchemaResourceManager(directory);
/*     */     }
/* 117 */     catch (IllegalStateException e) {
/*     */       
/* 119 */       if (e.getMessage() != null) {
/* 120 */         System.out.println(e.getMessage());
/*     */       } else {
/* 122 */         e.printStackTrace();
/* 123 */       }  System.exit(1);
/*     */       
/*     */       return;
/*     */     } 
/* 127 */     List uriList = new ArrayList();
/* 128 */     List fileList = new ArrayList();
/* 129 */     for (int j = 0; j < args.length; j++) {
/*     */       
/* 131 */       if (looksLikeURL(args[j])) {
/*     */         
/* 133 */         uriList.add(args[j]);
/*     */       }
/*     */       else {
/*     */         
/* 137 */         fileList.add(new File(directory, args[j]));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 142 */     for (Iterator i = fileList.iterator(); i.hasNext(); ) {
/*     */       
/* 144 */       File file = i.next();
/* 145 */       if (!isInDirectory(file, directory)) {
/*     */         
/* 147 */         System.err.println("File not within directory: " + file);
/* 148 */         i.remove();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 153 */     fileList = collectXSDFiles(fileList.<File>toArray(new File[0]));
/*     */     
/* 155 */     String[] uris = uriList.<String>toArray(new String[0]);
/* 156 */     File[] files = fileList.<File>toArray(new File[0]);
/* 157 */     String[] filenames = relativeFilenames(files, directory);
/*     */     
/* 159 */     if (uris.length + filenames.length > 0) {
/*     */       
/* 161 */       mgr.process(uris, filenames, sync, refresh, imports);
/*     */     }
/*     */     else {
/*     */       
/* 165 */       mgr.processAll(sync, refresh, imports);
/*     */     } 
/*     */     
/* 168 */     mgr.writeCache();
/* 169 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean looksLikeURL(String str) {
/* 174 */     return (str.startsWith("http:") || str.startsWith("https:") || str.startsWith("ftp:") || str.startsWith("file:"));
/*     */   }
/*     */ 
/*     */   
/*     */   private static String relativeFilename(File file, File directory) {
/* 179 */     if (file == null || file.equals(directory))
/* 180 */       return "."; 
/* 181 */     return relativeFilename(file.getParentFile(), directory) + "/" + file.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String[] relativeFilenames(File[] files, File directory) {
/* 186 */     String[] result = new String[files.length];
/* 187 */     for (int i = 0; i < files.length; i++)
/*     */     {
/* 189 */       result[i] = relativeFilename(files[i], directory);
/*     */     }
/* 191 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isInDirectory(File file, File dir) {
/* 196 */     if (file == null)
/* 197 */       return false; 
/* 198 */     if (file.equals(dir))
/* 199 */       return true; 
/* 200 */     return isInDirectory(file.getParentFile(), dir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaResourceManager(File directory) {
/* 209 */     this._directory = directory;
/* 210 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void warning(String msg) {
/* 223 */     System.out.println(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean fileExists(String filename) {
/* 233 */     return (new File(this._directory, filename)).exists();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream inputStreamForFile(String filename) throws IOException {
/* 241 */     return new FileInputStream(new File(this._directory, filename));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInputStreamToFile(InputStream input, String filename) throws IOException {
/* 250 */     File targetFile = new File(this._directory, filename);
/*     */     
/* 252 */     File parent = targetFile.getParentFile();
/* 253 */     if (!parent.exists())
/* 254 */       parent.mkdirs(); 
/* 255 */     OutputStream output = new FileOutputStream(targetFile);
/* 256 */     IOUtil.copyCompletely(input, output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void deleteFile(String filename) {
/* 267 */     (new File(this._directory, filename)).delete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getAllXSDFilenames() {
/* 275 */     File[] allFiles = (File[])collectXSDFiles(new File[] { this._directory }).toArray((Object[])new File[0]);
/* 276 */     return relativeFilenames(allFiles, this._directory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List collectXSDFiles(File[] dirs) {
/* 284 */     List files = new ArrayList();
/* 285 */     for (int i = 0; i < dirs.length; i++) {
/*     */       
/* 287 */       File f = dirs[i];
/* 288 */       if (!f.isDirectory()) {
/*     */         
/* 290 */         files.add(f);
/*     */       }
/*     */       else {
/*     */         
/* 294 */         files.addAll(collectXSDFiles(f.listFiles(new FileFilter()
/*     */                 {
/*     */                   public boolean accept(File file)
/*     */                   {
/* 298 */                     return (file.isDirectory() || (file.isFile() && file.getName().endsWith(".xsd")));
/*     */                   }
/*     */                 })));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 305 */     return files;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\SchemaResourceManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */