/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileWriter;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.xmlbeans.SystemProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeGenUtil
/*     */ {
/*  35 */   public static String DEFAULT_MEM_START = "8m";
/*  36 */   public static String DEFAULT_MEM_MAX = "256m";
/*  37 */   public static String DEFAULT_COMPILER = "javac";
/*  38 */   public static String DEFAULT_JAR = "jar";
/*     */   
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public static URI resolve(URI base, URI child) {
/*  43 */     URI ruri = base.resolve(child);
/*     */ 
/*     */     
/*  46 */     if ("file".equals(ruri.getScheme()) && !child.equals(ruri))
/*     */     {
/*  48 */       if (base.getPath().startsWith("//") && !ruri.getPath().startsWith("//")) {
/*     */         
/*  50 */         String path = "///".concat(ruri.getPath());
/*     */         
/*     */         try {
/*  53 */           ruri = new URI("file", null, path, ruri.getQuery(), ruri.getFragment());
/*     */         }
/*  55 */         catch (URISyntaxException uris) {}
/*     */       } 
/*     */     }
/*     */     
/*  59 */     return ruri;
/*     */   }
/*     */ 
/*     */   
/*     */   static void addAllJavaFiles(List srcFiles, List args) {
/*  64 */     for (Iterator i = srcFiles.iterator(); i.hasNext(); ) {
/*     */       
/*  66 */       File f = i.next();
/*  67 */       if (!f.isDirectory()) {
/*     */         
/*  69 */         args.add(quoteAndEscapeFilename(f.getAbsolutePath()));
/*     */         
/*     */         continue;
/*     */       } 
/*  73 */       List inside = Arrays.asList(f.listFiles(new FileFilter()
/*     */             {
/*     */               public boolean accept(File file)
/*     */               {
/*  77 */                 return ((file.isFile() && file.getName().endsWith(".java")) || file.isDirectory());
/*     */               }
/*     */             }));
/*  80 */       addAllJavaFiles(inside, args);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String quoteAndEscapeFilename(String filename) {
/*  88 */     if (filename.indexOf(" ") < 0) {
/*  89 */       return filename;
/*     */     }
/*     */ 
/*     */     
/*  93 */     return "\"" + filename.replaceAll("\\\\", "\\\\\\\\") + "\"";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String quoteNoEscapeFilename(String filename) {
/*  99 */     if (filename.indexOf(" ") < 0 || File.separatorChar == '/') {
/* 100 */       return filename;
/*     */     }
/* 102 */     return "\"" + filename + "\"";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean externalCompile(List srcFiles, File outdir, File[] cp, boolean debug) {
/* 115 */     return externalCompile(srcFiles, outdir, cp, debug, DEFAULT_COMPILER, null, DEFAULT_MEM_START, DEFAULT_MEM_MAX, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean externalCompile(List srcFiles, File outdir, File[] cp, boolean debug, String javacPath, String memStart, String memMax, boolean quiet, boolean verbose) {
/* 121 */     return externalCompile(srcFiles, outdir, cp, debug, javacPath, null, memStart, memMax, quiet, verbose);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean externalCompile(List srcFiles, File outdir, File[] cp, boolean debug, String javacPath, String genver, String memStart, String memMax, boolean quiet, boolean verbose) {
/* 132 */     List args = new ArrayList();
/*     */     
/* 134 */     File javac = findJavaTool((javacPath == null) ? DEFAULT_COMPILER : javacPath);
/* 135 */     assert javac.exists() : "compiler not found " + javac;
/* 136 */     args.add(javac.getAbsolutePath());
/*     */     
/* 138 */     if (outdir == null) {
/*     */       
/* 140 */       outdir = new File(".");
/*     */     }
/*     */     else {
/*     */       
/* 144 */       args.add("-d");
/* 145 */       args.add(quoteAndEscapeFilename(outdir.getAbsolutePath()));
/*     */     } 
/*     */     
/* 148 */     if (cp == null)
/*     */     {
/* 150 */       cp = systemClasspath();
/*     */     }
/*     */     
/* 153 */     if (cp.length > 0) {
/*     */       
/* 155 */       StringBuffer classPath = new StringBuffer();
/*     */ 
/*     */ 
/*     */       
/* 159 */       classPath.append(outdir.getAbsolutePath());
/*     */ 
/*     */       
/* 162 */       for (int i = 0; i < cp.length; i++) {
/*     */         
/* 164 */         classPath.append(File.pathSeparator);
/* 165 */         classPath.append(cp[i].getAbsolutePath());
/*     */       } 
/*     */       
/* 168 */       args.add("-classpath");
/*     */ 
/*     */       
/* 171 */       args.add(quoteAndEscapeFilename(classPath.toString()));
/*     */     } 
/*     */     
/* 174 */     if (genver == null) {
/* 175 */       genver = "1.4";
/*     */     }
/* 177 */     args.add("-source");
/* 178 */     args.add(genver);
/*     */     
/* 180 */     args.add("-target");
/* 181 */     args.add(genver);
/*     */     
/* 183 */     args.add(debug ? "-g" : "-g:none");
/*     */     
/* 185 */     if (verbose) {
/* 186 */       args.add("-verbose");
/*     */     }
/* 188 */     addAllJavaFiles(srcFiles, args);
/*     */     
/* 190 */     File clFile = null;
/*     */     
/*     */     try {
/* 193 */       clFile = File.createTempFile("javac", "");
/* 194 */       FileWriter fw = new FileWriter(clFile);
/* 195 */       Iterator i = args.iterator();
/* 196 */       i.next(); while (i.hasNext()) {
/*     */         
/* 198 */         String arg = i.next();
/* 199 */         fw.write(arg);
/* 200 */         fw.write(10);
/*     */       } 
/* 202 */       fw.close();
/* 203 */       List newargs = new ArrayList();
/* 204 */       newargs.add(args.get(0));
/*     */       
/* 206 */       if (memStart != null && memStart.length() != 0)
/* 207 */         newargs.add("-J-Xms" + memStart); 
/* 208 */       if (memMax != null && memMax.length() != 0) {
/* 209 */         newargs.add("-J-Xmx" + memMax);
/*     */       }
/* 211 */       newargs.add("@" + clFile.getAbsolutePath());
/* 212 */       args = newargs;
/*     */     }
/* 214 */     catch (Exception e) {
/*     */       
/* 216 */       System.err.println("Could not create command-line file for javac");
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 221 */       String[] strArgs = args.<String>toArray(new String[args.size()]);
/*     */       
/* 223 */       if (verbose) {
/*     */         
/* 225 */         System.out.print("compile command:");
/* 226 */         for (int i = 0; i < strArgs.length; i++)
/* 227 */           System.out.print(" " + strArgs[i]); 
/* 228 */         System.out.println();
/*     */       } 
/*     */       
/* 231 */       Process proc = Runtime.getRuntime().exec(strArgs);
/*     */       
/* 233 */       StringBuffer errorBuffer = new StringBuffer();
/* 234 */       StringBuffer outputBuffer = new StringBuffer();
/*     */       
/* 236 */       ThreadedReader out = new ThreadedReader(proc.getInputStream(), outputBuffer);
/* 237 */       ThreadedReader err = new ThreadedReader(proc.getErrorStream(), errorBuffer);
/*     */       
/* 239 */       proc.waitFor();
/*     */       
/* 241 */       if (verbose || proc.exitValue() != 0) {
/*     */         
/* 243 */         if (outputBuffer.length() > 0) {
/* 244 */           System.out.println(outputBuffer.toString());
/* 245 */           System.out.flush();
/*     */         } 
/* 247 */         if (errorBuffer.length() > 0) {
/* 248 */           System.err.println(errorBuffer.toString());
/* 249 */           System.err.flush();
/*     */         } 
/*     */         
/* 252 */         if (proc.exitValue() != 0) {
/* 253 */           return false;
/*     */         }
/*     */       } 
/* 256 */     } catch (Throwable e) {
/*     */       
/* 258 */       System.err.println(e.toString());
/* 259 */       System.err.println(e.getCause());
/* 260 */       e.printStackTrace(System.err);
/* 261 */       return false;
/*     */     } 
/*     */     
/* 264 */     if (clFile != null) {
/* 265 */       clFile.delete();
/*     */     }
/* 267 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File[] systemClasspath() {
/* 272 */     List cp = new ArrayList();
/* 273 */     String[] systemcp = SystemProperties.getProperty("java.class.path").split(File.pathSeparator);
/* 274 */     for (int i = 0; i < systemcp.length; i++)
/*     */     {
/* 276 */       cp.add(new File(systemcp[i]));
/*     */     }
/* 278 */     return cp.<File>toArray(new File[cp.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean externalJar(File srcdir, File outfile) {
/* 286 */     return externalJar(srcdir, outfile, DEFAULT_JAR, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean externalJar(File srcdir, File outfile, String jarPath, boolean quiet, boolean verbose) {
/* 294 */     List args = new ArrayList();
/*     */     
/* 296 */     File jar = findJavaTool((jarPath == null) ? DEFAULT_JAR : jarPath);
/* 297 */     assert jar.exists() : "jar not found " + jar;
/* 298 */     args.add(jar.getAbsolutePath());
/*     */     
/* 300 */     args.add("cf");
/* 301 */     args.add(quoteNoEscapeFilename(outfile.getAbsolutePath()));
/*     */     
/* 303 */     args.add("-C");
/* 304 */     args.add(quoteNoEscapeFilename(srcdir.getAbsolutePath()));
/*     */     
/* 306 */     args.add(".");
/*     */ 
/*     */     
/*     */     try {
/* 310 */       String[] strArgs = args.<String>toArray(new String[args.size()]);
/*     */       
/* 312 */       if (verbose) {
/*     */         
/* 314 */         System.out.print("jar command:");
/* 315 */         for (int i = 0; i < strArgs.length; i++)
/* 316 */           System.out.print(" " + strArgs[i]); 
/* 317 */         System.out.println();
/*     */       } 
/*     */       
/* 320 */       Process proc = Runtime.getRuntime().exec(strArgs);
/*     */       
/* 322 */       StringBuffer errorBuffer = new StringBuffer();
/* 323 */       StringBuffer outputBuffer = new StringBuffer();
/*     */       
/* 325 */       ThreadedReader out = new ThreadedReader(proc.getInputStream(), outputBuffer);
/* 326 */       ThreadedReader err = new ThreadedReader(proc.getErrorStream(), errorBuffer);
/*     */       
/* 328 */       proc.waitFor();
/*     */       
/* 330 */       if (verbose || proc.exitValue() != 0) {
/*     */         
/* 332 */         if (outputBuffer.length() > 0) {
/* 333 */           System.out.println(outputBuffer.toString());
/* 334 */           System.out.flush();
/*     */         } 
/* 336 */         if (errorBuffer.length() > 0) {
/* 337 */           System.err.println(errorBuffer.toString());
/* 338 */           System.err.flush();
/*     */         } 
/*     */         
/* 341 */         if (proc.exitValue() != 0) {
/* 342 */           return false;
/*     */         }
/*     */       } 
/* 345 */     } catch (Throwable e) {
/*     */       
/* 347 */       e.printStackTrace(System.err);
/* 348 */       return false;
/*     */     } 
/* 350 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static File findJavaTool(String tool) {
/* 359 */     File toolFile = new File(tool);
/* 360 */     if (toolFile.isFile()) {
/* 361 */       return toolFile;
/*     */     }
/*     */     
/* 364 */     File result = new File(tool + ".exe");
/* 365 */     if (result.isFile()) {
/* 366 */       return result;
/*     */     }
/*     */     
/* 369 */     String home = SystemProperties.getProperty("java.home");
/*     */     
/* 371 */     String sep = File.separator;
/* 372 */     result = new File(home + sep + ".." + sep + "bin", tool);
/*     */     
/* 374 */     if (result.isFile()) {
/* 375 */       return result;
/*     */     }
/*     */     
/* 378 */     result = new File(result.getPath() + ".exe");
/* 379 */     if (result.isFile()) {
/* 380 */       return result;
/*     */     }
/*     */     
/* 383 */     result = new File(home + sep + "bin", tool);
/* 384 */     if (result.isFile()) {
/* 385 */       return result;
/*     */     }
/*     */     
/* 388 */     result = new File(result.getPath() + ".exe");
/* 389 */     if (result.isFile()) {
/* 390 */       return result;
/*     */     }
/*     */ 
/*     */     
/* 394 */     return toolFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ThreadedReader
/*     */   {
/*     */     public ThreadedReader(InputStream stream, final StringBuffer output) {
/* 405 */       final BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
/*     */ 
/*     */       
/* 408 */       Thread readerThread = new Thread(new Runnable() {
/*     */             private final BufferedReader val$reader;
/*     */             
/*     */             public void run() {
/*     */               try {
/*     */                 String s;
/* 414 */                 while ((s = reader.readLine()) != null) {
/* 415 */                   output.append(s + "\n");
/*     */                 }
/* 417 */               } catch (Exception e) {}
/*     */             }
/*     */             private final StringBuffer val$output; private final CodeGenUtil.ThreadedReader this$0;
/*     */           });
/* 421 */       readerThread.start();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\CodeGenUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */