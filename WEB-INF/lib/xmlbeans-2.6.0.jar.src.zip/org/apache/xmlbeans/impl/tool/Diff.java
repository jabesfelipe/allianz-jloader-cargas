/*     */ package org.apache.xmlbeans.impl.tool;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.apache.xmlbeans.SystemProperties;
/*     */ import org.apache.xmlbeans.impl.schema.SchemaTypeSystemImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Diff
/*     */ {
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public static void main(String[] args) {
/*  34 */     if (args.length != 2) {
/*     */       
/*  36 */       System.out.println("Usage: diff <jarname1> <jarname2> to compare two jars");
/*  37 */       System.out.println("  or   diff <dirname1> <dirname2> to compare two dirs");
/*     */       return;
/*     */     } 
/*  40 */     File file1 = new File(args[0]);
/*  41 */     if (!file1.exists()) {
/*     */       
/*  43 */       System.out.println("File \"" + args[0] + "\" not found.");
/*     */       return;
/*     */     } 
/*  46 */     File file2 = new File(args[1]);
/*  47 */     if (!file2.exists()) {
/*     */       
/*  49 */       System.out.println("File \"" + args[1] + "\" not found.");
/*     */       return;
/*     */     } 
/*  52 */     List result = new ArrayList();
/*  53 */     if (file1.isDirectory()) {
/*     */       
/*  55 */       if (!file2.isDirectory()) {
/*     */         
/*  57 */         System.out.println("Both parameters have to be directories if the first parameter is a directory.");
/*     */         return;
/*     */       } 
/*  60 */       dirsAsTypeSystems(file1, file2, result);
/*     */     }
/*     */     else {
/*     */       
/*  64 */       if (file2.isDirectory()) {
/*     */         
/*  66 */         System.out.println("Both parameters have to be jar files if the first parameter is a jar file.");
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/*  71 */         JarFile jar1 = new JarFile(file1);
/*  72 */         JarFile jar2 = new JarFile(file2);
/*  73 */         jarsAsTypeSystems(jar1, jar2, result);
/*     */       }
/*  75 */       catch (IOException ioe) {
/*  76 */         ioe.printStackTrace();
/*     */       } 
/*  78 */     }  if (result.size() < 1) {
/*  79 */       System.out.println("No differences encountered.");
/*     */     } else {
/*     */       
/*  82 */       System.out.println("Differences:");
/*  83 */       for (int i = 0; i < result.size(); i++) {
/*  84 */         System.out.println(result.get(i).toString());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void jarsAsTypeSystems(JarFile jar1, JarFile jar2, List diffs) {
/*  94 */     Enumeration entries1 = jar1.entries();
/*  95 */     Enumeration entries2 = jar2.entries();
/*  96 */     List list1 = new ArrayList();
/*  97 */     List list2 = new ArrayList();
/*  98 */     while (entries1.hasMoreElements()) {
/*     */       
/* 100 */       ZipEntry ze = entries1.nextElement();
/* 101 */       String name = ze.getName();
/* 102 */       if (name.startsWith("schema" + SchemaTypeSystemImpl.METADATA_PACKAGE_GEN + "/system/s") && name.endsWith(".xsb"))
/* 103 */         list1.add(ze); 
/*     */     } 
/* 105 */     while (entries2.hasMoreElements()) {
/*     */       
/* 107 */       ZipEntry ze = entries2.nextElement();
/* 108 */       String name = ze.getName();
/* 109 */       if (name.startsWith("schema" + SchemaTypeSystemImpl.METADATA_PACKAGE_GEN + "/system/s") && name.endsWith(".xsb"))
/* 110 */         list2.add(ze); 
/*     */     } 
/* 112 */     ZipEntry[] files1 = list1.<ZipEntry>toArray(new ZipEntry[list1.size()]);
/* 113 */     ZipEntry[] files2 = list2.<ZipEntry>toArray(new ZipEntry[list2.size()]);
/* 114 */     ZipEntryNameComparator comparator = new ZipEntryNameComparator();
/* 115 */     Arrays.sort(files1, comparator);
/* 116 */     Arrays.sort(files2, comparator);
/* 117 */     int i1 = 0;
/* 118 */     int i2 = 0;
/* 119 */     while (i1 < files1.length && i2 < files2.length) {
/*     */       
/* 121 */       String name1 = files1[i1].getName();
/* 122 */       String name2 = files2[i2].getName();
/* 123 */       int dif = name1.compareTo(name2);
/* 124 */       if (dif == 0) {
/*     */ 
/*     */         
/* 127 */         zipEntriesAsXsb(files1[i1], jar1, files2[i2], jar2, diffs);
/* 128 */         i1++; i2++; continue;
/*     */       } 
/* 130 */       if (dif < 0) {
/*     */ 
/*     */         
/* 133 */         diffs.add("Jar \"" + jar1.getName() + "\" contains an extra file: \"" + name1 + "\"");
/*     */         
/* 135 */         i1++; continue;
/*     */       } 
/* 137 */       if (dif > 0) {
/*     */ 
/*     */         
/* 140 */         diffs.add("Jar \"" + jar2.getName() + "\" contains an extra file: \"" + name2 + "\"");
/*     */         
/* 142 */         i2++;
/*     */       } 
/*     */     } 
/* 145 */     while (i1 < files1.length) {
/*     */       
/* 147 */       diffs.add("Jar \"" + jar1.getName() + "\" contains an extra file: \"" + files1[i1].getName() + "\"");
/*     */       
/* 149 */       i1++;
/*     */     } 
/* 151 */     while (i2 < files2.length) {
/*     */       
/* 153 */       diffs.add("Jar \"" + jar2.getName() + "\" contains an extra file: \"" + files2[i2].getName() + "\"");
/*     */       
/* 155 */       i2++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dirsAsTypeSystems(File dir1, File dir2, List diffs) {
/* 167 */     assert dir1.isDirectory() : "Parameters must be directories";
/* 168 */     assert dir2.isDirectory() : "Parameters must be directories";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     File temp1 = new File(dir1, "schema" + SchemaTypeSystemImpl.METADATA_PACKAGE_GEN + "/system");
/* 175 */     File temp2 = new File(dir2, "schema" + SchemaTypeSystemImpl.METADATA_PACKAGE_GEN + "/system");
/* 176 */     if (temp1.exists() && temp2.exists()) {
/*     */       
/* 178 */       File[] arrayOfFile1 = temp1.listFiles();
/* 179 */       File[] arrayOfFile2 = temp2.listFiles();
/* 180 */       if (arrayOfFile1.length == 1 && arrayOfFile2.length == 1) {
/*     */         
/* 182 */         temp1 = arrayOfFile1[0];
/* 183 */         temp2 = arrayOfFile2[0];
/*     */       }
/*     */       else {
/*     */         
/* 187 */         if (arrayOfFile1.length == 0)
/* 188 */           temp1 = null; 
/* 189 */         if (arrayOfFile2.length == 0)
/* 190 */           temp2 = null; 
/* 191 */         if (arrayOfFile1.length > 1) {
/*     */           
/* 193 */           diffs.add("More than one typesystem found in dir \"" + dir1.getName() + "\"");
/*     */           
/*     */           return;
/*     */         } 
/* 197 */         if (arrayOfFile2.length > 1) {
/*     */           
/* 199 */           diffs.add("More than one typesystem found in dir \"" + dir2.getName() + "\"");
/*     */ 
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 207 */       if (!temp1.exists())
/* 208 */         temp1 = null; 
/* 209 */       if (!temp2.exists())
/* 210 */         temp2 = null; 
/*     */     } 
/* 212 */     if (temp1 == null && temp2 == null)
/*     */       return; 
/* 214 */     if (temp1 == null || temp2 == null) {
/*     */       
/* 216 */       if (temp1 == null)
/* 217 */         diffs.add("No typesystems found in dir \"" + dir1 + "\""); 
/* 218 */       if (temp2 == null) {
/* 219 */         diffs.add("No typesystems found in dir \"" + dir2 + "\"");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 224 */     dir1 = temp1;
/* 225 */     dir2 = temp2;
/*     */ 
/*     */     
/* 228 */     boolean diffIndex = isDiffIndex();
/* 229 */     XsbFilenameFilter xsbName = new XsbFilenameFilter();
/* 230 */     File[] files1 = dir1.listFiles(xsbName);
/* 231 */     File[] files2 = dir2.listFiles(xsbName);
/* 232 */     FileNameComparator comparator = new FileNameComparator();
/* 233 */     Arrays.sort(files1, comparator);
/* 234 */     Arrays.sort(files2, comparator);
/* 235 */     int i1 = 0;
/* 236 */     int i2 = 0;
/* 237 */     while (i1 < files1.length && i2 < files2.length) {
/*     */       
/* 239 */       String name1 = files1[i1].getName();
/* 240 */       String name2 = files2[i2].getName();
/* 241 */       int dif = name1.compareTo(name2);
/* 242 */       if (dif == 0) {
/*     */         
/* 244 */         if (diffIndex || !files1[i1].getName().equals("index.xsb"))
/* 245 */           filesAsXsb(files1[i1], files2[i2], diffs); 
/* 246 */         i1++; i2++; continue;
/*     */       } 
/* 248 */       if (dif < 0) {
/*     */ 
/*     */         
/* 251 */         diffs.add("Dir \"" + dir1.getName() + "\" contains an extra file: \"" + name1 + "\"");
/*     */         
/* 253 */         i1++; continue;
/*     */       } 
/* 255 */       if (dif > 0) {
/*     */ 
/*     */         
/* 258 */         diffs.add("Dir \"" + dir2.getName() + "\" contains an extra file: \"" + name2 + "\"");
/*     */         
/* 260 */         i2++;
/*     */       } 
/*     */     } 
/* 263 */     while (i1 < files1.length) {
/*     */       
/* 265 */       diffs.add("Dir \"" + dir1.getName() + "\" contains an extra file: \"" + files1[i1].getName() + "\"");
/*     */       
/* 267 */       i1++;
/*     */     } 
/* 269 */     while (i2 < files2.length) {
/*     */       
/* 271 */       diffs.add("Dir \"" + dir2.getName() + "\" contains an extra file: \"" + files2[i2].getName() + "\"");
/*     */       
/* 273 */       i2++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isDiffIndex() {
/* 279 */     String prop = SystemProperties.getProperty("xmlbeans.diff.diffIndex");
/* 280 */     if (prop == null)
/* 281 */       return true; 
/* 282 */     if ("0".equals(prop) || "false".equalsIgnoreCase(prop))
/* 283 */       return false; 
/* 284 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void filesAsXsb(File file1, File file2, List diffs) {
/* 293 */     assert file1.exists() : "File \"" + file1.getAbsolutePath() + "\" does not exist.";
/* 294 */     assert file2.exists() : "File \"" + file2.getAbsolutePath() + "\" does not exist.";
/*     */     
/*     */     try {
/* 297 */       FileInputStream stream1 = new FileInputStream(file1);
/* 298 */       FileInputStream stream2 = new FileInputStream(file2);
/* 299 */       streamsAsXsb(stream1, file1.getName(), stream2, file2.getName(), diffs);
/*     */     }
/* 301 */     catch (FileNotFoundException fnfe) {
/*     */     
/* 303 */     } catch (IOException ioe) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void zipEntriesAsXsb(ZipEntry file1, JarFile jar1, ZipEntry file2, JarFile jar2, List diffs) {
/*     */     try {
/* 312 */       InputStream stream1 = jar1.getInputStream(file1);
/* 313 */       InputStream stream2 = jar2.getInputStream(file2);
/* 314 */       streamsAsXsb(stream1, file1.getName(), stream2, file2.getName(), diffs);
/*     */     }
/* 316 */     catch (IOException ioe) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void streamsAsXsb(InputStream stream1, String name1, InputStream stream2, String name2, List diffs) throws IOException {
/* 324 */     ByteArrayOutputStream buf1 = new ByteArrayOutputStream();
/* 325 */     ByteArrayOutputStream buf2 = new ByteArrayOutputStream();
/* 326 */     XsbDumper.dump(stream1, "", new PrintStream(buf1));
/* 327 */     XsbDumper.dump(stream2, "", new PrintStream(buf2));
/* 328 */     stream1.close();
/* 329 */     stream2.close();
/* 330 */     readersAsText(new StringReader(buf1.toString()), name1, new StringReader(buf2.toString()), name2, diffs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void readersAsText(Reader r1, String name1, Reader r2, String name2, List diffs) throws IOException {
/* 338 */     org.apache.xmlbeans.impl.util.Diff.readersAsText(r1, name1, r2, name2, diffs);
/*     */   }
/*     */   
/*     */   private static class XsbFilenameFilter implements FilenameFilter {
/*     */     private XsbFilenameFilter() {}
/*     */     
/*     */     public boolean accept(File dir, String name) {
/* 345 */       return name.endsWith(".xsb");
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ZipEntryNameComparator implements Comparator {
/*     */     static final boolean $assertionsDisabled;
/*     */     
/*     */     public boolean equals(Object object) {
/* 353 */       return (this == object);
/*     */     }
/*     */     private ZipEntryNameComparator() {}
/*     */     
/*     */     public int compare(Object object1, Object object2) {
/* 358 */       assert object1 instanceof ZipEntry : "Must pass in a java.util.zip.ZipEntry as argument";
/* 359 */       assert object2 instanceof ZipEntry : "Must pass in a java.util.zip.ZipEntry as argument";
/*     */       
/* 361 */       String name1 = ((ZipEntry)object1).getName();
/* 362 */       String name2 = ((ZipEntry)object2).getName();
/* 363 */       return name1.compareTo(name2);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FileNameComparator implements Comparator {
/*     */     static final boolean $assertionsDisabled;
/*     */     
/*     */     public boolean equals(Object object) {
/* 371 */       return (this == object);
/*     */     }
/*     */     private FileNameComparator() {}
/*     */     
/*     */     public int compare(Object object1, Object object2) {
/* 376 */       assert object1 instanceof File : "Must pass in a java.io.File as argument";
/* 377 */       assert object2 instanceof File : "Must pass in a java.io.File as argument";
/*     */       
/* 379 */       String name1 = ((File)object1).getName();
/* 380 */       String name2 = ((File)object2).getName();
/* 381 */       return name1.compareTo(name2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\Diff.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */