/*      */ package org.apache.xmlbeans.impl.tool;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import org.apache.xmlbeans.Filer;
/*      */ import org.apache.xmlbeans.ResourceLoader;
/*      */ import org.apache.xmlbeans.SchemaCodePrinter;
/*      */ import org.apache.xmlbeans.SchemaTypeLoader;
/*      */ import org.apache.xmlbeans.SchemaTypeSystem;
/*      */ import org.apache.xmlbeans.SimpleValue;
/*      */ import org.apache.xmlbeans.SystemProperties;
/*      */ import org.apache.xmlbeans.XmlBeans;
/*      */ import org.apache.xmlbeans.XmlException;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.impl.common.IOUtil;
/*      */ import org.apache.xmlbeans.impl.common.JarHelper;
/*      */ import org.apache.xmlbeans.impl.common.ResolverUtil;
/*      */ import org.apache.xmlbeans.impl.common.XmlErrorPrinter;
/*      */ import org.apache.xmlbeans.impl.common.XmlErrorWatcher;
/*      */ import org.apache.xmlbeans.impl.config.BindingConfigImpl;
/*      */ import org.apache.xmlbeans.impl.schema.PathResourceLoader;
/*      */ import org.apache.xmlbeans.impl.schema.SchemaTypeLoaderImpl;
/*      */ import org.apache.xmlbeans.impl.schema.SchemaTypeSystemCompiler;
/*      */ import org.apache.xmlbeans.impl.schema.SchemaTypeSystemImpl;
/*      */ import org.apache.xmlbeans.impl.schema.StscState;
/*      */ import org.apache.xmlbeans.impl.util.FilerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlListImpl;
/*      */ import org.apache.xmlbeans.impl.xb.substwsdl.DefinitionsDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import repackage.Repackager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SchemaCompiler
/*      */ {
/*      */   private static final String CONFIG_URI = "http://xml.apache.org/xmlbeans/2004/02/xbean/config";
/*      */   private static final String COMPATIBILITY_CONFIG_URI = "http://www.bea.com/2002/09/xbean/config";
/*      */   
/*      */   public static void printUsage() {
/*   68 */     System.out.println("Compiles a schema into XML Bean classes and metadata.");
/*   69 */     System.out.println("Usage: scomp [opts] [dirs]* [schema.xsd]* [service.wsdl]* [config.xsdconfig]*");
/*   70 */     System.out.println("Options include:");
/*   71 */     System.out.println("    -cp [a;b;c] - classpath");
/*   72 */     System.out.println("    -d [dir] - target binary directory for .class and .xsb files");
/*   73 */     System.out.println("    -src [dir] - target directory for generated .java files");
/*   74 */     System.out.println("    -srconly - do not compile .java files or jar the output.");
/*   75 */     System.out.println("    -out [xmltypes.jar] - the name of the output jar");
/*   76 */     System.out.println("    -dl - permit network downloads for imports and includes (default is off)");
/*   77 */     System.out.println("    -noupa - do not enforce the unique particle attribution rule");
/*   78 */     System.out.println("    -nopvr - do not enforce the particle valid (restriction) rule");
/*   79 */     System.out.println("    -noann - ignore annotations");
/*   80 */     System.out.println("    -novdoc - do not validate contents of <documentation>");
/*   81 */     System.out.println("    -noext - ignore all extension (Pre/Post and Interface) found in .xsdconfig files");
/*   82 */     System.out.println("    -compiler - path to external java compiler");
/*   83 */     System.out.println("    -javasource [version] - generate java source compatible for a Java version (1.4 or 1.5)");
/*   84 */     System.out.println("    -ms - initial memory for external java compiler (default '" + CodeGenUtil.DEFAULT_MEM_START + "')");
/*   85 */     System.out.println("    -mx - maximum memory for external java compiler (default '" + CodeGenUtil.DEFAULT_MEM_MAX + "')");
/*   86 */     System.out.println("    -debug - compile with debug symbols");
/*   87 */     System.out.println("    -quiet - print fewer informational messages");
/*   88 */     System.out.println("    -verbose - print more informational messages");
/*   89 */     System.out.println("    -version - prints version information");
/*   90 */     System.out.println("    -license - prints license information");
/*   91 */     System.out.println("    -allowmdef \"[ns] [ns] [ns]\" - ignores multiple defs in given namespaces (use ##local for no-namespace)");
/*   92 */     System.out.println("    -catalog [file] -  catalog file for org.apache.xml.resolver.tools.CatalogResolver. (Note: needs resolver.jar from http://xml.apache.org/commons/components/resolver/index.html)");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   99 */     System.out.println();
/*      */   }
/*      */ 
/*      */   
/*      */   public static void main(String[] args) {
/*  104 */     if (args.length == 0) {
/*      */       
/*  106 */       printUsage();
/*  107 */       System.exit(0);
/*      */       
/*      */       return;
/*      */     } 
/*  111 */     Set flags = new HashSet();
/*  112 */     flags.add("h");
/*  113 */     flags.add("help");
/*  114 */     flags.add("usage");
/*  115 */     flags.add("license");
/*  116 */     flags.add("quiet");
/*  117 */     flags.add("verbose");
/*  118 */     flags.add("version");
/*  119 */     flags.add("dl");
/*  120 */     flags.add("noupa");
/*  121 */     flags.add("nopvr");
/*  122 */     flags.add("noann");
/*  123 */     flags.add("novdoc");
/*  124 */     flags.add("noext");
/*  125 */     flags.add("srconly");
/*  126 */     flags.add("debug");
/*      */     
/*  128 */     Set opts = new HashSet();
/*  129 */     opts.add("out");
/*  130 */     opts.add("name");
/*  131 */     opts.add("src");
/*  132 */     opts.add("d");
/*  133 */     opts.add("cp");
/*  134 */     opts.add("compiler");
/*  135 */     opts.add("javasource");
/*  136 */     opts.add("jar");
/*  137 */     opts.add("ms");
/*  138 */     opts.add("mx");
/*  139 */     opts.add("repackage");
/*  140 */     opts.add("schemaCodePrinter");
/*  141 */     opts.add("extension");
/*  142 */     opts.add("extensionParms");
/*  143 */     opts.add("allowmdef");
/*  144 */     opts.add("catalog");
/*  145 */     CommandLine cl = new CommandLine(args, flags, opts);
/*      */     
/*  147 */     if (cl.getOpt("h") != null || cl.getOpt("help") != null || cl.getOpt("usage") != null) {
/*      */       
/*  149 */       printUsage();
/*  150 */       System.exit(0);
/*      */       
/*      */       return;
/*      */     } 
/*  154 */     String[] badopts = cl.getBadOpts();
/*  155 */     if (badopts.length > 0) {
/*      */       
/*  157 */       for (int i = 0; i < badopts.length; i++)
/*  158 */         System.out.println("Unrecognized option: " + badopts[i]); 
/*  159 */       printUsage();
/*  160 */       System.exit(0);
/*      */       
/*      */       return;
/*      */     } 
/*  164 */     if (cl.getOpt("license") != null) {
/*      */       
/*  166 */       CommandLine.printLicense();
/*  167 */       System.exit(0);
/*      */       
/*      */       return;
/*      */     } 
/*  171 */     if (cl.getOpt("version") != null) {
/*      */       
/*  173 */       CommandLine.printVersion();
/*  174 */       System.exit(0);
/*      */       
/*      */       return;
/*      */     } 
/*  178 */     args = cl.args();
/*  179 */     boolean verbose = (cl.getOpt("verbose") != null);
/*  180 */     boolean quiet = (cl.getOpt("quiet") != null);
/*  181 */     if (verbose) {
/*  182 */       quiet = false;
/*      */     }
/*  184 */     if (verbose) {
/*  185 */       CommandLine.printVersion();
/*      */     }
/*  187 */     String outputfilename = cl.getOpt("out");
/*      */     
/*  189 */     String repackage = cl.getOpt("repackage");
/*      */     
/*  191 */     String codePrinterClass = cl.getOpt("schemaCodePrinter");
/*  192 */     SchemaCodePrinter codePrinter = null;
/*  193 */     if (codePrinterClass != null) {
/*      */       
/*      */       try {
/*      */         
/*  197 */         codePrinter = (SchemaCodePrinter)Class.forName(codePrinterClass).newInstance();
/*      */       
/*      */       }
/*  200 */       catch (Exception e) {
/*      */         
/*  202 */         System.err.println("Failed to load SchemaCodePrinter class " + codePrinterClass + "; proceeding with default printer");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  208 */     String name = cl.getOpt("name");
/*      */     
/*  210 */     boolean download = (cl.getOpt("dl") != null);
/*  211 */     boolean noUpa = (cl.getOpt("noupa") != null);
/*  212 */     boolean noPvr = (cl.getOpt("nopvr") != null);
/*  213 */     boolean noAnn = (cl.getOpt("noann") != null);
/*  214 */     boolean noVDoc = (cl.getOpt("novdoc") != null);
/*  215 */     boolean noExt = (cl.getOpt("noext") != null);
/*  216 */     boolean nojavac = (cl.getOpt("srconly") != null);
/*  217 */     boolean debug = (cl.getOpt("debug") != null);
/*      */     
/*  219 */     String allowmdef = cl.getOpt("allowmdef");
/*  220 */     Set mdefNamespaces = (allowmdef == null) ? Collections.EMPTY_SET : new HashSet(Arrays.asList((Object[])XmlListImpl.split_list(allowmdef)));
/*      */ 
/*      */     
/*  223 */     List extensions = new ArrayList();
/*  224 */     if (cl.getOpt("extension") != null) {
/*      */       try {
/*  226 */         Extension e = new Extension();
/*  227 */         e.setClassName(Class.forName(cl.getOpt("extension"), false, Thread.currentThread().getContextClassLoader()));
/*  228 */         extensions.add(e);
/*  229 */       } catch (ClassNotFoundException e) {
/*  230 */         System.err.println("Could not find extension class: " + cl.getOpt("extension") + "  Is it on your classpath?");
/*  231 */         System.exit(1);
/*      */       } 
/*      */     }
/*      */     
/*  235 */     if (extensions.size() > 0)
/*      */     {
/*      */       
/*  238 */       if (cl.getOpt("extensionParms") != null) {
/*  239 */         Extension e = extensions.get(0);
/*      */         
/*  241 */         StringTokenizer parmTokens = new StringTokenizer(cl.getOpt("extensionParms"), ";");
/*  242 */         while (parmTokens.hasMoreTokens()) {
/*      */           
/*  244 */           String nvPair = parmTokens.nextToken();
/*  245 */           int index = nvPair.indexOf('=');
/*  246 */           if (index < 0) {
/*      */             
/*  248 */             System.err.println("extensionParms should be name=value;name=value");
/*  249 */             System.exit(1);
/*      */           } 
/*  251 */           String n = nvPair.substring(0, index);
/*  252 */           String v = nvPair.substring(index + 1);
/*  253 */           Extension.Param param = e.createParam();
/*  254 */           param.setName(n);
/*  255 */           param.setValue(v);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  260 */     String classesdir = cl.getOpt("d");
/*  261 */     File classes = null;
/*  262 */     if (classesdir != null) {
/*  263 */       classes = new File(classesdir);
/*      */     }
/*  265 */     String srcdir = cl.getOpt("src");
/*  266 */     File src = null;
/*  267 */     if (srcdir != null)
/*  268 */       src = new File(srcdir); 
/*  269 */     if (nojavac && srcdir == null && classes != null) {
/*  270 */       src = classes;
/*      */     }
/*      */     
/*  273 */     File tempdir = null;
/*  274 */     if (src == null || classes == null) {
/*      */       
/*      */       try {
/*      */         
/*  278 */         tempdir = SchemaCodeGenerator.createTempDir();
/*      */       }
/*  280 */       catch (IOException e) {
/*      */         
/*  282 */         System.err.println("Error creating temp dir " + e);
/*  283 */         System.exit(1);
/*      */       } 
/*      */     }
/*      */     
/*  287 */     File jarfile = null;
/*  288 */     if (outputfilename == null && classes == null && !nojavac)
/*  289 */       outputfilename = "xmltypes.jar"; 
/*  290 */     if (outputfilename != null) {
/*  291 */       jarfile = new File(outputfilename);
/*      */     }
/*  293 */     if (src == null)
/*  294 */       src = IOUtil.createDir(tempdir, "src"); 
/*  295 */     if (classes == null) {
/*  296 */       classes = IOUtil.createDir(tempdir, "classes");
/*      */     }
/*  298 */     File[] classpath = null;
/*  299 */     String cpString = cl.getOpt("cp");
/*  300 */     if (cpString != null) {
/*      */       
/*  302 */       String[] cpparts = cpString.split(File.pathSeparator);
/*  303 */       List cpList = new ArrayList();
/*  304 */       for (int i = 0; i < cpparts.length; i++)
/*  305 */         cpList.add(new File(cpparts[i])); 
/*  306 */       classpath = cpList.<File>toArray(new File[cpList.size()]);
/*      */     }
/*      */     else {
/*      */       
/*  310 */       classpath = CodeGenUtil.systemClasspath();
/*      */     } 
/*      */     
/*  313 */     String javasource = cl.getOpt("javasource");
/*  314 */     String compiler = cl.getOpt("compiler");
/*  315 */     String jar = cl.getOpt("jar");
/*  316 */     if (verbose && jar != null) {
/*  317 */       System.out.println("The 'jar' option is no longer supported.");
/*      */     }
/*  319 */     String memoryInitialSize = cl.getOpt("ms");
/*  320 */     String memoryMaximumSize = cl.getOpt("mx");
/*      */     
/*  322 */     File[] xsdFiles = cl.filesEndingWith(".xsd");
/*  323 */     File[] wsdlFiles = cl.filesEndingWith(".wsdl");
/*  324 */     File[] javaFiles = cl.filesEndingWith(".java");
/*  325 */     File[] configFiles = cl.filesEndingWith(".xsdconfig");
/*  326 */     URL[] urlFiles = cl.getURLs();
/*      */     
/*  328 */     if (xsdFiles.length + wsdlFiles.length + urlFiles.length == 0) {
/*      */       
/*  330 */       System.out.println("Could not find any xsd or wsdl files to process.");
/*  331 */       System.exit(0);
/*      */     } 
/*  333 */     File baseDir = cl.getBaseDir();
/*  334 */     URI baseURI = (baseDir == null) ? null : baseDir.toURI();
/*      */     
/*  336 */     XmlErrorPrinter err = new XmlErrorPrinter(verbose, baseURI);
/*      */     
/*  338 */     String catString = cl.getOpt("catalog");
/*      */     
/*  340 */     Parameters params = new Parameters();
/*  341 */     params.setBaseDir(baseDir);
/*  342 */     params.setXsdFiles(xsdFiles);
/*  343 */     params.setWsdlFiles(wsdlFiles);
/*  344 */     params.setJavaFiles(javaFiles);
/*  345 */     params.setConfigFiles(configFiles);
/*  346 */     params.setUrlFiles(urlFiles);
/*  347 */     params.setClasspath(classpath);
/*  348 */     params.setOutputJar(jarfile);
/*  349 */     params.setName(name);
/*  350 */     params.setSrcDir(src);
/*  351 */     params.setClassesDir(classes);
/*  352 */     params.setCompiler(compiler);
/*  353 */     params.setJavaSource(javasource);
/*  354 */     params.setMemoryInitialSize(memoryInitialSize);
/*  355 */     params.setMemoryMaximumSize(memoryMaximumSize);
/*  356 */     params.setNojavac(nojavac);
/*  357 */     params.setQuiet(quiet);
/*  358 */     params.setVerbose(verbose);
/*  359 */     params.setDownload(download);
/*  360 */     params.setNoUpa(noUpa);
/*  361 */     params.setNoPvr(noPvr);
/*  362 */     params.setNoAnn(noAnn);
/*  363 */     params.setNoVDoc(noVDoc);
/*  364 */     params.setNoExt(noExt);
/*  365 */     params.setDebug(debug);
/*  366 */     params.setErrorListener((Collection)err);
/*  367 */     params.setRepackage(repackage);
/*  368 */     params.setExtensions(extensions);
/*  369 */     params.setMdefNamespaces(mdefNamespaces);
/*  370 */     params.setCatalogFile(catString);
/*  371 */     params.setSchemaCodePrinter(codePrinter);
/*      */     
/*  373 */     boolean result = compile(params);
/*      */     
/*  375 */     if (tempdir != null) {
/*  376 */       SchemaCodeGenerator.tryHardToDelete(tempdir);
/*      */     }
/*  378 */     if (!result) {
/*  379 */       System.exit(1);
/*      */     }
/*  381 */     System.exit(0);
/*      */   }
/*      */   
/*      */   public static class Parameters
/*      */   {
/*      */     private File baseDir;
/*      */     private File[] xsdFiles;
/*      */     private File[] wsdlFiles;
/*      */     private File[] javaFiles;
/*      */     private File[] configFiles;
/*      */     private URL[] urlFiles;
/*      */     private File[] classpath;
/*      */     private File outputJar;
/*      */     private String name;
/*      */     private File srcDir;
/*      */     private File classesDir;
/*      */     private String memoryInitialSize;
/*      */     private String memoryMaximumSize;
/*      */     private String compiler;
/*      */     private String javasource;
/*      */     private boolean nojavac;
/*      */     private boolean quiet;
/*      */     private boolean verbose;
/*      */     private boolean download;
/*      */     private Collection errorListener;
/*      */     private boolean noUpa;
/*      */     private boolean noPvr;
/*      */     private boolean noAnn;
/*      */     private boolean noVDoc;
/*      */     private boolean noExt;
/*      */     private boolean debug;
/*      */     private boolean incrementalSrcGen;
/*      */     private String repackage;
/*  414 */     private List extensions = Collections.EMPTY_LIST;
/*  415 */     private Set mdefNamespaces = Collections.EMPTY_SET;
/*      */     
/*      */     private String catalogFile;
/*      */     private SchemaCodePrinter schemaCodePrinter;
/*      */     private EntityResolver entityResolver;
/*      */     
/*      */     public File getBaseDir() {
/*  422 */       return this.baseDir;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setBaseDir(File baseDir) {
/*  427 */       this.baseDir = baseDir;
/*      */     }
/*      */ 
/*      */     
/*      */     public File[] getXsdFiles() {
/*  432 */       return this.xsdFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setXsdFiles(File[] xsdFiles) {
/*  437 */       this.xsdFiles = xsdFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public File[] getWsdlFiles() {
/*  442 */       return this.wsdlFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setWsdlFiles(File[] wsdlFiles) {
/*  447 */       this.wsdlFiles = wsdlFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public File[] getJavaFiles() {
/*  452 */       return this.javaFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setJavaFiles(File[] javaFiles) {
/*  457 */       this.javaFiles = javaFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public File[] getConfigFiles() {
/*  462 */       return this.configFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setConfigFiles(File[] configFiles) {
/*  467 */       this.configFiles = configFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public URL[] getUrlFiles() {
/*  472 */       return this.urlFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setUrlFiles(URL[] urlFiles) {
/*  477 */       this.urlFiles = urlFiles;
/*      */     }
/*      */ 
/*      */     
/*      */     public File[] getClasspath() {
/*  482 */       return this.classpath;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setClasspath(File[] classpath) {
/*  487 */       this.classpath = classpath;
/*      */     }
/*      */ 
/*      */     
/*      */     public File getOutputJar() {
/*  492 */       return this.outputJar;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setOutputJar(File outputJar) {
/*  497 */       this.outputJar = outputJar;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getName() {
/*  502 */       return this.name;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setName(String name) {
/*  507 */       this.name = name;
/*      */     }
/*      */ 
/*      */     
/*      */     public File getSrcDir() {
/*  512 */       return this.srcDir;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSrcDir(File srcDir) {
/*  517 */       this.srcDir = srcDir;
/*      */     }
/*      */ 
/*      */     
/*      */     public File getClassesDir() {
/*  522 */       return this.classesDir;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setClassesDir(File classesDir) {
/*  527 */       this.classesDir = classesDir;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isNojavac() {
/*  532 */       return this.nojavac;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setNojavac(boolean nojavac) {
/*  537 */       this.nojavac = nojavac;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isQuiet() {
/*  542 */       return this.quiet;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setQuiet(boolean quiet) {
/*  547 */       this.quiet = quiet;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isVerbose() {
/*  552 */       return this.verbose;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setVerbose(boolean verbose) {
/*  557 */       this.verbose = verbose;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDownload() {
/*  562 */       return this.download;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setDownload(boolean download) {
/*  567 */       this.download = download;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isNoUpa() {
/*  572 */       return this.noUpa;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setNoUpa(boolean noUpa) {
/*  577 */       this.noUpa = noUpa;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isNoPvr() {
/*  582 */       return this.noPvr;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setNoPvr(boolean noPvr) {
/*  587 */       this.noPvr = noPvr;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isNoAnn() {
/*  592 */       return this.noAnn;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setNoAnn(boolean noAnn) {
/*  597 */       this.noAnn = noAnn;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isNoVDoc() {
/*  602 */       return this.noVDoc;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setNoVDoc(boolean newNoVDoc) {
/*  607 */       this.noVDoc = newNoVDoc;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isNoExt() {
/*  612 */       return this.noExt;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setNoExt(boolean newNoExt) {
/*  617 */       this.noExt = newNoExt;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isIncrementalSrcGen() {
/*  622 */       return this.incrementalSrcGen;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setIncrementalSrcGen(boolean incrSrcGen) {
/*  627 */       this.incrementalSrcGen = incrSrcGen;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDebug() {
/*  632 */       return this.debug;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setDebug(boolean debug) {
/*  637 */       this.debug = debug;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getMemoryInitialSize() {
/*  642 */       return this.memoryInitialSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setMemoryInitialSize(String memoryInitialSize) {
/*  647 */       this.memoryInitialSize = memoryInitialSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getMemoryMaximumSize() {
/*  652 */       return this.memoryMaximumSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setMemoryMaximumSize(String memoryMaximumSize) {
/*  657 */       this.memoryMaximumSize = memoryMaximumSize;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getCompiler() {
/*  662 */       return this.compiler;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setCompiler(String compiler) {
/*  667 */       this.compiler = compiler;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getJavaSource() {
/*  672 */       return this.javasource;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setJavaSource(String javasource) {
/*  677 */       this.javasource = javasource;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String getJar() {
/*  683 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setJar(String jar) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection getErrorListener() {
/*  694 */       return this.errorListener;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setErrorListener(Collection errorListener) {
/*  699 */       this.errorListener = errorListener;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getRepackage() {
/*  704 */       return this.repackage;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setRepackage(String newRepackage) {
/*  709 */       this.repackage = newRepackage;
/*      */     }
/*      */     
/*      */     public List getExtensions() {
/*  713 */       return this.extensions;
/*      */     }
/*      */     
/*      */     public void setExtensions(List extensions) {
/*  717 */       this.extensions = extensions;
/*      */     }
/*      */ 
/*      */     
/*      */     public Set getMdefNamespaces() {
/*  722 */       return this.mdefNamespaces;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setMdefNamespaces(Set mdefNamespaces) {
/*  727 */       this.mdefNamespaces = mdefNamespaces;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getCatalogFile() {
/*  732 */       return this.catalogFile;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setCatalogFile(String catalogPropFile) {
/*  737 */       this.catalogFile = catalogPropFile;
/*      */     }
/*      */ 
/*      */     
/*      */     public SchemaCodePrinter getSchemaCodePrinter() {
/*  742 */       return this.schemaCodePrinter;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSchemaCodePrinter(SchemaCodePrinter schemaCodePrinter) {
/*  747 */       this.schemaCodePrinter = schemaCodePrinter;
/*      */     }
/*      */     
/*      */     public EntityResolver getEntityResolver() {
/*  751 */       return this.entityResolver;
/*      */     }
/*      */     
/*      */     public void setEntityResolver(EntityResolver entityResolver) {
/*  755 */       this.entityResolver = entityResolver;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static SchemaTypeSystem loadTypeSystem(String name, File[] xsdFiles, File[] wsdlFiles, URL[] urlFiles, File[] configFiles, File[] javaFiles, ResourceLoader cpResourceLoader, boolean download, boolean noUpa, boolean noPvr, boolean noAnn, boolean noVDoc, boolean noExt, Set mdefNamespaces, File baseDir, Map sourcesToCopyMap, Collection outerErrorListener, File schemasDir, EntityResolver entResolver, File[] classpath, String javasource) {
/*  765 */     XmlErrorWatcher errorListener = new XmlErrorWatcher(outerErrorListener);
/*      */ 
/*      */     
/*  768 */     StscState state = StscState.start();
/*  769 */     state.setErrorListener((Collection)errorListener);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  777 */     SchemaTypeLoader loader = XmlBeans.typeLoaderForClassLoader(SchemaDocument.class.getClassLoader());
/*      */ 
/*      */     
/*  780 */     ArrayList scontentlist = new ArrayList();
/*  781 */     if (xsdFiles != null)
/*      */     {
/*  783 */       for (int i = 0; i < xsdFiles.length; i++) {
/*      */ 
/*      */         
/*      */         try {
/*  787 */           XmlOptions options = new XmlOptions();
/*  788 */           options.setLoadLineNumbers();
/*  789 */           options.setLoadMessageDigest();
/*  790 */           options.setEntityResolver(entResolver);
/*      */           
/*  792 */           XmlObject schemadoc = loader.parse(xsdFiles[i], null, options);
/*  793 */           if (!(schemadoc instanceof SchemaDocument))
/*      */           {
/*  795 */             StscState.addError((Collection)errorListener, "invalid.document.type", new Object[] { xsdFiles[i], "schema" }, schemadoc);
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*  800 */             addSchema(xsdFiles[i].toString(), (SchemaDocument)schemadoc, errorListener, noVDoc, scontentlist);
/*      */           }
/*      */         
/*      */         }
/*  804 */         catch (XmlException e) {
/*      */           
/*  806 */           errorListener.add(e.getError());
/*      */         }
/*  808 */         catch (Exception e) {
/*      */           
/*  810 */           StscState.addError((Collection)errorListener, "cannot.load.file", new Object[] { "xsd", xsdFiles[i], e.getMessage() }, xsdFiles[i]);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  817 */     if (wsdlFiles != null)
/*      */     {
/*  819 */       for (int i = 0; i < wsdlFiles.length; i++) {
/*      */ 
/*      */         
/*      */         try {
/*  823 */           XmlOptions options = new XmlOptions();
/*  824 */           options.setLoadLineNumbers();
/*  825 */           options.setLoadSubstituteNamespaces(Collections.singletonMap("http://schemas.xmlsoap.org/wsdl/", "http://www.apache.org/internal/xmlbeans/wsdlsubst"));
/*      */ 
/*      */           
/*  828 */           options.setEntityResolver(entResolver);
/*      */           
/*  830 */           XmlObject wsdldoc = loader.parse(wsdlFiles[i], null, options);
/*      */           
/*  832 */           if (!(wsdldoc instanceof DefinitionsDocument)) {
/*  833 */             StscState.addError((Collection)errorListener, "invalid.document.type", new Object[] { wsdlFiles[i], "wsdl" }, wsdldoc);
/*      */           }
/*      */           else {
/*      */             
/*  837 */             addWsdlSchemas(wsdlFiles[i].toString(), (DefinitionsDocument)wsdldoc, errorListener, noVDoc, scontentlist);
/*      */           }
/*      */         
/*  840 */         } catch (XmlException e) {
/*      */           
/*  842 */           errorListener.add(e.getError());
/*      */         }
/*  844 */         catch (Exception e) {
/*      */           
/*  846 */           StscState.addError((Collection)errorListener, "cannot.load.file", new Object[] { "wsdl", wsdlFiles[i], e.getMessage() }, wsdlFiles[i]);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  854 */     if (urlFiles != null)
/*      */     {
/*  856 */       for (int i = 0; i < urlFiles.length; i++) {
/*      */ 
/*      */         
/*      */         try {
/*  860 */           XmlOptions options = new XmlOptions();
/*  861 */           options.setLoadLineNumbers();
/*  862 */           options.setLoadSubstituteNamespaces(Collections.singletonMap("http://schemas.xmlsoap.org/wsdl/", "http://www.apache.org/internal/xmlbeans/wsdlsubst"));
/*  863 */           options.setEntityResolver(entResolver);
/*      */           
/*  865 */           XmlObject urldoc = loader.parse(urlFiles[i], null, options);
/*      */           
/*  867 */           if (urldoc instanceof DefinitionsDocument)
/*      */           {
/*  869 */             addWsdlSchemas(urlFiles[i].toString(), (DefinitionsDocument)urldoc, errorListener, noVDoc, scontentlist);
/*      */           }
/*  871 */           else if (urldoc instanceof SchemaDocument)
/*      */           {
/*  873 */             addSchema(urlFiles[i].toString(), (SchemaDocument)urldoc, errorListener, noVDoc, scontentlist);
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*  878 */             StscState.addError((Collection)errorListener, "invalid.document.type", new Object[] { urlFiles[i], "wsdl or schema" }, urldoc);
/*      */           
/*      */           }
/*      */         
/*      */         }
/*  883 */         catch (XmlException e) {
/*      */           
/*  885 */           errorListener.add(e.getError());
/*      */         }
/*  887 */         catch (Exception e) {
/*      */           
/*  889 */           StscState.addError((Collection)errorListener, "cannot.load.file", new Object[] { "url", urlFiles[i], e.getMessage() }, urlFiles[i]);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  895 */     SchemaDocument.Schema[] sdocs = (SchemaDocument.Schema[])scontentlist.toArray((Object[])new SchemaDocument.Schema[scontentlist.size()]);
/*      */ 
/*      */     
/*  898 */     ArrayList cdoclist = new ArrayList();
/*  899 */     if (configFiles != null) {
/*      */       
/*  901 */       if (noExt) {
/*  902 */         System.out.println("Pre/Post and Interface extensions will be ignored.");
/*      */       }
/*  904 */       for (int i = 0; i < configFiles.length; i++) {
/*      */ 
/*      */         
/*      */         try {
/*  908 */           XmlOptions options = new XmlOptions();
/*  909 */           options.put("LOAD_LINE_NUMBERS");
/*  910 */           options.setEntityResolver(entResolver);
/*  911 */           options.setLoadSubstituteNamespaces(MAP_COMPATIBILITY_CONFIG_URIS);
/*      */           
/*  913 */           XmlObject configdoc = loader.parse(configFiles[i], null, options);
/*  914 */           if (!(configdoc instanceof ConfigDocument)) {
/*  915 */             StscState.addError((Collection)errorListener, "invalid.document.type", new Object[] { configFiles[i], "xsd config" }, configdoc);
/*      */           }
/*      */           else {
/*      */             
/*  919 */             StscState.addInfo((Collection)errorListener, "Loading config file " + configFiles[i]);
/*  920 */             if (configdoc.validate((new XmlOptions()).setErrorListener((Collection)errorListener)))
/*      */             {
/*  922 */               ConfigDocument.Config config = ((ConfigDocument)configdoc).getConfig();
/*  923 */               cdoclist.add(config);
/*  924 */               if (noExt)
/*      */               {
/*      */                 
/*  927 */                 config.setExtensionArray(new org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig[0]);
/*      */               }
/*      */             }
/*      */           
/*      */           } 
/*  932 */         } catch (XmlException e) {
/*      */           
/*  934 */           errorListener.add(e.getError());
/*      */         }
/*  936 */         catch (Exception e) {
/*      */           
/*  938 */           StscState.addError((Collection)errorListener, "cannot.load.file", new Object[] { "xsd config", configFiles[i], e.getMessage() }, configFiles[i]);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  943 */     ConfigDocument.Config[] cdocs = cdoclist.<ConfigDocument.Config>toArray(new ConfigDocument.Config[cdoclist.size()]);
/*      */     
/*  945 */     SchemaTypeLoader linkTo = SchemaTypeLoaderImpl.build(null, cpResourceLoader, null);
/*      */     
/*  947 */     URI baseURI = null;
/*  948 */     if (baseDir != null) {
/*  949 */       baseURI = baseDir.toURI();
/*      */     }
/*  951 */     XmlOptions opts = new XmlOptions();
/*  952 */     if (download)
/*  953 */       opts.setCompileDownloadUrls(); 
/*  954 */     if (noUpa)
/*  955 */       opts.setCompileNoUpaRule(); 
/*  956 */     if (noPvr)
/*  957 */       opts.setCompileNoPvrRule(); 
/*  958 */     if (noAnn)
/*  959 */       opts.setCompileNoAnnotations(); 
/*  960 */     if (mdefNamespaces != null)
/*  961 */       opts.setCompileMdefNamespaces(mdefNamespaces); 
/*  962 */     opts.setCompileNoValidation();
/*  963 */     opts.setEntityResolver(entResolver);
/*  964 */     if (javasource != null) {
/*  965 */       opts.setGenerateJavaVersion(javasource);
/*      */     }
/*      */     
/*  968 */     SchemaTypeSystemCompiler.Parameters params = new SchemaTypeSystemCompiler.Parameters();
/*  969 */     params.setName(name);
/*  970 */     params.setSchemas(sdocs);
/*  971 */     params.setConfig(BindingConfigImpl.forConfigDocuments(cdocs, javaFiles, classpath));
/*  972 */     params.setLinkTo(linkTo);
/*  973 */     params.setOptions(opts);
/*  974 */     params.setErrorListener((Collection)errorListener);
/*  975 */     params.setJavaize(true);
/*  976 */     params.setBaseURI(baseURI);
/*  977 */     params.setSourcesToCopyMap(sourcesToCopyMap);
/*  978 */     params.setSchemasDir(schemasDir);
/*  979 */     return SchemaTypeSystemCompiler.compile(params);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addSchema(String name, SchemaDocument schemadoc, XmlErrorWatcher errorListener, boolean noVDoc, List scontentlist) {
/*  985 */     StscState.addInfo((Collection)errorListener, "Loading schema file " + name);
/*  986 */     XmlOptions opts = (new XmlOptions()).setErrorListener((Collection)errorListener);
/*  987 */     if (noVDoc)
/*  988 */       opts.setValidateTreatLaxAsSkip(); 
/*  989 */     if (schemadoc.validate(opts)) {
/*  990 */       scontentlist.add(schemadoc.getSchema());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addWsdlSchemas(String name, DefinitionsDocument wsdldoc, XmlErrorWatcher errorListener, boolean noVDoc, List scontentlist) {
/*  997 */     if (wsdlContainsEncoded((XmlObject)wsdldoc))
/*  998 */       StscState.addWarning((Collection)errorListener, "The WSDL " + name + " uses SOAP encoding. SOAP encoding is not compatible with literal XML Schema.", 60, (XmlObject)wsdldoc); 
/*  999 */     StscState.addInfo((Collection)errorListener, "Loading wsdl file " + name);
/* 1000 */     XmlOptions opts = (new XmlOptions()).setErrorListener((Collection)errorListener);
/* 1001 */     if (noVDoc)
/* 1002 */       opts.setValidateTreatLaxAsSkip(); 
/* 1003 */     XmlObject[] types = wsdldoc.getDefinitions().getTypesArray();
/* 1004 */     int count = 0;
/* 1005 */     for (int j = 0; j < types.length; j++) {
/*      */       
/* 1007 */       XmlObject[] schemas = types[j].selectPath("declare namespace xs=\"http://www.w3.org/2001/XMLSchema\" xs:schema");
/* 1008 */       if (schemas.length == 0) {
/*      */         
/* 1010 */         StscState.addWarning((Collection)errorListener, "The WSDL " + name + " did not have any schema documents in namespace 'http://www.w3.org/2001/XMLSchema'", 60, (XmlObject)wsdldoc);
/*      */       }
/*      */       else {
/*      */         
/* 1014 */         for (int k = 0; k < schemas.length; k++) {
/*      */           
/* 1016 */           if (schemas[k] instanceof SchemaDocument.Schema && schemas[k].validate(opts)) {
/*      */ 
/*      */             
/* 1019 */             count++;
/* 1020 */             scontentlist.add(schemas[k]);
/*      */           } 
/*      */         } 
/*      */       } 
/* 1024 */     }  StscState.addInfo((Collection)errorListener, "Processing " + count + " schema(s) in " + name);
/*      */   }
/*      */   
/*      */   public static boolean compile(Parameters params) {
/*      */     PathResourceLoader pathResourceLoader;
/* 1029 */     File baseDir = params.getBaseDir();
/* 1030 */     File[] xsdFiles = params.getXsdFiles();
/* 1031 */     File[] wsdlFiles = params.getWsdlFiles();
/* 1032 */     URL[] urlFiles = params.getUrlFiles();
/* 1033 */     File[] javaFiles = params.getJavaFiles();
/* 1034 */     File[] configFiles = params.getConfigFiles();
/* 1035 */     File[] classpath = params.getClasspath();
/* 1036 */     File outputJar = params.getOutputJar();
/* 1037 */     String name = params.getName();
/* 1038 */     File srcDir = params.getSrcDir();
/* 1039 */     File classesDir = params.getClassesDir();
/* 1040 */     String compiler = params.getCompiler();
/* 1041 */     String javasource = params.getJavaSource();
/* 1042 */     String memoryInitialSize = params.getMemoryInitialSize();
/* 1043 */     String memoryMaximumSize = params.getMemoryMaximumSize();
/* 1044 */     boolean nojavac = params.isNojavac();
/* 1045 */     boolean debug = params.isDebug();
/* 1046 */     boolean verbose = params.isVerbose();
/* 1047 */     boolean quiet = params.isQuiet();
/* 1048 */     boolean download = params.isDownload();
/* 1049 */     boolean noUpa = params.isNoUpa();
/* 1050 */     boolean noPvr = params.isNoPvr();
/* 1051 */     boolean noAnn = params.isNoAnn();
/* 1052 */     boolean noVDoc = params.isNoVDoc();
/* 1053 */     boolean noExt = params.isNoExt();
/* 1054 */     boolean incrSrcGen = params.isIncrementalSrcGen();
/* 1055 */     Collection outerErrorListener = params.getErrorListener();
/*      */     
/* 1057 */     String repackage = params.getRepackage();
/*      */     
/* 1059 */     if (repackage != null) {
/*      */       
/* 1061 */       SchemaTypeLoaderImpl.METADATA_PACKAGE_LOAD = SchemaTypeSystemImpl.METADATA_PACKAGE_GEN;
/*      */       
/* 1063 */       String stsPackage = SchemaTypeSystem.class.getPackage().getName();
/* 1064 */       Repackager repackager = new Repackager(repackage);
/*      */       
/* 1066 */       SchemaTypeSystemImpl.METADATA_PACKAGE_GEN = repackager.repackage(new StringBuffer(stsPackage)).toString().replace('.', '_');
/*      */       
/* 1068 */       System.out.println("\n\n\n" + stsPackage + ".SchemaCompiler  Metadata LOAD:" + SchemaTypeLoaderImpl.METADATA_PACKAGE_LOAD + " GEN:" + SchemaTypeSystemImpl.METADATA_PACKAGE_GEN);
/*      */     } 
/*      */     
/* 1071 */     SchemaCodePrinter codePrinter = params.getSchemaCodePrinter();
/* 1072 */     List extensions = params.getExtensions();
/* 1073 */     Set mdefNamespaces = params.getMdefNamespaces();
/*      */     
/* 1075 */     EntityResolver cmdLineEntRes = (params.getEntityResolver() == null) ? ResolverUtil.resolverForCatalog(params.getCatalogFile()) : params.getEntityResolver();
/*      */ 
/*      */     
/* 1078 */     if (srcDir == null || classesDir == null) {
/* 1079 */       throw new IllegalArgumentException("src and class gen directories may not be null.");
/*      */     }
/* 1081 */     long start = System.currentTimeMillis();
/*      */ 
/*      */     
/* 1084 */     if (baseDir == null) {
/* 1085 */       baseDir = new File(SystemProperties.getProperty("user.dir"));
/*      */     }
/* 1087 */     ResourceLoader cpResourceLoader = null;
/*      */     
/* 1089 */     Map sourcesToCopyMap = new HashMap();
/*      */     
/* 1091 */     if (classpath != null) {
/* 1092 */       pathResourceLoader = new PathResourceLoader(classpath);
/*      */     }
/* 1094 */     boolean result = true;
/*      */     
/* 1096 */     File schemasDir = IOUtil.createDir(classesDir, "schema" + SchemaTypeSystemImpl.METADATA_PACKAGE_GEN + "/src");
/*      */ 
/*      */     
/* 1099 */     XmlErrorWatcher errorListener = new XmlErrorWatcher(outerErrorListener);
/* 1100 */     SchemaTypeSystem system = loadTypeSystem(name, xsdFiles, wsdlFiles, urlFiles, configFiles, javaFiles, (ResourceLoader)pathResourceLoader, download, noUpa, noPvr, noAnn, noVDoc, noExt, mdefNamespaces, baseDir, sourcesToCopyMap, (Collection)errorListener, schemasDir, cmdLineEntRes, classpath, javasource);
/*      */ 
/*      */     
/* 1103 */     if (errorListener.hasError())
/* 1104 */       result = false; 
/* 1105 */     long finish = System.currentTimeMillis();
/* 1106 */     if (!quiet) {
/* 1107 */       System.out.println("Time to build schema type system: " + ((finish - start) / 1000.0D) + " seconds");
/*      */     }
/*      */     
/* 1110 */     if (result && system != null) {
/*      */       
/* 1112 */       start = System.currentTimeMillis();
/*      */ 
/*      */       
/* 1115 */       Repackager repackager = (repackage == null) ? null : new Repackager(repackage);
/* 1116 */       FilerImpl filer = new FilerImpl(classesDir, srcDir, repackager, verbose, incrSrcGen);
/*      */ 
/*      */       
/* 1119 */       XmlOptions options = new XmlOptions();
/* 1120 */       if (codePrinter != null)
/* 1121 */         options.setSchemaCodePrinter(codePrinter); 
/* 1122 */       if (javasource != null) {
/* 1123 */         options.setGenerateJavaVersion(javasource);
/*      */       }
/*      */       
/* 1126 */       system.save((Filer)filer);
/*      */ 
/*      */       
/* 1129 */       result &= SchemaTypeSystemCompiler.generateTypes(system, (Filer)filer, options);
/*      */       
/* 1131 */       if (incrSrcGen)
/*      */       {
/*      */         
/* 1134 */         SchemaCodeGenerator.deleteObsoleteFiles(srcDir, srcDir, new HashSet(filer.getSourceFiles()));
/*      */       }
/*      */ 
/*      */       
/* 1138 */       if (result) {
/*      */         
/* 1140 */         finish = System.currentTimeMillis();
/* 1141 */         if (!quiet) {
/* 1142 */           System.out.println("Time to generate code: " + ((finish - start) / 1000.0D) + " seconds");
/*      */         }
/*      */       } 
/*      */       
/* 1146 */       if (result && !nojavac) {
/*      */         
/* 1148 */         start = System.currentTimeMillis();
/*      */         
/* 1150 */         List sourcefiles = filer.getSourceFiles();
/*      */         
/* 1152 */         if (javaFiles != null)
/* 1153 */           sourcefiles.addAll(Arrays.asList(javaFiles)); 
/* 1154 */         if (!CodeGenUtil.externalCompile(sourcefiles, classesDir, classpath, debug, compiler, javasource, memoryInitialSize, memoryMaximumSize, quiet, verbose)) {
/* 1155 */           result = false;
/*      */         }
/* 1157 */         finish = System.currentTimeMillis();
/* 1158 */         if (result && !params.isQuiet()) {
/* 1159 */           System.out.println("Time to compile code: " + ((finish - start) / 1000.0D) + " seconds");
/*      */         }
/*      */         
/* 1162 */         if (result && outputJar != null) {
/*      */ 
/*      */           
/*      */           try {
/* 1166 */             (new JarHelper()).jarDir(classesDir, outputJar);
/*      */           }
/* 1168 */           catch (IOException e) {
/*      */             
/* 1170 */             System.err.println("IO Error " + e);
/* 1171 */             result = false;
/*      */           } 
/*      */           
/* 1174 */           if (result && !params.isQuiet()) {
/* 1175 */             System.out.println("Compiled types to: " + outputJar);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1180 */     if (!result && !quiet) {
/*      */       
/* 1182 */       System.out.println("BUILD FAILED");
/*      */     }
/*      */     else {
/*      */       
/* 1186 */       runExtensions(extensions, system, classesDir);
/*      */     } 
/*      */     
/* 1189 */     if (pathResourceLoader != null)
/* 1190 */       pathResourceLoader.close(); 
/* 1191 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void runExtensions(List extensions, SchemaTypeSystem system, File classesDir) {
/* 1196 */     if (extensions != null && extensions.size() > 0) {
/*      */       
/* 1198 */       SchemaCompilerExtension sce = null;
/* 1199 */       Iterator i = extensions.iterator();
/* 1200 */       Map extensionParms = null;
/* 1201 */       String classesDirName = null;
/*      */       
/*      */       try {
/* 1204 */         classesDirName = classesDir.getCanonicalPath();
/*      */       }
/* 1206 */       catch (IOException e) {
/*      */         
/* 1208 */         System.out.println("WARNING: Unable to get the path for schema jar file");
/* 1209 */         classesDirName = classesDir.getAbsolutePath();
/*      */       } 
/*      */       
/* 1212 */       while (i.hasNext()) {
/*      */         
/* 1214 */         Extension extension = i.next();
/*      */         
/*      */         try {
/* 1217 */           sce = extension.getClassName().newInstance();
/*      */         }
/* 1219 */         catch (InstantiationException e) {
/*      */           
/* 1221 */           System.out.println("UNABLE to instantiate schema compiler extension:" + extension.getClassName().getName());
/* 1222 */           System.out.println("EXTENSION Class was not run");
/*      */           
/*      */           break;
/* 1225 */         } catch (IllegalAccessException e) {
/*      */           
/* 1227 */           System.out.println("ILLEGAL ACCESS Exception when attempting to instantiate schema compiler extension: " + extension.getClassName().getName());
/* 1228 */           System.out.println("EXTENSION Class was not run");
/*      */           
/*      */           break;
/*      */         } 
/* 1232 */         System.out.println("Running Extension: " + sce.getExtensionName());
/* 1233 */         extensionParms = new HashMap();
/* 1234 */         Iterator parmsi = extension.getParams().iterator();
/* 1235 */         while (parmsi.hasNext()) {
/*      */           
/* 1237 */           Extension.Param p = parmsi.next();
/* 1238 */           extensionParms.put(p.getName(), p.getValue());
/*      */         } 
/* 1240 */         extensionParms.put("classesDir", classesDirName);
/* 1241 */         sce.schemaCompilerExtension(system, extensionParms);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean wsdlContainsEncoded(XmlObject wsdldoc) {
/* 1250 */     XmlObject[] useAttrs = wsdldoc.selectPath("declare namespace soap='http://schemas.xmlsoap.org/wsdl/soap/' .//soap:body/@use|.//soap:header/@use|.//soap:fault/@use");
/*      */ 
/*      */     
/* 1253 */     for (int i = 0; i < useAttrs.length; i++) {
/*      */       
/* 1255 */       if ("encoded".equals(((SimpleValue)useAttrs[i]).getStringValue()))
/* 1256 */         return true; 
/*      */     } 
/* 1258 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1266 */   private static final Map MAP_COMPATIBILITY_CONFIG_URIS = new HashMap(); static {
/* 1267 */     MAP_COMPATIBILITY_CONFIG_URIS.put("http://www.bea.com/2002/09/xbean/config", "http://xml.apache.org/xmlbeans/2004/02/xbean/config");
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\tool\SchemaCompiler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */