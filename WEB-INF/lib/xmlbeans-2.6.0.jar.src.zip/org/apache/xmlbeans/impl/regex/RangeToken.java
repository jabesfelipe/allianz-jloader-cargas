/*     */ package org.apache.xmlbeans.impl.regex;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RangeToken
/*     */   extends Token
/*     */   implements Serializable
/*     */ {
/*     */   int[] ranges;
/*     */   boolean sorted;
/*     */   boolean compacted;
/*  26 */   RangeToken icaseCache = null;
/*  27 */   int[] map = null; int nonMapIndex;
/*     */   private static final int MAPSIZE = 256;
/*     */   
/*     */   RangeToken(int type) {
/*  31 */     super(type);
/*  32 */     setSorted(false);
/*     */   }
/*     */   
/*     */   protected void addRange(int start, int end) {
/*     */     int r1, r2;
/*  37 */     this.icaseCache = null;
/*     */ 
/*     */     
/*  40 */     if (start <= end) {
/*  41 */       r1 = start;
/*  42 */       r2 = end;
/*     */     } else {
/*  44 */       r1 = end;
/*  45 */       r2 = start;
/*     */     } 
/*     */     
/*  48 */     int pos = 0;
/*  49 */     if (this.ranges == null) {
/*  50 */       this.ranges = new int[2];
/*  51 */       this.ranges[0] = r1;
/*  52 */       this.ranges[1] = r2;
/*  53 */       setSorted(true);
/*     */     } else {
/*  55 */       pos = this.ranges.length;
/*  56 */       if (this.ranges[pos - 1] + 1 == r1) {
/*  57 */         this.ranges[pos - 1] = r2;
/*     */         return;
/*     */       } 
/*  60 */       int[] temp = new int[pos + 2];
/*  61 */       System.arraycopy(this.ranges, 0, temp, 0, pos);
/*  62 */       this.ranges = temp;
/*  63 */       if (this.ranges[pos - 1] >= r1)
/*  64 */         setSorted(false); 
/*  65 */       this.ranges[pos++] = r1;
/*  66 */       this.ranges[pos] = r2;
/*  67 */       if (!this.sorted)
/*  68 */         sortRanges(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final boolean isSorted() {
/*  73 */     return this.sorted;
/*     */   }
/*     */   private final void setSorted(boolean sort) {
/*  76 */     this.sorted = sort;
/*  77 */     if (!sort) this.compacted = false; 
/*     */   }
/*     */   private final boolean isCompacted() {
/*  80 */     return this.compacted;
/*     */   }
/*     */   private final void setCompacted() {
/*  83 */     this.compacted = true;
/*     */   }
/*     */   
/*     */   protected void sortRanges() {
/*  87 */     if (isSorted())
/*     */       return; 
/*  89 */     if (this.ranges == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     for (int i = this.ranges.length - 4; i >= 0; i -= 2) {
/*  97 */       for (int j = 0; j <= i; j += 2) {
/*  98 */         if (this.ranges[j] > this.ranges[j + 2] || (this.ranges[j] == this.ranges[j + 2] && this.ranges[j + 1] > this.ranges[j + 3])) {
/*     */ 
/*     */           
/* 101 */           int tmp = this.ranges[j + 2];
/* 102 */           this.ranges[j + 2] = this.ranges[j];
/* 103 */           this.ranges[j] = tmp;
/* 104 */           tmp = this.ranges[j + 3];
/* 105 */           this.ranges[j + 3] = this.ranges[j + 1];
/* 106 */           this.ranges[j + 1] = tmp;
/*     */         } 
/*     */       } 
/*     */     } 
/* 110 */     setSorted(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void compactRanges() {
/* 117 */     boolean DEBUG = false;
/* 118 */     if (this.ranges == null || this.ranges.length <= 2)
/*     */       return; 
/* 120 */     if (isCompacted())
/*     */       return; 
/* 122 */     int base = 0;
/* 123 */     int target = 0;
/*     */     
/* 125 */     while (target < this.ranges.length) {
/* 126 */       if (base != target) {
/* 127 */         this.ranges[base] = this.ranges[target++];
/* 128 */         this.ranges[base + 1] = this.ranges[target++];
/*     */       } else {
/* 130 */         target += 2;
/* 131 */       }  int baseend = this.ranges[base + 1];
/* 132 */       while (target < this.ranges.length && 
/* 133 */         baseend + 1 >= this.ranges[target]) {
/*     */         
/* 135 */         if (baseend + 1 == this.ranges[target]) {
/* 136 */           if (DEBUG) {
/* 137 */             System.err.println("Token#compactRanges(): Compaction: [" + this.ranges[base] + ", " + this.ranges[base + 1] + "], [" + this.ranges[target] + ", " + this.ranges[target + 1] + "] -> [" + this.ranges[base] + ", " + this.ranges[target + 1] + "]");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 144 */           this.ranges[base + 1] = this.ranges[target + 1];
/* 145 */           baseend = this.ranges[base + 1];
/* 146 */           target += 2; continue;
/* 147 */         }  if (baseend >= this.ranges[target + 1]) {
/* 148 */           if (DEBUG) {
/* 149 */             System.err.println("Token#compactRanges(): Compaction: [" + this.ranges[base] + ", " + this.ranges[base + 1] + "], [" + this.ranges[target] + ", " + this.ranges[target + 1] + "] -> [" + this.ranges[base] + ", " + this.ranges[base + 1] + "]");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 156 */           target += 2; continue;
/* 157 */         }  if (baseend < this.ranges[target + 1]) {
/* 158 */           if (DEBUG) {
/* 159 */             System.err.println("Token#compactRanges(): Compaction: [" + this.ranges[base] + ", " + this.ranges[base + 1] + "], [" + this.ranges[target] + ", " + this.ranges[target + 1] + "] -> [" + this.ranges[base] + ", " + this.ranges[target + 1] + "]");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 166 */           this.ranges[base + 1] = this.ranges[target + 1];
/* 167 */           baseend = this.ranges[base + 1];
/* 168 */           target += 2; continue;
/*     */         } 
/* 170 */         throw new RuntimeException("Token#compactRanges(): Internel Error: [" + this.ranges[base] + "," + this.ranges[base + 1] + "] [" + this.ranges[target] + "," + this.ranges[target + 1] + "]");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       base += 2;
/*     */     } 
/*     */     
/* 180 */     if (base != this.ranges.length) {
/* 181 */       int[] result = new int[base];
/* 182 */       System.arraycopy(this.ranges, 0, result, 0, base);
/* 183 */       this.ranges = result;
/*     */     } 
/* 185 */     setCompacted();
/*     */   }
/*     */   
/*     */   protected void mergeRanges(Token token) {
/* 189 */     RangeToken tok = (RangeToken)token;
/* 190 */     sortRanges();
/* 191 */     tok.sortRanges();
/* 192 */     if (tok.ranges == null)
/*     */       return; 
/* 194 */     this.icaseCache = null;
/* 195 */     setSorted(true);
/* 196 */     if (this.ranges == null) {
/* 197 */       this.ranges = new int[tok.ranges.length];
/* 198 */       System.arraycopy(tok.ranges, 0, this.ranges, 0, tok.ranges.length);
/*     */       return;
/*     */     } 
/* 201 */     int[] result = new int[this.ranges.length + tok.ranges.length];
/* 202 */     for (int i = 0, j = 0, k = 0; i < this.ranges.length || j < tok.ranges.length; ) {
/* 203 */       if (i >= this.ranges.length) {
/* 204 */         result[k++] = tok.ranges[j++];
/* 205 */         result[k++] = tok.ranges[j++]; continue;
/* 206 */       }  if (j >= tok.ranges.length) {
/* 207 */         result[k++] = this.ranges[i++];
/* 208 */         result[k++] = this.ranges[i++]; continue;
/* 209 */       }  if (tok.ranges[j] < this.ranges[i] || (tok.ranges[j] == this.ranges[i] && tok.ranges[j + 1] < this.ranges[i + 1])) {
/*     */         
/* 211 */         result[k++] = tok.ranges[j++];
/* 212 */         result[k++] = tok.ranges[j++]; continue;
/*     */       } 
/* 214 */       result[k++] = this.ranges[i++];
/* 215 */       result[k++] = this.ranges[i++];
/*     */     } 
/*     */     
/* 218 */     this.ranges = result;
/*     */   }
/*     */   
/*     */   protected void subtractRanges(Token token) {
/* 222 */     if (token.type == 5) {
/* 223 */       intersectRanges(token);
/*     */       return;
/*     */     } 
/* 226 */     RangeToken tok = (RangeToken)token;
/* 227 */     if (tok.ranges == null || this.ranges == null)
/*     */       return; 
/* 229 */     this.icaseCache = null;
/* 230 */     sortRanges();
/* 231 */     compactRanges();
/* 232 */     tok.sortRanges();
/* 233 */     tok.compactRanges();
/*     */ 
/*     */ 
/*     */     
/* 237 */     int[] result = new int[this.ranges.length + tok.ranges.length];
/* 238 */     int wp = 0, src = 0, sub = 0;
/* 239 */     while (src < this.ranges.length && sub < tok.ranges.length) {
/* 240 */       int srcbegin = this.ranges[src];
/* 241 */       int srcend = this.ranges[src + 1];
/* 242 */       int subbegin = tok.ranges[sub];
/* 243 */       int subend = tok.ranges[sub + 1];
/* 244 */       if (srcend < subbegin) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 249 */         result[wp++] = this.ranges[src++];
/* 250 */         result[wp++] = this.ranges[src++]; continue;
/* 251 */       }  if (srcend >= subbegin && srcbegin <= subend) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 258 */         if (subbegin <= srcbegin && srcend <= subend) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 263 */           src += 2; continue;
/* 264 */         }  if (subbegin <= srcbegin) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 269 */           this.ranges[src] = subend + 1;
/* 270 */           sub += 2; continue;
/* 271 */         }  if (srcend <= subend) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 276 */           result[wp++] = srcbegin;
/* 277 */           result[wp++] = subbegin - 1;
/* 278 */           src += 2;
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 284 */         result[wp++] = srcbegin;
/* 285 */         result[wp++] = subbegin - 1;
/* 286 */         this.ranges[src] = subend + 1;
/* 287 */         sub += 2; continue;
/*     */       } 
/* 289 */       if (subend < srcbegin) {
/*     */ 
/*     */ 
/*     */         
/* 293 */         sub += 2; continue;
/*     */       } 
/* 295 */       throw new RuntimeException("Token#subtractRanges(): Internal Error: [" + this.ranges[src] + "," + this.ranges[src + 1] + "] - [" + tok.ranges[sub] + "," + tok.ranges[sub + 1] + "]");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 302 */     while (src < this.ranges.length) {
/* 303 */       result[wp++] = this.ranges[src++];
/* 304 */       result[wp++] = this.ranges[src++];
/*     */     } 
/* 306 */     this.ranges = new int[wp];
/* 307 */     System.arraycopy(result, 0, this.ranges, 0, wp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void intersectRanges(Token token) {
/* 315 */     RangeToken tok = (RangeToken)token;
/* 316 */     if (tok.ranges == null || this.ranges == null)
/*     */       return; 
/* 318 */     this.icaseCache = null;
/* 319 */     sortRanges();
/* 320 */     compactRanges();
/* 321 */     tok.sortRanges();
/* 322 */     tok.compactRanges();
/*     */     
/* 324 */     int[] result = new int[this.ranges.length + tok.ranges.length];
/* 325 */     int wp = 0, src1 = 0, src2 = 0;
/* 326 */     while (src1 < this.ranges.length && src2 < tok.ranges.length) {
/* 327 */       int src1begin = this.ranges[src1];
/* 328 */       int src1end = this.ranges[src1 + 1];
/* 329 */       int src2begin = tok.ranges[src2];
/* 330 */       int src2end = tok.ranges[src2 + 1];
/* 331 */       if (src1end < src2begin) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 336 */         src1 += 2; continue;
/* 337 */       }  if (src1end >= src2begin && src1begin <= src2end) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 344 */         if (src2begin <= src2begin && src1end <= src2end) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 349 */           result[wp++] = src1begin;
/* 350 */           result[wp++] = src1end;
/* 351 */           src1 += 2; continue;
/* 352 */         }  if (src2begin <= src1begin) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 357 */           result[wp++] = src1begin;
/* 358 */           result[wp++] = src2end;
/* 359 */           this.ranges[src1] = src2end + 1;
/* 360 */           src2 += 2; continue;
/* 361 */         }  if (src1end <= src2end) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 366 */           result[wp++] = src2begin;
/* 367 */           result[wp++] = src1end;
/* 368 */           src1 += 2;
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 374 */         result[wp++] = src2begin;
/* 375 */         result[wp++] = src2end;
/* 376 */         this.ranges[src1] = src2end + 1; continue;
/*     */       } 
/* 378 */       if (src2end < src1begin) {
/*     */ 
/*     */ 
/*     */         
/* 382 */         src2 += 2; continue;
/*     */       } 
/* 384 */       throw new RuntimeException("Token#intersectRanges(): Internal Error: [" + this.ranges[src1] + "," + this.ranges[src1 + 1] + "] & [" + tok.ranges[src2] + "," + tok.ranges[src2 + 1] + "]");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 392 */     while (src1 < this.ranges.length) {
/* 393 */       result[wp++] = this.ranges[src1++];
/* 394 */       result[wp++] = this.ranges[src1++];
/*     */     } 
/* 396 */     this.ranges = new int[wp];
/* 397 */     System.arraycopy(result, 0, this.ranges, 0, wp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Token complementRanges(Token token) {
/* 406 */     if (token.type != 4 && token.type != 5)
/* 407 */       throw new IllegalArgumentException("Token#complementRanges(): must be RANGE: " + token.type); 
/* 408 */     RangeToken tok = (RangeToken)token;
/* 409 */     tok.sortRanges();
/* 410 */     tok.compactRanges();
/* 411 */     int len = tok.ranges.length + 2;
/* 412 */     if (tok.ranges[0] == 0)
/* 413 */       len -= 2; 
/* 414 */     int last = tok.ranges[tok.ranges.length - 1];
/* 415 */     if (last == 1114111)
/* 416 */       len -= 2; 
/* 417 */     RangeToken ret = Token.createRange();
/* 418 */     ret.ranges = new int[len];
/* 419 */     int wp = 0;
/* 420 */     if (tok.ranges[0] > 0) {
/* 421 */       ret.ranges[wp++] = 0;
/* 422 */       ret.ranges[wp++] = tok.ranges[0] - 1;
/*     */     } 
/* 424 */     for (int i = 1; i < tok.ranges.length - 2; i += 2) {
/* 425 */       ret.ranges[wp++] = tok.ranges[i] + 1;
/* 426 */       ret.ranges[wp++] = tok.ranges[i + 1] - 1;
/*     */     } 
/* 428 */     if (last != 1114111) {
/* 429 */       ret.ranges[wp++] = last + 1;
/* 430 */       ret.ranges[wp] = 1114111;
/*     */     } 
/* 432 */     ret.setCompacted();
/* 433 */     return ret;
/*     */   }
/*     */   
/*     */   synchronized RangeToken getCaseInsensitiveToken() {
/* 437 */     if (this.icaseCache != null) {
/* 438 */       return this.icaseCache;
/*     */     }
/* 440 */     RangeToken uppers = (this.type == 4) ? Token.createRange() : Token.createNRange();
/* 441 */     for (int i = 0; i < this.ranges.length; i += 2) {
/* 442 */       for (int ch = this.ranges[i]; ch <= this.ranges[i + 1]; ch++) {
/* 443 */         if (ch > 65535) {
/* 444 */           uppers.addRange(ch, ch);
/*     */         } else {
/* 446 */           char uch = Character.toUpperCase((char)ch);
/* 447 */           uppers.addRange(uch, uch);
/*     */         } 
/*     */       } 
/*     */     } 
/* 451 */     RangeToken lowers = (this.type == 4) ? Token.createRange() : Token.createNRange();
/* 452 */     for (int j = 0; j < uppers.ranges.length; j += 2) {
/* 453 */       for (int ch = uppers.ranges[j]; ch <= uppers.ranges[j + 1]; ch++) {
/* 454 */         if (ch > 65535) {
/* 455 */           lowers.addRange(ch, ch);
/*     */         } else {
/* 457 */           char uch = Character.toUpperCase((char)ch);
/* 458 */           lowers.addRange(uch, uch);
/*     */         } 
/*     */       } 
/*     */     } 
/* 462 */     lowers.mergeRanges(uppers);
/* 463 */     lowers.mergeRanges(this);
/* 464 */     lowers.compactRanges();
/*     */     
/* 466 */     this.icaseCache = lowers;
/* 467 */     return lowers;
/*     */   }
/*     */   
/*     */   void dumpRanges() {
/* 471 */     System.err.print("RANGE: ");
/* 472 */     if (this.ranges == null)
/* 473 */       System.err.println(" NULL"); 
/* 474 */     for (int i = 0; i < this.ranges.length; i += 2) {
/* 475 */       System.err.print("[" + this.ranges[i] + "," + this.ranges[i + 1] + "] ");
/*     */     }
/* 477 */     System.err.println("");
/*     */   }
/*     */   boolean match(int ch) {
/*     */     boolean ret;
/* 481 */     if (this.map == null) createMap();
/*     */     
/* 483 */     if (this.type == 4) {
/* 484 */       if (ch < 256)
/* 485 */         return ((this.map[ch / 32] & 1 << (ch & 0x1F)) != 0); 
/* 486 */       ret = false;
/* 487 */       for (int i = this.nonMapIndex; i < this.ranges.length; i += 2) {
/* 488 */         if (this.ranges[i] <= ch && ch <= this.ranges[i + 1])
/* 489 */           return true; 
/*     */       } 
/*     */     } else {
/* 492 */       if (ch < 256)
/* 493 */         return ((this.map[ch / 32] & 1 << (ch & 0x1F)) == 0); 
/* 494 */       ret = true;
/* 495 */       for (int i = this.nonMapIndex; i < this.ranges.length; i += 2) {
/* 496 */         if (this.ranges[i] <= ch && ch <= this.ranges[i + 1])
/* 497 */           return false; 
/*     */       } 
/*     */     } 
/* 500 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private void createMap() {
/* 505 */     int asize = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 511 */     int[] localmap = new int[asize];
/* 512 */     int localnonMapIndex = this.ranges.length; int i;
/* 513 */     for (i = 0; i < asize; ) { localmap[i] = 0; i++; }
/* 514 */      for (i = 0; i < this.ranges.length; i += 2) {
/* 515 */       int s = this.ranges[i];
/* 516 */       int e = this.ranges[i + 1];
/* 517 */       if (s < 256) {
/* 518 */         for (int j = s; j <= e && j < 256; j++)
/* 519 */           localmap[j / 32] = localmap[j / 32] | 1 << (j & 0x1F); 
/*     */       } else {
/* 521 */         localnonMapIndex = i;
/*     */         break;
/*     */       } 
/* 524 */       if (e >= 256) {
/* 525 */         localnonMapIndex = i;
/*     */         break;
/*     */       } 
/*     */     } 
/* 529 */     this.nonMapIndex = localnonMapIndex;
/* 530 */     this.map = localmap;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(int options) {
/*     */     String ret;
/* 536 */     if (this.type == 4) {
/* 537 */       if (this == Token.token_dot) {
/* 538 */         ret = ".";
/* 539 */       } else if (this == Token.token_0to9) {
/* 540 */         ret = "\\d";
/* 541 */       } else if (this == Token.token_wordchars) {
/* 542 */         ret = "\\w";
/* 543 */       } else if (this == Token.token_spaces) {
/* 544 */         ret = "\\s";
/*     */       } else {
/* 546 */         StringBuffer sb = new StringBuffer();
/* 547 */         sb.append("[");
/* 548 */         for (int i = 0; i < this.ranges.length; i += 2) {
/* 549 */           if ((options & 0x400) != 0 && i > 0) sb.append(","); 
/* 550 */           if (this.ranges[i] == this.ranges[i + 1]) {
/* 551 */             sb.append(escapeCharInCharClass(this.ranges[i]));
/*     */           } else {
/* 553 */             sb.append(escapeCharInCharClass(this.ranges[i]));
/* 554 */             sb.append('-');
/* 555 */             sb.append(escapeCharInCharClass(this.ranges[i + 1]));
/*     */           } 
/*     */         } 
/* 558 */         sb.append("]");
/* 559 */         ret = sb.toString();
/*     */       }
/*     */     
/* 562 */     } else if (this == Token.token_not_0to9) {
/* 563 */       ret = "\\D";
/* 564 */     } else if (this == Token.token_not_wordchars) {
/* 565 */       ret = "\\W";
/* 566 */     } else if (this == Token.token_not_spaces) {
/* 567 */       ret = "\\S";
/*     */     } else {
/* 569 */       StringBuffer sb = new StringBuffer();
/* 570 */       sb.append("[^");
/* 571 */       for (int i = 0; i < this.ranges.length; i += 2) {
/* 572 */         if ((options & 0x400) != 0 && i > 0) sb.append(","); 
/* 573 */         if (this.ranges[i] == this.ranges[i + 1]) {
/* 574 */           sb.append(escapeCharInCharClass(this.ranges[i]));
/*     */         } else {
/* 576 */           sb.append(escapeCharInCharClass(this.ranges[i]));
/* 577 */           sb.append('-');
/* 578 */           sb.append(escapeCharInCharClass(this.ranges[i + 1]));
/*     */         } 
/*     */       } 
/* 581 */       sb.append("]");
/* 582 */       ret = sb.toString();
/*     */     } 
/*     */     
/* 585 */     return ret;
/*     */   }
/*     */   
/*     */   private static String escapeCharInCharClass(int ch) {
/*     */     String ret;
/* 590 */     switch (ch) { case 44: case 45: case 91: case 92:
/*     */       case 93:
/*     */       case 94:
/* 593 */         ret = "\\" + (char)ch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 611 */         return ret;case 12: ret = "\\f"; return ret;case 10: ret = "\\n"; return ret;case 13: ret = "\\r"; return ret;case 9: ret = "\\t"; return ret;case 27: ret = "\\e"; return ret; }  if (ch < 32) { String pre = "0" + Integer.toHexString(ch); ret = "\\x" + pre.substring(pre.length() - 2, pre.length()); } else if (ch >= 65536) { String pre = "0" + Integer.toHexString(ch); ret = "\\v" + pre.substring(pre.length() - 6, pre.length()); } else { ret = "" + (char)ch; }  return ret;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\RangeToken.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */