/*    */ package org.apache.xmlbeans.impl.regex;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.xmlbeans.impl.common.XMLChar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchemaRegularExpression
/*    */   extends RegularExpression
/*    */ {
/*    */   private SchemaRegularExpression(String pattern) {
/* 27 */     super(pattern, "X");
/*    */   }
/*    */ 
/*    */   
/*    */   public static RegularExpression forPattern(String s) {
/* 32 */     SchemaRegularExpression tre = (SchemaRegularExpression)knownPatterns.get(s);
/* 33 */     if (tre != null)
/* 34 */       return tre; 
/* 35 */     return new RegularExpression(s, "X");
/*    */   }
/*    */   
/* 38 */   static final Map knownPatterns = buildKnownPatternMap();
/*    */ 
/*    */   
/*    */   private static Map buildKnownPatternMap() {
/* 42 */     Map result = new HashMap();
/* 43 */     result.put("\\c+", new SchemaRegularExpression("\\c+") {
/* 44 */           public boolean matches(String s) { return XMLChar.isValidNmtoken(s); } });
/* 45 */     result.put("\\i\\c*", new SchemaRegularExpression("\\i\\c*") {
/* 46 */           public boolean matches(String s) { return XMLChar.isValidName(s); } });
/* 47 */     result.put("[\\i-[:]][\\c-[:]]*", new SchemaRegularExpression("[\\i-[:]][\\c-[:]]*") {
/* 48 */           public boolean matches(String s) { return XMLChar.isValidNCName(s); } });
/* 49 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\SchemaRegularExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */