/*     */ package org.apache.xmlbeans.impl.regex;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Op
/*     */ {
/*     */   static final int DOT = 0;
/*     */   static final int CHAR = 1;
/*     */   static final int RANGE = 3;
/*     */   static final int NRANGE = 4;
/*     */   static final int ANCHOR = 5;
/*     */   static final int STRING = 6;
/*     */   static final int CLOSURE = 7;
/*     */   static final int NONGREEDYCLOSURE = 8;
/*     */   static final int QUESTION = 9;
/*     */   static final int NONGREEDYQUESTION = 10;
/*     */   static final int UNION = 11;
/*     */   static final int CAPTURE = 15;
/*     */   static final int BACKREFERENCE = 16;
/*     */   static final int LOOKAHEAD = 20;
/*     */   static final int NEGATIVELOOKAHEAD = 21;
/*     */   static final int LOOKBEHIND = 22;
/*     */   static final int NEGATIVELOOKBEHIND = 23;
/*     */   static final int INDEPENDENT = 24;
/*     */   static final int MODIFIER = 25;
/*     */   static final int CONDITION = 26;
/*  44 */   static int nofinstances = 0;
/*     */   static final boolean COUNT = false;
/*     */   int type;
/*     */   
/*     */   static Op createDot() {
/*  49 */     return new Op(0);
/*     */   }
/*     */   
/*     */   static CharOp createChar(int data) {
/*  53 */     return new CharOp(1, data);
/*     */   }
/*     */   
/*     */   static CharOp createAnchor(int data) {
/*  57 */     return new CharOp(5, data);
/*     */   }
/*     */   
/*     */   static CharOp createCapture(int number, Op next) {
/*  61 */     CharOp op = new CharOp(15, number);
/*  62 */     op.next = next;
/*  63 */     return op;
/*     */   }
/*     */ 
/*     */   
/*     */   static UnionOp createUnion(int size) {
/*  68 */     return new UnionOp(11, size);
/*     */   }
/*     */   
/*     */   static ChildOp createClosure(int id) {
/*  72 */     return new ModifierOp(7, id, -1);
/*     */   }
/*     */   
/*     */   static ChildOp createNonGreedyClosure() {
/*  76 */     return new ChildOp(8);
/*     */   }
/*     */   
/*     */   static ChildOp createQuestion(boolean nongreedy) {
/*  80 */     return new ChildOp(nongreedy ? 10 : 9);
/*     */   }
/*     */   
/*     */   static RangeOp createRange(Token tok) {
/*  84 */     return new RangeOp(3, tok);
/*     */   }
/*     */   
/*     */   static ChildOp createLook(int type, Op next, Op branch) {
/*  88 */     ChildOp op = new ChildOp(type);
/*  89 */     op.setChild(branch);
/*  90 */     op.next = next;
/*  91 */     return op;
/*     */   }
/*     */   
/*     */   static CharOp createBackReference(int refno) {
/*  95 */     return new CharOp(16, refno);
/*     */   }
/*     */   
/*     */   static StringOp createString(String literal) {
/*  99 */     return new StringOp(6, literal);
/*     */   }
/*     */   
/*     */   static ChildOp createIndependent(Op next, Op branch) {
/* 103 */     ChildOp op = new ChildOp(24);
/* 104 */     op.setChild(branch);
/* 105 */     op.next = next;
/* 106 */     return op;
/*     */   }
/*     */   
/*     */   static ModifierOp createModifier(Op next, Op branch, int add, int mask) {
/* 110 */     ModifierOp op = new ModifierOp(25, add, mask);
/* 111 */     op.setChild(branch);
/* 112 */     op.next = next;
/* 113 */     return op;
/*     */   }
/*     */   
/*     */   static ConditionOp createCondition(Op next, int ref, Op conditionflow, Op yesflow, Op noflow) {
/* 117 */     ConditionOp op = new ConditionOp(26, ref, conditionflow, yesflow, noflow);
/* 118 */     op.next = next;
/* 119 */     return op;
/*     */   }
/*     */ 
/*     */   
/* 123 */   Op next = null;
/*     */   
/*     */   protected Op(int type) {
/* 126 */     this.type = type;
/*     */   }
/*     */   
/*     */   int size() {
/* 130 */     return 0;
/*     */   }
/*     */   Op elementAt(int index) {
/* 133 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   Op getChild() {
/* 136 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   
/*     */   int getData() {
/* 140 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   int getData2() {
/* 143 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   RangeToken getToken() {
/* 146 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   String getString() {
/* 149 */     throw new RuntimeException("Internal Error: type=" + this.type);
/*     */   }
/*     */   
/*     */   static class CharOp extends Op {
/*     */     int charData;
/*     */     
/*     */     CharOp(int type, int data) {
/* 156 */       super(type);
/* 157 */       this.charData = data;
/*     */     }
/*     */     int getData() {
/* 160 */       return this.charData;
/*     */     }
/*     */   }
/*     */   
/*     */   static class UnionOp extends Op {
/*     */     Vector branches;
/*     */     
/*     */     UnionOp(int type, int size) {
/* 168 */       super(type);
/* 169 */       this.branches = new Vector(size);
/*     */     }
/*     */     void addElement(Op op) {
/* 172 */       this.branches.addElement(op);
/*     */     }
/*     */     int size() {
/* 175 */       return this.branches.size();
/*     */     }
/*     */     Op elementAt(int index) {
/* 178 */       return this.branches.elementAt(index);
/*     */     }
/*     */   }
/*     */   
/*     */   static class ChildOp extends Op {
/*     */     Op child;
/*     */     
/*     */     ChildOp(int type) {
/* 186 */       super(type);
/*     */     }
/*     */     void setChild(Op child) {
/* 189 */       this.child = child;
/*     */     }
/*     */     Op getChild() {
/* 192 */       return this.child;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ModifierOp extends ChildOp { int v1;
/*     */     int v2;
/*     */     
/*     */     ModifierOp(int type, int v1, int v2) {
/* 200 */       super(type);
/* 201 */       this.v1 = v1;
/* 202 */       this.v2 = v2;
/*     */     }
/*     */     int getData() {
/* 205 */       return this.v1;
/*     */     }
/*     */     int getData2() {
/* 208 */       return this.v2;
/*     */     } }
/*     */   
/*     */   static class RangeOp extends Op {
/*     */     Token tok;
/*     */     
/*     */     RangeOp(int type, Token tok) {
/* 215 */       super(type);
/* 216 */       this.tok = tok;
/*     */     }
/*     */     RangeToken getToken() {
/* 219 */       return (RangeToken)this.tok;
/*     */     }
/*     */   }
/*     */   
/*     */   static class StringOp extends Op { String string;
/*     */     
/*     */     StringOp(int type, String literal) {
/* 226 */       super(type);
/* 227 */       this.string = literal;
/*     */     }
/*     */     String getString() {
/* 230 */       return this.string;
/*     */     } }
/*     */   
/*     */   static class ConditionOp extends Op {
/*     */     int refNumber;
/*     */     Op condition;
/*     */     Op yes;
/*     */     Op no;
/*     */     
/*     */     ConditionOp(int type, int refno, Op conditionflow, Op yesflow, Op noflow) {
/* 240 */       super(type);
/* 241 */       this.refNumber = refno;
/* 242 */       this.condition = conditionflow;
/* 243 */       this.yes = yesflow;
/* 244 */       this.no = noflow;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\Op.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */