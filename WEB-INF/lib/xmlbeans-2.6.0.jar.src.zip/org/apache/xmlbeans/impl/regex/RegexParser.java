/*      */ package org.apache.xmlbeans.impl.regex;
/*      */ 
/*      */ import java.util.Locale;
/*      */ import java.util.MissingResourceException;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class RegexParser
/*      */ {
/*      */   static final int T_CHAR = 0;
/*      */   static final int T_EOF = 1;
/*      */   static final int T_OR = 2;
/*      */   static final int T_STAR = 3;
/*      */   static final int T_PLUS = 4;
/*      */   static final int T_QUESTION = 5;
/*      */   static final int T_LPAREN = 6;
/*      */   static final int T_RPAREN = 7;
/*      */   static final int T_DOT = 8;
/*      */   static final int T_LBRACKET = 9;
/*      */   static final int T_BACKSOLIDUS = 10;
/*      */   static final int T_CARET = 11;
/*      */   static final int T_DOLLAR = 12;
/*      */   static final int T_LPAREN2 = 13;
/*      */   static final int T_LOOKAHEAD = 14;
/*      */   static final int T_NEGATIVELOOKAHEAD = 15;
/*      */   static final int T_LOOKBEHIND = 16;
/*      */   static final int T_NEGATIVELOOKBEHIND = 17;
/*      */   static final int T_INDEPENDENT = 18;
/*      */   static final int T_SET_OPERATIONS = 19;
/*      */   static final int T_POSIX_CHARCLASS_START = 20;
/*      */   static final int T_COMMENT = 21;
/*      */   static final int T_MODIFIERS = 22;
/*      */   static final int T_CONDITION = 23;
/*      */   static final int T_XMLSCHEMA_CC_SUBTRACTION = 24;
/*      */   int offset;
/*      */   String regex;
/*      */   int regexlen;
/*      */   int options;
/*      */   ResourceBundle resources;
/*      */   int chardata;
/*      */   int nexttoken;
/*      */   protected static final int S_NORMAL = 0;
/*      */   protected static final int S_INBRACKETS = 1;
/*      */   protected static final int S_INXBRACKETS = 2;
/*      */   
/*      */   static class ReferencePosition
/*      */   {
/*      */     int refNumber;
/*      */     int position;
/*      */     
/*      */     ReferencePosition(int n, int pos) {
/*   57 */       this.refNumber = n;
/*   58 */       this.position = pos;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   72 */   int context = 0;
/*   73 */   int parennumber = 1;
/*      */   boolean hasBackReferences;
/*   75 */   Vector references = null;
/*      */   
/*      */   public RegexParser() {
/*   78 */     setLocale(Locale.getDefault());
/*      */   }
/*      */   public RegexParser(Locale locale) {
/*   81 */     setLocale(locale);
/*      */   }
/*      */   
/*      */   public void setLocale(Locale locale) {
/*      */     try {
/*   86 */       this.resources = ResourceBundle.getBundle("org.apache.xmlbeans.impl.regex.message", locale);
/*   87 */     } catch (MissingResourceException mre) {
/*   88 */       throw new RuntimeException("Installation Problem???  Couldn't load messages: " + mre.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final ParseException ex(String key, int loc) {
/*   94 */     return new ParseException(this.resources.getString(key), loc);
/*      */   }
/*      */   
/*      */   private final boolean isSet(int flag) {
/*   98 */     return ((this.options & flag) == flag);
/*      */   }
/*      */   
/*      */   synchronized Token parse(String regex, int options) throws ParseException {
/*  102 */     this.options = options;
/*  103 */     this.offset = 0;
/*  104 */     setContext(0);
/*  105 */     this.parennumber = 1;
/*  106 */     this.hasBackReferences = false;
/*  107 */     this.regex = regex;
/*  108 */     if (isSet(16))
/*  109 */       this.regex = REUtil.stripExtendedComment(this.regex); 
/*  110 */     this.regexlen = this.regex.length();
/*      */ 
/*      */     
/*  113 */     next();
/*  114 */     Token ret = parseRegex();
/*  115 */     if (this.offset != this.regexlen)
/*  116 */       throw ex("parser.parse.1", this.offset); 
/*  117 */     if (this.references != null) {
/*  118 */       for (int i = 0; i < this.references.size(); i++) {
/*  119 */         ReferencePosition position = this.references.elementAt(i);
/*  120 */         if (this.parennumber <= position.refNumber)
/*  121 */           throw ex("parser.parse.2", position.position); 
/*      */       } 
/*  123 */       this.references.removeAllElements();
/*      */     } 
/*  125 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setContext(int con) {
/*  136 */     this.context = con;
/*      */   }
/*      */   
/*      */   final int read() {
/*  140 */     return this.nexttoken;
/*      */   }
/*      */   final void next() {
/*      */     int ret;
/*  144 */     if (this.offset >= this.regexlen) {
/*  145 */       this.chardata = -1;
/*  146 */       this.nexttoken = 1;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  151 */     int ch = this.regex.charAt(this.offset++);
/*  152 */     this.chardata = ch;
/*      */     
/*  154 */     if (this.context == 1) {
/*      */       int i;
/*      */       
/*  157 */       switch (ch) {
/*      */         case 92:
/*  159 */           i = 10;
/*  160 */           if (this.offset >= this.regexlen)
/*  161 */             throw ex("parser.next.1", this.offset - 1); 
/*  162 */           this.chardata = this.regex.charAt(this.offset++);
/*      */           break;
/*      */         
/*      */         case 45:
/*  166 */           if (isSet(512) && this.offset < this.regexlen && this.regex.charAt(this.offset) == '[') {
/*      */             
/*  168 */             this.offset++;
/*  169 */             i = 24; break;
/*      */           } 
/*  171 */           i = 0;
/*      */           break;
/*      */         
/*      */         case 91:
/*  175 */           if (!isSet(512) && this.offset < this.regexlen && this.regex.charAt(this.offset) == ':') {
/*      */             
/*  177 */             this.offset++;
/*  178 */             i = 20;
/*      */             break;
/*      */           } 
/*      */         default:
/*  182 */           if (REUtil.isHighSurrogate(ch) && this.offset < this.regexlen) {
/*  183 */             int low = this.regex.charAt(this.offset);
/*  184 */             if (REUtil.isLowSurrogate(low)) {
/*  185 */               this.chardata = REUtil.composeFromSurrogates(ch, low);
/*  186 */               this.offset++;
/*      */             } 
/*      */           } 
/*  189 */           i = 0; break;
/*      */       } 
/*  191 */       this.nexttoken = i;
/*      */       
/*      */       return;
/*      */     } 
/*  195 */     switch (ch) { case 124:
/*  196 */         ret = 2; break;
/*  197 */       case 42: ret = 3; break;
/*  198 */       case 43: ret = 4; break;
/*  199 */       case 63: ret = 5; break;
/*  200 */       case 41: ret = 7; break;
/*  201 */       case 46: ret = 8; break;
/*  202 */       case 91: ret = 9; break;
/*  203 */       case 94: ret = 11; break;
/*  204 */       case 36: ret = 12; break;
/*      */       case 40:
/*  206 */         ret = 6;
/*  207 */         if (this.offset >= this.regexlen)
/*      */           break; 
/*  209 */         if (this.regex.charAt(this.offset) != '?')
/*      */           break; 
/*  211 */         if (++this.offset >= this.regexlen)
/*  212 */           throw ex("parser.next.2", this.offset - 1); 
/*  213 */         ch = this.regex.charAt(this.offset++);
/*  214 */         switch (ch) { case 58:
/*  215 */             ret = 13; break;
/*  216 */           case 61: ret = 14; break;
/*  217 */           case 33: ret = 15; break;
/*  218 */           case 91: ret = 19; break;
/*  219 */           case 62: ret = 18; break;
/*      */           case 60:
/*  221 */             if (this.offset >= this.regexlen)
/*  222 */               throw ex("parser.next.2", this.offset - 3); 
/*  223 */             ch = this.regex.charAt(this.offset++);
/*  224 */             if (ch == 61) {
/*  225 */               ret = 16; break;
/*  226 */             }  if (ch == 33) {
/*  227 */               ret = 17; break;
/*      */             } 
/*  229 */             throw ex("parser.next.3", this.offset - 3);
/*      */           
/*      */           case 35:
/*  232 */             while (this.offset < this.regexlen) {
/*  233 */               ch = this.regex.charAt(this.offset++);
/*  234 */               if (ch == 41)
/*      */                 break; 
/*  236 */             }  if (ch != 41)
/*  237 */               throw ex("parser.next.4", this.offset - 1); 
/*  238 */             ret = 21;
/*      */             break; }
/*      */         
/*  241 */         if (ch == 45 || (97 <= ch && ch <= 122) || (65 <= ch && ch <= 90)) {
/*  242 */           this.offset--;
/*  243 */           ret = 22; break;
/*      */         } 
/*  245 */         if (ch == 40) {
/*  246 */           ret = 23;
/*      */           break;
/*      */         } 
/*  249 */         throw ex("parser.next.2", this.offset - 2);
/*      */ 
/*      */ 
/*      */       
/*      */       case 92:
/*  254 */         ret = 10;
/*  255 */         if (this.offset >= this.regexlen)
/*  256 */           throw ex("parser.next.1", this.offset - 1); 
/*  257 */         this.chardata = this.regex.charAt(this.offset++);
/*      */         break;
/*      */       
/*      */       default:
/*  261 */         ret = 0; break; }
/*      */     
/*  263 */     this.nexttoken = ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token parseRegex() throws ParseException {
/*  276 */     Token tok = parseTerm();
/*  277 */     Token parent = null;
/*  278 */     while (read() == 2) {
/*  279 */       next();
/*  280 */       if (parent == null) {
/*  281 */         parent = Token.createUnion();
/*  282 */         parent.addChild(tok);
/*  283 */         tok = parent;
/*      */       } 
/*  285 */       tok.addChild(parseTerm());
/*      */     } 
/*  287 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token parseTerm() throws ParseException {
/*  294 */     int ch = read();
/*  295 */     if (ch == 2 || ch == 7 || ch == 1) {
/*  296 */       return Token.createEmpty();
/*      */     }
/*  298 */     Token tok = parseFactor();
/*  299 */     Token concat = null;
/*  300 */     while ((ch = read()) != 2 && ch != 7 && ch != 1) {
/*  301 */       if (concat == null) {
/*  302 */         concat = Token.createConcat();
/*  303 */         concat.addChild(tok);
/*  304 */         tok = concat;
/*      */       } 
/*  306 */       concat.addChild(parseFactor());
/*      */     } 
/*      */     
/*  309 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token processCaret() throws ParseException {
/*  316 */     next();
/*  317 */     return Token.token_linebeginning;
/*      */   }
/*      */   Token processDollar() throws ParseException {
/*  320 */     next();
/*  321 */     return Token.token_lineend;
/*      */   }
/*      */   Token processLookahead() throws ParseException {
/*  324 */     next();
/*  325 */     Token tok = Token.createLook(20, parseRegex());
/*  326 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  327 */     next();
/*  328 */     return tok;
/*      */   }
/*      */   Token processNegativelookahead() throws ParseException {
/*  331 */     next();
/*  332 */     Token tok = Token.createLook(21, parseRegex());
/*  333 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  334 */     next();
/*  335 */     return tok;
/*      */   }
/*      */   Token processLookbehind() throws ParseException {
/*  338 */     next();
/*  339 */     Token tok = Token.createLook(22, parseRegex());
/*  340 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  341 */     next();
/*  342 */     return tok;
/*      */   }
/*      */   Token processNegativelookbehind() throws ParseException {
/*  345 */     next();
/*  346 */     Token tok = Token.createLook(23, parseRegex());
/*  347 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  348 */     next();
/*  349 */     return tok;
/*      */   }
/*      */   Token processBacksolidus_A() throws ParseException {
/*  352 */     next();
/*  353 */     return Token.token_stringbeginning;
/*      */   }
/*      */   Token processBacksolidus_Z() throws ParseException {
/*  356 */     next();
/*  357 */     return Token.token_stringend2;
/*      */   }
/*      */   Token processBacksolidus_z() throws ParseException {
/*  360 */     next();
/*  361 */     return Token.token_stringend;
/*      */   }
/*      */   Token processBacksolidus_b() throws ParseException {
/*  364 */     next();
/*  365 */     return Token.token_wordedge;
/*      */   }
/*      */   Token processBacksolidus_B() throws ParseException {
/*  368 */     next();
/*  369 */     return Token.token_not_wordedge;
/*      */   }
/*      */   Token processBacksolidus_lt() throws ParseException {
/*  372 */     next();
/*  373 */     return Token.token_wordbeginning;
/*      */   }
/*      */   Token processBacksolidus_gt() throws ParseException {
/*  376 */     next();
/*  377 */     return Token.token_wordend;
/*      */   }
/*      */   Token processStar(Token tok) throws ParseException {
/*  380 */     next();
/*  381 */     if (read() == 5) {
/*  382 */       next();
/*  383 */       return Token.createNGClosure(tok);
/*      */     } 
/*  385 */     return Token.createClosure(tok);
/*      */   }
/*      */   
/*      */   Token processPlus(Token tok) throws ParseException {
/*  389 */     next();
/*  390 */     if (read() == 5) {
/*  391 */       next();
/*  392 */       return Token.createConcat(tok, Token.createNGClosure(tok));
/*      */     } 
/*  394 */     return Token.createConcat(tok, Token.createClosure(tok));
/*      */   }
/*      */   
/*      */   Token processQuestion(Token tok) throws ParseException {
/*  398 */     next();
/*  399 */     Token par = Token.createUnion();
/*  400 */     if (read() == 5) {
/*  401 */       next();
/*  402 */       par.addChild(Token.createEmpty());
/*  403 */       par.addChild(tok);
/*      */     } else {
/*  405 */       par.addChild(tok);
/*  406 */       par.addChild(Token.createEmpty());
/*      */     } 
/*  408 */     return par;
/*      */   }
/*      */   boolean checkQuestion(int off) {
/*  411 */     return (off < this.regexlen && this.regex.charAt(off) == '?');
/*      */   }
/*      */   Token processParen() throws ParseException {
/*  414 */     next();
/*  415 */     int p = this.parennumber++;
/*  416 */     Token tok = Token.createParen(parseRegex(), p);
/*  417 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  418 */     next();
/*  419 */     return tok;
/*      */   }
/*      */   Token processParen2() throws ParseException {
/*  422 */     next();
/*  423 */     Token tok = Token.createParen(parseRegex(), 0);
/*  424 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  425 */     next();
/*  426 */     return tok;
/*      */   }
/*      */   
/*      */   Token processCondition() throws ParseException {
/*  430 */     if (this.offset + 1 >= this.regexlen) throw ex("parser.factor.4", this.offset);
/*      */     
/*  432 */     int refno = -1;
/*  433 */     Token condition = null;
/*  434 */     int ch = this.regex.charAt(this.offset);
/*  435 */     if (49 <= ch && ch <= 57) {
/*  436 */       refno = ch - 48;
/*  437 */       this.hasBackReferences = true;
/*  438 */       if (this.references == null) this.references = new Vector(); 
/*  439 */       this.references.addElement(new ReferencePosition(refno, this.offset));
/*  440 */       this.offset++;
/*  441 */       if (this.regex.charAt(this.offset) != ')') throw ex("parser.factor.1", this.offset); 
/*  442 */       this.offset++;
/*      */     } else {
/*  444 */       if (ch == 63) this.offset--; 
/*  445 */       next();
/*  446 */       condition = parseFactor();
/*  447 */       switch (condition.type) {
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */           break;
/*      */         case 8:
/*  454 */           if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*      */           break;
/*      */         default:
/*  457 */           throw ex("parser.factor.5", this.offset);
/*      */       } 
/*      */     
/*      */     } 
/*  461 */     next();
/*  462 */     Token yesPattern = parseRegex();
/*  463 */     Token noPattern = null;
/*  464 */     if (yesPattern.type == 2) {
/*  465 */       if (yesPattern.size() != 2) throw ex("parser.factor.6", this.offset); 
/*  466 */       noPattern = yesPattern.getChild(1);
/*  467 */       yesPattern = yesPattern.getChild(0);
/*      */     } 
/*  469 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  470 */     next();
/*  471 */     return Token.createCondition(refno, condition, yesPattern, noPattern);
/*      */   }
/*      */   
/*      */   Token processModifiers() throws ParseException {
/*      */     Token tok;
/*  476 */     int add = 0, mask = 0, ch = -1;
/*  477 */     while (this.offset < this.regexlen) {
/*  478 */       ch = this.regex.charAt(this.offset);
/*  479 */       int v = REUtil.getOptionValue(ch);
/*  480 */       if (v == 0)
/*  481 */         break;  add |= v;
/*  482 */       this.offset++;
/*      */     } 
/*  484 */     if (this.offset >= this.regexlen) throw ex("parser.factor.2", this.offset - 1); 
/*  485 */     if (ch == 45) {
/*  486 */       this.offset++;
/*  487 */       while (this.offset < this.regexlen) {
/*  488 */         ch = this.regex.charAt(this.offset);
/*  489 */         int v = REUtil.getOptionValue(ch);
/*  490 */         if (v == 0)
/*  491 */           break;  mask |= v;
/*  492 */         this.offset++;
/*      */       } 
/*  494 */       if (this.offset >= this.regexlen) throw ex("parser.factor.2", this.offset - 1);
/*      */     
/*      */     } 
/*  497 */     if (ch == 58) {
/*  498 */       this.offset++;
/*  499 */       next();
/*  500 */       tok = Token.createModifierGroup(parseRegex(), add, mask);
/*  501 */       if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  502 */       next();
/*  503 */     } else if (ch == 41) {
/*  504 */       this.offset++;
/*  505 */       next();
/*  506 */       tok = Token.createModifierGroup(parseRegex(), add, mask);
/*      */     } else {
/*  508 */       throw ex("parser.factor.3", this.offset);
/*      */     } 
/*  510 */     return tok;
/*      */   }
/*      */   Token processIndependent() throws ParseException {
/*  513 */     next();
/*  514 */     Token tok = Token.createLook(24, parseRegex());
/*  515 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/*  516 */     next();
/*  517 */     return tok;
/*      */   }
/*      */   Token processBacksolidus_c() throws ParseException {
/*      */     int ch2;
/*  521 */     if (this.offset >= this.regexlen || ((ch2 = this.regex.charAt(this.offset++)) & 0xFFE0) != 64)
/*      */     {
/*  523 */       throw ex("parser.atom.1", this.offset - 1); } 
/*  524 */     next();
/*  525 */     return Token.createChar(ch2 - 64);
/*      */   }
/*      */   Token processBacksolidus_C() throws ParseException {
/*  528 */     throw ex("parser.process.1", this.offset);
/*      */   }
/*      */   Token processBacksolidus_i() throws ParseException {
/*  531 */     Token tok = Token.createChar(105);
/*  532 */     next();
/*  533 */     return tok;
/*      */   }
/*      */   Token processBacksolidus_I() throws ParseException {
/*  536 */     throw ex("parser.process.1", this.offset);
/*      */   }
/*      */   Token processBacksolidus_g() throws ParseException {
/*  539 */     next();
/*  540 */     return Token.getGraphemePattern();
/*      */   }
/*      */   Token processBacksolidus_X() throws ParseException {
/*  543 */     next();
/*  544 */     return Token.getCombiningCharacterSequence();
/*      */   }
/*      */   Token processBackreference() throws ParseException {
/*  547 */     int refnum = this.chardata - 48;
/*  548 */     Token tok = Token.createBackReference(refnum);
/*  549 */     this.hasBackReferences = true;
/*  550 */     if (this.references == null) this.references = new Vector(); 
/*  551 */     this.references.addElement(new ReferencePosition(refnum, this.offset - 2));
/*  552 */     next();
/*  553 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token parseFactor() throws ParseException {
/*  568 */     int ch = read();
/*      */     
/*  570 */     switch (ch) { case 11:
/*  571 */         return processCaret();
/*  572 */       case 12: return processDollar();
/*  573 */       case 14: return processLookahead();
/*  574 */       case 15: return processNegativelookahead();
/*  575 */       case 16: return processLookbehind();
/*  576 */       case 17: return processNegativelookbehind();
/*      */       
/*      */       case 21:
/*  579 */         next();
/*  580 */         return Token.createEmpty();
/*      */       
/*      */       case 10:
/*  583 */         switch (this.chardata) { case 65:
/*  584 */             return processBacksolidus_A();
/*  585 */           case 90: return processBacksolidus_Z();
/*  586 */           case 122: return processBacksolidus_z();
/*  587 */           case 98: return processBacksolidus_b();
/*  588 */           case 66: return processBacksolidus_B();
/*  589 */           case 60: return processBacksolidus_lt();
/*  590 */           case 62: return processBacksolidus_gt(); }
/*      */         
/*      */         break; }
/*      */     
/*  594 */     Token tok = parseAtom();
/*  595 */     ch = read();
/*  596 */     switch (ch) { case 3:
/*  597 */         return processStar(tok);
/*  598 */       case 4: return processPlus(tok);
/*  599 */       case 5: return processQuestion(tok);
/*      */       case 0:
/*  601 */         if (this.chardata == 123 && this.offset < this.regexlen) {
/*      */           
/*  603 */           int off = this.offset;
/*  604 */           int min = 0, max = -1;
/*      */           
/*  606 */           if ((ch = this.regex.charAt(off++)) >= 48 && ch <= 57) {
/*      */             
/*  608 */             min = ch - 48;
/*      */             
/*  610 */             while (off < this.regexlen && (ch = this.regex.charAt(off++)) >= 48 && ch <= 57) {
/*  611 */               min = min * 10 + ch - 48;
/*  612 */               if (min < 0) {
/*  613 */                 throw ex("parser.quantifier.5", this.offset);
/*      */               }
/*      */             } 
/*      */           } else {
/*  617 */             throw ex("parser.quantifier.1", this.offset);
/*      */           } 
/*      */           
/*  620 */           max = min;
/*  621 */           if (ch == 44) {
/*      */             
/*  623 */             if (off >= this.regexlen) {
/*  624 */               throw ex("parser.quantifier.3", this.offset);
/*      */             }
/*  626 */             if ((ch = this.regex.charAt(off++)) >= 48 && ch <= 57) {
/*      */               
/*  628 */               max = ch - 48;
/*      */ 
/*      */               
/*  631 */               while (off < this.regexlen && (ch = this.regex.charAt(off++)) >= 48 && ch <= 57) {
/*  632 */                 max = max * 10 + ch - 48;
/*  633 */                 if (max < 0) {
/*  634 */                   throw ex("parser.quantifier.5", this.offset);
/*      */                 }
/*      */               } 
/*  637 */               if (min > max) {
/*  638 */                 throw ex("parser.quantifier.4", this.offset);
/*      */               }
/*      */             } else {
/*  641 */               max = -1;
/*      */             } 
/*      */           } 
/*      */           
/*  645 */           if (ch != 125) {
/*  646 */             throw ex("parser.quantifier.2", this.offset);
/*      */           }
/*  648 */           if (checkQuestion(off)) {
/*  649 */             tok = Token.createNGClosure(tok);
/*  650 */             this.offset = off + 1;
/*      */           } else {
/*  652 */             tok = Token.createClosure(tok);
/*  653 */             this.offset = off;
/*      */           } 
/*      */           
/*  656 */           tok.setMin(min);
/*  657 */           tok.setMax(max);
/*      */           
/*  659 */           next();
/*      */         }  break; }
/*      */     
/*  662 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Token parseAtom() throws ParseException {
/*  672 */     int ch2, pstart, high, ch = read();
/*  673 */     Token tok = null;
/*  674 */     switch (ch) { case 6:
/*  675 */         return processParen();
/*  676 */       case 13: return processParen2();
/*  677 */       case 23: return processCondition();
/*  678 */       case 22: return processModifiers();
/*  679 */       case 18: return processIndependent();
/*      */       case 8:
/*  681 */         next();
/*  682 */         tok = Token.token_dot;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  758 */         return tok;case 9: return parseCharacterClass(true);case 19: return parseSetOperations();case 10: switch (this.chardata) { case 68: case 83: case 87: case 100: case 115: case 119: tok = getTokenForShorthand(this.chardata); next(); return tok;case 101: case 102: case 110: case 114: case 116: case 117: case 118: case 120: ch2 = decodeEscaped(); if (ch2 < 65536) { tok = Token.createChar(ch2); break; }  tok = Token.createString(REUtil.decomposeToSurrogates(ch2)); break;case 99: return processBacksolidus_c();case 67: return processBacksolidus_C();case 105: return processBacksolidus_i();case 73: return processBacksolidus_I();case 103: return processBacksolidus_g();case 88: return processBacksolidus_X();case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: return processBackreference();case 80: case 112: pstart = this.offset; tok = processBacksolidus_pP(this.chardata); if (tok == null) throw ex("parser.atom.5", pstart);  break;default: tok = Token.createChar(this.chardata); break; }  next(); return tok;case 0: if (this.chardata == 93 || this.chardata == 123 || this.chardata == 125) throw ex("parser.atom.4", this.offset - 1);  tok = Token.createChar(this.chardata); high = this.chardata; next(); if (REUtil.isHighSurrogate(high) && read() == 0 && REUtil.isLowSurrogate(this.chardata)) { char[] sur = new char[2]; sur[0] = (char)high; sur[1] = (char)this.chardata; tok = Token.createParen(Token.createString(new String(sur)), 0); next(); }  return tok; }
/*      */     
/*      */     throw ex("parser.atom.4", this.offset - 1);
/*      */   }
/*      */   protected RangeToken processBacksolidus_pP(int c) throws ParseException {
/*  763 */     next();
/*  764 */     if (read() != 0 || this.chardata != 123) {
/*  765 */       throw ex("parser.atom.2", this.offset - 1);
/*      */     }
/*      */     
/*  768 */     boolean positive = (c == 112);
/*  769 */     int namestart = this.offset;
/*  770 */     int nameend = this.regex.indexOf('}', namestart);
/*      */     
/*  772 */     if (nameend < 0) {
/*  773 */       throw ex("parser.atom.3", this.offset);
/*      */     }
/*  775 */     String pname = this.regex.substring(namestart, nameend);
/*  776 */     this.offset = nameend + 1;
/*      */     
/*  778 */     return Token.getRange(pname, positive, isSet(512));
/*      */   }
/*      */   
/*      */   int processCIinCharacterClass(RangeToken tok, int c) {
/*  782 */     return decodeEscaped();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RangeToken parseCharacterClass(boolean useNrange) throws ParseException {
/*      */     RangeToken tok;
/*  793 */     setContext(1);
/*  794 */     next();
/*  795 */     boolean nrange = false;
/*  796 */     RangeToken base = null;
/*      */     
/*  798 */     if (read() == 0 && this.chardata == 94) {
/*  799 */       nrange = true;
/*  800 */       next();
/*  801 */       if (useNrange) {
/*  802 */         tok = Token.createNRange();
/*      */       } else {
/*  804 */         base = Token.createRange();
/*  805 */         base.addRange(0, 1114111);
/*  806 */         tok = Token.createRange();
/*      */       } 
/*      */     } else {
/*  809 */       tok = Token.createRange();
/*      */     } 
/*      */     
/*  812 */     boolean firstloop = true; int type;
/*  813 */     while ((type = read()) != 1 && (
/*  814 */       type != 0 || this.chardata != 93 || firstloop)) {
/*      */       
/*  816 */       firstloop = false;
/*  817 */       int c = this.chardata;
/*  818 */       boolean end = false;
/*  819 */       if (type == 10) {
/*  820 */         int pstart; RangeToken tok2; switch (c) { case 68: case 83: case 87:
/*      */           case 100:
/*      */           case 115:
/*      */           case 119:
/*  824 */             tok.mergeRanges(getTokenForShorthand(c));
/*  825 */             end = true; break;
/*      */           case 67:
/*      */           case 73:
/*      */           case 99:
/*      */           case 105:
/*  830 */             c = processCIinCharacterClass(tok, c);
/*  831 */             if (c < 0) end = true;
/*      */             
/*      */             break;
/*      */           case 80:
/*      */           case 112:
/*  836 */             pstart = this.offset;
/*  837 */             tok2 = processBacksolidus_pP(c);
/*  838 */             if (tok2 == null) throw ex("parser.atom.5", pstart); 
/*  839 */             tok.mergeRanges(tok2);
/*  840 */             end = true;
/*      */             break;
/*      */           
/*      */           default:
/*  844 */             c = decodeEscaped();
/*      */             break; }
/*      */ 
/*      */       
/*  848 */       } else if (type == 20) {
/*  849 */         int nameend = this.regex.indexOf(':', this.offset);
/*  850 */         if (nameend < 0) throw ex("parser.cc.1", this.offset); 
/*  851 */         boolean positive = true;
/*  852 */         if (this.regex.charAt(this.offset) == '^') {
/*  853 */           this.offset++;
/*  854 */           positive = false;
/*      */         } 
/*  856 */         String name = this.regex.substring(this.offset, nameend);
/*  857 */         RangeToken range = Token.getRange(name, positive, isSet(512));
/*      */         
/*  859 */         if (range == null) throw ex("parser.cc.3", this.offset); 
/*  860 */         tok.mergeRanges(range);
/*  861 */         end = true;
/*  862 */         if (nameend + 1 >= this.regexlen || this.regex.charAt(nameend + 1) != ']')
/*  863 */           throw ex("parser.cc.1", nameend); 
/*  864 */         this.offset = nameend + 2;
/*      */       } 
/*  866 */       next();
/*  867 */       if (!end) {
/*  868 */         if (read() != 0 || this.chardata != 45) {
/*  869 */           tok.addRange(c, c);
/*      */         } else {
/*  871 */           next();
/*  872 */           if ((type = read()) == 1) throw ex("parser.cc.2", this.offset); 
/*  873 */           if (type == 0 && this.chardata == 93) {
/*  874 */             tok.addRange(c, c);
/*  875 */             tok.addRange(45, 45);
/*      */           } else {
/*  877 */             int rangeend = this.chardata;
/*  878 */             if (type == 10)
/*  879 */               rangeend = decodeEscaped(); 
/*  880 */             next();
/*  881 */             tok.addRange(c, rangeend);
/*      */           } 
/*      */         } 
/*      */       }
/*  885 */       if (isSet(1024) && read() == 0 && this.chardata == 44)
/*      */       {
/*  887 */         next(); } 
/*      */     } 
/*  889 */     if (read() == 1)
/*  890 */       throw ex("parser.cc.2", this.offset); 
/*  891 */     if (!useNrange && nrange) {
/*  892 */       base.subtractRanges(tok);
/*  893 */       tok = base;
/*      */     } 
/*  895 */     tok.sortRanges();
/*  896 */     tok.compactRanges();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  902 */     setContext(0);
/*  903 */     next();
/*      */     
/*  905 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RangeToken parseSetOperations() throws ParseException {
/*  912 */     RangeToken tok = parseCharacterClass(false);
/*      */     int type;
/*  914 */     while ((type = read()) != 7) {
/*  915 */       int ch = this.chardata;
/*  916 */       if ((type == 0 && (ch == 45 || ch == 38)) || type == 4) {
/*      */         
/*  918 */         next();
/*  919 */         if (read() != 9) throw ex("parser.ope.1", this.offset - 1); 
/*  920 */         RangeToken t2 = parseCharacterClass(false);
/*  921 */         if (type == 4) {
/*  922 */           tok.mergeRanges(t2); continue;
/*  923 */         }  if (ch == 45) {
/*  924 */           tok.subtractRanges(t2); continue;
/*  925 */         }  if (ch == 38) {
/*  926 */           tok.intersectRanges(t2); continue;
/*      */         } 
/*  928 */         throw new RuntimeException("ASSERT");
/*      */       } 
/*  930 */       throw ex("parser.ope.2", this.offset - 1);
/*      */     } 
/*      */     
/*  933 */     next();
/*  934 */     return tok;
/*      */   }
/*      */   
/*      */   Token getTokenForShorthand(int ch) {
/*      */     Token tok;
/*  939 */     switch (ch) {
/*      */       case 100:
/*  941 */         tok = isSet(32) ? Token.getRange("Nd", true) : Token.token_0to9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  968 */         return tok;case 68: tok = isSet(32) ? Token.getRange("Nd", false) : Token.token_not_0to9; return tok;case 119: tok = isSet(32) ? Token.getRange("IsWord", true) : Token.token_wordchars; return tok;case 87: tok = isSet(32) ? Token.getRange("IsWord", false) : Token.token_not_wordchars; return tok;case 115: tok = isSet(32) ? Token.getRange("IsSpace", true) : Token.token_spaces; return tok;case 83: tok = isSet(32) ? Token.getRange("IsSpace", false) : Token.token_not_spaces; return tok;
/*      */     } 
/*      */     throw new RuntimeException("Internal Error: shorthands: \\u" + Integer.toString(ch, 16));
/*      */   }
/*      */   int decodeEscaped() throws ParseException {
/*      */     int v1, uv;
/*  974 */     if (read() != 10) throw ex("parser.next.1", this.offset - 1); 
/*  975 */     int c = this.chardata;
/*  976 */     switch (c) { case 101:
/*  977 */         c = 27; break;
/*  978 */       case 102: c = 12; break;
/*  979 */       case 110: c = 10; break;
/*  980 */       case 114: c = 13; break;
/*  981 */       case 116: c = 9;
/*      */         break;
/*      */       case 120:
/*  984 */         next();
/*  985 */         if (read() != 0) throw ex("parser.descape.1", this.offset - 1); 
/*  986 */         if (this.chardata == 123) {
/*  987 */           int i = 0;
/*  988 */           int j = 0;
/*      */           while (true) {
/*  990 */             next();
/*  991 */             if (read() != 0) throw ex("parser.descape.1", this.offset - 1); 
/*  992 */             if ((i = hexChar(this.chardata)) < 0)
/*      */               break; 
/*  994 */             if (j > j * 16) throw ex("parser.descape.2", this.offset - 1); 
/*  995 */             j = j * 16 + i;
/*      */           } 
/*  997 */           if (this.chardata != 125) throw ex("parser.descape.3", this.offset - 1); 
/*  998 */           if (j > 1114111) throw ex("parser.descape.4", this.offset - 1); 
/*  999 */           c = j; break;
/*      */         } 
/* 1001 */         v1 = 0;
/* 1002 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1003 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1004 */         uv = v1;
/* 1005 */         next();
/* 1006 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1007 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1008 */         uv = uv * 16 + v1;
/* 1009 */         c = uv;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 117:
/* 1014 */         v1 = 0;
/* 1015 */         next();
/* 1016 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1017 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1018 */         uv = v1;
/* 1019 */         next();
/* 1020 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1021 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1022 */         uv = uv * 16 + v1;
/* 1023 */         next();
/* 1024 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1025 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1026 */         uv = uv * 16 + v1;
/* 1027 */         next();
/* 1028 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1029 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1030 */         uv = uv * 16 + v1;
/* 1031 */         c = uv;
/*      */         break;
/*      */       
/*      */       case 118:
/* 1035 */         next();
/* 1036 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1037 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1038 */         uv = v1;
/* 1039 */         next();
/* 1040 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1041 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1042 */         uv = uv * 16 + v1;
/* 1043 */         next();
/* 1044 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1045 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1046 */         uv = uv * 16 + v1;
/* 1047 */         next();
/* 1048 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1049 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1050 */         uv = uv * 16 + v1;
/* 1051 */         next();
/* 1052 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1053 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1054 */         uv = uv * 16 + v1;
/* 1055 */         next();
/* 1056 */         if (read() != 0 || (v1 = hexChar(this.chardata)) < 0)
/* 1057 */           throw ex("parser.descape.1", this.offset - 1); 
/* 1058 */         uv = uv * 16 + v1;
/* 1059 */         if (uv > 1114111) throw ex("parser.descappe.4", this.offset - 1); 
/* 1060 */         c = uv;
/*      */         break;
/*      */       case 65:
/*      */       case 90:
/*      */       case 122:
/* 1065 */         throw ex("parser.descape.5", this.offset - 2); }
/*      */ 
/*      */     
/* 1068 */     return c;
/*      */   }
/*      */   
/*      */   private static final int hexChar(int ch) {
/* 1072 */     if (ch < 48) return -1; 
/* 1073 */     if (ch > 102) return -1; 
/* 1074 */     if (ch <= 57) return ch - 48; 
/* 1075 */     if (ch < 65) return -1; 
/* 1076 */     if (ch <= 70) return ch - 65 + 10; 
/* 1077 */     if (ch < 97) return -1; 
/* 1078 */     return ch - 97 + 10;
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\RegexParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */