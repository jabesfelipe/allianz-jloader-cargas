/*     */ package org.apache.xmlbeans.impl.regex;
/*     */ 
/*     */ import java.text.CharacterIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class REUtil
/*     */ {
/*     */   static final int CACHESIZE = 20;
/*     */   
/*     */   static final int composeFromSurrogates(int high, int low) {
/*  25 */     return 65536 + (high - 55296 << 10) + low - 56320;
/*     */   }
/*     */   
/*     */   static final boolean isLowSurrogate(int ch) {
/*  29 */     return ((ch & 0xFC00) == 56320);
/*     */   }
/*     */   
/*     */   static final boolean isHighSurrogate(int ch) {
/*  33 */     return ((ch & 0xFC00) == 55296);
/*     */   }
/*     */   
/*     */   static final String decomposeToSurrogates(int ch) {
/*  37 */     char[] chs = new char[2];
/*  38 */     ch -= 65536;
/*  39 */     chs[0] = (char)((ch >> 10) + 55296);
/*  40 */     chs[1] = (char)((ch & 0x3FF) + 56320);
/*  41 */     return new String(chs);
/*     */   }
/*     */   
/*     */   static final String substring(CharacterIterator iterator, int begin, int end) {
/*  45 */     char[] src = new char[end - begin];
/*  46 */     for (int i = 0; i < src.length; i++)
/*  47 */       src[i] = iterator.setIndex(i + begin); 
/*  48 */     return new String(src);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final int getOptionValue(int ch) {
/*  54 */     int ret = 0;
/*  55 */     switch (ch) {
/*     */       case 105:
/*  57 */         ret = 2;
/*     */         break;
/*     */       case 109:
/*  60 */         ret = 8;
/*     */         break;
/*     */       case 115:
/*  63 */         ret = 4;
/*     */         break;
/*     */       case 120:
/*  66 */         ret = 16;
/*     */         break;
/*     */       case 117:
/*  69 */         ret = 32;
/*     */         break;
/*     */       case 119:
/*  72 */         ret = 64;
/*     */         break;
/*     */       case 70:
/*  75 */         ret = 256;
/*     */         break;
/*     */       case 72:
/*  78 */         ret = 128;
/*     */         break;
/*     */       case 88:
/*  81 */         ret = 512;
/*     */         break;
/*     */       case 44:
/*  84 */         ret = 1024;
/*     */         break;
/*     */     } 
/*     */     
/*  88 */     return ret;
/*     */   }
/*     */   
/*     */   static final int parseOptions(String opts) throws ParseException {
/*  92 */     if (opts == null) return 0; 
/*  93 */     int options = 0;
/*  94 */     for (int i = 0; i < opts.length(); i++) {
/*  95 */       int v = getOptionValue(opts.charAt(i));
/*  96 */       if (v == 0)
/*  97 */         throw new ParseException("Unknown Option: " + opts.substring(i), -1); 
/*  98 */       options |= v;
/*     */     } 
/* 100 */     return options;
/*     */   }
/*     */   
/*     */   static final String createOptionString(int options) {
/* 104 */     StringBuffer sb = new StringBuffer(9);
/* 105 */     if ((options & 0x100) != 0)
/* 106 */       sb.append('F'); 
/* 107 */     if ((options & 0x80) != 0)
/* 108 */       sb.append('H'); 
/* 109 */     if ((options & 0x200) != 0)
/* 110 */       sb.append('X'); 
/* 111 */     if ((options & 0x2) != 0)
/* 112 */       sb.append('i'); 
/* 113 */     if ((options & 0x8) != 0)
/* 114 */       sb.append('m'); 
/* 115 */     if ((options & 0x4) != 0)
/* 116 */       sb.append('s'); 
/* 117 */     if ((options & 0x20) != 0)
/* 118 */       sb.append('u'); 
/* 119 */     if ((options & 0x40) != 0)
/* 120 */       sb.append('w'); 
/* 121 */     if ((options & 0x10) != 0)
/* 122 */       sb.append('x'); 
/* 123 */     if ((options & 0x400) != 0)
/* 124 */       sb.append(','); 
/* 125 */     return sb.toString().intern();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String stripExtendedComment(String regex) {
/* 131 */     int len = regex.length();
/* 132 */     StringBuffer buffer = new StringBuffer(len);
/* 133 */     int offset = 0;
/* 134 */     while (offset < len) {
/* 135 */       int ch = regex.charAt(offset++);
/*     */       
/* 137 */       if (ch == 9 || ch == 10 || ch == 12 || ch == 13 || ch == 32) {
/*     */         continue;
/*     */       }
/* 140 */       if (ch == 35) {
/* 141 */         while (offset < len) {
/* 142 */           ch = regex.charAt(offset++);
/* 143 */           if (ch == 13 || ch == 10) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 150 */       if (ch == 92 && offset < len) {
/* 151 */         int next; if ((next = regex.charAt(offset)) == 35 || next == 9 || next == 10 || next == 12 || next == 13 || next == 32) {
/*     */ 
/*     */           
/* 154 */           buffer.append((char)next);
/* 155 */           offset++; continue;
/*     */         } 
/* 157 */         buffer.append('\\');
/* 158 */         buffer.append((char)next);
/* 159 */         offset++;
/*     */         continue;
/*     */       } 
/* 162 */       buffer.append((char)ch);
/*     */     } 
/* 164 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] argv) {
/* 174 */     String pattern = null;
/*     */     try {
/* 176 */       String options = "";
/* 177 */       String target = null;
/* 178 */       if (argv.length == 0) {
/* 179 */         System.out.println("Error:Usage: java REUtil -i|-m|-s|-u|-w|-X regularExpression String");
/* 180 */         System.exit(0);
/*     */       } 
/* 182 */       for (int i = 0; i < argv.length; i++) {
/* 183 */         if (argv[i].length() == 0 || argv[i].charAt(0) != '-') {
/* 184 */           if (pattern == null)
/* 185 */           { pattern = argv[i]; }
/* 186 */           else if (target == null)
/* 187 */           { target = argv[i]; }
/*     */           else
/* 189 */           { System.err.println("Unnecessary: " + argv[i]); } 
/* 190 */         } else if (argv[i].equals("-i")) {
/* 191 */           options = options + "i";
/* 192 */         } else if (argv[i].equals("-m")) {
/* 193 */           options = options + "m";
/* 194 */         } else if (argv[i].equals("-s")) {
/* 195 */           options = options + "s";
/* 196 */         } else if (argv[i].equals("-u")) {
/* 197 */           options = options + "u";
/* 198 */         } else if (argv[i].equals("-w")) {
/* 199 */           options = options + "w";
/* 200 */         } else if (argv[i].equals("-X")) {
/* 201 */           options = options + "X";
/*     */         } else {
/* 203 */           System.err.println("Unknown option: " + argv[i]);
/*     */         } 
/*     */       } 
/* 206 */       RegularExpression reg = new RegularExpression(pattern, options);
/* 207 */       System.out.println("RegularExpression: " + reg);
/* 208 */       Match match = new Match();
/* 209 */       reg.matches(target, match);
/* 210 */       for (int j = 0; j < match.getNumberOfGroups(); j++) {
/* 211 */         if (j == 0) { System.out.print("Matched range for the whole pattern: "); }
/* 212 */         else { System.out.print("[" + j + "]: "); }
/* 213 */          if (match.getBeginning(j) < 0) {
/* 214 */           System.out.println("-1");
/*     */         } else {
/* 216 */           System.out.print(match.getBeginning(j) + ", " + match.getEnd(j) + ", ");
/* 217 */           System.out.println("\"" + match.getCapturedText(j) + "\"");
/*     */         } 
/*     */       } 
/* 220 */     } catch (ParseException pe) {
/* 221 */       if (pattern == null) {
/* 222 */         pe.printStackTrace();
/*     */       } else {
/* 224 */         System.err.println("org.apache.xerces.utils.regex.ParseException: " + pe.getMessage());
/* 225 */         String indent = "        ";
/* 226 */         System.err.println(indent + pattern);
/* 227 */         int loc = pe.getLocation();
/* 228 */         if (loc >= 0) {
/* 229 */           System.err.print(indent);
/* 230 */           for (int i = 0; i < loc; ) { System.err.print("-"); i++; }
/* 231 */            System.err.println("^");
/*     */         } 
/*     */       } 
/* 234 */     } catch (Exception e) {
/* 235 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 240 */   static final RegularExpression[] regexCache = new RegularExpression[20];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RegularExpression createRegex(String pattern, String options) throws ParseException {
/* 249 */     RegularExpression re = null;
/* 250 */     int intOptions = parseOptions(options);
/* 251 */     synchronized (regexCache) {
/*     */       int i;
/* 253 */       for (i = 0; i < 20; i++) {
/* 254 */         RegularExpression cached = regexCache[i];
/* 255 */         if (cached == null) {
/* 256 */           i = -1;
/*     */           break;
/*     */         } 
/* 259 */         if (cached.equals(pattern, intOptions)) {
/* 260 */           re = cached;
/*     */           break;
/*     */         } 
/*     */       } 
/* 264 */       if (re != null) {
/* 265 */         if (i != 0) {
/* 266 */           System.arraycopy(regexCache, 0, regexCache, 1, i);
/* 267 */           regexCache[0] = re;
/*     */         } 
/*     */       } else {
/* 270 */         re = new RegularExpression(pattern, options);
/* 271 */         System.arraycopy(regexCache, 0, regexCache, 1, 19);
/* 272 */         regexCache[0] = re;
/*     */       } 
/*     */     } 
/* 275 */     return re;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean matches(String regex, String target) throws ParseException {
/* 283 */     return createRegex(regex, null).matches(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean matches(String regex, String options, String target) throws ParseException {
/* 291 */     return createRegex(regex, options).matches(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quoteMeta(String literal) {
/* 300 */     int len = literal.length();
/* 301 */     StringBuffer buffer = null;
/* 302 */     for (int i = 0; i < len; i++) {
/* 303 */       int ch = literal.charAt(i);
/* 304 */       if (".*+?{[()|\\^$".indexOf(ch) >= 0) {
/* 305 */         if (buffer == null) {
/* 306 */           buffer = new StringBuffer(i + (len - i) * 2);
/* 307 */           if (i > 0) buffer.append(literal.substring(0, i)); 
/*     */         } 
/* 309 */         buffer.append('\\');
/* 310 */         buffer.append((char)ch);
/* 311 */       } else if (buffer != null) {
/* 312 */         buffer.append((char)ch);
/*     */       } 
/* 314 */     }  return (buffer != null) ? buffer.toString() : literal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void dumpString(String v) {
/* 320 */     for (int i = 0; i < v.length(); i++) {
/* 321 */       System.out.print(Integer.toHexString(v.charAt(i)));
/* 322 */       System.out.print(" ");
/*     */     } 
/* 324 */     System.out.println();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\REUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */