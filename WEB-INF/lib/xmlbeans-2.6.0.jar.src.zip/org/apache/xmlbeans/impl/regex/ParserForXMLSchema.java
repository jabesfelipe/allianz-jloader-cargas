/*     */ package org.apache.xmlbeans.impl.regex;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParserForXMLSchema
/*     */   extends RegexParser
/*     */ {
/*     */   public ParserForXMLSchema() {}
/*     */   
/*     */   public ParserForXMLSchema(Locale locale) {}
/*     */   
/*     */   Token processCaret() throws ParseException {
/*  36 */     next();
/*  37 */     return Token.createChar(94);
/*     */   }
/*     */   Token processDollar() throws ParseException {
/*  40 */     next();
/*  41 */     return Token.createChar(36);
/*     */   }
/*     */   Token processLookahead() throws ParseException {
/*  44 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processNegativelookahead() throws ParseException {
/*  47 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processLookbehind() throws ParseException {
/*  50 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processNegativelookbehind() throws ParseException {
/*  53 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processBacksolidus_A() throws ParseException {
/*  56 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processBacksolidus_Z() throws ParseException {
/*  59 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processBacksolidus_z() throws ParseException {
/*  62 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processBacksolidus_b() throws ParseException {
/*  65 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processBacksolidus_B() throws ParseException {
/*  68 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processBacksolidus_lt() throws ParseException {
/*  71 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processBacksolidus_gt() throws ParseException {
/*  74 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processStar(Token tok) throws ParseException {
/*  77 */     next();
/*  78 */     return Token.createClosure(tok);
/*     */   }
/*     */   
/*     */   Token processPlus(Token tok) throws ParseException {
/*  82 */     next();
/*  83 */     return Token.createConcat(tok, Token.createClosure(tok));
/*     */   }
/*     */   
/*     */   Token processQuestion(Token tok) throws ParseException {
/*  87 */     next();
/*  88 */     Token par = Token.createUnion();
/*  89 */     par.addChild(tok);
/*  90 */     par.addChild(Token.createEmpty());
/*  91 */     return par;
/*     */   }
/*     */   boolean checkQuestion(int off) {
/*  94 */     return false;
/*     */   }
/*     */   Token processParen() throws ParseException {
/*  97 */     next();
/*  98 */     Token tok = Token.createParen(parseRegex(), 0);
/*  99 */     if (read() != 7) throw ex("parser.factor.1", this.offset - 1); 
/* 100 */     next();
/* 101 */     return tok;
/*     */   }
/*     */   Token processParen2() throws ParseException {
/* 104 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processCondition() throws ParseException {
/* 107 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processModifiers() throws ParseException {
/* 110 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processIndependent() throws ParseException {
/* 113 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   Token processBacksolidus_c() throws ParseException {
/* 116 */     next();
/* 117 */     return getTokenForShorthand(99);
/*     */   }
/*     */   Token processBacksolidus_C() throws ParseException {
/* 120 */     next();
/* 121 */     return getTokenForShorthand(67);
/*     */   }
/*     */   Token processBacksolidus_i() throws ParseException {
/* 124 */     next();
/* 125 */     return getTokenForShorthand(105);
/*     */   }
/*     */   Token processBacksolidus_I() throws ParseException {
/* 128 */     next();
/* 129 */     return getTokenForShorthand(73);
/*     */   }
/*     */   Token processBacksolidus_g() throws ParseException {
/* 132 */     throw ex("parser.process.1", this.offset - 2);
/*     */   }
/*     */   Token processBacksolidus_X() throws ParseException {
/* 135 */     throw ex("parser.process.1", this.offset - 2);
/*     */   }
/*     */   Token processBackreference() throws ParseException {
/* 138 */     throw ex("parser.process.1", this.offset - 4);
/*     */   }
/*     */   
/*     */   int processCIinCharacterClass(RangeToken tok, int c) {
/* 142 */     tok.mergeRanges(getTokenForShorthand(c));
/* 143 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RangeToken parseCharacterClass(boolean useNrange) throws ParseException {
/*     */     RangeToken tok;
/* 165 */     setContext(1);
/* 166 */     next();
/* 167 */     boolean nrange = false;
/* 168 */     RangeToken base = null;
/*     */     
/* 170 */     if (read() == 0 && this.chardata == 94) {
/* 171 */       nrange = true;
/* 172 */       next();
/* 173 */       base = Token.createRange();
/* 174 */       base.addRange(0, 1114111);
/* 175 */       tok = Token.createRange();
/*     */     } else {
/* 177 */       tok = Token.createRange();
/*     */     } 
/*     */     
/* 180 */     boolean firstloop = true; int type;
/* 181 */     while ((type = read()) != 1) {
/*     */       
/* 183 */       if (type == 0 && this.chardata == 93 && !firstloop) {
/* 184 */         if (nrange) {
/* 185 */           base.subtractRanges(tok);
/* 186 */           tok = base;
/*     */         } 
/*     */         break;
/*     */       } 
/* 190 */       int c = this.chardata;
/* 191 */       boolean end = false;
/* 192 */       if (type == 10) {
/* 193 */         int pstart; RangeToken tok2; switch (c) { case 68: case 83: case 87:
/*     */           case 100:
/*     */           case 115:
/*     */           case 119:
/* 197 */             tok.mergeRanges(getTokenForShorthand(c));
/* 198 */             end = true; break;
/*     */           case 67:
/*     */           case 73:
/*     */           case 99:
/*     */           case 105:
/* 203 */             c = processCIinCharacterClass(tok, c);
/* 204 */             if (c < 0) end = true;
/*     */             
/*     */             break;
/*     */           case 80:
/*     */           case 112:
/* 209 */             pstart = this.offset;
/* 210 */             tok2 = processBacksolidus_pP(c);
/* 211 */             if (tok2 == null) throw ex("parser.atom.5", pstart); 
/* 212 */             tok.mergeRanges(tok2);
/* 213 */             end = true;
/*     */             break;
/*     */           
/*     */           default:
/* 217 */             c = decodeEscaped();
/*     */             break; }
/*     */       
/* 220 */       } else if (type == 24 && !firstloop) {
/*     */         
/* 222 */         if (nrange) {
/* 223 */           base.subtractRanges(tok);
/* 224 */           tok = base;
/*     */         } 
/* 226 */         RangeToken range2 = parseCharacterClass(false);
/* 227 */         tok.subtractRanges(range2);
/* 228 */         if (read() != 0 || this.chardata != 93)
/* 229 */           throw ex("parser.cc.5", this.offset); 
/*     */         break;
/*     */       } 
/* 232 */       next();
/* 233 */       if (!end) {
/* 234 */         if (type == 0) {
/* 235 */           if (c == 91) throw ex("parser.cc.6", this.offset - 2); 
/* 236 */           if (c == 93) throw ex("parser.cc.7", this.offset - 2);
/*     */ 
/*     */           
/* 239 */           if (c == 45 && !firstloop && this.chardata != 93) throw ex("parser.cc.8", this.offset - 2); 
/*     */         } 
/* 241 */         if (read() != 0 || this.chardata != 45) {
/* 242 */           tok.addRange(c, c);
/*     */         } else {
/*     */           
/* 245 */           next();
/* 246 */           if ((type = read()) == 1) throw ex("parser.cc.2", this.offset);
/*     */           
/* 248 */           if (type == 24)
/* 249 */             throw ex("parser.cc.8", this.offset - 1); 
/* 250 */           if (type == 0 && this.chardata == 93) {
/*     */             
/* 252 */             tok.addRange(c, c);
/* 253 */             tok.addRange(45, 45);
/*     */           } else {
/* 255 */             int rangeend = this.chardata;
/* 256 */             if (type == 0) {
/* 257 */               if (rangeend == 91) throw ex("parser.cc.6", this.offset - 1); 
/* 258 */               if (rangeend == 93) throw ex("parser.cc.7", this.offset - 1); 
/* 259 */               if (rangeend == 45) {
/* 260 */                 next();
/* 261 */                 if (this.chardata != 93) {
/* 262 */                   throw ex("parser.cc.8", this.offset - 2);
/*     */                 }
/*     */               } 
/* 265 */             } else if (type == 10) {
/* 266 */               rangeend = decodeEscaped();
/* 267 */             }  if (rangeend != 45 || this.chardata != 93) {
/* 268 */               next();
/*     */             }
/* 270 */             if (c > rangeend) throw ex("parser.ope.3", this.offset - 1); 
/* 271 */             tok.addRange(c, rangeend);
/*     */           } 
/*     */         } 
/*     */       } 
/* 275 */       firstloop = false;
/*     */     } 
/* 277 */     if (read() == 1)
/* 278 */       throw ex("parser.cc.2", this.offset); 
/* 279 */     tok.sortRanges();
/* 280 */     tok.compactRanges();
/*     */     
/* 282 */     setContext(0);
/* 283 */     next();
/*     */     
/* 285 */     return tok;
/*     */   }
/*     */   
/*     */   protected RangeToken parseSetOperations() throws ParseException {
/* 289 */     throw ex("parser.process.1", this.offset);
/*     */   }
/*     */   
/*     */   Token getTokenForShorthand(int ch) {
/* 293 */     switch (ch) {
/*     */       case 100:
/* 295 */         return getRange("xml:isDigit", true);
/*     */       case 68:
/* 297 */         return getRange("xml:isDigit", false);
/*     */       case 119:
/* 299 */         return getRange("xml:isWord", true);
/*     */       case 87:
/* 301 */         return getRange("xml:isWord", false);
/*     */       case 115:
/* 303 */         return getRange("xml:isSpace", true);
/*     */       case 83:
/* 305 */         return getRange("xml:isSpace", false);
/*     */       case 99:
/* 307 */         return getRange("xml:isNameChar", true);
/*     */       case 67:
/* 309 */         return getRange("xml:isNameChar", false);
/*     */       case 105:
/* 311 */         return getRange("xml:isInitialNameChar", true);
/*     */       case 73:
/* 313 */         return getRange("xml:isInitialNameChar", false);
/*     */     } 
/* 315 */     throw new RuntimeException("Internal Error: shorthands: \\u" + Integer.toString(ch, 16));
/*     */   }
/*     */   
/*     */   int decodeEscaped() throws ParseException {
/* 319 */     if (read() != 10) throw ex("parser.next.1", this.offset - 1); 
/* 320 */     int c = this.chardata;
/* 321 */     switch (c) { case 110:
/* 322 */         c = 10;
/* 323 */       case 114: c = 13;
/* 324 */       case 116: c = 9;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 40:
/*     */       case 41:
/*     */       case 42:
/*     */       case 43:
/*     */       case 45:
/*     */       case 46:
/*     */       case 63:
/*     */       case 91:
/*     */       case 92:
/*     */       case 93:
/*     */       case 94:
/*     */       case 123:
/*     */       case 124:
/*     */       case 125:
/* 343 */         return c; }
/*     */     
/*     */     throw ex("parser.process.1", this.offset - 2);
/* 346 */   } private static Hashtable ranges = null;
/* 347 */   private static Hashtable ranges2 = null; private static final String SPACES = "\t\n\r\r  "; private static final String NAMECHARS = "-.0:AZ__az··ÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁːˑ̀͠͡ͅΆΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁ҃҆ҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆֹֻֽֿֿׁׂ֑֣֡ׄׄאתװײءغـْ٠٩ٰڷںھۀێېۓە۪ۭۨ۰۹ँःअह़्॑॔क़ॣ०९ঁঃঅঌএঐওনপরললশহ়়াৄেৈো্ৗৗড়ঢ়য়ৣ০ৱਂਂਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹ਼਼ਾੂੇੈੋ੍ਖ਼ੜਫ਼ਫ਼੦ੴઁઃઅઋઍઍએઑઓનપરલળવહ઼ૅેૉો્ૠૠ૦૯ଁଃଅଌଏଐଓନପରଲଳଶହ଼ୃେୈୋ୍ୖୗଡ଼ଢ଼ୟୡ୦୯ஂஃஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹாூெைொ்ௗௗ௧௯ఁఃఅఌఎఐఒనపళవహాౄెైొ్ౕౖౠౡ౦౯ಂಃಅಌಎಐಒನಪಳವಹಾೄೆೈೊ್ೕೖೞೞೠೡ೦೯ംഃഅഌഎഐഒനപഹാൃെൈൊ്ൗൗൠൡ൦൯กฮะฺเ๎๐๙ກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະູົຽເໄໆໆ່ໍ໐໙༘༙༠༩༹༹༵༵༷༷༾ཇཉཀྵ྄ཱ྆ྋྐྕྗྗྙྭྱྷྐྵྐྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼ⃐⃜⃡⃡ΩΩKÅ℮℮ↀↂ々々〇〇〡〯〱〵ぁゔ゙゚ゝゞァヺーヾㄅㄬ一龥가힣";
/*     */   protected static synchronized RangeToken getRange(String name, boolean positive) {
/* 349 */     if (ranges == null) {
/* 350 */       ranges = new Hashtable();
/* 351 */       ranges2 = new Hashtable();
/*     */       
/* 353 */       Token token = Token.createRange();
/* 354 */       setupRange(token, "\t\n\r\r  ");
/* 355 */       ranges.put("xml:isSpace", token);
/* 356 */       ranges2.put("xml:isSpace", Token.complementRanges(token));
/*     */       
/* 358 */       token = Token.createRange();
/* 359 */       setupRange(token, "09٠٩۰۹०९০৯੦੯૦૯୦୯௧௯౦౯೦೯൦൯๐๙໐໙༠༩");
/* 360 */       ranges.put("xml:isDigit", token);
/* 361 */       ranges2.put("xml:isDigit", Token.complementRanges(token));
/*     */       
/* 363 */       token = Token.createRange();
/* 364 */       setupRange(token, "09٠٩۰۹०९০৯੦੯૦૯୦୯௧௯౦౯೦೯൦൯๐๙໐໙༠༩");
/* 365 */       ranges.put("xml:isDigit", token);
/* 366 */       ranges2.put("xml:isDigit", Token.complementRanges(token));
/*     */       
/* 368 */       token = Token.createRange();
/* 369 */       setupRange(token, "AZazÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣");
/* 370 */       token.mergeRanges((Token)ranges.get("xml:isDigit"));
/* 371 */       ranges.put("xml:isWord", token);
/* 372 */       ranges2.put("xml:isWord", Token.complementRanges(token));
/*     */       
/* 374 */       token = Token.createRange();
/* 375 */       setupRange(token, "-.0:AZ__az··ÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁːˑ̀͠͡ͅΆΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁ҃҆ҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆֹֻֽֿֿׁׂ֑֣֡ׄׄאתװײءغـْ٠٩ٰڷںھۀێېۓە۪ۭۨ۰۹ँःअह़्॑॔क़ॣ०९ঁঃঅঌএঐওনপরললশহ়়াৄেৈো্ৗৗড়ঢ়য়ৣ০ৱਂਂਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹ਼਼ਾੂੇੈੋ੍ਖ਼ੜਫ਼ਫ਼੦ੴઁઃઅઋઍઍએઑઓનપરલળવહ઼ૅેૉો્ૠૠ૦૯ଁଃଅଌଏଐଓନପରଲଳଶହ଼ୃେୈୋ୍ୖୗଡ଼ଢ଼ୟୡ୦୯ஂஃஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹாூெைொ்ௗௗ௧௯ఁఃఅఌఎఐఒనపళవహాౄెైొ్ౕౖౠౡ౦౯ಂಃಅಌಎಐಒನಪಳವಹಾೄೆೈೊ್ೕೖೞೞೠೡ೦೯ംഃഅഌഎഐഒനപഹാൃെൈൊ്ൗൗൠൡ൦൯กฮะฺเ๎๐๙ກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະູົຽເໄໆໆ່ໍ໐໙༘༙༠༩༹༹༵༵༷༷༾ཇཉཀྵ྄ཱ྆ྋྐྕྗྗྙྭྱྷྐྵྐྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼ⃐⃜⃡⃡ΩΩKÅ℮℮ↀↂ々々〇〇〡〯〱〵ぁゔ゙゚ゝゞァヺーヾㄅㄬ一龥가힣");
/* 376 */       ranges.put("xml:isNameChar", token);
/* 377 */       ranges2.put("xml:isNameChar", Token.complementRanges(token));
/*     */       
/* 379 */       token = Token.createRange();
/* 380 */       setupRange(token, "AZazÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣");
/* 381 */       token.addRange(95, 95);
/* 382 */       token.addRange(58, 58);
/* 383 */       ranges.put("xml:isInitialNameChar", token);
/* 384 */       ranges2.put("xml:isInitialNameChar", Token.complementRanges(token));
/*     */     } 
/* 386 */     RangeToken tok = positive ? (RangeToken)ranges.get(name) : (RangeToken)ranges2.get(name);
/*     */     
/* 388 */     return tok;
/*     */   }
/*     */   private static final String LETTERS = "AZazÀÖØöøıĴľŁňŊžƀǃǍǰǴǵǺȗɐʨʻˁΆΆΈΊΌΌΎΡΣώϐϖϚϚϜϜϞϞϠϠϢϳЁЌЎяёќўҁҐӄӇӈӋӌӐӫӮӵӸӹԱՖՙՙաֆאתװײءغفيٱڷںھۀێېۓەەۥۦअहऽऽक़ॡঅঌএঐওনপরললশহড়ঢ়য়ৡৰৱਅਊਏਐਓਨਪਰਲਲ਼ਵਸ਼ਸਹਖ਼ੜਫ਼ਫ਼ੲੴઅઋઍઍએઑઓનપરલળવહઽઽૠૠଅଌଏଐଓନପରଲଳଶହଽଽଡ଼ଢ଼ୟୡஅஊஎஐஒகஙசஜஜஞடணதநபமவஷஹఅఌఎఐఒనపళవహౠౡಅಌಎಐಒನಪಳವಹೞೞೠೡഅഌഎഐഒനപഹൠൡกฮะะาำเๅກຂຄຄງຈຊຊຍຍດທນຟມຣລລວວສຫອຮະະາຳຽຽເໄཀཇཉཀྵႠჅაჶᄀᄀᄂᄃᄅᄇᄉᄉᄋᄌᄎᄒᄼᄼᄾᄾᅀᅀᅌᅌᅎᅎᅐᅐᅔᅕᅙᅙᅟᅡᅣᅣᅥᅥᅧᅧᅩᅩᅭᅮᅲᅳᅵᅵᆞᆞᆨᆨᆫᆫᆮᆯᆷᆸᆺᆺᆼᇂᇫᇫᇰᇰᇹᇹḀẛẠỹἀἕἘἝἠὅὈὍὐὗὙὙὛὛὝὝὟώᾀᾴᾶᾼιιῂῄῆῌῐΐῖΊῠῬῲῴῶῼΩΩKÅ℮℮ↀↂ〇〇〡〩ぁゔァヺㄅㄬ一龥가힣"; private static final String DIGITS = "09٠٩۰۹०९০৯੦੯૦૯୦୯௧௯౦౯೦೯൦൯๐๙໐໙༠༩";
/*     */   static void setupRange(Token range, String src) {
/* 392 */     int len = src.length();
/* 393 */     for (int i = 0; i < len; i += 2)
/* 394 */       range.addRange(src.charAt(i), src.charAt(i + 1)); 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\regex\ParserForXMLSchema.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */