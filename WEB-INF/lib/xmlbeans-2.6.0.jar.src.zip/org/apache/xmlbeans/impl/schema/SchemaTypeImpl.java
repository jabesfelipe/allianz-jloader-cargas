/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.InterfaceExtension;
/*      */ import org.apache.xmlbeans.PrePostExtension;
/*      */ import org.apache.xmlbeans.QNameSet;
/*      */ import org.apache.xmlbeans.QNameSetBuilder;
/*      */ import org.apache.xmlbeans.QNameSetSpecification;
/*      */ import org.apache.xmlbeans.SchemaAnnotation;
/*      */ import org.apache.xmlbeans.SchemaAttributeModel;
/*      */ import org.apache.xmlbeans.SchemaComponent;
/*      */ import org.apache.xmlbeans.SchemaField;
/*      */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*      */ import org.apache.xmlbeans.SchemaGlobalElement;
/*      */ import org.apache.xmlbeans.SchemaLocalAttribute;
/*      */ import org.apache.xmlbeans.SchemaLocalElement;
/*      */ import org.apache.xmlbeans.SchemaParticle;
/*      */ import org.apache.xmlbeans.SchemaProperty;
/*      */ import org.apache.xmlbeans.SchemaStringEnumEntry;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SchemaTypeElementSequencer;
/*      */ import org.apache.xmlbeans.SchemaTypeLoader;
/*      */ import org.apache.xmlbeans.SchemaTypeSystem;
/*      */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*      */ import org.apache.xmlbeans.XmlAnySimpleType;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.regex.RegularExpression;
/*      */ import org.apache.xmlbeans.impl.values.StringEnumValue;
/*      */ import org.apache.xmlbeans.impl.values.TypeStoreUser;
/*      */ import org.apache.xmlbeans.impl.values.TypeStoreUserFactory;
/*      */ import org.apache.xmlbeans.impl.values.XmlAnySimpleTypeRestriction;
/*      */ import org.apache.xmlbeans.impl.values.XmlAnyTypeImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlAnyUriImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlBase64BinaryImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlBase64BinaryRestriction;
/*      */ import org.apache.xmlbeans.impl.values.XmlBooleanImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlByteImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlDateImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlDateTimeImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlDecimalImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlDecimalRestriction;
/*      */ import org.apache.xmlbeans.impl.values.XmlDoubleImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlDurationImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlEntitiesImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlEntityImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlFloatImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlGDayImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlGMonthDayImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlGMonthImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlGYearImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlGYearMonthImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlHexBinaryImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlIdImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlIdRefImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlIdRefsImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlIntImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlIntRestriction;
/*      */ import org.apache.xmlbeans.impl.values.XmlIntegerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlLanguageImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlListImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlLongRestriction;
/*      */ import org.apache.xmlbeans.impl.values.XmlNCNameImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNameImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNegativeIntegerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNmTokenImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNmTokensImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNonNegativeIntegerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNonPositiveIntegerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNormalizedStringImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNotationImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlNotationRestriction;
/*      */ import org.apache.xmlbeans.impl.values.XmlObjectBase;
/*      */ import org.apache.xmlbeans.impl.values.XmlPositiveIntegerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlQNameRestriction;
/*      */ import org.apache.xmlbeans.impl.values.XmlShortImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlStringImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlStringRestriction;
/*      */ import org.apache.xmlbeans.impl.values.XmlTimeImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlTokenImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlUnionImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlUnsignedByteImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlUnsignedIntImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlUnsignedLongImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlUnsignedShortImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlValueOutOfRangeException;
/*      */ 
/*      */ public final class SchemaTypeImpl implements SchemaType, TypeStoreUserFactory {
/*      */   private QName _name;
/*      */   private SchemaAnnotation _annotation;
/*      */   private int _resolvePhase;
/*      */   private static final int UNRESOLVED = 0;
/*      */   private static final int RESOLVING_SGS = 1;
/*      */   private static final int RESOLVED_SGS = 2;
/*      */   private static final int RESOLVING = 3;
/*      */   private static final int RESOLVED = 4;
/*  109 */   private final Object[] _ctrArgs = new Object[] { this }; private static final int JAVAIZING = 5; private static final int JAVAIZED = 6; private SchemaType.Ref _outerSchemaTypeRef; private volatile SchemaComponent.Ref _containerFieldRef; private volatile SchemaField _containerField; private volatile int _containerFieldCode; private volatile int _containerFieldIndex; private volatile QName[] _groupReferenceContext; private SchemaType.Ref[] _anonymousTyperefs; private boolean _isDocumentType; private boolean _isAttributeType; private boolean _isCompiled; private String _shortJavaName; private String _fullJavaName; private String _shortJavaImplName; private String _fullJavaImplName; private InterfaceExtension[] _interfaces; private PrePostExtension _prepost; private volatile Class _javaClass; private volatile Class _javaEnumClass; private volatile Class _javaImplClass; private volatile Constructor _javaImplConstructor;
/*      */   private volatile Constructor _javaImplConstructor2;
/*      */   private volatile boolean _implNotAvailable;
/*      */   private volatile Class _userTypeClass;
/*      */   private volatile Class _userTypeHandlerClass;
/*      */   private volatile Object _userData;
/*      */   private SchemaContainer _container;
/*      */   private String _filename;
/*      */   private SchemaParticle _contentModel;
/*      */   private volatile SchemaLocalElement[] _localElts;
/*      */   private volatile Map _eltToIndexMap;
/*      */   private volatile Map _attrToIndexMap;
/*      */   private Map _propertyModelByElementName;
/*      */   private Map _propertyModelByAttributeName;
/*      */   private boolean _hasAllContent;
/*      */   private boolean _orderSensitive;
/*      */   private QNameSet _typedWildcardElements;
/*      */   private QNameSet _typedWildcardAttributes;
/*      */   private boolean _hasWildcardElements;
/*      */   private boolean _hasWildcardAttributes;
/*  129 */   private Set _validSubstitutions = Collections.EMPTY_SET;
/*      */   
/*      */   private int _complexTypeVariety;
/*      */   
/*      */   private SchemaAttributeModel _attributeModel;
/*      */   
/*      */   private int _builtinTypeCode;
/*      */   
/*      */   private int _simpleTypeVariety;
/*      */   
/*      */   private boolean _isSimpleType;
/*      */   
/*      */   private SchemaType.Ref _baseTyperef;
/*      */   
/*      */   private int _baseDepth;
/*      */   
/*      */   private int _derivationType;
/*      */   
/*      */   private String _userTypeName;
/*      */   
/*      */   private String _userTypeHandler;
/*      */   
/*      */   private SchemaType.Ref _contentBasedOnTyperef;
/*      */   
/*      */   private XmlValueRef[] _facetArray;
/*      */   
/*      */   private boolean[] _fixedFacetArray;
/*      */   
/*      */   private int _ordered;
/*      */   
/*      */   private boolean _isFinite;
/*      */   
/*      */   private boolean _isBounded;
/*      */   
/*      */   private boolean _isNumeric;
/*      */   
/*      */   private boolean _abs;
/*      */   
/*      */   private boolean _finalExt;
/*      */   
/*      */   private boolean _finalRest;
/*      */   
/*      */   private boolean _finalList;
/*      */   
/*      */   private boolean _finalUnion;
/*      */   
/*      */   private boolean _blockExt;
/*      */   
/*      */   private boolean _blockRest;
/*      */   
/*      */   private int _whiteSpaceRule;
/*      */   
/*      */   private boolean _hasPatterns;
/*      */   
/*      */   private RegularExpression[] _patterns;
/*      */   
/*      */   private XmlValueRef[] _enumerationValues;
/*      */   
/*      */   private SchemaType.Ref _baseEnumTyperef;
/*      */   
/*      */   private boolean _stringEnumEnsured;
/*      */   
/*      */   private volatile Map _lookupStringEnum;
/*      */   
/*      */   private volatile List _listOfStringEnum;
/*      */   
/*      */   private volatile Map _lookupStringEnumEntry;
/*      */   private SchemaStringEnumEntry[] _stringEnumEntries;
/*      */   private SchemaType.Ref _listItemTyperef;
/*      */   private boolean _isUnionOfLists;
/*      */   private SchemaType.Ref[] _unionMemberTyperefs;
/*      */   private int _anonymousUnionMemberOrdinal;
/*      */   private volatile SchemaType[] _unionConstituentTypes;
/*      */   private volatile SchemaType[] _unionSubTypes;
/*      */   private volatile SchemaType _unionCommonBaseType;
/*      */   private SchemaType.Ref _primitiveTypeRef;
/*      */   private int _decimalSize;
/*      */   private volatile boolean _unloaded;
/*      */   private QName _sg;
/*  208 */   private List _sgMembers = new ArrayList();
/*      */ 
/*      */   
/*      */   public boolean isUnloaded() {
/*  212 */     return this._unloaded;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishLoading() {
/*  217 */     this._unloaded = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSGResolved() {
/*  236 */     return (this._resolvePhase >= 2);
/*      */   }
/*      */   public boolean isSGResolving() {
/*  239 */     return (this._resolvePhase >= 1);
/*      */   }
/*      */   public boolean isResolved() {
/*  242 */     return (this._resolvePhase >= 4);
/*      */   }
/*      */   public boolean isResolving() {
/*  245 */     return (this._resolvePhase == 3);
/*      */   }
/*      */   public boolean isUnjavaized() {
/*  248 */     return (this._resolvePhase < 6);
/*      */   }
/*      */   public boolean isJavaized() {
/*  251 */     return (this._resolvePhase == 6);
/*      */   }
/*      */   
/*      */   public void startResolvingSGs() {
/*  255 */     if (this._resolvePhase != 0)
/*  256 */       throw new IllegalStateException(); 
/*  257 */     this._resolvePhase = 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishResolvingSGs() {
/*  262 */     if (this._resolvePhase != 1)
/*  263 */       throw new IllegalStateException(); 
/*  264 */     this._resolvePhase = 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public void startResolving() {
/*  269 */     if ((this._isDocumentType && this._resolvePhase != 2) || (!this._isDocumentType && this._resolvePhase != 0))
/*      */     {
/*  271 */       throw new IllegalStateException(); } 
/*  272 */     this._resolvePhase = 3;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishResolving() {
/*  277 */     if (this._resolvePhase != 3)
/*  278 */       throw new IllegalStateException(); 
/*  279 */     this._resolvePhase = 4;
/*      */   }
/*      */ 
/*      */   
/*      */   public void startJavaizing() {
/*  284 */     if (this._resolvePhase != 4)
/*  285 */       throw new IllegalStateException(); 
/*  286 */     this._resolvePhase = 5;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishJavaizing() {
/*  291 */     if (this._resolvePhase != 5)
/*  292 */       throw new IllegalStateException(); 
/*  293 */     this._resolvePhase = 6;
/*      */   }
/*      */ 
/*      */   
/*      */   private void finishQuick() {
/*  298 */     this._resolvePhase = 6;
/*      */   }
/*      */ 
/*      */   
/*      */   private void assertUnresolved() {
/*  303 */     if (this._resolvePhase != 0 && !this._unloaded) {
/*  304 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */   
/*      */   private void assertSGResolving() {
/*  309 */     if (this._resolvePhase != 1 && !this._unloaded) {
/*  310 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */   
/*      */   private void assertSGResolved() {
/*  315 */     if (this._resolvePhase != 2 && !this._unloaded) {
/*  316 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */   
/*      */   private void assertResolving() {
/*  321 */     if (this._resolvePhase != 3 && !this._unloaded) {
/*  322 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */   
/*      */   private void assertResolved() {
/*  327 */     if (this._resolvePhase != 4 && !this._unloaded) {
/*  328 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */   
/*      */   private void assertJavaizing() {
/*  333 */     if (this._resolvePhase != 5 && !this._unloaded)
/*  334 */       throw new IllegalStateException(); 
/*      */   }
/*      */   
/*      */   public QName getName() {
/*  338 */     return this._name;
/*      */   }
/*      */   public void setName(QName name) {
/*  341 */     assertUnresolved(); this._name = name;
/*      */   }
/*      */   
/*      */   public String getSourceName() {
/*  345 */     if (this._filename != null)
/*  346 */       return this._filename; 
/*  347 */     if (getOuterType() != null) {
/*  348 */       return getOuterType().getSourceName();
/*      */     }
/*  350 */     SchemaField field = getContainerField();
/*  351 */     if (field != null) {
/*      */       
/*  353 */       if (field instanceof SchemaGlobalElement)
/*  354 */         return ((SchemaGlobalElement)field).getSourceName(); 
/*  355 */       if (field instanceof SchemaGlobalAttribute)
/*  356 */         return ((SchemaGlobalAttribute)field).getSourceName(); 
/*      */     } 
/*  358 */     return null;
/*      */   }
/*      */   
/*      */   public void setFilename(String filename) {
/*  362 */     assertUnresolved(); this._filename = filename;
/*      */   }
/*      */   public int getComponentType() {
/*  365 */     return 0;
/*      */   }
/*      */   public boolean isAnonymousType() {
/*  368 */     return (this._name == null);
/*      */   }
/*      */   public boolean isDocumentType() {
/*  371 */     return this._isDocumentType;
/*      */   }
/*      */   public boolean isAttributeType() {
/*  374 */     return this._isAttributeType;
/*      */   }
/*      */   
/*      */   public QName getDocumentElementName() {
/*  378 */     if (this._isDocumentType) {
/*      */       
/*  380 */       SchemaParticle sp = getContentModel();
/*  381 */       if (sp != null) {
/*  382 */         return sp.getName();
/*      */       }
/*      */     } 
/*  385 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public QName getAttributeTypeAttributeName() {
/*  390 */     if (this._isAttributeType) {
/*      */       
/*  392 */       SchemaAttributeModel sam = getAttributeModel();
/*  393 */       if (sam != null) {
/*      */         
/*  395 */         SchemaLocalAttribute[] slaArray = sam.getAttributes();
/*  396 */         if (slaArray != null && slaArray.length > 0) {
/*      */           
/*  398 */           SchemaLocalAttribute sla = slaArray[0];
/*  399 */           return sla.getName();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  404 */     return null;
/*      */   }
/*      */   
/*      */   public void setAnnotation(SchemaAnnotation ann) {
/*  408 */     assertUnresolved(); this._annotation = ann;
/*      */   }
/*      */   public SchemaAnnotation getAnnotation() {
/*  411 */     return this._annotation;
/*      */   }
/*      */   public void setDocumentType(boolean isDocument) {
/*  414 */     assertUnresolved(); this._isDocumentType = isDocument;
/*      */   }
/*      */   public void setAttributeType(boolean isAttribute) {
/*  417 */     assertUnresolved(); this._isAttributeType = isAttribute;
/*      */   }
/*      */   public int getContentType() {
/*  420 */     return this._complexTypeVariety;
/*      */   }
/*      */   public void setComplexTypeVariety(int complexTypeVariety) {
/*  423 */     assertResolving(); this._complexTypeVariety = complexTypeVariety;
/*      */   }
/*      */   
/*      */   public SchemaTypeElementSequencer getElementSequencer() {
/*  427 */     if (this._complexTypeVariety == 0) {
/*  428 */       return new SequencerImpl(null);
/*      */     }
/*  430 */     return new SequencerImpl(new SchemaTypeVisitorImpl(this._contentModel));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setAbstractFinal(boolean abs, boolean finalExt, boolean finalRest, boolean finalList, boolean finalUnion) {
/*  437 */     assertResolving();
/*  438 */     this._abs = abs;
/*  439 */     this._finalExt = finalExt; this._finalRest = finalRest;
/*  440 */     this._finalList = finalList; this._finalUnion = finalUnion;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void setSimpleFinal(boolean finalRest, boolean finalList, boolean finalUnion) {
/*  446 */     assertResolving(); this._finalRest = finalRest; this._finalList = finalList; this._finalUnion = finalUnion;
/*      */   }
/*      */ 
/*      */   
/*      */   void setBlock(boolean blockExt, boolean blockRest) {
/*  451 */     assertResolving(); this._blockExt = blockExt; this._blockRest = blockRest;
/*      */   }
/*      */   
/*      */   public boolean blockRestriction() {
/*  455 */     return this._blockRest;
/*      */   }
/*      */   public boolean blockExtension() {
/*  458 */     return this._blockExt;
/*      */   }
/*      */   public boolean isAbstract() {
/*  461 */     return this._abs;
/*      */   }
/*      */   public boolean finalExtension() {
/*  464 */     return this._finalExt;
/*      */   }
/*      */   public boolean finalRestriction() {
/*  467 */     return this._finalRest;
/*      */   }
/*      */   public boolean finalList() {
/*  470 */     return this._finalList;
/*      */   }
/*      */   public boolean finalUnion() {
/*  473 */     return this._finalUnion;
/*      */   }
/*      */   
/*      */   public synchronized SchemaField getContainerField() {
/*  477 */     if (this._containerFieldCode != -1) {
/*      */       
/*  479 */       SchemaType outer = getOuterType();
/*  480 */       if (this._containerFieldCode == 0) {
/*  481 */         this._containerField = (this._containerFieldRef == null) ? null : (SchemaField)this._containerFieldRef.getComponent();
/*  482 */       } else if (this._containerFieldCode == 1) {
/*  483 */         this._containerField = (SchemaField)outer.getAttributeModel().getAttributes()[this._containerFieldIndex];
/*      */       } else {
/*  485 */         this._containerField = (SchemaField)((SchemaTypeImpl)outer).getLocalElementByIndex(this._containerFieldIndex);
/*  486 */       }  this._containerFieldCode = -1;
/*      */     } 
/*  488 */     return this._containerField;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setContainerField(SchemaField field) {
/*  493 */     assertUnresolved();
/*  494 */     this._containerField = field;
/*  495 */     this._containerFieldCode = -1;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setContainerFieldRef(SchemaComponent.Ref ref) {
/*  500 */     assertUnresolved();
/*  501 */     this._containerFieldRef = ref;
/*  502 */     this._containerFieldCode = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setContainerFieldIndex(short code, int index) {
/*  507 */     assertUnresolved();
/*  508 */     this._containerFieldCode = code;
/*  509 */     this._containerFieldIndex = index;
/*      */   }
/*      */ 
/*      */   
/*      */   void setGroupReferenceContext(QName[] groupNames) {
/*  514 */     assertUnresolved();
/*  515 */     this._groupReferenceContext = groupNames;
/*      */   }
/*      */   
/*      */   QName[] getGroupReferenceContext() {
/*  519 */     return this._groupReferenceContext;
/*      */   }
/*      */   public SchemaType getOuterType() {
/*  522 */     return (this._outerSchemaTypeRef == null) ? null : this._outerSchemaTypeRef.get();
/*      */   }
/*      */   public void setOuterSchemaTypeRef(SchemaType.Ref typeref) {
/*  525 */     assertUnresolved(); this._outerSchemaTypeRef = typeref;
/*      */   }
/*      */   public boolean isCompiled() {
/*  528 */     return this._isCompiled;
/*      */   }
/*      */   public void setCompiled(boolean f) {
/*  531 */     assertJavaizing(); this._isCompiled = f;
/*      */   }
/*      */   
/*      */   public boolean isSkippedAnonymousType() {
/*  535 */     SchemaType outerType = getOuterType();
/*  536 */     return (outerType == null) ? false : ((outerType.getBaseType() == this || outerType.getContentBasedOnType() == this));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getShortJavaName() {
/*  542 */     return this._shortJavaName;
/*      */   }
/*      */   
/*      */   public void setShortJavaName(String name) {
/*  546 */     assertResolved();
/*  547 */     this._shortJavaName = name;
/*  548 */     SchemaType outer = this._outerSchemaTypeRef.get();
/*  549 */     while (outer.getFullJavaName() == null) {
/*  550 */       outer = outer.getOuterType();
/*      */     }
/*  552 */     this._fullJavaName = outer.getFullJavaName() + "$" + this._shortJavaName;
/*      */   }
/*      */   
/*      */   public String getFullJavaName() {
/*  556 */     return this._fullJavaName;
/*      */   }
/*      */   
/*      */   public void setFullJavaName(String name) {
/*  560 */     assertResolved();
/*  561 */     this._fullJavaName = name;
/*  562 */     int index = Math.max(this._fullJavaName.lastIndexOf('$'), this._fullJavaName.lastIndexOf('.')) + 1;
/*      */     
/*  564 */     this._shortJavaName = this._fullJavaName.substring(index);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setShortJavaImplName(String name) {
/*  569 */     assertResolved();
/*  570 */     this._shortJavaImplName = name;
/*  571 */     SchemaType outer = this._outerSchemaTypeRef.get();
/*  572 */     while (outer.getFullJavaImplName() == null) {
/*  573 */       outer = outer.getOuterType();
/*      */     }
/*  575 */     this._fullJavaImplName = outer.getFullJavaImplName() + "$" + this._shortJavaImplName;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFullJavaImplName(String name) {
/*  580 */     assertResolved();
/*  581 */     this._fullJavaImplName = name;
/*  582 */     int index = Math.max(this._fullJavaImplName.lastIndexOf('$'), this._fullJavaImplName.lastIndexOf('.')) + 1;
/*      */     
/*  584 */     this._shortJavaImplName = this._fullJavaImplName.substring(index);
/*      */   }
/*      */   
/*  587 */   public String getFullJavaImplName() { return this._fullJavaImplName; } public String getShortJavaImplName() {
/*  588 */     return this._shortJavaImplName;
/*      */   }
/*      */   
/*      */   public String getUserTypeName() {
/*  592 */     return this._userTypeName;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUserTypeName(String userTypeName) {
/*  597 */     this._userTypeName = userTypeName;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUserTypeHandlerName() {
/*  602 */     return this._userTypeHandler;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUserTypeHandlerName(String typeHandler) {
/*  607 */     this._userTypeHandler = typeHandler;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInterfaceExtensions(InterfaceExtension[] interfaces) {
/*  612 */     assertResolved();
/*  613 */     this._interfaces = interfaces;
/*      */   }
/*      */ 
/*      */   
/*      */   public InterfaceExtension[] getInterfaceExtensions() {
/*  618 */     return this._interfaces;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPrePostExtension(PrePostExtension prepost) {
/*  623 */     assertResolved();
/*  624 */     this._prepost = prepost;
/*      */   }
/*      */ 
/*      */   
/*      */   public PrePostExtension getPrePostExtension() {
/*  629 */     return this._prepost;
/*      */   }
/*      */   
/*      */   public Object getUserData() {
/*  633 */     return this._userData;
/*      */   }
/*      */   public void setUserData(Object data) {
/*  636 */     this._userData = data;
/*      */   }
/*      */   
/*      */   SchemaContainer getContainer() {
/*  640 */     return this._container;
/*      */   }
/*      */   void setContainer(SchemaContainer container) {
/*  643 */     this._container = container;
/*      */   }
/*      */   public SchemaTypeSystem getTypeSystem() {
/*  646 */     return this._container.getTypeSystem();
/*      */   }
/*      */   public SchemaParticle getContentModel() {
/*  649 */     return this._contentModel;
/*      */   }
/*      */   private static void buildEltList(List eltList, SchemaParticle contentModel) {
/*      */     int i;
/*  653 */     if (contentModel == null) {
/*      */       return;
/*      */     }
/*  656 */     switch (contentModel.getParticleType()) {
/*      */       
/*      */       case 4:
/*  659 */         eltList.add(contentModel);
/*      */         return;
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*  664 */         for (i = 0; i < contentModel.countOfParticleChild(); i++) {
/*  665 */           buildEltList(eltList, contentModel.getParticleChild(i));
/*      */         }
/*      */         return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void buildLocalElts() {
/*  674 */     List eltList = new ArrayList();
/*  675 */     buildEltList(eltList, this._contentModel);
/*  676 */     this._localElts = (SchemaLocalElement[])eltList.toArray((Object[])new SchemaLocalElement[eltList.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaLocalElement getLocalElementByIndex(int i) {
/*  681 */     SchemaLocalElement[] elts = this._localElts;
/*  682 */     if (elts == null) {
/*      */       
/*  684 */       buildLocalElts();
/*  685 */       elts = this._localElts;
/*      */     } 
/*  687 */     return elts[i];
/*      */   }
/*      */ 
/*      */   
/*      */   public int getIndexForLocalElement(SchemaLocalElement elt) {
/*  692 */     Map localEltMap = this._eltToIndexMap;
/*  693 */     if (localEltMap == null) {
/*      */       
/*  695 */       if (this._localElts == null)
/*  696 */         buildLocalElts(); 
/*  697 */       localEltMap = new HashMap();
/*  698 */       for (int i = 0; i < this._localElts.length; i++)
/*      */       {
/*  700 */         localEltMap.put(this._localElts[i], new Integer(i));
/*      */       }
/*  702 */       this._eltToIndexMap = localEltMap;
/*      */     } 
/*  704 */     return ((Integer)localEltMap.get(elt)).intValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getIndexForLocalAttribute(SchemaLocalAttribute attr) {
/*  709 */     Map localAttrMap = this._attrToIndexMap;
/*  710 */     if (localAttrMap == null) {
/*      */       
/*  712 */       localAttrMap = new HashMap();
/*  713 */       SchemaLocalAttribute[] attrs = this._attributeModel.getAttributes();
/*  714 */       for (int i = 0; i < attrs.length; i++)
/*      */       {
/*  716 */         localAttrMap.put(attrs[i], new Integer(i));
/*      */       }
/*  718 */       this._attrToIndexMap = localAttrMap;
/*      */     } 
/*  720 */     return ((Integer)localAttrMap.get(attr)).intValue();
/*      */   }
/*      */   
/*      */   public SchemaAttributeModel getAttributeModel() {
/*  724 */     return this._attributeModel;
/*      */   }
/*      */   
/*      */   public SchemaProperty[] getProperties() {
/*  728 */     if (this._propertyModelByElementName == null) {
/*  729 */       return getAttributeProperties();
/*      */     }
/*  731 */     if (this._propertyModelByAttributeName == null) {
/*  732 */       return getElementProperties();
/*      */     }
/*  734 */     List list = new ArrayList();
/*  735 */     list.addAll(this._propertyModelByElementName.values());
/*  736 */     list.addAll(this._propertyModelByAttributeName.values());
/*  737 */     return (SchemaProperty[])list.toArray((Object[])new SchemaProperty[list.size()]);
/*      */   }
/*      */   
/*  740 */   private static final SchemaProperty[] NO_PROPERTIES = new SchemaProperty[0]; private XmlObject _parseObject; private String _parseTNS; private String _elemFormDefault; private String _attFormDefault; private boolean _chameleon; private boolean _redefinition; private SchemaType.Ref _selfref;
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   public SchemaProperty[] getDerivedProperties() {
/*  744 */     SchemaType baseType = getBaseType();
/*  745 */     if (baseType == null) {
/*  746 */       return getProperties();
/*      */     }
/*  748 */     List results = new ArrayList();
/*      */     
/*  750 */     if (this._propertyModelByElementName != null) {
/*  751 */       results.addAll(this._propertyModelByElementName.values());
/*      */     }
/*  753 */     if (this._propertyModelByAttributeName != null) {
/*  754 */       results.addAll(this._propertyModelByAttributeName.values());
/*      */     }
/*  756 */     for (Iterator it = results.iterator(); it.hasNext(); ) {
/*      */       
/*  758 */       SchemaProperty prop = it.next();
/*  759 */       SchemaProperty baseProp = prop.isAttribute() ? baseType.getAttributeProperty(prop.getName()) : baseType.getElementProperty(prop.getName());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  768 */       if (baseProp != null)
/*      */       {
/*  770 */         if (eq(prop.getMinOccurs(), baseProp.getMinOccurs()) && eq(prop.getMaxOccurs(), baseProp.getMaxOccurs()) && prop.hasNillable() == baseProp.hasNillable() && eq(prop.getDefaultText(), baseProp.getDefaultText()))
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  775 */           it.remove();
/*      */         }
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  782 */     return (SchemaProperty[])results.toArray((Object[])new SchemaProperty[results.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean eq(BigInteger a, BigInteger b) {
/*  787 */     if (a == null && b == null)
/*  788 */       return true; 
/*  789 */     if (a == null || b == null)
/*  790 */       return false; 
/*  791 */     return a.equals(b);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean eq(String a, String b) {
/*  796 */     if (a == null && b == null)
/*  797 */       return true; 
/*  798 */     if (a == null || b == null)
/*  799 */       return false; 
/*  800 */     return a.equals(b);
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaProperty[] getElementProperties() {
/*  805 */     if (this._propertyModelByElementName == null) {
/*  806 */       return NO_PROPERTIES;
/*      */     }
/*  808 */     return (SchemaProperty[])this._propertyModelByElementName.values().toArray((Object[])new SchemaProperty[this._propertyModelByElementName.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaProperty[] getAttributeProperties() {
/*  814 */     if (this._propertyModelByAttributeName == null) {
/*  815 */       return NO_PROPERTIES;
/*      */     }
/*  817 */     return (SchemaProperty[])this._propertyModelByAttributeName.values().toArray((Object[])new SchemaProperty[this._propertyModelByAttributeName.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaProperty getElementProperty(QName eltName) {
/*  822 */     return (this._propertyModelByElementName == null) ? null : (SchemaProperty)this._propertyModelByElementName.get(eltName);
/*      */   }
/*      */   public SchemaProperty getAttributeProperty(QName attrName) {
/*  825 */     return (this._propertyModelByAttributeName == null) ? null : (SchemaProperty)this._propertyModelByAttributeName.get(attrName);
/*      */   }
/*      */   public boolean hasAllContent() {
/*  828 */     return this._hasAllContent;
/*      */   }
/*      */   public boolean isOrderSensitive() {
/*  831 */     return this._orderSensitive;
/*      */   }
/*      */   public void setOrderSensitive(boolean sensitive) {
/*  834 */     assertJavaizing(); this._orderSensitive = sensitive;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContentModel(SchemaParticle contentModel, SchemaAttributeModel attrModel, Map propertyModelByElementName, Map propertyModelByAttributeName, boolean isAll) {
/*  843 */     assertResolving();
/*  844 */     this._contentModel = contentModel;
/*  845 */     this._attributeModel = attrModel;
/*  846 */     this._propertyModelByElementName = propertyModelByElementName;
/*  847 */     this._propertyModelByAttributeName = propertyModelByAttributeName;
/*  848 */     this._hasAllContent = isAll;
/*      */ 
/*      */ 
/*      */     
/*  852 */     if (this._propertyModelByElementName != null) {
/*      */       
/*  854 */       this._validSubstitutions = new LinkedHashSet();
/*  855 */       Collection eltProps = this._propertyModelByElementName.values();
/*  856 */       for (Iterator it = eltProps.iterator(); it.hasNext(); ) {
/*      */         
/*  858 */         SchemaProperty prop = it.next();
/*  859 */         QName[] names = prop.acceptedNames();
/*  860 */         for (int i = 0; i < names.length; i++) {
/*      */           
/*  862 */           if (!this._propertyModelByElementName.containsKey(names[i])) {
/*  863 */             this._validSubstitutions.add(names[i]);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean containsElements() {
/*  871 */     return (getContentType() == 3 || getContentType() == 4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasAttributeWildcards() {
/*  877 */     return this._hasWildcardAttributes;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasElementWildcards() {
/*  882 */     return this._hasWildcardElements;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isValidSubstitution(QName name) {
/*  887 */     return this._validSubstitutions.contains(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType getElementType(QName eltName, QName xsiType, SchemaTypeLoader wildcardTypeLoader) {
/*  892 */     if (isSimpleType() || !containsElements() || isNoType()) {
/*  893 */       return BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */     }
/*  895 */     SchemaType type = null;
/*  896 */     SchemaProperty prop = (SchemaProperty)this._propertyModelByElementName.get(eltName);
/*  897 */     if (prop != null) {
/*      */       
/*  899 */       type = prop.getType();
/*      */     }
/*      */     else {
/*      */       
/*  903 */       if (wildcardTypeLoader == null) {
/*  904 */         return BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */       }
/*  906 */       if (this._typedWildcardElements.contains(eltName) || this._validSubstitutions.contains(eltName)) {
/*      */ 
/*      */         
/*  909 */         SchemaGlobalElement elt = wildcardTypeLoader.findElement(eltName);
/*  910 */         if (elt == null) {
/*  911 */           return BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */         }
/*      */         
/*  914 */         type = elt.getType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  933 */       else if (type == null) {
/*  934 */         return BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */       } 
/*      */     } 
/*      */     
/*  938 */     if (xsiType != null && wildcardTypeLoader != null) {
/*      */       
/*  940 */       SchemaType itype = wildcardTypeLoader.findType(xsiType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  946 */       if (itype != null && type.isAssignableFrom(itype)) {
/*  947 */         return itype;
/*      */       }
/*      */     } 
/*      */     
/*  951 */     return type;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType getAttributeType(QName attrName, SchemaTypeLoader wildcardTypeLoader) {
/*  956 */     if (isSimpleType() || isNoType()) {
/*  957 */       return BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */     }
/*  959 */     if (isURType()) {
/*  960 */       return BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     }
/*  962 */     SchemaProperty prop = (SchemaProperty)this._propertyModelByAttributeName.get(attrName);
/*  963 */     if (prop != null) {
/*  964 */       return prop.getType();
/*      */     }
/*  966 */     if (!this._typedWildcardAttributes.contains(attrName) || wildcardTypeLoader == null) {
/*  967 */       return BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */     }
/*      */ 
/*      */     
/*  971 */     SchemaGlobalAttribute attr = wildcardTypeLoader.findAttribute(attrName);
/*  972 */     if (attr == null)
/*  973 */       return BuiltinSchemaTypeSystem.ST_NO_TYPE; 
/*  974 */     return attr.getType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlObject createElementType(QName eltName, QName xsiType, SchemaTypeLoader wildcardTypeLoader) {
/*  984 */     SchemaType type = null;
/*  985 */     SchemaProperty prop = null;
/*  986 */     if (isSimpleType() || !containsElements() || isNoType()) {
/*      */       
/*  988 */       type = BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */     }
/*      */     else {
/*      */       
/*  992 */       prop = (SchemaProperty)this._propertyModelByElementName.get(eltName);
/*  993 */       if (prop != null) {
/*      */         
/*  995 */         type = prop.getType();
/*      */       }
/*  997 */       else if (this._typedWildcardElements.contains(eltName) || this._validSubstitutions.contains(eltName)) {
/*      */ 
/*      */         
/* 1000 */         SchemaGlobalElement elt = wildcardTypeLoader.findElement(eltName);
/* 1001 */         if (elt != null) {
/*      */           
/* 1003 */           type = elt.getType();
/* 1004 */           SchemaType docType = wildcardTypeLoader.findDocumentType(eltName);
/* 1005 */           if (docType != null) {
/* 1006 */             prop = docType.getElementProperty(eltName);
/*      */           }
/*      */         } else {
/* 1009 */           type = BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1032 */       else if (type == null) {
/* 1033 */         type = BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */       } 
/*      */       
/* 1036 */       if (xsiType != null) {
/*      */         
/* 1038 */         SchemaType itype = wildcardTypeLoader.findType(xsiType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1044 */         if (itype != null && type.isAssignableFrom(itype)) {
/* 1045 */           type = itype;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1050 */     if (type != null)
/* 1051 */       return ((SchemaTypeImpl)type).createUnattachedNode(prop); 
/* 1052 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public XmlObject createAttributeType(QName attrName, SchemaTypeLoader wildcardTypeLoader) {
/* 1057 */     SchemaTypeImpl type = null;
/* 1058 */     SchemaProperty prop = null;
/* 1059 */     if (isSimpleType() || isNoType()) {
/*      */       
/* 1061 */       type = BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */     }
/* 1063 */     else if (isURType()) {
/*      */       
/* 1065 */       type = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     }
/*      */     else {
/*      */       
/* 1069 */       prop = (SchemaProperty)this._propertyModelByAttributeName.get(attrName);
/* 1070 */       if (prop != null) {
/*      */         
/* 1072 */         type = (SchemaTypeImpl)prop.getType();
/*      */       }
/* 1074 */       else if (!this._typedWildcardAttributes.contains(attrName)) {
/*      */         
/* 1076 */         type = BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */       }
/*      */       else {
/*      */         
/* 1080 */         SchemaGlobalAttribute attr = wildcardTypeLoader.findAttribute(attrName);
/* 1081 */         if (attr != null) {
/* 1082 */           type = (SchemaTypeImpl)attr.getType();
/*      */         } else {
/* 1084 */           type = BuiltinSchemaTypeSystem.ST_NO_TYPE;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1088 */     if (type != null) {
/* 1089 */       return type.createUnattachedNode(prop);
/*      */     }
/* 1091 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWildcardSummary(QNameSet elementSet, boolean haswcElt, QNameSet attributeSet, boolean haswcAtt) {
/* 1096 */     assertResolving(); this._typedWildcardElements = elementSet; this._hasWildcardElements = haswcElt; this._typedWildcardAttributes = attributeSet; this._hasWildcardAttributes = haswcAtt;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType[] getAnonymousTypes() {
/* 1101 */     SchemaType[] result = new SchemaType[this._anonymousTyperefs.length];
/* 1102 */     for (int i = 0; i < result.length; i++)
/* 1103 */       result[i] = this._anonymousTyperefs[i].get(); 
/* 1104 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAnonymousTypeRefs(SchemaType.Ref[] anonymousTyperefs) {
/* 1109 */     this._anonymousTyperefs = anonymousTyperefs;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static SchemaType[] staCopy(SchemaType[] a) {
/* 1115 */     if (a == null) {
/* 1116 */       return null;
/*      */     }
/* 1118 */     SchemaType[] result = new SchemaType[a.length];
/* 1119 */     System.arraycopy(a, 0, result, 0, a.length);
/* 1120 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean[] boaCopy(boolean[] a) {
/* 1125 */     if (a == null) {
/* 1126 */       return null;
/*      */     }
/* 1128 */     boolean[] result = new boolean[a.length];
/* 1129 */     System.arraycopy(a, 0, result, 0, a.length);
/* 1130 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSimpleTypeVariety(int variety) {
/* 1136 */     assertResolving(); this._simpleTypeVariety = variety;
/*      */   }
/*      */   public int getSimpleVariety() {
/* 1139 */     return this._simpleTypeVariety;
/*      */   }
/*      */   public boolean isURType() {
/* 1142 */     return (this._builtinTypeCode == 1 || this._builtinTypeCode == 2);
/*      */   }
/*      */   public boolean isNoType() {
/* 1145 */     return (this == BuiltinSchemaTypeSystem.ST_NO_TYPE);
/*      */   }
/*      */   public boolean isSimpleType() {
/* 1148 */     return this._isSimpleType;
/*      */   }
/*      */   public void setSimpleType(boolean f) {
/* 1151 */     assertUnresolved(); this._isSimpleType = f;
/*      */   }
/*      */   public boolean isUnionOfLists() {
/* 1154 */     return this._isUnionOfLists;
/*      */   }
/*      */   public void setUnionOfLists(boolean f) {
/* 1157 */     assertResolving(); this._isUnionOfLists = f;
/*      */   }
/*      */   public SchemaType getPrimitiveType() {
/* 1160 */     return (this._primitiveTypeRef == null) ? null : this._primitiveTypeRef.get();
/*      */   }
/*      */   public void setPrimitiveTypeRef(SchemaType.Ref typeref) {
/* 1163 */     assertResolving(); this._primitiveTypeRef = typeref;
/*      */   }
/*      */   public int getDecimalSize() {
/* 1166 */     return this._decimalSize;
/*      */   }
/*      */   public void setDecimalSize(int bits) {
/* 1169 */     assertResolving(); this._decimalSize = bits;
/*      */   }
/*      */   public SchemaType getBaseType() {
/* 1172 */     return (this._baseTyperef == null) ? null : this._baseTyperef.get();
/*      */   }
/*      */   public void setBaseTypeRef(SchemaType.Ref typeref) {
/* 1175 */     assertResolving(); this._baseTyperef = typeref;
/*      */   }
/*      */   public int getBaseDepth() {
/* 1178 */     return this._baseDepth;
/*      */   }
/*      */   public void setBaseDepth(int depth) {
/* 1181 */     assertResolving(); this._baseDepth = depth;
/*      */   }
/*      */   public SchemaType getContentBasedOnType() {
/* 1184 */     return (this._contentBasedOnTyperef == null) ? null : this._contentBasedOnTyperef.get();
/*      */   }
/*      */   public void setContentBasedOnTypeRef(SchemaType.Ref typeref) {
/* 1187 */     assertResolving(); this._contentBasedOnTyperef = typeref;
/*      */   }
/*      */   public int getDerivationType() {
/* 1190 */     return this._derivationType;
/*      */   }
/*      */   public void setDerivationType(int type) {
/* 1193 */     assertResolving(); this._derivationType = type;
/*      */   }
/*      */   public SchemaType getListItemType() {
/* 1196 */     return (this._listItemTyperef == null) ? null : this._listItemTyperef.get();
/*      */   }
/*      */   public void setListItemTypeRef(SchemaType.Ref typeref) {
/* 1199 */     assertResolving(); this._listItemTyperef = typeref;
/*      */   }
/*      */   
/*      */   public SchemaType[] getUnionMemberTypes() {
/* 1203 */     SchemaType[] result = new SchemaType[(this._unionMemberTyperefs == null) ? 0 : this._unionMemberTyperefs.length];
/* 1204 */     for (int i = 0; i < result.length; i++)
/* 1205 */       result[i] = this._unionMemberTyperefs[i].get(); 
/* 1206 */     return result;
/*      */   }
/*      */   
/*      */   public void setUnionMemberTypeRefs(SchemaType.Ref[] typerefs) {
/* 1210 */     assertResolving(); this._unionMemberTyperefs = typerefs;
/*      */   }
/*      */   public int getAnonymousUnionMemberOrdinal() {
/* 1213 */     return this._anonymousUnionMemberOrdinal;
/*      */   }
/*      */   public void setAnonymousUnionMemberOrdinal(int i) {
/* 1216 */     assertUnresolved(); this._anonymousUnionMemberOrdinal = i;
/*      */   }
/*      */   
/*      */   public synchronized SchemaType[] getUnionConstituentTypes() {
/* 1220 */     if (this._unionCommonBaseType == null)
/* 1221 */       computeFlatUnionModel(); 
/* 1222 */     return staCopy(this._unionConstituentTypes);
/*      */   }
/*      */   
/*      */   private void setUnionConstituentTypes(SchemaType[] types) {
/* 1226 */     this._unionConstituentTypes = types;
/*      */   }
/*      */   
/*      */   public synchronized SchemaType[] getUnionSubTypes() {
/* 1230 */     if (this._unionCommonBaseType == null)
/* 1231 */       computeFlatUnionModel(); 
/* 1232 */     return staCopy(this._unionSubTypes);
/*      */   }
/*      */   
/*      */   private void setUnionSubTypes(SchemaType[] types) {
/* 1236 */     this._unionSubTypes = types;
/*      */   }
/*      */   
/*      */   public synchronized SchemaType getUnionCommonBaseType() {
/* 1240 */     if (this._unionCommonBaseType == null)
/* 1241 */       computeFlatUnionModel(); 
/* 1242 */     return this._unionCommonBaseType;
/*      */   }
/*      */   
/*      */   private void setUnionCommonBaseType(SchemaType type) {
/* 1246 */     this._unionCommonBaseType = type;
/*      */   }
/*      */   
/*      */   private void computeFlatUnionModel() {
/* 1250 */     if (getSimpleVariety() != 2)
/* 1251 */       throw new IllegalStateException("Operation is only supported on union types"); 
/* 1252 */     Set constituentMemberTypes = new LinkedHashSet();
/* 1253 */     Set allSubTypes = new LinkedHashSet();
/* 1254 */     SchemaType commonBaseType = null;
/*      */     
/* 1256 */     allSubTypes.add(this);
/*      */     
/* 1258 */     for (int i = 0; i < this._unionMemberTyperefs.length; i++) {
/*      */       SchemaType otherCommonBaseType;
/* 1260 */       SchemaTypeImpl mImpl = (SchemaTypeImpl)this._unionMemberTyperefs[i].get();
/*      */       
/* 1262 */       switch (mImpl.getSimpleVariety()) {
/*      */         
/*      */         case 3:
/* 1265 */           constituentMemberTypes.add(mImpl);
/* 1266 */           allSubTypes.add(mImpl);
/* 1267 */           commonBaseType = mImpl.getCommonBaseType(commonBaseType);
/*      */           break;
/*      */         case 2:
/* 1270 */           constituentMemberTypes.addAll((Collection)Arrays.asList(mImpl.getUnionConstituentTypes()));
/* 1271 */           allSubTypes.addAll((Collection)Arrays.asList(mImpl.getUnionSubTypes()));
/* 1272 */           otherCommonBaseType = mImpl.getUnionCommonBaseType();
/* 1273 */           if (otherCommonBaseType != null)
/* 1274 */             commonBaseType = otherCommonBaseType.getCommonBaseType(commonBaseType); 
/*      */           break;
/*      */         case 1:
/* 1277 */           constituentMemberTypes.add(mImpl);
/* 1278 */           allSubTypes.add(mImpl);
/* 1279 */           commonBaseType = mImpl.getCommonBaseType(commonBaseType);
/*      */           break;
/*      */         default:
/*      */           assert false;
/*      */           break;
/*      */       } 
/*      */     } 
/* 1286 */     setUnionConstituentTypes(constituentMemberTypes.<SchemaType>toArray(StscState.EMPTY_ST_ARRAY));
/*      */     
/* 1288 */     setUnionSubTypes(allSubTypes.<SchemaType>toArray(StscState.EMPTY_ST_ARRAY));
/*      */     
/* 1290 */     setUnionCommonBaseType(commonBaseType);
/*      */   }
/*      */   
/*      */   public QName getSubstitutionGroup() {
/* 1294 */     return this._sg;
/*      */   }
/*      */   public void setSubstitutionGroup(QName sg) {
/* 1297 */     assertSGResolving(); this._sg = sg;
/*      */   }
/*      */   public void addSubstitutionGroupMember(QName member) {
/* 1300 */     assertSGResolved(); this._sgMembers.add(member);
/*      */   }
/*      */   
/*      */   public QName[] getSubstitutionGroupMembers() {
/* 1304 */     QName[] result = new QName[this._sgMembers.size()];
/* 1305 */     return (QName[])this._sgMembers.toArray((Object[])result);
/*      */   }
/*      */   
/*      */   public int getWhiteSpaceRule() {
/* 1309 */     return this._whiteSpaceRule;
/*      */   }
/*      */   public void setWhiteSpaceRule(int ws) {
/* 1312 */     assertResolving(); this._whiteSpaceRule = ws;
/*      */   }
/*      */   
/*      */   public XmlAnySimpleType getFacet(int facetCode) {
/* 1316 */     if (this._facetArray == null)
/* 1317 */       return null; 
/* 1318 */     XmlValueRef ref = this._facetArray[facetCode];
/* 1319 */     if (ref == null)
/* 1320 */       return null; 
/* 1321 */     return ref.get();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFacetFixed(int facetCode) {
/* 1326 */     return this._fixedFacetArray[facetCode];
/*      */   }
/*      */ 
/*      */   
/*      */   public XmlAnySimpleType[] getBasicFacets() {
/* 1331 */     XmlAnySimpleType[] result = new XmlAnySimpleType[12];
/* 1332 */     for (int i = 0; i <= 11; i++)
/*      */     {
/* 1334 */       result[i] = getFacet(i);
/*      */     }
/* 1336 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean[] getFixedFacets() {
/* 1341 */     return boaCopy(this._fixedFacetArray);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBasicFacets(XmlValueRef[] values, boolean[] fixed) {
/* 1346 */     assertResolving();
/* 1347 */     this._facetArray = values;
/* 1348 */     this._fixedFacetArray = fixed;
/*      */   }
/*      */   
/*      */   public int ordered() {
/* 1352 */     return this._ordered;
/*      */   }
/*      */   public void setOrdered(int ordering) {
/* 1355 */     assertResolving(); this._ordered = ordering;
/*      */   }
/*      */   public boolean isBounded() {
/* 1358 */     return this._isBounded;
/*      */   }
/*      */   public void setBounded(boolean f) {
/* 1361 */     assertResolving(); this._isBounded = f;
/*      */   }
/*      */   public boolean isFinite() {
/* 1364 */     return this._isFinite;
/*      */   }
/*      */   public void setFinite(boolean f) {
/* 1367 */     assertResolving(); this._isFinite = f;
/*      */   }
/*      */   public boolean isNumeric() {
/* 1370 */     return this._isNumeric;
/*      */   }
/*      */   public void setNumeric(boolean f) {
/* 1373 */     assertResolving(); this._isNumeric = f;
/*      */   }
/*      */   
/*      */   public boolean hasPatternFacet() {
/* 1377 */     return this._hasPatterns;
/*      */   }
/*      */   public void setPatternFacet(boolean hasPatterns) {
/* 1380 */     assertResolving(); this._hasPatterns = hasPatterns;
/*      */   }
/*      */   
/*      */   public boolean matchPatternFacet(String s) {
/* 1384 */     if (!this._hasPatterns) {
/* 1385 */       return true;
/*      */     }
/* 1387 */     if (this._patterns != null && this._patterns.length > 0) {
/*      */       int i;
/*      */       
/* 1390 */       for (i = 0; i < this._patterns.length; i++) {
/*      */         
/* 1392 */         if (this._patterns[i].matches(s))
/*      */           break; 
/*      */       } 
/* 1395 */       if (i >= this._patterns.length) {
/* 1396 */         return false;
/*      */       }
/*      */     } 
/* 1399 */     return getBaseType().matchPatternFacet(s);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getPatterns() {
/* 1404 */     if (this._patterns == null)
/* 1405 */       return new String[0]; 
/* 1406 */     String[] patterns = new String[this._patterns.length];
/* 1407 */     for (int i = 0; i < this._patterns.length; i++)
/* 1408 */       patterns[i] = this._patterns[i].getPattern(); 
/* 1409 */     return patterns;
/*      */   }
/*      */ 
/*      */   
/*      */   public RegularExpression[] getPatternExpressions() {
/* 1414 */     if (this._patterns == null)
/* 1415 */       return new RegularExpression[0]; 
/* 1416 */     RegularExpression[] result = new RegularExpression[this._patterns.length];
/* 1417 */     System.arraycopy(this._patterns, 0, result, 0, this._patterns.length);
/* 1418 */     return result;
/*      */   }
/*      */   
/*      */   public void setPatterns(RegularExpression[] list) {
/* 1422 */     assertResolving(); this._patterns = list;
/*      */   }
/*      */   
/*      */   public XmlAnySimpleType[] getEnumerationValues() {
/* 1426 */     if (this._enumerationValues == null)
/* 1427 */       return null; 
/* 1428 */     XmlAnySimpleType[] result = new XmlAnySimpleType[this._enumerationValues.length];
/* 1429 */     for (int i = 0; i < result.length; i++) {
/*      */       
/* 1431 */       XmlValueRef ref = this._enumerationValues[i];
/* 1432 */       result[i] = (ref == null) ? null : ref.get();
/*      */     } 
/*      */     
/* 1435 */     return result;
/*      */   }
/*      */   
/*      */   public void setEnumerationValues(XmlValueRef[] a) {
/* 1439 */     assertResolving(); this._enumerationValues = a;
/*      */   }
/*      */   
/*      */   public StringEnumAbstractBase enumForString(String s) {
/* 1443 */     ensureStringEnumInfo();
/* 1444 */     if (this._lookupStringEnum == null)
/* 1445 */       return null; 
/* 1446 */     return (StringEnumAbstractBase)this._lookupStringEnum.get(s);
/*      */   }
/*      */ 
/*      */   
/*      */   public StringEnumAbstractBase enumForInt(int i) {
/* 1451 */     ensureStringEnumInfo();
/* 1452 */     if (this._listOfStringEnum == null || i < 0 || i >= this._listOfStringEnum.size())
/* 1453 */       return null; 
/* 1454 */     return this._listOfStringEnum.get(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaStringEnumEntry enumEntryForString(String s) {
/* 1459 */     ensureStringEnumInfo();
/* 1460 */     if (this._lookupStringEnumEntry == null)
/* 1461 */       return null; 
/* 1462 */     return (SchemaStringEnumEntry)this._lookupStringEnumEntry.get(s);
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType getBaseEnumType() {
/* 1467 */     return (this._baseEnumTyperef == null) ? null : this._baseEnumTyperef.get();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBaseEnumTypeRef(SchemaType.Ref baseEnumTyperef) {
/* 1472 */     this._baseEnumTyperef = baseEnumTyperef;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaStringEnumEntry[] getStringEnumEntries() {
/* 1477 */     if (this._stringEnumEntries == null)
/* 1478 */       return null; 
/* 1479 */     SchemaStringEnumEntry[] result = new SchemaStringEnumEntry[this._stringEnumEntries.length];
/* 1480 */     System.arraycopy(this._stringEnumEntries, 0, result, 0, result.length);
/* 1481 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStringEnumEntries(SchemaStringEnumEntry[] sEnums) {
/* 1486 */     assertJavaizing();
/* 1487 */     this._stringEnumEntries = sEnums;
/*      */   }
/*      */ 
/*      */   
/*      */   private void ensureStringEnumInfo() {
/* 1492 */     if (this._stringEnumEnsured) {
/*      */       return;
/*      */     }
/* 1495 */     SchemaStringEnumEntry[] sEnums = this._stringEnumEntries;
/* 1496 */     if (sEnums == null) {
/*      */       
/* 1498 */       this._stringEnumEnsured = true;
/*      */       
/*      */       return;
/*      */     } 
/* 1502 */     Map lookupStringEnum = new HashMap(sEnums.length);
/* 1503 */     List listOfStringEnum = new ArrayList(sEnums.length + 1);
/* 1504 */     Map lookupStringEnumEntry = new HashMap(sEnums.length);
/*      */     
/* 1506 */     for (int i = 0; i < sEnums.length; i++)
/*      */     {
/* 1508 */       lookupStringEnumEntry.put(sEnums[i].getString(), sEnums[i]);
/*      */     }
/*      */     
/* 1511 */     Class jc = this._baseEnumTyperef.get().getEnumJavaClass();
/* 1512 */     if (jc != null) {
/*      */       
/*      */       try {
/*      */         
/* 1516 */         StringEnumAbstractBase.Table table = (StringEnumAbstractBase.Table)jc.getField("table").get(null);
/* 1517 */         for (int j = 0; j < sEnums.length; j++)
/*      */         {
/* 1519 */           int k = sEnums[j].getIntValue();
/* 1520 */           StringEnumAbstractBase enumVal = table.forInt(k);
/* 1521 */           lookupStringEnum.put(sEnums[j].getString(), enumVal);
/* 1522 */           while (listOfStringEnum.size() <= k)
/* 1523 */             listOfStringEnum.add(null); 
/* 1524 */           listOfStringEnum.set(k, enumVal);
/*      */         }
/*      */       
/* 1527 */       } catch (Exception e) {
/*      */         
/* 1529 */         System.err.println("Something wrong: could not locate enum table for " + jc);
/* 1530 */         jc = null;
/* 1531 */         lookupStringEnum.clear();
/* 1532 */         listOfStringEnum.clear();
/*      */       } 
/*      */     }
/*      */     
/* 1536 */     if (jc == null)
/*      */     {
/* 1538 */       for (int j = 0; j < sEnums.length; j++) {
/*      */         
/* 1540 */         int k = sEnums[j].getIntValue();
/* 1541 */         String s = sEnums[j].getString();
/* 1542 */         StringEnumValue stringEnumValue = new StringEnumValue(s, k);
/* 1543 */         lookupStringEnum.put(s, stringEnumValue);
/* 1544 */         while (listOfStringEnum.size() <= k)
/* 1545 */           listOfStringEnum.add(null); 
/* 1546 */         listOfStringEnum.set(k, stringEnumValue);
/*      */       } 
/*      */     }
/*      */     
/* 1550 */     synchronized (this) {
/*      */       
/* 1552 */       if (!this._stringEnumEnsured) {
/*      */         
/* 1554 */         this._lookupStringEnum = lookupStringEnum;
/* 1555 */         this._listOfStringEnum = listOfStringEnum;
/* 1556 */         this._lookupStringEnumEntry = lookupStringEnumEntry;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1561 */     synchronized (this) {
/*      */       
/* 1563 */       this._stringEnumEnsured = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasStringEnumValues() {
/* 1569 */     return (this._stringEnumEntries != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void copyEnumerationValues(SchemaTypeImpl baseImpl) {
/* 1574 */     assertResolving();
/* 1575 */     this._enumerationValues = baseImpl._enumerationValues;
/* 1576 */     this._baseEnumTyperef = baseImpl._baseEnumTyperef;
/*      */   }
/*      */   
/*      */   public int getBuiltinTypeCode() {
/* 1580 */     return this._builtinTypeCode;
/*      */   }
/*      */   public void setBuiltinTypeCode(int builtinTypeCode) {
/* 1583 */     assertResolving(); this._builtinTypeCode = builtinTypeCode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void assignJavaElementSetterModel() {
/* 1590 */     SchemaProperty[] eltProps = getElementProperties();
/* 1591 */     SchemaParticle contentModel = getContentModel();
/* 1592 */     Map state = new HashMap();
/* 1593 */     QNameSet allContents = computeAllContainedElements(contentModel, state);
/*      */     
/* 1595 */     for (int i = 0; i < eltProps.length; i++) {
/*      */       
/* 1597 */       SchemaPropertyImpl sImpl = (SchemaPropertyImpl)eltProps[i];
/* 1598 */       QNameSet nde = computeNondelimitingElements(sImpl.getName(), contentModel, state);
/* 1599 */       QNameSetBuilder builder = new QNameSetBuilder((QNameSetSpecification)allContents);
/* 1600 */       builder.removeAll((QNameSetSpecification)nde);
/* 1601 */       sImpl.setJavaSetterDelimiter(builder.toQNameSet());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static QNameSet computeNondelimitingElements(QName target, SchemaParticle contentModel, Map state) {
/*      */     int i;
/* 1615 */     QNameSet allContents = computeAllContainedElements(contentModel, state);
/* 1616 */     if (!allContents.contains(target)) {
/* 1617 */       return QNameSet.EMPTY;
/*      */     }
/*      */     
/* 1620 */     if (contentModel.getMaxOccurs() == null || contentModel.getMaxOccurs().compareTo(BigInteger.ONE) > 0)
/*      */     {
/* 1622 */       return allContents;
/*      */     }
/*      */ 
/*      */     
/* 1626 */     switch (contentModel.getParticleType()) {
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1631 */         return allContents;
/*      */       
/*      */       case 5:
/* 1634 */         return QNameSet.singleton(target);
/*      */       
/*      */       case 2:
/* 1637 */         builder = new QNameSetBuilder();
/* 1638 */         for (i = 0; i < contentModel.countOfParticleChild(); i++) {
/*      */           
/* 1640 */           QNameSet childContents = computeAllContainedElements(contentModel.getParticleChild(i), state);
/* 1641 */           if (childContents.contains(target))
/* 1642 */             builder.addAll((QNameSetSpecification)computeNondelimitingElements(target, contentModel.getParticleChild(i), state)); 
/*      */         } 
/* 1644 */         return builder.toQNameSet();
/*      */       case 3:
/*      */         break;
/* 1647 */     }  QNameSetBuilder builder = new QNameSetBuilder();
/* 1648 */     boolean seenTarget = false;
/* 1649 */     for (int j = contentModel.countOfParticleChild(); j > 0; ) {
/*      */       
/* 1651 */       j--;
/* 1652 */       QNameSet childContents = computeAllContainedElements(contentModel.getParticleChild(j), state);
/* 1653 */       if (seenTarget) {
/*      */         
/* 1655 */         builder.addAll((QNameSetSpecification)childContents); continue;
/*      */       } 
/* 1657 */       if (childContents.contains(target)) {
/*      */         
/* 1659 */         builder.addAll((QNameSetSpecification)computeNondelimitingElements(target, contentModel.getParticleChild(j), state));
/* 1660 */         seenTarget = true;
/*      */       } 
/*      */     } 
/* 1663 */     return builder.toQNameSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static QNameSet computeAllContainedElements(SchemaParticle contentModel, Map state) {
/*      */     QNameSetBuilder builder;
/*      */     int i;
/* 1678 */     QNameSet result = (QNameSet)state.get(contentModel);
/* 1679 */     if (result != null) {
/* 1680 */       return result;
/*      */     }
/*      */ 
/*      */     
/* 1684 */     switch (contentModel.getParticleType())
/*      */     
/*      */     { 
/*      */ 
/*      */       
/*      */       default:
/* 1690 */         builder = new QNameSetBuilder();
/* 1691 */         for (i = 0; i < contentModel.countOfParticleChild(); i++)
/*      */         {
/* 1693 */           builder.addAll((QNameSetSpecification)computeAllContainedElements(contentModel.getParticleChild(i), state));
/*      */         }
/* 1695 */         result = builder.toQNameSet();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1707 */         state.put(contentModel, result);
/* 1708 */         return result;case 5: result = contentModel.getWildcardSet(); state.put(contentModel, result); return result;case 4: break; }  result = ((SchemaLocalElementImpl)contentModel).acceptedStartNames(); state.put(contentModel, result); return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Class getJavaClass() {
/* 1714 */     if (this._javaClass == null && getFullJavaName() != null) {
/*      */       
/*      */       try {
/* 1717 */         this._javaClass = Class.forName(getFullJavaName(), false, getTypeSystem().getClassLoader());
/* 1718 */       } catch (ClassNotFoundException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1724 */         this._javaClass = null;
/*      */       } 
/*      */     }
/*      */     
/* 1728 */     return this._javaClass;
/*      */   }
/*      */   
/*      */   public Class getJavaImplClass() {
/* 1732 */     if (this._implNotAvailable) {
/* 1733 */       return null;
/*      */     }
/* 1735 */     if (this._javaImplClass == null) {
/*      */       
/*      */       try {
/* 1738 */         if (getFullJavaImplName() != null) {
/* 1739 */           this._javaImplClass = Class.forName(getFullJavaImplName(), false, getTypeSystem().getClassLoader());
/*      */         } else {
/* 1741 */           this._implNotAvailable = true;
/*      */         } 
/* 1743 */       } catch (ClassNotFoundException e) {
/* 1744 */         this._implNotAvailable = true;
/*      */       } 
/*      */     }
/*      */     
/* 1748 */     return this._javaImplClass;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Class getUserTypeClass() {
/* 1754 */     if (this._userTypeClass == null && getUserTypeName() != null) {
/*      */       
/*      */       try {
/*      */         
/* 1758 */         this._userTypeClass = Class.forName(this._userTypeName, false, getTypeSystem().getClassLoader());
/*      */       
/*      */       }
/* 1761 */       catch (ClassNotFoundException e) {
/*      */         
/* 1763 */         this._userTypeClass = null;
/*      */       } 
/*      */     }
/*      */     
/* 1767 */     return this._userTypeClass;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Class getUserTypeHandlerClass() {
/* 1773 */     if (this._userTypeHandlerClass == null && getUserTypeHandlerName() != null) {
/*      */       
/*      */       try {
/*      */         
/* 1777 */         this._userTypeHandlerClass = Class.forName(this._userTypeHandler, false, getTypeSystem().getClassLoader());
/*      */       
/*      */       }
/* 1780 */       catch (ClassNotFoundException e) {
/*      */         
/* 1782 */         this._userTypeHandlerClass = null;
/*      */       } 
/*      */     }
/*      */     
/* 1786 */     return this._userTypeHandlerClass;
/*      */   }
/*      */ 
/*      */   
/*      */   public Constructor getJavaImplConstructor() {
/* 1791 */     if (this._javaImplConstructor == null && !this._implNotAvailable) {
/*      */       
/* 1793 */       Class impl = getJavaImplClass();
/* 1794 */       if (impl == null) return null;
/*      */       
/*      */       try {
/* 1797 */         this._javaImplConstructor = impl.getConstructor(new Class[] { SchemaType.class });
/*      */       }
/* 1799 */       catch (NoSuchMethodException e) {
/*      */         
/* 1801 */         e.printStackTrace();
/*      */       } 
/*      */     } 
/*      */     
/* 1805 */     return this._javaImplConstructor;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Constructor getJavaImplConstructor2() {
/* 1811 */     if (this._javaImplConstructor2 == null && !this._implNotAvailable) {
/*      */       
/* 1813 */       Class impl = getJavaImplClass();
/* 1814 */       if (impl == null) return null;
/*      */       
/*      */       try {
/* 1817 */         this._javaImplConstructor2 = impl.getDeclaredConstructor(new Class[] { SchemaType.class, boolean.class });
/*      */       }
/* 1819 */       catch (NoSuchMethodException e) {
/*      */         
/* 1821 */         e.printStackTrace();
/*      */       } 
/*      */     } 
/*      */     
/* 1825 */     return this._javaImplConstructor2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class getEnumJavaClass() {
/* 1832 */     if (this._javaEnumClass == null)
/*      */     {
/* 1834 */       if (getBaseEnumType() != null) {
/*      */         
/*      */         try {
/*      */           
/* 1838 */           this._javaEnumClass = Class.forName(getBaseEnumType().getFullJavaName() + "$Enum", false, getTypeSystem().getClassLoader());
/*      */         }
/* 1840 */         catch (ClassNotFoundException e) {
/*      */           
/* 1842 */           this._javaEnumClass = null;
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/* 1847 */     return this._javaEnumClass;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setJavaClass(Class javaClass) {
/* 1852 */     assertResolved();
/* 1853 */     this._javaClass = javaClass;
/* 1854 */     setFullJavaName(javaClass.getName());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPrimitiveType() {
/* 1859 */     return (getBuiltinTypeCode() >= 2 && getBuiltinTypeCode() <= 21);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBuiltinType() {
/* 1865 */     return (getBuiltinTypeCode() != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlObject createUnwrappedNode() {
/* 1871 */     XmlObject result = createUnattachedNode(null);
/* 1872 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeStoreUser createTypeStoreUser() {
/* 1880 */     return (TypeStoreUser)createUnattachedNode(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlAnySimpleType newValidatingValue(Object obj) {
/* 1886 */     return newValue(obj, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlAnySimpleType newValue(Object obj) {
/* 1893 */     return newValue(obj, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public XmlAnySimpleType newValue(Object obj, boolean validateOnSet) {
/* 1898 */     if (!isSimpleType() && getContentType() != 2) {
/* 1899 */       throw new XmlValueOutOfRangeException();
/*      */     }
/* 1901 */     XmlObjectBase result = (XmlObjectBase)createUnattachedNode(null);
/* 1902 */     if (validateOnSet) {
/* 1903 */       result.setValidateOnSet();
/*      */     }
/*      */ 
/*      */     
/* 1907 */     if (obj instanceof XmlObject) {
/* 1908 */       result.set_newValue((XmlObject)obj);
/*      */     } else {
/* 1910 */       result.objectSet(obj);
/*      */     } 
/* 1912 */     result.check_dated();
/* 1913 */     result.setImmutable();
/*      */     
/* 1915 */     return (XmlAnySimpleType)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XmlObject createUnattachedNode(SchemaProperty prop) {
/* 1923 */     XmlObject result = null;
/*      */     
/* 1925 */     if (!isBuiltinType() && !isNoType()) {
/*      */ 
/*      */       
/* 1928 */       Constructor ctr = getJavaImplConstructor();
/* 1929 */       if (ctr != null) {
/*      */         try
/*      */         {
/*      */ 
/*      */           
/* 1934 */           return ctr.newInstance(this._ctrArgs);
/*      */         }
/* 1936 */         catch (Exception e)
/*      */         {
/* 1938 */           System.out.println("Exception trying to instantiate impl class.");
/* 1939 */           e.printStackTrace();
/*      */         }
/*      */       
/*      */       }
/*      */     } else {
/*      */       
/* 1945 */       result = createBuiltinInstance();
/*      */     } 
/*      */ 
/*      */     
/* 1949 */     for (SchemaType sType = this; result == null; sType = sType.getBaseType()) {
/* 1950 */       result = ((SchemaTypeImpl)sType).createUnattachedSubclass(this);
/*      */     }
/* 1952 */     ((XmlObjectBase)result).init_flags(prop);
/* 1953 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private XmlObject createUnattachedSubclass(SchemaType sType) {
/* 1958 */     if (!isBuiltinType() && !isNoType()) {
/*      */ 
/*      */       
/* 1961 */       Constructor ctr = getJavaImplConstructor2();
/* 1962 */       if (ctr != null) {
/*      */         
/* 1964 */         boolean accessible = ctr.isAccessible();
/*      */         
/*      */         try {
/* 1967 */           ctr.setAccessible(true);
/*      */ 
/*      */           
/*      */           try {
/* 1971 */             return ctr.newInstance(new Object[] { sType, sType.isSimpleType() ? Boolean.FALSE : Boolean.TRUE });
/*      */           }
/* 1973 */           catch (Exception e) {
/*      */             
/* 1975 */             System.out.println("Exception trying to instantiate impl class.");
/* 1976 */             e.printStackTrace();
/*      */           } finally {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/* 1982 */               ctr.setAccessible(accessible);
/* 1983 */             } catch (SecurityException se) {}
/*      */           }
/*      */         
/*      */         }
/* 1987 */         catch (Exception e) {
/*      */           
/* 1989 */           System.out.println("Exception trying to instantiate impl class.");
/* 1990 */           e.printStackTrace();
/*      */         } 
/*      */       } 
/* 1993 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 1997 */     return createBuiltinSubclass(sType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private XmlObject createBuiltinInstance() {
/* 2003 */     switch (getBuiltinTypeCode()) {
/*      */       
/*      */       case 0:
/* 2006 */         return (XmlObject)new XmlAnyTypeImpl(BuiltinSchemaTypeSystem.ST_NO_TYPE);
/*      */       case 1:
/* 2008 */         return (XmlObject)new XmlAnyTypeImpl();
/*      */       case 2:
/* 2010 */         return (XmlObject)new XmlAnySimpleTypeImpl();
/*      */       case 3:
/* 2012 */         return (XmlObject)new XmlBooleanImpl();
/*      */       case 4:
/* 2014 */         return (XmlObject)new XmlBase64BinaryImpl();
/*      */       case 5:
/* 2016 */         return (XmlObject)new XmlHexBinaryImpl();
/*      */       case 6:
/* 2018 */         return (XmlObject)new XmlAnyUriImpl();
/*      */       case 7:
/* 2020 */         return (XmlObject)new XmlQNameImpl();
/*      */       case 8:
/* 2022 */         return (XmlObject)new XmlNotationImpl();
/*      */       case 9:
/* 2024 */         return (XmlObject)new XmlFloatImpl();
/*      */       case 10:
/* 2026 */         return (XmlObject)new XmlDoubleImpl();
/*      */       case 11:
/* 2028 */         return (XmlObject)new XmlDecimalImpl();
/*      */       case 12:
/* 2030 */         return (XmlObject)new XmlStringImpl();
/*      */       case 13:
/* 2032 */         return (XmlObject)new XmlDurationImpl();
/*      */       case 14:
/* 2034 */         return (XmlObject)new XmlDateTimeImpl();
/*      */       case 15:
/* 2036 */         return (XmlObject)new XmlTimeImpl();
/*      */       case 16:
/* 2038 */         return (XmlObject)new XmlDateImpl();
/*      */       case 17:
/* 2040 */         return (XmlObject)new XmlGYearMonthImpl();
/*      */       case 18:
/* 2042 */         return (XmlObject)new XmlGYearImpl();
/*      */       case 19:
/* 2044 */         return (XmlObject)new XmlGMonthDayImpl();
/*      */       case 20:
/* 2046 */         return (XmlObject)new XmlGDayImpl();
/*      */       case 21:
/* 2048 */         return (XmlObject)new XmlGMonthImpl();
/*      */       case 22:
/* 2050 */         return (XmlObject)new XmlIntegerImpl();
/*      */       case 23:
/* 2052 */         return (XmlObject)new XmlLongImpl();
/*      */       case 24:
/* 2054 */         return (XmlObject)new XmlIntImpl();
/*      */       case 25:
/* 2056 */         return (XmlObject)new XmlShortImpl();
/*      */       case 26:
/* 2058 */         return (XmlObject)new XmlByteImpl();
/*      */       case 27:
/* 2060 */         return (XmlObject)new XmlNonPositiveIntegerImpl();
/*      */       case 28:
/* 2062 */         return (XmlObject)new XmlNegativeIntegerImpl();
/*      */       case 29:
/* 2064 */         return (XmlObject)new XmlNonNegativeIntegerImpl();
/*      */       case 30:
/* 2066 */         return (XmlObject)new XmlPositiveIntegerImpl();
/*      */       case 31:
/* 2068 */         return (XmlObject)new XmlUnsignedLongImpl();
/*      */       case 32:
/* 2070 */         return (XmlObject)new XmlUnsignedIntImpl();
/*      */       case 33:
/* 2072 */         return (XmlObject)new XmlUnsignedShortImpl();
/*      */       case 34:
/* 2074 */         return (XmlObject)new XmlUnsignedByteImpl();
/*      */       case 35:
/* 2076 */         return (XmlObject)new XmlNormalizedStringImpl();
/*      */       case 36:
/* 2078 */         return (XmlObject)new XmlTokenImpl();
/*      */       case 37:
/* 2080 */         return (XmlObject)new XmlNameImpl();
/*      */       case 38:
/* 2082 */         return (XmlObject)new XmlNCNameImpl();
/*      */       case 39:
/* 2084 */         return (XmlObject)new XmlLanguageImpl();
/*      */       case 40:
/* 2086 */         return (XmlObject)new XmlIdImpl();
/*      */       case 41:
/* 2088 */         return (XmlObject)new XmlIdRefImpl();
/*      */       case 42:
/* 2090 */         return (XmlObject)new XmlIdRefsImpl();
/*      */       case 43:
/* 2092 */         return (XmlObject)new XmlEntityImpl();
/*      */       case 44:
/* 2094 */         return (XmlObject)new XmlEntitiesImpl();
/*      */       case 45:
/* 2096 */         return (XmlObject)new XmlNmTokenImpl();
/*      */       case 46:
/* 2098 */         return (XmlObject)new XmlNmTokensImpl();
/*      */     } 
/* 2100 */     throw new IllegalStateException("Unrecognized builtin type: " + getBuiltinTypeCode());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private XmlObject createBuiltinSubclass(SchemaType sType) {
/* 2106 */     boolean complex = !sType.isSimpleType();
/* 2107 */     switch (getBuiltinTypeCode()) {
/*      */       
/*      */       case 0:
/* 2110 */         return (XmlObject)new XmlAnyTypeImpl(BuiltinSchemaTypeSystem.ST_NO_TYPE);
/*      */       case 1:
/*      */       case 2:
/* 2113 */         switch (sType.getSimpleVariety()) {
/*      */           
/*      */           case 0:
/* 2116 */             return (XmlObject)new XmlComplexContentImpl(sType);
/*      */           case 1:
/* 2118 */             return (XmlObject)new XmlAnySimpleTypeRestriction(sType, complex);
/*      */           case 3:
/* 2120 */             return (XmlObject)new XmlListImpl(sType, complex);
/*      */           case 2:
/* 2122 */             return (XmlObject)new XmlUnionImpl(sType, complex);
/*      */         } 
/* 2124 */         throw new IllegalStateException();
/*      */       
/*      */       case 3:
/* 2127 */         return (XmlObject)new XmlBooleanRestriction(sType, complex);
/*      */       case 4:
/* 2129 */         return (XmlObject)new XmlBase64BinaryRestriction(sType, complex);
/*      */       case 5:
/* 2131 */         return (XmlObject)new XmlHexBinaryRestriction(sType, complex);
/*      */       case 6:
/* 2133 */         return (XmlObject)new XmlAnyUriRestriction(sType, complex);
/*      */       case 7:
/* 2135 */         return (XmlObject)new XmlQNameRestriction(sType, complex);
/*      */       case 8:
/* 2137 */         return (XmlObject)new XmlNotationRestriction(sType, complex);
/*      */       case 9:
/* 2139 */         return (XmlObject)new XmlFloatRestriction(sType, complex);
/*      */       case 10:
/* 2141 */         return (XmlObject)new XmlDoubleRestriction(sType, complex);
/*      */       case 11:
/* 2143 */         return (XmlObject)new XmlDecimalRestriction(sType, complex);
/*      */       case 12:
/* 2145 */         if (sType.hasStringEnumValues()) {
/* 2146 */           return (XmlObject)new XmlStringEnumeration(sType, complex);
/*      */         }
/* 2148 */         return (XmlObject)new XmlStringRestriction(sType, complex);
/*      */       case 13:
/* 2150 */         return (XmlObject)new XmlDurationImpl(sType, complex);
/*      */       case 14:
/* 2152 */         return (XmlObject)new XmlDateTimeImpl(sType, complex);
/*      */       case 15:
/* 2154 */         return (XmlObject)new XmlTimeImpl(sType, complex);
/*      */       case 16:
/* 2156 */         return (XmlObject)new XmlDateImpl(sType, complex);
/*      */       case 17:
/* 2158 */         return (XmlObject)new XmlGYearMonthImpl(sType, complex);
/*      */       case 18:
/* 2160 */         return (XmlObject)new XmlGYearImpl(sType, complex);
/*      */       case 19:
/* 2162 */         return (XmlObject)new XmlGMonthDayImpl(sType, complex);
/*      */       case 20:
/* 2164 */         return (XmlObject)new XmlGDayImpl(sType, complex);
/*      */       case 21:
/* 2166 */         return (XmlObject)new XmlGMonthImpl(sType, complex);
/*      */       case 22:
/* 2168 */         return (XmlObject)new XmlIntegerRestriction(sType, complex);
/*      */       case 23:
/* 2170 */         return (XmlObject)new XmlLongRestriction(sType, complex);
/*      */       case 24:
/* 2172 */         return (XmlObject)new XmlIntRestriction(sType, complex);
/*      */       case 25:
/* 2174 */         return (XmlObject)new XmlShortImpl(sType, complex);
/*      */       case 26:
/* 2176 */         return (XmlObject)new XmlByteImpl(sType, complex);
/*      */       case 27:
/* 2178 */         return (XmlObject)new XmlNonPositiveIntegerImpl(sType, complex);
/*      */       case 28:
/* 2180 */         return (XmlObject)new XmlNegativeIntegerImpl(sType, complex);
/*      */       case 29:
/* 2182 */         return (XmlObject)new XmlNonNegativeIntegerImpl(sType, complex);
/*      */       case 30:
/* 2184 */         return (XmlObject)new XmlPositiveIntegerImpl(sType, complex);
/*      */       case 31:
/* 2186 */         return (XmlObject)new XmlUnsignedLongImpl(sType, complex);
/*      */       case 32:
/* 2188 */         return (XmlObject)new XmlUnsignedIntImpl(sType, complex);
/*      */       case 33:
/* 2190 */         return (XmlObject)new XmlUnsignedShortImpl(sType, complex);
/*      */       case 34:
/* 2192 */         return (XmlObject)new XmlUnsignedByteImpl(sType, complex);
/*      */       case 35:
/* 2194 */         return (XmlObject)new XmlNormalizedStringImpl(sType, complex);
/*      */       case 36:
/* 2196 */         return (XmlObject)new XmlTokenImpl(sType, complex);
/*      */       case 37:
/* 2198 */         return (XmlObject)new XmlNameImpl(sType, complex);
/*      */       case 38:
/* 2200 */         return (XmlObject)new XmlNCNameImpl(sType, complex);
/*      */       case 39:
/* 2202 */         return (XmlObject)new XmlLanguageImpl(sType, complex);
/*      */       case 40:
/* 2204 */         return (XmlObject)new XmlIdImpl(sType, complex);
/*      */       case 41:
/* 2206 */         return (XmlObject)new XmlIdRefImpl(sType, complex);
/*      */       case 42:
/* 2208 */         return (XmlObject)new XmlIdRefsImpl(sType, complex);
/*      */       case 43:
/* 2210 */         return (XmlObject)new XmlEntityImpl(sType, complex);
/*      */       case 44:
/* 2212 */         return (XmlObject)new XmlEntitiesImpl(sType, complex);
/*      */       case 45:
/* 2214 */         return (XmlObject)new XmlNmTokenImpl(sType, complex);
/*      */       case 46:
/* 2216 */         return (XmlObject)new XmlNmTokensImpl(sType, complex);
/*      */     } 
/* 2218 */     throw new IllegalStateException("Unrecognized builtin type: " + getBuiltinTypeCode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaType getCommonBaseType(SchemaType type) {
/* 2225 */     if (this == BuiltinSchemaTypeSystem.ST_ANY_TYPE || type == null || type.isNoType()) {
/* 2226 */       return this;
/*      */     }
/*      */     
/* 2229 */     if (type == BuiltinSchemaTypeSystem.ST_ANY_TYPE || isNoType()) {
/* 2230 */       return type;
/*      */     }
/*      */     
/* 2233 */     SchemaTypeImpl sImpl1 = (SchemaTypeImpl)type;
/* 2234 */     while (sImpl1.getBaseDepth() > getBaseDepth())
/* 2235 */       sImpl1 = (SchemaTypeImpl)sImpl1.getBaseType(); 
/* 2236 */     SchemaTypeImpl sImpl2 = this;
/* 2237 */     while (sImpl2.getBaseDepth() > sImpl1.getBaseDepth()) {
/* 2238 */       sImpl2 = (SchemaTypeImpl)sImpl2.getBaseType();
/*      */     }
/*      */     
/* 2241 */     while (!sImpl1.equals(sImpl2)) {
/*      */       
/* 2243 */       sImpl1 = (SchemaTypeImpl)sImpl1.getBaseType();
/* 2244 */       sImpl2 = (SchemaTypeImpl)sImpl2.getBaseType();
/* 2245 */       assert sImpl1 != null && sImpl2 != null;
/*      */     } 
/* 2247 */     return sImpl1;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAssignableFrom(SchemaType type) {
/* 2252 */     if (type == null || type.isNoType()) {
/* 2253 */       return true;
/*      */     }
/* 2255 */     if (isNoType()) {
/* 2256 */       return false;
/*      */     }
/* 2258 */     if (getSimpleVariety() == 2) {
/*      */       
/* 2260 */       SchemaType[] members = getUnionMemberTypes();
/* 2261 */       for (int i = 0; i < members.length; i++) {
/* 2262 */         if (members[i].isAssignableFrom(type))
/* 2263 */           return true; 
/*      */       } 
/*      */     } 
/* 2266 */     int depth = ((SchemaTypeImpl)type).getBaseDepth() - getBaseDepth();
/* 2267 */     if (depth < 0)
/* 2268 */       return false; 
/* 2269 */     while (depth > 0) {
/*      */       
/* 2271 */       type = type.getBaseType();
/* 2272 */       depth--;
/*      */     } 
/* 2274 */     return type.equals(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*      */     String prefix;
/* 2280 */     if (getName() != null) {
/* 2281 */       return "T=" + QNameHelper.pretty(getName());
/*      */     }
/* 2283 */     if (isDocumentType()) {
/* 2284 */       return "D=" + QNameHelper.pretty(getDocumentElementName());
/*      */     }
/* 2286 */     if (isAttributeType()) {
/* 2287 */       return "R=" + QNameHelper.pretty(getAttributeTypeAttributeName());
/*      */     }
/*      */ 
/*      */     
/* 2291 */     if (getContainerField() != null) {
/*      */       
/* 2293 */       prefix = ((getContainerField().getName().getNamespaceURI().length() > 0) ? (getContainerField().isAttribute() ? "Q=" : "E=") : (getContainerField().isAttribute() ? "A=" : "U=")) + getContainerField().getName().getLocalPart();
/*      */ 
/*      */ 
/*      */       
/* 2297 */       if (getOuterType() == null)
/* 2298 */         return prefix + "@" + getContainerField().getName().getNamespaceURI(); 
/*      */     } else {
/* 2300 */       if (isNoType())
/* 2301 */         return "N="; 
/* 2302 */       if (getOuterType() == null)
/* 2303 */         return "noouter"; 
/* 2304 */       if (getOuterType().getBaseType() == this) {
/* 2305 */         prefix = "B=";
/* 2306 */       } else if (getOuterType().getContentBasedOnType() == this) {
/* 2307 */         prefix = "S=";
/* 2308 */       } else if (getOuterType().getSimpleVariety() == 3) {
/* 2309 */         prefix = "I=";
/* 2310 */       } else if (getOuterType().getSimpleVariety() == 2) {
/* 2311 */         prefix = "M=" + getAnonymousUnionMemberOrdinal();
/*      */       } else {
/* 2313 */         prefix = "strange=";
/*      */       } 
/* 2315 */     }  return prefix + "|" + getOuterType().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParseContext(XmlObject parseObject, String targetNamespace, boolean chameleon, String elemFormDefault, String attFormDefault, boolean redefinition) {
/* 2327 */     this._parseObject = parseObject;
/* 2328 */     this._parseTNS = targetNamespace;
/* 2329 */     this._chameleon = chameleon;
/* 2330 */     this._elemFormDefault = elemFormDefault;
/* 2331 */     this._attFormDefault = attFormDefault;
/* 2332 */     this._redefinition = redefinition;
/*      */   }
/*      */   
/*      */   public XmlObject getParseObject() {
/* 2336 */     return this._parseObject;
/*      */   }
/*      */   public String getTargetNamespace() {
/* 2339 */     return this._parseTNS;
/*      */   }
/*      */   public boolean isChameleon() {
/* 2342 */     return this._chameleon;
/*      */   }
/*      */   public String getElemFormDefault() {
/* 2345 */     return this._elemFormDefault;
/*      */   }
/*      */   public String getAttFormDefault() {
/* 2348 */     return this._attFormDefault;
/*      */   }
/*      */   public String getChameleonNamespace() {
/* 2351 */     return this._chameleon ? this._parseTNS : null;
/*      */   }
/*      */   public boolean isRedefinition() {
/* 2354 */     return this._redefinition;
/*      */   }
/* 2356 */   SchemaTypeImpl(SchemaContainer container) { this._selfref = new SchemaType.Ref(this); this._container = container; } SchemaTypeImpl(SchemaContainer container, boolean unloaded) { this._selfref = new SchemaType.Ref(this); this._container = container;
/*      */     this._unloaded = unloaded;
/*      */     if (unloaded)
/* 2359 */       finishQuick();  } public SchemaType.Ref getRef() { return this._selfref; }
/*      */   
/*      */   public SchemaComponent.Ref getComponentRef() {
/* 2362 */     return (SchemaComponent.Ref)getRef();
/*      */   }
/*      */ 
/*      */   
/*      */   private static class SequencerImpl
/*      */     implements SchemaTypeElementSequencer
/*      */   {
/*      */     private SchemaTypeVisitorImpl _visitor;
/*      */ 
/*      */     
/*      */     private SequencerImpl(SchemaTypeVisitorImpl visitor) {
/* 2373 */       this._visitor = visitor;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean next(QName elementName) {
/* 2378 */       if (this._visitor == null) {
/* 2379 */         return false;
/*      */       }
/* 2381 */       return this._visitor.visit(elementName);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean peek(QName elementName) {
/* 2386 */       if (this._visitor == null) {
/* 2387 */         return false;
/*      */       }
/* 2389 */       return this._visitor.testValid(elementName);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QNameSet qnameSetForWildcardElements() {
/* 2408 */     SchemaParticle model = getContentModel();
/* 2409 */     QNameSetBuilder wildcardSet = new QNameSetBuilder();
/* 2410 */     computeWildcardSet(model, wildcardSet);
/*      */     
/* 2412 */     QNameSetBuilder qnsb = new QNameSetBuilder((QNameSetSpecification)wildcardSet);
/* 2413 */     SchemaProperty[] props = getElementProperties();
/*      */     
/* 2415 */     for (int i = 0; i < props.length; i++) {
/*      */       
/* 2417 */       SchemaProperty prop = props[i];
/* 2418 */       qnsb.remove(prop.getName());
/*      */     } 
/*      */     
/* 2421 */     return qnsb.toQNameSet();
/*      */   }
/*      */ 
/*      */   
/*      */   private static void computeWildcardSet(SchemaParticle model, QNameSetBuilder result) {
/* 2426 */     if (model.getParticleType() == 5) {
/*      */       
/* 2428 */       QNameSet cws = model.getWildcardSet();
/* 2429 */       result.addAll((QNameSetSpecification)cws);
/*      */       return;
/*      */     } 
/* 2432 */     for (int i = 0; i < model.countOfParticleChild(); i++) {
/*      */       
/* 2434 */       SchemaParticle child = model.getParticleChild(i);
/* 2435 */       computeWildcardSet(child, result);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QNameSet qnameSetForWildcardAttributes() {
/* 2453 */     SchemaAttributeModel model = getAttributeModel();
/* 2454 */     QNameSet wildcardSet = model.getWildcardSet();
/*      */     
/* 2456 */     if (wildcardSet == null) {
/* 2457 */       return QNameSet.EMPTY;
/*      */     }
/* 2459 */     QNameSetBuilder qnsb = new QNameSetBuilder((QNameSetSpecification)wildcardSet);
/*      */     
/* 2461 */     SchemaProperty[] props = getAttributeProperties();
/*      */     
/* 2463 */     for (int i = 0; i < props.length; i++) {
/*      */       
/* 2465 */       SchemaProperty prop = props[i];
/* 2466 */       qnsb.remove(prop.getName());
/*      */     } 
/*      */     
/* 2469 */     return qnsb.toQNameSet();
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaTypeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */