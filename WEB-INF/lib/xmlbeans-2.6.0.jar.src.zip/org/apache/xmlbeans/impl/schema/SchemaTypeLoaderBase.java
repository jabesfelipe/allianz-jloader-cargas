/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.DigestInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaAttributeGroup;
/*     */ import org.apache.xmlbeans.SchemaField;
/*     */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*     */ import org.apache.xmlbeans.SchemaGlobalElement;
/*     */ import org.apache.xmlbeans.SchemaModelGroup;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlFactoryHook;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlSaxHandler;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.store.Locale;
/*     */ import org.apache.xmlbeans.impl.validator.ValidatingXMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SchemaTypeLoaderBase
/*     */   implements SchemaTypeLoader
/*     */ {
/*  64 */   private static final String USER_AGENT = "XMLBeans/" + XmlBeans.getVersion() + " (" + XmlBeans.getTitle() + ")";
/*     */   
/*  66 */   private static final Method _pathCompiler = getMethod("org.apache.xmlbeans.impl.store.Path", "compilePath", new Class[] { String.class, XmlOptions.class });
/*  67 */   private static final Method _queryCompiler = getMethod("org.apache.xmlbeans.impl.store.Query", "compileQuery", new Class[] { String.class, XmlOptions.class });
/*     */   
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   private static Method getMethod(String className, String methodName, Class[] args) {
/*     */     try {
/*  73 */       return Class.forName(className).getDeclaredMethod(methodName, args);
/*     */ 
/*     */     
/*     */     }
/*  77 */     catch (Exception e) {
/*     */       
/*  79 */       throw new IllegalStateException("Cannot find " + className + "." + methodName + ".  verify that xmlstore " + "(from xbean.jar) is on classpath");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object invokeMethod(Method method, Object[] args) {
/*     */     try {
/*  90 */       return method.invoke(method, args);
/*     */     }
/*  92 */     catch (InvocationTargetException e) {
/*     */       
/*  94 */       Throwable t = e.getCause();
/*  95 */       IllegalStateException ise = new IllegalStateException(t.getMessage());
/*  96 */       ise.initCause(t);
/*  97 */       throw ise;
/*     */     }
/*  99 */     catch (Exception e) {
/*     */       
/* 101 */       IllegalStateException ise = new IllegalStateException(e.getMessage());
/* 102 */       ise.initCause(e);
/* 103 */       throw ise;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String doCompilePath(String pathExpr, XmlOptions options) {
/* 109 */     return (String)invokeMethod(_pathCompiler, new Object[] { pathExpr, options });
/*     */   }
/*     */ 
/*     */   
/*     */   private static String doCompileQuery(String queryExpr, XmlOptions options) {
/* 114 */     return (String)invokeMethod(_queryCompiler, new Object[] { queryExpr, options });
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType findType(QName name) {
/* 119 */     SchemaType.Ref ref = findTypeRef(name);
/* 120 */     if (ref == null)
/* 121 */       return null; 
/* 122 */     SchemaType result = ref.get();
/* 123 */     assert result != null;
/* 124 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType findDocumentType(QName name) {
/* 129 */     SchemaType.Ref ref = findDocumentTypeRef(name);
/* 130 */     if (ref == null)
/* 131 */       return null; 
/* 132 */     SchemaType result = ref.get();
/* 133 */     assert result != null;
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType findAttributeType(QName name) {
/* 139 */     SchemaType.Ref ref = findAttributeTypeRef(name);
/* 140 */     if (ref == null)
/* 141 */       return null; 
/* 142 */     SchemaType result = ref.get();
/* 143 */     assert result != null;
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaModelGroup findModelGroup(QName name) {
/* 149 */     SchemaModelGroup.Ref ref = findModelGroupRef(name);
/* 150 */     if (ref == null)
/* 151 */       return null; 
/* 152 */     SchemaModelGroup result = ref.get();
/* 153 */     assert result != null;
/* 154 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAttributeGroup findAttributeGroup(QName name) {
/* 159 */     SchemaAttributeGroup.Ref ref = findAttributeGroupRef(name);
/* 160 */     if (ref == null)
/* 161 */       return null; 
/* 162 */     SchemaAttributeGroup result = ref.get();
/* 163 */     assert result != null;
/* 164 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalElement findElement(QName name) {
/* 169 */     SchemaGlobalElement.Ref ref = findElementRef(name);
/* 170 */     if (ref == null)
/* 171 */       return null; 
/* 172 */     SchemaGlobalElement result = ref.get();
/* 173 */     assert result != null;
/* 174 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalAttribute findAttribute(QName name) {
/* 179 */     SchemaGlobalAttribute.Ref ref = findAttributeRef(name);
/* 180 */     if (ref == null)
/* 181 */       return null; 
/* 182 */     SchemaGlobalAttribute result = ref.get();
/* 183 */     assert result != null;
/* 184 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlObject newInstance(SchemaType type, XmlOptions options) {
/* 193 */     XmlFactoryHook hook = XmlFactoryHook.ThreadContext.getHook();
/*     */     
/* 195 */     if (hook != null) {
/* 196 */       return hook.newInstance(this, type, options);
/*     */     }
/* 198 */     return Locale.newInstance(this, type, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlObject parse(String xmlText, SchemaType type, XmlOptions options) throws XmlException {
/* 203 */     XmlFactoryHook hook = XmlFactoryHook.ThreadContext.getHook();
/*     */     
/* 205 */     if (hook != null) {
/* 206 */       return hook.parse(this, xmlText, type, options);
/*     */     }
/* 208 */     return Locale.parseToXmlObject(this, xmlText, type, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlObject parse(XMLInputStream xis, SchemaType type, XmlOptions options) throws XmlException, XMLStreamException {
/* 216 */     XmlFactoryHook hook = XmlFactoryHook.ThreadContext.getHook();
/*     */     
/* 218 */     if (hook != null) {
/* 219 */       return hook.parse(this, xis, type, options);
/*     */     }
/* 221 */     return Locale.parseToXmlObject(this, xis, type, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlObject parse(XMLStreamReader xsr, SchemaType type, XmlOptions options) throws XmlException {
/* 226 */     XmlFactoryHook hook = XmlFactoryHook.ThreadContext.getHook();
/*     */     
/* 228 */     if (hook != null) {
/* 229 */       return hook.parse(this, xsr, type, options);
/*     */     }
/* 231 */     return Locale.parseToXmlObject(this, xsr, type, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlObject parse(File file, SchemaType type, XmlOptions options) throws XmlException, IOException {
/* 236 */     if (options == null) {
/*     */       
/* 238 */       options = new XmlOptions();
/* 239 */       options.put("DOCUMENT_SOURCE_NAME", file.toURI().normalize().toString());
/*     */     
/*     */     }
/* 242 */     else if (!options.hasOption("DOCUMENT_SOURCE_NAME")) {
/*     */       
/* 244 */       options = new XmlOptions(options);
/* 245 */       options.put("DOCUMENT_SOURCE_NAME", file.toURI().normalize().toString());
/*     */     } 
/*     */     
/* 248 */     InputStream fis = new FileInputStream(file);
/*     */ 
/*     */     
/*     */     try {
/* 252 */       return parse(fis, type, options);
/*     */     }
/*     */     finally {
/*     */       
/* 256 */       fis.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlObject parse(URL url, SchemaType type, XmlOptions options) throws XmlException, IOException {
/* 262 */     if (options == null) {
/*     */       
/* 264 */       options = new XmlOptions();
/* 265 */       options.put("DOCUMENT_SOURCE_NAME", url.toString());
/*     */     
/*     */     }
/* 268 */     else if (!options.hasOption("DOCUMENT_SOURCE_NAME")) {
/*     */       
/* 270 */       options = new XmlOptions(options);
/* 271 */       options.put("DOCUMENT_SOURCE_NAME", url.toString());
/*     */     } 
/*     */     
/* 274 */     URLConnection conn = null;
/* 275 */     InputStream stream = null;
/*     */ 
/*     */     
/*     */     try {
/* 279 */       boolean redirected = false;
/* 280 */       int count = 0;
/*     */       
/*     */       do {
/* 283 */         conn = url.openConnection();
/* 284 */         conn.addRequestProperty("User-Agent", USER_AGENT);
/* 285 */         conn.addRequestProperty("Accept", "application/xml, text/xml, */*");
/* 286 */         if (!(conn instanceof HttpURLConnection))
/*     */           continue; 
/* 288 */         HttpURLConnection httpcon = (HttpURLConnection)conn;
/* 289 */         int code = httpcon.getResponseCode();
/* 290 */         redirected = (code == 301 || code == 302);
/* 291 */         if (redirected && count > 5) {
/* 292 */           redirected = false;
/*     */         }
/* 294 */         if (!redirected)
/*     */           continue; 
/* 296 */         String newLocation = httpcon.getHeaderField("Location");
/* 297 */         if (newLocation == null) {
/* 298 */           redirected = false;
/*     */         } else {
/*     */           
/* 301 */           url = new URL(newLocation);
/* 302 */           count++;
/*     */         }
/*     */       
/*     */       }
/* 306 */       while (redirected);
/*     */       
/* 308 */       stream = conn.getInputStream();
/* 309 */       return parse(stream, type, options);
/*     */     }
/*     */     finally {
/*     */       
/* 313 */       if (stream != null) {
/* 314 */         stream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public XmlObject parse(InputStream jiois, SchemaType type, XmlOptions options) throws XmlException, IOException {
/* 320 */     XmlFactoryHook hook = XmlFactoryHook.ThreadContext.getHook();
/*     */     
/* 322 */     DigestInputStream digestStream = null;
/*     */ 
/*     */     
/* 325 */     if (options != null && options.hasOption("LOAD_MESSAGE_DIGEST")) {
/*     */       MessageDigest sha;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 331 */         sha = MessageDigest.getInstance("SHA");
/*     */       }
/* 333 */       catch (NoSuchAlgorithmException e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 338 */       digestStream = new DigestInputStream(jiois, sha);
/* 339 */       jiois = digestStream;
/*     */     } 
/*     */     
/* 342 */     if (hook != null) {
/* 343 */       return hook.parse(this, jiois, type, options);
/*     */     }
/* 345 */     XmlObject result = Locale.parseToXmlObject(this, jiois, type, options);
/*     */     
/* 347 */     if (digestStream != null) {
/* 348 */       result.documentProperties().setMessageDigest(digestStream.getMessageDigest().digest());
/*     */     }
/* 350 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlObject parse(Reader jior, SchemaType type, XmlOptions options) throws XmlException, IOException {
/* 355 */     XmlFactoryHook hook = XmlFactoryHook.ThreadContext.getHook();
/*     */     
/* 357 */     if (hook != null) {
/* 358 */       return hook.parse(this, jior, type, options);
/*     */     }
/* 360 */     return Locale.parseToXmlObject(this, jior, type, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlObject parse(Node node, SchemaType type, XmlOptions options) throws XmlException {
/* 365 */     XmlFactoryHook hook = XmlFactoryHook.ThreadContext.getHook();
/*     */     
/* 367 */     if (hook != null) {
/* 368 */       return hook.parse(this, node, type, options);
/*     */     }
/* 370 */     return Locale.parseToXmlObject(this, node, type, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlSaxHandler newXmlSaxHandler(SchemaType type, XmlOptions options) {
/* 375 */     XmlFactoryHook hook = XmlFactoryHook.ThreadContext.getHook();
/*     */     
/* 377 */     if (hook != null) {
/* 378 */       return hook.newXmlSaxHandler(this, type, options);
/*     */     }
/* 380 */     return Locale.newSaxHandler(this, type, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public DOMImplementation newDomImplementation(XmlOptions options) {
/* 385 */     return Locale.newDomImplementation(this, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, SchemaType type, XmlOptions options) throws XmlException, XMLStreamException {
/* 393 */     return (XMLInputStream)new ValidatingXMLInputStream(xis, this, type, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String compilePath(String pathExpr) {
/* 402 */     return compilePath(pathExpr, (XmlOptions)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String compilePath(String pathExpr, XmlOptions options) {
/* 407 */     return doCompilePath(pathExpr, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public String compileQuery(String queryExpr) {
/* 412 */     return compileQuery(queryExpr, (XmlOptions)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String compileQuery(String queryExpr, XmlOptions options) {
/* 417 */     return doCompileQuery(queryExpr, options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaType typeForSignature(String signature) {
/*     */     String uri;
/* 427 */     int end = signature.indexOf('@');
/*     */ 
/*     */     
/* 430 */     if (end < 0) {
/*     */       
/* 432 */       uri = "";
/* 433 */       end = signature.length();
/*     */     }
/*     */     else {
/*     */       
/* 437 */       uri = signature.substring(end + 1);
/*     */     } 
/*     */     
/* 440 */     List parts = new ArrayList();
/*     */     int index;
/* 442 */     for (index = 0; index < end; ) {
/*     */       
/* 444 */       int nextc = signature.indexOf(':', index);
/* 445 */       int nextd = signature.indexOf('|', index);
/* 446 */       int next = (nextc < 0) ? nextd : ((nextd < 0) ? nextc : ((nextc < nextd) ? nextc : nextd));
/* 447 */       if (next < 0 || next > end)
/* 448 */         next = end; 
/* 449 */       String part = signature.substring(index, next);
/* 450 */       parts.add(part);
/* 451 */       index = next + 1;
/*     */     } 
/*     */     
/* 454 */     SchemaType curType = null;
/*     */     
/* 456 */     for (int i = parts.size() - 1; i >= 0; i--) {
/*     */       SchemaGlobalElement elt; SchemaGlobalAttribute attr; SchemaType[] subTypes; int j; SchemaType[] arrayOfSchemaType1;
/* 458 */       String part = parts.get(i);
/* 459 */       if (part.length() < 1)
/* 460 */         throw new IllegalArgumentException(); 
/* 461 */       int offset = (part.length() >= 2 && part.charAt(1) == '=') ? 2 : 1;
/* 462 */       switch (part.charAt(0)) {
/*     */         
/*     */         case 'T':
/* 465 */           if (curType != null)
/* 466 */             throw new IllegalArgumentException(); 
/* 467 */           curType = findType(QNameHelper.forLNS(part.substring(offset), uri));
/* 468 */           if (curType == null) {
/* 469 */             return null;
/*     */           }
/*     */           break;
/*     */         case 'D':
/* 473 */           if (curType != null)
/* 474 */             throw new IllegalArgumentException(); 
/* 475 */           curType = findDocumentType(QNameHelper.forLNS(part.substring(offset), uri));
/* 476 */           if (curType == null) {
/* 477 */             return null;
/*     */           }
/*     */           break;
/*     */         case 'C':
/*     */         case 'R':
/* 482 */           if (curType != null)
/* 483 */             throw new IllegalArgumentException(); 
/* 484 */           curType = findAttributeType(QNameHelper.forLNS(part.substring(offset), uri));
/* 485 */           if (curType == null) {
/* 486 */             return null;
/*     */           }
/*     */           break;
/*     */         case 'E':
/*     */         case 'U':
/* 491 */           if (curType != null) {
/*     */             
/* 493 */             if (curType.getContentType() < 3)
/* 494 */               return null; 
/* 495 */             SchemaType[] arrayOfSchemaType = curType.getAnonymousTypes();
/* 496 */             String localName = part.substring(offset);
/* 497 */             int k = 0; while (true) { if (k < arrayOfSchemaType.length) {
/*     */                 
/* 499 */                 SchemaField field = arrayOfSchemaType[k].getContainerField();
/* 500 */                 if (field != null && !field.isAttribute() && field.getName().getLocalPart().equals(localName)) {
/*     */                   
/* 502 */                   curType = arrayOfSchemaType[k]; break;
/*     */                 }  k++;
/*     */                 continue;
/*     */               } 
/* 506 */               return null; }
/*     */             
/*     */             break;
/*     */           } 
/* 510 */           elt = findElement(QNameHelper.forLNS(part.substring(offset), uri));
/* 511 */           if (elt == null)
/* 512 */             return null; 
/* 513 */           curType = elt.getType();
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'A':
/*     */         case 'Q':
/* 519 */           if (curType != null) {
/*     */             
/* 521 */             if (curType.isSimpleType())
/* 522 */               return null; 
/* 523 */             SchemaType[] arrayOfSchemaType = curType.getAnonymousTypes();
/* 524 */             String localName = part.substring(offset);
/* 525 */             int k = 0; while (true) { if (k < arrayOfSchemaType.length) {
/*     */                 
/* 527 */                 SchemaField field = arrayOfSchemaType[k].getContainerField();
/* 528 */                 if (field != null && field.isAttribute() && field.getName().getLocalPart().equals(localName)) {
/*     */                   
/* 530 */                   curType = arrayOfSchemaType[k]; break;
/*     */                 }  k++;
/*     */                 continue;
/*     */               } 
/* 534 */               return null; }
/*     */             
/*     */             break;
/*     */           } 
/* 538 */           attr = findAttribute(QNameHelper.forLNS(part.substring(offset), uri));
/* 539 */           if (attr == null)
/* 540 */             return null; 
/* 541 */           curType = attr.getType();
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'B':
/* 546 */           if (curType == null)
/*     */           {
/* 548 */             throw new IllegalArgumentException();
/*     */           }
/*     */ 
/*     */           
/* 552 */           if (curType.getSimpleVariety() != 1)
/* 553 */             return null; 
/* 554 */           subTypes = curType.getAnonymousTypes();
/* 555 */           if (subTypes.length != 1)
/* 556 */             return null; 
/* 557 */           curType = subTypes[0];
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'I':
/* 562 */           if (curType == null)
/*     */           {
/* 564 */             throw new IllegalArgumentException();
/*     */           }
/*     */ 
/*     */           
/* 568 */           if (curType.getSimpleVariety() != 3)
/* 569 */             return null; 
/* 570 */           subTypes = curType.getAnonymousTypes();
/* 571 */           if (subTypes.length != 1)
/* 572 */             return null; 
/* 573 */           curType = subTypes[0];
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'M':
/* 578 */           if (curType == null)
/*     */           {
/* 580 */             throw new IllegalArgumentException();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 587 */             j = Integer.parseInt(part.substring(offset));
/*     */           }
/* 589 */           catch (Exception e) {
/*     */             
/* 591 */             throw new IllegalArgumentException();
/*     */           } 
/*     */           
/* 594 */           if (curType.getSimpleVariety() != 2)
/* 595 */             return null; 
/* 596 */           arrayOfSchemaType1 = curType.getAnonymousTypes();
/* 597 */           if (arrayOfSchemaType1.length <= j)
/* 598 */             return null; 
/* 599 */           curType = arrayOfSchemaType1[j];
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 604 */           throw new IllegalArgumentException();
/*     */       } 
/*     */     } 
/* 607 */     return curType;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaTypeLoaderBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */