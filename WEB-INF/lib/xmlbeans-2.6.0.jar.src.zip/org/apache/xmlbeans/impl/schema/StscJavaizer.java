/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.BindingConfig;
/*     */ import org.apache.xmlbeans.InterfaceExtension;
/*     */ import org.apache.xmlbeans.PrePostExtension;
/*     */ import org.apache.xmlbeans.SchemaField;
/*     */ import org.apache.xmlbeans.SchemaProperty;
/*     */ import org.apache.xmlbeans.SchemaStringEnumEntry;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.UserType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.NameUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StscJavaizer
/*     */ {
/*     */   private static final int MAX_ENUM_COUNT = 3668;
/*     */   
/*     */   public static void javaizeAllTypes(boolean javaize) {
/*  54 */     StscState state = StscState.get();
/*     */     
/*  56 */     List allSeenTypes = new ArrayList();
/*  57 */     allSeenTypes.addAll(Arrays.asList(state.documentTypes()));
/*  58 */     allSeenTypes.addAll(Arrays.asList(state.attributeTypes()));
/*  59 */     allSeenTypes.addAll(Arrays.asList(state.globalTypes()));
/*     */ 
/*     */     
/*  62 */     if (javaize) {
/*  63 */       assignGlobalJavaNames(allSeenTypes);
/*     */     }
/*     */     
/*  66 */     for (int i = 0; i < allSeenTypes.size(); i++) {
/*     */       
/*  68 */       SchemaType gType = allSeenTypes.get(i);
/*  69 */       if (javaize) {
/*     */         
/*  71 */         javaizeType((SchemaTypeImpl)gType);
/*  72 */         String className = gType.getFullJavaName();
/*  73 */         if (className != null) {
/*  74 */           state.addClassname(className.replace('$', '.'), gType);
/*     */         }
/*     */       } else {
/*  77 */         skipJavaizingType((SchemaTypeImpl)gType);
/*  78 */       }  allSeenTypes.addAll(Arrays.asList(gType.getAnonymousTypes()));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  83 */       addAnonymousTypesFromRedefinition(gType, allSeenTypes);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void assignGlobalJavaNames(Collection schemaTypes) {
/*  89 */     HashSet usedNames = new HashSet();
/*  90 */     StscState state = StscState.get();
/*     */     
/*  92 */     for (Iterator i = schemaTypes.iterator(); i.hasNext(); ) {
/*     */       
/*  94 */       SchemaTypeImpl sImpl = i.next();
/*  95 */       QName topName = findTopName(sImpl);
/*  96 */       String pickedName = state.getJavaname(topName, sImpl.isDocumentType() ? 2 : 1);
/*     */       
/*  98 */       if (sImpl.isUnjavaized()) {
/*     */         
/* 100 */         sImpl.setFullJavaName(pickFullJavaClassName(usedNames, findTopName(sImpl), pickedName, sImpl.isDocumentType(), sImpl.isAttributeType()));
/* 101 */         sImpl.setFullJavaImplName(pickFullJavaImplName(usedNames, sImpl.getFullJavaName()));
/*     */         
/* 103 */         setUserTypes(sImpl, state);
/*     */         
/* 105 */         setExtensions(sImpl, state);
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     verifyInterfaceNameCollisions(usedNames, state);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void verifyInterfaceNameCollisions(Set usedNames, StscState state) {
/* 114 */     BindingConfig config = state.getBindingConfig();
/* 115 */     if (config == null) {
/*     */       return;
/*     */     }
/* 118 */     InterfaceExtension[] exts = config.getInterfaceExtensions();
/* 119 */     for (int i = 0; i < exts.length; i++) {
/*     */       
/* 121 */       if (usedNames.contains(exts[i].getInterface().toLowerCase())) {
/* 122 */         state.error("InterfaceExtension interface '" + exts[i].getInterface() + "' creates a name collision with one of the generated interfaces or classes.", 0, (XmlObject)null);
/*     */       }
/* 124 */       String handler = exts[i].getStaticHandler();
/* 125 */       if (handler != null && usedNames.contains(handler.toLowerCase())) {
/* 126 */         state.error("InterfaceExtension handler class '" + handler + "' creates a name collision with one of the generated interfaces or classes.", 0, (XmlObject)null);
/*     */       }
/*     */     } 
/* 129 */     PrePostExtension[] prepost = config.getPrePostExtensions();
/* 130 */     for (int j = 0; j < prepost.length; j++) {
/*     */       
/* 132 */       String handler = prepost[j].getStaticHandler();
/* 133 */       if (handler != null && usedNames.contains(handler.toLowerCase())) {
/* 134 */         state.error("PrePostExtension handler class '" + handler + "' creates a name collision with one of the generated interfaces or classes.", 0, (XmlObject)null);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void setUserTypes(SchemaTypeImpl sImpl, StscState state) {
/* 140 */     BindingConfig config = state.getBindingConfig();
/*     */     
/* 142 */     if (config != null) {
/*     */       
/* 144 */       UserType utype = config.lookupUserTypeForQName(sImpl.getName());
/* 145 */       if (utype != null) {
/*     */         
/* 147 */         sImpl.setUserTypeName(utype.getJavaName());
/* 148 */         sImpl.setUserTypeHandlerName(utype.getStaticHandler());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void setExtensions(SchemaTypeImpl sImpl, StscState state) {
/* 155 */     String javaName = sImpl.getFullJavaName();
/* 156 */     BindingConfig config = state.getBindingConfig();
/*     */     
/* 158 */     if (javaName != null && config != null) {
/*     */       
/* 160 */       sImpl.setInterfaceExtensions(config.getInterfaceExtensions(javaName));
/* 161 */       sImpl.setPrePostExtension(config.getPrePostExtension(javaName));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isStringType(SchemaType type) {
/* 167 */     if (type == null || type.getSimpleVariety() != 1)
/* 168 */       return false; 
/* 169 */     return (type.getPrimitiveType().getBuiltinTypeCode() == 12);
/*     */   }
/*     */ 
/*     */   
/*     */   static String pickConstantName(Set usedNames, String words) {
/* 174 */     String base = NameUtil.upperCaseUnderbar(words);
/*     */     
/* 176 */     if (base.length() == 0)
/*     */     {
/* 178 */       base = "X";
/*     */     }
/*     */     
/* 181 */     if (base.startsWith("INT_"))
/*     */     {
/* 183 */       base = "X_" + base;
/*     */     }
/*     */ 
/*     */     
/* 187 */     int index = 1; String uniqName;
/* 188 */     for (uniqName = base; usedNames.contains(uniqName); ) {
/*     */       
/* 190 */       index++;
/* 191 */       uniqName = base + "_" + index;
/*     */     } 
/*     */     
/* 194 */     usedNames.add(uniqName);
/*     */     
/* 196 */     return uniqName;
/*     */   }
/*     */ 
/*     */   
/*     */   static void skipJavaizingType(SchemaTypeImpl sImpl) {
/* 201 */     if (sImpl.isJavaized()) {
/*     */       return;
/*     */     }
/* 204 */     SchemaTypeImpl baseType = (SchemaTypeImpl)sImpl.getBaseType();
/* 205 */     if (baseType != null) {
/* 206 */       skipJavaizingType(baseType);
/*     */     }
/* 208 */     sImpl.startJavaizing();
/* 209 */     secondPassProcessType(sImpl);
/* 210 */     sImpl.finishJavaizing();
/*     */   }
/*     */ 
/*     */   
/*     */   static void secondPassProcessType(SchemaTypeImpl sImpl) {
/* 215 */     if (isStringType(sImpl)) {
/*     */       
/* 217 */       XmlAnySimpleType[] enumVals = sImpl.getEnumerationValues();
/*     */ 
/*     */ 
/*     */       
/* 221 */       if (enumVals != null)
/*     */       {
/*     */         
/* 224 */         if (enumVals.length > 3668) {
/*     */           
/* 226 */           StscState.get().warning("SchemaType Enumeration found with too many enumeration values to create a Java enumeration. The base SchemaType \"" + sImpl.getBaseEnumType() + "\" will be used instead", 1, (XmlObject)null);
/*     */ 
/*     */ 
/*     */           
/* 230 */           sImpl = (SchemaTypeImpl)sImpl.getBaseEnumType();
/*     */         }
/*     */         else {
/*     */           
/* 234 */           SchemaStringEnumEntry[] entryArray = new SchemaStringEnumEntry[enumVals.length];
/* 235 */           SchemaType basedOn = sImpl.getBaseEnumType();
/* 236 */           if (basedOn == sImpl) {
/*     */             
/* 238 */             Set usedNames = new HashSet();
/* 239 */             for (int i = 0; i < enumVals.length; i++)
/*     */             {
/* 241 */               String val = enumVals[i].getStringValue();
/*     */               
/* 243 */               entryArray[i] = new SchemaStringEnumEntryImpl(val, i + 1, pickConstantName(usedNames, val));
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 248 */             for (int i = 0; i < enumVals.length; i++) {
/*     */               
/* 250 */               String val = enumVals[i].getStringValue();
/* 251 */               entryArray[i] = basedOn.enumEntryForString(val);
/*     */             } 
/*     */           } 
/* 254 */           sImpl.setStringEnumEntries(entryArray);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void javaizeType(SchemaTypeImpl sImpl) {
/* 262 */     if (sImpl.isJavaized()) {
/*     */       return;
/*     */     }
/* 265 */     SchemaTypeImpl baseType = (SchemaTypeImpl)sImpl.getBaseType();
/* 266 */     if (baseType != null)
/* 267 */       javaizeType(baseType); 
/* 268 */     if (sImpl.getContentBasedOnType() != null && sImpl.getContentBasedOnType() != baseType) {
/* 269 */       javaizeType((SchemaTypeImpl)sImpl.getContentBasedOnType());
/*     */     }
/* 271 */     sImpl.startJavaizing();
/*     */     
/* 273 */     sImpl.setCompiled(true);
/*     */     
/* 275 */     secondPassProcessType(sImpl);
/*     */     
/* 277 */     if (!sImpl.isSimpleType()) {
/*     */       
/* 279 */       SchemaProperty[] eltProps = sImpl.getElementProperties();
/* 280 */       SchemaProperty[] attrProps = sImpl.getAttributeProperties();
/*     */ 
/*     */       
/* 283 */       Set usedPropNames = new HashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 288 */       SchemaProperty[] baseProps = baseType.getProperties();
/* 289 */       for (int i = 0; i < baseProps.length; i++) {
/*     */         
/* 291 */         String name = baseProps[i].getJavaPropertyName();
/* 292 */         assert !usedPropNames.contains(name);
/* 293 */         usedPropNames.add(name);
/*     */       } 
/*     */ 
/*     */       
/* 297 */       avoidExtensionMethods(usedPropNames, sImpl);
/*     */       
/*     */       boolean doInherited;
/* 300 */       for (doInherited = true;; doInherited = false) {
/*     */         
/* 302 */         if (eltProps.length > 0) {
/* 303 */           assignJavaPropertyNames(usedPropNames, eltProps, baseType, doInherited);
/*     */         }
/* 305 */         assignJavaPropertyNames(usedPropNames, attrProps, baseType, doInherited);
/*     */         
/* 307 */         if (!doInherited) {
/*     */           break;
/*     */         }
/*     */       } 
/* 311 */       SchemaProperty[] allprops = sImpl.getProperties();
/*     */ 
/*     */       
/* 314 */       boolean insensitive = isPropertyModelOrderInsensitive(allprops);
/*     */ 
/*     */ 
/*     */       
/* 318 */       assignJavaTypeCodes(allprops);
/*     */       
/* 320 */       sImpl.setOrderSensitive(!insensitive);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 325 */     if (sImpl.getFullJavaName() != null || sImpl.getOuterType() != null) {
/* 326 */       assignJavaAnonymousTypeNames(sImpl);
/*     */     }
/* 328 */     sImpl.finishJavaizing();
/*     */   }
/*     */   
/* 331 */   private static final String[] PREFIXES = new String[] { "get", "xget", "isNil", "isSet", "sizeOf", "set", "xset", "addNew", "setNil", "unset", "insert", "add", "insertNew", "addNew", "remove" };
/*     */ 
/*     */ 
/*     */   
/*     */   private static void avoidExtensionMethods(Set usedPropNames, SchemaTypeImpl sImpl) {
/* 336 */     InterfaceExtension[] exts = sImpl.getInterfaceExtensions();
/* 337 */     if (exts != null) for (int i = 0; i < exts.length; i++) {
/*     */         
/* 339 */         InterfaceExtension ext = exts[i];
/* 340 */         InterfaceExtension.MethodSignature[] methods = ext.getMethods();
/* 341 */         for (int j = 0; j < methods.length; j++) {
/*     */           
/* 343 */           String methodName = methods[j].getName();
/* 344 */           for (int k = 0; k < PREFIXES.length; k++) {
/*     */             
/* 346 */             String prefix = PREFIXES[k];
/* 347 */             if (methodName.startsWith(prefix)) {
/* 348 */               usedPropNames.add(methodName.substring(prefix.length()));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   static void assignJavaAnonymousTypeNames(SchemaTypeImpl outerType) {
/* 356 */     Set usedTypeNames = new HashSet();
/* 357 */     SchemaType[] anonymousTypes = outerType.getAnonymousTypes();
/* 358 */     StscState state = StscState.get();
/*     */     
/* 360 */     int nrOfAnonTypes = anonymousTypes.length;
/* 361 */     if (outerType.isRedefinition()) {
/*     */ 
/*     */ 
/*     */       
/* 365 */       ArrayList list = new ArrayList();
/* 366 */       addAnonymousTypesFromRedefinition(outerType, list);
/* 367 */       if (list.size() > 0) {
/*     */         
/* 369 */         SchemaType[] temp = new SchemaType[nrOfAnonTypes + list.size()];
/* 370 */         list.toArray((Object[])temp);
/* 371 */         System.arraycopy(anonymousTypes, 0, temp, list.size(), nrOfAnonTypes);
/* 372 */         anonymousTypes = temp;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 380 */     SchemaType scanOuterType = outerType;
/* 381 */     for (; scanOuterType != null; 
/* 382 */       scanOuterType = scanOuterType.getOuterType())
/*     */     {
/* 384 */       usedTypeNames.add(scanOuterType.getShortJavaName());
/*     */     }
/*     */     
/* 387 */     scanOuterType = outerType;
/* 388 */     for (; scanOuterType != null; 
/* 389 */       scanOuterType = scanOuterType.getOuterType())
/*     */     {
/* 391 */       usedTypeNames.add(scanOuterType.getShortJavaImplName());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 397 */     usedTypeNames.add(getOutermostPackage(outerType.getFullJavaName()));
/*     */ 
/*     */     
/* 400 */     for (int i = 0; i < anonymousTypes.length; i++) {
/*     */       
/* 402 */       SchemaTypeImpl sImpl = (SchemaTypeImpl)anonymousTypes[i];
/* 403 */       if (sImpl != null)
/*     */       {
/* 405 */         if (!sImpl.isSkippedAnonymousType()) {
/*     */           
/* 407 */           String localname = null;
/* 408 */           String javaname = null;
/*     */           
/* 410 */           SchemaField containerField = sImpl.getContainerField();
/* 411 */           if (containerField != null) {
/*     */             
/* 413 */             QName qname = sImpl.getContainerField().getName();
/* 414 */             localname = qname.getLocalPart();
/* 415 */             javaname = state.getJavaname(sImpl.getContainerField().getName(), 1);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 420 */             switch (sImpl.getOuterType().getSimpleVariety()) {
/*     */               
/*     */               case 2:
/* 423 */                 javaname = "Member"; break;
/*     */               case 3:
/* 425 */                 javaname = "Item";
/*     */                 break;
/*     */               default:
/* 428 */                 assert false : "Weird type " + sImpl.toString();
/* 429 */                 javaname = "Base";
/*     */                 break;
/*     */             } 
/*     */           } 
/* 433 */           if (i < nrOfAnonTypes) {
/*     */             
/* 435 */             sImpl.setShortJavaName(pickInnerJavaClassName(usedTypeNames, localname, javaname));
/*     */             
/* 437 */             sImpl.setShortJavaImplName(pickInnerJavaImplName(usedTypeNames, localname, (javaname == null) ? null : (javaname + "Impl")));
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 444 */             sImpl.setFullJavaName(outerType.getFullJavaName() + "$" + pickInnerJavaClassName(usedTypeNames, localname, javaname));
/*     */             
/* 446 */             sImpl.setFullJavaImplName(outerType.getFullJavaImplName() + "$" + pickInnerJavaImplName(usedTypeNames, localname, (javaname == null) ? null : (javaname + "Impl")));
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 451 */           setExtensions(sImpl, state);
/*     */         }  } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static void assignJavaPropertyNames(Set usedNames, SchemaProperty[] props, SchemaType baseType, boolean doInherited) {
/* 457 */     StscState state = StscState.get();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 466 */     for (int i = 0; i < props.length; i++) {
/*     */       
/* 468 */       SchemaPropertyImpl sImpl = (SchemaPropertyImpl)props[i];
/*     */       
/* 470 */       SchemaProperty baseProp = sImpl.isAttribute() ? baseType.getAttributeProperty(sImpl.getName()) : baseType.getElementProperty(sImpl.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 475 */       if (((baseProp != null)) == doInherited) {
/*     */         String theName;
/*     */         
/* 478 */         QName propQName = sImpl.getName();
/*     */ 
/*     */ 
/*     */         
/* 482 */         if (baseProp == null) {
/* 483 */           theName = pickJavaPropertyName(usedNames, propQName.getLocalPart(), state.getJavaname(propQName, sImpl.isAttribute() ? 4 : 3));
/*     */         }
/*     */         else {
/*     */           
/* 487 */           theName = baseProp.getJavaPropertyName();
/*     */         } 
/* 489 */         sImpl.setJavaPropertyName(theName);
/*     */         
/* 491 */         boolean isArray = (sImpl.getMaxOccurs() == null || sImpl.getMaxOccurs().compareTo(BigInteger.ONE) > 0);
/*     */         
/* 493 */         boolean isSingleton = (!isArray && sImpl.getMaxOccurs().signum() > 0);
/* 494 */         boolean isOption = (isSingleton && sImpl.getMinOccurs().signum() == 0);
/* 495 */         SchemaType javaBasedOnType = sImpl.getType();
/*     */         
/* 497 */         if (baseProp != null) {
/*     */           
/* 499 */           if (baseProp.extendsJavaArray()) {
/*     */             
/* 501 */             isSingleton = false;
/* 502 */             isOption = false;
/* 503 */             isArray = true;
/*     */           } 
/* 505 */           if (baseProp.extendsJavaSingleton())
/*     */           {
/* 507 */             isSingleton = true;
/*     */           }
/* 509 */           if (baseProp.extendsJavaOption())
/*     */           {
/* 511 */             isOption = true;
/*     */           }
/* 513 */           javaBasedOnType = baseProp.javaBasedOnType();
/*     */         } 
/*     */         
/* 516 */         sImpl.setExtendsJava(javaBasedOnType.getRef(), isSingleton, isOption, isArray);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void assignJavaTypeCodes(SchemaProperty[] properties) {
/* 523 */     for (int i = 0; i < properties.length; i++) {
/*     */       
/* 525 */       SchemaPropertyImpl sImpl = (SchemaPropertyImpl)properties[i];
/* 526 */       SchemaType sType = sImpl.javaBasedOnType();
/* 527 */       sImpl.setJavaTypeCode(javaTypeCodeForType(sType));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static int javaTypeCodeInCommon(SchemaType[] types) {
/* 533 */     if (types == null || types.length == 0) {
/* 534 */       return 0;
/*     */     }
/* 536 */     int code = javaTypeCodeForType(types[0]);
/* 537 */     if (code == 19)
/* 538 */       return code; 
/* 539 */     for (int i = 1; i < types.length; i++) {
/*     */ 
/*     */       
/* 542 */       if (code != javaTypeCodeForType(types[i]))
/* 543 */         return 19; 
/*     */     } 
/* 545 */     return code;
/*     */   }
/*     */ 
/*     */   
/*     */   static int javaTypeCodeForType(SchemaType sType) {
/* 550 */     if (!sType.isSimpleType()) {
/* 551 */       return 0;
/*     */     }
/* 553 */     if (((SchemaTypeImpl)sType).getUserTypeHandlerName() != null) {
/* 554 */       return 20;
/*     */     }
/* 556 */     if (sType.getSimpleVariety() == 2) {
/*     */ 
/*     */       
/* 559 */       SchemaType baseType = sType.getUnionCommonBaseType();
/* 560 */       if (baseType != null && !baseType.isURType()) {
/* 561 */         sType = baseType;
/*     */       } else {
/* 563 */         return javaTypeCodeInCommon(sType.getUnionConstituentTypes());
/*     */       } 
/*     */     } 
/* 566 */     if (sType.getSimpleVariety() == 3) {
/* 567 */       return 16;
/*     */     }
/* 569 */     if (sType.isURType()) {
/* 570 */       return 0;
/*     */     }
/* 572 */     switch (sType.getPrimitiveType().getBuiltinTypeCode()) {
/*     */ 
/*     */       
/*     */       case 2:
/* 576 */         return 10;
/*     */       
/*     */       case 3:
/* 579 */         return 1;
/*     */       
/*     */       case 4:
/* 582 */         return 11;
/*     */       
/*     */       case 5:
/* 585 */         return 11;
/*     */       
/*     */       case 6:
/* 588 */         return 10;
/*     */       
/*     */       case 7:
/* 591 */         return 15;
/*     */       
/*     */       case 8:
/* 594 */         return 0;
/*     */       
/*     */       case 9:
/* 597 */         return 2;
/*     */       
/*     */       case 10:
/* 600 */         return 3;
/*     */       
/*     */       case 11:
/* 603 */         switch (sType.getDecimalSize()) {
/*     */           
/*     */           case 8:
/* 606 */             return 4;
/*     */           case 16:
/* 608 */             return 5;
/*     */           case 32:
/* 610 */             return 6;
/*     */           case 64:
/* 612 */             return 7;
/*     */           case 1000000:
/* 614 */             return 9;
/*     */         } 
/*     */         
/* 617 */         return 8;
/*     */ 
/*     */       
/*     */       case 12:
/* 621 */         if (isStringType(sType.getBaseEnumType())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 628 */           if (sType.getEnumerationValues() != null && (sType.getEnumerationValues()).length > 3668)
/*     */           {
/*     */             
/* 631 */             return 10;
/*     */           }
/*     */ 
/*     */           
/* 635 */           return 18;
/*     */         } 
/*     */         
/* 638 */         return 10;
/*     */       
/*     */       case 13:
/* 641 */         return 13;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 14:
/*     */       case 15:
/*     */       case 16:
/*     */       case 17:
/*     */       case 18:
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/* 654 */         return 17;
/*     */     } 
/*     */     
/* 657 */     assert false : "unrecognized code " + sType.getPrimitiveType().getBuiltinTypeCode();
/* 658 */     throw new IllegalStateException("unrecognized code " + sType.getPrimitiveType().getBuiltinTypeCode() + " of " + sType.getPrimitiveType().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isPropertyModelOrderInsensitive(SchemaProperty[] properties) {
/* 664 */     for (int i = 0; i < properties.length; i++) {
/*     */       
/* 666 */       SchemaProperty prop = properties[i];
/* 667 */       if (prop.hasNillable() == 1)
/* 668 */         return false; 
/* 669 */       if (prop.hasDefault() == 1)
/* 670 */         return false; 
/* 671 */       if (prop.hasFixed() == 1)
/* 672 */         return false; 
/* 673 */       if (prop.hasDefault() != 0 && prop.getDefaultText() == null)
/*     */       {
/* 675 */         return false; } 
/*     */     } 
/* 677 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean protectReservedGlobalClassNames(String name) {
/* 682 */     int i = name.lastIndexOf('.');
/* 683 */     String lastSegment = name.substring(i + 1);
/* 684 */     if (lastSegment.endsWith("Document") && !lastSegment.equals("Document"))
/* 685 */       return true; 
/* 686 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean protectReservedInnerClassNames(String name) {
/* 691 */     return (name.equals("Enum") || name.equals("Factory"));
/*     */   }
/*     */   
/* 694 */   static String[] PROTECTED_PROPERTIES = new String[] { "StringValue", "BooleanValue", "ByteValue", "ShortValue", "IntValue", "LongValue", "BigIntegerValue", "BigDecimalValue", "FloatValue", "DoubleValue", "ByteArrayValue", "EnumValue", "CalendarValue", "DateValue", "GDateValue", "GDurationValue", "QNameValue", "ListValue", "ObjectValue", "Class" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 716 */   static Set PROTECTED_PROPERTIES_SET = new HashSet(Arrays.asList((Object[])PROTECTED_PROPERTIES));
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   static boolean protectReservedPropertyNames(String name) {
/* 720 */     return (PROTECTED_PROPERTIES_SET.contains(name) || (name.endsWith("Array") && !name.equals("Array")));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String pickFullJavaClassName(Set usedNames, QName qName, String configname, boolean isDocument, boolean isAttrType) {
/*     */     String base;
/*     */     boolean protect;
/*     */     String uniqName;
/* 729 */     if (configname != null && configname.indexOf('.') >= 0) {
/*     */ 
/*     */       
/* 732 */       base = configname;
/* 733 */       protect = protectReservedGlobalClassNames(base);
/*     */     }
/*     */     else {
/*     */       
/* 737 */       StscState state = StscState.get();
/* 738 */       String uri = qName.getNamespaceURI();
/*     */       
/* 740 */       base = NameUtil.getClassNameFromQName(qName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 746 */       String pkgPrefix = state.getPackageOverride(uri);
/*     */       
/* 748 */       if (pkgPrefix != null)
/*     */       {
/*     */ 
/*     */         
/* 752 */         base = pkgPrefix + "." + base.substring(base.lastIndexOf('.') + 1);
/*     */       }
/*     */ 
/*     */       
/* 756 */       String javaPrefix = state.getJavaPrefix(uri);
/* 757 */       if (javaPrefix != null) {
/* 758 */         base = base.substring(0, base.lastIndexOf('.') + 1) + javaPrefix + base.substring(base.lastIndexOf('.') + 1);
/*     */       }
/*     */       
/* 761 */       if (configname != null)
/*     */       {
/* 763 */         base = base.substring(0, base.lastIndexOf('.') + 1) + configname;
/*     */       }
/*     */       
/* 766 */       protect = protectReservedGlobalClassNames(base);
/* 767 */       if (configname == null) {
/*     */ 
/*     */         
/* 770 */         if (isDocument) {
/* 771 */           base = base + "Document";
/* 772 */         } else if (isAttrType) {
/* 773 */           base = base + "Attribute";
/*     */         } 
/*     */         
/* 776 */         String javaSuffix = state.getJavaSuffix(uri);
/* 777 */         if (javaSuffix != null) {
/* 778 */           base = base + javaSuffix;
/*     */         }
/*     */       } 
/*     */     } 
/* 782 */     String outermostPkg = getOutermostPackage(base);
/*     */     
/* 784 */     int index = 1;
/*     */     
/* 786 */     if (protect) {
/* 787 */       uniqName = base + index;
/*     */     } else {
/* 789 */       uniqName = base;
/* 790 */     }  while (usedNames.contains(uniqName.toLowerCase()) || uniqName.equals(outermostPkg)) {
/*     */       
/* 792 */       index++;
/* 793 */       uniqName = base + index;
/*     */     } 
/*     */     
/* 796 */     usedNames.add(uniqName.toLowerCase());
/*     */     
/* 798 */     return uniqName;
/*     */   }
/*     */ 
/*     */   
/*     */   static String getOutermostPackage(String fqcn) {
/* 803 */     if (fqcn == null) {
/* 804 */       return "";
/*     */     }
/*     */     
/* 807 */     int lastdot = fqcn.indexOf('.');
/* 808 */     if (lastdot < 0) {
/* 809 */       return "";
/*     */     }
/*     */     
/* 812 */     return fqcn.substring(0, lastdot);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String pickFullJavaImplName(Set usedNames, String intfName) {
/* 818 */     String className = intfName;
/* 819 */     String pkgName = null;
/* 820 */     int index = intfName.lastIndexOf('.');
/* 821 */     if (index >= 0) {
/*     */       
/* 823 */       className = intfName.substring(index + 1);
/* 824 */       pkgName = intfName.substring(0, index);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 829 */     String base = pkgName + ".impl." + className + "Impl";
/*     */     
/* 831 */     index = 1;
/* 832 */     String uniqName = base;
/* 833 */     while (usedNames.contains(uniqName.toLowerCase())) {
/*     */       
/* 835 */       index++;
/* 836 */       uniqName = base + index;
/*     */     } 
/*     */     
/* 839 */     usedNames.add(uniqName.toLowerCase());
/*     */     
/* 841 */     return uniqName;
/*     */   }
/*     */   
/*     */   static String pickJavaPropertyName(Set usedNames, String localName, String javaName) {
/*     */     String uniqName;
/* 846 */     if (javaName == null)
/* 847 */       javaName = NameUtil.upperCamelCase(localName); 
/* 848 */     boolean protect = protectReservedPropertyNames(javaName);
/*     */     
/* 850 */     int index = 1;
/* 851 */     if (protect) {
/* 852 */       uniqName = javaName + index;
/*     */     } else {
/* 854 */       uniqName = javaName;
/* 855 */     }  while (usedNames.contains(uniqName)) {
/*     */       
/* 857 */       index++;
/* 858 */       uniqName = javaName + index;
/*     */     } 
/*     */     
/* 861 */     usedNames.add(uniqName);
/*     */     
/* 863 */     return uniqName;
/*     */   }
/*     */   
/*     */   static String pickInnerJavaClassName(Set usedNames, String localName, String javaName) {
/*     */     String uniqName;
/* 868 */     if (javaName == null)
/* 869 */       javaName = NameUtil.upperCamelCase(localName); 
/* 870 */     boolean protect = protectReservedInnerClassNames(javaName);
/*     */     
/* 872 */     int index = 1;
/* 873 */     if (protect) {
/* 874 */       uniqName = javaName + index;
/*     */     } else {
/* 876 */       uniqName = javaName;
/* 877 */     }  while (usedNames.contains(uniqName)) {
/*     */       
/* 879 */       index++;
/* 880 */       uniqName = javaName + index;
/*     */     } 
/*     */     
/* 883 */     usedNames.add(uniqName);
/*     */     
/* 885 */     return uniqName;
/*     */   }
/*     */ 
/*     */   
/*     */   static String pickInnerJavaImplName(Set usedNames, String localName, String javaName) {
/* 890 */     if (javaName == null)
/* 891 */       javaName = NameUtil.upperCamelCase(localName) + "Impl"; 
/* 892 */     String uniqName = javaName;
/* 893 */     int index = 1;
/* 894 */     while (usedNames.contains(uniqName)) {
/*     */       
/* 896 */       index++;
/* 897 */       uniqName = javaName + index;
/*     */     } 
/*     */     
/* 900 */     usedNames.add(uniqName);
/*     */     
/* 902 */     return uniqName;
/*     */   }
/*     */ 
/*     */   
/*     */   static QName findTopName(SchemaType sType) {
/* 907 */     if (sType.getName() != null) {
/* 908 */       return sType.getName();
/*     */     }
/* 910 */     if (sType.isDocumentType()) {
/*     */ 
/*     */       
/* 913 */       if (sType.getContentModel() == null || sType.getContentModel().getParticleType() != 4)
/* 914 */         throw new IllegalStateException(); 
/* 915 */       return sType.getDocumentElementName();
/*     */     } 
/*     */     
/* 918 */     if (sType.isAttributeType()) {
/*     */       
/* 920 */       if (sType.getAttributeModel() == null || (sType.getAttributeModel().getAttributes()).length != 1)
/* 921 */         throw new IllegalStateException(); 
/* 922 */       return sType.getAttributeTypeAttributeName();
/*     */     } 
/*     */     
/* 925 */     SchemaField sElt = sType.getContainerField();
/* 926 */     assert sElt != null;
/* 927 */     assert sType.getOuterType() == null;
/* 928 */     return sElt.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   static void addAnonymousTypesFromRedefinition(SchemaType sType, List result) {
/* 933 */     while (((SchemaTypeImpl)sType).isRedefinition() && (sType.getDerivationType() == 2 || sType.isSimpleType())) {
/*     */ 
/*     */ 
/*     */       
/* 937 */       sType = sType.getBaseType();
/* 938 */       SchemaType[] newAnonTypes = sType.getAnonymousTypes();
/* 939 */       if (newAnonTypes.length > 0)
/* 940 */         result.addAll(Arrays.asList(newAnonTypes)); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\StscJavaizer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */