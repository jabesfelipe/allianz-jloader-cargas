/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.ResourceLoader;
/*     */ import org.apache.xmlbeans.SchemaAttributeGroup;
/*     */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*     */ import org.apache.xmlbeans.SchemaGlobalElement;
/*     */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*     */ import org.apache.xmlbeans.SchemaModelGroup;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.SystemCache;
/*     */ import org.apache.xmlbeans.impl.common.XBeanDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaTypeLoaderImpl
/*     */   extends SchemaTypeLoaderBase
/*     */ {
/*     */   private ResourceLoader _resourceLoader;
/*     */   private ClassLoader _classLoader;
/*     */   private SchemaTypeLoader[] _searchPath;
/*     */   private Map _classpathTypeSystems;
/*     */   private Map _classLoaderTypeSystems;
/*     */   private Map _elementCache;
/*     */   private Map _attributeCache;
/*     */   private Map _modelGroupCache;
/*     */   private Map _attributeGroupCache;
/*     */   private Map _idConstraintCache;
/*     */   private Map _typeCache;
/*     */   private Map _documentCache;
/*     */   private Map _attributeTypeCache;
/*     */   private Map _classnameCache;
/*  60 */   public static String METADATA_PACKAGE_LOAD = SchemaTypeSystemImpl.METADATA_PACKAGE_GEN;
/*  61 */   private static final Object CACHED_NOT_FOUND = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SchemaTypeLoaderCache
/*     */     extends SystemCache
/*     */   {
/*  69 */     private ThreadLocal _cachedTypeSystems = new ThreadLocal() { protected Object initialValue() {
/*  70 */           return new ArrayList();
/*     */         } private final SchemaTypeLoaderImpl.SchemaTypeLoaderCache this$0; }
/*     */     ; static final boolean $assertionsDisabled;
/*     */     public SchemaTypeLoader getFromTypeLoaderCache(ClassLoader cl) {
/*  74 */       ArrayList a = this._cachedTypeSystems.get();
/*     */       
/*  76 */       int candidate = -1;
/*  77 */       SchemaTypeLoaderImpl result = null;
/*     */       
/*  79 */       for (int i = 0; i < a.size(); i++) {
/*     */         
/*  81 */         SchemaTypeLoaderImpl tl = ((SoftReference)a.get(i)).get();
/*     */         
/*  83 */         if (tl == null) {
/*     */           
/*  85 */           assert i > candidate;
/*  86 */           a.remove(i--);
/*     */         }
/*  88 */         else if (tl._classLoader == cl) {
/*     */           
/*  90 */           assert candidate == -1 && result == null;
/*     */           
/*  92 */           candidate = i;
/*  93 */           result = tl;
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 101 */       if (candidate > 0) {
/*     */         
/* 103 */         Object t = (Object)a.get(0);
/* 104 */         a.set(0, a.get(candidate));
/* 105 */         a.set(candidate, t);
/*     */       } 
/*     */       
/* 108 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void addToTypeLoaderCache(SchemaTypeLoader stl, ClassLoader cl) {
/* 113 */       assert stl instanceof SchemaTypeLoaderImpl && ((SchemaTypeLoaderImpl)stl)._classLoader == cl;
/*     */ 
/*     */       
/* 116 */       ArrayList a = this._cachedTypeSystems.get();
/*     */       
/* 118 */       if (a.size() > 0) {
/*     */         
/* 120 */         Object t = a.get(0);
/* 121 */         a.set(0, new SoftReference(stl));
/* 122 */         a.add(t);
/*     */       } else {
/*     */         
/* 125 */         a.add(new SoftReference(stl));
/*     */       } 
/*     */     }
/*     */     private SchemaTypeLoaderCache() {} }
/*     */   
/*     */   public static SchemaTypeLoaderImpl getContextTypeLoader() {
/* 131 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 132 */     SchemaTypeLoaderImpl result = (SchemaTypeLoaderImpl)SystemCache.get().getFromTypeLoaderCache(cl);
/*     */ 
/*     */     
/* 135 */     if (result == null) {
/*     */       
/* 137 */       result = new SchemaTypeLoaderImpl(new SchemaTypeLoader[] { (SchemaTypeLoader)BuiltinSchemaTypeSystem.get() }, null, cl);
/*     */ 
/*     */       
/* 140 */       SystemCache.get().addToTypeLoaderCache(result, cl);
/*     */     } 
/*     */     
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static SchemaTypeLoader build(SchemaTypeLoader[] searchPath, ResourceLoader resourceLoader, ClassLoader classLoader) {
/* 148 */     if (searchPath == null) {
/*     */       
/* 150 */       searchPath = EMPTY_SCHEMATYPELOADER_ARRAY;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 155 */       SubLoaderList list = new SubLoaderList();
/* 156 */       for (int i = 0; i < searchPath.length; i++) {
/*     */         
/* 158 */         if (searchPath[i] == null)
/* 159 */           throw new IllegalArgumentException("searchPath[" + i + "] is null"); 
/* 160 */         if (!(searchPath[i] instanceof SchemaTypeLoaderImpl)) {
/* 161 */           list.add(searchPath[i]);
/*     */         } else {
/*     */           
/* 164 */           SchemaTypeLoaderImpl sub = (SchemaTypeLoaderImpl)searchPath[i];
/* 165 */           if (sub._classLoader != null || sub._resourceLoader != null)
/* 166 */           { list.add(sub); }
/* 167 */           else { for (int j = 0; j < sub._searchPath.length; j++)
/* 168 */               list.add(sub._searchPath[j]);  }
/*     */         
/*     */         } 
/* 171 */       }  searchPath = list.toArray();
/*     */     } 
/*     */     
/* 174 */     if (searchPath.length == 1 && resourceLoader == null && classLoader == null) {
/* 175 */       return searchPath[0];
/*     */     }
/* 177 */     return new SchemaTypeLoaderImpl(searchPath, resourceLoader, classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SubLoaderList
/*     */   {
/* 185 */     private List theList = new ArrayList();
/* 186 */     private Map seen = new IdentityHashMap();
/*     */ 
/*     */     
/*     */     private boolean add(SchemaTypeLoader loader) {
/* 190 */       if (this.seen.containsKey(loader))
/* 191 */         return false; 
/* 192 */       this.theList.add(loader);
/* 193 */       this.seen.put(loader, null);
/* 194 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     private SchemaTypeLoader[] toArray() {
/* 199 */       return (SchemaTypeLoader[])this.theList.toArray((Object[])SchemaTypeLoaderImpl.EMPTY_SCHEMATYPELOADER_ARRAY);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private SubLoaderList() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SchemaTypeLoaderImpl(SchemaTypeLoader[] searchPath, ResourceLoader resourceLoader, ClassLoader classLoader) {
/* 219 */     if (searchPath == null) {
/* 220 */       this._searchPath = EMPTY_SCHEMATYPELOADER_ARRAY;
/*     */     } else {
/* 222 */       this._searchPath = searchPath;
/* 223 */     }  this._resourceLoader = resourceLoader;
/* 224 */     this._classLoader = classLoader;
/*     */     
/* 226 */     initCaches();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void initCaches() {
/* 234 */     this._classpathTypeSystems = Collections.synchronizedMap(new HashMap());
/* 235 */     this._classLoaderTypeSystems = Collections.synchronizedMap(new HashMap());
/* 236 */     this._elementCache = Collections.synchronizedMap(new HashMap());
/* 237 */     this._attributeCache = Collections.synchronizedMap(new HashMap());
/* 238 */     this._modelGroupCache = Collections.synchronizedMap(new HashMap());
/* 239 */     this._attributeGroupCache = Collections.synchronizedMap(new HashMap());
/* 240 */     this._idConstraintCache = Collections.synchronizedMap(new HashMap());
/* 241 */     this._typeCache = Collections.synchronizedMap(new HashMap());
/* 242 */     this._documentCache = Collections.synchronizedMap(new HashMap());
/* 243 */     this._attributeTypeCache = Collections.synchronizedMap(new HashMap());
/* 244 */     this._classnameCache = Collections.synchronizedMap(new HashMap());
/*     */   }
/*     */ 
/*     */   
/*     */   SchemaTypeSystemImpl typeSystemForComponent(String searchdir, QName name) {
/* 249 */     String searchfor = searchdir + QNameHelper.hexsafedir(name) + ".xsb";
/* 250 */     String tsname = null;
/*     */     
/* 252 */     if (this._resourceLoader != null) {
/* 253 */       tsname = crackEntry(this._resourceLoader, searchfor);
/*     */     }
/* 255 */     if (this._classLoader != null) {
/* 256 */       tsname = crackEntry(this._classLoader, searchfor);
/*     */     }
/* 258 */     if (tsname != null) {
/* 259 */       return (SchemaTypeSystemImpl)typeSystemForName(tsname);
/*     */     }
/* 261 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaTypeSystem typeSystemForName(String name) {
/* 266 */     if (this._resourceLoader != null) {
/*     */       
/* 268 */       SchemaTypeSystem result = getTypeSystemOnClasspath(name);
/* 269 */       if (result != null) {
/* 270 */         return result;
/*     */       }
/*     */     } 
/* 273 */     if (this._classLoader != null) {
/*     */       
/* 275 */       SchemaTypeSystem result = getTypeSystemOnClassloader(name);
/* 276 */       if (result != null)
/* 277 */         return result; 
/*     */     } 
/* 279 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   SchemaTypeSystemImpl typeSystemForClassname(String searchdir, String name) {
/* 284 */     String searchfor = searchdir + name.replace('.', '/') + ".xsb";
/*     */     
/* 286 */     if (this._resourceLoader != null) {
/*     */       
/* 288 */       String tsname = crackEntry(this._resourceLoader, searchfor);
/* 289 */       if (tsname != null) {
/* 290 */         return getTypeSystemOnClasspath(tsname);
/*     */       }
/*     */     } 
/* 293 */     if (this._classLoader != null) {
/*     */       
/* 295 */       String tsname = crackEntry(this._classLoader, searchfor);
/* 296 */       if (tsname != null) {
/* 297 */         return getTypeSystemOnClassloader(tsname);
/*     */       }
/*     */     } 
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   SchemaTypeSystemImpl getTypeSystemOnClasspath(String name) {
/* 305 */     SchemaTypeSystemImpl result = (SchemaTypeSystemImpl)this._classpathTypeSystems.get(name);
/* 306 */     if (result == null) {
/*     */       
/* 308 */       result = new SchemaTypeSystemImpl(this._resourceLoader, name, this);
/* 309 */       this._classpathTypeSystems.put(name, result);
/*     */     } 
/* 311 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   SchemaTypeSystemImpl getTypeSystemOnClassloader(String name) {
/* 316 */     XBeanDebug.trace(1, "Finding type system " + name + " on classloader", 0);
/* 317 */     SchemaTypeSystemImpl result = (SchemaTypeSystemImpl)this._classLoaderTypeSystems.get(name);
/* 318 */     if (result == null) {
/*     */       
/* 320 */       XBeanDebug.trace(1, "Type system " + name + " not cached - consulting field", 0);
/* 321 */       result = SchemaTypeSystemImpl.forName(name, this._classLoader);
/* 322 */       this._classLoaderTypeSystems.put(name, result);
/*     */     } 
/* 324 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   static String crackEntry(ResourceLoader loader, String searchfor) {
/* 329 */     InputStream is = loader.getResourceAsStream(searchfor);
/* 330 */     if (is == null)
/* 331 */       return null; 
/* 332 */     return crackPointer(is);
/*     */   }
/*     */ 
/*     */   
/*     */   static String crackEntry(ClassLoader loader, String searchfor) {
/* 337 */     InputStream stream = loader.getResourceAsStream(searchfor);
/* 338 */     if (stream == null)
/* 339 */       return null; 
/* 340 */     return crackPointer(stream);
/*     */   }
/*     */ 
/*     */   
/*     */   static String crackPointer(InputStream stream) {
/* 345 */     return SchemaTypeSystemImpl.crackPointer(stream);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNamespaceDefined(String namespace) {
/* 350 */     for (int i = 0; i < this._searchPath.length; i++) {
/* 351 */       if (this._searchPath[i].isNamespaceDefined(namespace))
/* 352 */         return true; 
/*     */     } 
/* 354 */     SchemaTypeSystem sts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/namespace/", new QName(namespace, "xmlns"));
/* 355 */     return (sts != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaType.Ref findTypeRef(QName name) {
/* 367 */     Object cached = this._typeCache.get(name);
/* 368 */     if (cached == CACHED_NOT_FOUND)
/* 369 */       return null; 
/* 370 */     SchemaType.Ref result = (SchemaType.Ref)cached;
/* 371 */     if (result == null) {
/*     */       
/* 373 */       for (int i = 0; i < this._searchPath.length && 
/* 374 */         null == (result = this._searchPath[i].findTypeRef(name)); i++);
/*     */       
/* 376 */       if (result == null) {
/*     */         
/* 378 */         SchemaTypeSystem ts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/type/", name);
/* 379 */         if (ts != null) {
/*     */           
/* 381 */           result = ts.findTypeRef(name);
/* 382 */           assert result != null : "Type system registered type " + QNameHelper.pretty(name) + " but does not return it";
/*     */         } 
/*     */       } 
/* 385 */       this._typeCache.put(name, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 387 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType typeForClassname(String classname) {
/* 392 */     classname = classname.replace('$', '.');
/*     */     
/* 394 */     Object cached = this._classnameCache.get(classname);
/* 395 */     if (cached == CACHED_NOT_FOUND)
/* 396 */       return null; 
/* 397 */     SchemaType result = (SchemaType)cached;
/* 398 */     if (result == null) {
/*     */       
/* 400 */       for (int i = 0; i < this._searchPath.length && 
/* 401 */         null == (result = this._searchPath[i].typeForClassname(classname)); i++);
/*     */       
/* 403 */       if (result == null) {
/*     */         
/* 405 */         SchemaTypeSystem ts = typeSystemForClassname("schema" + METADATA_PACKAGE_LOAD + "/javaname/", classname);
/* 406 */         if (ts != null) {
/*     */           
/* 408 */           result = ts.typeForClassname(classname);
/* 409 */           assert result != null : "Type system registered type " + classname + " but does not return it";
/*     */         } 
/*     */       } 
/* 412 */       this._classnameCache.put(classname, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 414 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType.Ref findDocumentTypeRef(QName name) {
/* 419 */     Object cached = this._documentCache.get(name);
/* 420 */     if (cached == CACHED_NOT_FOUND)
/* 421 */       return null; 
/* 422 */     SchemaType.Ref result = (SchemaType.Ref)cached;
/* 423 */     if (result == null) {
/*     */       
/* 425 */       for (int i = 0; i < this._searchPath.length && 
/* 426 */         null == (result = this._searchPath[i].findDocumentTypeRef(name)); i++);
/*     */       
/* 428 */       if (result == null) {
/*     */         
/* 430 */         SchemaTypeSystem ts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/element/", name);
/* 431 */         if (ts != null) {
/*     */           
/* 433 */           result = ts.findDocumentTypeRef(name);
/* 434 */           assert result != null : "Type system registered element " + QNameHelper.pretty(name) + " but does not contain document type";
/*     */         } 
/*     */       } 
/* 437 */       this._documentCache.put(name, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 439 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType.Ref findAttributeTypeRef(QName name) {
/* 444 */     Object cached = this._attributeTypeCache.get(name);
/* 445 */     if (cached == CACHED_NOT_FOUND)
/* 446 */       return null; 
/* 447 */     SchemaType.Ref result = (SchemaType.Ref)cached;
/* 448 */     if (result == null) {
/*     */       
/* 450 */       for (int i = 0; i < this._searchPath.length && 
/* 451 */         null == (result = this._searchPath[i].findAttributeTypeRef(name)); i++);
/*     */       
/* 453 */       if (result == null) {
/*     */         
/* 455 */         SchemaTypeSystem ts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/attribute/", name);
/* 456 */         if (ts != null) {
/*     */           
/* 458 */           result = ts.findAttributeTypeRef(name);
/* 459 */           assert result != null : "Type system registered attribute " + QNameHelper.pretty(name) + " but does not contain attribute type";
/*     */         } 
/*     */       } 
/* 462 */       this._attributeTypeCache.put(name, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 464 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalElement.Ref findElementRef(QName name) {
/* 469 */     Object cached = this._elementCache.get(name);
/* 470 */     if (cached == CACHED_NOT_FOUND)
/* 471 */       return null; 
/* 472 */     SchemaGlobalElement.Ref result = (SchemaGlobalElement.Ref)cached;
/* 473 */     if (result == null) {
/*     */       
/* 475 */       for (int i = 0; i < this._searchPath.length && 
/* 476 */         null == (result = this._searchPath[i].findElementRef(name)); i++);
/*     */       
/* 478 */       if (result == null) {
/*     */         
/* 480 */         SchemaTypeSystem ts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/element/", name);
/* 481 */         if (ts != null) {
/*     */           
/* 483 */           result = ts.findElementRef(name);
/* 484 */           assert result != null : "Type system registered element " + QNameHelper.pretty(name) + " but does not return it";
/*     */         } 
/*     */       } 
/* 487 */       this._elementCache.put(name, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 489 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaGlobalAttribute.Ref findAttributeRef(QName name) {
/* 494 */     Object cached = this._attributeCache.get(name);
/* 495 */     if (cached == CACHED_NOT_FOUND)
/* 496 */       return null; 
/* 497 */     SchemaGlobalAttribute.Ref result = (SchemaGlobalAttribute.Ref)cached;
/* 498 */     if (result == null) {
/*     */       
/* 500 */       for (int i = 0; i < this._searchPath.length && 
/* 501 */         null == (result = this._searchPath[i].findAttributeRef(name)); i++);
/*     */       
/* 503 */       if (result == null) {
/*     */         
/* 505 */         SchemaTypeSystem ts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/attribute/", name);
/* 506 */         if (ts != null) {
/*     */           
/* 508 */           result = ts.findAttributeRef(name);
/* 509 */           assert result != null : "Type system registered attribute " + QNameHelper.pretty(name) + " but does not return it";
/*     */         } 
/*     */       } 
/* 512 */       this._attributeCache.put(name, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 514 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaModelGroup.Ref findModelGroupRef(QName name) {
/* 519 */     Object cached = this._modelGroupCache.get(name);
/* 520 */     if (cached == CACHED_NOT_FOUND)
/* 521 */       return null; 
/* 522 */     SchemaModelGroup.Ref result = (SchemaModelGroup.Ref)cached;
/* 523 */     if (result == null) {
/*     */       
/* 525 */       for (int i = 0; i < this._searchPath.length && 
/* 526 */         null == (result = this._searchPath[i].findModelGroupRef(name)); i++);
/*     */       
/* 528 */       if (result == null) {
/*     */         
/* 530 */         SchemaTypeSystem ts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/modelgroup/", name);
/* 531 */         if (ts != null) {
/*     */           
/* 533 */           result = ts.findModelGroupRef(name);
/* 534 */           assert result != null : "Type system registered model group " + QNameHelper.pretty(name) + " but does not return it";
/*     */         } 
/*     */       } 
/* 537 */       this._modelGroupCache.put(name, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 539 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAttributeGroup.Ref findAttributeGroupRef(QName name) {
/* 544 */     Object cached = this._attributeGroupCache.get(name);
/* 545 */     if (cached == CACHED_NOT_FOUND)
/* 546 */       return null; 
/* 547 */     SchemaAttributeGroup.Ref result = (SchemaAttributeGroup.Ref)cached;
/* 548 */     if (result == null) {
/*     */       
/* 550 */       for (int i = 0; i < this._searchPath.length && 
/* 551 */         null == (result = this._searchPath[i].findAttributeGroupRef(name)); i++);
/*     */       
/* 553 */       if (result == null) {
/*     */         
/* 555 */         SchemaTypeSystem ts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/attributegroup/", name);
/* 556 */         if (ts != null) {
/*     */           
/* 558 */           result = ts.findAttributeGroupRef(name);
/* 559 */           assert result != null : "Type system registered attribute group " + QNameHelper.pretty(name) + " but does not return it";
/*     */         } 
/*     */       } 
/* 562 */       this._attributeGroupCache.put(name, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 564 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaIdentityConstraint.Ref findIdentityConstraintRef(QName name) {
/* 569 */     Object cached = this._idConstraintCache.get(name);
/* 570 */     if (cached == CACHED_NOT_FOUND)
/* 571 */       return null; 
/* 572 */     SchemaIdentityConstraint.Ref result = (SchemaIdentityConstraint.Ref)cached;
/* 573 */     if (result == null) {
/*     */       
/* 575 */       for (int i = 0; i < this._searchPath.length && 
/* 576 */         null == (result = this._searchPath[i].findIdentityConstraintRef(name)); i++);
/*     */       
/* 578 */       if (result == null) {
/*     */         
/* 580 */         SchemaTypeSystem ts = typeSystemForComponent("schema" + METADATA_PACKAGE_LOAD + "/identityconstraint/", name);
/* 581 */         if (ts != null) {
/*     */           
/* 583 */           result = ts.findIdentityConstraintRef(name);
/* 584 */           assert result != null : "Type system registered identity constraint " + QNameHelper.pretty(name) + " but does not return it";
/*     */         } 
/*     */       } 
/* 587 */       this._idConstraintCache.put(name, (result == null) ? CACHED_NOT_FOUND : result);
/*     */     } 
/* 589 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getSourceAsStream(String sourceName) {
/* 594 */     InputStream result = null;
/*     */     
/* 596 */     if (!sourceName.startsWith("/")) {
/* 597 */       sourceName = "/" + sourceName;
/*     */     }
/* 599 */     if (this._resourceLoader != null) {
/* 600 */       result = this._resourceLoader.getResourceAsStream("schema" + METADATA_PACKAGE_LOAD + "/src" + sourceName);
/*     */     }
/* 602 */     if (result == null && this._classLoader != null) {
/* 603 */       return this._classLoader.getResourceAsStream("schema" + METADATA_PACKAGE_LOAD + "/src" + sourceName);
/*     */     }
/* 605 */     return result;
/*     */   }
/*     */   
/* 608 */   private static final SchemaTypeLoader[] EMPTY_SCHEMATYPELOADER_ARRAY = new SchemaTypeLoader[0];
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   static {
/* 612 */     if (SystemCache.get() instanceof SystemCache)
/* 613 */       SystemCache.set(new SchemaTypeLoaderCache()); 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaTypeLoaderImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */