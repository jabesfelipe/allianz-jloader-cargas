/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaAnnotation;
/*     */ import org.apache.xmlbeans.SchemaComponent;
/*     */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.XPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaIdentityConstraintImpl
/*     */   implements SchemaIdentityConstraint
/*     */ {
/*     */   private SchemaContainer _container;
/*     */   private String _selector;
/*     */   private String[] _fields;
/*     */   private SchemaIdentityConstraint.Ref _key;
/*     */   private QName _name;
/*     */   private int _type;
/*     */   private XmlObject _parse;
/*     */   private Object _userData;
/*     */   private SchemaAnnotation _annotation;
/*  39 */   private Map _nsMap = Collections.EMPTY_MAP;
/*     */   
/*     */   private String _parseTNS;
/*     */   
/*     */   private boolean _chameleon;
/*     */   
/*     */   private String _filename;
/*     */   
/*     */   private volatile XPath _selectorPath;
/*     */   private volatile XPath[] _fieldPaths;
/*     */   private SchemaIdentityConstraint.Ref _selfref;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public void setFilename(String filename) {
/*  53 */     this._filename = filename;
/*     */   }
/*     */   public String getSourceName() {
/*  56 */     return this._filename;
/*     */   }
/*     */   
/*     */   public String getSelector() {
/*  60 */     return this._selector;
/*     */   }
/*     */   
/*     */   public Object getSelectorPath() {
/*  64 */     XPath p = this._selectorPath;
/*  65 */     if (p == null) {
/*     */       try {
/*  67 */         buildPaths();
/*  68 */         p = this._selectorPath;
/*     */       }
/*  70 */       catch (org.apache.xmlbeans.impl.common.XPath.XPathCompileException e) {
/*  71 */         assert false : "Failed to compile xpath. Should be caught by compiler " + e;
/*  72 */         return null;
/*     */       } 
/*     */     }
/*  75 */     return p;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAnnotation(SchemaAnnotation ann) {
/*  80 */     this._annotation = ann;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAnnotation getAnnotation() {
/*  85 */     return this._annotation;
/*     */   }
/*     */   
/*     */   public void setNSMap(Map nsMap) {
/*  89 */     this._nsMap = nsMap;
/*     */   }
/*     */   
/*     */   public Map getNSMap() {
/*  93 */     return Collections.unmodifiableMap(this._nsMap);
/*     */   }
/*     */   
/*     */   public void setSelector(String selector) {
/*  97 */     assert selector != null;
/*  98 */     this._selector = selector;
/*     */   }
/*     */   
/*     */   public void setFields(String[] fields) {
/* 102 */     assert fields != null && fields.length > 0;
/* 103 */     this._fields = fields;
/*     */   }
/*     */   
/*     */   public String[] getFields() {
/* 107 */     String[] fields = new String[this._fields.length];
/* 108 */     System.arraycopy(this._fields, 0, fields, 0, fields.length);
/* 109 */     return fields;
/*     */   }
/*     */   
/*     */   public Object getFieldPath(int index) {
/* 113 */     XPath[] p = this._fieldPaths;
/* 114 */     if (p == null) {
/*     */       try {
/* 116 */         buildPaths();
/* 117 */         p = this._fieldPaths;
/*     */       }
/* 119 */       catch (org.apache.xmlbeans.impl.common.XPath.XPathCompileException e) {
/* 120 */         assert false : "Failed to compile xpath. Should be caught by compiler " + e;
/* 121 */         return null;
/*     */       } 
/*     */     }
/* 124 */     return p[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildPaths() throws XPath.XPathCompileException {
/* 129 */     this._selectorPath = XPath.compileXPath(this._selector, this._nsMap);
/*     */     
/* 131 */     this._fieldPaths = new XPath[this._fields.length];
/* 132 */     for (int i = 0; i < this._fieldPaths.length; i++)
/* 133 */       this._fieldPaths[i] = XPath.compileXPath(this._fields[i], this._nsMap); 
/*     */   }
/*     */   
/*     */   public void setReferencedKey(SchemaIdentityConstraint.Ref key) {
/* 137 */     this._key = key;
/*     */   }
/*     */   
/*     */   public SchemaIdentityConstraint getReferencedKey() {
/* 141 */     return this._key.get();
/*     */   }
/*     */   
/*     */   public void setConstraintCategory(int type) {
/* 145 */     assert type >= 1 && type <= 3;
/* 146 */     this._type = type;
/*     */   }
/*     */   
/*     */   public int getConstraintCategory() {
/* 150 */     return this._type;
/*     */   }
/*     */   
/*     */   public void setName(QName name) {
/* 154 */     assert name != null;
/* 155 */     this._name = name;
/*     */   }
/*     */   
/*     */   public QName getName() {
/* 159 */     return this._name;
/*     */   }
/*     */   
/*     */   public int getComponentType() {
/* 163 */     return 5;
/*     */   }
/*     */   
/*     */   public SchemaTypeSystem getTypeSystem() {
/* 167 */     return this._container.getTypeSystem();
/*     */   }
/*     */   
/*     */   SchemaContainer getContainer() {
/* 171 */     return this._container;
/*     */   }
/*     */   
/*     */   public void setParseContext(XmlObject o, String targetNamespace, boolean chameleon) {
/* 175 */     this._parse = o;
/* 176 */     this._parseTNS = targetNamespace;
/* 177 */     this._chameleon = chameleon;
/*     */   }
/*     */   
/*     */   public XmlObject getParseObject() {
/* 181 */     return this._parse;
/*     */   }
/*     */   
/*     */   public String getTargetNamespace() {
/* 185 */     return this._parseTNS;
/*     */   }
/*     */   
/*     */   public String getChameleonNamespace() {
/* 189 */     return this._chameleon ? this._parseTNS : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResolved() {
/* 197 */     return (getConstraintCategory() != 2 || this._key != null);
/*     */   }
/*     */   public SchemaIdentityConstraintImpl(SchemaContainer c) {
/* 200 */     this._selfref = new SchemaIdentityConstraint.Ref(this);
/*     */     this._container = c;
/*     */   } public SchemaIdentityConstraint.Ref getRef() {
/* 203 */     return this._selfref;
/*     */   }
/*     */   public SchemaComponent.Ref getComponentRef() {
/* 206 */     return (SchemaComponent.Ref)getRef();
/*     */   }
/*     */   public Object getUserData() {
/* 209 */     return this._userData;
/*     */   }
/*     */   public void setUserData(Object data) {
/* 212 */     this._userData = data;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaIdentityConstraintImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */