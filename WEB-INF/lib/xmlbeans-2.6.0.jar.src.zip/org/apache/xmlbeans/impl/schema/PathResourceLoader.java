/*    */ package org.apache.xmlbeans.impl.schema;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.xmlbeans.ResourceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathResourceLoader
/*    */   implements ResourceLoader
/*    */ {
/*    */   private ResourceLoader[] _path;
/*    */   
/*    */   public PathResourceLoader(ResourceLoader[] loaderpath) throws IOException {
/* 32 */     this._path = new ResourceLoader[loaderpath.length];
/* 33 */     System.arraycopy(loaderpath, 0, this._path, 0, this._path.length);
/*    */   }
/*    */ 
/*    */   
/*    */   public PathResourceLoader(File[] filepath) {
/* 38 */     List pathlist = new ArrayList();
/* 39 */     for (int i = 0; i < filepath.length; i++) {
/*    */ 
/*    */       
/*    */       try {
/* 43 */         ResourceLoader path = new FileResourceLoader(filepath[i]);
/* 44 */         pathlist.add(path);
/*    */       }
/* 46 */       catch (IOException e) {}
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 51 */     this._path = pathlist.<ResourceLoader>toArray(new ResourceLoader[pathlist.size()]);
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getResourceAsStream(String resourceName) {
/* 56 */     for (int i = 0; i < this._path.length; i++) {
/*    */       
/* 58 */       InputStream result = this._path[i].getResourceAsStream(resourceName);
/* 59 */       if (result != null)
/* 60 */         return result; 
/*    */     } 
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 67 */     for (int i = 0; i < this._path.length; i++) {
/*    */ 
/*    */       
/*    */       try {
/* 71 */         this._path[i].close();
/*    */       }
/* 73 */       catch (Exception e) {}
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\PathResourceLoader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */