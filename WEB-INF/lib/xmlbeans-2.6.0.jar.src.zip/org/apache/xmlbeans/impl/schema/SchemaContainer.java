/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.xmlbeans.SchemaAnnotation;
/*     */ import org.apache.xmlbeans.SchemaAttributeGroup;
/*     */ import org.apache.xmlbeans.SchemaComponent;
/*     */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*     */ import org.apache.xmlbeans.SchemaGlobalElement;
/*     */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*     */ import org.apache.xmlbeans.SchemaModelGroup;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SchemaTypeSystem;
/*     */ 
/*     */ class SchemaContainer
/*     */ {
/*     */   private String _namespace;
/*     */   private SchemaTypeSystem _typeSystem;
/*     */   boolean _immutable;
/*     */   private List _globalElements;
/*     */   private List _globalAttributes;
/*     */   private List _modelGroups;
/*     */   private List _redefinedModelGroups;
/*     */   private List _attributeGroups;
/*     */   private List _redefinedAttributeGroups;
/*     */   private List _globalTypes;
/*     */   private List _redefinedGlobalTypes;
/*     */   private List _documentTypes;
/*     */   private List _attributeTypes;
/*     */   private List _identityConstraints;
/*     */   private List _annotations;
/*     */   
/*     */   String getNamespace() {
/*     */     return this._namespace;
/*     */   }
/*     */   
/*     */   synchronized SchemaTypeSystem getTypeSystem() {
/*     */     return this._typeSystem;
/*     */   }
/*     */   
/*     */   synchronized void setTypeSystem(SchemaTypeSystem typeSystem) {
/*     */     this._typeSystem = typeSystem;
/*     */   }
/*     */   
/*     */   synchronized void setImmutable() {
/*     */     this._immutable = true;
/*     */   }
/*     */   
/*     */   synchronized void unsetImmutable() {
/*     */     this._immutable = false;
/*     */   }
/*     */   
/*     */   private void check_immutable() {
/*     */     if (this._immutable)
/*     */       throw new IllegalStateException("Cannot add components to immutable SchemaContainer"); 
/*     */   }
/*     */   
/*     */   void addGlobalElement(SchemaGlobalElement.Ref e) {
/*     */     check_immutable();
/*     */     this._globalElements.add(e);
/*     */   }
/*     */   
/*     */   List globalElements() {
/*     */     return getComponentList(this._globalElements);
/*     */   }
/*     */   
/*     */   void addGlobalAttribute(SchemaGlobalAttribute.Ref a) {
/*     */     check_immutable();
/*     */     this._globalAttributes.add(a);
/*     */   }
/*     */   
/*     */   List globalAttributes() {
/*     */     return getComponentList(this._globalAttributes);
/*     */   }
/*     */   
/*     */   void addModelGroup(SchemaModelGroup.Ref g) {
/*     */     check_immutable();
/*     */     this._modelGroups.add(g);
/*     */   }
/*     */   
/*     */   List modelGroups() {
/*     */     return getComponentList(this._modelGroups);
/*     */   }
/*     */   
/*     */   void addRedefinedModelGroup(SchemaModelGroup.Ref g) {
/*     */     check_immutable();
/*     */     this._redefinedModelGroups.add(g);
/*     */   }
/*     */   
/*     */   List redefinedModelGroups() {
/*     */     return getComponentList(this._redefinedModelGroups);
/*     */   }
/*     */   
/*     */   SchemaContainer(String namespace) {
/*  96 */     this._globalElements = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     this._globalAttributes = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     this._modelGroups = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     this._redefinedModelGroups = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     this._attributeGroups = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     this._redefinedAttributeGroups = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     this._globalTypes = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     this._redefinedGlobalTypes = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     this._documentTypes = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     this._attributeTypes = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     this._identityConstraints = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     this._annotations = new ArrayList(); this._namespace = namespace; }
/*     */   void addAttributeGroup(SchemaAttributeGroup.Ref g) { check_immutable(); this._attributeGroups.add(g); }
/*     */   List attributeGroups() { return getComponentList(this._attributeGroups); }
/* 198 */   void addRedefinedAttributeGroup(SchemaAttributeGroup.Ref g) { check_immutable(); this._redefinedAttributeGroups.add(g); } List redefinedAttributeGroups() { return getComponentList(this._redefinedAttributeGroups); } void addGlobalType(SchemaType.Ref t) { check_immutable(); this._globalTypes.add(t); } List globalTypes() { return getComponentList(this._globalTypes); } void addRedefinedType(SchemaType.Ref t) { check_immutable(); this._redefinedGlobalTypes.add(t); } void addAnnotation(SchemaAnnotation a) { check_immutable(); this._annotations.add(a); }
/*     */   List redefinedGlobalTypes() { return getComponentList(this._redefinedGlobalTypes); }
/*     */   void addDocumentType(SchemaType.Ref t) { check_immutable(); this._documentTypes.add(t); }
/* 201 */   List documentTypes() { return getComponentList(this._documentTypes); } void addAttributeType(SchemaType.Ref t) { check_immutable(); this._attributeTypes.add(t); } List attributeTypes() { return getComponentList(this._attributeTypes); } void addIdentityConstraint(SchemaIdentityConstraint.Ref c) { check_immutable(); this._identityConstraints.add(c); } List identityConstraints() { return getComponentList(this._identityConstraints); } List annotations() { return Collections.unmodifiableList(this._annotations); }
/*     */ 
/*     */   
/*     */   private List getComponentList(List referenceList) {
/* 205 */     List result = new ArrayList();
/* 206 */     for (int i = 0; i < referenceList.size(); i++)
/* 207 */       result.add(((SchemaComponent.Ref)referenceList.get(i)).getComponent()); 
/* 208 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaContainer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */