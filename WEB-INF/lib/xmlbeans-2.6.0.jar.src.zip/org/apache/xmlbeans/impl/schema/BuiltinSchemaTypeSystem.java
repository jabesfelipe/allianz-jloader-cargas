/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.InputStream;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.Filer;
/*      */ import org.apache.xmlbeans.QNameSet;
/*      */ import org.apache.xmlbeans.SchemaAnnotation;
/*      */ import org.apache.xmlbeans.SchemaAttributeGroup;
/*      */ import org.apache.xmlbeans.SchemaComponent;
/*      */ import org.apache.xmlbeans.SchemaGlobalAttribute;
/*      */ import org.apache.xmlbeans.SchemaGlobalElement;
/*      */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*      */ import org.apache.xmlbeans.SchemaModelGroup;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SchemaTypeSystem;
/*      */ import org.apache.xmlbeans.XmlAnySimpleType;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.regex.ParseException;
/*      */ import org.apache.xmlbeans.impl.regex.RegularExpression;
/*      */ import org.apache.xmlbeans.impl.regex.SchemaRegularExpression;
/*      */ import org.apache.xmlbeans.impl.values.XmlIntegerImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlStringImpl;
/*      */ import org.apache.xmlbeans.impl.values.XmlValueOutOfRangeException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BuiltinSchemaTypeSystem
/*      */   extends SchemaTypeLoaderBase
/*      */   implements SchemaTypeSystem
/*      */ {
/*      */   public static SchemaTypeSystem get() {
/*   51 */     return _global;
/*      */   }
/*      */   
/*   54 */   private static final SchemaType[] EMPTY_SCHEMATYPE_ARRAY = new SchemaType[0];
/*   55 */   private static final SchemaType.Ref[] EMPTY_SCHEMATYPEREF_ARRAY = new SchemaType.Ref[0];
/*   56 */   private static final SchemaGlobalElement[] EMPTY_SCHEMAELEMENT_ARRAY = new SchemaGlobalElement[0];
/*   57 */   private static final SchemaGlobalAttribute[] EMPTY_SCHEMAATTRIBUTE_ARRAY = new SchemaGlobalAttribute[0];
/*   58 */   private static final SchemaModelGroup[] EMPTY_SCHEMAMODELGROUP_ARRAY = new SchemaModelGroup[0];
/*   59 */   private static final SchemaAttributeGroup[] EMPTY_SCHEMAATTRIBUTEGROUP_ARRAY = new SchemaAttributeGroup[0];
/*   60 */   private static final SchemaAnnotation[] EMPTY_SCHEMAANNOTATION_ARRAY = new SchemaAnnotation[0];
/*      */   
/*   62 */   private static BuiltinSchemaTypeSystem _global = new BuiltinSchemaTypeSystem();
/*      */ 
/*      */   
/*   65 */   public static final SchemaTypeImpl ST_ANY_TYPE = _global.getBuiltinType(1);
/*   66 */   public static final SchemaTypeImpl ST_ANY_SIMPLE = _global.getBuiltinType(2);
/*      */ 
/*      */   
/*   69 */   public static final SchemaTypeImpl ST_BOOLEAN = _global.getBuiltinType(3);
/*   70 */   public static final SchemaTypeImpl ST_BASE_64_BINARY = _global.getBuiltinType(4);
/*   71 */   public static final SchemaTypeImpl ST_HEX_BINARY = _global.getBuiltinType(5);
/*   72 */   public static final SchemaTypeImpl ST_ANY_URI = _global.getBuiltinType(6);
/*   73 */   public static final SchemaTypeImpl ST_QNAME = _global.getBuiltinType(7);
/*   74 */   public static final SchemaTypeImpl ST_NOTATION = _global.getBuiltinType(8);
/*   75 */   public static final SchemaTypeImpl ST_FLOAT = _global.getBuiltinType(9);
/*   76 */   public static final SchemaTypeImpl ST_DOUBLE = _global.getBuiltinType(10);
/*   77 */   public static final SchemaTypeImpl ST_DECIMAL = _global.getBuiltinType(11);
/*   78 */   public static final SchemaTypeImpl ST_STRING = _global.getBuiltinType(12);
/*      */   
/*   80 */   public static final SchemaTypeImpl ST_DURATION = _global.getBuiltinType(13);
/*   81 */   public static final SchemaTypeImpl ST_DATE_TIME = _global.getBuiltinType(14);
/*   82 */   public static final SchemaTypeImpl ST_TIME = _global.getBuiltinType(15);
/*   83 */   public static final SchemaTypeImpl ST_DATE = _global.getBuiltinType(16);
/*   84 */   public static final SchemaTypeImpl ST_G_YEAR_MONTH = _global.getBuiltinType(17);
/*   85 */   public static final SchemaTypeImpl ST_G_YEAR = _global.getBuiltinType(18);
/*   86 */   public static final SchemaTypeImpl ST_G_MONTH_DAY = _global.getBuiltinType(19);
/*   87 */   public static final SchemaTypeImpl ST_G_DAY = _global.getBuiltinType(20);
/*   88 */   public static final SchemaTypeImpl ST_G_MONTH = _global.getBuiltinType(21);
/*      */ 
/*      */   
/*   91 */   public static final SchemaTypeImpl ST_INTEGER = _global.getBuiltinType(22);
/*   92 */   public static final SchemaTypeImpl ST_LONG = _global.getBuiltinType(23);
/*   93 */   public static final SchemaTypeImpl ST_INT = _global.getBuiltinType(24);
/*   94 */   public static final SchemaTypeImpl ST_SHORT = _global.getBuiltinType(25);
/*   95 */   public static final SchemaTypeImpl ST_BYTE = _global.getBuiltinType(26);
/*   96 */   public static final SchemaTypeImpl ST_NON_POSITIVE_INTEGER = _global.getBuiltinType(27);
/*   97 */   public static final SchemaTypeImpl ST_NEGATIVE_INTEGER = _global.getBuiltinType(28);
/*   98 */   public static final SchemaTypeImpl ST_NON_NEGATIVE_INTEGER = _global.getBuiltinType(29);
/*   99 */   public static final SchemaTypeImpl ST_POSITIVE_INTEGER = _global.getBuiltinType(30);
/*  100 */   public static final SchemaTypeImpl ST_UNSIGNED_LONG = _global.getBuiltinType(31);
/*  101 */   public static final SchemaTypeImpl ST_UNSIGNED_INT = _global.getBuiltinType(32);
/*  102 */   public static final SchemaTypeImpl ST_UNSIGNED_SHORT = _global.getBuiltinType(33);
/*  103 */   public static final SchemaTypeImpl ST_UNSIGNED_BYTE = _global.getBuiltinType(34);
/*      */ 
/*      */   
/*  106 */   public static final SchemaTypeImpl ST_NORMALIZED_STRING = _global.getBuiltinType(35);
/*  107 */   public static final SchemaTypeImpl ST_TOKEN = _global.getBuiltinType(36);
/*  108 */   public static final SchemaTypeImpl ST_NAME = _global.getBuiltinType(37);
/*  109 */   public static final SchemaTypeImpl ST_NCNAME = _global.getBuiltinType(38);
/*  110 */   public static final SchemaTypeImpl ST_LANGUAGE = _global.getBuiltinType(39);
/*  111 */   public static final SchemaTypeImpl ST_ID = _global.getBuiltinType(40);
/*  112 */   public static final SchemaTypeImpl ST_IDREF = _global.getBuiltinType(41);
/*  113 */   public static final SchemaTypeImpl ST_IDREFS = _global.getBuiltinType(42);
/*  114 */   public static final SchemaTypeImpl ST_ENTITY = _global.getBuiltinType(43);
/*  115 */   public static final SchemaTypeImpl ST_ENTITIES = _global.getBuiltinType(44);
/*  116 */   public static final SchemaTypeImpl ST_NMTOKEN = _global.getBuiltinType(45);
/*  117 */   public static final SchemaTypeImpl ST_NMTOKENS = _global.getBuiltinType(46);
/*      */ 
/*      */   
/*  120 */   public static final SchemaTypeImpl ST_NO_TYPE = _global.getBuiltinType(0);
/*      */   
/*  122 */   private static final XmlValueRef XMLSTR_PRESERVE = buildString("preserve");
/*  123 */   private static final XmlValueRef XMLSTR_REPLACE = buildString("preserve");
/*  124 */   private static final XmlValueRef XMLSTR_COLLAPSE = buildString("preserve");
/*      */   
/*  126 */   private static final XmlValueRef[] FACETS_NONE = new XmlValueRef[] { null, null, null, null, null, null, null, null, null, null, null, null };
/*      */ 
/*      */ 
/*      */   
/*  130 */   private static final boolean[] FIXED_FACETS_NONE = new boolean[] { 
/*      */       false, false, false, false, false, false, false, false, false, false, 
/*      */       false, false };
/*      */   
/*  134 */   private static final XmlValueRef[] FACETS_WS_COLLAPSE = new XmlValueRef[] { null, null, null, null, null, null, null, null, null, build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  138 */   private static final XmlValueRef[] FACETS_WS_REPLACE = new XmlValueRef[] { null, null, null, null, null, null, null, null, null, build_wsstring(2), null, null };
/*      */ 
/*      */ 
/*      */   
/*  142 */   private static final XmlValueRef[] FACETS_WS_PRESERVE = new XmlValueRef[] { null, null, null, null, null, null, null, null, null, build_wsstring(1), null, null };
/*      */ 
/*      */ 
/*      */   
/*  146 */   private static final XmlValueRef[] FACETS_INTEGER = new XmlValueRef[] { null, null, null, null, null, null, null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  150 */   private static final XmlValueRef[] FACETS_LONG = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.valueOf(Long.MIN_VALUE)), buildInteger(BigInteger.valueOf(Long.MAX_VALUE)), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  154 */   private static final XmlValueRef[] FACETS_INT = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.valueOf(-2147483648L)), buildInteger(BigInteger.valueOf(2147483647L)), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  158 */   private static final XmlValueRef[] FACETS_SHORT = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.valueOf(-32768L)), buildInteger(BigInteger.valueOf(32767L)), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  162 */   private static final XmlValueRef[] FACETS_BYTE = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.valueOf(-128L)), buildInteger(BigInteger.valueOf(127L)), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  166 */   private static final XmlValueRef[] FACETS_NONNEGATIVE = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.ZERO), null, null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  170 */   private static final XmlValueRef[] FACETS_POSITIVE = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.ONE), null, null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  174 */   private static final XmlValueRef[] FACETS_NONPOSITIVE = new XmlValueRef[] { null, null, null, null, null, buildInteger(BigInteger.ZERO), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  178 */   private static final XmlValueRef[] FACETS_NEGATIVE = new XmlValueRef[] { null, null, null, null, null, buildInteger(BigInteger.ONE.negate()), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  182 */   private static final XmlValueRef[] FACETS_UNSIGNED_LONG = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.ZERO), buildInteger(new BigInteger("18446744073709551615")), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  186 */   private static final XmlValueRef[] FACETS_UNSIGNED_INT = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.ZERO), buildInteger(BigInteger.valueOf(4294967295L)), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  190 */   private static final XmlValueRef[] FACETS_UNSIGNED_SHORT = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.ZERO), buildInteger(BigInteger.valueOf(65535L)), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  194 */   private static final XmlValueRef[] FACETS_UNSIGNED_BYTE = new XmlValueRef[] { null, null, null, null, buildInteger(BigInteger.ZERO), buildInteger(BigInteger.valueOf(255L)), null, null, buildNnInteger(BigInteger.ZERO), build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  198 */   private static final XmlValueRef[] FACETS_BUILTIN_LIST = new XmlValueRef[] { null, buildNnInteger(BigInteger.ONE), null, null, null, null, null, null, null, build_wsstring(3), null, null };
/*      */ 
/*      */ 
/*      */   
/*  202 */   private static final boolean[] FIXED_FACETS_WS = new boolean[] { 
/*      */       false, false, false, false, false, false, false, false, false, true, 
/*      */       false, false };
/*      */   
/*  206 */   private static final boolean[] FIXED_FACETS_INTEGER = new boolean[] { 
/*      */       false, false, false, false, false, false, false, false, true, true, 
/*      */       false, false };
/*      */   
/*  210 */   static final XmlValueRef[] FACETS_UNION = FACETS_NONE;
/*  211 */   static final boolean[] FIXED_FACETS_UNION = FIXED_FACETS_NONE;
/*      */   
/*  213 */   static final XmlValueRef[] FACETS_LIST = FACETS_WS_COLLAPSE;
/*  214 */   static final boolean[] FIXED_FACETS_LIST = FIXED_FACETS_WS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  221 */     for (int i = 0; i <= 46; i++)
/*      */     {
/*  223 */       _global.fillInType(i);
/*      */     }
/*      */   }
/*      */   
/*  227 */   private Map _typeMap = new HashMap();
/*  228 */   private SchemaTypeImpl[] _typeArray = new SchemaTypeImpl[47];
/*  229 */   private Map _handlesToObjects = new HashMap();
/*  230 */   private Map _objectsToHandles = new HashMap();
/*  231 */   private Map _typesByClassname = new HashMap();
/*  232 */   private SchemaContainer _container = new SchemaContainer("http://www.w3.org/2001/XMLSchema");
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   private SchemaTypeImpl getBuiltinType(int btc) {
/*  236 */     return this._typeArray[btc];
/*      */   }
/*      */ 
/*      */   
/*      */   private BuiltinSchemaTypeSystem() {
/*  241 */     this._container.setTypeSystem(this);
/*      */     
/*  243 */     setupBuiltin(1, "anyType", "org.apache.xmlbeans.XmlObject");
/*  244 */     setupBuiltin(2, "anySimpleType", "org.apache.xmlbeans.XmlAnySimpleType");
/*      */ 
/*      */     
/*  247 */     setupBuiltin(3, "boolean", "org.apache.xmlbeans.XmlBoolean");
/*  248 */     setupBuiltin(4, "base64Binary", "org.apache.xmlbeans.XmlBase64Binary");
/*  249 */     setupBuiltin(5, "hexBinary", "org.apache.xmlbeans.XmlHexBinary");
/*  250 */     setupBuiltin(6, "anyURI", "org.apache.xmlbeans.XmlAnyURI");
/*  251 */     setupBuiltin(7, "QName", "org.apache.xmlbeans.XmlQName");
/*  252 */     setupBuiltin(8, "NOTATION", "org.apache.xmlbeans.XmlNOTATION");
/*  253 */     setupBuiltin(9, "float", "org.apache.xmlbeans.XmlFloat");
/*  254 */     setupBuiltin(10, "double", "org.apache.xmlbeans.XmlDouble");
/*  255 */     setupBuiltin(11, "decimal", "org.apache.xmlbeans.XmlDecimal");
/*  256 */     setupBuiltin(12, "string", "org.apache.xmlbeans.XmlString");
/*      */     
/*  258 */     setupBuiltin(13, "duration", "org.apache.xmlbeans.XmlDuration");
/*  259 */     setupBuiltin(14, "dateTime", "org.apache.xmlbeans.XmlDateTime");
/*  260 */     setupBuiltin(15, "time", "org.apache.xmlbeans.XmlTime");
/*  261 */     setupBuiltin(16, "date", "org.apache.xmlbeans.XmlDate");
/*  262 */     setupBuiltin(17, "gYearMonth", "org.apache.xmlbeans.XmlGYearMonth");
/*  263 */     setupBuiltin(18, "gYear", "org.apache.xmlbeans.XmlGYear");
/*  264 */     setupBuiltin(19, "gMonthDay", "org.apache.xmlbeans.XmlGMonthDay");
/*  265 */     setupBuiltin(20, "gDay", "org.apache.xmlbeans.XmlGDay");
/*  266 */     setupBuiltin(21, "gMonth", "org.apache.xmlbeans.XmlGMonth");
/*      */ 
/*      */     
/*  269 */     setupBuiltin(22, "integer", "org.apache.xmlbeans.XmlInteger");
/*  270 */     setupBuiltin(23, "long", "org.apache.xmlbeans.XmlLong");
/*  271 */     setupBuiltin(24, "int", "org.apache.xmlbeans.XmlInt");
/*  272 */     setupBuiltin(25, "short", "org.apache.xmlbeans.XmlShort");
/*  273 */     setupBuiltin(26, "byte", "org.apache.xmlbeans.XmlByte");
/*  274 */     setupBuiltin(27, "nonPositiveInteger", "org.apache.xmlbeans.XmlNonPositiveInteger");
/*  275 */     setupBuiltin(28, "negativeInteger", "org.apache.xmlbeans.XmlNegativeInteger");
/*  276 */     setupBuiltin(29, "nonNegativeInteger", "org.apache.xmlbeans.XmlNonNegativeInteger");
/*  277 */     setupBuiltin(30, "positiveInteger", "org.apache.xmlbeans.XmlPositiveInteger");
/*  278 */     setupBuiltin(31, "unsignedLong", "org.apache.xmlbeans.XmlUnsignedLong");
/*  279 */     setupBuiltin(32, "unsignedInt", "org.apache.xmlbeans.XmlUnsignedInt");
/*  280 */     setupBuiltin(33, "unsignedShort", "org.apache.xmlbeans.XmlUnsignedShort");
/*  281 */     setupBuiltin(34, "unsignedByte", "org.apache.xmlbeans.XmlUnsignedByte");
/*      */ 
/*      */     
/*  284 */     setupBuiltin(35, "normalizedString", "org.apache.xmlbeans.XmlNormalizedString");
/*  285 */     setupBuiltin(36, "token", "org.apache.xmlbeans.XmlToken");
/*  286 */     setupBuiltin(37, "Name", "org.apache.xmlbeans.XmlName");
/*  287 */     setupBuiltin(38, "NCName", "org.apache.xmlbeans.XmlNCName");
/*  288 */     setupBuiltin(39, "language", "org.apache.xmlbeans.XmlLanguage");
/*  289 */     setupBuiltin(40, "ID", "org.apache.xmlbeans.XmlID");
/*  290 */     setupBuiltin(41, "IDREF", "org.apache.xmlbeans.XmlIDREF");
/*  291 */     setupBuiltin(42, "IDREFS", "org.apache.xmlbeans.XmlIDREFS");
/*  292 */     setupBuiltin(43, "ENTITY", "org.apache.xmlbeans.XmlENTITY");
/*  293 */     setupBuiltin(44, "ENTITIES", "org.apache.xmlbeans.XmlENTITIES");
/*  294 */     setupBuiltin(45, "NMTOKEN", "org.apache.xmlbeans.XmlNMTOKEN");
/*  295 */     setupBuiltin(46, "NMTOKENS", "org.apache.xmlbeans.XmlNMTOKENS");
/*      */ 
/*      */     
/*  298 */     setupBuiltin(0, null, null);
/*  299 */     this._container.setImmutable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  308 */     return "schema.typesystem.builtin";
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNamespaceDefined(String namespace) {
/*  313 */     return namespace.equals("http://www.w3.org/2001/XMLSchema");
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType findType(QName name) {
/*  318 */     return (SchemaType)this._typeMap.get(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaType findDocumentType(QName name) {
/*  324 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType findAttributeType(QName name) {
/*  329 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaGlobalElement findElement(QName name) {
/*  334 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaGlobalAttribute findAttribute(QName name) {
/*  339 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType.Ref findTypeRef(QName name) {
/*  344 */     SchemaType type = findType(name);
/*  345 */     return (type == null) ? null : type.getRef();
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType.Ref findDocumentTypeRef(QName name) {
/*  350 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType.Ref findAttributeTypeRef(QName name) {
/*  355 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaGlobalElement.Ref findElementRef(QName name) {
/*  360 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaGlobalAttribute.Ref findAttributeRef(QName name) {
/*  365 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaModelGroup.Ref findModelGroupRef(QName name) {
/*  370 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaAttributeGroup.Ref findAttributeGroupRef(QName name) {
/*  375 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaIdentityConstraint.Ref findIdentityConstraintRef(QName name) {
/*  380 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaType typeForClassname(String classname) {
/*  385 */     return (SchemaType)this._typesByClassname.get(classname);
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getSourceAsStream(String sourceName) {
/*  390 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaType[] globalTypes() {
/*  398 */     SchemaType[] result = new SchemaType[this._typeArray.length - 1];
/*  399 */     System.arraycopy(this._typeArray, 1, result, 0, result.length);
/*  400 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaType[] documentTypes() {
/*  408 */     return EMPTY_SCHEMATYPE_ARRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaType[] attributeTypes() {
/*  416 */     return EMPTY_SCHEMATYPE_ARRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaGlobalElement[] globalElements() {
/*  424 */     return EMPTY_SCHEMAELEMENT_ARRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaGlobalAttribute[] globalAttributes() {
/*  432 */     return EMPTY_SCHEMAATTRIBUTE_ARRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaModelGroup[] modelGroups() {
/*  440 */     return EMPTY_SCHEMAMODELGROUP_ARRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaAttributeGroup[] attributeGroups() {
/*  448 */     return EMPTY_SCHEMAATTRIBUTEGROUP_ARRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SchemaAnnotation[] annotations() {
/*  456 */     return EMPTY_SCHEMAANNOTATION_ARRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String handleForType(SchemaType type) {
/*  464 */     return (String)this._objectsToHandles.get(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassLoader getClassLoader() {
/*  472 */     return BuiltinSchemaTypeSystem.class.getClassLoader();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void saveToDirectory(File classDir) {
/*  480 */     throw new UnsupportedOperationException("The builtin schema type system cannot be saved.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void save(Filer filer) {
/*  488 */     throw new UnsupportedOperationException("The builtin schema type system cannot be saved.");
/*      */   }
/*      */ 
/*      */   
/*      */   private static XmlValueRef build_wsstring(int wsr) {
/*  493 */     switch (wsr) {
/*      */       
/*      */       case 1:
/*  496 */         return XMLSTR_PRESERVE;
/*      */       case 2:
/*  498 */         return XMLSTR_REPLACE;
/*      */       case 3:
/*  500 */         return XMLSTR_COLLAPSE;
/*      */     } 
/*  502 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static XmlValueRef buildNnInteger(BigInteger bigInt) {
/*  507 */     if (bigInt == null)
/*  508 */       return null; 
/*  509 */     if (bigInt.signum() < 0) {
/*  510 */       return null;
/*      */     }
/*      */     try {
/*  513 */       XmlIntegerImpl i = new XmlIntegerImpl();
/*  514 */       i.set(bigInt);
/*  515 */       i.setImmutable();
/*  516 */       return new XmlValueRef((XmlAnySimpleType)i);
/*      */     }
/*  518 */     catch (XmlValueOutOfRangeException e) {
/*      */       
/*  520 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static XmlValueRef buildInteger(BigInteger bigInt) {
/*  526 */     if (bigInt == null) {
/*  527 */       return null;
/*      */     }
/*      */     try {
/*  530 */       XmlIntegerImpl i = new XmlIntegerImpl();
/*  531 */       i.set(bigInt);
/*  532 */       i.setImmutable();
/*  533 */       return new XmlValueRef((XmlAnySimpleType)i);
/*      */     }
/*  535 */     catch (XmlValueOutOfRangeException e) {
/*      */       
/*  537 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static XmlValueRef buildString(String str) {
/*  543 */     if (str == null) {
/*  544 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  548 */       XmlStringImpl i = new XmlStringImpl();
/*  549 */       i.set(str);
/*  550 */       i.setImmutable();
/*  551 */       return new XmlValueRef((XmlAnySimpleType)i);
/*      */     }
/*  553 */     catch (XmlValueOutOfRangeException e) {
/*      */       
/*  555 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void setupBuiltin(int btc, String localname, String classname) {
/*  561 */     SchemaTypeImpl result = new SchemaTypeImpl(this._container, true);
/*  562 */     this._container.addGlobalType(result.getRef());
/*  563 */     QName name = (localname == null) ? null : QNameHelper.forLNS(localname, "http://www.w3.org/2001/XMLSchema");
/*  564 */     String handle = "_BI_" + ((localname == null) ? "NO_TYPE" : localname);
/*  565 */     result.setName(name);
/*  566 */     result.setBuiltinTypeCode(btc);
/*  567 */     if (classname != null) {
/*  568 */       result.setFullJavaName(classname);
/*      */     }
/*  570 */     this._typeArray[btc] = result;
/*  571 */     this._typeMap.put(name, result);
/*  572 */     this._handlesToObjects.put(handle, result);
/*  573 */     this._objectsToHandles.put(result, handle);
/*  574 */     if (classname != null) {
/*  575 */       this._typesByClassname.put(classname, result);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve() {}
/*      */ 
/*      */   
/*      */   public SchemaType typeForHandle(String handle) {
/*  585 */     return (SchemaType)this._handlesToObjects.get(handle);
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaComponent resolveHandle(String handle) {
/*  590 */     return (SchemaComponent)this._handlesToObjects.get(handle);
/*      */   }
/*      */ 
/*      */   
/*      */   public void fillInType(int btc) {
/*      */     SchemaType base;
/*      */     XmlValueRef[] facets;
/*      */     boolean[] fixedf;
/*  598 */     SchemaTypeImpl result = getBuiltinType(btc);
/*      */     
/*  600 */     SchemaType item = null;
/*  601 */     int variety = 1;
/*  602 */     int derivationType = 1;
/*      */     
/*  604 */     switch (btc) {
/*      */       
/*      */       case 0:
/*  607 */         variety = 0;
/*  608 */         base = ST_ANY_TYPE;
/*      */         break;
/*      */       
/*      */       case 1:
/*  612 */         variety = 0;
/*  613 */         base = null;
/*  614 */         derivationType = 1;
/*      */         break;
/*      */       
/*      */       default:
/*      */         assert false;
/*      */       
/*      */       case 2:
/*  621 */         base = ST_ANY_TYPE;
/*      */         break;
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*  642 */         base = ST_ANY_SIMPLE;
/*      */         break;
/*      */       
/*      */       case 22:
/*  646 */         base = ST_DECIMAL;
/*      */         break;
/*      */       case 23:
/*  649 */         base = ST_INTEGER;
/*      */         break;
/*      */       case 24:
/*  652 */         base = ST_LONG;
/*      */         break;
/*      */       case 25:
/*  655 */         base = ST_INT;
/*      */         break;
/*      */       case 26:
/*  658 */         base = ST_SHORT;
/*      */         break;
/*      */       case 27:
/*  661 */         base = ST_INTEGER;
/*      */         break;
/*      */       case 28:
/*  664 */         base = ST_NON_POSITIVE_INTEGER;
/*      */         break;
/*      */       case 29:
/*  667 */         base = ST_INTEGER;
/*      */         break;
/*      */       case 30:
/*  670 */         base = ST_NON_NEGATIVE_INTEGER;
/*      */         break;
/*      */       case 31:
/*  673 */         base = ST_NON_NEGATIVE_INTEGER;
/*      */         break;
/*      */       case 32:
/*  676 */         base = ST_UNSIGNED_LONG;
/*      */         break;
/*      */       case 33:
/*  679 */         base = ST_UNSIGNED_INT;
/*      */         break;
/*      */       case 34:
/*  682 */         base = ST_UNSIGNED_SHORT;
/*      */         break;
/*      */       
/*      */       case 35:
/*  686 */         base = ST_STRING;
/*      */         break;
/*      */       case 36:
/*  689 */         base = ST_NORMALIZED_STRING;
/*      */         break;
/*      */       case 37:
/*  692 */         base = ST_TOKEN;
/*      */         break;
/*      */       case 38:
/*  695 */         base = ST_NAME;
/*      */         break;
/*      */       case 40:
/*      */       case 41:
/*      */       case 43:
/*  700 */         base = ST_NCNAME;
/*      */         break;
/*      */       case 39:
/*      */       case 45:
/*  704 */         base = ST_TOKEN;
/*      */         break;
/*      */       case 42:
/*      */       case 44:
/*      */       case 46:
/*  709 */         variety = 3;
/*  710 */         base = ST_ANY_SIMPLE;
/*  711 */         if (btc == 42) {
/*  712 */           item = ST_IDREF; break;
/*  713 */         }  if (btc == 44) {
/*  714 */           item = ST_ENTITY; break;
/*      */         } 
/*  716 */         item = ST_NMTOKEN;
/*      */         break;
/*      */     } 
/*      */     
/*  720 */     result.setDerivationType(derivationType);
/*  721 */     result.setSimpleTypeVariety(variety);
/*  722 */     if (variety != 0) {
/*      */       
/*  724 */       result.setSimpleType(true);
/*      */     }
/*      */     else {
/*      */       
/*  728 */       assert btc == 1 || btc == 0;
/*      */     } 
/*  730 */     result.setBaseTypeRef((base == null) ? null : base.getRef());
/*  731 */     result.setBaseDepth((base == null) ? 0 : (((SchemaTypeImpl)base).getBaseDepth() + 1));
/*  732 */     result.setListItemTypeRef((item == null) ? null : item.getRef());
/*  733 */     if (btc >= 2 && btc <= 21) {
/*  734 */       result.setPrimitiveTypeRef(result.getRef());
/*  735 */     } else if (variety == 1) {
/*      */       
/*  737 */       if (base == null)
/*  738 */         throw new IllegalStateException("Base was null for " + btc); 
/*  739 */       if (base.getPrimitiveType() == null)
/*  740 */         throw new IllegalStateException("Base.gpt was null for " + btc); 
/*  741 */       result.setPrimitiveTypeRef(base.getPrimitiveType().getRef());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  746 */     int wsr = 3;
/*  747 */     int decimalSize = 0;
/*      */ 
/*      */     
/*  750 */     switch (btc) {
/*      */       default:
/*      */         assert false;
/*      */ 
/*      */       
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*  758 */         facets = FACETS_NONE;
/*  759 */         fixedf = FIXED_FACETS_NONE;
/*  760 */         wsr = 0;
/*      */         break;
/*      */       
/*      */       case 12:
/*  764 */         facets = FACETS_WS_PRESERVE;
/*  765 */         fixedf = FIXED_FACETS_NONE;
/*  766 */         wsr = 1;
/*      */         break;
/*      */       
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*  786 */         facets = FACETS_WS_COLLAPSE;
/*  787 */         fixedf = FIXED_FACETS_WS;
/*      */         break;
/*      */       
/*      */       case 11:
/*  791 */         facets = FACETS_WS_COLLAPSE;
/*  792 */         fixedf = FIXED_FACETS_WS;
/*  793 */         decimalSize = 1000001;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 22:
/*  798 */         facets = FACETS_INTEGER;
/*  799 */         fixedf = FIXED_FACETS_INTEGER;
/*  800 */         decimalSize = 1000000;
/*      */         break;
/*      */       
/*      */       case 23:
/*  804 */         facets = FACETS_LONG;
/*  805 */         fixedf = FIXED_FACETS_INTEGER;
/*  806 */         decimalSize = 64;
/*      */         break;
/*      */       
/*      */       case 24:
/*  810 */         facets = FACETS_INT;
/*  811 */         fixedf = FIXED_FACETS_INTEGER;
/*  812 */         decimalSize = 32;
/*      */         break;
/*      */       
/*      */       case 25:
/*  816 */         facets = FACETS_SHORT;
/*  817 */         fixedf = FIXED_FACETS_INTEGER;
/*  818 */         decimalSize = 16;
/*      */         break;
/*      */       
/*      */       case 26:
/*  822 */         facets = FACETS_BYTE;
/*  823 */         fixedf = FIXED_FACETS_INTEGER;
/*  824 */         decimalSize = 8;
/*      */         break;
/*      */       
/*      */       case 27:
/*  828 */         facets = FACETS_NONPOSITIVE;
/*  829 */         fixedf = FIXED_FACETS_INTEGER;
/*  830 */         decimalSize = 1000000;
/*      */         break;
/*      */       
/*      */       case 28:
/*  834 */         facets = FACETS_NEGATIVE;
/*  835 */         fixedf = FIXED_FACETS_INTEGER;
/*  836 */         decimalSize = 1000000;
/*      */         break;
/*      */       
/*      */       case 29:
/*  840 */         facets = FACETS_NONNEGATIVE;
/*  841 */         fixedf = FIXED_FACETS_INTEGER;
/*  842 */         decimalSize = 1000000;
/*      */         break;
/*      */       
/*      */       case 30:
/*  846 */         facets = FACETS_POSITIVE;
/*  847 */         fixedf = FIXED_FACETS_INTEGER;
/*  848 */         decimalSize = 1000000;
/*      */         break;
/*      */       
/*      */       case 31:
/*  852 */         facets = FACETS_UNSIGNED_LONG;
/*  853 */         fixedf = FIXED_FACETS_INTEGER;
/*  854 */         decimalSize = 1000000;
/*      */         break;
/*      */       
/*      */       case 32:
/*  858 */         facets = FACETS_UNSIGNED_INT;
/*  859 */         fixedf = FIXED_FACETS_INTEGER;
/*  860 */         decimalSize = 64;
/*      */         break;
/*      */       
/*      */       case 33:
/*  864 */         facets = FACETS_UNSIGNED_SHORT;
/*  865 */         fixedf = FIXED_FACETS_INTEGER;
/*  866 */         decimalSize = 32;
/*      */         break;
/*      */       
/*      */       case 34:
/*  870 */         facets = FACETS_UNSIGNED_BYTE;
/*  871 */         fixedf = FIXED_FACETS_INTEGER;
/*  872 */         decimalSize = 16;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 35:
/*  878 */         facets = FACETS_WS_REPLACE;
/*  879 */         fixedf = FIXED_FACETS_NONE;
/*  880 */         wsr = 2;
/*      */         break;
/*      */       
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 42:
/*      */       case 43:
/*      */       case 45:
/*  892 */         facets = FACETS_WS_COLLAPSE;
/*  893 */         fixedf = FIXED_FACETS_NONE;
/*  894 */         wsr = 3;
/*      */         break;
/*      */       
/*      */       case 44:
/*      */       case 46:
/*  899 */         facets = FACETS_BUILTIN_LIST;
/*  900 */         fixedf = FIXED_FACETS_NONE;
/*  901 */         wsr = 0;
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  906 */     int ordered = 0;
/*  907 */     boolean isNumeric = false;
/*  908 */     boolean isFinite = false;
/*  909 */     boolean isBounded = false;
/*      */     
/*  911 */     switch (btc) {
/*      */       default:
/*      */         assert false;
/*      */         break;
/*      */       
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 12:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/*      */       case 40:
/*      */       case 41:
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 45:
/*      */       case 46:
/*      */         break;
/*      */       
/*      */       case 3:
/*  940 */         isFinite = true;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 22:
/*  948 */         isNumeric = true;
/*  949 */         ordered = 2;
/*      */         break;
/*      */       
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*  961 */         ordered = 1;
/*      */         break;
/*      */       
/*      */       case 23:
/*      */       case 24:
/*      */       case 25:
/*      */       case 26:
/*      */       case 27:
/*      */       case 28:
/*      */       case 29:
/*      */       case 30:
/*      */       case 31:
/*      */       case 32:
/*      */       case 33:
/*      */       case 34:
/*  976 */         isNumeric = true;
/*  977 */         ordered = 2;
/*  978 */         isFinite = true;
/*  979 */         isBounded = true;
/*      */         break;
/*      */     } 
/*      */     
/*  983 */     result.setBasicFacets(facets, fixedf);
/*  984 */     result.setWhiteSpaceRule(wsr);
/*  985 */     result.setOrdered(ordered);
/*  986 */     result.setBounded(isBounded);
/*  987 */     result.setNumeric(isNumeric);
/*  988 */     result.setFinite(isFinite);
/*  989 */     result.setDecimalSize(decimalSize);
/*  990 */     result.setAnonymousTypeRefs(EMPTY_SCHEMATYPEREF_ARRAY);
/*      */     
/*  992 */     String pattern = null;
/*  993 */     boolean hasPattern = false;
/*      */     
/*  995 */     switch (btc) {
/*      */       
/*      */       case 39:
/*  998 */         pattern = "[a-zA-Z]{1,8}(-[a-zA-Z0-9]{1,8})*";
/*  999 */         hasPattern = true;
/*      */         break;
/*      */       case 45:
/* 1002 */         pattern = "\\c+";
/* 1003 */         hasPattern = true;
/*      */         break;
/*      */       case 37:
/* 1006 */         pattern = "\\i\\c*";
/* 1007 */         hasPattern = true;
/*      */         break;
/*      */       case 38:
/* 1010 */         pattern = "[\\i-[:]][\\c-[:]]*";
/* 1011 */         hasPattern = true;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 40:
/*      */       case 41:
/*      */       case 43:
/* 1018 */         hasPattern = true;
/*      */         break;
/*      */     } 
/*      */     
/* 1022 */     if (pattern != null) {
/*      */       
/* 1024 */       RegularExpression p = null; 
/* 1025 */       try { p = SchemaRegularExpression.forPattern(pattern); }
/*      */       catch (ParseException e) { assert false; }
/* 1027 */        result.setPatterns(new RegularExpression[] { p });
/*      */     } 
/* 1029 */     result.setPatternFacet(hasPattern);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1034 */     if (btc == 1) {
/*      */       
/* 1036 */       SchemaParticleImpl contentModel = new SchemaParticleImpl();
/* 1037 */       contentModel.setParticleType(5);
/* 1038 */       contentModel.setWildcardSet(QNameSet.ALL);
/* 1039 */       contentModel.setWildcardProcess(2);
/* 1040 */       contentModel.setMinOccurs(BigInteger.ZERO);
/* 1041 */       contentModel.setMaxOccurs(null);
/* 1042 */       contentModel.setTransitionRules(QNameSet.ALL, true);
/* 1043 */       contentModel.setTransitionNotes(QNameSet.ALL, true);
/*      */       
/* 1045 */       SchemaAttributeModelImpl attrModel = new SchemaAttributeModelImpl();
/* 1046 */       attrModel.setWildcardProcess(2);
/* 1047 */       attrModel.setWildcardSet(QNameSet.ALL);
/*      */       
/* 1049 */       result.setComplexTypeVariety(4);
/* 1050 */       result.setContentModel(contentModel, attrModel, Collections.EMPTY_MAP, Collections.EMPTY_MAP, false);
/* 1051 */       result.setAnonymousTypeRefs(EMPTY_SCHEMATYPEREF_ARRAY);
/* 1052 */       result.setWildcardSummary(QNameSet.ALL, true, QNameSet.ALL, true);
/*      */     }
/* 1054 */     else if (btc == 0) {
/*      */ 
/*      */       
/* 1057 */       SchemaParticleImpl contentModel = null;
/* 1058 */       SchemaAttributeModelImpl attrModel = new SchemaAttributeModelImpl();
/* 1059 */       result.setComplexTypeVariety(1);
/* 1060 */       result.setContentModel(contentModel, attrModel, Collections.EMPTY_MAP, Collections.EMPTY_MAP, false);
/* 1061 */       result.setAnonymousTypeRefs(EMPTY_SCHEMATYPEREF_ARRAY);
/* 1062 */       result.setWildcardSummary(QNameSet.EMPTY, false, QNameSet.EMPTY, false);
/*      */     } 
/*      */     
/* 1065 */     result.setOrderSensitive(false);
/*      */   }
/*      */ 
/*      */   
/*      */   public static SchemaType getNoType() {
/* 1070 */     return ST_NO_TYPE;
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\BuiltinSchemaTypeSystem.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */