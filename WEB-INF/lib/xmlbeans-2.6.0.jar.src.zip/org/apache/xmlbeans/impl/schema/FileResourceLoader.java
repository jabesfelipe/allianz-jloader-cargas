/*    */ package org.apache.xmlbeans.impl.schema;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipFile;
/*    */ import org.apache.xmlbeans.ResourceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileResourceLoader
/*    */   implements ResourceLoader
/*    */ {
/*    */   private File _directory;
/*    */   private ZipFile _zipfile;
/*    */   
/*    */   public FileResourceLoader(File file) throws IOException {
/* 34 */     if (file.isDirectory()) {
/* 35 */       this._directory = file;
/*    */     } else {
/*    */       
/* 38 */       this._zipfile = new ZipFile(file);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public InputStream getResourceAsStream(String resourceName) {
/*    */     try {
/* 46 */       if (this._zipfile != null) {
/*    */         
/* 48 */         ZipEntry entry = this._zipfile.getEntry(resourceName);
/* 49 */         if (entry == null)
/* 50 */           return null; 
/* 51 */         return this._zipfile.getInputStream(entry);
/*    */       } 
/*    */ 
/*    */       
/* 55 */       return new FileInputStream(new File(this._directory, resourceName));
/*    */     
/*    */     }
/* 58 */     catch (IOException e) {
/*    */       
/* 60 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 66 */     if (this._zipfile != null) {
/*    */ 
/*    */       
/*    */       try {
/* 70 */         this._zipfile.close();
/*    */       }
/* 72 */       catch (IOException e) {}
/*    */ 
/*    */ 
/*    */       
/* 76 */       this._zipfile = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\FileResourceLoader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */