/*     */ package org.apache.xmlbeans.impl.schema;
/*     */ 
/*     */ import org.apache.xmlbeans.SchemaAnnotation;
/*     */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*     */ import org.apache.xmlbeans.SchemaLocalElement;
/*     */ import org.apache.xmlbeans.soap.SOAPArrayType;
/*     */ import org.apache.xmlbeans.soap.SchemaWSDLArrayType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaLocalElementImpl
/*     */   extends SchemaParticleImpl
/*     */   implements SchemaLocalElement, SchemaWSDLArrayType
/*     */ {
/*     */   private boolean _blockExt;
/*     */   private boolean _blockRest;
/*     */   private boolean _blockSubst;
/*     */   protected boolean _abs;
/*     */   private SchemaAnnotation _annotation;
/*     */   private SOAPArrayType _wsdlArrayType;
/*  34 */   private SchemaIdentityConstraint.Ref[] _constraints = new SchemaIdentityConstraint.Ref[0];
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaLocalElementImpl() {
/*  39 */     setParticleType(4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean blockExtension() {
/*  44 */     return this._blockExt;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean blockRestriction() {
/*  49 */     return this._blockRest;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean blockSubstitution() {
/*  54 */     return this._blockSubst;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAbstract() {
/*  59 */     return this._abs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAbstract(boolean abs) {
/*  64 */     this._abs = abs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlock(boolean extension, boolean restriction, boolean substitution) {
/*  69 */     mutate();
/*  70 */     this._blockExt = extension;
/*  71 */     this._blockRest = restriction;
/*  72 */     this._blockSubst = substitution;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAnnotation(SchemaAnnotation ann) {
/*  77 */     this._annotation = ann;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWsdlArrayType(SOAPArrayType arrayType) {
/*  82 */     this._wsdlArrayType = arrayType;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaAnnotation getAnnotation() {
/*  87 */     return this._annotation;
/*     */   }
/*     */ 
/*     */   
/*     */   public SOAPArrayType getWSDLArrayType() {
/*  92 */     return this._wsdlArrayType;
/*     */   }
/*     */   
/*     */   public void setIdentityConstraints(SchemaIdentityConstraint.Ref[] constraints) {
/*  96 */     mutate();
/*  97 */     this._constraints = constraints;
/*     */   }
/*     */   
/*     */   public SchemaIdentityConstraint[] getIdentityConstraints() {
/* 101 */     SchemaIdentityConstraint[] result = new SchemaIdentityConstraint[this._constraints.length];
/* 102 */     for (int i = 0; i < result.length; i++)
/* 103 */       result[i] = this._constraints[i].get(); 
/* 104 */     return result;
/*     */   }
/*     */   
/*     */   public SchemaIdentityConstraint.Ref[] getIdentityConstraintRefs() {
/* 108 */     SchemaIdentityConstraint.Ref[] result = new SchemaIdentityConstraint.Ref[this._constraints.length];
/* 109 */     System.arraycopy(this._constraints, 0, result, 0, result.length);
/* 110 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\SchemaLocalElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */