/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ 
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.SimpleValue;
/*      */ import org.apache.xmlbeans.XmlAnySimpleType;
/*      */ import org.apache.xmlbeans.XmlByte;
/*      */ import org.apache.xmlbeans.XmlCursor;
/*      */ import org.apache.xmlbeans.XmlNonNegativeInteger;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlPositiveInteger;
/*      */ import org.apache.xmlbeans.XmlQName;
/*      */ import org.apache.xmlbeans.XmlShort;
/*      */ import org.apache.xmlbeans.XmlUnsignedByte;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.regex.ParseException;
/*      */ import org.apache.xmlbeans.impl.regex.RegularExpression;
/*      */ import org.apache.xmlbeans.impl.values.XmlValueOutOfRangeException;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Facet;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalSimpleType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.RestrictionDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SchemaDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.SimpleType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.UnionDocument;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StscSimpleTypeResolver
/*      */ {
/*      */   public static void resolveSimpleType(SchemaTypeImpl sImpl) {
/*   60 */     SimpleType parseSt = (SimpleType)sImpl.getParseObject();
/*      */     
/*   62 */     assert sImpl.isSimpleType();
/*      */     
/*   64 */     SchemaDocument.Schema schema = StscComplexTypeResolver.getSchema((XmlObject)parseSt);
/*      */ 
/*      */     
/*   67 */     int count = (parseSt.isSetList() ? 1 : 0) + (parseSt.isSetUnion() ? 1 : 0) + (parseSt.isSetRestriction() ? 1 : 0);
/*      */ 
/*      */ 
/*      */     
/*   71 */     if (count > 1) {
/*      */       
/*   73 */       StscState.get().error("A simple type must define either a list, a union, or a restriction: more than one found.", 52, (XmlObject)parseSt);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*   79 */     else if (count < 1) {
/*      */       
/*   81 */       StscState.get().error("A simple type must define either a list, a union, or a restriction: none was found.", 52, (XmlObject)parseSt);
/*      */ 
/*      */ 
/*      */       
/*   85 */       resolveErrorSimpleType(sImpl);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*   90 */     boolean finalRest = false;
/*   91 */     boolean finalList = false;
/*   92 */     boolean finalUnion = false;
/*      */     
/*   94 */     Object finalValue = null;
/*   95 */     if (parseSt.isSetFinal()) {
/*      */       
/*   97 */       finalValue = parseSt.getFinal();
/*      */     
/*      */     }
/*  100 */     else if (schema != null && schema.isSetFinalDefault()) {
/*      */       
/*  102 */       finalValue = schema.getFinalDefault();
/*      */     } 
/*      */     
/*  105 */     if (finalValue != null)
/*      */     {
/*  107 */       if (finalValue instanceof String) {
/*      */         
/*  109 */         if ("#all".equals(finalValue))
/*      */         {
/*  111 */           finalRest = finalList = finalUnion = true;
/*      */         }
/*      */       }
/*  114 */       else if (finalValue instanceof List) {
/*      */         
/*  116 */         List lFinalValue = (List)finalValue;
/*  117 */         if (lFinalValue.contains("restriction")) {
/*  118 */           finalRest = true;
/*      */         }
/*  120 */         if (lFinalValue.contains("list")) {
/*  121 */           finalList = true;
/*      */         }
/*  123 */         if (lFinalValue.contains("union")) {
/*  124 */           finalUnion = true;
/*      */         }
/*      */       } 
/*      */     }
/*  128 */     sImpl.setSimpleFinal(finalRest, finalList, finalUnion);
/*      */     
/*  130 */     List anonTypes = new ArrayList();
/*      */     
/*  132 */     if (parseSt.getList() != null) {
/*  133 */       resolveListType(sImpl, parseSt.getList(), anonTypes);
/*  134 */     } else if (parseSt.getUnion() != null) {
/*  135 */       resolveUnionType(sImpl, parseSt.getUnion(), anonTypes);
/*  136 */     } else if (parseSt.getRestriction() != null) {
/*  137 */       resolveSimpleRestrictionType(sImpl, parseSt.getRestriction(), anonTypes);
/*      */     } 
/*  139 */     sImpl.setAnonymousTypeRefs(makeRefArray(anonTypes));
/*      */   }
/*      */ 
/*      */   
/*      */   private static SchemaType.Ref[] makeRefArray(Collection typeList) {
/*  144 */     SchemaType.Ref[] result = new SchemaType.Ref[typeList.size()];
/*  145 */     int j = 0;
/*  146 */     for (Iterator i = typeList.iterator(); i.hasNext(); j++)
/*  147 */       result[j] = ((SchemaType)i.next()).getRef(); 
/*  148 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   static void resolveErrorSimpleType(SchemaTypeImpl sImpl) {
/*  153 */     sImpl.setSimpleTypeVariety(1);
/*  154 */     sImpl.setBaseTypeRef(BuiltinSchemaTypeSystem.ST_ANY_SIMPLE.getRef());
/*  155 */     sImpl.setBaseDepth(BuiltinSchemaTypeSystem.ST_ANY_SIMPLE.getBaseDepth() + 1);
/*  156 */     sImpl.setPrimitiveTypeRef(BuiltinSchemaTypeSystem.ST_ANY_SIMPLE.getRef());
/*      */   }
/*      */   static void resolveListType(SchemaTypeImpl sImpl, ListDocument.List parseList, List anonTypes) {
/*      */     SchemaTypeImpl itemImpl;
/*      */     LocalSimpleType localSimpleType1;
/*  161 */     StscState state = StscState.get();
/*      */     
/*  163 */     sImpl.setSimpleTypeVariety(3);
/*  164 */     sImpl.setBaseTypeRef(BuiltinSchemaTypeSystem.ST_ANY_SIMPLE.getRef());
/*  165 */     sImpl.setBaseDepth(BuiltinSchemaTypeSystem.ST_ANY_SIMPLE.getBaseDepth() + 1);
/*  166 */     sImpl.setDerivationType(1);
/*      */     
/*  168 */     if (sImpl.isRedefinition())
/*      */     {
/*  170 */       state.error("src-redefine.5a", new Object[] { "list" }, (XmlObject)parseList);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  175 */     QName itemName = parseList.getItemType();
/*  176 */     LocalSimpleType parseInner = parseList.getSimpleType();
/*      */     
/*  178 */     if (itemName != null && parseInner != null) {
/*      */       
/*  180 */       state.error("src-simple-type.3a", (Object[])null, (XmlObject)parseList);
/*      */       
/*  182 */       parseInner = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  188 */     if (itemName != null) {
/*      */       
/*  190 */       itemImpl = state.findGlobalType(itemName, sImpl.getChameleonNamespace(), sImpl.getTargetNamespace());
/*  191 */       XmlQName xmlQName = parseList.xgetItemType();
/*  192 */       if (itemImpl == null)
/*      */       {
/*  194 */         state.notFoundError(itemName, 0, (XmlObject)parseList.xgetItemType(), true);
/*      */         
/*  196 */         itemImpl = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */       }
/*      */     
/*  199 */     } else if (parseInner != null) {
/*      */       
/*  201 */       itemImpl = StscTranslator.translateAnonymousSimpleType((SimpleType)parseInner, sImpl.getTargetNamespace(), (sImpl.getChameleonNamespace() != null), sImpl.getElemFormDefault(), sImpl.getAttFormDefault(), anonTypes, sImpl);
/*      */ 
/*      */       
/*  204 */       localSimpleType1 = parseInner;
/*      */     }
/*      */     else {
/*      */       
/*  208 */       state.error("src-simple-type.3b", (Object[])null, (XmlObject)parseList);
/*      */       
/*  210 */       resolveErrorSimpleType(sImpl);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  215 */     if (itemImpl.finalList()) {
/*  216 */       state.error("st-props-correct.4.2.1", (Object[])null, (XmlObject)parseList);
/*      */     }
/*      */     
/*  219 */     StscResolver.resolveType(itemImpl);
/*      */     
/*  221 */     if (!itemImpl.isSimpleType()) {
/*      */       
/*  223 */       state.error("cos-st-restricts.2.1a", (Object[])null, (XmlObject)localSimpleType1);
/*      */       
/*  225 */       sImpl = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     } 
/*      */     
/*  228 */     switch (itemImpl.getSimpleVariety()) {
/*      */       
/*      */       case 3:
/*  231 */         state.error("cos-st-restricts.2.1b", (Object[])null, (XmlObject)localSimpleType1);
/*      */         
/*  233 */         resolveErrorSimpleType(sImpl);
/*      */         return;
/*      */       case 2:
/*  236 */         if (itemImpl.isUnionOfLists()) {
/*      */           
/*  238 */           state.error("cos-st-restricts.2.1c", (Object[])null, (XmlObject)localSimpleType1);
/*  239 */           resolveErrorSimpleType(sImpl);
/*      */           return;
/*      */         } 
/*      */       
/*      */       case 1:
/*  244 */         sImpl.setListItemTypeRef(itemImpl.getRef());
/*      */         
/*  246 */         if (sImpl.getBuiltinTypeCode() == 8)
/*  247 */           state.recover("enumeration-required-notation", null, (XmlObject)localSimpleType1); 
/*      */         break;
/*      */       default:
/*      */         assert false;
/*  251 */         sImpl.setListItemTypeRef(BuiltinSchemaTypeSystem.ST_ANY_SIMPLE.getRef());
/*      */         break;
/*      */     } 
/*      */     
/*  255 */     sImpl.setBasicFacets(StscState.FACETS_LIST, StscState.FIXED_FACETS_LIST);
/*  256 */     sImpl.setWhiteSpaceRule(3);
/*      */ 
/*      */     
/*  259 */     resolveFundamentalFacets(sImpl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void resolveUnionType(SchemaTypeImpl sImpl, UnionDocument.Union parseUnion, List anonTypes) {
/*  267 */     sImpl.setSimpleTypeVariety(2);
/*  268 */     sImpl.setBaseTypeRef(BuiltinSchemaTypeSystem.ST_ANY_SIMPLE.getRef());
/*  269 */     sImpl.setBaseDepth(BuiltinSchemaTypeSystem.ST_ANY_SIMPLE.getBaseDepth() + 1);
/*  270 */     sImpl.setDerivationType(1);
/*      */     
/*  272 */     StscState state = StscState.get();
/*      */     
/*  274 */     if (sImpl.isRedefinition())
/*      */     {
/*  276 */       state.error("src-redefine.5a", new Object[] { "union" }, (XmlObject)parseUnion);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  281 */     List memberTypes = parseUnion.getMemberTypes();
/*  282 */     LocalSimpleType[] arrayOfLocalSimpleType = parseUnion.getSimpleTypeArray();
/*      */     
/*  284 */     List memberImplList = new ArrayList();
/*      */     
/*  286 */     if (arrayOfLocalSimpleType.length == 0 && (memberTypes == null || memberTypes.size() == 0))
/*      */     {
/*  288 */       state.error("src-union-memberTypes-or-simpleTypes", (Object[])null, (XmlObject)parseUnion);
/*      */     }
/*      */ 
/*      */     
/*  292 */     if (memberTypes != null)
/*      */     {
/*  294 */       for (Iterator mNames = memberTypes.iterator(); mNames.hasNext(); ) {
/*      */         
/*  296 */         QName mName = mNames.next();
/*  297 */         SchemaTypeImpl memberImpl = state.findGlobalType(mName, sImpl.getChameleonNamespace(), sImpl.getTargetNamespace());
/*  298 */         if (memberImpl == null) {
/*      */           
/*  300 */           state.notFoundError(mName, 0, (XmlObject)parseUnion.xgetMemberTypes(), true); continue;
/*      */         } 
/*  302 */         memberImplList.add(memberImpl);
/*      */       } 
/*      */     }
/*      */     
/*  306 */     for (int i = 0; i < arrayOfLocalSimpleType.length; i++) {
/*      */ 
/*      */       
/*  309 */       SchemaTypeImpl mImpl = StscTranslator.translateAnonymousSimpleType((SimpleType)arrayOfLocalSimpleType[i], sImpl.getTargetNamespace(), (sImpl.getChameleonNamespace() != null), sImpl.getElemFormDefault(), sImpl.getAttFormDefault(), anonTypes, sImpl);
/*      */ 
/*      */       
/*  312 */       memberImplList.add(mImpl);
/*  313 */       mImpl.setAnonymousUnionMemberOrdinal(i + 1);
/*      */     } 
/*      */ 
/*      */     
/*  317 */     for (Iterator mImpls = memberImplList.iterator(); mImpls.hasNext(); ) {
/*      */       
/*  319 */       SchemaTypeImpl mImpl = mImpls.next();
/*  320 */       if (!StscResolver.resolveType(mImpl)) {
/*      */         UnionDocument.Union.MemberTypes memberTypes1;
/*      */         
/*  323 */         String memberName = "";
/*      */         
/*  325 */         if (mImpl.getOuterType().equals(sImpl)) {
/*      */           
/*  327 */           XmlObject errorLoc = mImpl.getParseObject();
/*      */         }
/*      */         else {
/*      */           
/*  331 */           memberName = QNameHelper.pretty(mImpl.getName()) + " ";
/*  332 */           memberTypes1 = parseUnion.xgetMemberTypes();
/*      */         } 
/*      */         
/*  335 */         state.error("src-simple-type.4", new Object[] { memberName }, (XmlObject)memberTypes1);
/*      */ 
/*      */         
/*  338 */         mImpls.remove();
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  344 */     boolean isUnionOfLists = false;
/*      */     
/*  346 */     for (Iterator iterator1 = memberImplList.iterator(); iterator1.hasNext(); ) {
/*      */       
/*  348 */       SchemaTypeImpl mImpl = iterator1.next();
/*      */       
/*  350 */       if (!mImpl.isSimpleType()) {
/*      */         UnionDocument.Union.MemberTypes memberTypes1;
/*      */         
/*  353 */         String memberName = "";
/*      */         
/*  355 */         if (mImpl.getOuterType() != null && mImpl.getOuterType().equals(sImpl)) {
/*      */           
/*  357 */           XmlObject errorLoc = mImpl.getParseObject();
/*      */         }
/*      */         else {
/*      */           
/*  361 */           memberName = QNameHelper.pretty(mImpl.getName()) + " ";
/*  362 */           memberTypes1 = parseUnion.xgetMemberTypes();
/*      */         } 
/*      */         
/*  365 */         state.error("cos-st-restricts.3.1", new Object[] { memberName }, (XmlObject)memberTypes1);
/*      */ 
/*      */         
/*  368 */         iterator1.remove();
/*      */         
/*      */         continue;
/*      */       } 
/*  372 */       if (mImpl.getSimpleVariety() == 3 || (mImpl.getSimpleVariety() == 2 && mImpl.isUnionOfLists()))
/*      */       {
/*  374 */         isUnionOfLists = true;
/*      */       }
/*      */     } 
/*      */     
/*  378 */     for (int j = 0; j < memberImplList.size(); j++) {
/*      */       
/*  380 */       SchemaTypeImpl mImpl = memberImplList.get(j);
/*  381 */       if (mImpl.finalUnion()) {
/*  382 */         state.error("st-props-correct.4.2.2", (Object[])null, (XmlObject)parseUnion);
/*      */       }
/*      */     } 
/*  385 */     sImpl.setUnionOfLists(isUnionOfLists);
/*      */     
/*  387 */     sImpl.setUnionMemberTypeRefs(makeRefArray(memberImplList));
/*      */ 
/*      */     
/*  390 */     sImpl.setBasicFacets(StscState.FACETS_UNION, StscState.FIXED_FACETS_UNION);
/*      */ 
/*      */     
/*  393 */     resolveFundamentalFacets(sImpl);
/*      */   }
/*      */   
/*      */   static void resolveSimpleRestrictionType(SchemaTypeImpl sImpl, RestrictionDocument.Restriction parseRestr, List anonTypes) {
/*      */     SchemaTypeImpl baseImpl;
/*  398 */     QName baseName = parseRestr.getBase();
/*  399 */     LocalSimpleType localSimpleType = parseRestr.getSimpleType();
/*  400 */     StscState state = StscState.get();
/*      */     
/*  402 */     if (baseName != null && localSimpleType != null) {
/*      */       
/*  404 */       state.error("src-simple-type.2a", (Object[])null, (XmlObject)parseRestr);
/*      */       
/*  406 */       localSimpleType = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  411 */     if (baseName != null) {
/*      */       
/*  413 */       if (sImpl.isRedefinition()) {
/*      */         
/*  415 */         baseImpl = state.findRedefinedGlobalType(parseRestr.getBase(), sImpl.getChameleonNamespace(), sImpl);
/*  416 */         if (baseImpl != null && !baseImpl.getName().equals(sImpl.getName()))
/*      */         {
/*  418 */           state.error("src-redefine.5b", new Object[] { "<simpleType>", QNameHelper.pretty(baseName), QNameHelper.pretty(sImpl.getName()) }, (XmlObject)parseRestr);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  428 */         baseImpl = state.findGlobalType(baseName, sImpl.getChameleonNamespace(), sImpl.getTargetNamespace());
/*      */       } 
/*  430 */       if (baseImpl == null)
/*      */       {
/*  432 */         state.notFoundError(baseName, 0, (XmlObject)parseRestr.xgetBase(), true);
/*      */         
/*  434 */         baseImpl = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */       }
/*      */     
/*  437 */     } else if (localSimpleType != null) {
/*      */       
/*  439 */       if (sImpl.isRedefinition())
/*      */       {
/*  441 */         StscState.get().error("src-redefine.5a", new Object[] { "<simpleType>" }, (XmlObject)localSimpleType);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  446 */       baseImpl = StscTranslator.translateAnonymousSimpleType((SimpleType)localSimpleType, sImpl.getTargetNamespace(), (sImpl.getChameleonNamespace() != null), sImpl.getElemFormDefault(), sImpl.getAttFormDefault(), anonTypes, sImpl);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  452 */       state.error("src-simple-type.2b", (Object[])null, (XmlObject)parseRestr);
/*      */       
/*  454 */       baseImpl = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     } 
/*      */ 
/*      */     
/*  458 */     if (!StscResolver.resolveType(baseImpl))
/*      */     {
/*      */       
/*  461 */       baseImpl = BuiltinSchemaTypeSystem.ST_ANY_SIMPLE;
/*      */     }
/*      */     
/*  464 */     if (baseImpl.finalRestriction()) {
/*  465 */       state.error("st-props-correct.3", (Object[])null, (XmlObject)parseRestr);
/*      */     }
/*  467 */     sImpl.setBaseTypeRef(baseImpl.getRef());
/*  468 */     sImpl.setBaseDepth(baseImpl.getBaseDepth() + 1);
/*  469 */     sImpl.setDerivationType(1);
/*      */     
/*  471 */     if (!baseImpl.isSimpleType()) {
/*      */       
/*  473 */       state.error("cos-st-restricts.1.1", (Object[])null, (XmlObject)parseRestr.xgetBase());
/*      */       
/*  475 */       resolveErrorSimpleType(sImpl);
/*      */       
/*      */       return;
/*      */     } 
/*  479 */     sImpl.setSimpleTypeVariety(baseImpl.getSimpleVariety());
/*      */ 
/*      */     
/*  482 */     switch (baseImpl.getSimpleVariety()) {
/*      */       
/*      */       case 1:
/*  485 */         sImpl.setPrimitiveTypeRef(baseImpl.getPrimitiveType().getRef());
/*      */         break;
/*      */       case 2:
/*  488 */         sImpl.setUnionOfLists(baseImpl.isUnionOfLists());
/*  489 */         sImpl.setUnionMemberTypeRefs(makeRefArray(Arrays.asList(baseImpl.getUnionMemberTypes())));
/*      */         break;
/*      */       case 3:
/*  492 */         sImpl.setListItemTypeRef(baseImpl.getListItemType().getRef());
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  497 */     resolveFacets(sImpl, (XmlObject)parseRestr, baseImpl);
/*      */ 
/*      */     
/*  500 */     resolveFundamentalFacets(sImpl);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static int translateWhitespaceCode(XmlAnySimpleType value) {
/*  506 */     String textval = value.getStringValue();
/*      */     
/*  508 */     if (textval.equals("collapse")) {
/*  509 */       return 3;
/*      */     }
/*  511 */     if (textval.equals("preserve")) {
/*  512 */       return 1;
/*      */     }
/*  514 */     if (textval.equals("replace")) {
/*  515 */       return 2;
/*      */     }
/*      */     
/*  518 */     StscState.get().error("Unrecognized whitespace value \"" + textval + "\"", 20, (XmlObject)value);
/*  519 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isMultipleFacet(int facetcode) {
/*  524 */     return (facetcode == 11 || facetcode == 10);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean facetAppliesToType(int facetCode, SchemaTypeImpl baseImpl) {
/*  530 */     switch (baseImpl.getSimpleVariety()) {
/*      */       
/*      */       case 3:
/*  533 */         switch (facetCode) {
/*      */           
/*      */           case 0:
/*      */           case 1:
/*      */           case 2:
/*      */           case 9:
/*      */           case 10:
/*      */           case 11:
/*  541 */             return true;
/*      */         } 
/*  543 */         return false;
/*      */       
/*      */       case 2:
/*  546 */         switch (facetCode) {
/*      */           
/*      */           case 10:
/*      */           case 11:
/*  550 */             return true;
/*      */         } 
/*  552 */         return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  557 */     switch (baseImpl.getPrimitiveType().getBuiltinTypeCode()) {
/*      */       
/*      */       case 2:
/*  560 */         return false;
/*      */       
/*      */       case 3:
/*  563 */         switch (facetCode) {
/*      */           
/*      */           case 9:
/*      */           case 10:
/*  567 */             return true;
/*      */         } 
/*  569 */         return false;
/*      */       
/*      */       case 9:
/*      */       case 10:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*  582 */         switch (facetCode) {
/*      */           
/*      */           case 3:
/*      */           case 4:
/*      */           case 5:
/*      */           case 6:
/*      */           case 9:
/*      */           case 10:
/*      */           case 11:
/*  591 */             return true;
/*      */         } 
/*  593 */         return false;
/*      */       
/*      */       case 11:
/*  596 */         switch (facetCode) {
/*      */           
/*      */           case 3:
/*      */           case 4:
/*      */           case 5:
/*      */           case 6:
/*      */           case 7:
/*      */           case 8:
/*      */           case 9:
/*      */           case 10:
/*      */           case 11:
/*  607 */             return true;
/*      */         } 
/*  609 */         return false;
/*      */       
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 12:
/*  617 */         switch (facetCode) {
/*      */           
/*      */           case 0:
/*      */           case 1:
/*      */           case 2:
/*      */           case 9:
/*      */           case 10:
/*      */           case 11:
/*  625 */             return true;
/*      */         } 
/*  627 */         return false;
/*      */     } 
/*      */     
/*      */     assert false;
/*  631 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int other_similar_limit(int facetcode) {
/*  637 */     switch (facetcode) {
/*      */       
/*      */       case 3:
/*  640 */         return 4;
/*      */       case 4:
/*  642 */         return 3;
/*      */       case 5:
/*  644 */         return 6;
/*      */       case 6:
/*  646 */         return 5;
/*      */     } 
/*      */     assert false;
/*  649 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */   
/*      */   static void resolveFacets(SchemaTypeImpl sImpl, XmlObject restriction, SchemaTypeImpl baseImpl) {
/*      */     RegularExpression[] patternArray;
/*  655 */     StscState state = StscState.get();
/*      */     
/*  657 */     boolean[] seenFacet = new boolean[12];
/*  658 */     XmlAnySimpleType[] myFacets = baseImpl.getBasicFacets();
/*  659 */     boolean[] fixedFacets = baseImpl.getFixedFacets();
/*  660 */     int wsr = 0;
/*  661 */     List enumeratedValues = null;
/*  662 */     List patterns = null;
/*      */     
/*  664 */     if (restriction != null) {
/*      */       
/*  666 */       XmlCursor cur = restriction.newCursor(); boolean more;
/*  667 */       for (more = cur.toFirstChild(); more; more = cur.toNextSibling()) {
/*      */         
/*  669 */         QName facetQName = cur.getName();
/*  670 */         String facetName = facetQName.getLocalPart();
/*  671 */         int code = translateFacetCode(facetQName);
/*  672 */         if (code != -1) {
/*      */ 
/*      */           
/*  675 */           Facet facet = (Facet)cur.getObject();
/*      */           
/*  677 */           if (!facetAppliesToType(code, baseImpl)) {
/*      */             
/*  679 */             state.error("cos-applicable-facets", new Object[] { facetName, QNameHelper.pretty(baseImpl.getName()) }, (XmlObject)facet);
/*      */           }
/*      */           else {
/*      */             
/*  683 */             if (baseImpl.getSimpleVariety() == 1 && baseImpl.getPrimitiveType().getBuiltinTypeCode() == 8 && (code == 0 || code == 1 || code == 2))
/*      */             {
/*      */ 
/*      */ 
/*      */               
/*  688 */               state.warning("notation-facets", new Object[] { facetName, QNameHelper.pretty(baseImpl.getName()) }, (XmlObject)facet);
/*      */             }
/*      */             
/*  691 */             if (seenFacet[code] && !isMultipleFacet(code)) {
/*      */               
/*  693 */               state.error("src-single-facet-value", (Object[])null, (XmlObject)facet);
/*      */             } else {
/*      */               XmlNonNegativeInteger xmlNonNegativeInteger1, xmlNonNegativeInteger2; XmlPositiveInteger dig; XmlNonNegativeInteger fdig; boolean ismin, isexclusive; XmlAnySimpleType limit, xmlAnySimpleType1; RegularExpression p;
/*  696 */               seenFacet[code] = true;
/*      */               
/*  698 */               switch (code) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 case 0:
/*  707 */                   xmlNonNegativeInteger1 = StscTranslator.buildNnInteger(facet.getValue());
/*  708 */                   if (xmlNonNegativeInteger1 == null) {
/*      */                     
/*  710 */                     state.error("Must be a nonnegative integer", 20, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  713 */                   if (fixedFacets[code] && !myFacets[code].valueEquals((XmlObject)xmlNonNegativeInteger1)) {
/*      */                     
/*  715 */                     state.error("facet-fixed", new Object[] { facetName }, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  718 */                   if (myFacets[1] != null) {
/*      */ 
/*      */ 
/*      */                     
/*  722 */                     XmlAnySimpleType baseMinLength = baseImpl.getFacet(1);
/*  723 */                     if (baseMinLength == null || !baseMinLength.valueEquals((XmlObject)myFacets[1]) || baseMinLength.compareValue((XmlObject)xmlNonNegativeInteger1) > 0) {
/*      */ 
/*      */ 
/*      */                       
/*  727 */                       state.error("length-minLength-maxLength", (Object[])null, (XmlObject)facet);
/*      */                       break;
/*      */                     } 
/*      */                   } 
/*  731 */                   if (myFacets[2] != null) {
/*      */ 
/*      */ 
/*      */                     
/*  735 */                     XmlAnySimpleType baseMaxLength = baseImpl.getFacet(2);
/*  736 */                     if (baseMaxLength == null || !baseMaxLength.valueEquals((XmlObject)myFacets[2]) || baseMaxLength.compareValue((XmlObject)xmlNonNegativeInteger1) < 0) {
/*      */ 
/*      */ 
/*      */                       
/*  740 */                       state.error("length-minLength-maxLength", (Object[])null, (XmlObject)facet);
/*      */                       break;
/*      */                     } 
/*      */                   } 
/*  744 */                   myFacets[code] = (XmlAnySimpleType)xmlNonNegativeInteger1;
/*      */ 
/*      */                 
/*      */                 case 1:
/*      */                 case 2:
/*  749 */                   xmlNonNegativeInteger2 = StscTranslator.buildNnInteger(facet.getValue());
/*  750 */                   if (xmlNonNegativeInteger2 == null) {
/*      */                     
/*  752 */                     state.error("Must be a nonnegative integer", 20, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  755 */                   if (fixedFacets[code] && !myFacets[code].valueEquals((XmlObject)xmlNonNegativeInteger2)) {
/*      */                     
/*  757 */                     state.error("facet-fixed", new Object[] { facetName }, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  760 */                   if (myFacets[0] != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*  766 */                     XmlAnySimpleType baseMinMaxLength = baseImpl.getFacet(code);
/*  767 */                     if (baseMinMaxLength == null || !baseMinMaxLength.valueEquals((XmlObject)xmlNonNegativeInteger2) || ((code == 1) ? (baseMinMaxLength.compareTo(myFacets[0]) <= 0) : (baseMinMaxLength.compareTo(myFacets[0]) >= 0))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/*  773 */                       state.error("length-minLength-maxLength", (Object[])null, (XmlObject)facet);
/*      */                       break;
/*      */                     } 
/*      */                   } 
/*  777 */                   if (myFacets[2] != null)
/*      */                   {
/*  779 */                     if (xmlNonNegativeInteger2.compareValue((XmlObject)myFacets[2]) > 0) {
/*      */                       
/*  781 */                       state.error("maxLength-valid-restriction", (Object[])null, (XmlObject)facet);
/*      */                       break;
/*      */                     } 
/*      */                   }
/*  785 */                   if (myFacets[1] != null)
/*      */                   {
/*  787 */                     if (xmlNonNegativeInteger2.compareValue((XmlObject)myFacets[1]) < 0) {
/*      */                       
/*  789 */                       state.error("minLength-valid-restriction", (Object[])null, (XmlObject)facet);
/*      */                       break;
/*      */                     } 
/*      */                   }
/*  793 */                   myFacets[code] = (XmlAnySimpleType)xmlNonNegativeInteger2;
/*      */ 
/*      */                 
/*      */                 case 7:
/*  797 */                   dig = StscTranslator.buildPosInteger(facet.getValue());
/*  798 */                   if (dig == null) {
/*      */                     
/*  800 */                     state.error("Must be a positive integer", 20, (XmlObject)facet);
/*      */                   } else {
/*      */                     
/*  803 */                     if (fixedFacets[code] && !myFacets[code].valueEquals((XmlObject)dig)) {
/*      */                       
/*  805 */                       state.error("facet-fixed", new Object[] { facetName }, (XmlObject)facet);
/*      */                       break;
/*      */                     } 
/*  808 */                     if (myFacets[7] != null)
/*      */                     {
/*  810 */                       if (dig.compareValue((XmlObject)myFacets[7]) > 0)
/*  811 */                         state.error("totalDigits-valid-restriction", (Object[])null, (XmlObject)facet); 
/*      */                     }
/*  813 */                     myFacets[code] = (XmlAnySimpleType)dig;
/*      */                   } 
/*      */                 
/*      */                 case 8:
/*  817 */                   fdig = StscTranslator.buildNnInteger(facet.getValue());
/*  818 */                   if (fdig == null) {
/*      */                     
/*  820 */                     state.error("Must be a nonnegative integer", 20, (XmlObject)facet);
/*      */                   } else {
/*      */                     
/*  823 */                     if (fixedFacets[code] && !myFacets[code].valueEquals((XmlObject)fdig)) {
/*      */                       
/*  825 */                       state.error("facet-fixed", new Object[] { facetName }, (XmlObject)facet);
/*      */                       break;
/*      */                     } 
/*  828 */                     if (myFacets[8] != null)
/*      */                     {
/*  830 */                       if (fdig.compareValue((XmlObject)myFacets[8]) > 0)
/*  831 */                         state.error("fractionDigits-valid-restriction", (Object[])null, (XmlObject)facet); 
/*      */                     }
/*  833 */                     if (myFacets[7] != null)
/*      */                     {
/*  835 */                       if (fdig.compareValue((XmlObject)myFacets[7]) > 0)
/*  836 */                         state.error("fractionDigits-totalDigits", (Object[])null, (XmlObject)facet); 
/*      */                     }
/*  838 */                     myFacets[code] = (XmlAnySimpleType)fdig;
/*      */                   } 
/*      */ 
/*      */                 
/*      */                 case 3:
/*      */                 case 4:
/*      */                 case 5:
/*      */                 case 6:
/*  846 */                   if (seenFacet[other_similar_limit(code)]) {
/*      */                     
/*  848 */                     state.error("Cannot define both inclusive and exclusive limit in the same restriciton", 19, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  851 */                   ismin = (code == 3 || code == 4);
/*  852 */                   isexclusive = (code == 3 || code == 6);
/*      */ 
/*      */ 
/*      */                   
/*      */                   try {
/*  857 */                     limit = baseImpl.newValue(facet.getValue(), true);
/*      */                   }
/*  859 */                   catch (XmlValueOutOfRangeException e) {
/*      */ 
/*      */ 
/*      */                     
/*  863 */                     switch (code) {
/*      */                       
/*      */                       case 3:
/*  866 */                         state.error("minExclusive-valid-restriction", new Object[] { e.getMessage() }, (XmlObject)facet);
/*      */                         break;
/*      */                       
/*      */                       case 4:
/*  870 */                         state.error("minInclusive-valid-restriction", new Object[] { e.getMessage() }, (XmlObject)facet);
/*      */                         break;
/*      */                       
/*      */                       case 5:
/*  874 */                         state.error("maxInclusive-valid-restriction", new Object[] { e.getMessage() }, (XmlObject)facet);
/*      */                         break;
/*      */                       
/*      */                       case 6:
/*  878 */                         state.error("maxExclusive-valid-restriction", new Object[] { e.getMessage() }, (XmlObject)facet);
/*      */                         break;
/*      */                     } 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*      */                     break;
/*      */                   } 
/*  887 */                   if (fixedFacets[code] && !myFacets[code].valueEquals((XmlObject)limit)) {
/*      */                     
/*  889 */                     state.error("facet-fixed", new Object[] { facetName }, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  892 */                   if (myFacets[code] != null) {
/*      */                     
/*  894 */                     SchemaType limitSType = limit.schemaType();
/*  895 */                     if (limitSType != null && !limitSType.isSimpleType() && limitSType.getContentType() == 2)
/*      */                     {
/*      */ 
/*      */ 
/*      */                       
/*  900 */                       limit = baseImpl.getContentBasedOnType().newValue(facet.getValue());
/*      */                     }
/*      */                     
/*  903 */                     int comparison = limit.compareValue((XmlObject)myFacets[code]);
/*  904 */                     if (comparison == 2 || comparison == (ismin ? -1 : 1)) {
/*      */                       
/*  906 */                       state.error(ismin ? (isexclusive ? "Must be greater than or equal to previous minExclusive" : "Must be greater than or equal to previous minInclusive") : (isexclusive ? "Must be less than or equal to previous maxExclusive" : "Must be less than or equal to previous maxInclusive"), 20, (XmlObject)facet);
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/*      */                       break;
/*      */                     } 
/*      */                   } 
/*      */ 
/*      */ 
/*      */                   
/*  917 */                   myFacets[code] = limit;
/*  918 */                   myFacets[other_similar_limit(code)] = null;
/*      */ 
/*      */                 
/*      */                 case 9:
/*  922 */                   wsr = translateWhitespaceCode(facet.getValue());
/*  923 */                   if (baseImpl.getWhiteSpaceRule() > wsr) {
/*      */                     
/*  925 */                     wsr = 0;
/*  926 */                     state.error("whiteSpace-valid-restriction", (Object[])null, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  929 */                   myFacets[code] = StscState.build_wsstring(wsr).get();
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 case 11:
/*      */                   try {
/*  936 */                     xmlAnySimpleType1 = baseImpl.newValue(facet.getValue(), true);
/*      */ 
/*      */                   
/*      */                   }
/*  940 */                   catch (XmlValueOutOfRangeException e) {
/*      */                     
/*  942 */                     state.error("enumeration-valid-restriction", new Object[] { facet.getValue().getStringValue(), e.getMessage() }, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  945 */                   if (enumeratedValues == null)
/*  946 */                     enumeratedValues = new ArrayList(); 
/*  947 */                   enumeratedValues.add(xmlAnySimpleType1);
/*      */ 
/*      */                 
/*      */                 case 10:
/*      */                   try {
/*  952 */                     p = new RegularExpression(facet.getValue().getStringValue(), "X");
/*  953 */                   } catch (ParseException e) {
/*      */                     
/*  955 */                     state.error("pattern-regex", new Object[] { facet.getValue().getStringValue(), e.getMessage() }, (XmlObject)facet);
/*      */                     break;
/*      */                   } 
/*  958 */                   if (patterns == null)
/*  959 */                     patterns = new ArrayList(); 
/*  960 */                   patterns.add(p);
/*      */ 
/*      */                 
/*      */                 default:
/*  964 */                   if (facet.getFixed())
/*  965 */                     fixedFacets[code] = true;  break;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  971 */     }  sImpl.setBasicFacets(makeValueRefArray(myFacets), fixedFacets);
/*      */ 
/*      */     
/*  974 */     if (wsr == 0)
/*  975 */       wsr = baseImpl.getWhiteSpaceRule(); 
/*  976 */     sImpl.setWhiteSpaceRule(wsr);
/*      */ 
/*      */     
/*  979 */     if (enumeratedValues != null) {
/*      */       
/*  981 */       sImpl.setEnumerationValues(makeValueRefArray(enumeratedValues.<XmlAnySimpleType>toArray(new XmlAnySimpleType[enumeratedValues.size()])));
/*      */ 
/*      */       
/*  984 */       SchemaType beType = sImpl;
/*  985 */       if (sImpl.isRedefinition()) {
/*  986 */         beType = sImpl.getBaseType().getBaseEnumType();
/*  987 */         if (beType == null || sImpl.getBaseType() == beType) {
/*  988 */           beType = sImpl;
/*      */         }
/*      */       }
/*  991 */       else if (sImpl.getBaseType().getBaseEnumType() != null) {
/*  992 */         beType = sImpl.getBaseType().getBaseEnumType();
/*  993 */       }  sImpl.setBaseEnumTypeRef(beType.getRef());
/*      */     }
/*      */     else {
/*      */       
/*  997 */       sImpl.copyEnumerationValues(baseImpl);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1002 */     if (patterns != null) {
/* 1003 */       patternArray = patterns.<RegularExpression>toArray(EMPTY_REGEX_ARRAY);
/*      */     } else {
/* 1005 */       patternArray = EMPTY_REGEX_ARRAY;
/* 1006 */     }  sImpl.setPatternFacet((patternArray.length > 0 || baseImpl.hasPatternFacet()));
/* 1007 */     sImpl.setPatterns(patternArray);
/*      */ 
/*      */ 
/*      */     
/* 1011 */     if (baseImpl.getBuiltinTypeCode() == 8 && 
/* 1012 */       sImpl.getEnumerationValues() == null) {
/* 1013 */       state.recover("enumeration-required-notation", null, restriction);
/*      */     }
/*      */   }
/*      */   
/*      */   private static XmlValueRef[] makeValueRefArray(XmlAnySimpleType[] source) {
/* 1018 */     XmlValueRef[] result = new XmlValueRef[source.length];
/* 1019 */     for (int i = 0; i < result.length; i++)
/* 1020 */       result[i] = (source[i] == null) ? null : new XmlValueRef(source[i]); 
/* 1021 */     return result;
/*      */   }
/*      */   
/* 1024 */   private static final RegularExpression[] EMPTY_REGEX_ARRAY = new RegularExpression[0];
/*      */ 
/*      */   
/*      */   private static boolean isDiscreteType(SchemaTypeImpl sImpl) {
/* 1028 */     if (sImpl.getFacet(8) != null) {
/* 1029 */       return true;
/*      */     }
/* 1031 */     switch (sImpl.getPrimitiveType().getBuiltinTypeCode()) {
/*      */       
/*      */       case 3:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/* 1040 */         return true;
/*      */     } 
/* 1042 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isNumericPrimitive(SchemaType sImpl) {
/* 1047 */     switch (sImpl.getBuiltinTypeCode()) {
/*      */       
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/* 1052 */         return true;
/*      */     } 
/* 1054 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int decimalSizeOfType(SchemaTypeImpl sImpl) {
/* 1059 */     int size = mathematicalSizeOfType(sImpl);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1065 */     if (size == 8 && !XmlByte.type.isAssignableFrom(sImpl))
/* 1066 */       size = 16; 
/* 1067 */     if (size == 16 && !XmlShort.type.isAssignableFrom(sImpl) && !XmlUnsignedByte.type.isAssignableFrom(sImpl)) {
/* 1068 */       size = 32;
/*      */     }
/* 1070 */     return size;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int mathematicalSizeOfType(SchemaTypeImpl sImpl) {
/* 1075 */     if (sImpl.getPrimitiveType().getBuiltinTypeCode() != 11) {
/* 1076 */       return 0;
/*      */     }
/* 1078 */     if (sImpl.getFacet(8) == null || ((SimpleValue)sImpl.getFacet(8)).getBigIntegerValue().signum() != 0)
/*      */     {
/* 1080 */       return 1000001;
/*      */     }
/* 1082 */     BigInteger min = null;
/* 1083 */     BigInteger max = null;
/*      */     
/* 1085 */     if (sImpl.getFacet(3) != null)
/* 1086 */       min = ((SimpleValue)sImpl.getFacet(3)).getBigIntegerValue(); 
/* 1087 */     if (sImpl.getFacet(4) != null)
/* 1088 */       min = ((SimpleValue)sImpl.getFacet(4)).getBigIntegerValue(); 
/* 1089 */     if (sImpl.getFacet(5) != null)
/* 1090 */       max = ((SimpleValue)sImpl.getFacet(5)).getBigIntegerValue(); 
/* 1091 */     if (sImpl.getFacet(6) != null) {
/* 1092 */       max = ((SimpleValue)sImpl.getFacet(6)).getBigIntegerValue();
/*      */     }
/* 1094 */     if (sImpl.getFacet(7) != null) {
/*      */       
/* 1096 */       BigInteger peg = null;
/*      */       
/*      */       try {
/* 1099 */         BigInteger totalDigits = ((SimpleValue)sImpl.getFacet(7)).getBigIntegerValue();
/*      */         
/* 1101 */         switch (totalDigits.intValue()) { case 0:
/*      */           case 1:
/*      */           case 2:
/* 1104 */             peg = BigInteger.valueOf(99L); break;
/*      */           case 3:
/*      */           case 4:
/* 1107 */             peg = BigInteger.valueOf(9999L); break;
/*      */           case 5: case 6: case 7: case 8:
/*      */           case 9:
/* 1110 */             peg = BigInteger.valueOf(999999999L); break;
/*      */           case 10: case 11: case 12: case 13: case 14: case 15: case 16:
/*      */           case 17:
/*      */           case 18:
/* 1114 */             peg = BigInteger.valueOf(999999999999999999L);
/*      */             break; }
/*      */ 
/*      */       
/* 1118 */       } catch (XmlValueOutOfRangeException e) {}
/* 1119 */       if (peg != null) {
/*      */         
/* 1121 */         min = (min == null) ? peg.negate() : min.max(peg.negate());
/* 1122 */         max = (max == null) ? peg : max.min(peg);
/*      */       } 
/*      */     } 
/*      */     
/* 1126 */     if (min != null && max != null) {
/*      */ 
/*      */       
/* 1129 */       if (min.signum() < 0)
/* 1130 */         min = min.negate().subtract(BigInteger.ONE); 
/* 1131 */       if (max.signum() < 0) {
/* 1132 */         max = max.negate().subtract(BigInteger.ONE);
/*      */       }
/* 1134 */       max = max.max(min);
/* 1135 */       if (max.compareTo(BigInteger.valueOf(127L)) <= 0)
/* 1136 */         return 8; 
/* 1137 */       if (max.compareTo(BigInteger.valueOf(32767L)) <= 0)
/* 1138 */         return 16; 
/* 1139 */       if (max.compareTo(BigInteger.valueOf(2147483647L)) <= 0)
/* 1140 */         return 32; 
/* 1141 */       if (max.compareTo(BigInteger.valueOf(Long.MAX_VALUE)) <= 0) {
/* 1142 */         return 64;
/*      */       }
/*      */     } 
/* 1145 */     return 1000000; } static void resolveFundamentalFacets(SchemaTypeImpl sImpl) {
/*      */     SchemaTypeImpl baseImpl;
/*      */     SchemaType[] mTypes;
/*      */     int ordered;
/*      */     boolean isBounded;
/*      */     boolean isFinite;
/*      */     boolean isNumeric;
/*      */     int i;
/* 1153 */     switch (sImpl.getSimpleVariety()) {
/*      */       
/*      */       case 1:
/* 1156 */         baseImpl = (SchemaTypeImpl)sImpl.getBaseType();
/* 1157 */         sImpl.setOrdered(baseImpl.ordered());
/* 1158 */         sImpl.setBounded(((sImpl.getFacet(3) != null || sImpl.getFacet(4) != null) && (sImpl.getFacet(5) != null || sImpl.getFacet(6) != null)));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1163 */         sImpl.setFinite((baseImpl.isFinite() || (sImpl.isBounded() && isDiscreteType(sImpl))));
/*      */         
/* 1165 */         sImpl.setNumeric((baseImpl.isNumeric() || isNumericPrimitive(sImpl.getPrimitiveType())));
/*      */         
/* 1167 */         sImpl.setDecimalSize(decimalSizeOfType(sImpl));
/*      */         break;
/*      */       case 2:
/* 1170 */         mTypes = sImpl.getUnionMemberTypes();
/* 1171 */         ordered = 0;
/* 1172 */         isBounded = true;
/* 1173 */         isFinite = true;
/* 1174 */         isNumeric = true;
/*      */         
/* 1176 */         for (i = 0; i < mTypes.length; i++) {
/*      */           
/* 1178 */           if (mTypes[i].ordered() != 0)
/* 1179 */             ordered = 1; 
/* 1180 */           if (!mTypes[i].isBounded())
/* 1181 */             isBounded = false; 
/* 1182 */           if (!mTypes[i].isFinite())
/* 1183 */             isFinite = false; 
/* 1184 */           if (!mTypes[i].isNumeric())
/* 1185 */             isNumeric = false; 
/*      */         } 
/* 1187 */         sImpl.setOrdered(ordered);
/* 1188 */         sImpl.setBounded(isBounded);
/* 1189 */         sImpl.setFinite(isFinite);
/* 1190 */         sImpl.setNumeric(isNumeric);
/* 1191 */         sImpl.setDecimalSize(0);
/*      */         break;
/*      */       case 3:
/* 1194 */         sImpl.setOrdered(0);
/*      */         
/* 1196 */         sImpl.setBounded((sImpl.getFacet(0) != null || sImpl.getFacet(2) != null));
/*      */ 
/*      */         
/* 1199 */         sImpl.setFinite((sImpl.getListItemType().isFinite() && sImpl.isBounded()));
/* 1200 */         sImpl.setNumeric(false);
/* 1201 */         sImpl.setDecimalSize(0);
/*      */         break;
/*      */     } 
/*      */   }
/*      */   private static class CodeForNameEntry { public QName name;
/*      */     public int code;
/*      */     
/*      */     CodeForNameEntry(QName name, int code) {
/* 1209 */       this.name = name; this.code = code;
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/* 1214 */   private static CodeForNameEntry[] facetCodes = new CodeForNameEntry[] { new CodeForNameEntry(QNameHelper.forLNS("length", "http://www.w3.org/2001/XMLSchema"), 0), new CodeForNameEntry(QNameHelper.forLNS("minLength", "http://www.w3.org/2001/XMLSchema"), 1), new CodeForNameEntry(QNameHelper.forLNS("maxLength", "http://www.w3.org/2001/XMLSchema"), 2), new CodeForNameEntry(QNameHelper.forLNS("pattern", "http://www.w3.org/2001/XMLSchema"), 10), new CodeForNameEntry(QNameHelper.forLNS("enumeration", "http://www.w3.org/2001/XMLSchema"), 11), new CodeForNameEntry(QNameHelper.forLNS("whiteSpace", "http://www.w3.org/2001/XMLSchema"), 9), new CodeForNameEntry(QNameHelper.forLNS("maxInclusive", "http://www.w3.org/2001/XMLSchema"), 5), new CodeForNameEntry(QNameHelper.forLNS("maxExclusive", "http://www.w3.org/2001/XMLSchema"), 6), new CodeForNameEntry(QNameHelper.forLNS("minInclusive", "http://www.w3.org/2001/XMLSchema"), 4), new CodeForNameEntry(QNameHelper.forLNS("minExclusive", "http://www.w3.org/2001/XMLSchema"), 3), new CodeForNameEntry(QNameHelper.forLNS("totalDigits", "http://www.w3.org/2001/XMLSchema"), 7), new CodeForNameEntry(QNameHelper.forLNS("fractionDigits", "http://www.w3.org/2001/XMLSchema"), 8) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1230 */   private static final Map facetCodeMap = buildFacetCodeMap();
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   private static Map buildFacetCodeMap() {
/* 1234 */     Map result = new HashMap();
/* 1235 */     for (int i = 0; i < facetCodes.length; i++)
/* 1236 */       result.put((facetCodes[i]).name, new Integer((facetCodes[i]).code)); 
/* 1237 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int translateFacetCode(QName name) {
/* 1242 */     Integer result = (Integer)facetCodeMap.get(name);
/* 1243 */     if (result == null)
/* 1244 */       return -1; 
/* 1245 */     return result.intValue();
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\StscSimpleTypeResolver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */