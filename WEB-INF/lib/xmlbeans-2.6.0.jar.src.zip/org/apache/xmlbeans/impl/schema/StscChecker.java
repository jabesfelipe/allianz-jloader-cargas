/*      */ package org.apache.xmlbeans.impl.schema;
/*      */ 
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.QNameSetSpecification;
/*      */ import org.apache.xmlbeans.SchemaAttributeModel;
/*      */ import org.apache.xmlbeans.SchemaGlobalElement;
/*      */ import org.apache.xmlbeans.SchemaIdentityConstraint;
/*      */ import org.apache.xmlbeans.SchemaLocalAttribute;
/*      */ import org.apache.xmlbeans.SchemaLocalElement;
/*      */ import org.apache.xmlbeans.SchemaParticle;
/*      */ import org.apache.xmlbeans.SchemaType;
/*      */ import org.apache.xmlbeans.XmlAnySimpleType;
/*      */ import org.apache.xmlbeans.XmlError;
/*      */ import org.apache.xmlbeans.XmlID;
/*      */ import org.apache.xmlbeans.XmlNOTATION;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.XmlString;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.common.XBeanDebug;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StscChecker
/*      */ {
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   public static void checkAll() {
/*   52 */     StscState state = StscState.get();
/*      */     
/*   54 */     List allSeenTypes = new ArrayList();
/*   55 */     allSeenTypes.addAll(Arrays.asList(state.documentTypes()));
/*   56 */     allSeenTypes.addAll(Arrays.asList(state.attributeTypes()));
/*   57 */     allSeenTypes.addAll(Arrays.asList(state.redefinedGlobalTypes()));
/*   58 */     allSeenTypes.addAll(Arrays.asList(state.globalTypes()));
/*      */     
/*   60 */     for (int i = 0; i < allSeenTypes.size(); i++) {
/*      */       
/*   62 */       SchemaType gType = allSeenTypes.get(i);
/*   63 */       if (!state.noPvr() && !gType.isDocumentType())
/*      */       {
/*      */         
/*   66 */         checkRestriction((SchemaTypeImpl)gType);
/*      */       }
/*   68 */       checkFields((SchemaTypeImpl)gType);
/*   69 */       allSeenTypes.addAll(Arrays.asList(gType.getAnonymousTypes()));
/*      */     } 
/*      */     
/*   72 */     checkSubstitutionGroups(state.globalElements());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkFields(SchemaTypeImpl sType) {
/*   82 */     if (sType.isSimpleType()) {
/*      */       return;
/*      */     }
/*   85 */     XmlObject location = sType.getParseObject();
/*      */     
/*   87 */     SchemaAttributeModel sAttrModel = sType.getAttributeModel();
/*   88 */     if (sAttrModel != null) {
/*      */       
/*   90 */       SchemaLocalAttribute[] sAttrs = sAttrModel.getAttributes();
/*   91 */       QName idAttr = null;
/*   92 */       for (int i = 0; i < sAttrs.length; i++) {
/*      */         
/*   94 */         XmlObject attrLocation = ((SchemaLocalAttributeImpl)sAttrs[i])._parseObject;
/*   95 */         if (XmlID.type.isAssignableFrom(sAttrs[i].getType())) {
/*      */           
/*   97 */           if (idAttr == null) {
/*      */             
/*   99 */             idAttr = sAttrs[i].getName();
/*      */           }
/*      */           else {
/*      */             
/*  103 */             StscState.get().error("ag-props-correct.3", new Object[] { QNameHelper.pretty(idAttr), sAttrs[i].getName() }, (attrLocation != null) ? attrLocation : location);
/*      */           } 
/*      */ 
/*      */           
/*  107 */           if (sAttrs[i].getDefaultText() != null)
/*      */           {
/*  109 */             StscState.get().error("a-props-correct.3", (Object[])null, (attrLocation != null) ? attrLocation : location);
/*      */           
/*      */           }
/*      */         }
/*  113 */         else if (XmlNOTATION.type.isAssignableFrom(sAttrs[i].getType())) {
/*      */           
/*  115 */           if (sAttrs[i].getType().getBuiltinTypeCode() == 8) {
/*      */             
/*  117 */             StscState.get().recover("enumeration-required-notation-attr", new Object[] { QNameHelper.pretty(sAttrs[i].getName()) }, (attrLocation != null) ? attrLocation : location);
/*      */           } else {
/*      */             boolean hasNS;
/*      */ 
/*      */ 
/*      */             
/*  123 */             if (sAttrs[i].getType().getSimpleVariety() == 2) {
/*      */               
/*  125 */               SchemaType[] members = sAttrs[i].getType().getUnionConstituentTypes();
/*  126 */               for (int j = 0; j < members.length; j++) {
/*  127 */                 if (members[j].getBuiltinTypeCode() == 8) {
/*  128 */                   StscState.get().recover("enumeration-required-notation-attr", new Object[] { QNameHelper.pretty(sAttrs[i].getName()) }, (attrLocation != null) ? attrLocation : location);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/*  134 */             if (sType.isAttributeType()) {
/*  135 */               hasNS = (sAttrs[i].getName().getNamespaceURI().length() > 0);
/*      */             } else {
/*      */               
/*  138 */               SchemaType t = sType;
/*  139 */               while (t.getOuterType() != null)
/*  140 */                 t = t.getOuterType(); 
/*  141 */               if (t.isDocumentType())
/*  142 */               { hasNS = (t.getDocumentElementName().getNamespaceURI().length() > 0); }
/*  143 */               else { hasNS = (t.getName().getNamespaceURI().length() > 0); }
/*      */             
/*  145 */             }  if (hasNS) {
/*  146 */               StscState.get().warning("notation-targetns-attr", new Object[] { QNameHelper.pretty(sAttrs[i].getName()) }, (attrLocation != null) ? attrLocation : location);
/*      */             }
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  153 */           String valueConstraint = sAttrs[i].getDefaultText();
/*  154 */           if (valueConstraint != null) {
/*      */             
/*      */             try {
/*      */               
/*  158 */               XmlAnySimpleType val = sAttrs[i].getDefaultValue();
/*  159 */               if (!val.validate()) {
/*  160 */                 throw new Exception();
/*      */               }
/*  162 */               SchemaPropertyImpl sProp = (SchemaPropertyImpl)sType.getAttributeProperty(sAttrs[i].getName());
/*  163 */               if (sProp != null && sProp.getDefaultText() != null)
/*      */               {
/*  165 */                 sProp.setDefaultValue(new XmlValueRef(val));
/*      */               }
/*      */             }
/*  168 */             catch (Exception e) {
/*      */ 
/*      */               
/*  171 */               String constraintName = sAttrs[i].isFixed() ? "fixed" : "default";
/*  172 */               XmlObject constraintLocation = location;
/*  173 */               if (attrLocation != null) {
/*      */                 
/*  175 */                 constraintLocation = attrLocation.selectAttribute("", constraintName);
/*  176 */                 if (constraintLocation == null) {
/*  177 */                   constraintLocation = attrLocation;
/*      */                 }
/*      */               } 
/*  180 */               StscState.get().error("a-props-correct.2", new Object[] { QNameHelper.pretty(sAttrs[i].getName()), constraintName, valueConstraint, QNameHelper.pretty(sAttrs[i].getType().getName()) }, constraintLocation);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  192 */     checkElementDefaults(sType.getContentModel(), location, sType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void checkElementDefaults(SchemaParticle model, XmlObject location, SchemaType parentType) {
/*      */     SchemaParticle[] children;
/*      */     int i;
/*      */     String valueConstraint;
/*      */     String warningType;
/*  205 */     if (model == null)
/*      */       return; 
/*  207 */     switch (model.getParticleType()) {
/*      */       
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*  212 */         children = model.getParticleChildren();
/*  213 */         for (i = 0; i < children.length; i++)
/*      */         {
/*  215 */           checkElementDefaults(children[i], location, parentType);
/*      */         }
/*      */         break;
/*      */       case 4:
/*  219 */         valueConstraint = model.getDefaultText();
/*  220 */         if (valueConstraint != null)
/*      */         {
/*  222 */           if (model.getType().isSimpleType() || model.getType().getContentType() == 2) {
/*      */             
/*      */             try
/*      */             {
/*  226 */               XmlAnySimpleType val = model.getDefaultValue();
/*  227 */               XmlOptions opt = new XmlOptions();
/*  228 */               opt.put("VALIDATE_TEXT_ONLY");
/*  229 */               if (!val.validate(opt)) {
/*  230 */                 throw new Exception();
/*      */               }
/*  232 */               SchemaPropertyImpl sProp = (SchemaPropertyImpl)parentType.getElementProperty(model.getName());
/*  233 */               if (sProp != null && sProp.getDefaultText() != null)
/*      */               {
/*  235 */                 sProp.setDefaultValue(new XmlValueRef(val));
/*      */               }
/*      */             }
/*  238 */             catch (Exception e)
/*      */             {
/*      */               
/*  241 */               String constraintName = model.isFixed() ? "fixed" : "default";
/*  242 */               XmlObject constraintLocation = location.selectAttribute("", constraintName);
/*      */               
/*  244 */               StscState.get().error("e-props-correct.2", new Object[] { QNameHelper.pretty(model.getName()), constraintName, valueConstraint, QNameHelper.pretty(model.getType().getName()) }, (constraintLocation == null) ? location : constraintLocation);
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  252 */           else if (model.getType().getContentType() == 4) {
/*      */             
/*  254 */             if (!model.getType().getContentModel().isSkippable())
/*      */             {
/*  256 */               String constraintName = model.isFixed() ? "fixed" : "default";
/*  257 */               XmlObject constraintLocation = location.selectAttribute("", constraintName);
/*      */               
/*  259 */               StscState.get().error("cos-valid-default.2.2.2", new Object[] { QNameHelper.pretty(model.getName()), constraintName, valueConstraint }, (constraintLocation == null) ? location : constraintLocation);
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/*      */ 
/*      */               
/*  269 */               SchemaPropertyImpl sProp = (SchemaPropertyImpl)parentType.getElementProperty(model.getName());
/*  270 */               if (sProp != null && sProp.getDefaultText() != null)
/*      */               {
/*  272 */                 sProp.setDefaultValue(new XmlValueRef(XmlString.type.newValue(valueConstraint)));
/*      */               }
/*      */             }
/*      */           
/*  276 */           } else if (model.getType().getContentType() == 3) {
/*      */             
/*  278 */             XmlObject constraintLocation = location.selectAttribute("", "default");
/*  279 */             StscState.get().error("cos-valid-default.2.1", new Object[] { QNameHelper.pretty(model.getName()), valueConstraint, "element" }, (constraintLocation == null) ? location : constraintLocation);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  285 */           else if (model.getType().getContentType() == 1) {
/*      */             
/*  287 */             XmlObject constraintLocation = location.selectAttribute("", "default");
/*  288 */             StscState.get().error("cos-valid-default.2.1", new Object[] { QNameHelper.pretty(model.getName()), valueConstraint, "empty" }, (constraintLocation == null) ? location : constraintLocation);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  296 */         warningType = null;
/*  297 */         if (BuiltinSchemaTypeSystem.ST_ID.isAssignableFrom(model.getType())) {
/*  298 */           warningType = BuiltinSchemaTypeSystem.ST_ID.getName().getLocalPart();
/*  299 */         } else if (BuiltinSchemaTypeSystem.ST_IDREF.isAssignableFrom(model.getType())) {
/*  300 */           warningType = BuiltinSchemaTypeSystem.ST_IDREF.getName().getLocalPart();
/*  301 */         } else if (BuiltinSchemaTypeSystem.ST_IDREFS.isAssignableFrom(model.getType())) {
/*  302 */           warningType = BuiltinSchemaTypeSystem.ST_IDREFS.getName().getLocalPart();
/*  303 */         } else if (BuiltinSchemaTypeSystem.ST_ENTITY.isAssignableFrom(model.getType())) {
/*  304 */           warningType = BuiltinSchemaTypeSystem.ST_ENTITY.getName().getLocalPart();
/*  305 */         } else if (BuiltinSchemaTypeSystem.ST_ENTITIES.isAssignableFrom(model.getType())) {
/*  306 */           warningType = BuiltinSchemaTypeSystem.ST_ENTITIES.getName().getLocalPart();
/*  307 */         } else if (BuiltinSchemaTypeSystem.ST_NOTATION.isAssignableFrom(model.getType())) {
/*      */           boolean hasNS;
/*  309 */           if (model.getType().getBuiltinTypeCode() == 8) {
/*      */             
/*  311 */             StscState.get().recover("enumeration-required-notation-elem", new Object[] { QNameHelper.pretty(model.getName()) }, (((SchemaLocalElementImpl)model)._parseObject == null) ? location : ((SchemaLocalElementImpl)model)._parseObject.selectAttribute("", "type"));
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/*  318 */             if (model.getType().getSimpleVariety() == 2) {
/*      */               
/*  320 */               SchemaType[] members = model.getType().getUnionConstituentTypes();
/*  321 */               for (int j = 0; j < members.length; j++) {
/*  322 */                 if (members[j].getBuiltinTypeCode() == 8) {
/*  323 */                   StscState.get().recover("enumeration-required-notation-elem", new Object[] { QNameHelper.pretty(model.getName()) }, (((SchemaLocalElementImpl)model)._parseObject == null) ? location : ((SchemaLocalElementImpl)model)._parseObject.selectAttribute("", "type"));
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/*  328 */             warningType = BuiltinSchemaTypeSystem.ST_NOTATION.getName().getLocalPart();
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  333 */           SchemaType t = parentType;
/*  334 */           while (t.getOuterType() != null)
/*  335 */             t = t.getOuterType(); 
/*  336 */           if (t.isDocumentType()) {
/*  337 */             hasNS = (t.getDocumentElementName().getNamespaceURI().length() > 0);
/*      */           } else {
/*  339 */             hasNS = (t.getName().getNamespaceURI().length() > 0);
/*  340 */           }  if (hasNS) {
/*  341 */             StscState.get().warning("notation-targetns-elem", new Object[] { QNameHelper.pretty(model.getName()) }, (((SchemaLocalElementImpl)model)._parseObject == null) ? location : ((SchemaLocalElementImpl)model)._parseObject);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  347 */         if (warningType != null) {
/*  348 */           StscState.get().warning("id-idref-idrefs-entity-entities-notation", new Object[] { QNameHelper.pretty(model.getName()), warningType }, (((SchemaLocalElementImpl)model)._parseObject == null) ? location : ((SchemaLocalElementImpl)model)._parseObject.selectAttribute("", "type"));
/*      */         }
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean checkRestriction(SchemaTypeImpl sType) {
/*  367 */     if (sType.getDerivationType() == 1 && !sType.isSimpleType()) {
/*      */       SchemaType cType; SchemaParticle baseModel, derivedModel; List errors; boolean isValid;
/*  369 */       StscState state = StscState.get();
/*      */ 
/*      */       
/*  372 */       XmlObject location = sType.getParseObject();
/*      */       
/*  374 */       SchemaType baseType = sType.getBaseType();
/*  375 */       if (baseType.isSimpleType()) {
/*      */         
/*  377 */         state.error("src-ct.1", new Object[] { QNameHelper.pretty(baseType.getName()) }, location);
/*      */ 
/*      */         
/*  380 */         return false;
/*      */       } 
/*      */ 
/*      */       
/*  384 */       switch (sType.getContentType()) {
/*      */ 
/*      */         
/*      */         case 2:
/*  388 */           switch (baseType.getContentType()) {
/*      */ 
/*      */             
/*      */             case 2:
/*  392 */               cType = sType.getContentBasedOnType();
/*  393 */               if (cType != baseType) {
/*      */ 
/*      */ 
/*      */                 
/*  397 */                 SchemaType bType = baseType;
/*  398 */                 while (bType != null && !bType.isSimpleType())
/*  399 */                   bType = bType.getContentBasedOnType(); 
/*  400 */                 if (bType != null && !bType.isAssignableFrom(cType)) {
/*      */                   
/*  402 */                   state.error("derivation-ok-restriction.5.2.2.1", (Object[])null, location);
/*      */                   
/*  404 */                   return false;
/*      */                 } 
/*      */               } 
/*      */               break;
/*      */ 
/*      */             
/*      */             case 4:
/*  411 */               if (baseType.getContentModel() != null && !baseType.getContentModel().isSkippable()) {
/*      */                 
/*  413 */                 state.error("derivation-ok-restriction.5.1.2", (Object[])null, location);
/*      */                 
/*  415 */                 return false;
/*      */               } 
/*      */               break;
/*      */           } 
/*      */           
/*  420 */           state.error("derivation-ok-restriction.5.1", (Object[])null, location);
/*      */           
/*  422 */           return false;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 1:
/*  428 */           switch (baseType.getContentType()) {
/*      */             case 1:
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 3:
/*      */             case 4:
/*  436 */               if (baseType.getContentModel() != null && !baseType.getContentModel().isSkippable()) {
/*      */                 
/*  438 */                 state.error("derivation-ok-restriction.5.2.2", (Object[])null, location);
/*      */                 
/*  440 */                 return false;
/*      */               } 
/*      */               break;
/*      */           } 
/*  444 */           state.error("derivation-ok-restriction.5.2", (Object[])null, location);
/*      */           
/*  446 */           return false;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/*  452 */           if (baseType.getContentType() != 4) {
/*      */             
/*  454 */             state.error("derivation-ok-restriction.5.3a", (Object[])null, location);
/*      */             
/*  456 */             return false;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/*  462 */           if (baseType.getContentType() == 1) {
/*      */             
/*  464 */             state.error("derivation-ok-restriction.5.3b", (Object[])null, location);
/*      */             
/*  466 */             return false;
/*      */           } 
/*  468 */           if (baseType.getContentType() == 2) {
/*      */             
/*  470 */             state.error("derivation-ok-restriction.5.3c", (Object[])null, location);
/*      */             
/*  472 */             return false;
/*      */           } 
/*      */ 
/*      */           
/*  476 */           baseModel = baseType.getContentModel();
/*  477 */           derivedModel = sType.getContentModel();
/*      */           
/*  479 */           if (derivedModel == null && sType.getDerivationType() == 1)
/*      */           {
/*      */ 
/*      */             
/*  483 */             return true;
/*      */           }
/*  485 */           if (baseModel == null || derivedModel == null) {
/*      */             
/*  487 */             XBeanDebug.logStackTrace("Null models that weren't caught by EMPTY_CONTENT: " + baseType + " (" + baseModel + "), " + sType + " (" + derivedModel + ")");
/*  488 */             state.error("derivation-ok-restriction.5.3", (Object[])null, location);
/*  489 */             return false;
/*      */           } 
/*      */ 
/*      */           
/*  493 */           errors = new ArrayList();
/*  494 */           isValid = isParticleValidRestriction(baseModel, derivedModel, errors, location);
/*  495 */           if (!isValid) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  500 */             if (errors.size() == 0) {
/*  501 */               state.error("derivation-ok-restriction.5.3", (Object[])null, location);
/*      */             } else {
/*  503 */               state.getErrorListener().add(errors.get(errors.size() - 1));
/*      */             } 
/*  505 */             return false;
/*      */           }  break;
/*      */       } 
/*      */     } 
/*  509 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isParticleValidRestriction(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/*  523 */     boolean restrictionValid = false;
/*      */     
/*  525 */     if (baseModel.equals(derivedModel))
/*  526 */     { restrictionValid = true; }
/*      */     
/*      */     else
/*      */     
/*  530 */     { switch (baseModel.getParticleType())
/*      */       { case 4:
/*  532 */           switch (derivedModel.getParticleType())
/*      */           { case 4:
/*  534 */               restrictionValid = nameAndTypeOK((SchemaLocalElement)baseModel, (SchemaLocalElement)derivedModel, errors, context);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  636 */               return restrictionValid;case 1: case 2: case 3: case 5: errors.add(XmlError.forObject("cos-particle-restrict.2", new Object[] { printParticle(derivedModel), printParticle(baseModel) }, context)); restrictionValid = false; return restrictionValid; }  assert false : XBeanDebug.logStackTrace("Unknown schema type for Derived Type"); return restrictionValid;case 5: switch (derivedModel.getParticleType()) { case 4: restrictionValid = nsCompat(baseModel, (SchemaLocalElement)derivedModel, errors, context); return restrictionValid;case 5: restrictionValid = nsSubset(baseModel, derivedModel, errors, context); return restrictionValid;case 1: restrictionValid = nsRecurseCheckCardinality(baseModel, derivedModel, errors, context); return restrictionValid;case 2: restrictionValid = nsRecurseCheckCardinality(baseModel, derivedModel, errors, context); return restrictionValid;case 3: restrictionValid = nsRecurseCheckCardinality(baseModel, derivedModel, errors, context); return restrictionValid; }  assert false : XBeanDebug.logStackTrace("Unknown schema type for Derived Type"); return restrictionValid;case 1: switch (derivedModel.getParticleType()) { case 4: restrictionValid = recurseAsIfGroup(baseModel, derivedModel, errors, context); return restrictionValid;case 2: case 5: errors.add(XmlError.forObject("cos-particle-restrict.2", new Object[] { printParticle(derivedModel), printParticle(baseModel) }, context)); restrictionValid = false; return restrictionValid;case 1: restrictionValid = recurse(baseModel, derivedModel, errors, context); return restrictionValid;case 3: restrictionValid = recurseUnordered(baseModel, derivedModel, errors, context); return restrictionValid; }  assert false : XBeanDebug.logStackTrace("Unknown schema type for Derived Type"); return restrictionValid;case 2: switch (derivedModel.getParticleType()) { case 4: restrictionValid = recurseAsIfGroup(baseModel, derivedModel, errors, context); return restrictionValid;case 1: case 5: errors.add(XmlError.forObject("cos-particle-restrict.2", new Object[] { printParticle(derivedModel), printParticle(baseModel) }, context)); restrictionValid = false; return restrictionValid;case 2: restrictionValid = recurseLax(baseModel, derivedModel, errors, context); return restrictionValid;case 3: restrictionValid = mapAndSum(baseModel, derivedModel, errors, context); return restrictionValid; }  assert false : XBeanDebug.logStackTrace("Unknown schema type for Derived Type"); return restrictionValid;case 3: switch (derivedModel.getParticleType()) { case 4: restrictionValid = recurseAsIfGroup(baseModel, derivedModel, errors, context); return restrictionValid;case 1: case 2: case 5: errors.add(XmlError.forObject("cos-particle-restrict.2", new Object[] { printParticle(derivedModel), printParticle(baseModel) }, context)); restrictionValid = false; return restrictionValid;case 3: restrictionValid = recurse(baseModel, derivedModel, errors, context); return restrictionValid; }  assert false : XBeanDebug.logStackTrace("Unknown schema type for Derived Type"); return restrictionValid; }  assert false : XBeanDebug.logStackTrace("Unknown schema type for Base Type"); }  return restrictionValid;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean mapAndSum(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/*  641 */     assert baseModel.getParticleType() == 2;
/*  642 */     assert derivedModel.getParticleType() == 3;
/*  643 */     boolean mapAndSumValid = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  661 */     SchemaParticle[] derivedParticleArray = derivedModel.getParticleChildren();
/*  662 */     SchemaParticle[] baseParticleArray = baseModel.getParticleChildren();
/*  663 */     for (int i = 0; i < derivedParticleArray.length; i++) {
/*  664 */       SchemaParticle derivedParticle = derivedParticleArray[i];
/*  665 */       boolean foundMatch = false;
/*  666 */       for (int j = 0; j < baseParticleArray.length; j++) {
/*  667 */         SchemaParticle baseParticle = baseParticleArray[j];
/*      */         
/*  669 */         if (isParticleValidRestriction(baseParticle, derivedParticle, errors, context)) {
/*      */           
/*  671 */           foundMatch = true;
/*      */           break;
/*      */         } 
/*      */       } 
/*  675 */       if (!foundMatch) {
/*  676 */         mapAndSumValid = false;
/*  677 */         errors.add(XmlError.forObject("rcase-MapAndSum.1", new Object[] { printParticle(derivedParticle) }, context));
/*      */ 
/*      */ 
/*      */         
/*  681 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  687 */     BigInteger derivedRangeMin = derivedModel.getMinOccurs().multiply(BigInteger.valueOf((derivedModel.getParticleChildren()).length));
/*  688 */     BigInteger derivedRangeMax = null;
/*  689 */     BigInteger UNBOUNDED = null;
/*  690 */     if (derivedModel.getMaxOccurs() == UNBOUNDED) {
/*  691 */       derivedRangeMax = null;
/*      */     } else {
/*  693 */       derivedRangeMax = derivedModel.getMaxOccurs().multiply(BigInteger.valueOf((derivedModel.getParticleChildren()).length));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  704 */     if (derivedRangeMin.compareTo(baseModel.getMinOccurs()) < 0) {
/*  705 */       mapAndSumValid = false;
/*  706 */       errors.add(XmlError.forObject("rcase-MapAndSum.2a", new Object[] { derivedRangeMin.toString(), baseModel.getMinOccurs().toString() }, context));
/*      */     
/*      */     }
/*  709 */     else if (baseModel.getMaxOccurs() != UNBOUNDED && (derivedRangeMax == UNBOUNDED || derivedRangeMax.compareTo(baseModel.getMaxOccurs()) > 0)) {
/*  710 */       mapAndSumValid = false;
/*  711 */       errors.add(XmlError.forObject("rcase-MapAndSum.2b", new Object[] { (derivedRangeMax == UNBOUNDED) ? "unbounded" : derivedRangeMax.toString(), baseModel.getMaxOccurs().toString() }, context));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  716 */     return mapAndSumValid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean recurseAsIfGroup(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/*  724 */     assert (baseModel.getParticleType() == 2 && derivedModel.getParticleType() == 4) || (baseModel.getParticleType() == 3 && derivedModel.getParticleType() == 4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  738 */     SchemaParticleImpl asIfPart = new SchemaParticleImpl();
/*  739 */     asIfPart.setParticleType(baseModel.getParticleType());
/*  740 */     asIfPart.setMinOccurs(BigInteger.ONE);
/*  741 */     asIfPart.setMaxOccurs(BigInteger.ONE);
/*  742 */     asIfPart.setParticleChildren(new SchemaParticle[] { derivedModel });
/*      */ 
/*      */     
/*  745 */     return isParticleValidRestriction(baseModel, asIfPart, errors, context);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean recurseLax(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/*  750 */     assert baseModel.getParticleType() == 2 && derivedModel.getParticleType() == 2;
/*  751 */     boolean recurseLaxValid = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  767 */     if (!occurrenceRangeOK(baseModel, derivedModel, errors, context)) {
/*  768 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  773 */     SchemaParticle[] derivedParticleArray = derivedModel.getParticleChildren();
/*  774 */     SchemaParticle[] baseParticleArray = baseModel.getParticleChildren();
/*  775 */     int i = 0, j = 0;
/*  776 */     while (i < derivedParticleArray.length && j < baseParticleArray.length) {
/*  777 */       SchemaParticle derivedParticle = derivedParticleArray[i];
/*  778 */       SchemaParticle baseParticle = baseParticleArray[j];
/*      */       
/*  780 */       if (isParticleValidRestriction(baseParticle, derivedParticle, errors, context)) {
/*      */         
/*  782 */         i++;
/*  783 */         j++;
/*      */         
/*      */         continue;
/*      */       } 
/*  787 */       j++;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  794 */     if (i < derivedParticleArray.length) {
/*  795 */       recurseLaxValid = false;
/*      */ 
/*      */       
/*  798 */       errors.add(XmlError.forObject("rcase-RecurseLax.2", new Object[] { printParticles(baseParticleArray, i) }context));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  804 */     return recurseLaxValid;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean recurseUnordered(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/*  809 */     assert baseModel.getParticleType() == 1 && derivedModel.getParticleType() == 3;
/*  810 */     boolean recurseUnorderedValid = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  828 */     if (!occurrenceRangeOK(baseModel, derivedModel, errors, context)) {
/*  829 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  833 */     SchemaParticle[] baseParticles = baseModel.getParticleChildren();
/*  834 */     HashMap baseParticleMap = new HashMap(10);
/*  835 */     Object MAPPED = new Object();
/*      */     
/*  837 */     for (int i = 0; i < baseParticles.length; i++) {
/*  838 */       baseParticleMap.put(baseParticles[i].getName(), baseParticles[i]);
/*      */     }
/*      */     
/*  841 */     SchemaParticle[] derivedParticles = derivedModel.getParticleChildren();
/*  842 */     for (int j = 0; j < derivedParticles.length; j++) {
/*  843 */       Object baseParticle = baseParticleMap.get(derivedParticles[j].getName());
/*  844 */       if (baseParticle == null) {
/*  845 */         recurseUnorderedValid = false;
/*  846 */         errors.add(XmlError.forObject("rcase-RecurseUnordered.2", new Object[] { printParticle(derivedParticles[j]) }, context));
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/*  851 */       if (baseParticle == MAPPED) {
/*      */         
/*  853 */         recurseUnorderedValid = false;
/*  854 */         errors.add(XmlError.forObject("rcase-RecurseUnordered.2.1", new Object[] { printParticle(derivedParticles[j]) }, context));
/*      */         
/*      */         break;
/*      */       } 
/*  858 */       SchemaParticle matchedBaseParticle = (SchemaParticle)baseParticle;
/*  859 */       if (derivedParticles[j].getMaxOccurs() == null || derivedParticles[j].getMaxOccurs().compareTo(BigInteger.ONE) > 0) {
/*      */ 
/*      */         
/*  862 */         recurseUnorderedValid = false;
/*  863 */         errors.add(XmlError.forObject("rcase-RecurseUnordered.2.2a", new Object[] { printParticle(derivedParticles[j]), printMaxOccurs(derivedParticles[j].getMinOccurs()) }, context));
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/*  868 */       if (!isParticleValidRestriction(matchedBaseParticle, derivedParticles[j], errors, context)) {
/*      */ 
/*      */         
/*  871 */         recurseUnorderedValid = false;
/*      */         
/*      */         break;
/*      */       } 
/*  875 */       baseParticleMap.put(derivedParticles[j].getName(), MAPPED);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  881 */     if (recurseUnorderedValid) {
/*      */       
/*  883 */       Set baseParticleCollection = baseParticleMap.keySet();
/*  884 */       for (Iterator iterator = baseParticleCollection.iterator(); iterator.hasNext(); ) {
/*  885 */         QName baseParticleQName = iterator.next();
/*  886 */         if (baseParticleMap.get(baseParticleQName) != MAPPED && !((SchemaParticle)baseParticleMap.get(baseParticleQName)).isSkippable()) {
/*      */           
/*  888 */           recurseUnorderedValid = false;
/*  889 */           errors.add(XmlError.forObject("rcase-RecurseUnordered.2.3", new Object[] { printParticle((SchemaParticle)baseParticleMap.get(baseParticleQName)) }, context));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  896 */     return recurseUnorderedValid;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean recurse(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/*  901 */     boolean recurseValid = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  920 */     if (!occurrenceRangeOK(baseModel, derivedModel, errors, context))
/*      */     {
/*  922 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  930 */     SchemaParticle[] derivedParticleArray = derivedModel.getParticleChildren();
/*  931 */     SchemaParticle[] baseParticleArray = baseModel.getParticleChildren();
/*  932 */     int i = 0, j = 0;
/*  933 */     while (i < derivedParticleArray.length && j < baseParticleArray.length) {
/*  934 */       SchemaParticle derivedParticle = derivedParticleArray[i];
/*  935 */       SchemaParticle baseParticle = baseParticleArray[j];
/*      */       
/*  937 */       if (isParticleValidRestriction(baseParticle, derivedParticle, errors, context)) {
/*      */         
/*  939 */         i++;
/*  940 */         j++;
/*      */         
/*      */         continue;
/*      */       } 
/*  944 */       if (baseParticle.isSkippable()) {
/*      */         
/*  946 */         j++;
/*      */         continue;
/*      */       } 
/*  949 */       recurseValid = false;
/*  950 */       errors.add(XmlError.forObject("rcase-Recurse.2.1", new Object[] { printParticle(derivedParticle), printParticle(derivedModel), printParticle(baseParticle), printParticle(baseModel) }, context));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  962 */     if (i < derivedParticleArray.length) {
/*  963 */       recurseValid = false;
/*  964 */       errors.add(XmlError.forObject("rcase-Recurse.2", new Object[] { printParticle(derivedModel), printParticle(baseModel), printParticles(derivedParticleArray, i) }context));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  970 */     else if (j < baseParticleArray.length) {
/*  971 */       ArrayList particles = new ArrayList(baseParticleArray.length);
/*  972 */       for (int k = j; k < baseParticleArray.length; k++) {
/*  973 */         if (!baseParticleArray[k].isSkippable()) {
/*  974 */           particles.add(baseParticleArray[k]);
/*      */         }
/*      */       } 
/*  977 */       if (particles.size() > 0) {
/*      */         
/*  979 */         recurseValid = false;
/*  980 */         errors.add(XmlError.forObject("rcase-Recurse.2.2", new Object[] { printParticle(baseModel), printParticle(derivedModel), printParticles(particles) }, context));
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  986 */     return recurseValid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean nsRecurseCheckCardinality(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/*  994 */     assert baseModel.getParticleType() == 5;
/*  995 */     assert derivedModel.getParticleType() == 1 || derivedModel.getParticleType() == 2 || derivedModel.getParticleType() == 3;
/*      */ 
/*      */     
/*  998 */     boolean nsRecurseCheckCardinality = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1009 */     SchemaParticleImpl asIfPart = new SchemaParticleImpl();
/* 1010 */     asIfPart.setParticleType(baseModel.getParticleType());
/* 1011 */     asIfPart.setWildcardProcess(baseModel.getWildcardProcess());
/* 1012 */     asIfPart.setWildcardSet(baseModel.getWildcardSet());
/* 1013 */     asIfPart.setMinOccurs(BigInteger.ZERO);
/* 1014 */     asIfPart.setMaxOccurs(null);
/* 1015 */     asIfPart.setTransitionRules(baseModel.getWildcardSet(), true);
/* 1016 */     asIfPart.setTransitionNotes(baseModel.getWildcardSet(), true);
/*      */     
/* 1018 */     SchemaParticle[] particleChildren = derivedModel.getParticleChildren();
/* 1019 */     for (int i = 0; i < particleChildren.length; i++) {
/* 1020 */       SchemaParticle particle = particleChildren[i];
/* 1021 */       switch (particle.getParticleType()) {
/*      */         
/*      */         case 4:
/* 1024 */           nsRecurseCheckCardinality = nsCompat(asIfPart, (SchemaLocalElement)particle, errors, context);
/*      */           break;
/*      */         
/*      */         case 5:
/* 1028 */           nsRecurseCheckCardinality = nsSubset(asIfPart, particle, errors, context);
/*      */           break;
/*      */         
/*      */         case 1:
/*      */         case 2:
/*      */         case 3:
/* 1034 */           nsRecurseCheckCardinality = nsRecurseCheckCardinality(asIfPart, particle, errors, context);
/*      */           break;
/*      */       } 
/*      */       
/* 1038 */       if (!nsRecurseCheckCardinality) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1047 */     if (nsRecurseCheckCardinality) {
/* 1048 */       nsRecurseCheckCardinality = checkGroupOccurrenceOK(baseModel, derivedModel, errors, context);
/*      */     }
/*      */     
/* 1051 */     return nsRecurseCheckCardinality;
/*      */   }
/*      */   
/*      */   private static boolean checkGroupOccurrenceOK(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/* 1055 */     boolean groupOccurrenceOK = true;
/* 1056 */     BigInteger minRange = BigInteger.ZERO;
/* 1057 */     BigInteger maxRange = BigInteger.ZERO;
/* 1058 */     switch (derivedModel.getParticleType()) {
/*      */       case 1:
/*      */       case 3:
/* 1061 */         minRange = getEffectiveMinRangeAllSeq(derivedModel);
/* 1062 */         maxRange = getEffectiveMaxRangeAllSeq(derivedModel);
/*      */         break;
/*      */       case 2:
/* 1065 */         minRange = getEffectiveMinRangeChoice(derivedModel);
/* 1066 */         maxRange = getEffectiveMaxRangeChoice(derivedModel);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1072 */     if (minRange.compareTo(baseModel.getMinOccurs()) < 0) {
/* 1073 */       groupOccurrenceOK = false;
/* 1074 */       errors.add(XmlError.forObject("range-ok.1", new Object[] { printParticle(derivedModel), printParticle(baseModel) }, context));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1082 */     BigInteger UNBOUNDED = null;
/* 1083 */     if (baseModel.getMaxOccurs() != UNBOUNDED) {
/* 1084 */       if (maxRange == UNBOUNDED) {
/* 1085 */         groupOccurrenceOK = false;
/* 1086 */         errors.add(XmlError.forObject("range-ok.2", new Object[] { printParticle(derivedModel), printParticle(baseModel) }, context));
/*      */ 
/*      */       
/*      */       }
/* 1090 */       else if (maxRange.compareTo(baseModel.getMaxOccurs()) > 0) {
/* 1091 */         groupOccurrenceOK = false;
/* 1092 */         errors.add(XmlError.forObject("range-ok.2", new Object[] { printParticle(derivedModel), printParticle(baseModel) }, context));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1098 */     return groupOccurrenceOK;
/*      */   }
/*      */   
/*      */   private static BigInteger getEffectiveMaxRangeChoice(SchemaParticle derivedModel) {
/* 1102 */     BigInteger maxRange = BigInteger.ZERO;
/* 1103 */     BigInteger UNBOUNDED = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1118 */     boolean nonZeroParticleChildFound = false;
/* 1119 */     BigInteger maxOccursInWildCardOrElement = BigInteger.ZERO;
/* 1120 */     BigInteger maxOccursInGroup = BigInteger.ZERO;
/* 1121 */     SchemaParticle[] particleChildren = derivedModel.getParticleChildren();
/* 1122 */     for (int i = 0; i < particleChildren.length; i++) {
/* 1123 */       SchemaParticle particle = particleChildren[i];
/* 1124 */       switch (particle.getParticleType()) {
/*      */         
/*      */         case 4:
/*      */         case 5:
/* 1128 */           if (particle.getMaxOccurs() == UNBOUNDED) {
/* 1129 */             maxRange = UNBOUNDED; break;
/*      */           } 
/* 1131 */           if (particle.getIntMaxOccurs() > 0) {
/*      */             
/* 1133 */             nonZeroParticleChildFound = true;
/* 1134 */             if (particle.getMaxOccurs().compareTo(maxOccursInWildCardOrElement) > 0) {
/* 1135 */               maxOccursInWildCardOrElement = particle.getMaxOccurs();
/*      */             }
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 1:
/*      */         case 3:
/* 1142 */           maxRange = getEffectiveMaxRangeAllSeq(particle);
/* 1143 */           if (maxRange != UNBOUNDED)
/*      */           {
/* 1145 */             if (maxRange.compareTo(maxOccursInGroup) > 0) {
/* 1146 */               maxOccursInGroup = maxRange;
/*      */             }
/*      */           }
/*      */           break;
/*      */         case 2:
/* 1151 */           maxRange = getEffectiveMaxRangeChoice(particle);
/* 1152 */           if (maxRange != UNBOUNDED)
/*      */           {
/* 1154 */             if (maxRange.compareTo(maxOccursInGroup) > 0) {
/* 1155 */               maxOccursInGroup = maxRange;
/*      */             }
/*      */           }
/*      */           break;
/*      */       } 
/*      */       
/* 1161 */       if (maxRange == UNBOUNDED) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1169 */     if (maxRange != UNBOUNDED)
/*      */     {
/* 1171 */       if (nonZeroParticleChildFound && derivedModel.getMaxOccurs() == UNBOUNDED) {
/* 1172 */         maxRange = UNBOUNDED;
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1177 */         maxRange = derivedModel.getMaxOccurs().multiply(maxOccursInWildCardOrElement.add(maxOccursInGroup));
/*      */       } 
/*      */     }
/*      */     
/* 1181 */     return maxRange;
/*      */   }
/*      */   
/*      */   private static BigInteger getEffectiveMaxRangeAllSeq(SchemaParticle derivedModel) {
/* 1185 */     BigInteger maxRange = BigInteger.ZERO;
/* 1186 */     BigInteger UNBOUNDED = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1198 */     boolean nonZeroParticleChildFound = false;
/* 1199 */     BigInteger maxOccursTotal = BigInteger.ZERO;
/* 1200 */     BigInteger maxOccursInGroup = BigInteger.ZERO;
/* 1201 */     SchemaParticle[] particleChildren = derivedModel.getParticleChildren();
/* 1202 */     for (int i = 0; i < particleChildren.length; i++) {
/* 1203 */       SchemaParticle particle = particleChildren[i];
/* 1204 */       switch (particle.getParticleType()) {
/*      */         
/*      */         case 4:
/*      */         case 5:
/* 1208 */           if (particle.getMaxOccurs() == UNBOUNDED) {
/* 1209 */             maxRange = UNBOUNDED; break;
/*      */           } 
/* 1211 */           if (particle.getIntMaxOccurs() > 0) {
/*      */             
/* 1213 */             nonZeroParticleChildFound = true;
/* 1214 */             maxOccursTotal = maxOccursTotal.add(particle.getMaxOccurs());
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 1:
/*      */         case 3:
/* 1220 */           maxRange = getEffectiveMaxRangeAllSeq(particle);
/* 1221 */           if (maxRange != UNBOUNDED)
/*      */           {
/* 1223 */             if (maxRange.compareTo(maxOccursInGroup) > 0) {
/* 1224 */               maxOccursInGroup = maxRange;
/*      */             }
/*      */           }
/*      */           break;
/*      */         case 2:
/* 1229 */           maxRange = getEffectiveMaxRangeChoice(particle);
/* 1230 */           if (maxRange != UNBOUNDED)
/*      */           {
/* 1232 */             if (maxRange.compareTo(maxOccursInGroup) > 0) {
/* 1233 */               maxOccursInGroup = maxRange;
/*      */             }
/*      */           }
/*      */           break;
/*      */       } 
/*      */       
/* 1239 */       if (maxRange == UNBOUNDED) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1247 */     if (maxRange != UNBOUNDED)
/*      */     {
/* 1249 */       if (nonZeroParticleChildFound && derivedModel.getMaxOccurs() == UNBOUNDED) {
/* 1250 */         maxRange = UNBOUNDED;
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1255 */         maxRange = derivedModel.getMaxOccurs().multiply(maxOccursTotal.add(maxOccursInGroup));
/*      */       } 
/*      */     }
/*      */     
/* 1259 */     return maxRange;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BigInteger getEffectiveMinRangeChoice(SchemaParticle derivedModel) {
/* 1272 */     SchemaParticle[] particleChildren = derivedModel.getParticleChildren();
/* 1273 */     if (particleChildren.length == 0)
/* 1274 */       return BigInteger.ZERO; 
/* 1275 */     BigInteger minRange = null;
/*      */ 
/*      */     
/* 1278 */     for (int i = 0; i < particleChildren.length; i++) {
/* 1279 */       BigInteger mrs, mrc; SchemaParticle particle = particleChildren[i];
/* 1280 */       switch (particle.getParticleType()) {
/*      */         case 4:
/*      */         case 5:
/* 1283 */           if (minRange == null || minRange.compareTo(particle.getMinOccurs()) > 0) {
/* 1284 */             minRange = particle.getMinOccurs();
/*      */           }
/*      */           break;
/*      */         case 1:
/*      */         case 3:
/* 1289 */           mrs = getEffectiveMinRangeAllSeq(particle);
/* 1290 */           if (minRange == null || minRange.compareTo(mrs) > 0) {
/* 1291 */             minRange = mrs;
/*      */           }
/*      */           break;
/*      */         case 2:
/* 1295 */           mrc = getEffectiveMinRangeChoice(particle);
/* 1296 */           if (minRange == null || minRange.compareTo(mrc) > 0) {
/* 1297 */             minRange = mrc;
/*      */           }
/*      */           break;
/*      */       } 
/*      */     } 
/* 1302 */     if (minRange == null) {
/* 1303 */       minRange = BigInteger.ZERO;
/*      */     }
/*      */     
/* 1306 */     minRange = derivedModel.getMinOccurs().multiply(minRange);
/* 1307 */     return minRange;
/*      */   }
/*      */   
/*      */   private static BigInteger getEffectiveMinRangeAllSeq(SchemaParticle derivedModel) {
/* 1311 */     BigInteger minRange = BigInteger.ZERO;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1321 */     SchemaParticle[] particleChildren = derivedModel.getParticleChildren();
/* 1322 */     BigInteger particleTotalMinOccurs = BigInteger.ZERO;
/* 1323 */     for (int i = 0; i < particleChildren.length; i++) {
/* 1324 */       SchemaParticle particle = particleChildren[i];
/* 1325 */       switch (particle.getParticleType()) {
/*      */         case 4:
/*      */         case 5:
/* 1328 */           particleTotalMinOccurs = particleTotalMinOccurs.add(particle.getMinOccurs());
/*      */           break;
/*      */         case 1:
/*      */         case 3:
/* 1332 */           particleTotalMinOccurs = particleTotalMinOccurs.add(getEffectiveMinRangeAllSeq(particle));
/*      */           break;
/*      */         case 2:
/* 1335 */           particleTotalMinOccurs = particleTotalMinOccurs.add(getEffectiveMinRangeChoice(particle));
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 1340 */     minRange = derivedModel.getMinOccurs().multiply(particleTotalMinOccurs);
/*      */     
/* 1342 */     return minRange;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean nsSubset(SchemaParticle baseModel, SchemaParticle derivedModel, Collection errors, XmlObject context) {
/* 1347 */     assert baseModel.getParticleType() == 5;
/* 1348 */     assert derivedModel.getParticleType() == 5;
/* 1349 */     boolean nsSubset = false;
/*      */ 
/*      */     
/* 1352 */     if (occurrenceRangeOK(baseModel, derivedModel, errors, context)) {
/*      */ 
/*      */       
/* 1355 */       if (baseModel.getWildcardSet().inverse().isDisjoint((QNameSetSpecification)derivedModel.getWildcardSet())) {
/* 1356 */         nsSubset = true;
/*      */       } else {
/* 1358 */         nsSubset = false;
/* 1359 */         errors.add(XmlError.forObject("rcase-NSSubset.2", new Object[] { printParticle(derivedModel), printParticle(baseModel) }, context));
/*      */       } 
/*      */     } else {
/*      */       
/* 1363 */       nsSubset = false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1369 */     return nsSubset;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean nsCompat(SchemaParticle baseModel, SchemaLocalElement derivedElement, Collection errors, XmlObject context) {
/* 1374 */     assert baseModel.getParticleType() == 5;
/* 1375 */     boolean nsCompat = false;
/*      */ 
/*      */ 
/*      */     
/* 1379 */     if (baseModel.getWildcardSet().contains(derivedElement.getName())) {
/*      */       
/* 1381 */       if (occurrenceRangeOK(baseModel, (SchemaParticle)derivedElement, errors, context)) {
/* 1382 */         nsCompat = true;
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1388 */       nsCompat = false;
/* 1389 */       errors.add(XmlError.forObject("rcase-NSCompat.1", new Object[] { printParticle((SchemaParticle)derivedElement), printParticle(baseModel) }, context));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1395 */     return nsCompat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean nameAndTypeOK(SchemaLocalElement baseElement, SchemaLocalElement derivedElement, Collection errors, XmlObject context) {
/* 1403 */     if (!((SchemaParticle)baseElement).canStartWithElement(derivedElement.getName())) {
/* 1404 */       errors.add(XmlError.forObject("rcase-NameAndTypeOK.1", new Object[] { printParticle((SchemaParticle)derivedElement), printParticle((SchemaParticle)baseElement) }, context));
/*      */       
/* 1406 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1410 */     if (!baseElement.isNillable() && derivedElement.isNillable()) {
/* 1411 */       errors.add(XmlError.forObject("rcase-NameAndTypeOK.2", new Object[] { printParticle((SchemaParticle)derivedElement), printParticle((SchemaParticle)baseElement) }, context));
/*      */       
/* 1413 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1417 */     if (!occurrenceRangeOK((SchemaParticle)baseElement, (SchemaParticle)derivedElement, errors, context))
/*      */     {
/* 1419 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1424 */     if (!checkFixed(baseElement, derivedElement, errors, context))
/*      */     {
/*      */       
/* 1427 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1431 */     if (!checkIdentityConstraints(baseElement, derivedElement, errors, context))
/*      */     {
/*      */       
/* 1434 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1439 */     if (!typeDerivationOK(baseElement.getType(), derivedElement.getType(), errors, context))
/*      */     {
/*      */       
/* 1442 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1446 */     if (!blockSetOK(baseElement, derivedElement, errors, context))
/*      */     {
/*      */       
/* 1449 */       return false;
/*      */     }
/*      */     
/* 1452 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean blockSetOK(SchemaLocalElement baseElement, SchemaLocalElement derivedElement, Collection errors, XmlObject context) {
/* 1457 */     if (baseElement.blockRestriction() && !derivedElement.blockRestriction()) {
/*      */       
/* 1459 */       errors.add(XmlError.forObject("rcase-NameAndTypeOK.6", new Object[] { printParticle((SchemaParticle)derivedElement), "restriction", printParticle((SchemaParticle)baseElement) }, context));
/*      */ 
/*      */       
/* 1462 */       return false;
/*      */     } 
/* 1464 */     if (baseElement.blockExtension() && !derivedElement.blockExtension()) {
/*      */       
/* 1466 */       errors.add(XmlError.forObject("rcase-NameAndTypeOK.6", new Object[] { printParticle((SchemaParticle)derivedElement), "extension", printParticle((SchemaParticle)baseElement) }, context));
/*      */ 
/*      */       
/* 1469 */       return false;
/*      */     } 
/* 1471 */     if (baseElement.blockSubstitution() && !derivedElement.blockSubstitution()) {
/*      */       
/* 1473 */       errors.add(XmlError.forObject("rcase-NameAndTypeOK.6", new Object[] { printParticle((SchemaParticle)derivedElement), "substitution", printParticle((SchemaParticle)baseElement) }, context));
/*      */ 
/*      */       
/* 1476 */       return false;
/*      */     } 
/* 1478 */     return true;
/*      */   }
/*      */   
/*      */   private static boolean typeDerivationOK(SchemaType baseType, SchemaType derivedType, Collection errors, XmlObject context) {
/* 1482 */     boolean typeDerivationOK = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1493 */     if (baseType.isAssignableFrom(derivedType)) {
/*      */ 
/*      */       
/* 1496 */       typeDerivationOK = checkAllDerivationsForRestriction(baseType, derivedType, errors, context);
/*      */     } else {
/*      */       
/* 1499 */       typeDerivationOK = false;
/* 1500 */       errors.add(XmlError.forObject("rcase-NameAndTypeOK.7a", new Object[] { printType(derivedType), printType(baseType) }, context));
/*      */     } 
/*      */ 
/*      */     
/* 1504 */     return typeDerivationOK;
/*      */   }
/*      */   
/*      */   private static boolean checkAllDerivationsForRestriction(SchemaType baseType, SchemaType derivedType, Collection errors, XmlObject context) {
/* 1508 */     boolean allDerivationsAreRestrictions = true;
/* 1509 */     SchemaType currentType = derivedType;
/*      */ 
/*      */     
/* 1512 */     Set possibleTypes = null;
/* 1513 */     if (baseType.getSimpleVariety() == 2) {
/* 1514 */       possibleTypes = new HashSet(Arrays.asList((Object[])baseType.getUnionConstituentTypes()));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1519 */     while (!baseType.equals(currentType) && possibleTypes != null && !possibleTypes.contains(currentType)) {
/* 1520 */       if (currentType.getDerivationType() == 1) {
/* 1521 */         currentType = currentType.getBaseType(); continue;
/*      */       } 
/* 1523 */       allDerivationsAreRestrictions = false;
/* 1524 */       errors.add(XmlError.forObject("rcase-NameAndTypeOK.7b", new Object[] { printType(derivedType), printType(baseType), printType(currentType) }, context));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1529 */     return allDerivationsAreRestrictions;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean checkIdentityConstraints(SchemaLocalElement baseElement, SchemaLocalElement derivedElement, Collection errors, XmlObject context) {
/* 1534 */     boolean identityConstraintsOK = true;
/*      */     
/* 1536 */     SchemaIdentityConstraint[] baseConstraints = baseElement.getIdentityConstraints();
/* 1537 */     SchemaIdentityConstraint[] derivedConstraints = derivedElement.getIdentityConstraints();
/*      */     
/* 1539 */     for (int i = 0; i < derivedConstraints.length; i++) {
/* 1540 */       SchemaIdentityConstraint derivedConstraint = derivedConstraints[i];
/* 1541 */       if (checkForIdentityConstraintExistence(baseConstraints, derivedConstraint)) {
/* 1542 */         identityConstraintsOK = false;
/* 1543 */         errors.add(XmlError.forObject("rcase-NameAndTypeOK.5", new Object[] { printParticle((SchemaParticle)derivedElement), printParticle((SchemaParticle)baseElement) }, context));
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 1549 */     return identityConstraintsOK;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean checkForIdentityConstraintExistence(SchemaIdentityConstraint[] baseConstraints, SchemaIdentityConstraint derivedConstraint) {
/* 1554 */     boolean identityConstraintExists = false;
/* 1555 */     for (int i = 0; i < baseConstraints.length; i++) {
/* 1556 */       SchemaIdentityConstraint baseConstraint = baseConstraints[i];
/* 1557 */       if (baseConstraint.getName().equals(derivedConstraint.getName())) {
/* 1558 */         identityConstraintExists = true;
/*      */         break;
/*      */       } 
/*      */     } 
/* 1562 */     return identityConstraintExists;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean checkFixed(SchemaLocalElement baseModel, SchemaLocalElement derivedModel, Collection errors, XmlObject context) {
/* 1569 */     boolean checkFixed = false;
/* 1570 */     if (baseModel.isFixed()) {
/* 1571 */       if (baseModel.getDefaultText().equals(derivedModel.getDefaultText())) {
/*      */         
/* 1573 */         checkFixed = true;
/*      */       } else {
/*      */         
/* 1576 */         errors.add(XmlError.forObject("rcase-NameAndTypeOK.4", new Object[] { printParticle((SchemaParticle)derivedModel), derivedModel.getDefaultText(), printParticle((SchemaParticle)baseModel), baseModel.getDefaultText() }, context));
/*      */ 
/*      */ 
/*      */         
/* 1580 */         checkFixed = false;
/*      */       } 
/*      */     } else {
/*      */       
/* 1584 */       checkFixed = true;
/*      */     } 
/* 1586 */     return checkFixed;
/*      */   }
/*      */   
/*      */   private static boolean occurrenceRangeOK(SchemaParticle baseParticle, SchemaParticle derivedParticle, Collection errors, XmlObject context) {
/* 1590 */     boolean occurrenceRangeOK = false;
/*      */ 
/*      */     
/* 1593 */     if (derivedParticle.getMinOccurs().compareTo(baseParticle.getMinOccurs()) >= 0) {
/*      */ 
/*      */       
/* 1596 */       if (baseParticle.getMaxOccurs() == null) {
/* 1597 */         occurrenceRangeOK = true;
/*      */       
/*      */       }
/* 1600 */       else if (derivedParticle.getMaxOccurs() != null && baseParticle.getMaxOccurs() != null && derivedParticle.getMaxOccurs().compareTo(baseParticle.getMaxOccurs()) <= 0) {
/*      */         
/* 1602 */         occurrenceRangeOK = true;
/*      */       } else {
/* 1604 */         occurrenceRangeOK = false;
/* 1605 */         errors.add(XmlError.forObject("range-ok.2", new Object[] { printParticle(derivedParticle), printMaxOccurs(derivedParticle.getMaxOccurs()), printParticle(baseParticle), printMaxOccurs(baseParticle.getMaxOccurs()) }, context));
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1612 */       occurrenceRangeOK = false;
/* 1613 */       errors.add(XmlError.forObject("range-ok.1", new Object[] { printParticle(derivedParticle), derivedParticle.getMinOccurs().toString(), printParticle(baseParticle), baseParticle.getMinOccurs().toString() }, context));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1618 */     return occurrenceRangeOK;
/*      */   }
/*      */ 
/*      */   
/*      */   private static String printParticles(List parts) {
/* 1623 */     return printParticles((SchemaParticle[])parts.toArray((Object[])new SchemaParticle[parts.size()]));
/*      */   }
/*      */ 
/*      */   
/*      */   private static String printParticles(SchemaParticle[] parts) {
/* 1628 */     return printParticles(parts, 0, parts.length);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String printParticles(SchemaParticle[] parts, int start) {
/* 1633 */     return printParticles(parts, start, parts.length);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String printParticles(SchemaParticle[] parts, int start, int end) {
/* 1638 */     StringBuffer buf = new StringBuffer(parts.length * 30);
/* 1639 */     for (int i = start; i < end; ) {
/*      */       
/* 1641 */       buf.append(printParticle(parts[i]));
/* 1642 */       if (++i != end)
/* 1643 */         buf.append(", "); 
/*      */     } 
/* 1645 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private static String printParticle(SchemaParticle part) {
/* 1650 */     switch (part.getParticleType()) {
/*      */       case 1:
/* 1652 */         return "<all>";
/*      */       case 2:
/* 1654 */         return "<choice>";
/*      */       case 4:
/* 1656 */         return "<element name=\"" + QNameHelper.pretty(part.getName()) + "\">";
/*      */       case 3:
/* 1658 */         return "<sequence>";
/*      */       case 5:
/* 1660 */         return "<any>";
/*      */     } 
/* 1662 */     return "??";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String printMaxOccurs(BigInteger bi) {
/* 1668 */     if (bi == null)
/* 1669 */       return "unbounded"; 
/* 1670 */     return bi.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private static String printType(SchemaType type) {
/* 1675 */     if (type.getName() != null)
/* 1676 */       return QNameHelper.pretty(type.getName()); 
/* 1677 */     return type.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private static void checkSubstitutionGroups(SchemaGlobalElement[] elts) {
/* 1682 */     StscState state = StscState.get();
/*      */     
/* 1684 */     for (int i = 0; i < elts.length; i++) {
/*      */       
/* 1686 */       SchemaGlobalElement elt = elts[i];
/* 1687 */       SchemaGlobalElement head = elt.substitutionGroup();
/*      */       
/* 1689 */       if (head != null) {
/*      */         
/* 1691 */         SchemaType headType = head.getType();
/* 1692 */         SchemaType tailType = elt.getType();
/* 1693 */         XmlObject parseTree = ((SchemaGlobalElementImpl)elt)._parseObject;
/*      */         
/* 1695 */         if (!headType.isAssignableFrom(tailType)) {
/*      */           
/* 1697 */           state.error("e-props-correct.4", new Object[] { QNameHelper.pretty(elt.getName()), QNameHelper.pretty(head.getName()) }, parseTree);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1702 */         else if (head.finalExtension() && head.finalRestriction()) {
/*      */           
/* 1704 */           state.error("e-props-correct.4a", new Object[] { QNameHelper.pretty(elt.getName()), QNameHelper.pretty(head.getName()), "#all" }, parseTree);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1709 */         else if (!headType.equals(tailType)) {
/*      */           
/* 1711 */           if (head.finalExtension() && tailType.getDerivationType() == 2) {
/*      */ 
/*      */             
/* 1714 */             state.error("e-props-correct.4a", new Object[] { QNameHelper.pretty(elt.getName()), QNameHelper.pretty(head.getName()), "extension" }, parseTree);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 1719 */           else if (head.finalRestriction() && tailType.getDerivationType() == 1) {
/*      */ 
/*      */             
/* 1722 */             state.error("e-props-correct.4a", new Object[] { QNameHelper.pretty(elt.getName()), QNameHelper.pretty(head.getName()), "restriction" }, parseTree);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\schema\StscChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */