/*    */ package org.apache.xmlbeans.impl.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.LineNumberReader;
/*    */ import java.io.Reader;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Diff
/*    */ {
/*    */   public static void readersAsText(Reader r1, String name1, Reader r2, String name2, List diffs) throws IOException {
/* 32 */     LineNumberReader reader1 = new LineNumberReader(r1);
/* 33 */     LineNumberReader reader2 = new LineNumberReader(r2);
/* 34 */     String line1 = reader1.readLine();
/* 35 */     String line2 = reader2.readLine();
/* 36 */     while (line1 != null && line2 != null) {
/*    */       
/* 38 */       if (!line1.equals(line2)) {
/*    */         
/* 40 */         diffs.add("File \"" + name1 + "\" and file \"" + name2 + "\" differ at line " + reader1.getLineNumber() + ":" + "\n" + line1 + "\n========\n" + line2);
/*    */         
/*    */         break;
/*    */       } 
/*    */       
/* 45 */       line1 = reader1.readLine();
/* 46 */       line2 = reader2.readLine();
/*    */     } 
/* 48 */     if (line1 == null && line2 != null) {
/* 49 */       diffs.add("File \"" + name2 + "\" has extra lines at line " + reader2.getLineNumber() + ":\n" + line2);
/*    */     }
/* 51 */     if (line1 != null && line2 == null)
/* 52 */       diffs.add("File \"" + name1 + "\" has extra lines at line " + reader1.getLineNumber() + ":\n" + line1); 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\imp\\util\Diff.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */