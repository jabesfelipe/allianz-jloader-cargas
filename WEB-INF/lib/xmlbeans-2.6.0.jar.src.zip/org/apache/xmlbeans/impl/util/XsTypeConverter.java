/*     */ package org.apache.xmlbeans.impl.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URI;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.GDate;
/*     */ import org.apache.xmlbeans.GDateBuilder;
/*     */ import org.apache.xmlbeans.GDateSpecification;
/*     */ import org.apache.xmlbeans.XmlCalendar;
/*     */ import org.apache.xmlbeans.XmlError;
/*     */ import org.apache.xmlbeans.impl.common.InvalidLexicalValueException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XsTypeConverter
/*     */ {
/*     */   private static final String POS_INF_LEX = "INF";
/*     */   private static final String NEG_INF_LEX = "-INF";
/*     */   private static final String NAN_LEX = "NaN";
/*     */   private static final char NAMESPACE_SEP = ':';
/*     */   private static final String EMPTY_PREFIX = "";
/*  43 */   private static final BigDecimal DECIMAL__ZERO = new BigDecimal(0.0D);
/*     */ 
/*     */   
/*  46 */   private static final String[] URI_CHARS_TO_BE_REPLACED = new String[] { " ", "{", "}", "|", "\\", "^", "[", "]", "`" };
/*  47 */   private static final String[] URI_CHARS_REPLACED_WITH = new String[] { "%20", "%7b", "%7d", "%7c", "%5c", "%5e", "%5b", "%5d", "%60" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float lexFloat(CharSequence cs) throws NumberFormatException {
/*  53 */     String v = cs.toString();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  58 */       if (cs.length() > 0) {
/*  59 */         char ch = cs.charAt(cs.length() - 1);
/*  60 */         if ((ch == 'f' || ch == 'F') && 
/*  61 */           cs.charAt(cs.length() - 2) != 'N') {
/*  62 */           throw new NumberFormatException("Invalid char '" + ch + "' in float.");
/*     */         }
/*     */       } 
/*  65 */       return Float.parseFloat(v);
/*     */     }
/*  67 */     catch (NumberFormatException e) {
/*  68 */       if (v.equals("INF")) return Float.POSITIVE_INFINITY; 
/*  69 */       if (v.equals("-INF")) return Float.NEGATIVE_INFINITY; 
/*  70 */       if (v.equals("NaN")) return Float.NaN;
/*     */       
/*  72 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static float lexFloat(CharSequence cs, Collection errors) {
/*     */     try {
/*  79 */       return lexFloat(cs);
/*     */     }
/*  81 */     catch (NumberFormatException e) {
/*  82 */       String msg = "invalid float: " + cs;
/*  83 */       errors.add(XmlError.forMessage(msg));
/*     */       
/*  85 */       return Float.NaN;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printFloat(float value) {
/*  91 */     if (value == Float.POSITIVE_INFINITY)
/*  92 */       return "INF"; 
/*  93 */     if (value == Float.NEGATIVE_INFINITY)
/*  94 */       return "-INF"; 
/*  95 */     if (Float.isNaN(value)) {
/*  96 */       return "NaN";
/*     */     }
/*  98 */     return Float.toString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double lexDouble(CharSequence cs) throws NumberFormatException {
/* 106 */     String v = cs.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 112 */       if (cs.length() > 0) {
/* 113 */         char ch = cs.charAt(cs.length() - 1);
/* 114 */         if (ch == 'd' || ch == 'D')
/* 115 */           throw new NumberFormatException("Invalid char '" + ch + "' in double."); 
/*     */       } 
/* 117 */       return Double.parseDouble(v);
/*     */     }
/* 119 */     catch (NumberFormatException e) {
/* 120 */       if (v.equals("INF")) return Double.POSITIVE_INFINITY; 
/* 121 */       if (v.equals("-INF")) return Double.NEGATIVE_INFINITY; 
/* 122 */       if (v.equals("NaN")) return Double.NaN;
/*     */       
/* 124 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static double lexDouble(CharSequence cs, Collection errors) {
/*     */     try {
/* 131 */       return lexDouble(cs);
/*     */     }
/* 133 */     catch (NumberFormatException e) {
/* 134 */       String msg = "invalid double: " + cs;
/* 135 */       errors.add(XmlError.forMessage(msg));
/*     */       
/* 137 */       return Double.NaN;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printDouble(double value) {
/* 143 */     if (value == Double.POSITIVE_INFINITY)
/* 144 */       return "INF"; 
/* 145 */     if (value == Double.NEGATIVE_INFINITY)
/* 146 */       return "-INF"; 
/* 147 */     if (Double.isNaN(value)) {
/* 148 */       return "NaN";
/*     */     }
/* 150 */     return Double.toString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal lexDecimal(CharSequence cs) throws NumberFormatException {
/* 158 */     String v = cs.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     return new BigDecimal(trimTrailingZeros(v));
/*     */   }
/*     */ 
/*     */   
/*     */   public static BigDecimal lexDecimal(CharSequence cs, Collection errors) {
/*     */     try {
/* 172 */       return lexDecimal(cs);
/*     */     }
/* 174 */     catch (NumberFormatException e) {
/* 175 */       String msg = "invalid long: " + cs;
/* 176 */       errors.add(XmlError.forMessage(msg));
/* 177 */       return DECIMAL__ZERO;
/*     */     } 
/*     */   }
/*     */   
/* 181 */   private static final char[] CH_ZEROS = new char[] { '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0' };
/*     */ 
/*     */   
/*     */   static final boolean $assertionsDisabled;
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printDecimal(BigDecimal value) {
/* 189 */     String intStr = value.unscaledValue().toString();
/* 190 */     int scale = value.scale();
/* 191 */     if (scale == 0 || (value.longValue() == 0L && scale < 0)) {
/* 192 */       return intStr;
/*     */     }
/* 194 */     int begin = (value.signum() < 0) ? 1 : 0;
/* 195 */     int delta = scale;
/*     */     
/* 197 */     StringBuffer result = new StringBuffer(intStr.length() + 1 + Math.abs(scale));
/*     */     
/* 199 */     if (begin == 1)
/*     */     {
/*     */       
/* 202 */       result.append('-');
/*     */     }
/* 204 */     if (scale > 0) {
/*     */       
/* 206 */       delta -= intStr.length() - begin;
/* 207 */       if (delta >= 0)
/*     */       {
/* 209 */         result.append("0.");
/*     */         
/* 211 */         for (; delta > CH_ZEROS.length; delta -= CH_ZEROS.length)
/* 212 */           result.append(CH_ZEROS); 
/* 213 */         result.append(CH_ZEROS, 0, delta);
/* 214 */         result.append(intStr.substring(begin));
/*     */       }
/*     */       else
/*     */       {
/* 218 */         delta = begin - delta;
/* 219 */         result.append(intStr.substring(begin, delta));
/* 220 */         result.append('.');
/* 221 */         result.append(intStr.substring(delta));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 226 */       result.append(intStr.substring(begin));
/*     */       
/* 228 */       for (; delta < -CH_ZEROS.length; delta += CH_ZEROS.length)
/* 229 */         result.append(CH_ZEROS); 
/* 230 */       result.append(CH_ZEROS, 0, -delta);
/*     */     } 
/* 232 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger lexInteger(CharSequence cs) throws NumberFormatException {
/* 239 */     if (cs.length() > 1 && 
/* 240 */       cs.charAt(0) == '+' && cs.charAt(1) == '-') {
/* 241 */       throw new NumberFormatException("Illegal char sequence '+-'");
/*     */     }
/* 243 */     String v = cs.toString();
/*     */ 
/*     */ 
/*     */     
/* 247 */     return new BigInteger(trimInitialPlus(v));
/*     */   }
/*     */ 
/*     */   
/*     */   public static BigInteger lexInteger(CharSequence cs, Collection errors) {
/*     */     try {
/* 253 */       return lexInteger(cs);
/*     */     }
/* 255 */     catch (NumberFormatException e) {
/* 256 */       String msg = "invalid long: " + cs;
/* 257 */       errors.add(XmlError.forMessage(msg));
/* 258 */       return BigInteger.ZERO;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printInteger(BigInteger value) {
/* 264 */     return value.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long lexLong(CharSequence cs) throws NumberFormatException {
/* 271 */     String v = cs.toString();
/* 272 */     return Long.parseLong(trimInitialPlus(v));
/*     */   }
/*     */ 
/*     */   
/*     */   public static long lexLong(CharSequence cs, Collection errors) {
/*     */     try {
/* 278 */       return lexLong(cs);
/*     */     }
/* 280 */     catch (NumberFormatException e) {
/* 281 */       String msg = "invalid long: " + cs;
/* 282 */       errors.add(XmlError.forMessage(msg));
/* 283 */       return 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printLong(long value) {
/* 289 */     return Long.toString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static short lexShort(CharSequence cs) throws NumberFormatException {
/* 297 */     return parseShort(cs);
/*     */   }
/*     */ 
/*     */   
/*     */   public static short lexShort(CharSequence cs, Collection errors) {
/*     */     try {
/* 303 */       return lexShort(cs);
/*     */     }
/* 305 */     catch (NumberFormatException e) {
/* 306 */       String msg = "invalid short: " + cs;
/* 307 */       errors.add(XmlError.forMessage(msg));
/* 308 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printShort(short value) {
/* 314 */     return Short.toString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int lexInt(CharSequence cs) throws NumberFormatException {
/* 322 */     return parseInt(cs);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int lexInt(CharSequence cs, Collection errors) {
/*     */     try {
/* 328 */       return lexInt(cs);
/*     */     }
/* 330 */     catch (NumberFormatException e) {
/* 331 */       String msg = "invalid int:" + cs;
/* 332 */       errors.add(XmlError.forMessage(msg));
/* 333 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printInt(int value) {
/* 339 */     return Integer.toString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte lexByte(CharSequence cs) throws NumberFormatException {
/* 347 */     return parseByte(cs);
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte lexByte(CharSequence cs, Collection errors) {
/*     */     try {
/* 353 */       return lexByte(cs);
/*     */     }
/* 355 */     catch (NumberFormatException e) {
/* 356 */       String msg = "invalid byte: " + cs;
/* 357 */       errors.add(XmlError.forMessage(msg));
/* 358 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printByte(byte value) {
/* 364 */     return Byte.toString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean lexBoolean(CharSequence v) {
/*     */     char c;
/* 371 */     switch (v.length()) {
/*     */       case 1:
/* 373 */         c = v.charAt(0);
/* 374 */         if ('0' == c) return false; 
/* 375 */         if ('1' == c) return true; 
/*     */         break;
/*     */       case 4:
/* 378 */         if ('t' == v.charAt(0) && 'r' == v.charAt(1) && 'u' == v.charAt(2) && 'e' == v.charAt(3))
/*     */         {
/*     */ 
/*     */           
/* 382 */           return true;
/*     */         }
/*     */         break;
/*     */       case 5:
/* 386 */         if ('f' == v.charAt(0) && 'a' == v.charAt(1) && 'l' == v.charAt(2) && 's' == v.charAt(3) && 'e' == v.charAt(4))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 391 */           return false;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 397 */     String msg = "invalid boolean: " + v;
/* 398 */     throw new InvalidLexicalValueException(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean lexBoolean(CharSequence value, Collection errors) {
/*     */     try {
/* 404 */       return lexBoolean(value);
/*     */     }
/* 406 */     catch (InvalidLexicalValueException e) {
/* 407 */       errors.add(XmlError.forMessage(e.getMessage()));
/* 408 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printBoolean(boolean value) {
/* 414 */     return value ? "true" : "false";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String lexString(CharSequence cs, Collection errors) {
/* 421 */     String v = cs.toString();
/*     */     
/* 423 */     return v;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String lexString(CharSequence lexical_value) {
/* 429 */     return lexical_value.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printString(String value) {
/* 434 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName lexQName(CharSequence charSeq, NamespaceContext nscontext) {
/*     */     String prefix, localname;
/* 444 */     boolean hasFirstCollon = false; int firstcolon;
/* 445 */     for (firstcolon = 0; firstcolon < charSeq.length(); firstcolon++) {
/* 446 */       if (charSeq.charAt(firstcolon) == ':') {
/* 447 */         hasFirstCollon = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 451 */     if (hasFirstCollon) {
/* 452 */       prefix = charSeq.subSequence(0, firstcolon).toString();
/* 453 */       localname = charSeq.subSequence(firstcolon + 1, charSeq.length()).toString();
/* 454 */       if (firstcolon == 0) {
/* 455 */         throw new InvalidLexicalValueException("invalid xsd:QName '" + charSeq.toString() + "'");
/*     */       }
/*     */     } else {
/* 458 */       prefix = "";
/* 459 */       localname = charSeq.toString();
/*     */     } 
/*     */     
/* 462 */     String uri = nscontext.getNamespaceURI(prefix);
/*     */     
/* 464 */     if (uri == null) {
/* 465 */       if (prefix != null && prefix.length() > 0) {
/* 466 */         throw new InvalidLexicalValueException("Can't resolve prefix: " + prefix);
/*     */       }
/* 468 */       uri = "";
/*     */     } 
/*     */     
/* 471 */     return new QName(uri, localname);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName lexQName(String xsd_qname, Collection errors, NamespaceContext nscontext) {
/*     */     try {
/* 478 */       return lexQName(xsd_qname, nscontext);
/*     */     }
/* 480 */     catch (InvalidLexicalValueException e) {
/* 481 */       errors.add(XmlError.forMessage(e.getMessage()));
/* 482 */       int idx = xsd_qname.indexOf(':');
/* 483 */       return new QName(null, xsd_qname.substring(idx));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printQName(QName qname, NamespaceContext nsContext, Collection errors) {
/* 490 */     String prefix, uri = qname.getNamespaceURI();
/* 491 */     assert uri != null;
/*     */     
/* 493 */     if (uri.length() > 0) {
/* 494 */       prefix = nsContext.getPrefix(uri);
/* 495 */       if (prefix == null) {
/* 496 */         String msg = "NamespaceContext does not provide prefix for namespaceURI " + uri;
/*     */         
/* 498 */         errors.add(XmlError.forMessage(msg));
/*     */       } 
/*     */     } else {
/* 501 */       prefix = null;
/*     */     } 
/* 503 */     return getQNameString(uri, qname.getLocalPart(), prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getQNameString(String uri, String localpart, String prefix) {
/* 511 */     if (prefix != null && uri != null && uri.length() > 0 && prefix.length() > 0)
/*     */     {
/*     */ 
/*     */       
/* 515 */       return prefix + ':' + localpart;
/*     */     }
/* 517 */     return localpart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GDate lexGDate(CharSequence charSeq) {
/* 524 */     return new GDate(charSeq);
/*     */   }
/*     */ 
/*     */   
/*     */   public static GDate lexGDate(String xsd_gdate, Collection errors) {
/*     */     try {
/* 530 */       return lexGDate(xsd_gdate);
/*     */     }
/* 532 */     catch (IllegalArgumentException e) {
/* 533 */       errors.add(XmlError.forMessage(e.getMessage()));
/* 534 */       return (new GDateBuilder()).toGDate();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printGDate(GDate gdate, Collection errors) {
/* 540 */     return gdate.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XmlCalendar lexDateTime(CharSequence v) {
/* 547 */     GDateSpecification value = getGDateValue(v, 14);
/* 548 */     return value.getCalendar();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printDateTime(Calendar c) {
/* 554 */     return printDateTime(c, 14);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printTime(Calendar c) {
/* 559 */     return printDateTime(c, 15);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printDate(Calendar c) {
/* 564 */     return printDateTime(c, 16);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printDate(Date d) {
/* 569 */     GDateSpecification value = getGDateValue(d, 16);
/* 570 */     return value.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printDateTime(Calendar c, int type_code) {
/* 575 */     GDateSpecification value = getGDateValue(c, type_code);
/* 576 */     return value.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String printDateTime(Date c) {
/* 581 */     GDateSpecification value = getGDateValue(c, 14);
/* 582 */     return value.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence printHexBinary(byte[] val) {
/* 589 */     return HexBin.bytesToString(val);
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] lexHexBinary(CharSequence lexical_value) {
/* 594 */     byte[] buf = HexBin.decode(lexical_value.toString().getBytes());
/* 595 */     if (buf != null) {
/* 596 */       return buf;
/*     */     }
/* 598 */     throw new InvalidLexicalValueException("invalid hexBinary value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence printBase64Binary(byte[] val) {
/* 605 */     byte[] bytes = Base64.encode(val);
/* 606 */     return new String(bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] lexBase64Binary(CharSequence lexical_value) {
/* 611 */     byte[] buf = Base64.decode(lexical_value.toString().getBytes());
/* 612 */     if (buf != null) {
/* 613 */       return buf;
/*     */     }
/* 615 */     throw new InvalidLexicalValueException("invalid base64Binary value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GDateSpecification getGDateValue(Date d, int builtin_type_code) {
/* 623 */     GDateBuilder gDateBuilder = new GDateBuilder(d);
/* 624 */     gDateBuilder.setBuiltinTypeCode(builtin_type_code);
/* 625 */     GDate value = gDateBuilder.toGDate();
/* 626 */     return (GDateSpecification)value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GDateSpecification getGDateValue(Calendar c, int builtin_type_code) {
/* 633 */     GDateBuilder gDateBuilder = new GDateBuilder(c);
/* 634 */     gDateBuilder.setBuiltinTypeCode(builtin_type_code);
/* 635 */     GDate value = gDateBuilder.toGDate();
/* 636 */     return (GDateSpecification)value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static GDateSpecification getGDateValue(CharSequence v, int builtin_type_code) {
/* 642 */     GDateBuilder gDateBuilder = new GDateBuilder(v);
/* 643 */     gDateBuilder.setBuiltinTypeCode(builtin_type_code);
/* 644 */     GDate value = gDateBuilder.toGDate();
/* 645 */     return (GDateSpecification)value;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String trimInitialPlus(String xml) {
/* 650 */     if (xml.length() > 0 && xml.charAt(0) == '+') {
/* 651 */       return xml.substring(1);
/*     */     }
/* 653 */     return xml;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String trimTrailingZeros(String xsd_decimal) {
/* 659 */     int last_char_idx = xsd_decimal.length() - 1;
/* 660 */     if (xsd_decimal.charAt(last_char_idx) == '0') {
/*     */       
/* 662 */       int last_point = xsd_decimal.lastIndexOf('.');
/* 663 */       if (last_point >= 0) {
/*     */         
/* 665 */         for (int idx = last_char_idx; idx > last_point; idx--) {
/* 666 */           if (xsd_decimal.charAt(idx) != '0') {
/* 667 */             return xsd_decimal.substring(0, idx + 1);
/*     */           }
/*     */         } 
/*     */         
/* 671 */         return xsd_decimal.substring(0, last_point);
/*     */       } 
/*     */     } 
/* 674 */     return xsd_decimal;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int parseInt(CharSequence cs) {
/* 679 */     return parseIntXsdNumber(cs, -2147483648, 2147483647);
/*     */   }
/*     */ 
/*     */   
/*     */   private static short parseShort(CharSequence cs) {
/* 684 */     return (short)parseIntXsdNumber(cs, -32768, 32767);
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte parseByte(CharSequence cs) {
/* 689 */     return (byte)parseIntXsdNumber(cs, -128, 127);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseIntXsdNumber(CharSequence ch, int min_value, int max_value) {
/* 695 */     int limit, limit2, length = ch.length();
/* 696 */     if (length < 1) {
/* 697 */       throw new NumberFormatException("For input string: \"" + ch.toString() + "\"");
/*     */     }
/* 699 */     int sign = 1;
/* 700 */     int result = 0;
/* 701 */     int start = 0;
/*     */ 
/*     */ 
/*     */     
/* 705 */     char c = ch.charAt(0);
/* 706 */     if (c == '-') {
/* 707 */       start++;
/* 708 */       limit = min_value / 10;
/* 709 */       limit2 = -(min_value % 10);
/* 710 */     } else if (c == '+') {
/* 711 */       start++;
/* 712 */       sign = -1;
/* 713 */       limit = -(max_value / 10);
/* 714 */       limit2 = max_value % 10;
/*     */     } else {
/* 716 */       sign = -1;
/* 717 */       limit = -(max_value / 10);
/* 718 */       limit2 = max_value % 10;
/*     */     } 
/*     */     
/* 721 */     for (int i = 0; i < length - start; i++) {
/* 722 */       c = ch.charAt(i + start);
/* 723 */       int v = Character.digit(c, 10);
/*     */       
/* 725 */       if (v < 0) {
/* 726 */         throw new NumberFormatException("For input string: \"" + ch.toString() + "\"");
/*     */       }
/* 728 */       if (result < limit || (result == limit && v > limit2)) {
/* 729 */         throw new NumberFormatException("For input string: \"" + ch.toString() + "\"");
/*     */       }
/* 731 */       result = result * 10 - v;
/*     */     } 
/*     */     
/* 734 */     return sign * result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence printAnyURI(CharSequence val) {
/* 740 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSequence lexAnyURI(CharSequence lexical_value) {
/* 768 */     StringBuffer s = new StringBuffer(lexical_value.toString());
/* 769 */     for (int ic = 0; ic < URI_CHARS_TO_BE_REPLACED.length; ic++) {
/*     */       
/* 771 */       int i = 0;
/* 772 */       while ((i = s.indexOf(URI_CHARS_TO_BE_REPLACED[ic], i)) >= 0) {
/*     */         
/* 774 */         s.replace(i, i + 1, URI_CHARS_REPLACED_WITH[ic]);
/* 775 */         i += 3;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 781 */       URI.create(s.toString());
/*     */     }
/* 783 */     catch (IllegalArgumentException e) {
/*     */       
/* 785 */       throw new InvalidLexicalValueException("invalid anyURI value: " + lexical_value, e);
/*     */     } 
/*     */     
/* 788 */     return lexical_value;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\imp\\util\XsTypeConverter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */