/*     */ package org.apache.xmlbeans.impl.util;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HexBin
/*     */ {
/*     */   private static final int BASELENGTH = 255;
/*     */   private static final int LOOKUPLENGTH = 16;
/*  29 */   private static byte[] hexNumberTable = new byte[255];
/*  30 */   private static byte[] lookUpHexAlphabet = new byte[16];
/*     */   
/*     */   static {
/*     */     int i;
/*  34 */     for (i = 0; i < 255; i++) {
/*  35 */       hexNumberTable[i] = -1;
/*     */     }
/*  37 */     for (i = 57; i >= 48; i--) {
/*  38 */       hexNumberTable[i] = (byte)(i - 48);
/*     */     }
/*  40 */     for (i = 70; i >= 65; i--) {
/*  41 */       hexNumberTable[i] = (byte)(i - 65 + 10);
/*     */     }
/*  43 */     for (i = 102; i >= 97; i--) {
/*  44 */       hexNumberTable[i] = (byte)(i - 97 + 10);
/*     */     }
/*     */     
/*  47 */     for (i = 0; i < 10; i++)
/*  48 */       lookUpHexAlphabet[i] = (byte)(48 + i); 
/*  49 */     for (i = 10; i <= 15; i++) {
/*  50 */       lookUpHexAlphabet[i] = (byte)(65 + i - 10);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isHex(byte octect) {
/*  60 */     return (hexNumberTable[octect] != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bytesToString(byte[] binaryData) {
/*  68 */     if (binaryData == null)
/*  69 */       return null; 
/*  70 */     return new String(encode(binaryData));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] stringToBytes(String hexEncoded) {
/*  78 */     return decode(hexEncoded.getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encode(byte[] binaryData) {
/*  88 */     if (binaryData == null)
/*  89 */       return null; 
/*  90 */     int lengthData = binaryData.length;
/*  91 */     int lengthEncode = lengthData * 2;
/*  92 */     byte[] encodedData = new byte[lengthEncode];
/*  93 */     for (int i = 0; i < lengthData; i++) {
/*  94 */       encodedData[i * 2] = lookUpHexAlphabet[binaryData[i] >> 4 & 0xF];
/*  95 */       encodedData[i * 2 + 1] = lookUpHexAlphabet[binaryData[i] & 0xF];
/*     */     } 
/*  97 */     return encodedData;
/*     */   }
/*     */   
/*     */   public static byte[] decode(byte[] binaryData) {
/* 101 */     if (binaryData == null)
/* 102 */       return null; 
/* 103 */     int lengthData = binaryData.length;
/* 104 */     if (lengthData % 2 != 0) {
/* 105 */       return null;
/*     */     }
/* 107 */     int lengthDecode = lengthData / 2;
/* 108 */     byte[] decodedData = new byte[lengthDecode];
/* 109 */     for (int i = 0; i < lengthDecode; i++) {
/* 110 */       if (!isHex(binaryData[i * 2]) || !isHex(binaryData[i * 2 + 1])) {
/* 111 */         return null;
/*     */       }
/* 113 */       decodedData[i] = (byte)(hexNumberTable[binaryData[i * 2]] << 4 | hexNumberTable[binaryData[i * 2 + 1]]);
/*     */     } 
/* 115 */     return decodedData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decode(String binaryData) {
/* 125 */     if (binaryData == null) {
/* 126 */       return null;
/*     */     }
/* 128 */     byte[] decoded = null;
/*     */     try {
/* 130 */       decoded = decode(binaryData.getBytes("utf-8"));
/*     */     }
/* 132 */     catch (UnsupportedEncodingException e) {}
/*     */     
/* 134 */     return (decoded == null) ? null : new String(decoded);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(String binaryData) {
/* 144 */     if (binaryData == null) {
/* 145 */       return null;
/*     */     }
/* 147 */     byte[] encoded = null;
/*     */     try {
/* 149 */       encoded = encode(binaryData.getBytes("utf-8"));
/*     */     }
/* 151 */     catch (UnsupportedEncodingException e) {}
/* 152 */     return (encoded == null) ? null : new String(encoded);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\imp\\util\HexBin.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */