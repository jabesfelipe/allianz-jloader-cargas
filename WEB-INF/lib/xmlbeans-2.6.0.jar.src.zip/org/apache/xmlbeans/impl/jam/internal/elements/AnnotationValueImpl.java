/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotationValue;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.JClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.QualifiedJClassRef;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationValueImpl
/*     */   implements JAnnotationValue
/*     */ {
/*  34 */   private Object mValue = null;
/*  35 */   private JClassRef mType = null;
/*     */ 
/*     */   
/*     */   private String mName;
/*     */ 
/*     */   
/*     */   private ElementContext mContext;
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationValueImpl(ElementContext ctx, String name, Object value, JClass type) {
/*  46 */     if (ctx == null) throw new IllegalArgumentException("null ctx"); 
/*  47 */     if (name == null) throw new IllegalArgumentException("null name"); 
/*  48 */     if (value == null) throw new IllegalArgumentException("null value"); 
/*  49 */     if (type == null) throw new IllegalArgumentException("null type"); 
/*  50 */     if (value.getClass().isArray()) {
/*  51 */       this.mValue = ensureArrayWrapped(value);
/*     */     } else {
/*  53 */       this.mValue = value;
/*     */     } 
/*  55 */     this.mContext = ctx;
/*  56 */     this.mName = name;
/*  57 */     this.mType = QualifiedJClassRef.create(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultValueUsed() {
/*  64 */     throw new IllegalStateException("NYI");
/*     */   }
/*     */   
/*     */   public String getName() {
/*  68 */     return this.mName;
/*     */   } public JClass getType() {
/*  70 */     return this.mType.getRefClass();
/*     */   }
/*     */   
/*     */   public JAnnotation asAnnotation() {
/*  74 */     if (this.mValue instanceof JAnnotation) {
/*  75 */       return (JAnnotation)this.mValue;
/*     */     }
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public JClass asClass() {
/*  82 */     if (this.mValue instanceof JClass) {
/*  83 */       return (JClass)this.mValue;
/*     */     }
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String asString() {
/*  90 */     if (this.mValue == null) return null; 
/*  91 */     return this.mValue.toString();
/*     */   }
/*     */   
/*     */   public int asInt() throws NumberFormatException {
/*  95 */     if (this.mValue == null) return 0; 
/*  96 */     if (this.mValue instanceof Number) return ((Number)this.mValue).intValue(); 
/*     */     try {
/*  98 */       return Integer.parseInt(this.mValue.toString().trim());
/*  99 */     } catch (NumberFormatException nfe) {
/* 100 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean asBoolean() throws IllegalArgumentException {
/* 105 */     if (this.mValue == null) return false; 
/* 106 */     return Boolean.valueOf(this.mValue.toString().trim()).booleanValue();
/*     */   }
/*     */   
/*     */   public long asLong() throws NumberFormatException {
/* 110 */     if (this.mValue == null) return 0L; 
/* 111 */     if (this.mValue instanceof Number) return ((Number)this.mValue).longValue(); 
/*     */     try {
/* 113 */       return Long.parseLong(this.mValue.toString().trim());
/* 114 */     } catch (NumberFormatException nfe) {
/* 115 */       return 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public short asShort() throws NumberFormatException {
/* 120 */     if (this.mValue == null) return 0; 
/* 121 */     if (this.mValue instanceof Number) return ((Number)this.mValue).shortValue(); 
/*     */     try {
/* 123 */       return Short.parseShort(this.mValue.toString().trim());
/* 124 */     } catch (NumberFormatException nfe) {
/* 125 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public double asDouble() throws NumberFormatException {
/* 130 */     if (this.mValue == null) return 0.0D; 
/* 131 */     if (this.mValue instanceof Number) return ((Number)this.mValue).doubleValue(); 
/*     */     try {
/* 133 */       return Double.parseDouble(this.mValue.toString().trim());
/* 134 */     } catch (NumberFormatException nfe) {
/* 135 */       return 0.0D;
/*     */     } 
/*     */   }
/*     */   
/*     */   public float asFloat() throws NumberFormatException {
/* 140 */     if (this.mValue == null) return 0.0F; 
/* 141 */     if (this.mValue instanceof Number) return ((Number)this.mValue).floatValue(); 
/*     */     try {
/* 143 */       return Float.parseFloat(this.mValue.toString().trim());
/* 144 */     } catch (NumberFormatException nfe) {
/* 145 */       return 0.0F;
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte asByte() throws NumberFormatException {
/* 150 */     if (this.mValue == null) return 0; 
/* 151 */     if (this.mValue instanceof Number) return ((Number)this.mValue).byteValue(); 
/*     */     try {
/* 153 */       return Byte.parseByte(this.mValue.toString().trim());
/* 154 */     } catch (NumberFormatException nfe) {
/* 155 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public char asChar() throws IllegalArgumentException {
/* 161 */     if (this.mValue == null) return Character.MIN_VALUE; 
/* 162 */     if (this.mValue instanceof Character) return ((Character)this.mValue).charValue(); 
/* 163 */     this.mValue = this.mValue.toString();
/* 164 */     return (((String)this.mValue).length() == 0) ? Character.MIN_VALUE : ((String)this.mValue).charAt(0);
/*     */   }
/*     */   
/*     */   public JClass[] asClassArray() {
/* 168 */     if (this.mValue instanceof JClass[]) {
/* 169 */       return (JClass[])this.mValue;
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public JAnnotation[] asAnnotationArray() {
/* 176 */     if (this.mValue instanceof JAnnotation[]) {
/* 177 */       return (JAnnotation[])this.mValue;
/*     */     }
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] asStringArray() {
/* 184 */     if (!this.mValue.getClass().isArray()) return null; 
/* 185 */     String[] out = new String[((Object[])this.mValue).length];
/* 186 */     for (int i = 0; i < out.length; i++) {
/* 187 */       if (((Object[])this.mValue)[i] == null) {
/* 188 */         this.mContext.getLogger().error("Null annotation value array element on " + getName());
/*     */         
/* 190 */         out[i] = "";
/*     */       } else {
/* 192 */         out[i] = ((Object[])this.mValue)[i].toString();
/*     */       } 
/*     */     } 
/* 195 */     return out;
/*     */   }
/*     */   
/*     */   public int[] asIntArray() throws NumberFormatException {
/* 199 */     if (!this.mValue.getClass().isArray()) return null; 
/* 200 */     int[] out = new int[((Object[])this.mValue).length];
/* 201 */     for (int i = 0; i < out.length; i++) {
/* 202 */       if (((Object[])this.mValue)[i] == null) {
/* 203 */         this.mContext.getLogger().error("Null annotation value array element " + i + " on " + getName());
/*     */         
/* 205 */         out[i] = 0;
/*     */       } else {
/* 207 */         out[i] = Integer.parseInt(((Object[])this.mValue)[i].toString());
/*     */       } 
/*     */     } 
/* 210 */     return out;
/*     */   }
/*     */   
/*     */   public boolean[] asBooleanArray() throws IllegalArgumentException {
/* 214 */     if (!this.mValue.getClass().isArray()) return null; 
/* 215 */     boolean[] out = new boolean[((Object[])this.mValue).length];
/* 216 */     for (int i = 0; i < out.length; i++) {
/* 217 */       if (((Object[])this.mValue)[i] == null) {
/* 218 */         this.mContext.getLogger().error("Null annotation value array element " + i + " on " + getName());
/*     */         
/* 220 */         out[i] = false;
/*     */       } else {
/* 222 */         out[i] = Boolean.valueOf(((Object[])this.mValue)[i].toString()).booleanValue();
/*     */       } 
/*     */     } 
/* 225 */     return out;
/*     */   }
/*     */   
/*     */   public short[] asShortArray() throws NumberFormatException {
/* 229 */     if (!this.mValue.getClass().isArray()) return null; 
/* 230 */     short[] out = new short[((Object[])this.mValue).length];
/* 231 */     for (int i = 0; i < out.length; i++) {
/* 232 */       if (((Object[])this.mValue)[i] == null) {
/* 233 */         this.mContext.getLogger().error("Null annotation value array element " + i + " on " + getName());
/*     */         
/* 235 */         out[i] = 0;
/*     */       } else {
/* 237 */         out[i] = Short.parseShort(((Object[])this.mValue)[i].toString());
/*     */       } 
/*     */     } 
/* 240 */     return out;
/*     */   }
/*     */   
/*     */   public long[] asLongArray() throws NumberFormatException {
/* 244 */     if (!this.mValue.getClass().isArray()) return null; 
/* 245 */     long[] out = new long[((Object[])this.mValue).length];
/* 246 */     for (int i = 0; i < out.length; i++) {
/* 247 */       if (((Object[])this.mValue)[i] == null) {
/* 248 */         this.mContext.getLogger().error("Null annotation value array element " + i + " on " + getName());
/*     */         
/* 250 */         out[i] = 0L;
/*     */       } else {
/* 252 */         out[i] = Long.parseLong(((Object[])this.mValue)[i].toString());
/*     */       } 
/*     */     } 
/* 255 */     return out;
/*     */   }
/*     */   
/*     */   public double[] asDoubleArray() throws NumberFormatException {
/* 259 */     if (!this.mValue.getClass().isArray()) return null; 
/* 260 */     double[] out = new double[((Object[])this.mValue).length];
/* 261 */     for (int i = 0; i < out.length; i++) {
/* 262 */       if (((Object[])this.mValue)[i] == null) {
/* 263 */         this.mContext.getLogger().error("Null annotation value array element " + i + " on " + getName());
/*     */         
/* 265 */         out[i] = 0.0D;
/*     */       } else {
/* 267 */         out[i] = Double.parseDouble(((Object[])this.mValue)[i].toString());
/*     */       } 
/*     */     } 
/* 270 */     return out;
/*     */   }
/*     */   
/*     */   public float[] asFloatArray() throws NumberFormatException {
/* 274 */     if (!this.mValue.getClass().isArray()) return null; 
/* 275 */     float[] out = new float[((Object[])this.mValue).length];
/* 276 */     for (int i = 0; i < out.length; i++) {
/* 277 */       if (((Object[])this.mValue)[i] == null) {
/* 278 */         this.mContext.getLogger().error("Null annotation value array element " + i + " on " + getName());
/*     */         
/* 280 */         out[i] = 0.0F;
/*     */       } else {
/* 282 */         out[i] = Float.parseFloat(((Object[])this.mValue)[i].toString());
/*     */       } 
/*     */     } 
/* 285 */     return out;
/*     */   }
/*     */   
/*     */   public byte[] asByteArray() throws NumberFormatException {
/* 289 */     if (!this.mValue.getClass().isArray()) return null; 
/* 290 */     byte[] out = new byte[((Object[])this.mValue).length];
/* 291 */     for (int i = 0; i < out.length; i++) {
/* 292 */       if (((Object[])this.mValue)[i] == null) {
/* 293 */         this.mContext.getLogger().error("Null annotation value array element " + i + " on " + getName());
/*     */         
/* 295 */         out[i] = 0;
/*     */       } else {
/* 297 */         out[i] = Byte.parseByte(((Object[])this.mValue)[i].toString());
/*     */       } 
/*     */     } 
/* 300 */     return out;
/*     */   }
/*     */   
/*     */   public char[] asCharArray() throws IllegalArgumentException {
/* 304 */     if (!this.mValue.getClass().isArray()) return null; 
/* 305 */     char[] out = new char[((Object[])this.mValue).length];
/* 306 */     for (int i = 0; i < out.length; i++) {
/* 307 */       if (((Object[])this.mValue)[i] == null) {
/* 308 */         this.mContext.getLogger().error("Null annotation value array element " + i + " on " + getName());
/*     */         
/* 310 */         out[i] = Character.MIN_VALUE;
/*     */       } else {
/*     */         
/* 313 */         out[i] = ((Object[])this.mValue)[i].toString().charAt(0);
/*     */       } 
/*     */     } 
/* 316 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Object[] ensureArrayWrapped(Object o) {
/* 324 */     if (o instanceof Object[]) return (Object[])o; 
/* 325 */     if (o instanceof int[]) {
/* 326 */       int dims = ((int[])o).length;
/* 327 */       Integer[] out = new Integer[dims];
/* 328 */       for (int i = 0; i < dims; ) { out[i] = new Integer(((int[])o)[i]); i++; }
/* 329 */        return (Object[])out;
/* 330 */     }  if (o instanceof boolean[]) {
/* 331 */       int dims = ((boolean[])o).length;
/* 332 */       Boolean[] out = new Boolean[dims];
/* 333 */       for (int i = 0; i < dims; ) { out[i] = Boolean.valueOf(((boolean[])o)[i]); i++; }
/* 334 */        return (Object[])out;
/* 335 */     }  if (o instanceof byte[]) {
/* 336 */       int dims = ((byte[])o).length;
/* 337 */       Byte[] out = new Byte[dims];
/* 338 */       for (int i = 0; i < dims; ) { out[i] = new Byte(((byte[])o)[i]); i++; }
/* 339 */        return (Object[])out;
/* 340 */     }  if (o instanceof char[]) {
/* 341 */       int dims = ((char[])o).length;
/* 342 */       Character[] out = new Character[dims];
/* 343 */       for (int i = 0; i < dims; ) { out[i] = new Character(((char[])o)[i]); i++; }
/* 344 */        return (Object[])out;
/* 345 */     }  if (o instanceof float[]) {
/* 346 */       int dims = ((float[])o).length;
/* 347 */       Float[] out = new Float[dims];
/* 348 */       for (int i = 0; i < dims; ) { out[i] = new Float(((float[])o)[i]); i++; }
/* 349 */        return (Object[])out;
/* 350 */     }  if (o instanceof double[]) {
/* 351 */       int dims = ((double[])o).length;
/* 352 */       Double[] out = new Double[dims];
/* 353 */       for (int i = 0; i < dims; ) { out[i] = new Double(((double[])o)[i]); i++; }
/* 354 */        return (Object[])out;
/* 355 */     }  if (o instanceof long[]) {
/* 356 */       int dims = ((long[])o).length;
/* 357 */       Long[] out = new Long[dims];
/* 358 */       for (int i = 0; i < dims; ) { out[i] = new Long(((long[])o)[i]); i++; }
/* 359 */        return (Object[])out;
/* 360 */     }  if (o instanceof short[]) {
/* 361 */       int dims = ((short[])o).length;
/* 362 */       Short[] out = new Short[dims];
/* 363 */       for (int i = 0; i < dims; ) { out[i] = new Short(((short[])o)[i]); i++; }
/* 364 */        return (Object[])out;
/*     */     } 
/* 366 */     throw new IllegalStateException("Unknown array type " + o.getClass());
/*     */   }
/*     */   
/*     */   public Object getValue() {
/* 370 */     return this.mValue;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\AnnotationValueImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */