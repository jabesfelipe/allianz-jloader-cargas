/*     */ package org.apache.xmlbeans.impl.jam.internal;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JPackage;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ArrayClassImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ClassImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.PackageImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.PrimitiveClassImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.UnresolvedClassImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.VoidClassImpl;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.TraversingMVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JamClassLoaderImpl
/*     */   implements JamClassLoader
/*     */ {
/*  48 */   private Map mName2Package = new HashMap();
/*  49 */   private Map mFd2ClassCache = new HashMap();
/*     */   private JamClassBuilder mBuilder;
/*  51 */   private MVisitor mInitializer = null;
/*     */   private ElementContext mContext;
/*  53 */   private Stack mInitializeStack = new Stack();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mAlreadyInitializing = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public JamClassLoaderImpl(ElementContext context, JamClassBuilder builder, MVisitor initializerOrNull) {
/*  62 */     if (builder == null) throw new IllegalArgumentException("null builder"); 
/*  63 */     if (context == null) throw new IllegalArgumentException("null builder"); 
/*  64 */     this.mBuilder = builder;
/*  65 */     this.mInitializer = (initializerOrNull == null) ? null : (MVisitor)new TraversingMVisitor(initializerOrNull);
/*     */     
/*  67 */     this.mContext = context;
/*  68 */     initCache();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final JClass loadClass(String fd) {
/*     */     UnresolvedClassImpl unresolvedClassImpl;
/*     */     String pkg, name;
/*  76 */     fd = fd.trim();
/*  77 */     JClass out = cacheGet(fd);
/*  78 */     if (out != null) return out; 
/*  79 */     if (fd.indexOf('[') != -1) {
/*  80 */       String normalFd = ArrayClassImpl.normalizeArrayName(fd);
/*  81 */       out = cacheGet(normalFd);
/*  82 */       if (out == null) {
/*  83 */         out = ArrayClassImpl.createClassForFD(normalFd, this);
/*  84 */         cachePut(out, normalFd);
/*     */       } 
/*  86 */       cachePut(out, fd);
/*  87 */       return out;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     int dollar = fd.indexOf('$');
/*  94 */     if (dollar != -1) {
/*  95 */       String outerName = fd.substring(0, dollar);
/*  96 */       ((ClassImpl)loadClass(outerName)).ensureLoaded();
/*  97 */       out = cacheGet(fd);
/*     */       
/*  99 */       int i = fd.lastIndexOf('.');
/* 100 */       if (out == null) {
/*     */         String str1, str2;
/*     */         
/* 103 */         if (i == -1) {
/* 104 */           str1 = "";
/* 105 */           str2 = fd;
/*     */         } else {
/* 107 */           str1 = fd.substring(0, i);
/* 108 */           str2 = fd.substring(i + 1);
/*     */         } 
/* 110 */         unresolvedClassImpl = new UnresolvedClassImpl(str1, str2, this.mContext);
/* 111 */         this.mContext.warning("failed to resolve class " + fd);
/* 112 */         cachePut((JClass)unresolvedClassImpl);
/*     */       } 
/* 114 */       return (JClass)unresolvedClassImpl;
/*     */     } 
/*     */ 
/*     */     
/* 118 */     int dot = fd.lastIndexOf('.');
/*     */ 
/*     */     
/* 121 */     if (dot == -1) {
/* 122 */       pkg = "";
/* 123 */       name = fd;
/*     */     } else {
/* 125 */       pkg = fd.substring(0, dot);
/* 126 */       name = fd.substring(dot + 1);
/*     */     } 
/* 128 */     MClass mClass = this.mBuilder.build(pkg, name);
/* 129 */     if (mClass == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       unresolvedClassImpl = new UnresolvedClassImpl(pkg, name, this.mContext);
/* 135 */       this.mContext.warning("failed to resolve class " + fd);
/* 136 */       cachePut((JClass)unresolvedClassImpl);
/* 137 */       return (JClass)unresolvedClassImpl;
/*     */     } 
/* 139 */     cachePut((JClass)unresolvedClassImpl);
/* 140 */     return (JClass)unresolvedClassImpl;
/*     */   }
/*     */   public JPackage getPackage(String named) {
/*     */     PackageImpl packageImpl;
/* 144 */     JPackage out = (JPackage)this.mName2Package.get(named);
/* 145 */     if (out == null) {
/* 146 */       packageImpl = new PackageImpl(this.mContext, named);
/* 147 */       this.mName2Package.put(named, packageImpl);
/*     */     } 
/* 149 */     return (JPackage)packageImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initCache() {
/* 159 */     PrimitiveClassImpl.mapNameToPrimitive(this.mContext, this.mFd2ClassCache);
/* 160 */     this.mFd2ClassCache.put("void", new VoidClassImpl(this.mContext));
/*     */   }
/*     */   
/*     */   private void cachePut(JClass clazz) {
/* 164 */     this.mFd2ClassCache.put(clazz.getFieldDescriptor().trim(), new WeakReference(clazz));
/*     */   }
/*     */ 
/*     */   
/*     */   private void cachePut(JClass clazz, String cachedName) {
/* 169 */     this.mFd2ClassCache.put(cachedName, new WeakReference(clazz));
/*     */   }
/*     */   
/*     */   private JClass cacheGet(String fd) {
/* 173 */     Object out = this.mFd2ClassCache.get(fd.trim());
/* 174 */     if (out == null) return null; 
/* 175 */     if (out instanceof JClass) return (JClass)out; 
/* 176 */     if (out instanceof WeakReference) {
/* 177 */       out = ((WeakReference)out).get();
/* 178 */       if (out == null) {
/* 179 */         this.mFd2ClassCache.remove(fd.trim());
/* 180 */         return null;
/*     */       } 
/* 182 */       return (JClass)out;
/*     */     } 
/*     */     
/* 185 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(ClassImpl out) {
/* 193 */     if (this.mInitializer != null)
/*     */     {
/*     */       
/* 196 */       if (this.mAlreadyInitializing) {
/*     */         
/* 198 */         this.mInitializeStack.push(out);
/*     */       } else {
/* 200 */         out.accept(this.mInitializer);
/* 201 */         while (!this.mInitializeStack.isEmpty()) {
/* 202 */           ClassImpl initme = this.mInitializeStack.pop();
/* 203 */           initme.accept(this.mInitializer);
/*     */         } 
/* 205 */         this.mAlreadyInitializing = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection getResolvedClasses() {
/* 215 */     return Collections.unmodifiableCollection(this.mFd2ClassCache.values());
/*     */   }
/*     */ 
/*     */   
/*     */   public void addToCache(JClass c) {
/* 220 */     cachePut(c);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\JamClassLoaderImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */