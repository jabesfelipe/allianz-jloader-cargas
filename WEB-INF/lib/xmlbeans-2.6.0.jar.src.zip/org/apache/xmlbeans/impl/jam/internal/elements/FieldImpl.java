/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JField;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.DirectJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.JClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.QualifiedJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.UnqualifiedJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.JVisitor;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FieldImpl
/*     */   extends MemberImpl
/*     */   implements MField
/*     */ {
/*     */   private JClassRef mTypeClassRef;
/*     */   
/*     */   FieldImpl(String simpleName, ClassImpl containingClass, String qualifiedTypeClassName) {
/*  48 */     super(containingClass);
/*  49 */     setSimpleName(simpleName);
/*  50 */     this.mTypeClassRef = QualifiedJClassRef.create(qualifiedTypeClassName, containingClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(JClass type) {
/*  58 */     if (type == null) throw new IllegalArgumentException("null type"); 
/*  59 */     this.mTypeClassRef = DirectJClassRef.create(type);
/*     */   }
/*     */   
/*     */   public void setType(String qcname) {
/*  63 */     if (qcname == null) throw new IllegalArgumentException("null qcname"); 
/*  64 */     this.mTypeClassRef = QualifiedJClassRef.create(qcname, (ClassImpl)getContainingClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUnqualifiedType(String ucname) {
/*  69 */     if (ucname == null) throw new IllegalArgumentException("null ucname"); 
/*  70 */     this.mTypeClassRef = UnqualifiedJClassRef.create(ucname, (ClassImpl)getContainingClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JClass getType() {
/*  78 */     if (this.mTypeClassRef == null) throw new IllegalStateException(); 
/*  79 */     return this.mTypeClassRef.getRefClass();
/*     */   }
/*     */   
/*     */   public boolean isFinal() {
/*  83 */     return Modifier.isFinal(getModifiers());
/*     */   }
/*     */   
/*     */   public boolean isStatic() {
/*  87 */     return Modifier.isStatic(getModifiers());
/*     */   }
/*     */   
/*     */   public boolean isVolatile() {
/*  91 */     return Modifier.isVolatile(getModifiers());
/*     */   }
/*     */   
/*     */   public boolean isTransient() {
/*  95 */     return Modifier.isTransient(getModifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(MVisitor visitor) {
/* 101 */     visitor.visit(this);
/*     */   } public void accept(JVisitor visitor) {
/* 103 */     visitor.visit((JField)this);
/*     */   }
/*     */   public String getQualifiedName() {
/* 106 */     StringWriter sbuf = new StringWriter();
/* 107 */     sbuf.write(Modifier.toString(getModifiers()));
/* 108 */     sbuf.write(32);
/* 109 */     sbuf.write(getType().getQualifiedName());
/* 110 */     sbuf.write(32);
/* 111 */     sbuf.write(getContainingClass().getQualifiedName());
/* 112 */     sbuf.write(46);
/* 113 */     sbuf.write(getSimpleName());
/* 114 */     return sbuf.toString();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\FieldImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */