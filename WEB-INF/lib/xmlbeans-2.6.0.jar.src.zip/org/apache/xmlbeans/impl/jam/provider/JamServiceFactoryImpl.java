/*     */ package org.apache.xmlbeans.impl.jam.provider;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ import org.apache.xmlbeans.impl.jam.JamService;
/*     */ import org.apache.xmlbeans.impl.jam.JamServiceFactory;
/*     */ import org.apache.xmlbeans.impl.jam.JamServiceParams;
/*     */ import org.apache.xmlbeans.impl.jam.internal.JamClassLoaderImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.JamServiceContextImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.JamServiceImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*     */ import org.apache.xmlbeans.impl.jam.internal.javadoc.JavadocClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.internal.parser.ParserClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.internal.reflect.ReflectClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JamServiceFactoryImpl
/*     */   extends JamServiceFactory
/*     */ {
/*     */   public static final String USE_NEW_PARSER = "JamServiceFactoryImpl.use-new-parser";
/*     */   private static final String PREFIX = "[JamServiceFactoryImpl]";
/*     */   
/*     */   public JamServiceParams createServiceParams() {
/*  67 */     return (JamServiceParams)new JamServiceContextImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JamService createService(JamServiceParams jsps) throws IOException {
/*  73 */     if (!(jsps instanceof JamServiceContextImpl)) {
/*  74 */       throw new IllegalArgumentException("JamServiceParams must be instantiated by this JamServiceFactory.");
/*     */     }
/*     */ 
/*     */     
/*  78 */     JamClassLoader clToUse = createClassLoader((JamServiceContext)jsps);
/*     */ 
/*     */     
/*  81 */     ((JamServiceContextImpl)jsps).setClassLoader(clToUse);
/*     */     
/*  83 */     return (JamService)new JamServiceImpl((ElementContext)jsps, getSpecifiedClasses((JamServiceContext)jsps));
/*     */   }
/*     */ 
/*     */   
/*     */   public JamClassLoader createSystemJamClassLoader() {
/*  88 */     JamServiceParams params = createServiceParams();
/*  89 */     params.setUseSystemClasspath(true);
/*     */     try {
/*  91 */       JamService service = createService(params);
/*  92 */       return service.getClassLoader();
/*  93 */     } catch (IOException reallyUnexpected) {
/*  94 */       reallyUnexpected.printStackTrace();
/*  95 */       throw new IllegalStateException(reallyUnexpected.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public JamClassLoader createJamClassLoader(ClassLoader cl) {
/* 100 */     JamServiceParams params = createServiceParams();
/* 101 */     params.setUseSystemClasspath(false);
/* 102 */     params.setPropertyInitializer(null);
/* 103 */     params.addClassLoader(cl);
/*     */     try {
/* 105 */       JamService service = createService(params);
/* 106 */       return service.getClassLoader();
/* 107 */     } catch (IOException reallyUnexpected) {
/* 108 */       reallyUnexpected.printStackTrace();
/* 109 */       throw new IllegalStateException(reallyUnexpected.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getSpecifiedClasses(JamServiceContext params) throws IOException {
/* 125 */     return params.getAllClassnames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JamClassLoader createClassLoader(JamServiceContext ctx) throws IOException {
/* 137 */     JamClassBuilder builder = createBuilder(ctx);
/* 138 */     return (JamClassLoader)new JamClassLoaderImpl((ElementContext)ctx, builder, ctx.getInitializer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JamClassBuilder createBuilder(JamServiceContext ctx) throws IOException {
/* 152 */     JamLogger log = ctx.getLogger();
/* 153 */     List builders = new ArrayList();
/*     */     
/* 155 */     JamClassBuilder b = ctx.getBaseBuilder();
/* 156 */     if (b != null) builders.add(b);
/*     */     
/* 158 */     b = createSourceBuilder(ctx);
/* 159 */     if (log.isVerbose(this)) {
/* 160 */       log.verbose("added classbuilder for sources");
/*     */     }
/* 162 */     if (b != null) builders.add(b); 
/* 163 */     b = createClassfileBuilder(ctx);
/* 164 */     if (log.isVerbose(this)) {
/* 165 */       log.verbose("added classbuilder for custom classpath");
/*     */     }
/* 167 */     if (b != null) builders.add(b); 
/* 168 */     ClassLoader[] cls = ctx.getReflectionClassLoaders();
/* 169 */     for (int i = 0; i < cls.length; i++) {
/* 170 */       if (log.isVerbose(this)) {
/* 171 */         log.verbose("added classbuilder for classloader " + cls[i].getClass());
/*     */       }
/* 173 */       builders.add(new ReflectClassBuilder(cls[i]));
/*     */     } 
/* 175 */     JamClassBuilder[] barray = new JamClassBuilder[builders.size()];
/* 176 */     builders.toArray(barray);
/* 177 */     JamClassBuilder out = new CompositeJamClassBuilder(barray);
/* 178 */     out.init((ElementContext)ctx);
/* 179 */     if (log.isVerbose(this)) {
/* 180 */       log.verbose("returning a composite of " + barray.length + " class builders.");
/* 181 */       MClass mClass = out.build("java.lang", "Object");
/* 182 */       mClass = out.build("javax.ejb", "SessionBean");
/*     */     } 
/* 184 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JamClassBuilder createSourceBuilder(JamServiceContext ctx) throws IOException {
/* 196 */     File[] sources = ctx.getSourceFiles();
/* 197 */     if (sources == null || sources.length == 0) {
/* 198 */       if (ctx.isVerbose(this)) {
/* 199 */         ctx.verbose("[JamServiceFactoryImpl]no source files present, skipping source ClassBuilder");
/*     */       }
/*     */       
/* 202 */       return null;
/*     */     } 
/* 204 */     if (ctx.getProperty("JamServiceFactoryImpl.use-new-parser") == null) {
/* 205 */       return (JamClassBuilder)new JavadocClassBuilder();
/*     */     }
/* 207 */     return (JamClassBuilder)new ParserClassBuilder(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JamClassBuilder createClassfileBuilder(JamServiceContext jp) throws IOException {
/* 222 */     ResourcePath cp = jp.getInputClasspath();
/* 223 */     if (cp == null) {
/* 224 */       return null;
/*     */     }
/* 226 */     URL[] urls = cp.toUrlPath();
/* 227 */     ClassLoader cl = new URLClassLoader(urls);
/* 228 */     return (JamClassBuilder)new ReflectClassBuilder(cl);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\provider\JamServiceFactoryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */