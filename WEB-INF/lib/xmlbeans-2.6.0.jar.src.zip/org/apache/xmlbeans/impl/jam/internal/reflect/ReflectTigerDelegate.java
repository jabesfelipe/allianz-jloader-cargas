/*    */ package org.apache.xmlbeans.impl.jam.internal.reflect;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.xmlbeans.impl.jam.internal.TigerDelegate;
/*    */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MConstructor;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MMember;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*    */ import org.apache.xmlbeans.impl.jam.provider.JamLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ReflectTigerDelegate
/*    */   extends TigerDelegate
/*    */ {
/*    */   private static final String IMPL_NAME = "org.apache.xmlbeans.impl.jam.internal.reflect.ReflectTigerDelegateImpl_150";
/*    */   
/*    */   public static ReflectTigerDelegate create(JamLogger logger) {
/* 45 */     if (!isTigerReflectionAvailable(logger)) return null;
/*    */     
/*    */     try {
/* 48 */       ReflectTigerDelegate out = (ReflectTigerDelegate)Class.forName("org.apache.xmlbeans.impl.jam.internal.reflect.ReflectTigerDelegateImpl_150").newInstance();
/*    */       
/* 50 */       out.init(logger);
/* 51 */       return out;
/* 52 */     } catch (ClassNotFoundException e) {
/* 53 */       issue14BuildWarning(e, logger);
/* 54 */     } catch (IllegalAccessException e) {
/* 55 */       logger.error(e);
/* 56 */     } catch (InstantiationException e) {
/* 57 */       logger.error(e);
/*    */     } 
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ReflectTigerDelegate create(ElementContext ctx) {
/* 66 */     if (!isTigerReflectionAvailable(ctx.getLogger())) return null;
/*    */     
/*    */     try {
/* 69 */       ReflectTigerDelegate out = (ReflectTigerDelegate)Class.forName("org.apache.xmlbeans.impl.jam.internal.reflect.ReflectTigerDelegateImpl_150").newInstance();
/*    */       
/* 71 */       out.init(ctx);
/* 72 */       return out;
/* 73 */     } catch (ClassNotFoundException e) {
/* 74 */       issue14BuildWarning(e, ctx.getLogger());
/* 75 */     } catch (IllegalAccessException e) {
/* 76 */       ctx.getLogger().error(e);
/* 77 */     } catch (InstantiationException e) {
/* 78 */       ctx.getLogger().error(e);
/*    */     } 
/* 80 */     return null;
/*    */   }
/*    */   
/*    */   public abstract void populateAnnotationTypeIfNecessary(Class paramClass, MClass paramMClass, ReflectClassBuilder paramReflectClassBuilder);
/*    */   
/*    */   public abstract boolean isEnum(Class paramClass);
/*    */   
/*    */   public abstract Constructor getEnclosingConstructor(Class paramClass);
/*    */   
/*    */   public abstract Method getEnclosingMethod(Class paramClass);
/*    */   
/*    */   public abstract void extractAnnotations(MMember paramMMember, Method paramMethod);
/*    */   
/*    */   public abstract void extractAnnotations(MConstructor paramMConstructor, Constructor paramConstructor);
/*    */   
/*    */   public abstract void extractAnnotations(MField paramMField, Field paramField);
/*    */   
/*    */   public abstract void extractAnnotations(MClass paramMClass, Class paramClass);
/*    */   
/*    */   public abstract void extractAnnotations(MParameter paramMParameter, Method paramMethod, int paramInt);
/*    */   
/*    */   public abstract void extractAnnotations(MParameter paramMParameter, Constructor paramConstructor, int paramInt);
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\reflect\ReflectTigerDelegate.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */