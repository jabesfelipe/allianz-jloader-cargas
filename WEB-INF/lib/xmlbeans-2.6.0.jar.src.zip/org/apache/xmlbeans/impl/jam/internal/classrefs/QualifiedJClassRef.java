/*    */ package org.apache.xmlbeans.impl.jam.internal.classrefs;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QualifiedJClassRef
/*    */   implements JClassRef
/*    */ {
/*    */   private String mQualifiedClassname;
/*    */   private JamClassLoader mClassLoader;
/*    */   
/*    */   public static JClassRef create(JClass clazz) {
/* 44 */     if (clazz == null) throw new IllegalArgumentException("null clazz"); 
/* 45 */     return new QualifiedJClassRef(clazz.getFieldDescriptor(), clazz.getClassLoader());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static JClassRef create(String qcname, JClassRefContext ctx) {
/* 54 */     if (qcname == null) throw new IllegalArgumentException("null qcname"); 
/* 55 */     if (ctx == null) throw new IllegalArgumentException("null ctx"); 
/* 56 */     return create(qcname, ctx.getClassLoader());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static JClassRef create(String qcname, JamClassLoader cl) {
/* 63 */     if (qcname == null) throw new IllegalArgumentException("null qcname"); 
/* 64 */     if (cl == null) throw new IllegalArgumentException("null classloader"); 
/* 65 */     return new QualifiedJClassRef(qcname, cl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private QualifiedJClassRef(String qcname, JamClassLoader cl) {
/* 72 */     this.mClassLoader = cl;
/* 73 */     this.mQualifiedClassname = qcname;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JClass getRefClass() {
/* 80 */     return this.mClassLoader.loadClass(this.mQualifiedClassname);
/*    */   }
/*    */   
/*    */   public String getQualifiedName() {
/* 84 */     return this.mQualifiedClassname;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     return "(QualifiedJClassRef '" + this.mQualifiedClassname + "')";
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\classrefs\QualifiedJClassRef.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */