/*    */ package org.apache.xmlbeans.impl.jam.internal.reflect;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MConstructor;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MMember;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReflectTigerDelegateImpl_150
/*    */   extends ReflectTigerDelegate
/*    */ {
/*    */   public void populateAnnotationTypeIfNecessary(Class cd, MClass clazz, ReflectClassBuilder builder) {}
/*    */   
/*    */   public void extractAnnotations(MMember dest, Method src) {}
/*    */   
/*    */   public void extractAnnotations(MConstructor dest, Constructor src) {}
/*    */   
/*    */   public void extractAnnotations(MField dest, Field src) {}
/*    */   
/*    */   public void extractAnnotations(MClass dest, Class src) {}
/*    */   
/*    */   public void extractAnnotations(MParameter dest, Method src, int paramNum) {}
/*    */   
/*    */   public void extractAnnotations(MParameter dest, Constructor src, int paramNum) {}
/*    */   
/*    */   public boolean isEnum(Class clazz) {
/* 76 */     return false;
/*    */   }
/*    */   
/*    */   public Constructor getEnclosingConstructor(Class clazz) {
/* 80 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Method getEnclosingMethod(Class clazz) {
/* 85 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\reflect\ReflectTigerDelegateImpl_150.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */