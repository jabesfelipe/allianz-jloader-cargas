package org.apache.xmlbeans.impl.jam;

public interface JamClassLoader {
  JClass loadClass(String paramString);
  
  JPackage getPackage(String paramString);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\JamClassLoader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */