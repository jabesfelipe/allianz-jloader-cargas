/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PrimitiveClassImpl
/*     */   extends BuiltinClassImpl
/*     */ {
/*  33 */   private static final Object[][] PRIMITIVES = new Object[][] { { "int", "I", int.class }, { "long", "J", long.class }, { "boolean", "Z", boolean.class }, { "short", "S", short.class }, { "byte", "B", byte.class }, { "char", "C", char.class }, { "float", "F", float.class }, { "double", "D", double.class } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private static final Map NAME_TO_FD = new HashMap();
/*  49 */   private static final Map NAME_TO_CLASS = new HashMap(); static {
/*  50 */     for (int i = 0; i < PRIMITIVES.length; i++) {
/*  51 */       NAME_TO_FD.put(PRIMITIVES[i][0], PRIMITIVES[i][1]);
/*  52 */       NAME_TO_CLASS.put(PRIMITIVES[i][0], PRIMITIVES[i][2]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void mapNameToPrimitive(ElementContext ctx, Map out) {
/*  60 */     for (int i = 0; i < PRIMITIVES.length; i++) {
/*  61 */       PrimitiveClassImpl primitiveClassImpl = new PrimitiveClassImpl(ctx, (String)PRIMITIVES[i][0]);
/*  62 */       out.put(PRIMITIVES[i][0], primitiveClassImpl);
/*  63 */       out.put(PRIMITIVES[i][1], primitiveClassImpl);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPrimitiveClassForName(String named) {
/*  74 */     return (String)NAME_TO_FD.get(named);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrimitive(String name) {
/* 106 */     return (NAME_TO_FD.get(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getFieldDescriptor(String classname) {
/* 114 */     return (String)NAME_TO_FD.get(classname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Class getPrimitiveClass(String classname) {
/* 124 */     return (Class)NAME_TO_CLASS.get(classname);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PrimitiveClassImpl(ElementContext ctx, String name) {
/* 131 */     super(ctx);
/* 132 */     if (name == null) throw new IllegalArgumentException("null name"); 
/* 133 */     if (!NAME_TO_FD.containsKey(name)) {
/* 134 */       throw new IllegalArgumentException("Unknown primitive class '" + name + "'");
/*     */     }
/*     */     
/* 137 */     reallySetSimpleName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQualifiedName() {
/* 143 */     return getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldDescriptor() {
/* 149 */     return (String)NAME_TO_FD.get(getSimpleName());
/*     */   }
/*     */   
/*     */   public boolean isAssignableFrom(JClass c) {
/* 153 */     return (c.isPrimitiveType() && c.getSimpleName().equals(getSimpleName()));
/*     */   }
/*     */   public boolean isPrimitiveType() {
/* 156 */     return true;
/*     */   }
/*     */   public Class getPrimitiveClass() {
/* 159 */     return (Class)NAME_TO_CLASS.get(getSimpleName());
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\PrimitiveClassImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */