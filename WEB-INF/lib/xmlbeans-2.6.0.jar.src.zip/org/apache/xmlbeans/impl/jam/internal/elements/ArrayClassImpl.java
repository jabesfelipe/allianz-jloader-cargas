/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ArrayClassImpl
/*     */   extends BuiltinClassImpl
/*     */ {
/*     */   private int mDimensions;
/*     */   private JClass mComponentType;
/*     */   
/*     */   public static JClass createClassForFD(String arrayFD, JamClassLoader loader) {
/*  44 */     if (!arrayFD.startsWith("[")) {
/*  45 */       throw new IllegalArgumentException("must be an array type fd: " + arrayFD);
/*     */     }
/*     */     
/*  48 */     if (arrayFD.endsWith(";")) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  53 */       int i = arrayFD.indexOf("L");
/*  54 */       if (i != -1 && i < arrayFD.length() - 2) {
/*  55 */         String componentType = arrayFD.substring(i + 1, arrayFD.length() - 1);
/*  56 */         return (JClass)new ArrayClassImpl(loader.loadClass(componentType), i);
/*     */       } 
/*     */       
/*  59 */       throw new IllegalArgumentException("array type field descriptor '" + arrayFD + "' is malformed");
/*     */     } 
/*     */ 
/*     */     
/*  63 */     int dims = arrayFD.lastIndexOf("[") + 1;
/*  64 */     String compFd = arrayFD.substring(dims, dims + 1);
/*  65 */     JClass primType = loader.loadClass(compFd);
/*  66 */     if (primType == null)
/*     */     {
/*     */       
/*  69 */       throw new IllegalArgumentException("array type field descriptor '" + arrayFD + "' is malformed");
/*     */     }
/*     */     
/*  72 */     return (JClass)new ArrayClassImpl(primType, dims);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String normalizeArrayName(String declaration) {
/*  84 */     if (declaration.startsWith("[")) return declaration; 
/*  85 */     if (declaration.endsWith("]")) {
/*  86 */       int bracket = declaration.indexOf('[');
/*  87 */       if (bracket != -1) {
/*  88 */         String typeName = declaration.substring(0, bracket);
/*  89 */         String fd = PrimitiveClassImpl.getPrimitiveClassForName(typeName);
/*  90 */         if (fd == null) fd = 'L' + typeName + ';'; 
/*  91 */         StringWriter out = new StringWriter();
/*     */         while (true) {
/*  93 */           out.write(91);
/*  94 */           bracket = declaration.indexOf('[', bracket + 1);
/*  95 */           if (bracket == -1)
/*  96 */           { out.write(fd);
/*  97 */             return out.toString(); } 
/*     */         } 
/*     */       } 
/* 100 */     }  throw new IllegalArgumentException("'" + declaration + "' does not name an array");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayClassImpl(JClass componentType, int dimensions) {
/* 114 */     super(((ElementImpl)componentType).getContext());
/* 115 */     if (dimensions < 1) {
/* 116 */       throw new IllegalArgumentException("dimensions=" + dimensions);
/*     */     }
/* 118 */     if (componentType == null) {
/* 119 */       throw new IllegalArgumentException("null componentType");
/*     */     }
/* 121 */     this.mComponentType = componentType;
/* 122 */     this.mDimensions = dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSimpleName() {
/* 131 */     String out = getQualifiedName();
/* 132 */     int lastDot = out.lastIndexOf('.');
/* 133 */     return (lastDot == -1) ? out : out.substring(lastDot + 1);
/*     */   }
/*     */   
/*     */   public String getQualifiedName() {
/* 137 */     StringWriter out = new StringWriter();
/* 138 */     out.write(this.mComponentType.getQualifiedName());
/* 139 */     for (int i = 0; i < this.mDimensions; ) { out.write("[]"); i++; }
/* 140 */      return out.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isArrayType() {
/* 146 */     return true;
/*     */   } public JClass getArrayComponentType() {
/* 148 */     return this.mComponentType;
/*     */   } public int getArrayDimensions() {
/* 150 */     return this.mDimensions;
/*     */   }
/*     */   public JClass getSuperclass() {
/* 153 */     return getClassLoader().loadClass("java.lang.Object");
/*     */   }
/*     */   
/*     */   public boolean isAssignableFrom(JClass c) {
/* 157 */     return (c.isArrayType() && c.getArrayDimensions() == this.mDimensions && this.mComponentType.isAssignableFrom(c.getArrayComponentType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldDescriptor() {
/* 164 */     StringWriter out = new StringWriter();
/* 165 */     for (int i = 0; i < this.mDimensions; ) { out.write("["); i++; }
/* 166 */      if (this.mComponentType.isPrimitiveType()) {
/* 167 */       out.write(this.mComponentType.getFieldDescriptor());
/*     */     } else {
/* 169 */       out.write("L");
/* 170 */       out.write(this.mComponentType.getQualifiedName());
/* 171 */       out.write(";");
/*     */     } 
/* 173 */     return out.toString();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\ArrayClassImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */