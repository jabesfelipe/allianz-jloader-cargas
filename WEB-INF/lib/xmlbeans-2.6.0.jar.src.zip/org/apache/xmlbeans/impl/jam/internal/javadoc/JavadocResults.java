/*    */ package org.apache.xmlbeans.impl.jam.internal.javadoc;
/*    */ 
/*    */ import com.sun.javadoc.RootDoc;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavadocResults
/*    */ {
/* 37 */   private static final JavadocResults INSTANCE = new JavadocResults();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   private ThreadLocal mRootsPerThread = new ThreadLocal();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void prepare() {
/* 48 */     Thread.currentThread().setContextClassLoader(JavadocResults.class.getClassLoader());
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setRoot(RootDoc root) {
/*    */     try {
/* 54 */       Object holder = getHolder();
/* 55 */       Method setter = holder.getClass().getMethod("_setRoot", new Class[] { RootDoc.class });
/*    */       
/* 57 */       setter.invoke(holder, new Object[] { root });
/* 58 */     } catch (Exception e) {
/* 59 */       e.printStackTrace();
/* 60 */       throw new IllegalStateException();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static RootDoc getRoot() {
/*    */     try {
/* 66 */       Object holder = getHolder();
/* 67 */       Method getter = holder.getClass().getMethod("_getRoot", new Class[0]);
/* 68 */       return (RootDoc)getter.invoke(holder, (Object[])null);
/* 69 */     } catch (Exception e) {
/* 70 */       e.printStackTrace();
/* 71 */       throw new IllegalStateException();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void _setRoot(RootDoc root) {
/* 78 */     this.mRootsPerThread.set(root);
/*    */   } public RootDoc _getRoot() {
/* 80 */     return this.mRootsPerThread.get();
/*    */   } public static JavadocResults getInstance() {
/* 82 */     return INSTANCE;
/*    */   }
/*    */   private static Object getHolder() throws Exception {
/* 85 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 86 */     Class clazz = classLoader.loadClass(JavadocResults.class.getName());
/* 87 */     Method method = clazz.getMethod("getInstance", new Class[0]);
/* 88 */     return method.invoke(null, new Object[0]);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\javadoc\JavadocResults.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */