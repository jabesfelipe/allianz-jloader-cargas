/*     */ package org.apache.xmlbeans.impl.jam.internal.javadoc;
/*     */ 
/*     */ import com.sun.javadoc.ClassDoc;
/*     */ import com.sun.javadoc.ConstructorDoc;
/*     */ import com.sun.javadoc.Doc;
/*     */ import com.sun.javadoc.ExecutableMemberDoc;
/*     */ import com.sun.javadoc.FieldDoc;
/*     */ import com.sun.javadoc.MethodDoc;
/*     */ import com.sun.javadoc.PackageDoc;
/*     */ import com.sun.javadoc.Parameter;
/*     */ import com.sun.javadoc.ProgramElementDoc;
/*     */ import com.sun.javadoc.RootDoc;
/*     */ import com.sun.javadoc.SourcePosition;
/*     */ import com.sun.javadoc.Tag;
/*     */ import com.sun.javadoc.Type;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.xmlbeans.impl.jam.annotation.JavadocTagParser;
/*     */ import org.apache.xmlbeans.impl.jam.internal.JamServiceContextImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.PrimitiveClassImpl;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotatedElement;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MElement;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MInvokable;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MMethod;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MSourcePosition;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassPopulator;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamServiceContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocClassBuilder
/*     */   extends JamClassBuilder
/*     */   implements JamClassPopulator
/*     */ {
/*     */   public static final String ARGS_PROPERTY = "javadoc.args";
/*     */   public static final String PARSETAGS_PROPERTY = "javadoc.parsetags";
/*  69 */   private RootDoc mRootDoc = null;
/*  70 */   private JavadocTigerDelegate mTigerDelegate = null;
/*  71 */   private JavadocTagParser mTagParser = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mParseTags = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(ElementContext ctx) {
/*  83 */     if (ctx == null) throw new IllegalArgumentException("null context"); 
/*  84 */     super.init(ctx);
/*  85 */     getLogger().verbose("init()", this);
/*  86 */     initDelegate(ctx);
/*  87 */     initJavadoc((JamServiceContext)ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public MClass build(String packageName, String className) {
/*  92 */     assertInitialized();
/*  93 */     if (getLogger().isVerbose(this)) {
/*  94 */       getLogger().verbose("trying to build '" + packageName + "' '" + className + "'");
/*     */     }
/*  96 */     String loadme = (packageName.trim().length() > 0) ? (packageName + '.' + className) : className;
/*     */ 
/*     */     
/*  99 */     ClassDoc cd = this.mRootDoc.classNamed(loadme);
/* 100 */     if (cd == null) {
/* 101 */       if (getLogger().isVerbose(this)) {
/* 102 */         getLogger().verbose("no ClassDoc for " + loadme);
/*     */       }
/* 104 */       return null;
/*     */     } 
/* 106 */     List importSpecs = null;
/*     */     
/* 108 */     ClassDoc[] arrayOfClassDoc = cd.importedClasses();
/* 109 */     if (arrayOfClassDoc != null) {
/* 110 */       importSpecs = new ArrayList();
/* 111 */       for (int i = 0; i < arrayOfClassDoc.length; i++) {
/* 112 */         importSpecs.add(getFdFor((Type)arrayOfClassDoc[i]));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 117 */     PackageDoc[] imported = cd.importedPackages();
/* 118 */     if (imported != null) {
/* 119 */       if (importSpecs == null) importSpecs = new ArrayList(); 
/* 120 */       for (int i = 0; i < imported.length; i++) {
/* 121 */         importSpecs.add(imported[i].name() + ".*");
/*     */       }
/*     */     } 
/*     */     
/* 125 */     String[] importSpecsArray = null;
/* 126 */     if (importSpecs != null) {
/* 127 */       importSpecsArray = new String[importSpecs.size()];
/* 128 */       importSpecs.toArray(importSpecsArray);
/*     */     } 
/* 130 */     MClass out = createClassToBuild(packageName, className, importSpecsArray, this);
/* 131 */     out.setArtifact(cd);
/* 132 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populate(MClass dest) {
/* 139 */     if (dest == null) throw new IllegalArgumentException("null dest"); 
/* 140 */     assertInitialized();
/* 141 */     ClassDoc src = (ClassDoc)dest.getArtifact();
/* 142 */     if (src == null) throw new IllegalStateException("null artifact"); 
/* 143 */     dest.setModifiers(src.modifierSpecifier());
/* 144 */     dest.setIsInterface(src.isInterface());
/* 145 */     if (this.mTigerDelegate != null) dest.setIsEnumType(this.mTigerDelegate.isEnum(src));
/*     */     
/* 147 */     ClassDoc s = src.superclass();
/* 148 */     if (s != null) dest.setSuperclass(getFdFor((Type)s));
/*     */     
/* 150 */     ClassDoc[] ints = src.interfaces();
/* 151 */     for (int i = 0; i < ints.length; i++) {
/* 152 */       dest.addInterface(getFdFor((Type)ints[i]));
/*     */     }
/*     */     
/* 155 */     FieldDoc[] fields = src.fields();
/* 156 */     for (int j = 0; j < fields.length; ) { populate(dest.addNewField(), fields[j]); j++; }
/*     */     
/* 158 */     ConstructorDoc[] ctors = src.constructors();
/* 159 */     for (int k = 0; k < ctors.length; ) { populate((MInvokable)dest.addNewConstructor(), (ExecutableMemberDoc)ctors[k]); k++; }
/*     */     
/* 161 */     MethodDoc[] methods = src.methods();
/* 162 */     for (int m = 0; m < methods.length; ) { populate(dest.addNewMethod(), methods[m]); m++; }
/*     */ 
/*     */ 
/*     */     
/* 166 */     if (this.mTigerDelegate != null) {
/* 167 */       this.mTigerDelegate.populateAnnotationTypeIfNecessary(src, dest, this);
/*     */     }
/*     */ 
/*     */     
/* 171 */     addAnnotations((MAnnotatedElement)dest, (ProgramElementDoc)src);
/*     */     
/* 173 */     addSourcePosition((MElement)dest, (Doc)src);
/*     */     
/* 175 */     ClassDoc[] inners = src.innerClasses();
/* 176 */     if (inners != null) {
/* 177 */       for (int n = 0; n < inners.length; n++) {
/* 178 */         MClass inner = dest.addNewInnerClass(inners[n].typeName());
/* 179 */         inner.setArtifact(inners[n]);
/* 180 */         populate(inner);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MMethod addMethod(MClass dest, MethodDoc doc) {
/* 188 */     MMethod out = dest.addNewMethod();
/* 189 */     populate(out, doc);
/* 190 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initDelegate(ElementContext ctx) {
/* 197 */     this.mTigerDelegate = JavadocTigerDelegate.create(ctx);
/*     */   }
/*     */   
/*     */   private void initJavadoc(JamServiceContext serviceContext) {
/*     */     File[] files;
/* 202 */     this.mTagParser = serviceContext.getTagParser();
/* 203 */     String pct = serviceContext.getProperty("javadoc.parsetags");
/* 204 */     if (pct != null) {
/* 205 */       this.mParseTags = Boolean.valueOf(pct).booleanValue();
/* 206 */       getLogger().verbose("mParseTags=" + this.mParseTags, this);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 211 */       files = serviceContext.getSourceFiles();
/* 212 */     } catch (IOException ioe) {
/* 213 */       getLogger().error(ioe);
/*     */       return;
/*     */     } 
/* 216 */     if (files == null || files.length == 0) {
/* 217 */       throw new IllegalArgumentException("No source files in context.");
/*     */     }
/* 219 */     String sourcePath = (serviceContext.getInputSourcepath() == null) ? null : serviceContext.getInputSourcepath().toString();
/*     */     
/* 221 */     String classPath = (serviceContext.getInputClasspath() == null) ? null : serviceContext.getInputClasspath().toString();
/*     */     
/* 223 */     if (getLogger().isVerbose(this)) {
/* 224 */       getLogger().verbose("sourcePath =" + sourcePath);
/* 225 */       getLogger().verbose("classPath =" + classPath);
/* 226 */       for (int i = 0; i < files.length; i++) {
/* 227 */         getLogger().verbose("including '" + files[i] + "'");
/*     */       }
/*     */     } 
/* 230 */     JavadocRunner jdr = JavadocRunner.newInstance();
/*     */     try {
/* 232 */       PrintWriter out = null;
/* 233 */       if (getLogger().isVerbose(this)) {
/* 234 */         out = new PrintWriter(System.out);
/*     */       }
/* 236 */       this.mRootDoc = jdr.run(files, out, sourcePath, classPath, getJavadocArgs(serviceContext), getLogger());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 242 */       if (this.mRootDoc == null) {
/* 243 */         getLogger().error("Javadoc returned a null root");
/*     */       } else {
/* 245 */         if (getLogger().isVerbose(this)) {
/* 246 */           getLogger().verbose(" received " + (this.mRootDoc.classes()).length + " ClassDocs from javadoc: ");
/*     */         }
/*     */         
/* 249 */         ClassDoc[] classes = this.mRootDoc.classes();
/*     */ 
/*     */ 
/*     */         
/* 253 */         for (int i = 0; i < classes.length; i++) {
/* 254 */           if (classes[i].containingClass() == null) {
/* 255 */             if (getLogger().isVerbose(this)) {
/* 256 */               getLogger().verbose("..." + classes[i].qualifiedName());
/*     */             }
/* 258 */             ((JamServiceContextImpl)serviceContext).includeClass(getFdFor((Type)classes[i]));
/*     */           } 
/*     */         } 
/*     */       } 
/* 262 */     } catch (FileNotFoundException e) {
/* 263 */       getLogger().error(e);
/* 264 */     } catch (IOException e) {
/* 265 */       getLogger().error(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void populate(MField dest, FieldDoc src) {
/* 270 */     dest.setArtifact(src);
/* 271 */     dest.setSimpleName(src.name());
/* 272 */     dest.setType(getFdFor(src.type()));
/* 273 */     dest.setModifiers(src.modifierSpecifier());
/* 274 */     addAnnotations((MAnnotatedElement)dest, (ProgramElementDoc)src);
/* 275 */     addSourcePosition((MElement)dest, (Doc)src);
/*     */   }
/*     */   
/*     */   private void populate(MMethod dest, MethodDoc src) {
/* 279 */     if (dest == null) throw new IllegalArgumentException("null dest"); 
/* 280 */     if (src == null) throw new IllegalArgumentException("null src"); 
/* 281 */     populate((MInvokable)dest, (ExecutableMemberDoc)src);
/* 282 */     dest.setReturnType(getFdFor(src.returnType()));
/*     */   }
/*     */   
/*     */   private void populate(MInvokable dest, ExecutableMemberDoc src) {
/* 286 */     if (dest == null) throw new IllegalArgumentException("null dest"); 
/* 287 */     if (src == null) throw new IllegalArgumentException("null src"); 
/* 288 */     dest.setArtifact(src);
/* 289 */     dest.setSimpleName(src.name());
/* 290 */     dest.setModifiers(src.modifierSpecifier());
/* 291 */     ClassDoc[] exceptions = src.thrownExceptions();
/* 292 */     for (int i = 0; i < exceptions.length; i++) {
/* 293 */       dest.addException(getFdFor((Type)exceptions[i]));
/*     */     }
/* 295 */     Parameter[] params = src.parameters();
/* 296 */     for (int j = 0; j < params.length; j++) {
/* 297 */       populate(dest.addNewParameter(), src, params[j]);
/*     */     }
/* 299 */     addAnnotations((MAnnotatedElement)dest, (ProgramElementDoc)src);
/* 300 */     addSourcePosition((MElement)dest, (Doc)src);
/*     */   }
/*     */   
/*     */   private void populate(MParameter dest, ExecutableMemberDoc method, Parameter src) {
/* 304 */     dest.setArtifact(src);
/* 305 */     dest.setSimpleName(src.name());
/* 306 */     dest.setType(getFdFor(src.type()));
/* 307 */     if (this.mTigerDelegate != null) this.mTigerDelegate.extractAnnotations((MAnnotatedElement)dest, method, src);
/*     */   
/*     */   }
/*     */   
/*     */   private String[] getJavadocArgs(JamServiceContext ctx) {
/* 312 */     String prop = ctx.getProperty("javadoc.args");
/* 313 */     if (prop == null) return null; 
/* 314 */     StringTokenizer t = new StringTokenizer(prop);
/* 315 */     String[] out = new String[t.countTokens()];
/* 316 */     int i = 0;
/* 317 */     for (; t.hasMoreTokens(); out[i++] = t.nextToken());
/* 318 */     return out;
/*     */   }
/*     */   
/*     */   private void addAnnotations(MAnnotatedElement dest, ProgramElementDoc src) {
/* 322 */     String comments = src.commentText();
/* 323 */     if (comments != null) dest.createComment().setText(comments); 
/* 324 */     Tag[] tags = src.tags();
/*     */ 
/*     */ 
/*     */     
/* 328 */     for (int i = 0; i < tags.length; i++) {
/* 329 */       if (getLogger().isVerbose(this)) {
/* 330 */         getLogger().verbose("...'" + tags[i].name() + "' ' " + tags[i].text());
/*     */       }
/*     */       
/* 333 */       this.mTagParser.parse(dest, tags[i]);
/*     */     } 
/* 335 */     if (this.mTigerDelegate != null) this.mTigerDelegate.extractAnnotations(dest, src);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFdFor(Type t) {
/* 348 */     if (t == null) throw new IllegalArgumentException("null type"); 
/* 349 */     String dim = t.dimension();
/* 350 */     if (dim == null || dim.length() == 0) {
/* 351 */       ClassDoc cd = t.asClassDoc();
/* 352 */       if (cd != null) {
/* 353 */         ClassDoc outer = cd.containingClass();
/* 354 */         if (outer == null) return cd.qualifiedName(); 
/* 355 */         String simpleName = cd.name();
/* 356 */         simpleName = simpleName.substring(simpleName.lastIndexOf('.') + 1);
/* 357 */         return outer.qualifiedName() + '$' + simpleName;
/*     */       } 
/* 359 */       return t.qualifiedTypeName();
/*     */     } 
/*     */     
/* 362 */     StringWriter out = new StringWriter();
/* 363 */     for (int i = 0, iL = dim.length() / 2; i < iL; ) { out.write("["); i++; }
/* 364 */      String primFd = PrimitiveClassImpl.getPrimitiveClassForName(t.qualifiedTypeName());
/*     */     
/* 366 */     if (primFd != null) {
/* 367 */       out.write(primFd);
/*     */     } else {
/* 369 */       out.write("L");
/* 370 */       if (t.asClassDoc() != null) {
/* 371 */         out.write(t.asClassDoc().qualifiedName());
/*     */       } else {
/* 373 */         out.write(t.qualifiedTypeName());
/*     */       } 
/* 375 */       out.write(";");
/*     */     } 
/* 377 */     return out.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addSourcePosition(MElement dest, Doc src) {
/* 382 */     SourcePosition pos = src.position();
/* 383 */     if (pos != null) addSourcePosition(dest, pos); 
/*     */   }
/*     */   
/*     */   public static void addSourcePosition(MElement dest, SourcePosition pos) {
/* 387 */     MSourcePosition sp = dest.createSourcePosition();
/* 388 */     sp.setColumn(pos.column());
/* 389 */     sp.setLine(pos.line());
/* 390 */     File f = pos.file();
/* 391 */     if (f != null) sp.setSourceURI(f.toURI()); 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\javadoc\JavadocClassBuilder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */