/*    */ package org.apache.xmlbeans.impl.jam.internal.classrefs;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirectJClassRef
/*    */   implements JClassRef
/*    */ {
/*    */   private JClass mClass;
/*    */   
/*    */   public static JClassRef create(JClass clazz) {
/* 31 */     if (clazz instanceof JClassRef) return (JClassRef)clazz; 
/* 32 */     return new DirectJClassRef(clazz);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private DirectJClassRef(JClass clazz) {
/* 44 */     if (clazz == null) throw new IllegalArgumentException("null clazz"); 
/* 45 */     this.mClass = clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JClass getRefClass() {
/* 52 */     return this.mClass;
/*    */   }
/*    */   
/*    */   public String getQualifiedName() {
/* 56 */     return this.mClass.getQualifiedName();
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\classrefs\DirectJClassRef.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */