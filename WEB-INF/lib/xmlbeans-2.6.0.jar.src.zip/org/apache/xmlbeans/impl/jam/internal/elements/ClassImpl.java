/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotationValue;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JComment;
/*     */ import org.apache.xmlbeans.impl.jam.JConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.JField;
/*     */ import org.apache.xmlbeans.impl.jam.JMethod;
/*     */ import org.apache.xmlbeans.impl.jam.JPackage;
/*     */ import org.apache.xmlbeans.impl.jam.JProperty;
/*     */ import org.apache.xmlbeans.impl.jam.JSourcePosition;
/*     */ import org.apache.xmlbeans.impl.jam.internal.JamClassLoaderImpl;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.JClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.JClassRefContext;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.QualifiedJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.internal.classrefs.UnqualifiedJClassRef;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MMethod;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassPopulator;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.JVisitor;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassImpl
/*     */   extends MemberImpl
/*     */   implements MClass, JClassRef, JClassRefContext
/*     */ {
/*     */   public static final int NEW = 1;
/*     */   public static final int UNPOPULATED = 2;
/*     */   public static final int POPULATING = 3;
/*     */   public static final int UNINITIALIZED = 4;
/*     */   public static final int INITIALIZING = 5;
/*     */   public static final int LOADED = 6;
/*  69 */   private int mState = 1;
/*     */   
/*     */   private boolean mIsAnnotationType = false;
/*     */   
/*     */   private boolean mIsInterface = false;
/*     */   private boolean mIsEnum = false;
/*  75 */   private String mPackageName = null;
/*     */   
/*  77 */   private JClassRef mSuperClassRef = null;
/*  78 */   private ArrayList mInterfaceRefs = null;
/*     */   
/*  80 */   private ArrayList mFields = null;
/*  81 */   private ArrayList mMethods = null;
/*  82 */   private ArrayList mConstructors = null;
/*  83 */   private ArrayList mProperties = null;
/*  84 */   private ArrayList mDeclaredProperties = null;
/*  85 */   private ArrayList mInnerClasses = null;
/*     */   
/*  87 */   private String[] mImports = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JamClassPopulator mPopulator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassImpl(String packageName, String simpleName, ElementContext ctx, String[] importSpecs, JamClassPopulator populator) {
/* 103 */     super(ctx);
/* 104 */     super.setSimpleName(simpleName);
/* 105 */     this.mPackageName = packageName.trim();
/* 106 */     this.mImports = importSpecs;
/* 107 */     this.mPopulator = populator;
/* 108 */     setState(2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassImpl(String packageName, String simpleName, ElementContext ctx, String[] importSpecs) {
/* 116 */     super(ctx);
/* 117 */     super.setSimpleName(simpleName);
/* 118 */     this.mPackageName = packageName.trim();
/* 119 */     this.mImports = importSpecs;
/* 120 */     this.mPopulator = null;
/* 121 */     setState(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassImpl(String packageName, String simpleName, String[] importSpecs, ClassImpl parent) {
/* 129 */     super(parent);
/* 130 */     super.setSimpleName(simpleName);
/* 131 */     this.mPackageName = packageName.trim();
/* 132 */     this.mImports = importSpecs;
/* 133 */     this.mPopulator = null;
/* 134 */     setState(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JPackage getContainingPackage() {
/* 143 */     return getClassLoader().getPackage(this.mPackageName);
/*     */   }
/*     */   
/*     */   public JClass getSuperclass() {
/* 147 */     ensureLoaded();
/* 148 */     if (this.mSuperClassRef == null) {
/* 149 */       return null;
/*     */     }
/* 151 */     return this.mSuperClassRef.getRefClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public JClass[] getInterfaces() {
/* 156 */     ensureLoaded();
/* 157 */     if (this.mInterfaceRefs == null || this.mInterfaceRefs.size() == 0) {
/* 158 */       return new JClass[0];
/*     */     }
/* 160 */     JClass[] out = new JClass[this.mInterfaceRefs.size()];
/* 161 */     for (int i = 0; i < out.length; i++) {
/* 162 */       out[i] = ((JClassRef)this.mInterfaceRefs.get(i)).getRefClass();
/*     */     }
/* 164 */     return out;
/*     */   }
/*     */ 
/*     */   
/*     */   public JField[] getFields() {
/* 169 */     ensureLoaded();
/* 170 */     List list = new ArrayList();
/* 171 */     addFieldsRecursively((JClass)this, list);
/* 172 */     JField[] out = new JField[list.size()];
/* 173 */     list.toArray((Object[])out);
/* 174 */     return out;
/*     */   }
/*     */   
/*     */   public JField[] getDeclaredFields() {
/* 178 */     ensureLoaded();
/* 179 */     return (JField[])getMutableFields();
/*     */   }
/*     */   
/*     */   public JMethod[] getMethods() {
/* 183 */     ensureLoaded();
/* 184 */     List list = new ArrayList();
/* 185 */     addMethodsRecursively((JClass)this, list);
/* 186 */     JMethod[] out = new JMethod[list.size()];
/* 187 */     list.toArray((Object[])out);
/* 188 */     return out;
/*     */   }
/*     */   
/*     */   public JProperty[] getProperties() {
/* 192 */     ensureLoaded();
/* 193 */     if (this.mProperties == null) return new JProperty[0]; 
/* 194 */     JProperty[] out = new JProperty[this.mProperties.size()];
/* 195 */     this.mProperties.toArray((Object[])out);
/* 196 */     return out;
/*     */   }
/*     */   
/*     */   public JProperty[] getDeclaredProperties() {
/* 200 */     ensureLoaded();
/* 201 */     if (this.mDeclaredProperties == null) return new JProperty[0]; 
/* 202 */     JProperty[] out = new JProperty[this.mDeclaredProperties.size()];
/* 203 */     this.mDeclaredProperties.toArray((Object[])out);
/* 204 */     return out;
/*     */   }
/*     */   
/*     */   public JMethod[] getDeclaredMethods() {
/* 208 */     ensureLoaded();
/* 209 */     return (JMethod[])getMutableMethods();
/*     */   }
/*     */   
/*     */   public JConstructor[] getConstructors() {
/* 213 */     ensureLoaded();
/* 214 */     return (JConstructor[])getMutableConstructors();
/*     */   }
/*     */   
/*     */   public boolean isInterface() {
/* 218 */     ensureLoaded();
/* 219 */     return this.mIsInterface;
/*     */   }
/*     */   
/*     */   public boolean isAnnotationType() {
/* 223 */     ensureLoaded();
/* 224 */     return this.mIsAnnotationType;
/*     */   }
/*     */   
/*     */   public boolean isEnumType() {
/* 228 */     ensureLoaded();
/* 229 */     return this.mIsEnum;
/*     */   }
/*     */   
/*     */   public int getModifiers() {
/* 233 */     ensureLoaded();
/* 234 */     return super.getModifiers();
/*     */   }
/*     */   
/*     */   public boolean isFinal() {
/* 238 */     return Modifier.isFinal(getModifiers());
/*     */   } public boolean isStatic() {
/* 240 */     return Modifier.isStatic(getModifiers());
/*     */   } public boolean isAbstract() {
/* 242 */     return Modifier.isAbstract(getModifiers());
/*     */   }
/*     */   public boolean isAssignableFrom(JClass arg) {
/* 245 */     ensureLoaded();
/* 246 */     if (isPrimitiveType() || arg.isPrimitiveType()) {
/* 247 */       return getQualifiedName().equals(arg.getQualifiedName());
/*     */     }
/* 249 */     return isAssignableFromRecursively(arg);
/*     */   }
/*     */   
/*     */   public JClass[] getClasses() {
/* 253 */     ensureLoaded();
/* 254 */     if (this.mInnerClasses == null) return new JClass[0]; 
/* 255 */     JClass[] out = new JClass[this.mInnerClasses.size()];
/* 256 */     this.mInnerClasses.toArray((Object[])out);
/* 257 */     return out;
/*     */   }
/*     */   
/*     */   public String getFieldDescriptor() {
/* 261 */     return getQualifiedName();
/*     */   }
/*     */   
/*     */   public JClass forName(String name) {
/* 265 */     return getClassLoader().loadClass(name);
/*     */   }
/*     */   
/*     */   public JPackage[] getImportedPackages() {
/* 269 */     ensureLoaded();
/* 270 */     Set set = new TreeSet();
/* 271 */     JClass[] importedClasses = getImportedClasses();
/* 272 */     for (int i = 0; i < importedClasses.length; i++) {
/* 273 */       JPackage c = importedClasses[i].getContainingPackage();
/* 274 */       if (c != null) set.add(c); 
/*     */     } 
/* 276 */     String[] imports = getImportSpecs();
/* 277 */     if (imports != null) {
/* 278 */       for (int j = 0; j < imports.length; j++) {
/* 279 */         if (imports[j].endsWith(".*")) {
/* 280 */           set.add(getClassLoader().getPackage(imports[j].substring(0, imports[j].length() - 2)));
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 285 */     JPackage[] array = new JPackage[set.size()];
/* 286 */     set.toArray(array);
/* 287 */     return array;
/*     */   }
/*     */   
/*     */   public JClass[] getImportedClasses() {
/* 291 */     ensureLoaded();
/* 292 */     String[] imports = getImportSpecs();
/* 293 */     if (imports == null) return new JClass[0]; 
/* 294 */     List list = new ArrayList();
/* 295 */     for (int i = 0; i < imports.length; i++) {
/* 296 */       if (!imports[i].endsWith("*"))
/* 297 */         list.add(getClassLoader().loadClass(imports[i])); 
/*     */     } 
/* 299 */     JClass[] out = new JClass[list.size()];
/* 300 */     list.toArray(out);
/* 301 */     return out;
/*     */   }
/*     */   public void accept(MVisitor visitor) {
/* 304 */     visitor.visit(this);
/*     */   } public void accept(JVisitor visitor) {
/* 306 */     visitor.visit((JClass)this);
/*     */   }
/*     */   public void setSimpleName(String name) {
/* 309 */     throw new UnsupportedOperationException("Class names cannot be changed");
/*     */   }
/*     */   
/* 312 */   public Class getPrimitiveClass() { return null; }
/* 313 */   public boolean isPrimitiveType() { return false; }
/* 314 */   public boolean isBuiltinType() { return false; }
/* 315 */   public boolean isVoidType() { return false; } public boolean isUnresolvedType() {
/* 316 */     return false;
/*     */   } public boolean isObjectType() {
/* 318 */     return getQualifiedName().equals("java.lang.Object");
/*     */   }
/*     */   
/* 321 */   public boolean isArrayType() { return false; }
/* 322 */   public JClass getArrayComponentType() { return null; } public int getArrayDimensions() {
/* 323 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JAnnotation[] getAnnotations() {
/* 329 */     ensureLoaded();
/* 330 */     return super.getAnnotations();
/*     */   }
/*     */   
/*     */   public JAnnotation getAnnotation(Class proxyClass) {
/* 334 */     ensureLoaded();
/* 335 */     return super.getAnnotation(proxyClass);
/*     */   }
/*     */   
/*     */   public JAnnotation getAnnotation(String named) {
/* 339 */     ensureLoaded();
/* 340 */     return super.getAnnotation(named);
/*     */   }
/*     */   
/*     */   public JAnnotationValue getAnnotationValue(String valueId) {
/* 344 */     ensureLoaded();
/* 345 */     return super.getAnnotationValue(valueId);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAnnotationProxy(Class proxyClass) {
/* 350 */     ensureLoaded();
/* 351 */     return super.getAnnotationProxy(proxyClass);
/*     */   }
/*     */   
/*     */   public JComment getComment() {
/* 355 */     ensureLoaded();
/* 356 */     return super.getComment();
/*     */   }
/*     */   
/*     */   public JAnnotation[] getAllJavadocTags() {
/* 360 */     ensureLoaded();
/* 361 */     return super.getAllJavadocTags();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSourcePosition getSourcePosition() {
/* 368 */     ensureLoaded();
/* 369 */     return super.getSourcePosition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuperclass(String qualifiedClassName) {
/* 379 */     if (qualifiedClassName == null) {
/* 380 */       this.mSuperClassRef = null;
/*     */     } else {
/* 382 */       if (qualifiedClassName.equals(getQualifiedName())) {
/* 383 */         throw new IllegalArgumentException("A class cannot be it's own superclass: '" + qualifiedClassName + "'");
/*     */       }
/*     */       
/* 386 */       this.mSuperClassRef = QualifiedJClassRef.create(qualifiedClassName, this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setSuperclassUnqualified(String unqualifiedClassName) {
/* 391 */     this.mSuperClassRef = UnqualifiedJClassRef.create(unqualifiedClassName, this);
/*     */   }
/*     */   
/*     */   public void setSuperclass(JClass clazz) {
/* 395 */     if (clazz == null) {
/* 396 */       this.mSuperClassRef = null;
/*     */     } else {
/* 398 */       setSuperclass(clazz.getQualifiedName());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addInterface(JClass interf) {
/* 403 */     if (interf == null) throw new IllegalArgumentException("null interf");
/*     */     
/* 405 */     addInterface(interf.getQualifiedName());
/*     */   }
/*     */   
/*     */   public void addInterface(String qcName) {
/* 409 */     if (this.mInterfaceRefs == null) this.mInterfaceRefs = new ArrayList(); 
/* 410 */     if (qcName.equals(getQualifiedName())) {
/* 411 */       throw new IllegalArgumentException("A class cannot implement itself: '" + qcName + "'");
/*     */     }
/*     */     
/* 414 */     this.mInterfaceRefs.add(QualifiedJClassRef.create(qcName, this));
/*     */   }
/*     */   
/*     */   public void addInterfaceUnqualified(String ucname) {
/* 418 */     if (this.mInterfaceRefs == null) this.mInterfaceRefs = new ArrayList(); 
/* 419 */     this.mInterfaceRefs.add(UnqualifiedJClassRef.create(ucname, this));
/*     */   }
/*     */   
/*     */   public void removeInterface(JClass interf) {
/* 423 */     if (interf == null) throw new IllegalArgumentException("null interf"); 
/* 424 */     removeInterface(interf.getQualifiedName());
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeInterface(String qcname) {
/* 429 */     if (qcname == null) throw new IllegalArgumentException("null classname"); 
/* 430 */     if (this.mInterfaceRefs == null)
/* 431 */       return;  for (int i = 0; i < this.mInterfaceRefs.size(); i++) {
/* 432 */       if (qcname.equals(((JClassRef)this.mInterfaceRefs.get(i)).getQualifiedName()))
/*     */       {
/* 434 */         this.mInterfaceRefs.remove(i);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public MConstructor addNewConstructor() {
/* 440 */     if (this.mConstructors == null) this.mConstructors = new ArrayList(); 
/* 441 */     MConstructor out = new ConstructorImpl(this);
/* 442 */     this.mConstructors.add(out);
/* 443 */     return out;
/*     */   }
/*     */   
/*     */   public void removeConstructor(MConstructor constr) {
/* 447 */     if (this.mConstructors == null)
/* 448 */       return;  this.mConstructors.remove(constr);
/*     */   }
/*     */   
/*     */   public MConstructor[] getMutableConstructors() {
/* 452 */     if (this.mConstructors == null || this.mConstructors.size() == 0) {
/* 453 */       return new MConstructor[0];
/*     */     }
/* 455 */     MConstructor[] out = new MConstructor[this.mConstructors.size()];
/* 456 */     this.mConstructors.toArray((Object[])out);
/* 457 */     return out;
/*     */   }
/*     */   
/*     */   public MField addNewField() {
/* 461 */     if (this.mFields == null) this.mFields = new ArrayList(); 
/* 462 */     MField out = new FieldImpl(defaultName(this.mFields.size()), this, "java.lang.Object");
/*     */     
/* 464 */     this.mFields.add(out);
/* 465 */     return out;
/*     */   }
/*     */   
/*     */   public void removeField(MField field) {
/* 469 */     if (this.mFields == null)
/* 470 */       return;  this.mFields.remove(field);
/*     */   }
/*     */   
/*     */   public MField[] getMutableFields() {
/* 474 */     if (this.mFields == null || this.mFields.size() == 0) {
/* 475 */       return new MField[0];
/*     */     }
/* 477 */     MField[] out = new MField[this.mFields.size()];
/* 478 */     this.mFields.toArray((Object[])out);
/* 479 */     return out;
/*     */   }
/*     */   
/*     */   public MMethod addNewMethod() {
/* 483 */     if (this.mMethods == null) this.mMethods = new ArrayList(); 
/* 484 */     MMethod out = new MethodImpl(defaultName(this.mMethods.size()), this);
/* 485 */     this.mMethods.add(out);
/* 486 */     return out;
/*     */   }
/*     */   
/*     */   public void removeMethod(MMethod method) {
/* 490 */     if (this.mMethods == null)
/* 491 */       return;  this.mMethods.remove(method);
/*     */   }
/*     */   
/*     */   public MMethod[] getMutableMethods() {
/* 495 */     if (this.mMethods == null || this.mMethods.size() == 0) {
/* 496 */       return new MMethod[0];
/*     */     }
/* 498 */     MMethod[] out = new MMethod[this.mMethods.size()];
/* 499 */     this.mMethods.toArray((Object[])out);
/* 500 */     return out;
/*     */   }
/*     */   
/*     */   public JProperty addNewProperty(String name, JMethod getter, JMethod setter) {
/* 504 */     if (this.mProperties == null) this.mProperties = new ArrayList(); 
/* 505 */     String typeName = (getter != null) ? getter.getReturnType().getFieldDescriptor() : setter.getParameters()[0].getType().getFieldDescriptor();
/*     */ 
/*     */     
/* 508 */     JProperty out = new PropertyImpl(name, getter, setter, typeName);
/* 509 */     this.mProperties.add(out);
/* 510 */     return out;
/*     */   }
/*     */   
/*     */   public void removeProperty(JProperty p) {
/* 514 */     if (this.mProperties != null) this.mProperties.remove(p); 
/*     */   }
/*     */   
/*     */   public JProperty addNewDeclaredProperty(String name, JMethod getter, JMethod setter) {
/* 518 */     if (this.mDeclaredProperties == null) this.mDeclaredProperties = new ArrayList(); 
/* 519 */     String typeName = (getter != null) ? getter.getReturnType().getFieldDescriptor() : setter.getParameters()[0].getType().getFieldDescriptor();
/*     */ 
/*     */     
/* 522 */     JProperty out = new PropertyImpl(name, getter, setter, typeName);
/* 523 */     this.mDeclaredProperties.add(out);
/* 524 */     return out;
/*     */   }
/*     */   
/*     */   public void removeDeclaredProperty(JProperty p) {
/* 528 */     if (this.mDeclaredProperties != null) this.mDeclaredProperties.remove(p);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MClass addNewInnerClass(String name) {
/* 535 */     int lastDot = name.lastIndexOf('.');
/* 536 */     if (lastDot == -1) lastDot = name.lastIndexOf('$'); 
/* 537 */     if (lastDot != -1) name = name.substring(lastDot + 1); 
/* 538 */     ClassImpl inner = new ClassImpl(this.mPackageName, getSimpleName() + "$" + name, getImportSpecs(), this);
/*     */ 
/*     */ 
/*     */     
/* 542 */     if (this.mInnerClasses == null) this.mInnerClasses = new ArrayList(); 
/* 543 */     this.mInnerClasses.add(inner);
/* 544 */     inner.setState(6);
/* 545 */     ((JamClassLoaderImpl)getClassLoader()).addToCache((JClass)inner);
/* 546 */     return inner;
/*     */   }
/*     */   
/*     */   public void removeInnerClass(MClass clazz) {
/* 550 */     if (this.mInnerClasses == null)
/* 551 */       return;  this.mInnerClasses.remove(clazz);
/*     */   }
/*     */   public void setIsInterface(boolean b) {
/* 554 */     this.mIsInterface = b;
/*     */   } public void setIsAnnotationType(boolean b) {
/* 556 */     this.mIsAnnotationType = b;
/*     */   } public void setIsEnumType(boolean b) {
/* 558 */     this.mIsEnum = b;
/*     */   }
/*     */   public String getQualifiedName() {
/* 561 */     return ((this.mPackageName.length() > 0) ? (this.mPackageName + '.') : "") + this.mSimpleName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JClass getRefClass() {
/* 568 */     return (JClass)this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPackageName() {
/* 574 */     return this.mPackageName;
/*     */   }
/*     */   
/*     */   public String[] getImportSpecs() {
/* 578 */     ensureLoaded();
/* 579 */     if (this.mImports == null) return new String[0]; 
/* 580 */     return this.mImports;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setState(int state) {
/* 587 */     this.mState = state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateClassName(String className) throws IllegalArgumentException {
/* 600 */     if (className == null) {
/* 601 */       throw new IllegalArgumentException("null class name specified");
/*     */     }
/* 603 */     if (!Character.isJavaIdentifierStart(className.charAt(0))) {
/* 604 */       throw new IllegalArgumentException("Invalid first character in class name: " + className);
/*     */     }
/*     */     
/* 607 */     for (int i = 1; i < className.length(); i++) {
/* 608 */       char c = className.charAt(i);
/* 609 */       if (c == '.') {
/* 610 */         if (className.charAt(i - 1) == '.') {
/* 611 */           throw new IllegalArgumentException("'..' not allowed in class name: " + className);
/*     */         }
/*     */         
/* 614 */         if (i == className.length() - 1) {
/* 615 */           throw new IllegalArgumentException("'.' not allowed at end of class name: " + className);
/*     */         
/*     */         }
/*     */       }
/* 619 */       else if (!Character.isJavaIdentifierPart(c)) {
/* 620 */         throw new IllegalArgumentException("Illegal character '" + c + "' in class name: " + className);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAssignableFromRecursively(JClass arg) {
/* 631 */     if (getQualifiedName().equals(arg.getQualifiedName())) return true;
/*     */     
/* 633 */     JClass[] interfaces = arg.getInterfaces();
/* 634 */     if (interfaces != null) {
/* 635 */       for (int i = 0; i < interfaces.length; i++) {
/* 636 */         if (isAssignableFromRecursively(interfaces[i])) return true;
/*     */       
/*     */       } 
/*     */     }
/* 640 */     arg = arg.getSuperclass();
/* 641 */     if (arg != null && 
/* 642 */       isAssignableFromRecursively(arg)) return true;
/*     */     
/* 644 */     return false;
/*     */   }
/*     */   
/*     */   private void addFieldsRecursively(JClass clazz, Collection out) {
/* 648 */     JField[] fields = clazz.getDeclaredFields();
/* 649 */     for (int i = 0; i < fields.length; ) { out.add(fields[i]); i++; }
/* 650 */      JClass[] ints = clazz.getInterfaces();
/* 651 */     for (int j = 0; j < ints.length; j++) {
/* 652 */       addFieldsRecursively(ints[j], out);
/*     */     }
/* 654 */     clazz = clazz.getSuperclass();
/* 655 */     if (clazz != null) addFieldsRecursively(clazz, out); 
/*     */   }
/*     */   
/*     */   private void addMethodsRecursively(JClass clazz, Collection out) {
/* 659 */     JMethod[] methods = clazz.getDeclaredMethods();
/* 660 */     for (int i = 0; i < methods.length; ) { out.add(methods[i]); i++; }
/* 661 */      JClass[] ints = clazz.getInterfaces();
/* 662 */     for (int j = 0; j < ints.length; j++) {
/* 663 */       addMethodsRecursively(ints[j], out);
/*     */     }
/* 665 */     clazz = clazz.getSuperclass();
/* 666 */     if (clazz != null) addMethodsRecursively(clazz, out); 
/*     */   }
/*     */   
/*     */   public void ensureLoaded() {
/* 670 */     if (this.mState == 6)
/* 671 */       return;  if (this.mState == 2) {
/* 672 */       if (this.mPopulator == null) throw new IllegalStateException("null populator"); 
/* 673 */       setState(3);
/* 674 */       this.mPopulator.populate(this);
/* 675 */       setState(4);
/*     */     } 
/* 677 */     if (this.mState == 4) {
/* 678 */       setState(5);
/* 679 */       ((JamClassLoaderImpl)getClassLoader()).initialize(this);
/*     */     } 
/* 681 */     setState(6);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\ClassImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */