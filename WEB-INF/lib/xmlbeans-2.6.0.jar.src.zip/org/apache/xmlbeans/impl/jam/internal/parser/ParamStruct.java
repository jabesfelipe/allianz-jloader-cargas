/*    */ package org.apache.xmlbeans.impl.jam.internal.parser;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MInvokable;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ParamStruct
/*    */ {
/*    */   private String mName;
/*    */   private String mType;
/*    */   
/*    */   public ParamStruct(String type, String name) {
/* 36 */     init(type, name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void init(String type, String name) {
/* 43 */     this.mType = type;
/* 44 */     this.mName = name;
/*    */   }
/*    */   
/*    */   public MParameter createParameter(MInvokable e) {
/* 48 */     if (e == null) throw new IllegalArgumentException("null invokable"); 
/* 49 */     MParameter param = e.addNewParameter();
/* 50 */     param.setSimpleName(this.mName);
/* 51 */     param.setUnqualifiedType(this.mType);
/* 52 */     return param;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\parser\ParamStruct.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */