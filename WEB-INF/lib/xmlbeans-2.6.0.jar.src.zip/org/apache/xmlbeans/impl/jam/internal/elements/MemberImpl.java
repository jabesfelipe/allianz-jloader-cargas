/*    */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*    */ 
/*    */ import java.lang.reflect.Modifier;
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ import org.apache.xmlbeans.impl.jam.JElement;
/*    */ import org.apache.xmlbeans.impl.jam.JMember;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MMember;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MemberImpl
/*    */   extends AnnotatedElementImpl
/*    */   implements MMember
/*    */ {
/* 35 */   private int mModifiers = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MemberImpl(ElementImpl parent) {
/* 41 */     super(parent);
/*    */   }
/*    */   
/*    */   protected MemberImpl(ElementContext ctx) {
/* 45 */     super(ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JClass getContainingClass() {
/* 52 */     JElement p = getParent();
/*    */     
/* 54 */     if (p instanceof JClass) return (JClass)p; 
/* 55 */     if (p instanceof JMember) return ((JMember)p).getContainingClass(); 
/* 56 */     return null;
/*    */   }
/*    */   public int getModifiers() {
/* 59 */     return this.mModifiers;
/*    */   }
/*    */   public boolean isPackagePrivate() {
/* 62 */     return (!isPrivate() && !isPublic() && !isProtected());
/*    */   }
/*    */   public boolean isPrivate() {
/* 65 */     return Modifier.isPrivate(getModifiers());
/*    */   } public boolean isProtected() {
/* 67 */     return Modifier.isProtected(getModifiers());
/*    */   } public boolean isPublic() {
/* 69 */     return Modifier.isPublic(getModifiers());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setModifiers(int modifiers) {
/* 74 */     this.mModifiers = modifiers;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\MemberImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */