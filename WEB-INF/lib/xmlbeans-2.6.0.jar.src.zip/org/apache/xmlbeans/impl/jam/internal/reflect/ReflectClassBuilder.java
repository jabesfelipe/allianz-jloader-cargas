/*     */ package org.apache.xmlbeans.impl.jam.internal.reflect;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MInvokable;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MMember;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MMethod;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassBuilder;
/*     */ import org.apache.xmlbeans.impl.jam.provider.JamClassPopulator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectClassBuilder
/*     */   extends JamClassBuilder
/*     */   implements JamClassPopulator
/*     */ {
/*     */   private ClassLoader mLoader;
/*  41 */   private ReflectTigerDelegate mTigerDelegate = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReflectClassBuilder(ClassLoader rcl) {
/*  47 */     if (rcl == null) throw new IllegalArgumentException("null rcl"); 
/*  48 */     this.mLoader = rcl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(ElementContext ctx) {
/*  55 */     super.init(ctx);
/*  56 */     initDelegate(ctx);
/*     */   }
/*     */   public MClass build(String packageName, String className) {
/*     */     Class rclass;
/*  60 */     assertInitialized();
/*  61 */     if (getLogger().isVerbose(this)) {
/*  62 */       getLogger().verbose("trying to build '" + packageName + "' '" + className + "'");
/*     */     }
/*     */     
/*     */     try {
/*  66 */       String loadme = (packageName.trim().length() > 0) ? (packageName + '.' + className) : className;
/*     */ 
/*     */       
/*  69 */       rclass = this.mLoader.loadClass(loadme);
/*  70 */     } catch (ClassNotFoundException cnfe) {
/*  71 */       getLogger().verbose(cnfe, this);
/*  72 */       return null;
/*     */     } 
/*  74 */     MClass out = createClassToBuild(packageName, className, null, this);
/*  75 */     out.setArtifact(rclass);
/*  76 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populate(MClass dest) {
/*  83 */     assertInitialized();
/*  84 */     Class src = (Class)dest.getArtifact();
/*  85 */     dest.setModifiers(src.getModifiers());
/*  86 */     dest.setIsInterface(src.isInterface());
/*  87 */     if (this.mTigerDelegate != null) dest.setIsEnumType(this.mTigerDelegate.isEnum(src));
/*     */     
/*  89 */     Class s = src.getSuperclass();
/*  90 */     if (s != null) dest.setSuperclass(s.getName());
/*     */     
/*  92 */     Class[] ints = src.getInterfaces();
/*  93 */     for (int i = 0; i < ints.length; ) { dest.addInterface(ints[i].getName()); i++; }
/*     */     
/*  95 */     Field[] fields = null;
/*     */     try {
/*  97 */       fields = src.getFields();
/*  98 */     } catch (Exception ignore) {}
/*     */ 
/*     */     
/* 101 */     if (fields != null) {
/* 102 */       for (int m = 0; m < fields.length; ) { populate(dest.addNewField(), fields[m]); m++; }
/*     */     
/*     */     }
/* 105 */     Method[] methods = src.getDeclaredMethods();
/* 106 */     for (int j = 0; j < methods.length; ) { populate(dest.addNewMethod(), methods[j]); j++; }
/*     */     
/* 108 */     if (this.mTigerDelegate != null) this.mTigerDelegate.populateAnnotationTypeIfNecessary(src, dest, this);
/*     */ 
/*     */     
/* 111 */     Constructor[] ctors = (Constructor[])src.getDeclaredConstructors();
/* 112 */     for (int k = 0; k < ctors.length; ) { populate(dest.addNewConstructor(), ctors[k]); k++; }
/*     */     
/* 114 */     if (this.mTigerDelegate != null) this.mTigerDelegate.extractAnnotations(dest, src);
/*     */ 
/*     */ 
/*     */     
/* 118 */     Class[] inners = src.getDeclaredClasses();
/* 119 */     if (inners != null) {
/* 120 */       for (int m = 0; m < inners.length; m++) {
/* 121 */         if (this.mTigerDelegate != null)
/*     */         {
/* 123 */           if (this.mTigerDelegate.getEnclosingConstructor(inners[m]) != null || this.mTigerDelegate.getEnclosingMethod(inners[m]) != null)
/*     */             continue; 
/*     */         }
/* 126 */         String simpleName = inners[m].getName();
/* 127 */         int lastDollar = simpleName.lastIndexOf('$');
/* 128 */         simpleName = simpleName.substring(lastDollar + 1);
/*     */         
/* 130 */         char first = simpleName.charAt(0);
/* 131 */         if ('0' > first || first > '9') {
/*     */ 
/*     */ 
/*     */           
/* 135 */           MClass inner = dest.addNewInnerClass(simpleName);
/* 136 */           inner.setArtifact(inners[m]);
/* 137 */           populate(inner);
/*     */         } 
/*     */         continue;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initDelegate(ElementContext ctx) {
/* 148 */     this.mTigerDelegate = ReflectTigerDelegate.create(ctx);
/*     */   }
/*     */   
/*     */   private void populate(MField dest, Field src) {
/* 152 */     dest.setArtifact(src);
/* 153 */     dest.setSimpleName(src.getName());
/* 154 */     dest.setType(src.getType().getName());
/* 155 */     dest.setModifiers(src.getModifiers());
/* 156 */     if (this.mTigerDelegate != null) this.mTigerDelegate.extractAnnotations(dest, src); 
/*     */   }
/*     */   
/*     */   private void populate(MConstructor dest, Constructor src) {
/* 160 */     dest.setArtifact(src);
/* 161 */     dest.setSimpleName(src.getName());
/* 162 */     dest.setModifiers(src.getModifiers());
/* 163 */     Class[] exceptions = src.getExceptionTypes();
/* 164 */     addThrows((MInvokable)dest, exceptions);
/* 165 */     Class[] paramTypes = src.getParameterTypes();
/* 166 */     for (int i = 0; i < paramTypes.length; i++) {
/* 167 */       MParameter p = addParameter((MInvokable)dest, i, paramTypes[i]);
/* 168 */       if (this.mTigerDelegate != null) this.mTigerDelegate.extractAnnotations(p, src, i); 
/*     */     } 
/* 170 */     if (this.mTigerDelegate != null) this.mTigerDelegate.extractAnnotations(dest, src); 
/*     */   }
/*     */   
/*     */   private void populate(MMethod dest, Method src) {
/* 174 */     dest.setArtifact(src);
/* 175 */     dest.setSimpleName(src.getName());
/* 176 */     dest.setModifiers(src.getModifiers());
/* 177 */     dest.setReturnType(src.getReturnType().getName());
/* 178 */     Class[] exceptions = src.getExceptionTypes();
/* 179 */     addThrows((MInvokable)dest, exceptions);
/* 180 */     Class[] paramTypes = src.getParameterTypes();
/* 181 */     for (int i = 0; i < paramTypes.length; i++) {
/* 182 */       MParameter p = addParameter((MInvokable)dest, i, paramTypes[i]);
/* 183 */       if (this.mTigerDelegate != null) this.mTigerDelegate.extractAnnotations(p, src, i); 
/*     */     } 
/* 185 */     if (this.mTigerDelegate != null) this.mTigerDelegate.extractAnnotations((MMember)dest, src); 
/*     */   }
/*     */   
/*     */   private void addThrows(MInvokable dest, Class[] exceptionTypes) {
/* 189 */     for (int i = 0; i < exceptionTypes.length; i++) {
/* 190 */       dest.addException(exceptionTypes[i].getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MParameter addParameter(MInvokable dest, int paramNum, Class paramType) {
/* 198 */     MParameter p = dest.addNewParameter();
/* 199 */     p.setSimpleName("param" + paramNum);
/* 200 */     p.setType(paramType.getName());
/* 201 */     return p;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\reflect\ReflectClassBuilder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */