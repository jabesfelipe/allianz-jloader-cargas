/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.JConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.JField;
/*     */ import org.apache.xmlbeans.impl.jam.JMethod;
/*     */ import org.apache.xmlbeans.impl.jam.JPackage;
/*     */ import org.apache.xmlbeans.impl.jam.JProperty;
/*     */ import org.apache.xmlbeans.impl.jam.JSourcePosition;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MMethod;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.JVisitor;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BuiltinClassImpl
/*     */   extends AnnotatedElementImpl
/*     */   implements MClass
/*     */ {
/*     */   protected BuiltinClassImpl(ElementContext ctx) {
/*  53 */     super(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(MVisitor visitor) {
/*  59 */     visitor.visit(this);
/*     */   } public void accept(JVisitor visitor) {
/*  61 */     visitor.visit((JClass)this);
/*     */   } public String getQualifiedName() {
/*  63 */     return this.mSimpleName;
/*     */   } public String getFieldDescriptor() {
/*  65 */     return this.mSimpleName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/*  70 */     return Object.class.getModifiers(); }
/*  71 */   public boolean isPublic() { return true; }
/*  72 */   public boolean isPackagePrivate() { return false; }
/*  73 */   public boolean isProtected() { return false; }
/*  74 */   public boolean isPrivate() { return false; }
/*  75 */   public JSourcePosition getSourcePosition() { return null; } public JClass getContainingClass() {
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JClass forName(String fd) {
/*  82 */     return getClassLoader().loadClass(fd);
/*     */   }
/*     */   
/*  85 */   public JClass getArrayComponentType() { return null; } public int getArrayDimensions() {
/*  86 */     return 0;
/*     */   }
/*  88 */   public JClass getSuperclass() { return null; }
/*  89 */   public JClass[] getInterfaces() { return (JClass[])NO_CLASS; }
/*  90 */   public JField[] getFields() { return (JField[])NO_FIELD; }
/*  91 */   public JField[] getDeclaredFields() { return (JField[])NO_FIELD; }
/*  92 */   public JConstructor[] getConstructors() { return (JConstructor[])NO_CONSTRUCTOR; }
/*  93 */   public JMethod[] getMethods() { return (JMethod[])NO_METHOD; }
/*  94 */   public JMethod[] getDeclaredMethods() { return (JMethod[])NO_METHOD; }
/*  95 */   public JPackage getContainingPackage() { return null; } public boolean isInterface() {
/*  96 */     return false;
/*     */   }
/*  98 */   public boolean isArrayType() { return false; }
/*  99 */   public boolean isAnnotationType() { return false; }
/* 100 */   public boolean isPrimitiveType() { return false; }
/* 101 */   public boolean isBuiltinType() { return true; }
/* 102 */   public boolean isUnresolvedType() { return false; }
/* 103 */   public boolean isObjectType() { return false; }
/* 104 */   public boolean isVoidType() { return false; }
/* 105 */   public boolean isEnumType() { return false; }
/* 106 */   public Class getPrimitiveClass() { return null; }
/* 107 */   public boolean isAbstract() { return false; }
/* 108 */   public boolean isFinal() { return false; }
/* 109 */   public boolean isStatic() { return false; }
/* 110 */   public JClass[] getClasses() { return (JClass[])NO_CLASS; }
/* 111 */   public JProperty[] getProperties() { return NO_PROPERTY; }
/* 112 */   public JProperty[] getDeclaredProperties() { return NO_PROPERTY; }
/* 113 */   public JPackage[] getImportedPackages() { return NO_PACKAGE; } public JClass[] getImportedClasses() {
/* 114 */     return (JClass[])NO_CLASS;
/*     */   }
/*     */ 
/*     */   
/*     */   public MField[] getMutableFields() {
/* 119 */     return (MField[])NO_FIELD; }
/* 120 */   public MConstructor[] getMutableConstructors() { return (MConstructor[])NO_CONSTRUCTOR; } public MMethod[] getMutableMethods() {
/* 121 */     return (MMethod[])NO_METHOD;
/*     */   }
/*     */   
/*     */   public void setSimpleName(String s) {
/* 125 */     nocando();
/*     */   }
/* 127 */   public void setIsAnnotationType(boolean b) { nocando(); }
/* 128 */   public void setIsInterface(boolean b) { nocando(); }
/* 129 */   public void setIsUnresolvedType(boolean b) { nocando(); }
/* 130 */   public void setIsEnumType(boolean b) { nocando(); }
/* 131 */   public void setSuperclass(String qualifiedClassName) { nocando(); }
/* 132 */   public void setSuperclassUnqualified(String unqualifiedClassName) { nocando(); }
/* 133 */   public void setSuperclass(JClass clazz) { nocando(); }
/* 134 */   public void addInterface(String className) { nocando(); }
/* 135 */   public void addInterfaceUnqualified(String unqualifiedClassName) { nocando(); }
/* 136 */   public void addInterface(JClass interf) { nocando(); }
/* 137 */   public void removeInterface(String className) { nocando(); }
/* 138 */   public void removeInterface(JClass interf) { nocando(); }
/* 139 */   public MConstructor addNewConstructor() { nocando(); return null; }
/* 140 */   public void removeConstructor(MConstructor constr) { nocando(); }
/* 141 */   public MField addNewField() { nocando(); return null; }
/* 142 */   public void removeField(MField field) { nocando(); }
/* 143 */   public MMethod addNewMethod() { nocando(); return null; }
/* 144 */   public void removeMethod(MMethod method) { nocando(); }
/* 145 */   public void setModifiers(int modifiers) { nocando(); }
/* 146 */   public MClass addNewInnerClass(String named) { nocando(); return null; } public void removeInnerClass(MClass inner) {
/* 147 */     nocando();
/*     */   }
/*     */   public JProperty addNewProperty(String name, JMethod m, JMethod x) {
/* 150 */     nocando();
/* 151 */     return null;
/*     */   } public void removeProperty(JProperty prop) {
/* 153 */     nocando();
/*     */   }
/*     */   public JProperty addNewDeclaredProperty(String name, JMethod m, JMethod x) {
/* 156 */     nocando();
/* 157 */     return null;
/*     */   } public void removeDeclaredProperty(JProperty prop) {
/* 159 */     nocando();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 165 */     if (o instanceof JClass) {
/* 166 */       return ((JClass)o).getFieldDescriptor().equals(getFieldDescriptor());
/*     */     }
/* 168 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 172 */     return getFieldDescriptor().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reallySetSimpleName(String name) {
/* 178 */     super.setSimpleName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void nocando() {
/* 185 */     throw new UnsupportedOperationException("Cannot alter builtin types");
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\BuiltinClassImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */