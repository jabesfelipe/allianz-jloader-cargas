/*     */ package org.apache.xmlbeans.impl.jam.provider;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringWriter;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourcePath
/*     */ {
/*     */   private File[] mFiles;
/*     */   
/*     */   public static ResourcePath forFiles(File[] files) {
/*  38 */     return new ResourcePath(files);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourcePath(File[] files) {
/*  55 */     if (files == null) throw new IllegalArgumentException("null files"); 
/*  56 */     this.mFiles = files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI[] toUriPath() {
/*  63 */     URI[] out = new URI[this.mFiles.length];
/*  64 */     for (int i = 0; i < this.mFiles.length; i++) {
/*  65 */       out[i] = this.mFiles[i].toURI();
/*     */     }
/*  67 */     return out;
/*     */   }
/*     */   
/*     */   public URL[] toUrlPath() throws MalformedURLException {
/*  71 */     URL[] out = new URL[this.mFiles.length];
/*  72 */     for (int i = 0; i < this.mFiles.length; i++) {
/*  73 */       out[i] = this.mFiles[i].toURL();
/*     */     }
/*  75 */     return out;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream findInPath(String resource) {
/*  80 */     for (int i = 0; i < this.mFiles.length; i++) {
/*  81 */       File f = new File(this.mFiles[i], resource);
/*     */       try {
/*  83 */         if (f.exists()) return new FileInputStream(f); 
/*  84 */       } catch (FileNotFoundException weird) {
/*  85 */         weird.printStackTrace();
/*     */       } 
/*     */     } 
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     StringWriter out = new StringWriter();
/* 100 */     for (int i = 0; i < this.mFiles.length; i++) {
/* 101 */       out.write(this.mFiles[i].getAbsolutePath());
/* 102 */       out.write(File.pathSeparatorChar);
/*     */     } 
/* 104 */     return out.toString();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\provider\ResourcePath.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */