/*    */ package org.apache.xmlbeans.impl.jam.internal.parser;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MInvokable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParamStructPool
/*    */ {
/*    */   private static final boolean VERBOSE = true;
/* 39 */   private List mList = new ArrayList();
/* 40 */   private int mLength = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setParametersOn(MInvokable e) {
/* 46 */     for (int i = 0; i < this.mLength; i++) {
/* 47 */       ParamStruct struct = this.mList.get(i);
/* 48 */       struct.createParameter(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void add(String type, String name) {
/* 53 */     this.mLength++;
/* 54 */     if (this.mLength >= this.mList.size()) {
/* 55 */       this.mList.add(new ParamStruct(type, name));
/*    */     } else {
/* 57 */       ((ParamStruct)this.mList.get(this.mLength)).init(type, name);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void clear() {
/* 62 */     this.mLength = 0;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\parser\ParamStructPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */