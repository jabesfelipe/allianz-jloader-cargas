/*     */ package org.apache.xmlbeans.impl.jam.visitor;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotatedElement;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MComment;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MConstructor;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MField;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MInvokable;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MMethod;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MPackage;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TraversingMVisitor
/*     */   extends MVisitor
/*     */ {
/*     */   private MVisitor mDelegate;
/*     */   
/*     */   public TraversingMVisitor(MVisitor jv) {
/*  62 */     if (jv == null) throw new IllegalArgumentException("null jv"); 
/*  63 */     this.mDelegate = jv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(MPackage pkg) {
/*  70 */     pkg.accept(this.mDelegate);
/*  71 */     MClass[] c = pkg.getMutableClasses();
/*  72 */     for (int i = 0; i < c.length; ) { visit(c[i]); i++; }
/*  73 */      visitAnnotations((MAnnotatedElement)pkg);
/*  74 */     visitComment((MAnnotatedElement)pkg);
/*     */   }
/*     */   
/*     */   public void visit(MClass clazz) {
/*  78 */     clazz.accept(this.mDelegate);
/*     */     
/*  80 */     MField[] f = clazz.getMutableFields(); int i;
/*  81 */     for (i = 0; i < f.length; ) { visit(f[i]); i++; }
/*     */     
/*  83 */     MConstructor[] c = clazz.getMutableConstructors();
/*  84 */     for (i = 0; i < c.length; ) { visit(c[i]); i++; }
/*     */     
/*  86 */     MMethod[] m = clazz.getMutableMethods();
/*  87 */     for (i = 0; i < m.length; ) { visit(m[i]); i++; }
/*     */     
/*  89 */     visitAnnotations((MAnnotatedElement)clazz);
/*  90 */     visitComment((MAnnotatedElement)clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(MField field) {
/*  97 */     field.accept(this.mDelegate);
/*  98 */     visitAnnotations((MAnnotatedElement)field);
/*  99 */     visitComment((MAnnotatedElement)field);
/*     */   }
/*     */   
/*     */   public void visit(MConstructor ctor) {
/* 103 */     ctor.accept(this.mDelegate);
/* 104 */     visitParameters((MInvokable)ctor);
/* 105 */     visitAnnotations((MAnnotatedElement)ctor);
/* 106 */     visitComment((MAnnotatedElement)ctor);
/*     */   }
/*     */   
/*     */   public void visit(MMethod method) {
/* 110 */     method.accept(this.mDelegate);
/* 111 */     visitParameters((MInvokable)method);
/* 112 */     visitAnnotations((MAnnotatedElement)method);
/* 113 */     visitComment((MAnnotatedElement)method);
/*     */   }
/*     */   
/*     */   public void visit(MParameter param) {
/* 117 */     param.accept(this.mDelegate);
/* 118 */     visitAnnotations((MAnnotatedElement)param);
/* 119 */     visitComment((MAnnotatedElement)param);
/*     */   }
/*     */   public void visit(MAnnotation ann) {
/* 122 */     ann.accept(this.mDelegate);
/*     */   } public void visit(MComment comment) {
/* 124 */     comment.accept(this.mDelegate);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void visitParameters(MInvokable iv) {
/* 130 */     MParameter[] p = iv.getMutableParameters();
/* 131 */     for (int i = 0; i < p.length; ) { visit(p[i]); i++; }
/*     */   
/*     */   }
/*     */   private void visitAnnotations(MAnnotatedElement ae) {
/* 135 */     MAnnotation[] anns = ae.getMutableAnnotations();
/* 136 */     for (int i = 0; i < anns.length; ) { visit(anns[i]); i++; }
/*     */   
/*     */   }
/*     */   private void visitComment(MAnnotatedElement e) {
/* 140 */     MComment c = e.getMutableComment();
/* 141 */     if (c != null) visit(c); 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\visitor\TraversingMVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */