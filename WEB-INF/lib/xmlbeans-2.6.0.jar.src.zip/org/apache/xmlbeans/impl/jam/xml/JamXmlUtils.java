/*    */ package org.apache.xmlbeans.impl.jam.xml;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Writer;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ import org.apache.xmlbeans.impl.jam.JamService;
/*    */ import org.apache.xmlbeans.impl.jam.JamServiceFactory;
/*    */ import org.apache.xmlbeans.impl.jam.JamServiceParams;
/*    */ import org.apache.xmlbeans.impl.jam.internal.CachedClassBuilder;
/*    */ import org.apache.xmlbeans.impl.jam.internal.JamServiceImpl;
/*    */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*    */ import org.apache.xmlbeans.impl.jam.provider.JamClassBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JamXmlUtils
/*    */ {
/*    */   public static final JamXmlUtils getInstance() {
/* 40 */     return INSTANCE;
/*    */   }
/* 42 */   private static final JamXmlUtils INSTANCE = new JamXmlUtils();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JamService createService(InputStream in) throws IOException, XMLStreamException {
/* 52 */     if (in == null) throw new IllegalArgumentException("null stream"); 
/* 53 */     JamServiceFactory jsf = JamServiceFactory.getInstance();
/* 54 */     JamServiceParams params = jsf.createServiceParams();
/* 55 */     CachedClassBuilder cache = new CachedClassBuilder();
/*    */     
/* 57 */     params.addClassBuilder((JamClassBuilder)cache);
/* 58 */     JamService out = jsf.createService(params);
/*    */ 
/*    */     
/* 61 */     JamXmlReader reader = new JamXmlReader(cache, in, (ElementContext)params);
/* 62 */     reader.read();
/*    */ 
/*    */     
/* 65 */     List classNames = Arrays.asList(cache.getClassNames());
/* 66 */     classNames.addAll(Arrays.asList(out.getClassNames()));
/* 67 */     String[] nameArray = new String[classNames.size()];
/* 68 */     classNames.toArray(nameArray);
/* 69 */     ((JamServiceImpl)out).setClassNames(nameArray);
/*    */     
/* 71 */     return out;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toXml(JClass[] clazzes, Writer writer) throws IOException, XMLStreamException {
/* 77 */     if (clazzes == null) throw new IllegalArgumentException("null classes"); 
/* 78 */     if (writer == null) throw new IllegalArgumentException("null writer"); 
/* 79 */     JamXmlWriter out = new JamXmlWriter(writer);
/* 80 */     out.begin();
/* 81 */     for (int i = 0; i < clazzes.length; ) { out.write(clazzes[i]); i++; }
/* 82 */      out.end();
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\xml\JamXmlUtils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */