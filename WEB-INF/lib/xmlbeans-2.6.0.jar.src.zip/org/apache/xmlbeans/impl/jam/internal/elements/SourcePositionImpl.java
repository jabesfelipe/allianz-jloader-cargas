/*    */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MSourcePosition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SourcePositionImpl
/*    */   implements MSourcePosition
/*    */ {
/* 32 */   private int mColumn = -1;
/* 33 */   private int mLine = -1;
/* 34 */   private URI mURI = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setColumn(int col) {
/* 44 */     this.mColumn = col;
/*    */   } public void setLine(int line) {
/* 46 */     this.mLine = line;
/*    */   } public void setSourceURI(URI uri) {
/* 48 */     this.mURI = uri;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getColumn() {
/* 53 */     return this.mColumn;
/*    */   } public int getLine() {
/* 55 */     return this.mLine;
/*    */   } public URI getSourceURI() {
/* 57 */     return this.mURI;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\SourcePositionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */