/*    */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.jam.JClass;
/*    */ import org.apache.xmlbeans.impl.jam.JParameter;
/*    */ import org.apache.xmlbeans.impl.jam.internal.classrefs.DirectJClassRef;
/*    */ import org.apache.xmlbeans.impl.jam.internal.classrefs.JClassRef;
/*    */ import org.apache.xmlbeans.impl.jam.internal.classrefs.QualifiedJClassRef;
/*    */ import org.apache.xmlbeans.impl.jam.internal.classrefs.UnqualifiedJClassRef;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MParameter;
/*    */ import org.apache.xmlbeans.impl.jam.visitor.JVisitor;
/*    */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterImpl
/*    */   extends MemberImpl
/*    */   implements MParameter
/*    */ {
/*    */   private JClassRef mTypeClassRef;
/*    */   
/*    */   ParameterImpl(String simpleName, InvokableImpl containingMember, String typeName) {
/* 46 */     super(containingMember);
/* 47 */     setSimpleName(simpleName);
/* 48 */     setType(typeName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getQualifiedName() {
/* 55 */     return getSimpleName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setType(String qcname) {
/* 62 */     if (qcname == null) throw new IllegalArgumentException("null typename"); 
/* 63 */     this.mTypeClassRef = QualifiedJClassRef.create(qcname, (ClassImpl)getContainingClass());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setType(JClass qcname) {
/* 68 */     if (qcname == null) throw new IllegalArgumentException("null qcname"); 
/* 69 */     this.mTypeClassRef = DirectJClassRef.create(qcname);
/*    */   }
/*    */   
/*    */   public void setUnqualifiedType(String ucname) {
/* 73 */     if (ucname == null) throw new IllegalArgumentException("null ucname"); 
/* 74 */     this.mTypeClassRef = UnqualifiedJClassRef.create(ucname, (ClassImpl)getContainingClass());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JClass getType() {
/* 82 */     return this.mTypeClassRef.getRefClass();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(MVisitor visitor) {
/* 88 */     visitor.visit(this);
/*    */   } public void accept(JVisitor visitor) {
/* 90 */     visitor.visit((JParameter)this);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\ParameterImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */