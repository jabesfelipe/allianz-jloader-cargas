/*    */ package org.apache.xmlbeans.impl.jam.provider;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.jam.internal.elements.ElementContext;
/*    */ import org.apache.xmlbeans.impl.jam.mutable.MClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeJamClassBuilder
/*    */   extends JamClassBuilder
/*    */ {
/*    */   private JamClassBuilder[] mBuilders;
/*    */   
/*    */   public CompositeJamClassBuilder(JamClassBuilder[] builders) {
/* 37 */     if (builders == null) throw new IllegalArgumentException("null builders"); 
/* 38 */     this.mBuilders = builders;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void init(ElementContext ctx) {
/* 45 */     for (int i = 0; i < this.mBuilders.length; ) { this.mBuilders[i].init(ctx); i++; }
/*    */   
/*    */   }
/*    */   public MClass build(String pkg, String cname) {
/* 49 */     MClass out = null;
/* 50 */     for (int i = 0; i < this.mBuilders.length; i++) {
/* 51 */       out = this.mBuilders[i].build(pkg, cname);
/* 52 */       if (out != null) return out; 
/*    */     } 
/* 54 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\provider\CompositeJamClassBuilder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */