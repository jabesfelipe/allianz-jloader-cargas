/*     */ package org.apache.xmlbeans.impl.jam.internal.elements;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.JAnnotationValue;
/*     */ import org.apache.xmlbeans.impl.jam.JClass;
/*     */ import org.apache.xmlbeans.impl.jam.annotation.AnnotationProxy;
/*     */ import org.apache.xmlbeans.impl.jam.mutable.MAnnotation;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.JVisitor;
/*     */ import org.apache.xmlbeans.impl.jam.visitor.MVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotationImpl
/*     */   extends ElementImpl
/*     */   implements MAnnotation
/*     */ {
/*     */   private AnnotationProxy mProxy;
/*  35 */   private Object mAnnotationInstance = null;
/*  36 */   private String mQualifiedName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationImpl(ElementContext ctx, AnnotationProxy proxy, String qualifiedName) {
/*  45 */     super(ctx);
/*  46 */     if (proxy == null) throw new IllegalArgumentException("null proxy"); 
/*  47 */     if (qualifiedName == null) throw new IllegalArgumentException("null qn"); 
/*  48 */     this.mProxy = proxy;
/*     */ 
/*     */     
/*  51 */     setSimpleName(qualifiedName.substring(qualifiedName.lastIndexOf('.') + 1));
/*  52 */     this.mQualifiedName = qualifiedName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProxy() {
/*  58 */     return this.mProxy;
/*     */   } public JAnnotationValue[] getValues() {
/*  60 */     return this.mProxy.getValues();
/*     */   }
/*     */   public JAnnotationValue getValue(String name) {
/*  63 */     return this.mProxy.getValue(name);
/*     */   }
/*     */   public Object getAnnotationInstance() {
/*  66 */     return this.mAnnotationInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnnotationInstance(Object o) {
/*  72 */     this.mAnnotationInstance = o;
/*     */   }
/*     */   
/*     */   public void setSimpleValue(String name, Object value, JClass type) {
/*  76 */     if (name == null) throw new IllegalArgumentException("null name"); 
/*  77 */     if (type == null) throw new IllegalArgumentException("null type"); 
/*  78 */     if (value == null) throw new IllegalArgumentException("null value"); 
/*  79 */     this.mProxy.setValue(name, value, type);
/*     */   }
/*     */   
/*     */   public MAnnotation createNestedValue(String name, String annTypeName) {
/*  83 */     if (name == null) throw new IllegalArgumentException("null name"); 
/*  84 */     if (annTypeName == null) throw new IllegalArgumentException("null typename"); 
/*  85 */     AnnotationProxy p = getContext().createAnnotationProxy(annTypeName);
/*  86 */     AnnotationImpl out = new AnnotationImpl(getContext(), p, annTypeName);
/*  87 */     JClass type = getContext().getClassLoader().loadClass(annTypeName);
/*  88 */     this.mProxy.setValue(name, out, type);
/*  89 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MAnnotation[] createNestedValueArray(String name, String annComponentTypeName, int dimensions) {
/*  95 */     if (name == null) throw new IllegalArgumentException("null name"); 
/*  96 */     if (annComponentTypeName == null) throw new IllegalArgumentException("null typename"); 
/*  97 */     if (dimensions < 0) throw new IllegalArgumentException("dimensions = " + dimensions); 
/*  98 */     MAnnotation[] out = new MAnnotation[dimensions];
/*  99 */     for (int i = 0; i < out.length; i++) {
/* 100 */       AnnotationProxy p = getContext().createAnnotationProxy(annComponentTypeName);
/* 101 */       out[i] = new AnnotationImpl(getContext(), p, annComponentTypeName);
/*     */     } 
/* 103 */     JClass type = getContext().getClassLoader().loadClass("[L" + annComponentTypeName + ";");
/* 104 */     this.mProxy.setValue(name, out, type);
/* 105 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQualifiedName() {
/* 111 */     return this.mQualifiedName;
/*     */   } public void accept(MVisitor visitor) {
/* 113 */     visitor.visit(this);
/*     */   } public void accept(JVisitor visitor) {
/* 115 */     visitor.visit((JAnnotation)this);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\jam\internal\elements\AnnotationImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */