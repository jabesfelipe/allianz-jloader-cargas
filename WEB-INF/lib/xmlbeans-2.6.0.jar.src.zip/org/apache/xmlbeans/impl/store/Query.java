/*     */ package org.apache.xmlbeans.impl.store;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlBoolean;
/*     */ import org.apache.xmlbeans.XmlCursor;
/*     */ import org.apache.xmlbeans.XmlDate;
/*     */ import org.apache.xmlbeans.XmlDecimal;
/*     */ import org.apache.xmlbeans.XmlDouble;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlFloat;
/*     */ import org.apache.xmlbeans.XmlInteger;
/*     */ import org.apache.xmlbeans.XmlLong;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlRuntimeException;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.impl.common.XPath;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Query
/*     */ {
/*     */   public static final String QUERY_DELEGATE_INTERFACE = "QUERY_DELEGATE_INTERFACE";
/*  35 */   public static String _useDelegateForXQuery = "use delegate for xquery";
/*  36 */   public static String _useXdkForXQuery = "use xdk for xquery";
/*     */ 
/*     */   
/*     */   private static String _delIntfName;
/*     */   
/*  41 */   private static HashMap _xdkQueryCache = new HashMap();
/*     */   
/*     */   private static Method _xdkCompileQuery;
/*     */   private static boolean _xdkAvailable = true;
/*  45 */   private static HashMap _xqrlQueryCache = new HashMap();
/*     */   
/*     */   private static Method _xqrlCompileQuery;
/*     */   private static boolean _xqrlAvailable = true;
/*  49 */   private static HashMap _xqrl2002QueryCache = new HashMap();
/*     */   private static Method _xqrl2002CompileQuery;
/*     */   private static boolean _xqrl2002Available = true;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   static {
/*  55 */     ClassLoader cl = Query.class.getClassLoader();
/*  56 */     String id = "META-INF/services/org.apache.xmlbeans.impl.store.QueryDelegate.QueryInterface";
/*  57 */     InputStream in = cl.getResourceAsStream(id);
/*     */     
/*     */     try {
/*  60 */       BufferedReader br = new BufferedReader(new InputStreamReader(in));
/*  61 */       _delIntfName = br.readLine().trim();
/*  62 */       br.close();
/*     */     }
/*  64 */     catch (Exception e) {
/*     */       
/*  66 */       _delIntfName = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static XmlObject[] objectExecQuery(Cur c, String queryExpr, XmlOptions options) {
/*  80 */     return getCompiledQuery(queryExpr, options).objectExecute(c, options);
/*     */   }
/*     */ 
/*     */   
/*     */   static XmlCursor cursorExecQuery(Cur c, String queryExpr, XmlOptions options) {
/*  85 */     return getCompiledQuery(queryExpr, options).cursorExecute(c, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized Query getCompiledQuery(String queryExpr, XmlOptions options) {
/*  90 */     return getCompiledQuery(queryExpr, Path.getCurrentNodeVar(options), options);
/*     */   }
/*     */ 
/*     */   
/*     */   static synchronized Query getCompiledQuery(String queryExpr, String currentVar, XmlOptions options) {
/*  95 */     assert queryExpr != null;
/*  96 */     options = XmlOptions.maskNull(options);
/*     */ 
/*     */     
/*  99 */     if (options.hasOption(Path._forceXqrl2002ForXpathXQuery)) {
/*     */       
/* 101 */       Query query1 = (Query)_xqrl2002QueryCache.get(queryExpr);
/* 102 */       if (query1 != null) {
/* 103 */         return query1;
/*     */       }
/* 105 */       query1 = getXqrl2002CompiledQuery(queryExpr, currentVar);
/* 106 */       if (query1 != null) {
/*     */         
/* 108 */         _xqrl2002QueryCache.put(queryExpr, query1);
/* 109 */         return query1;
/*     */       } 
/* 111 */       throw new RuntimeException("No 2002 query engine found.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 116 */     Map boundary = new HashMap();
/* 117 */     int boundaryVal = 0;
/*     */     
/*     */     try {
/* 120 */       XPath.compileXPath(queryExpr, currentVar, boundary);
/*     */     }
/* 122 */     catch (org.apache.xmlbeans.impl.common.XPath.XPathCompileException e) {
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 128 */       boundaryVal = (boundary.get("$xmlbeans!ns_boundary") == null) ? 0 : ((Integer)boundary.get("$xmlbeans!ns_boundary")).intValue();
/*     */     } 
/*     */ 
/*     */     
/* 132 */     if (options.hasOption(_useXdkForXQuery)) {
/*     */ 
/*     */       
/* 135 */       Query query1 = (Query)_xdkQueryCache.get(queryExpr);
/* 136 */       if (query1 != null) {
/* 137 */         return query1;
/*     */       }
/* 139 */       query1 = createXdkCompiledQuery(queryExpr, currentVar);
/* 140 */       if (query1 != null) {
/*     */         
/* 142 */         _xdkQueryCache.put(queryExpr, query1);
/* 143 */         return query1;
/*     */       } 
/*     */     } 
/*     */     
/* 147 */     if (!options.hasOption(_useDelegateForXQuery)) {
/*     */ 
/*     */       
/* 150 */       Query query1 = (Query)_xqrlQueryCache.get(queryExpr);
/* 151 */       if (query1 != null) {
/* 152 */         return query1;
/*     */       }
/* 154 */       query1 = createXqrlCompiledQuery(queryExpr, currentVar);
/* 155 */       if (query1 != null) {
/*     */         
/* 157 */         _xqrlQueryCache.put(queryExpr, query1);
/* 158 */         return query1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     String delIntfName = options.hasOption("QUERY_DELEGATE_INTERFACE") ? (String)options.get("QUERY_DELEGATE_INTERFACE") : _delIntfName;
/*     */ 
/*     */     
/* 172 */     Query query = DelegateQueryImpl.createDelegateCompiledQuery(delIntfName, queryExpr, currentVar, boundaryVal);
/*     */     
/* 174 */     if (query != null)
/*     */     {
/*     */       
/* 177 */       return query;
/*     */     }
/*     */     
/* 180 */     throw new RuntimeException("No query engine found");
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized String compileQuery(String queryExpr, XmlOptions options) {
/* 185 */     getCompiledQuery(queryExpr, options);
/* 186 */     return queryExpr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Query createXdkCompiledQuery(String queryExpr, String currentVar) {
/* 192 */     if (!_xdkAvailable) return null; 
/* 193 */     if (_xdkCompileQuery == null) {
/*     */       
/*     */       try {
/*     */         
/* 197 */         Class xdkImpl = Class.forName("org.apache.xmlbeans.impl.store.OXQXBXqrlImpl");
/*     */         
/* 199 */         _xdkCompileQuery = xdkImpl.getDeclaredMethod("compileQuery", new Class[] { String.class, String.class, Boolean.class });
/*     */ 
/*     */       
/*     */       }
/* 203 */       catch (ClassNotFoundException e) {
/*     */         
/* 205 */         _xdkAvailable = false;
/* 206 */         return null;
/*     */       }
/* 208 */       catch (Exception e) {
/*     */         
/* 210 */         _xdkAvailable = false;
/* 211 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 215 */     Object[] args = { queryExpr, currentVar, new Boolean(true) };
/*     */ 
/*     */     
/*     */     try {
/* 219 */       return (Query)_xdkCompileQuery.invoke(null, args);
/*     */     }
/* 221 */     catch (InvocationTargetException e) {
/*     */       
/* 223 */       Throwable t = e.getCause();
/* 224 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/* 226 */     catch (IllegalAccessException e) {
/*     */       
/* 228 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Query createXqrlCompiledQuery(String queryExpr, String currentVar) {
/* 235 */     if (!_xqrlAvailable) return null; 
/* 236 */     if (_xqrlCompileQuery == null) {
/*     */       
/*     */       try {
/*     */         
/* 240 */         Class xqrlImpl = Class.forName("org.apache.xmlbeans.impl.store.XqrlImpl");
/*     */         
/* 242 */         _xqrlCompileQuery = xqrlImpl.getDeclaredMethod("compileQuery", new Class[] { String.class, String.class, Boolean.class });
/*     */ 
/*     */       
/*     */       }
/* 246 */       catch (ClassNotFoundException e) {
/*     */         
/* 248 */         _xqrlAvailable = false;
/* 249 */         return null;
/*     */       }
/* 251 */       catch (Exception e) {
/*     */         
/* 253 */         _xqrlAvailable = false;
/* 254 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 258 */     Object[] args = { queryExpr, currentVar, new Boolean(true) };
/*     */ 
/*     */     
/*     */     try {
/* 262 */       return (Query)_xqrlCompileQuery.invoke(null, args);
/*     */     }
/* 264 */     catch (InvocationTargetException e) {
/*     */       
/* 266 */       Throwable t = e.getCause();
/* 267 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/* 269 */     catch (IllegalAccessException e) {
/*     */       
/* 271 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   abstract XmlObject[] objectExecute(Cur paramCur, XmlOptions paramXmlOptions);
/*     */   
/*     */   private static Query getXqrl2002CompiledQuery(String queryExpr, String currentVar) {
/* 277 */     if (_xqrl2002Available && _xqrl2002CompileQuery == null) {
/*     */       
/*     */       try {
/*     */         
/* 281 */         Class xqrlImpl = Class.forName("org.apache.xmlbeans.impl.store.Xqrl2002Impl");
/*     */         
/* 283 */         _xqrl2002CompileQuery = xqrlImpl.getDeclaredMethod("compileQuery", new Class[] { String.class, String.class, Boolean.class });
/*     */ 
/*     */       
/*     */       }
/* 287 */       catch (ClassNotFoundException e) {
/*     */         
/* 289 */         _xqrl2002Available = false;
/* 290 */         return null;
/*     */       }
/* 292 */       catch (Exception e) {
/*     */         
/* 294 */         _xqrl2002Available = false;
/* 295 */         throw new RuntimeException(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */     
/* 299 */     Object[] args = { queryExpr, currentVar, new Boolean(true) };
/*     */ 
/*     */     
/*     */     try {
/* 303 */       return (Query)_xqrl2002CompileQuery.invoke(null, args);
/*     */     }
/* 305 */     catch (InvocationTargetException e) {
/*     */       
/* 307 */       Throwable t = e.getCause();
/* 308 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/* 310 */     catch (IllegalAccessException e) {
/*     */       
/* 312 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   abstract XmlCursor cursorExecute(Cur paramCur, XmlOptions paramXmlOptions);
/*     */   
/*     */   private static final class DelegateQueryImpl extends Query {
/*     */     private DelegateQueryImpl(QueryDelegate.QueryInterface xqueryImpl) {
/* 320 */       this._xqueryImpl = xqueryImpl;
/*     */     }
/*     */ 
/*     */     
/*     */     private QueryDelegate.QueryInterface _xqueryImpl;
/*     */     static final boolean $assertionsDisabled;
/*     */     
/*     */     public static Query createDelegateCompiledQuery(String delIntfName, String queryExpr, String currentVar, int boundary) {
/* 328 */       assert !currentVar.startsWith(".") && !currentVar.startsWith("..");
/* 329 */       QueryDelegate.QueryInterface impl = QueryDelegate.createInstance(delIntfName, queryExpr, currentVar, boundary);
/*     */ 
/*     */       
/* 332 */       if (impl == null) {
/* 333 */         return null;
/*     */       }
/* 335 */       return new DelegateQueryImpl(impl);
/*     */     }
/*     */ 
/*     */     
/*     */     XmlObject[] objectExecute(Cur c, XmlOptions options) {
/* 340 */       return (new DelegateQueryEngine(this._xqueryImpl, c, options)).objectExecute();
/*     */     }
/*     */ 
/*     */     
/*     */     XmlCursor cursorExecute(Cur c, XmlOptions options) {
/* 345 */       return (new DelegateQueryEngine(this._xqueryImpl, c, options)).cursorExecute();
/*     */     }
/*     */     
/*     */     private static class DelegateQueryEngine { private Cur _cur;
/*     */       private QueryDelegate.QueryInterface _engine;
/*     */       private long _version;
/*     */       private XmlOptions _options;
/*     */       static final boolean $assertionsDisabled;
/*     */       
/*     */       public DelegateQueryEngine(QueryDelegate.QueryInterface xqImpl, Cur c, XmlOptions opt) {
/* 355 */         this._engine = xqImpl;
/* 356 */         this._version = c._locale.version();
/* 357 */         this._cur = c.weakCur(this);
/* 358 */         this._options = opt;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public XmlObject[] objectExecute() {
/* 364 */         if (this._cur == null || this._version != this._cur._locale.version());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 369 */         Map bindings = (Map)XmlOptions.maskNull(this._options).get("XQUERY_VARIABLE_MAP");
/*     */ 
/*     */         
/* 372 */         List resultsList = this._engine.execQuery(this._cur.getDom(), bindings);
/*     */         
/* 374 */         assert resultsList.size() > -1;
/*     */         
/* 376 */         XmlObject[] result = new XmlObject[resultsList.size()];
/*     */         
/* 378 */         for (int i = 0; i < resultsList.size(); i++) {
/*     */           
/* 380 */           Locale l = Locale.getLocale(this._cur._locale._schemaTypeLoader, this._options);
/*     */ 
/*     */           
/* 383 */           l.enter();
/* 384 */           Object node = resultsList.get(i);
/* 385 */           Cur res = null;
/*     */           
/*     */           try {
/* 388 */             if (!(node instanceof Node)) {
/*     */ 
/*     */ 
/*     */               
/* 392 */               res = l.load("<xml-fragment/>").tempCur();
/* 393 */               res.setValue(node.toString());
/* 394 */               SchemaType type = getType(node);
/* 395 */               Locale.autoTypeDocument(res, type, null);
/* 396 */               result[i] = res.getObject();
/*     */             } else {
/*     */               
/* 399 */               res = loadNode(l, (Node)node);
/* 400 */             }  result[i] = res.getObject();
/*     */           }
/* 402 */           catch (XmlException e) {
/* 403 */             throw new RuntimeException(e);
/*     */           } finally {
/*     */             
/* 406 */             l.exit();
/*     */           } 
/* 408 */           res.release();
/*     */         } 
/* 410 */         release();
/* 411 */         this._engine = null;
/* 412 */         return result;
/*     */       }
/*     */       
/*     */       private SchemaType getType(Object node) {
/*     */         SchemaType type;
/* 417 */         if (node instanceof Integer) {
/* 418 */           type = XmlInteger.type;
/* 419 */         } else if (node instanceof Double) {
/* 420 */           type = XmlDouble.type;
/* 421 */         } else if (node instanceof Long) {
/* 422 */           type = XmlLong.type;
/* 423 */         } else if (node instanceof Float) {
/* 424 */           type = XmlFloat.type;
/* 425 */         } else if (node instanceof java.math.BigDecimal) {
/* 426 */           type = XmlDecimal.type;
/* 427 */         } else if (node instanceof Boolean) {
/* 428 */           type = XmlBoolean.type;
/* 429 */         } else if (node instanceof String) {
/* 430 */           type = XmlString.type;
/* 431 */         } else if (node instanceof java.util.Date) {
/* 432 */           type = XmlDate.type;
/*     */         } else {
/* 434 */           type = XmlAnySimpleType.type;
/* 435 */         }  return type;
/*     */       }
/*     */       
/*     */       public XmlCursor cursorExecute() {
/* 439 */         if (this._cur == null || this._version != this._cur._locale.version());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 444 */         Map bindings = (Map)XmlOptions.maskNull(this._options).get("XQUERY_VARIABLE_MAP");
/*     */ 
/*     */         
/* 447 */         List resultsList = this._engine.execQuery(this._cur.getDom(), bindings);
/*     */         
/* 449 */         assert resultsList.size() > -1;
/*     */ 
/*     */         
/* 452 */         this._engine = null;
/*     */         
/* 454 */         Locale locale = Locale.getLocale(this._cur._locale._schemaTypeLoader, this._options);
/* 455 */         locale.enter();
/* 456 */         Locale.LoadContext _context = new Cur.CurLoadContext(locale, this._options);
/* 457 */         Cursor resultCur = null;
/*     */         try {
/* 459 */           for (int i = 0; i < resultsList.size(); i++) {
/* 460 */             loadNodeHelper(locale, resultsList.get(i), _context);
/*     */           }
/* 462 */           Cur c = _context.finish();
/* 463 */           Locale.associateSourceName(c, this._options);
/* 464 */           Locale.autoTypeDocument(c, null, this._options);
/* 465 */           resultCur = new Cursor(c);
/*     */         }
/* 467 */         catch (Exception e) {
/*     */         
/*     */         } finally {
/* 470 */           locale.exit();
/*     */         } 
/* 472 */         release();
/* 473 */         return resultCur;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void release() {
/* 479 */         if (this._cur != null) {
/* 480 */           this._cur.release();
/* 481 */           this._cur = null;
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       private Cur loadNode(Locale locale, Node node) {
/* 488 */         Locale.LoadContext context = new Cur.CurLoadContext(locale, this._options);
/*     */         
/*     */         try {
/* 491 */           loadNodeHelper(locale, node, context);
/* 492 */           Cur c = context.finish();
/* 493 */           Locale.associateSourceName(c, this._options);
/* 494 */           Locale.autoTypeDocument(c, null, this._options);
/* 495 */           return c;
/*     */         }
/* 497 */         catch (Exception e) {
/* 498 */           throw new XmlRuntimeException(e.getMessage(), e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       private void loadNodeHelper(Locale locale, Node node, Locale.LoadContext context) {
/* 504 */         if (node.getNodeType() == 2) {
/* 505 */           QName attName = new QName(node.getNamespaceURI(), node.getLocalName(), node.getPrefix());
/*     */ 
/*     */           
/* 508 */           context.attr(attName, node.getNodeValue());
/*     */         } else {
/*     */           
/* 511 */           locale.loadNode(node, context);
/*     */         } 
/*     */       } }
/*     */   
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\Query.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */