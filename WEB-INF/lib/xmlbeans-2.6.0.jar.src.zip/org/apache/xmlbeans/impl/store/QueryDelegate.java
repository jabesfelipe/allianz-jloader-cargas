/*    */ package org.apache.xmlbeans.impl.store;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class QueryDelegate
/*    */ {
/* 24 */   private static HashMap _constructors = new HashMap();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static synchronized void init(String implClassName) {
/* 32 */     if (implClassName == null)
/* 33 */       implClassName = "org.apache.xmlbeans.impl.xquery.saxon.XBeansXQuery"; 
/* 34 */     Class queryInterfaceImpl = null;
/* 35 */     boolean engineAvailable = true;
/*    */     
/*    */     try {
/* 38 */       queryInterfaceImpl = Class.forName(implClassName);
/*    */     }
/* 40 */     catch (ClassNotFoundException e) {
/*    */       
/* 42 */       engineAvailable = false;
/*    */     }
/* 44 */     catch (NoClassDefFoundError e) {
/*    */       
/* 46 */       engineAvailable = false;
/*    */     } 
/*    */     
/* 49 */     if (engineAvailable) {
/*    */       
/*    */       try {
/*    */         
/* 53 */         Constructor constructor = queryInterfaceImpl.getConstructor(new Class[] { String.class, String.class, Integer.class });
/*    */         
/* 55 */         _constructors.put(implClassName, constructor);
/*    */       }
/* 57 */       catch (Exception e) {
/*    */         
/* 59 */         throw new RuntimeException(e);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized QueryInterface createInstance(String implClassName, String query, String contextVar, int boundary) {
/* 67 */     if (_constructors.get(implClassName) == null) {
/* 68 */       init(implClassName);
/*    */     }
/* 70 */     if (_constructors.get(implClassName) == null) {
/* 71 */       return null;
/*    */     }
/* 73 */     Constructor constructor = (Constructor)_constructors.get(implClassName);
/*    */     
/*    */     try {
/* 76 */       return constructor.newInstance(new Object[] { query, contextVar, new Integer(boundary) });
/*    */     
/*    */     }
/* 79 */     catch (Exception e) {
/*    */       
/* 81 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static interface QueryInterface {
/*    */     List execQuery(Object param1Object, Map param1Map);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\QueryDelegate.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */