/*      */ package org.apache.xmlbeans.impl.store;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.XMLStreamReader;
/*      */ import javax.xml.transform.Source;
/*      */ import org.apache.xmlbeans.XmlCursor;
/*      */ import org.apache.xmlbeans.XmlException;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlRuntimeException;
/*      */ import org.apache.xmlbeans.impl.common.XMLChar;
/*      */ import org.apache.xmlbeans.impl.soap.Detail;
/*      */ import org.apache.xmlbeans.impl.soap.DetailEntry;
/*      */ import org.apache.xmlbeans.impl.soap.Name;
/*      */ import org.apache.xmlbeans.impl.soap.Node;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPBody;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPBodyElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPEnvelope;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPException;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPFault;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPHeader;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPHeaderElement;
/*      */ import org.apache.xmlbeans.impl.soap.SOAPPart;
/*      */ import org.apache.xmlbeans.impl.soap.Text;
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.CDATASection;
/*      */ import org.w3c.dom.CharacterData;
/*      */ import org.w3c.dom.Comment;
/*      */ import org.w3c.dom.DOMException;
/*      */ import org.w3c.dom.DOMImplementation;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.DocumentFragment;
/*      */ import org.w3c.dom.DocumentType;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.EntityReference;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.w3c.dom.ProcessingInstruction;
/*      */ import org.w3c.dom.Text;
/*      */ import org.w3c.dom.UserDataHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DomImpl
/*      */ {
/*      */   static final int ELEMENT = 1;
/*      */   static final int ATTR = 2;
/*      */   static final int TEXT = 3;
/*      */   static final int CDATA = 4;
/*      */   static final int ENTITYREF = 5;
/*      */   static final int ENTITY = 6;
/*      */   static final int PROCINST = 7;
/*      */   static final int COMMENT = 8;
/*      */   static final int DOCUMENT = 9;
/*      */   static final int DOCTYPE = 10;
/*      */   static final int DOCFRAG = 11;
/*      */   static final int NOTATION = 12;
/*      */   
/*      */   static Dom parent(Dom d) {
/*   99 */     return node_getParentNode(d);
/*  100 */   } static Dom firstChild(Dom d) { return node_getFirstChild(d); }
/*  101 */   static Dom nextSibling(Dom d) { return node_getNextSibling(d); } static Dom prevSibling(Dom d) {
/*  102 */     return node_getPreviousSibling(d);
/*      */   }
/*      */   
/*      */   public static Dom append(Dom n, Dom p) {
/*  106 */     return node_insertBefore(p, n, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom insert(Dom n, Dom b) {
/*  111 */     assert b != null;
/*  112 */     return node_insertBefore(parent(b), n, b);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom remove(Dom n) {
/*  117 */     Dom p = parent(n);
/*      */     
/*  119 */     if (p != null) {
/*  120 */       node_removeChild(p, n);
/*      */     }
/*  122 */     return n;
/*      */   } static interface Dom {
/*      */     Locale locale(); int nodeType(); Cur tempCur();
/*      */     QName getQName();
/*      */     boolean nodeCanHavePrefixUri();
/*      */     void dump();
/*      */     void dump(PrintStream param1PrintStream);
/*      */     void dump(PrintStream param1PrintStream, Object param1Object); }
/*      */   static class HierarchyRequestErr extends DOMException {
/*  131 */     HierarchyRequestErr() { this("This node isn't allowed there"); } HierarchyRequestErr(String message) {
/*  132 */       super((short)3, message);
/*      */     }
/*      */   }
/*      */   
/*      */   static class WrongDocumentErr extends DOMException {
/*  137 */     WrongDocumentErr() { this("Nodes do not belong to the same document"); } WrongDocumentErr(String message) {
/*  138 */       super((short)4, message);
/*      */     }
/*      */   }
/*      */   
/*      */   static class NotFoundErr extends DOMException {
/*  143 */     NotFoundErr() { this("Node not found"); } NotFoundErr(String message) {
/*  144 */       super((short)8, message);
/*      */     }
/*      */   }
/*      */   
/*      */   static class NamespaceErr extends DOMException {
/*  149 */     NamespaceErr() { this("Namespace error"); } NamespaceErr(String message) {
/*  150 */       super((short)14, message);
/*      */     }
/*      */   }
/*      */   
/*      */   static class NoModificationAllowedErr extends DOMException {
/*  155 */     NoModificationAllowedErr() { this("No modification allowed error"); } NoModificationAllowedErr(String message) {
/*  156 */       super((short)7, message);
/*      */     }
/*      */   }
/*      */   
/*      */   static class InuseAttributeError extends DOMException {
/*  161 */     InuseAttributeError() { this("Attribute currently in use error"); } InuseAttributeError(String message) {
/*  162 */       super((short)10, message);
/*      */     }
/*      */   }
/*      */   
/*      */   static class IndexSizeError extends DOMException {
/*  167 */     IndexSizeError() { this("Index Size Error"); } IndexSizeError(String message) {
/*  168 */       super((short)1, message);
/*      */     }
/*      */   }
/*      */   
/*      */   static class NotSupportedError extends DOMException {
/*  173 */     NotSupportedError() { this("This operation is not supported"); } NotSupportedError(String message) {
/*  174 */       super((short)9, message);
/*      */     }
/*      */   }
/*      */   
/*      */   static class InvalidCharacterError extends DOMException {
/*  179 */     InvalidCharacterError() { this("The name contains an invalid character"); } InvalidCharacterError(String message) {
/*  180 */       super((short)5, message);
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class EmptyNodeList
/*      */     implements NodeList
/*      */   {
/*      */     private EmptyNodeList() {}
/*      */     
/*  189 */     public int getLength() { return 0; } public Node item(int i) {
/*  190 */       return null;
/*      */     } }
/*      */   
/*  193 */   public static NodeList _emptyNodeList = new EmptyNodeList();
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   static String nodeKindName(int t) {
/*  197 */     switch (t) {
/*      */       case 2:
/*  199 */         return "attribute";
/*  200 */       case 4: return "cdata section";
/*  201 */       case 8: return "comment";
/*  202 */       case 11: return "document fragment";
/*  203 */       case 9: return "document";
/*  204 */       case 10: return "document type";
/*  205 */       case 1: return "element";
/*  206 */       case 6: return "entity";
/*  207 */       case 5: return "entity reference";
/*  208 */       case 12: return "notation";
/*  209 */       case 7: return "processing instruction";
/*  210 */       case 3: return "text";
/*      */     } 
/*  212 */     throw new RuntimeException("Unknown node type");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String isValidChild(Dom parent, Dom child) {
/*  218 */     int pk = parent.nodeType();
/*  219 */     int ck = child.nodeType();
/*      */     
/*  221 */     switch (pk) {
/*      */ 
/*      */       
/*      */       case 9:
/*  225 */         switch (ck) {
/*      */ 
/*      */           
/*      */           case 1:
/*  229 */             if (document_getDocumentElement(parent) != null) {
/*  230 */               return "Documents may only have a maximum of one document element";
/*      */             }
/*  232 */             return null;
/*      */ 
/*      */           
/*      */           case 10:
/*  236 */             if (document_getDoctype(parent) != null) {
/*  237 */               return "Documents may only have a maximum of one document type node";
/*      */             }
/*  239 */             return null;
/*      */           
/*      */           case 7:
/*      */           case 8:
/*  243 */             return null;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  251 */         if (ck == 3 || ck == 5) {
/*  252 */           return null;
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 5:
/*      */       case 6:
/*      */       case 11:
/*  265 */         switch (ck) {
/*      */           
/*      */           case 1:
/*      */           case 3:
/*      */           case 4:
/*      */           case 5:
/*      */           case 7:
/*      */           case 8:
/*  273 */             return null;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       
/*      */       case 3:
/*      */       case 4:
/*      */       case 7:
/*      */       case 8:
/*      */       case 10:
/*      */       case 12:
/*  285 */         return nodeKindName(pk) + " nodes may not have any children";
/*      */     } 
/*      */     
/*  288 */     return nodeKindName(pk) + " nodes may not have " + nodeKindName(ck) + " nodes as children";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void validateNewChild(Dom parent, Dom child) {
/*  295 */     String msg = isValidChild(parent, child);
/*      */     
/*  297 */     if (msg != null) {
/*  298 */       throw new HierarchyRequestErr(msg);
/*      */     }
/*  300 */     if (parent == child) {
/*  301 */       throw new HierarchyRequestErr("New child and parent are the same node");
/*      */     }
/*  303 */     while ((parent = parent(parent)) != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  308 */       if (child.nodeType() == 5) {
/*  309 */         throw new NoModificationAllowedErr("Entity reference trees may not be modified");
/*      */       }
/*  311 */       if (child == parent) {
/*  312 */         throw new HierarchyRequestErr("New child is an ancestor node of the parent node");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static String validatePrefix(String prefix, String uri, String local, boolean isAttr) {
/*  319 */     validateNcName(prefix);
/*      */     
/*  321 */     if (prefix == null) {
/*  322 */       prefix = "";
/*      */     }
/*  324 */     if (uri == null) {
/*  325 */       uri = "";
/*      */     }
/*  327 */     if (prefix.length() > 0 && uri.length() == 0) {
/*  328 */       throw new NamespaceErr("Attempt to give a prefix for no namespace");
/*      */     }
/*  330 */     if (prefix.equals("xml") && !uri.equals("http://www.w3.org/XML/1998/namespace")) {
/*  331 */       throw new NamespaceErr("Invalid prefix - begins with 'xml'");
/*      */     }
/*  333 */     if (isAttr) {
/*      */       
/*  335 */       if (prefix.length() > 0) {
/*      */         
/*  337 */         if (local.equals("xmlns")) {
/*  338 */           throw new NamespaceErr("Invalid namespace - attr is default namespace already");
/*      */         }
/*  340 */         if (Locale.beginsWithXml(local)) {
/*  341 */           throw new NamespaceErr("Invalid namespace - attr prefix begins with 'xml'");
/*      */         }
/*  343 */         if (prefix.equals("xmlns") && !uri.equals("http://www.w3.org/2000/xmlns/")) {
/*  344 */           throw new NamespaceErr("Invalid namespace - uri is not 'http://www.w3.org/2000/xmlns/;");
/*      */         
/*      */         }
/*      */       }
/*  348 */       else if (local.equals("xmlns") && !uri.equals("http://www.w3.org/2000/xmlns/")) {
/*  349 */         throw new NamespaceErr("Invalid namespace - uri is not 'http://www.w3.org/2000/xmlns/;");
/*      */       }
/*      */     
/*  352 */     } else if (Locale.beginsWithXml(prefix)) {
/*  353 */       throw new NamespaceErr("Invalid prefix - begins with 'xml'");
/*      */     } 
/*  355 */     return prefix;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void validateName(String name) {
/*  360 */     if (name == null) {
/*  361 */       throw new IllegalArgumentException("Name is null");
/*      */     }
/*  363 */     if (name.length() == 0) {
/*  364 */       throw new IllegalArgumentException("Name is empty");
/*      */     }
/*  366 */     if (!XMLChar.isValidName(name)) {
/*  367 */       throw new InvalidCharacterError("Name has an invalid character");
/*      */     }
/*      */   }
/*      */   
/*      */   private static void validateNcName(String name) {
/*  372 */     if (name != null && name.length() > 0 && !XMLChar.isValidNCName(name))
/*  373 */       throw new InvalidCharacterError(); 
/*      */   }
/*      */   
/*      */   private static void validateQualifiedName(String name, String uri, boolean isAttr) {
/*      */     String local;
/*  378 */     assert name != null;
/*      */     
/*  380 */     if (uri == null) {
/*  381 */       uri = "";
/*      */     }
/*  383 */     int i = name.indexOf(':');
/*      */ 
/*      */ 
/*      */     
/*  387 */     if (i < 0) {
/*      */       
/*  389 */       validateNcName(local = name);
/*      */       
/*  391 */       if (isAttr && local.equals("xmlns") && !uri.equals("http://www.w3.org/2000/xmlns/"))
/*      */       {
/*  393 */         throw new NamespaceErr("Default xmlns attribute does not have namespace: http://www.w3.org/2000/xmlns/");
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  400 */       if (i == 0) {
/*  401 */         throw new NamespaceErr("Invalid qualified name, no prefix specified");
/*      */       }
/*  403 */       String prefix = name.substring(0, i);
/*      */       
/*  405 */       validateNcName(prefix);
/*      */       
/*  407 */       if (uri.length() == 0) {
/*  408 */         throw new NamespaceErr("Attempt to give a prefix for no namespace");
/*      */       }
/*  410 */       local = name.substring(i + 1);
/*      */       
/*  412 */       if (local.indexOf(':') >= 0) {
/*  413 */         throw new NamespaceErr("Invalid qualified name, more than one colon");
/*      */       }
/*  415 */       validateNcName(local);
/*      */       
/*  417 */       if (prefix.equals("xml") && !uri.equals("http://www.w3.org/XML/1998/namespace")) {
/*  418 */         throw new NamespaceErr("Invalid prefix - begins with 'xml'");
/*      */       }
/*      */     } 
/*  421 */     if (local.length() == 0) {
/*  422 */       throw new NamespaceErr("Invalid qualified name, no local part specified");
/*      */     }
/*      */   }
/*      */   
/*      */   private static void removeNode(Dom n) {
/*  427 */     assert n.nodeType() != 3 && n.nodeType() != 4;
/*      */     
/*  429 */     Cur cFrom = n.tempCur();
/*      */     
/*  431 */     cFrom.toEnd();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  437 */     if (cFrom.next()) {
/*      */       
/*  439 */       CharNode fromNodes = cFrom.getCharNodes();
/*      */       
/*  441 */       if (fromNodes != null) {
/*      */         
/*  443 */         cFrom.setCharNodes(null);
/*  444 */         Cur cTo = n.tempCur();
/*  445 */         cTo.setCharNodes(CharNode.appendNodes(cTo.getCharNodes(), fromNodes));
/*  446 */         cTo.release();
/*      */       } 
/*      */     } 
/*      */     
/*  450 */     cFrom.release();
/*      */     
/*  452 */     Cur.moveNode((Xobj)n, null);
/*      */   }
/*      */   private static abstract class ElementsNodeList implements NodeList { private DomImpl.Dom _root; private Locale _locale; private long _version;
/*      */     private ArrayList _elements;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     ElementsNodeList(DomImpl.Dom root) {
/*  459 */       assert root.nodeType() == 9 || root.nodeType() == 1;
/*      */       
/*  461 */       this._root = root;
/*  462 */       this._locale = this._root.locale();
/*  463 */       this._version = 0L;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getLength() {
/*  468 */       ensureElements();
/*      */       
/*  470 */       return this._elements.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public Node item(int i) {
/*  475 */       ensureElements();
/*      */       
/*  477 */       return (i < 0 || i >= this._elements.size()) ? (Node)null : this._elements.get(i);
/*      */     }
/*      */ 
/*      */     
/*      */     private void ensureElements() {
/*  482 */       if (this._version == this._locale.version()) {
/*      */         return;
/*      */       }
/*  485 */       this._version = this._locale.version();
/*      */       
/*  487 */       this._elements = new ArrayList();
/*      */       
/*  489 */       Locale l = this._locale;
/*      */       
/*  491 */       if (l.noSync()) { l.enter(); try { addElements(this._root); } finally { l.exit(); }  }
/*  492 */       else { synchronized (l) { l.enter(); try { addElements(this._root); } finally { l.exit(); }
/*      */            }
/*      */          }
/*      */     
/*      */     } private void addElements(DomImpl.Dom node) {
/*  497 */       for (DomImpl.Dom c = DomImpl.firstChild(node); c != null; c = DomImpl.nextSibling(c)) {
/*      */         
/*  499 */         if (c.nodeType() == 1) {
/*      */           
/*  501 */           if (match(c)) {
/*  502 */             this._elements.add(c);
/*      */           }
/*  504 */           addElements(c);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected abstract boolean match(DomImpl.Dom param1Dom); }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ElementsByTagNameNodeList
/*      */     extends ElementsNodeList
/*      */   {
/*      */     private String _name;
/*      */ 
/*      */     
/*      */     ElementsByTagNameNodeList(DomImpl.Dom root, String name) {
/*  521 */       super(root);
/*      */       
/*  523 */       this._name = name;
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean match(DomImpl.Dom element) {
/*  528 */       return this._name.equals("*") ? true : DomImpl._node_getNodeName(element).equals(this._name);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class ElementsByTagNameNSNodeList
/*      */     extends ElementsNodeList {
/*      */     private String _uri;
/*      */     private String _local;
/*      */     
/*      */     ElementsByTagNameNSNodeList(DomImpl.Dom root, String uri, String local) {
/*  538 */       super(root);
/*      */       
/*  540 */       this._uri = (uri == null) ? "" : uri;
/*  541 */       this._local = local;
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean match(DomImpl.Dom element) {
/*  546 */       if (!this._uri.equals("*") && !DomImpl._node_getNamespaceURI(element).equals(this._uri)) {
/*  547 */         return false;
/*      */       }
/*  549 */       return this._local.equals("*") ? true : DomImpl._node_getLocalName(element).equals(this._local);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document _domImplementation_createDocument(Locale l, String u, String n, DocumentType t) {
/*  565 */     if (l.noSync()) { l.enter(); try { return domImplementation_createDocument(l, u, n, t); } finally { l.exit(); }  }
/*  566 */      synchronized (l) { l.enter(); try { return domImplementation_createDocument(l, u, n, t); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   
/*      */   public static Document domImplementation_createDocument(Locale l, String namespaceURI, String qualifiedName, DocumentType doctype) {
/*  572 */     validateQualifiedName(qualifiedName, namespaceURI, false);
/*      */     
/*  574 */     Cur c = l.tempCur();
/*      */     
/*  576 */     c.createDomDocumentRoot();
/*      */     
/*  578 */     Document doc = (Document)c.getDom();
/*      */     
/*  580 */     c.next();
/*      */     
/*  582 */     c.createElement(l.makeQualifiedQName(namespaceURI, qualifiedName));
/*      */     
/*  584 */     if (doctype != null) {
/*  585 */       throw new RuntimeException("Not impl");
/*      */     }
/*  587 */     c.toParent();
/*      */ 
/*      */     
/*      */     try {
/*  591 */       Locale.autoTypeDocument(c, null, null);
/*      */     }
/*  593 */     catch (XmlException e) {
/*      */       
/*  595 */       throw new XmlRuntimeException(e);
/*      */     } 
/*      */     
/*  598 */     c.release();
/*      */     
/*  600 */     return doc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _domImplementation_hasFeature(Locale l, String feature, String version) {
/*  609 */     if (feature == null) {
/*  610 */       return false;
/*      */     }
/*  612 */     if (version != null && version.length() > 0 && !version.equals("1.0") && !version.equals("2.0"))
/*      */     {
/*      */       
/*  615 */       return false;
/*      */     }
/*      */     
/*  618 */     if (feature.equalsIgnoreCase("core")) {
/*  619 */       return true;
/*      */     }
/*  621 */     if (feature.equalsIgnoreCase("xml")) {
/*  622 */       return true;
/*      */     }
/*  624 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element _document_getDocumentElement(Dom d) {
/*      */     Dom e;
/*  633 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/*  637 */     if (l.noSync()) { l.enter(); try { e = document_getDocumentElement(d); } finally { l.exit(); }  }
/*  638 */     else { synchronized (l) { l.enter(); try { e = document_getDocumentElement(d); } finally { l.exit(); }  }
/*      */        }
/*  640 */      return (Element)e;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_getDocumentElement(Dom d) {
/*  645 */     for (d = firstChild(d); d != null; d = nextSibling(d)) {
/*      */       
/*  647 */       if (d.nodeType() == 1) {
/*  648 */         return d;
/*      */       }
/*      */     } 
/*  651 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DocumentFragment _document_createDocumentFragment(Dom d) {
/*      */     Dom f;
/*  660 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/*  664 */     if (l.noSync()) { l.enter(); try { f = document_createDocumentFragment(d); } finally { l.exit(); }  }
/*  665 */     else { synchronized (l) { l.enter(); try { f = document_createDocumentFragment(d); } finally { l.exit(); }  }
/*      */        }
/*  667 */      return (DocumentFragment)f;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_createDocumentFragment(Dom d) {
/*  672 */     Cur c = d.locale().tempCur();
/*      */     
/*  674 */     c.createDomDocFragRoot();
/*      */     
/*  676 */     Dom f = c.getDom();
/*      */     
/*  678 */     c.release();
/*      */     
/*  680 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element _document_createElement(Dom d, String name) {
/*      */     Dom e;
/*  689 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/*  693 */     if (l.noSync()) { l.enter(); try { e = document_createElement(d, name); } finally { l.exit(); }  }
/*  694 */     else { synchronized (l) { l.enter(); try { e = document_createElement(d, name); } finally { l.exit(); }  }
/*      */        }
/*  696 */      return (Element)e;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_createElement(Dom d, String name) {
/*  701 */     validateName(name);
/*      */     
/*  703 */     Locale l = d.locale();
/*      */     
/*  705 */     Cur c = l.tempCur();
/*      */     
/*  707 */     c.createElement(l.makeQualifiedQName("", name));
/*      */     
/*  709 */     Dom e = c.getDom();
/*      */     
/*  711 */     c.release();
/*  712 */     ((Xobj.ElementXobj)e)._canHavePrefixUri = false;
/*  713 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element _document_createElementNS(Dom d, String uri, String qname) {
/*      */     Dom e;
/*  722 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/*  726 */     if (l.noSync()) { l.enter(); try { e = document_createElementNS(d, uri, qname); } finally { l.exit(); }  }
/*  727 */     else { synchronized (l) { l.enter(); try { e = document_createElementNS(d, uri, qname); } finally { l.exit(); }  }
/*      */        }
/*  729 */      return (Element)e;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_createElementNS(Dom d, String uri, String qname) {
/*  734 */     validateQualifiedName(qname, uri, false);
/*      */     
/*  736 */     Locale l = d.locale();
/*      */     
/*  738 */     Cur c = l.tempCur();
/*      */     
/*  740 */     c.createElement(l.makeQualifiedQName(uri, qname));
/*      */     
/*  742 */     Dom e = c.getDom();
/*      */     
/*  744 */     c.release();
/*      */     
/*  746 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Attr _document_createAttribute(Dom d, String name) {
/*      */     Dom a;
/*  755 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/*  759 */     if (l.noSync()) { l.enter(); try { a = document_createAttribute(d, name); } finally { l.exit(); }  }
/*  760 */     else { synchronized (l) { l.enter(); try { a = document_createAttribute(d, name); } finally { l.exit(); }  }
/*      */        }
/*  762 */      return (Attr)a;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_createAttribute(Dom d, String name) {
/*  767 */     validateName(name);
/*      */     
/*  769 */     Locale l = d.locale();
/*      */     
/*  771 */     Cur c = l.tempCur();
/*      */     
/*  773 */     c.createAttr(l.makeQualifiedQName("", name));
/*      */     
/*  775 */     Dom e = c.getDom();
/*      */     
/*  777 */     c.release();
/*  778 */     ((Xobj.AttrXobj)e)._canHavePrefixUri = false;
/*  779 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Attr _document_createAttributeNS(Dom d, String uri, String qname) {
/*      */     Dom a;
/*  788 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/*  792 */     if (l.noSync()) { l.enter(); try { a = document_createAttributeNS(d, uri, qname); } finally { l.exit(); }  }
/*  793 */     else { synchronized (l) { l.enter(); try { a = document_createAttributeNS(d, uri, qname); } finally { l.exit(); }  }
/*      */        }
/*  795 */      return (Attr)a;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_createAttributeNS(Dom d, String uri, String qname) {
/*  800 */     validateQualifiedName(qname, uri, true);
/*      */     
/*  802 */     Locale l = d.locale();
/*      */     
/*  804 */     Cur c = l.tempCur();
/*      */     
/*  806 */     c.createAttr(l.makeQualifiedQName(uri, qname));
/*      */     
/*  808 */     Dom e = c.getDom();
/*      */     
/*  810 */     c.release();
/*      */     
/*  812 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Comment _document_createComment(Dom d, String data) {
/*      */     Dom c;
/*  821 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/*  825 */     if (l.noSync()) { l.enter(); try { c = document_createComment(d, data); } finally { l.exit(); }  }
/*  826 */     else { synchronized (l) { l.enter(); try { c = document_createComment(d, data); } finally { l.exit(); }  }
/*      */        }
/*  828 */      return (Comment)c;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_createComment(Dom d, String data) {
/*  833 */     Locale l = d.locale();
/*      */     
/*  835 */     Cur c = l.tempCur();
/*      */     
/*  837 */     c.createComment();
/*      */     
/*  839 */     Dom comment = c.getDom();
/*      */     
/*  841 */     if (data != null) {
/*      */       
/*  843 */       c.next();
/*  844 */       c.insertString(data);
/*      */     } 
/*      */     
/*  847 */     c.release();
/*      */     
/*  849 */     return comment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ProcessingInstruction _document_createProcessingInstruction(Dom d, String target, String data) {
/*      */     Dom pi;
/*  858 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/*  862 */     if (l.noSync()) { l.enter(); try { pi = document_createProcessingInstruction(d, target, data); } finally { l.exit(); }  }
/*  863 */     else { synchronized (l) { l.enter(); try { pi = document_createProcessingInstruction(d, target, data); } finally { l.exit(); }  }
/*      */        }
/*  865 */      return (ProcessingInstruction)pi;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_createProcessingInstruction(Dom d, String target, String data) {
/*  870 */     if (target == null) {
/*  871 */       throw new IllegalArgumentException("Target is null");
/*      */     }
/*  873 */     if (target.length() == 0) {
/*  874 */       throw new IllegalArgumentException("Target is empty");
/*      */     }
/*  876 */     if (!XMLChar.isValidName(target)) {
/*  877 */       throw new InvalidCharacterError("Target has an invalid character");
/*      */     }
/*  879 */     if (Locale.beginsWithXml(target) && target.length() == 3) {
/*  880 */       throw new InvalidCharacterError("Invalid target - is 'xml'");
/*      */     }
/*  882 */     Locale l = d.locale();
/*      */     
/*  884 */     Cur c = l.tempCur();
/*      */     
/*  886 */     c.createProcinst(target);
/*      */     
/*  888 */     Dom pi = c.getDom();
/*      */     
/*  890 */     if (data != null) {
/*      */       
/*  892 */       c.next();
/*  893 */       c.insertString(data);
/*      */     } 
/*      */     
/*  896 */     c.release();
/*      */     
/*  898 */     return pi;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CDATASection _document_createCDATASection(Dom d, String data) {
/*  907 */     return (CDATASection)document_createCDATASection(d, data);
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_createCDATASection(Dom d, String data) {
/*  912 */     TextNode t = d.locale().createCdataNode();
/*      */     
/*  914 */     if (data == null) {
/*  915 */       data = "";
/*      */     }
/*  917 */     t.setChars(data, 0, data.length());
/*      */     
/*  919 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Text _document_createTextNode(Dom d, String data) {
/*  928 */     return (Text)document_createTextNode(d, data);
/*      */   }
/*      */ 
/*      */   
/*      */   public static CharNode document_createTextNode(Dom d, String data) {
/*  933 */     TextNode t = d.locale().createTextNode();
/*      */     
/*  935 */     if (data == null) {
/*  936 */       data = "";
/*      */     }
/*  938 */     t.setChars(data, 0, data.length());
/*      */     
/*  940 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static EntityReference _document_createEntityReference(Dom d, String name) {
/*  949 */     throw new RuntimeException("Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element _document_getElementById(Dom d, String elementId) {
/*  958 */     throw new RuntimeException("Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NodeList _document_getElementsByTagName(Dom d, String name) {
/*  967 */     Locale l = d.locale();
/*      */     
/*  969 */     if (l.noSync()) { l.enter(); try { return document_getElementsByTagName(d, name); } finally { l.exit(); }  }
/*  970 */      synchronized (l) { l.enter(); try { return document_getElementsByTagName(d, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static NodeList document_getElementsByTagName(Dom d, String name) {
/*  975 */     return new ElementsByTagNameNodeList(d, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NodeList _document_getElementsByTagNameNS(Dom d, String uri, String local) {
/*  984 */     Locale l = d.locale();
/*      */     
/*  986 */     if (l.noSync()) { l.enter(); try { return document_getElementsByTagNameNS(d, uri, local); } finally { l.exit(); }  }
/*  987 */      synchronized (l) { l.enter(); try { return document_getElementsByTagNameNS(d, uri, local); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static NodeList document_getElementsByTagNameNS(Dom d, String uri, String local) {
/*  992 */     return new ElementsByTagNameNSNodeList(d, uri, local);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DOMImplementation _document_getImplementation(Dom d) {
/* 1001 */     return d.locale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _document_importNode(Dom d, Node n, boolean deep) {
/*      */     Dom i;
/* 1010 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1019 */     if (l.noSync()) { l.enter(); try { i = document_importNode(d, n, deep); } finally { l.exit(); }  }
/* 1020 */     else { synchronized (l) { l.enter(); try { i = document_importNode(d, n, deep); } finally { l.exit(); }
/*      */          }
/*      */        }
/* 1023 */      return (Node)i; } public static Dom document_importNode(Dom d, Node n, boolean deep) {
/*      */     Dom i;
/*      */     String local;
/*      */     NamedNodeMap attrs;
/*      */     int a;
/* 1028 */     if (n == null) {
/* 1029 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1033 */     boolean copyChildren = false;
/*      */     
/* 1035 */     switch (n.getNodeType()) {
/*      */       
/*      */       case 9:
/* 1038 */         throw new NotSupportedError("Document nodes may not be imported");
/*      */       
/*      */       case 10:
/* 1041 */         throw new NotSupportedError("Document type nodes may not be imported");
/*      */ 
/*      */       
/*      */       case 1:
/* 1045 */         local = n.getLocalName();
/*      */         
/* 1047 */         if (local == null || local.length() == 0) {
/* 1048 */           i = document_createElement(d, n.getNodeName());
/*      */         } else {
/*      */           
/* 1051 */           String prefix = n.getPrefix();
/* 1052 */           String name = (prefix == null || prefix.length() == 0) ? local : (prefix + ":" + local);
/* 1053 */           String uri = n.getNamespaceURI();
/*      */           
/* 1055 */           if (uri == null || uri.length() == 0) {
/* 1056 */             i = document_createElement(d, name);
/*      */           } else {
/* 1058 */             i = document_createElementNS(d, uri, name);
/*      */           } 
/*      */         } 
/* 1061 */         attrs = n.getAttributes();
/*      */         
/* 1063 */         for (a = 0; a < attrs.getLength(); a++) {
/* 1064 */           attributes_setNamedItem(i, document_importNode(d, attrs.item(a), true));
/*      */         }
/* 1066 */         copyChildren = deep;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 1073 */         local = n.getLocalName();
/*      */         
/* 1075 */         if (local == null || local.length() == 0) {
/* 1076 */           i = document_createAttribute(d, n.getNodeName());
/*      */         } else {
/*      */           
/* 1079 */           String prefix = n.getPrefix();
/* 1080 */           String name = (prefix == null || prefix.length() == 0) ? local : (prefix + ":" + local);
/* 1081 */           String uri = n.getNamespaceURI();
/*      */           
/* 1083 */           if (uri == null || uri.length() == 0) {
/* 1084 */             i = document_createAttribute(d, name);
/*      */           } else {
/* 1086 */             i = document_createAttributeNS(d, uri, name);
/*      */           } 
/*      */         } 
/* 1089 */         copyChildren = true;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 11:
/* 1096 */         i = document_createDocumentFragment(d);
/*      */         
/* 1098 */         copyChildren = deep;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/* 1105 */         i = document_createProcessingInstruction(d, n.getNodeName(), n.getNodeValue());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/* 1111 */         i = document_createComment(d, n.getNodeValue());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 1117 */         i = document_createTextNode(d, n.getNodeValue());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/* 1123 */         i = document_createCDATASection(d, n.getNodeValue());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 5:
/*      */       case 6:
/*      */       case 12:
/* 1130 */         throw new RuntimeException("Not impl");
/*      */       default:
/* 1132 */         throw new RuntimeException("Unknown kind");
/*      */     } 
/*      */     
/* 1135 */     if (copyChildren) {
/*      */       
/* 1137 */       NodeList children = n.getChildNodes();
/*      */       
/* 1139 */       for (int c = 0; c < children.getLength(); c++) {
/* 1140 */         node_insertBefore(i, document_importNode(d, children.item(c), true), null);
/*      */       }
/*      */     } 
/* 1143 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DocumentType _document_getDoctype(Dom d) {
/*      */     Dom dt;
/* 1152 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/* 1156 */     if (l.noSync()) { l.enter(); try { dt = document_getDoctype(d); } finally { l.exit(); }  }
/* 1157 */     else { synchronized (l) { l.enter(); try { dt = document_getDoctype(d); } finally { l.exit(); }  }
/*      */        }
/* 1159 */      return (DocumentType)dt;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom document_getDoctype(Dom d) {
/* 1164 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document _node_getOwnerDocument(Dom n) {
/*      */     Dom d;
/* 1173 */     Locale l = n.locale();
/*      */ 
/*      */ 
/*      */     
/* 1177 */     if (l.noSync()) { l.enter(); try { d = node_getOwnerDocument(n); } finally { l.exit(); }  }
/* 1178 */     else { synchronized (l) { l.enter(); try { d = node_getOwnerDocument(n); } finally { l.exit(); }  }
/*      */        }
/* 1180 */      return (Document)d;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom node_getOwnerDocument(Dom n) {
/* 1185 */     if (n.nodeType() == 9) {
/* 1186 */       return null;
/*      */     }
/* 1188 */     Locale l = n.locale();
/*      */     
/* 1190 */     if (l._ownerDoc == null) {
/*      */       
/* 1192 */       Cur c = l.tempCur();
/* 1193 */       c.createDomDocumentRoot();
/* 1194 */       l._ownerDoc = c.getDom();
/* 1195 */       c.release();
/*      */     } 
/*      */     
/* 1198 */     return l._ownerDoc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _node_getParentNode(Dom n) {
/*      */     Dom p;
/* 1207 */     Locale l = n.locale();
/*      */ 
/*      */ 
/*      */     
/* 1211 */     if (l.noSync()) { l.enter(); try { p = node_getParentNode(n); } finally { l.exit(); }  }
/* 1212 */     else { synchronized (l) { l.enter(); try { p = node_getParentNode(n); } finally { l.exit(); }  }
/*      */        }
/* 1214 */      return (Node)p;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom node_getParentNode(Dom n) {
/* 1219 */     Cur c = null;
/*      */     
/* 1221 */     switch (n.nodeType()) {
/*      */       case 2:
/*      */       case 9:
/*      */       case 11:
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 7:
/*      */       case 8:
/* 1232 */         if (!(c = n.tempCur()).toParentRaw()) {
/*      */           
/* 1234 */           c.release();
/* 1235 */           c = null;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 4:
/* 1244 */         if ((c = n.tempCur()) != null) {
/* 1245 */           c.toParent();
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 5:
/* 1251 */         throw new RuntimeException("Not impl");
/*      */       
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/* 1256 */         throw new RuntimeException("Not impl");
/*      */       default:
/* 1258 */         throw new RuntimeException("Unknown kind");
/*      */     } 
/*      */     
/* 1261 */     if (c == null) {
/* 1262 */       return null;
/*      */     }
/* 1264 */     Dom d = c.getDom();
/*      */     
/* 1266 */     c.release();
/*      */     
/* 1268 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _node_getFirstChild(Dom n) {
/*      */     Dom fc;
/* 1277 */     Locale l = n.locale();
/*      */ 
/*      */     
/* 1280 */     assert n instanceof Xobj;
/* 1281 */     Xobj node = (Xobj)n;
/* 1282 */     if (!node.isVacant()) {
/*      */       
/* 1284 */       if (node.isFirstChildPtrDomUsable())
/* 1285 */         return (Node)node._firstChild; 
/* 1286 */       Xobj lastAttr = node.lastAttr();
/* 1287 */       if (lastAttr != null && lastAttr.isNextSiblingPtrDomUsable())
/*      */       {
/* 1289 */         return (Xobj.NodeXobj)lastAttr._nextSibling; } 
/* 1290 */       if (node.isExistingCharNodesValueUsable())
/* 1291 */         return node._charNodesValue; 
/*      */     } 
/* 1293 */     if (l.noSync()) { fc = node_getFirstChild(n); }
/* 1294 */     else { synchronized (l) { fc = node_getFirstChild(n); }
/*      */        }
/* 1296 */      return (Node)fc;
/*      */   }
/*      */   
/*      */   public static Dom node_getFirstChild(Dom n) {
/*      */     Xobj node, lastAttr;
/* 1301 */     Dom fc = null;
/*      */     
/* 1303 */     switch (n.nodeType()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/* 1312 */         throw new RuntimeException("Not impl");
/*      */       
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/* 1317 */         throw new RuntimeException("Not impl");
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/*      */       case 9:
/*      */       case 11:
/* 1325 */         node = (Xobj)n;
/* 1326 */         node.ensureOccupancy();
/* 1327 */         if (node.isFirstChildPtrDomUsable())
/* 1328 */           return (Xobj.NodeXobj)node._firstChild; 
/* 1329 */         lastAttr = node.lastAttr();
/* 1330 */         if (lastAttr != null) {
/*      */           
/* 1332 */           if (lastAttr.isNextSiblingPtrDomUsable())
/* 1333 */             return (Xobj.NodeXobj)lastAttr._nextSibling; 
/* 1334 */           if (lastAttr.isCharNodesAfterUsable())
/* 1335 */             return lastAttr._charNodesAfter; 
/*      */         } 
/* 1337 */         if (node.isCharNodesValueUsable()) {
/* 1338 */           return node._charNodesValue;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1347 */     return fc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _node_getLastChild(Dom n) {
/*      */     Dom lc;
/* 1356 */     Locale l = n.locale();
/*      */ 
/*      */ 
/*      */     
/* 1360 */     if (l.noSync()) { l.enter(); try { lc = node_getLastChild(n); } finally { l.exit(); }  }
/* 1361 */     else { synchronized (l) { l.enter(); try { lc = node_getLastChild(n); } finally { l.exit(); }  }
/*      */        }
/* 1363 */      return (Node)lc;
/*      */   }
/*      */   
/*      */   public static Dom node_getLastChild(Dom n) {
/*      */     CharNode nodes;
/* 1368 */     switch (n.nodeType()) {
/*      */       
/*      */       case 3:
/*      */       case 4:
/*      */       case 7:
/*      */       case 8:
/* 1374 */         return null;
/*      */       
/*      */       case 5:
/* 1377 */         throw new RuntimeException("Not impl");
/*      */       
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/* 1382 */         throw new RuntimeException("Not impl");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1391 */     Dom lc = null;
/*      */ 
/*      */     
/* 1394 */     Cur c = n.tempCur();
/*      */     
/* 1396 */     if (c.toLastChild()) {
/*      */       
/* 1398 */       lc = c.getDom();
/*      */       
/* 1400 */       c.skip();
/*      */       
/* 1402 */       if ((nodes = c.getCharNodes()) != null) {
/* 1403 */         lc = null;
/*      */       }
/*      */     } else {
/*      */       
/* 1407 */       c.next();
/* 1408 */       nodes = c.getCharNodes();
/*      */     } 
/*      */     
/* 1411 */     if (lc == null && nodes != null) {
/*      */       
/* 1413 */       while (nodes._next != null) {
/* 1414 */         nodes = nodes._next;
/*      */       }
/* 1416 */       lc = nodes;
/*      */     } 
/*      */     
/* 1419 */     c.release();
/*      */ 
/*      */ 
/*      */     
/* 1423 */     return lc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _node_getNextSibling(Dom n) {
/*      */     Dom ns;
/* 1432 */     Locale l = n.locale();
/*      */ 
/*      */ 
/*      */     
/* 1436 */     if (l.noSync()) { ns = node_getNextSibling(n); }
/* 1437 */     else { synchronized (l) { ns = node_getNextSibling(n); }
/*      */        }
/* 1439 */      return (Node)ns;
/*      */   } public static Dom node_getNextSibling(Dom n) {
/*      */     CharNode cn;
/*      */     Xobj node, src;
/*      */     boolean isThisNodeAfterText;
/* 1444 */     Dom ns = null;
/*      */     
/* 1446 */     switch (n.nodeType()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 4:
/* 1456 */         cn = (CharNode)n;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1463 */         if (!(cn._src instanceof Xobj))
/* 1464 */           return null; 
/* 1465 */         src = (Xobj)cn._src;
/*      */ 
/*      */         
/* 1468 */         src._charNodesAfter = Cur.updateCharNodes(src._locale, src, src._charNodesAfter, src._cchAfter);
/*      */ 
/*      */         
/* 1471 */         src._charNodesValue = Cur.updateCharNodes(src._locale, src, src._charNodesValue, src._cchValue);
/*      */ 
/*      */         
/* 1474 */         if (cn._next != null) {
/*      */           
/* 1476 */           ns = cn._next;
/*      */           break;
/*      */         } 
/* 1479 */         isThisNodeAfterText = cn.isNodeAftertext();
/*      */         
/* 1481 */         if (isThisNodeAfterText) {
/* 1482 */           ns = (Xobj.NodeXobj)src._nextSibling; break;
/*      */         } 
/* 1484 */         ns = (Xobj.NodeXobj)src._firstChild;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 7:
/*      */       case 8:
/* 1493 */         assert n instanceof Xobj : "PI, Comments and Elements always backed up by Xobj";
/* 1494 */         node = (Xobj)n;
/* 1495 */         node.ensureOccupancy();
/* 1496 */         if (node.isNextSiblingPtrDomUsable()) {
/* 1497 */           return (Xobj.NodeXobj)node._nextSibling;
/*      */         }
/* 1499 */         if (node.isCharNodesAfterUsable()) {
/* 1500 */           return node._charNodesAfter;
/*      */         }
/*      */         break;
/*      */       
/*      */       case 5:
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/* 1508 */         throw new RuntimeException("Not implemented");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1513 */     return ns;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _node_getPreviousSibling(Dom n) {
/*      */     Dom ps;
/* 1522 */     Locale l = n.locale();
/*      */ 
/*      */ 
/*      */     
/* 1526 */     if (l.noSync()) { ps = node_getPreviousSibling(n); }
/* 1527 */     else { synchronized (l) { ps = node_getPreviousSibling(n); }
/*      */        }
/* 1529 */      return (Node)ps;
/*      */   } public static Dom node_getPreviousSibling(Dom n) {
/*      */     CharNode charNode;
/*      */     Xobj node, src;
/*      */     boolean isThisNodeAfterText;
/* 1534 */     Dom prev = null;
/*      */     
/* 1536 */     switch (n.nodeType()) {
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 4:
/* 1541 */         assert n instanceof CharNode : "Text/CData should be a CharNode";
/* 1542 */         charNode = (CharNode)n;
/* 1543 */         if (!(charNode._src instanceof Xobj))
/* 1544 */           return null; 
/* 1545 */         src = (Xobj)charNode._src;
/* 1546 */         src.ensureOccupancy();
/* 1547 */         isThisNodeAfterText = charNode.isNodeAftertext();
/* 1548 */         prev = charNode._prev;
/* 1549 */         if (prev == null) {
/* 1550 */           prev = isThisNodeAfterText ? (Dom)src : src._charNodesValue;
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1556 */         assert n instanceof Xobj;
/* 1557 */         node = (Xobj)n;
/* 1558 */         prev = (Dom)node._prevSibling;
/* 1559 */         if (prev == null && node._parent != null)
/* 1560 */           prev = node_getFirstChild((Dom)node._parent); 
/*      */         break;
/*      */     } 
/* 1563 */     Dom temp = prev;
/*      */     
/* 1565 */     while (temp != null && (temp = node_getNextSibling(temp)) != n)
/* 1566 */       prev = temp; 
/* 1567 */     return prev;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _node_hasAttributes(Dom n) {
/* 1576 */     Locale l = n.locale();
/*      */     
/* 1578 */     if (l.noSync()) { l.enter(); try { return node_hasAttributes(n); } finally { l.exit(); }  }
/* 1579 */      synchronized (l) { l.enter(); try { return node_hasAttributes(n); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static boolean node_hasAttributes(Dom n) {
/* 1584 */     boolean hasAttrs = false;
/*      */     
/* 1586 */     if (n.nodeType() == 1) {
/*      */       
/* 1588 */       Cur c = n.tempCur();
/*      */       
/* 1590 */       hasAttrs = c.hasAttrs();
/*      */       
/* 1592 */       c.release();
/*      */     } 
/*      */     
/* 1595 */     return hasAttrs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _node_isSupported(Dom n, String feature, String version) {
/* 1604 */     return _domImplementation_hasFeature(n.locale(), feature, version);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _node_normalize(Dom n) {
/* 1613 */     Locale l = n.locale();
/*      */     
/* 1615 */     if (l.noSync()) { l.enter(); try { node_normalize(n); } finally { l.exit(); }  }
/* 1616 */     else { synchronized (l) { l.enter(); try { node_normalize(n); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void node_normalize(Dom n) {
/* 1621 */     switch (n.nodeType()) {
/*      */       case 3:
/*      */       case 4:
/*      */       case 7:
/*      */       case 8:
/*      */         return;
/*      */ 
/*      */       
/*      */       case 5:
/* 1630 */         throw new RuntimeException("Not impl");
/*      */       
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/* 1635 */         throw new RuntimeException("Not impl");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1644 */     Cur c = n.tempCur();
/*      */     
/* 1646 */     c.push();
/*      */ 
/*      */     
/*      */     do {
/* 1650 */       c.nextWithAttrs();
/*      */       
/* 1652 */       CharNode cn = c.getCharNodes();
/*      */       
/* 1654 */       if (cn == null)
/*      */         continue; 
/* 1656 */       if (!c.isText()) {
/*      */         
/* 1658 */         while (cn != null)
/*      */         {
/* 1660 */           cn.setChars(null, 0, 0);
/* 1661 */           cn = CharNode.remove(cn, cn);
/*      */         }
/*      */       
/* 1664 */       } else if (cn._next != null) {
/*      */         
/* 1666 */         while (cn._next != null) {
/*      */           
/* 1668 */           cn.setChars(null, 0, 0);
/* 1669 */           cn = CharNode.remove(cn, cn._next);
/*      */         } 
/*      */         
/* 1672 */         cn._cch = Integer.MAX_VALUE;
/*      */       } 
/*      */       
/* 1675 */       c.setCharNodes(cn);
/*      */     
/*      */     }
/* 1678 */     while (!c.isAtEndOfLastPush());
/*      */     
/* 1680 */     c.release();
/*      */     
/* 1682 */     n.locale().invalidateDomCaches(n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _node_hasChildNodes(Dom n) {
/* 1692 */     return (_node_getFirstChild(n) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _node_appendChild(Dom p, Node newChild) {
/* 1701 */     return _node_insertBefore(p, newChild, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _node_replaceChild(Dom p, Node newChild, Node oldChild) {
/*      */     Dom d;
/* 1710 */     Locale l = p.locale();
/*      */     
/* 1712 */     if (newChild == null) {
/* 1713 */       throw new IllegalArgumentException("Child to add is null");
/*      */     }
/* 1715 */     if (oldChild == null) {
/* 1716 */       throw new NotFoundErr("Child to replace is null");
/*      */     }
/*      */     
/*      */     Dom nc;
/* 1720 */     if (!(newChild instanceof Dom) || (nc = (Dom)newChild).locale() != l) {
/* 1721 */       throw new WrongDocumentErr("Child to add is from another document");
/*      */     }
/* 1723 */     Dom oc = null;
/*      */     
/* 1725 */     if (!(oldChild instanceof Dom) || (oc = (Dom)oldChild).locale() != l) {
/* 1726 */       throw new WrongDocumentErr("Child to replace is from another document");
/*      */     }
/*      */ 
/*      */     
/* 1730 */     if (l.noSync()) { l.enter(); try { d = node_replaceChild(p, nc, oc); } finally { l.exit(); }  }
/* 1731 */     else { synchronized (l) { l.enter(); try { d = node_replaceChild(p, nc, oc); } finally { l.exit(); }  }
/*      */        }
/* 1733 */      return (Node)d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Dom node_replaceChild(Dom p, Dom newChild, Dom oldChild) {
/* 1741 */     Dom nextNode = node_getNextSibling(oldChild);
/*      */     
/* 1743 */     node_removeChild(p, oldChild);
/*      */ 
/*      */     
/*      */     try {
/* 1747 */       node_insertBefore(p, newChild, nextNode);
/*      */     }
/* 1749 */     catch (DOMException e) {
/*      */       
/* 1751 */       node_insertBefore(p, oldChild, nextNode);
/*      */       
/* 1753 */       throw e;
/*      */     } 
/*      */     
/* 1756 */     return oldChild;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _node_insertBefore(Dom p, Node newChild, Node refChild) {
/*      */     Dom d;
/* 1765 */     Locale l = p.locale();
/*      */     
/* 1767 */     if (newChild == null) {
/* 1768 */       throw new IllegalArgumentException("Child to add is null");
/*      */     }
/*      */     
/*      */     Dom nc;
/* 1772 */     if (!(newChild instanceof Dom) || (nc = (Dom)newChild).locale() != l) {
/* 1773 */       throw new WrongDocumentErr("Child to add is from another document");
/*      */     }
/* 1775 */     Dom rc = null;
/*      */     
/* 1777 */     if (refChild != null)
/*      */     {
/* 1779 */       if (!(refChild instanceof Dom) || (rc = (Dom)refChild).locale() != l) {
/* 1780 */         throw new WrongDocumentErr("Reference child is from another document");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/* 1785 */     if (l.noSync()) { l.enter(); try { d = node_insertBefore(p, nc, rc); } finally { l.exit(); }  }
/* 1786 */     else { synchronized (l) { l.enter(); try { d = node_insertBefore(p, nc, rc); } finally { l.exit(); }  }
/*      */        }
/* 1788 */      return (Node)d;
/*      */   } public static Dom node_insertBefore(Dom p, Dom nc, Dom rc) {
/*      */     CharNode n, refCharNode;
/*      */     Cur c;
/*      */     CharNode nodes;
/* 1793 */     assert nc != null;
/*      */ 
/*      */ 
/*      */     
/* 1797 */     if (nc == rc) {
/* 1798 */       return nc;
/*      */     }
/* 1800 */     if (rc != null && parent(rc) != p) {
/* 1801 */       throw new NotFoundErr("RefChild is not a child of this node");
/*      */     }
/*      */ 
/*      */     
/* 1805 */     int nck = nc.nodeType();
/*      */     
/* 1807 */     if (nck == 11) {
/*      */       Dom dom;
/* 1809 */       for (dom = firstChild(nc); dom != null; dom = nextSibling(dom)) {
/* 1810 */         validateNewChild(p, dom);
/*      */       }
/* 1812 */       for (dom = firstChild(nc); dom != null; ) {
/*      */         
/* 1814 */         Dom dom1 = nextSibling(dom);
/*      */         
/* 1816 */         if (rc == null) {
/* 1817 */           append(dom, p);
/*      */         } else {
/* 1819 */           insert(dom, rc);
/*      */         } 
/* 1821 */         dom = dom1;
/*      */       } 
/*      */       
/* 1824 */       return nc;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1831 */     validateNewChild(p, nc);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1837 */     remove(nc);
/*      */     
/* 1839 */     int pk = p.nodeType();
/*      */ 
/*      */     
/* 1842 */     assert pk == 2 || pk == 11 || pk == 9 || pk == 1;
/*      */     
/* 1844 */     switch (nck) {
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 7:
/*      */       case 8:
/* 1850 */         if (rc == null) {
/*      */           
/* 1852 */           Cur cTo = p.tempCur();
/* 1853 */           cTo.toEnd();
/* 1854 */           Cur.moveNode((Xobj)nc, cTo);
/* 1855 */           cTo.release();
/*      */         }
/*      */         else {
/*      */           
/* 1859 */           int rck = rc.nodeType();
/*      */           
/* 1861 */           if (rck == 3 || rck == 4)
/*      */           
/*      */           { 
/*      */             
/* 1865 */             ArrayList charNodes = new ArrayList();
/*      */             
/* 1867 */             while (rc != null && (rc.nodeType() == 3 || rc.nodeType() == 4)) {
/*      */               
/* 1869 */               Dom next = nextSibling(rc);
/* 1870 */               charNodes.add(remove(rc));
/* 1871 */               rc = next;
/*      */             } 
/*      */             
/* 1874 */             if (rc == null) {
/* 1875 */               append(nc, p);
/*      */             } else {
/* 1877 */               insert(nc, rc);
/*      */             } 
/* 1879 */             rc = nextSibling(nc);
/*      */             
/* 1881 */             for (int i = 0; i < charNodes.size(); i++) {
/*      */               
/* 1883 */               Dom dom = charNodes.get(i);
/*      */               
/* 1885 */               if (rc == null) {
/* 1886 */                 append(dom, p);
/*      */               } else {
/* 1888 */                 insert(dom, rc);
/*      */               } 
/*      */             }  }
/* 1891 */           else { if (rck == 5)
/*      */             {
/* 1893 */               throw new RuntimeException("Not implemented");
/*      */             }
/*      */ 
/*      */             
/* 1897 */             assert rck == 1 || rck == 7 || rck == 8;
/* 1898 */             Cur cTo = rc.tempCur();
/* 1899 */             Cur.moveNode((Xobj)nc, cTo);
/* 1900 */             cTo.release(); }
/*      */         
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1961 */         return nc;case 3: case 4: n = (CharNode)nc; assert n._prev == null && n._next == null; refCharNode = null; c = p.tempCur(); if (rc == null) { c.toEnd(); } else { int rck = rc.nodeType(); if (rck == 3 || rck == 4) { c.moveToCharNode(refCharNode = (CharNode)rc); } else { if (rck == 5) throw new RuntimeException("Not implemented");  c.moveToDom(rc); }  }  nodes = c.getCharNodes(); nodes = CharNode.insertNode(nodes, n, refCharNode); c.insertChars(n._src, n._off, n._cch); c.setCharNodes(nodes); c.release(); return nc;
/*      */       case 5:
/*      */         throw new RuntimeException("Not implemented");
/*      */       case 10:
/*      */         throw new RuntimeException("Not implemented");
/*      */     } 
/*      */     throw new RuntimeException("Unexpected child node type");
/*      */   } public static Node _node_removeChild(Dom p, Node child) {
/*      */     Dom d;
/* 1970 */     Locale l = p.locale();
/*      */     
/* 1972 */     if (child == null) {
/* 1973 */       throw new NotFoundErr("Child to remove is null");
/*      */     }
/*      */     
/*      */     Dom c;
/* 1977 */     if (!(child instanceof Dom) || (c = (Dom)child).locale() != l) {
/* 1978 */       throw new WrongDocumentErr("Child to remove is from another document");
/*      */     }
/*      */ 
/*      */     
/* 1982 */     if (l.noSync()) { l.enter(); try { d = node_removeChild(p, c); } finally { l.exit(); }  }
/* 1983 */     else { synchronized (l) { l.enter(); try { d = node_removeChild(p, c); } finally { l.exit(); }  }
/*      */        }
/* 1985 */      return (Node)d;
/*      */   }
/*      */   public static Dom node_removeChild(Dom parent, Dom child) { Cur c;
/*      */     CharNode nodes;
/*      */     CharNode cn;
/* 1990 */     if (parent(child) != parent) {
/* 1991 */       throw new NotFoundErr("Child to remove is not a child of given parent");
/*      */     }
/* 1993 */     switch (child.nodeType()) {
/*      */       
/*      */       case 2:
/*      */       case 9:
/*      */       case 11:
/* 1998 */         throw new IllegalStateException();
/*      */       
/*      */       case 1:
/*      */       case 7:
/*      */       case 8:
/* 2003 */         removeNode(child);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2037 */         return child;case 3: case 4: c = child.tempCur(); nodes = c.getCharNodes(); cn = (CharNode)child; assert cn._src instanceof Dom; cn.setChars(c.moveChars(null, cn._cch), c._offSrc, c._cchSrc); c.setCharNodes(CharNode.remove(nodes, cn)); c.release(); return child;
/*      */       case 5:
/*      */         throw new RuntimeException("Not impl");
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/*      */         throw new RuntimeException("Not impl");
/*      */     } 
/*      */     throw new RuntimeException("Unknown kind"); } public static Node _node_cloneNode(Dom n, boolean deep) { Dom c;
/* 2046 */     Locale l = n.locale();
/*      */ 
/*      */ 
/*      */     
/* 2050 */     if (l.noSync()) { l.enter(); try { c = node_cloneNode(n, deep); } finally { l.exit(); }  }
/* 2051 */     else { synchronized (l) { l.enter(); try { c = node_cloneNode(n, deep); } finally { l.exit(); }  }
/*      */        }
/* 2053 */      return (Node)c; }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Dom node_cloneNode(Dom n, boolean deep) {
/* 2058 */     Locale l = n.locale();
/*      */     
/* 2060 */     Dom clone = null;
/*      */     
/* 2062 */     if (!deep) {
/*      */       Element elem; NamedNodeMap attrs; int i;
/* 2064 */       Cur shallow = null;
/*      */       
/* 2066 */       switch (n.nodeType()) {
/*      */         
/*      */         case 9:
/* 2069 */           shallow = l.tempCur();
/* 2070 */           shallow.createDomDocumentRoot();
/*      */           break;
/*      */         
/*      */         case 11:
/* 2074 */           shallow = l.tempCur();
/* 2075 */           shallow.createDomDocFragRoot();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1:
/* 2080 */           shallow = l.tempCur();
/* 2081 */           shallow.createElement(n.getQName());
/*      */           
/* 2083 */           elem = (Element)shallow.getDom();
/* 2084 */           attrs = ((Element)n).getAttributes();
/*      */           
/* 2086 */           for (i = 0; i < attrs.getLength(); i++) {
/* 2087 */             elem.setAttributeNodeNS((Attr)attrs.item(i).cloneNode(true));
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/* 2093 */           shallow = l.tempCur();
/* 2094 */           shallow.createAttr(n.getQName());
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2108 */       if (shallow != null) {
/*      */         
/* 2110 */         clone = shallow.getDom();
/* 2111 */         shallow.release();
/*      */       } 
/*      */     } 
/*      */     
/* 2115 */     if (clone == null)
/*      */     { Cur cClone; Cur c; Cur cSrc; CharNode cn;
/* 2117 */       switch (n.nodeType())
/*      */       
/*      */       { 
/*      */         case 1:
/*      */         case 2:
/*      */         case 7:
/*      */         case 8:
/*      */         case 9:
/*      */         case 11:
/* 2126 */           cClone = l.tempCur();
/* 2127 */           cSrc = n.tempCur();
/* 2128 */           cSrc.copyNode(cClone);
/* 2129 */           clone = cClone.getDom();
/* 2130 */           cClone.release();
/* 2131 */           cSrc.release();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2162 */           return clone;case 3: case 4: c = n.tempCur(); cn = (n.nodeType() == 3) ? l.createTextNode() : l.createCdataNode(); cn.setChars(c.getChars(((CharNode)n)._cch), c._offSrc, c._cchSrc); clone = cn; c.release(); return clone;case 5: case 6: case 10: case 12: throw new RuntimeException("Not impl"); }  throw new RuntimeException("Unknown kind"); }  return clone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_getLocalName(Dom n) {
/* 2171 */     if (!n.nodeCanHavePrefixUri()) return null; 
/* 2172 */     QName name = n.getQName();
/* 2173 */     return (name == null) ? "" : name.getLocalPart();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_getNamespaceURI(Dom n) {
/* 2182 */     if (!n.nodeCanHavePrefixUri()) return null; 
/* 2183 */     QName name = n.getQName();
/*      */     
/* 2185 */     return (name == null) ? "" : name.getNamespaceURI();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _node_setPrefix(Dom n, String prefix) {
/* 2196 */     Locale l = n.locale();
/*      */     
/* 2198 */     if (l.noSync()) { l.enter(); try { node_setPrefix(n, prefix); } finally { l.exit(); }  }
/* 2199 */     else { synchronized (l) { l.enter(); try { node_setPrefix(n, prefix); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void node_setPrefix(Dom n, String prefix) {
/* 2211 */     if (n.nodeType() == 1 || n.nodeType() == 2) {
/*      */       
/* 2213 */       Cur c = n.tempCur();
/* 2214 */       QName name = c.getName();
/* 2215 */       String uri = name.getNamespaceURI();
/* 2216 */       String local = name.getLocalPart();
/*      */       
/* 2218 */       prefix = validatePrefix(prefix, uri, local, (n.nodeType() == 2));
/*      */       
/* 2220 */       c.setName(n.locale().makeQName(uri, local, prefix));
/*      */       
/* 2222 */       c.release();
/*      */     } else {
/*      */       
/* 2225 */       validatePrefix(prefix, "", "", false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_getPrefix(Dom n) {
/* 2234 */     if (!n.nodeCanHavePrefixUri()) return null; 
/* 2235 */     QName name = n.getQName();
/* 2236 */     return (name == null) ? "" : name.getPrefix();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_getNodeName(Dom n) {
/*      */     QName name;
/*      */     String prefix;
/* 2246 */     switch (n.nodeType()) {
/*      */       case 4:
/* 2248 */         return "#cdata-section";
/* 2249 */       case 8: return "#comment";
/* 2250 */       case 11: return "#document-fragment";
/* 2251 */       case 9: return "#document";
/* 2252 */       case 7: return n.getQName().getLocalPart();
/* 2253 */       case 3: return "#text";
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/* 2258 */         name = n.getQName();
/* 2259 */         prefix = name.getPrefix();
/* 2260 */         return (prefix.length() == 0) ? name.getLocalPart() : (prefix + ":" + name.getLocalPart());
/*      */ 
/*      */       
/*      */       case 5:
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/* 2267 */         throw new RuntimeException("Not impl");
/*      */     } 
/* 2269 */     throw new RuntimeException("Unknown node type");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short _node_getNodeType(Dom n) {
/* 2279 */     return (short)n.nodeType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _node_setNodeValue(Dom n, String nodeValue) {
/* 2288 */     Locale l = n.locale();
/*      */     
/* 2290 */     if (l.noSync()) { l.enter(); try { node_setNodeValue(n, nodeValue); } finally { l.exit(); }  }
/* 2291 */     else { synchronized (l) { l.enter(); try { node_setNodeValue(n, nodeValue); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */      } public static void node_setNodeValue(Dom n, String nodeValue) { CharNode cn; NodeList children; Cur c;
/*      */     Cur cur1;
/* 2296 */     if (nodeValue == null) {
/* 2297 */       nodeValue = "";
/*      */     }
/* 2299 */     switch (n.nodeType()) {
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 4:
/* 2304 */         cn = (CharNode)n;
/*      */ 
/*      */ 
/*      */         
/* 2308 */         if ((cur1 = cn.tempCur()) != null) {
/*      */           
/* 2310 */           cur1.moveChars(null, cn._cch);
/* 2311 */           cn._cch = nodeValue.length();
/* 2312 */           cur1.insertString(nodeValue);
/* 2313 */           cur1.release();
/*      */           break;
/*      */         } 
/* 2316 */         cn.setChars(nodeValue, 0, nodeValue.length());
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 2325 */         children = ((Node)n).getChildNodes();
/*      */         
/* 2327 */         while (children.getLength() > 1) {
/* 2328 */           node_removeChild(n, (Dom)children.item(1));
/*      */         }
/* 2330 */         if (children.getLength() == 0) {
/*      */           
/* 2332 */           TextNode tn = n.locale().createTextNode();
/* 2333 */           tn.setChars(nodeValue, 0, nodeValue.length());
/* 2334 */           node_insertBefore(n, tn, null);
/*      */         }
/*      */         else {
/*      */           
/* 2338 */           assert children.getLength() == 1;
/* 2339 */           children.item(0).setNodeValue(nodeValue);
/*      */         } 
/* 2341 */         if (((Xobj.AttrXobj)n).isId()) {
/*      */           
/* 2343 */           Dom d = node_getOwnerDocument(n);
/* 2344 */           String val = node_getNodeValue(n);
/* 2345 */           if (d instanceof Xobj.DocumentXobj) {
/*      */             
/* 2347 */             ((Xobj.DocumentXobj)d).removeIdElement(val);
/* 2348 */             ((Xobj.DocumentXobj)d).addIdElement(nodeValue, attr_getOwnerElement(n));
/*      */           } 
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*      */       case 8:
/* 2359 */         c = n.tempCur();
/* 2360 */         c.next();
/*      */         
/* 2362 */         c.getChars(-1);
/* 2363 */         c.moveChars(null, c._cchSrc);
/* 2364 */         c.insertString(nodeValue);
/*      */         
/* 2366 */         c.release();
/*      */         break;
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_getNodeValue(Dom n) {
/* 2379 */     Locale l = n.locale();
/*      */     
/* 2381 */     if (l.noSync()) return node_getNodeValue(n); 
/* 2382 */     synchronized (l) { return node_getNodeValue(n); }
/*      */      } public static String node_getNodeValue(Dom n) {
/*      */     CharNode node;
/*      */     Xobj src;
/*      */     boolean isThisNodeAfterText;
/* 2387 */     String s = null;
/*      */     
/* 2389 */     switch (n.nodeType()) {
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 7:
/*      */       case 8:
/* 2395 */         s = ((Xobj)n).getValueAsString();
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 4:
/* 2402 */         assert n instanceof CharNode : "Text/CData should be a CharNode";
/* 2403 */         node = (CharNode)n;
/* 2404 */         if (!(node._src instanceof Xobj)) {
/* 2405 */           s = CharUtil.getString(node._src, node._off, node._cch); break;
/*      */         } 
/* 2407 */         src = (Xobj)node._src;
/* 2408 */         src.ensureOccupancy();
/* 2409 */         isThisNodeAfterText = node.isNodeAftertext();
/* 2410 */         if (isThisNodeAfterText) {
/* 2411 */           src._charNodesAfter = Cur.updateCharNodes(src._locale, src, src._charNodesAfter, src._cchAfter);
/*      */           
/* 2413 */           s = src.getCharsAfterAsString(node._off, node._cch);
/*      */           break;
/*      */         } 
/* 2416 */         src._charNodesValue = Cur.updateCharNodes(src._locale, src, src._charNodesValue, src._cchValue);
/*      */         
/* 2418 */         s = src.getCharsValueAsString(node._off, node._cch);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2426 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object _node_getUserData(Dom n, String key) {
/* 2435 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object _node_setUserData(Dom n, String key, Object data, UserDataHandler handler) {
/* 2444 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object _node_getFeature(Dom n, String feature, String version) {
/* 2453 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _node_isEqualNode(Dom n, Node arg) {
/* 2462 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _node_isSameNode(Dom n, Node arg) {
/* 2471 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_lookupNamespaceURI(Dom n, String prefix) {
/* 2480 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _node_isDefaultNamespace(Dom n, String namespaceURI) {
/* 2489 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_lookupPrefix(Dom n, String namespaceURI) {
/* 2498 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _node_setTextContent(Dom n, String textContent) {
/* 2507 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_getTextContent(Dom n) {
/* 2516 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short _node_compareDocumentPosition(Dom n, Node other) {
/* 2525 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _node_getBaseURI(Dom n) {
/* 2534 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _childNodes_item(Dom n, int i) {
/*      */     Dom d;
/* 2543 */     Locale l = n.locale();
/*      */ 
/*      */     
/* 2546 */     if (i == 0) return _node_getFirstChild(n); 
/* 2547 */     if (l.noSync()) { d = childNodes_item(n, i); }
/* 2548 */     else { synchronized (l) { d = childNodes_item(n, i); }
/*      */        }
/* 2550 */      return (Node)d;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom childNodes_item(Dom n, int i) {
/* 2555 */     if (i < 0) {
/* 2556 */       return null;
/*      */     }
/* 2558 */     switch (n.nodeType()) {
/*      */       
/*      */       case 3:
/*      */       case 4:
/*      */       case 7:
/*      */       case 8:
/* 2564 */         return null;
/*      */       
/*      */       case 5:
/* 2567 */         throw new RuntimeException("Not impl");
/*      */       
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/* 2572 */         throw new RuntimeException("Not impl");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2580 */     if (i == 0)
/* 2581 */       return node_getFirstChild(n); 
/* 2582 */     return n.locale().findDomNthChild(n, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _childNodes_getLength(Dom n) {
/* 2591 */     Locale l = n.locale();
/* 2592 */     assert n instanceof Xobj;
/*      */     
/* 2594 */     Xobj node = (Xobj)n; int count;
/* 2595 */     if (!node.isVacant() && (count = node.getDomZeroOneChildren()) < 2)
/*      */     {
/* 2597 */       return count; } 
/* 2598 */     if (l.noSync()) return childNodes_getLength(n); 
/* 2599 */     synchronized (l) { return childNodes_getLength(n); }
/*      */   
/*      */   }
/*      */   
/*      */   public static int childNodes_getLength(Dom n) {
/* 2604 */     switch (n.nodeType()) {
/*      */       
/*      */       case 3:
/*      */       case 4:
/*      */       case 7:
/*      */       case 8:
/* 2610 */         return 0;
/*      */       
/*      */       case 5:
/* 2613 */         throw new RuntimeException("Not impl");
/*      */       
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/* 2618 */         throw new RuntimeException("Not impl");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2628 */     assert n instanceof Xobj;
/* 2629 */     Xobj node = (Xobj)n;
/* 2630 */     node.ensureOccupancy(); int count;
/* 2631 */     if ((count = node.getDomZeroOneChildren()) < 2)
/* 2632 */       return count; 
/* 2633 */     return n.locale().domLength(n);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _element_getTagName(Dom e) {
/* 2642 */     return _node_getNodeName(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Attr _element_getAttributeNode(Dom e, String name) {
/* 2651 */     return (Attr)_attributes_getNamedItem(e, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Attr _element_getAttributeNodeNS(Dom e, String uri, String local) {
/* 2660 */     return (Attr)_attributes_getNamedItemNS(e, uri, local);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Attr _element_setAttributeNode(Dom e, Attr newAttr) {
/* 2669 */     return (Attr)_attributes_setNamedItem(e, newAttr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Attr _element_setAttributeNodeNS(Dom e, Attr newAttr) {
/* 2678 */     return (Attr)_attributes_setNamedItemNS(e, newAttr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _element_getAttribute(Dom e, String name) {
/* 2687 */     Node a = _attributes_getNamedItem(e, name);
/* 2688 */     return (a == null) ? "" : a.getNodeValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _element_getAttributeNS(Dom e, String uri, String local) {
/* 2697 */     Node a = _attributes_getNamedItemNS(e, uri, local);
/* 2698 */     return (a == null) ? "" : a.getNodeValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _element_hasAttribute(Dom e, String name) {
/* 2707 */     return (_attributes_getNamedItem(e, name) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _element_hasAttributeNS(Dom e, String uri, String local) {
/* 2716 */     return (_attributes_getNamedItemNS(e, uri, local) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _element_removeAttribute(Dom e, String name) {
/*      */     try {
/* 2727 */       _attributes_removeNamedItem(e, name);
/*      */     }
/* 2729 */     catch (NotFoundErr ex) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _element_removeAttributeNS(Dom e, String uri, String local) {
/*      */     try {
/* 2742 */       _attributes_removeNamedItemNS(e, uri, local);
/*      */     }
/* 2744 */     catch (NotFoundErr ex) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Attr _element_removeAttributeNode(Dom e, Attr oldAttr) {
/* 2755 */     if (oldAttr == null) {
/* 2756 */       throw new NotFoundErr("Attribute to remove is null");
/*      */     }
/* 2758 */     if (oldAttr.getOwnerElement() != e) {
/* 2759 */       throw new NotFoundErr("Attribute to remove does not belong to this element");
/*      */     }
/* 2761 */     return (Attr)_attributes_removeNamedItem(e, oldAttr.getNodeName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _element_setAttribute(Dom e, String name, String value) {
/* 2773 */     Locale l = e.locale();
/*      */     
/* 2775 */     if (l.noSync()) { l.enter(); try { element_setAttribute(e, name, value); } finally { l.exit(); }  }
/* 2776 */     else { synchronized (l) { l.enter(); try { element_setAttribute(e, name, value); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void element_setAttribute(Dom e, String name, String value) {
/* 2781 */     Dom a = attributes_getNamedItem(e, name);
/*      */     
/* 2783 */     if (a == null) {
/*      */       
/* 2785 */       a = document_createAttribute(node_getOwnerDocument(e), name);
/* 2786 */       attributes_setNamedItem(e, a);
/*      */     } 
/*      */     
/* 2789 */     node_setNodeValue(a, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _element_setAttributeNS(Dom e, String uri, String qname, String value) {
/* 2798 */     Locale l = e.locale();
/*      */     
/* 2800 */     if (l.noSync()) { l.enter(); try { element_setAttributeNS(e, uri, qname, value); } finally { l.exit(); }  }
/* 2801 */     else { synchronized (l) { l.enter(); try { element_setAttributeNS(e, uri, qname, value); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void element_setAttributeNS(Dom e, String uri, String qname, String value) {
/* 2806 */     validateQualifiedName(qname, uri, true);
/*      */     
/* 2808 */     QName name = e.locale().makeQualifiedQName(uri, qname);
/* 2809 */     String local = name.getLocalPart();
/* 2810 */     String prefix = validatePrefix(name.getPrefix(), uri, local, true);
/*      */     
/* 2812 */     Dom a = attributes_getNamedItemNS(e, uri, local);
/*      */     
/* 2814 */     if (a == null) {
/*      */       
/* 2816 */       a = document_createAttributeNS(node_getOwnerDocument(e), uri, local);
/* 2817 */       attributes_setNamedItemNS(e, a);
/*      */     } 
/*      */     
/* 2820 */     node_setPrefix(a, prefix);
/* 2821 */     node_setNodeValue(a, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NodeList _element_getElementsByTagName(Dom e, String name) {
/* 2830 */     Locale l = e.locale();
/*      */     
/* 2832 */     if (l.noSync()) { l.enter(); try { return element_getElementsByTagName(e, name); } finally { l.exit(); }  }
/* 2833 */      synchronized (l) { l.enter(); try { return element_getElementsByTagName(e, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static NodeList element_getElementsByTagName(Dom e, String name) {
/* 2838 */     return new ElementsByTagNameNodeList(e, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NodeList _element_getElementsByTagNameNS(Dom e, String uri, String local) {
/* 2847 */     Locale l = e.locale();
/*      */     
/* 2849 */     if (l.noSync()) { l.enter(); try { return element_getElementsByTagNameNS(e, uri, local); } finally { l.exit(); }  }
/* 2850 */      synchronized (l) { l.enter(); try { return element_getElementsByTagNameNS(e, uri, local); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static NodeList element_getElementsByTagNameNS(Dom e, String uri, String local) {
/* 2855 */     return new ElementsByTagNameNSNodeList(e, uri, local);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _attributes_getLength(Dom e) {
/* 2864 */     Locale l = e.locale();
/*      */     
/* 2866 */     if (l.noSync()) { l.enter(); try { return attributes_getLength(e); } finally { l.exit(); }  }
/* 2867 */      synchronized (l) { l.enter(); try { return attributes_getLength(e); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static int attributes_getLength(Dom e) {
/* 2872 */     int n = 0;
/*      */     
/* 2874 */     Cur c = e.tempCur();
/*      */     
/* 2876 */     while (c.toNextAttr()) {
/* 2877 */       n++;
/*      */     }
/* 2879 */     c.release();
/*      */     
/* 2881 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _attributes_setNamedItem(Dom e, Node attr) {
/*      */     Dom oldA;
/* 2890 */     Locale l = e.locale();
/*      */     
/* 2892 */     if (attr == null) {
/* 2893 */       throw new IllegalArgumentException("Attr to set is null");
/*      */     }
/*      */     
/*      */     Dom a;
/* 2897 */     if (!(attr instanceof Dom) || (a = (Dom)attr).locale() != l) {
/* 2898 */       throw new WrongDocumentErr("Attr to set is from another document");
/*      */     }
/*      */ 
/*      */     
/* 2902 */     if (l.noSync()) { l.enter(); try { oldA = attributes_setNamedItem(e, a); } finally { l.exit(); }  }
/* 2903 */     else { synchronized (l) { l.enter(); try { oldA = attributes_setNamedItem(e, a); } finally { l.exit(); }  }
/*      */        }
/* 2905 */      return (Node)oldA;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom attributes_setNamedItem(Dom e, Dom a) {
/* 2910 */     if (attr_getOwnerElement(a) != null) {
/* 2911 */       throw new InuseAttributeError();
/*      */     }
/* 2913 */     if (a.nodeType() != 2) {
/* 2914 */       throw new HierarchyRequestErr("Node is not an attribute");
/*      */     }
/* 2916 */     String name = _node_getNodeName(a);
/* 2917 */     Dom oldAttr = null;
/*      */     
/* 2919 */     Cur c = e.tempCur();
/*      */     
/* 2921 */     while (c.toNextAttr()) {
/*      */       
/* 2923 */       Dom aa = c.getDom();
/*      */       
/* 2925 */       if (_node_getNodeName(aa).equals(name)) {
/*      */         
/* 2927 */         if (oldAttr == null) {
/* 2928 */           oldAttr = aa;
/*      */           continue;
/*      */         } 
/* 2931 */         removeNode(aa);
/* 2932 */         c.toPrevAttr();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2937 */     if (oldAttr == null) {
/*      */       
/* 2939 */       c.moveToDom(e);
/* 2940 */       c.next();
/* 2941 */       Cur.moveNode((Xobj)a, c);
/*      */     }
/*      */     else {
/*      */       
/* 2945 */       c.moveToDom(oldAttr);
/* 2946 */       Cur.moveNode((Xobj)a, c);
/* 2947 */       removeNode(oldAttr);
/*      */     } 
/*      */     
/* 2950 */     c.release();
/*      */     
/* 2952 */     return oldAttr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _attributes_getNamedItem(Dom e, String name) {
/*      */     Dom n;
/* 2961 */     Locale l = e.locale();
/*      */ 
/*      */ 
/*      */     
/* 2965 */     if (l.noSync()) { l.enter(); try { n = attributes_getNamedItem(e, name); } finally { l.exit(); }  }
/* 2966 */     else { synchronized (l) { l.enter(); try { n = attributes_getNamedItem(e, name); } finally { l.exit(); }  }
/*      */        }
/* 2968 */      return (Node)n;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom attributes_getNamedItem(Dom e, String name) {
/* 2973 */     Dom a = null;
/*      */     
/* 2975 */     Cur c = e.tempCur();
/*      */     
/* 2977 */     while (c.toNextAttr()) {
/*      */       
/* 2979 */       Dom d = c.getDom();
/*      */       
/* 2981 */       if (_node_getNodeName(d).equals(name)) {
/*      */         
/* 2983 */         a = d;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 2988 */     c.release();
/*      */     
/* 2990 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _attributes_getNamedItemNS(Dom e, String uri, String local) {
/*      */     Dom n;
/* 2999 */     Locale l = e.locale();
/*      */ 
/*      */ 
/*      */     
/* 3003 */     if (l.noSync()) { l.enter(); try { n = attributes_getNamedItemNS(e, uri, local); } finally { l.exit(); }  }
/* 3004 */     else { synchronized (l) { l.enter(); try { n = attributes_getNamedItemNS(e, uri, local); } finally { l.exit(); }  }
/*      */        }
/* 3006 */      return (Node)n;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom attributes_getNamedItemNS(Dom e, String uri, String local) {
/* 3011 */     if (uri == null) {
/* 3012 */       uri = "";
/*      */     }
/* 3014 */     Dom a = null;
/*      */     
/* 3016 */     Cur c = e.tempCur();
/*      */     
/* 3018 */     while (c.toNextAttr()) {
/*      */       
/* 3020 */       Dom d = c.getDom();
/*      */       
/* 3022 */       QName n = d.getQName();
/*      */       
/* 3024 */       if (n.getNamespaceURI().equals(uri) && n.getLocalPart().equals(local)) {
/*      */         
/* 3026 */         a = d;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 3031 */     c.release();
/*      */     
/* 3033 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _attributes_removeNamedItem(Dom e, String name) {
/*      */     Dom n;
/* 3042 */     Locale l = e.locale();
/*      */ 
/*      */ 
/*      */     
/* 3046 */     if (l.noSync()) { l.enter(); try { n = attributes_removeNamedItem(e, name); } finally { l.exit(); }  }
/* 3047 */     else { synchronized (l) { l.enter(); try { n = attributes_removeNamedItem(e, name); } finally { l.exit(); }  }
/*      */        }
/* 3049 */      return (Node)n;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom attributes_removeNamedItem(Dom e, String name) {
/* 3054 */     Dom oldAttr = null;
/*      */     
/* 3056 */     Cur c = e.tempCur();
/*      */     
/* 3058 */     while (c.toNextAttr()) {
/*      */       
/* 3060 */       Dom aa = c.getDom();
/*      */       
/* 3062 */       if (_node_getNodeName(aa).equals(name)) {
/*      */         
/* 3064 */         if (oldAttr == null) {
/* 3065 */           oldAttr = aa;
/*      */         }
/* 3067 */         if (((Xobj.AttrXobj)aa).isId()) {
/*      */           
/* 3069 */           Dom d = node_getOwnerDocument(aa);
/* 3070 */           String val = node_getNodeValue(aa);
/* 3071 */           if (d instanceof Xobj.DocumentXobj)
/* 3072 */             ((Xobj.DocumentXobj)d).removeIdElement(val); 
/*      */         } 
/* 3074 */         removeNode(aa);
/* 3075 */         c.toPrevAttr();
/*      */       } 
/*      */     } 
/*      */     
/* 3079 */     c.release();
/*      */     
/* 3081 */     if (oldAttr == null) {
/* 3082 */       throw new NotFoundErr("Named item not found: " + name);
/*      */     }
/* 3084 */     return oldAttr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _attributes_removeNamedItemNS(Dom e, String uri, String local) {
/*      */     Dom n;
/* 3093 */     Locale l = e.locale();
/*      */ 
/*      */ 
/*      */     
/* 3097 */     if (l.noSync()) { l.enter(); try { n = attributes_removeNamedItemNS(e, uri, local); } finally { l.exit(); }  }
/* 3098 */     else { synchronized (l) { l.enter(); try { n = attributes_removeNamedItemNS(e, uri, local); } finally { l.exit(); }  }
/*      */        }
/* 3100 */      return (Node)n;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom attributes_removeNamedItemNS(Dom e, String uri, String local) {
/* 3105 */     if (uri == null) {
/* 3106 */       uri = "";
/*      */     }
/* 3108 */     Dom oldAttr = null;
/*      */     
/* 3110 */     Cur c = e.tempCur();
/*      */     
/* 3112 */     while (c.toNextAttr()) {
/*      */       
/* 3114 */       Dom aa = c.getDom();
/*      */       
/* 3116 */       QName qn = aa.getQName();
/*      */       
/* 3118 */       if (qn.getNamespaceURI().equals(uri) && qn.getLocalPart().equals(local)) {
/*      */         
/* 3120 */         if (oldAttr == null)
/* 3121 */           oldAttr = aa; 
/* 3122 */         if (((Xobj.AttrXobj)aa).isId()) {
/*      */           
/* 3124 */           Dom d = node_getOwnerDocument(aa);
/* 3125 */           String val = node_getNodeValue(aa);
/* 3126 */           if (d instanceof Xobj.DocumentXobj)
/* 3127 */             ((Xobj.DocumentXobj)d).removeIdElement(val); 
/*      */         } 
/* 3129 */         removeNode(aa);
/*      */         
/* 3131 */         c.toPrevAttr();
/*      */       } 
/*      */     } 
/*      */     
/* 3135 */     c.release();
/*      */     
/* 3137 */     if (oldAttr == null) {
/* 3138 */       throw new NotFoundErr("Named item not found: uri=" + uri + ", local=" + local);
/*      */     }
/* 3140 */     return oldAttr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _attributes_setNamedItemNS(Dom e, Node attr) {
/*      */     Dom oldA;
/* 3149 */     Locale l = e.locale();
/*      */     
/* 3151 */     if (attr == null) {
/* 3152 */       throw new IllegalArgumentException("Attr to set is null");
/*      */     }
/*      */     
/*      */     Dom a;
/* 3156 */     if (!(attr instanceof Dom) || (a = (Dom)attr).locale() != l) {
/* 3157 */       throw new WrongDocumentErr("Attr to set is from another document");
/*      */     }
/*      */ 
/*      */     
/* 3161 */     if (l.noSync()) { l.enter(); try { oldA = attributes_setNamedItemNS(e, a); } finally { l.exit(); }  }
/* 3162 */     else { synchronized (l) { l.enter(); try { oldA = attributes_setNamedItemNS(e, a); } finally { l.exit(); }  }
/*      */        }
/* 3164 */      return (Node)oldA;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom attributes_setNamedItemNS(Dom e, Dom a) {
/* 3169 */     Dom owner = attr_getOwnerElement(a);
/*      */     
/* 3171 */     if (owner == e) {
/* 3172 */       return a;
/*      */     }
/* 3174 */     if (owner != null) {
/* 3175 */       throw new InuseAttributeError();
/*      */     }
/* 3177 */     if (a.nodeType() != 2) {
/* 3178 */       throw new HierarchyRequestErr("Node is not an attribute");
/*      */     }
/* 3180 */     QName name = a.getQName();
/* 3181 */     Dom oldAttr = null;
/*      */     
/* 3183 */     Cur c = e.tempCur();
/*      */     
/* 3185 */     while (c.toNextAttr()) {
/*      */       
/* 3187 */       Dom aa = c.getDom();
/*      */       
/* 3189 */       if (aa.getQName().equals(name)) {
/*      */         
/* 3191 */         if (oldAttr == null) {
/* 3192 */           oldAttr = aa;
/*      */           continue;
/*      */         } 
/* 3195 */         removeNode(aa);
/* 3196 */         c.toPrevAttr();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3201 */     if (oldAttr == null) {
/*      */       
/* 3203 */       c.moveToDom(e);
/* 3204 */       c.next();
/* 3205 */       Cur.moveNode((Xobj)a, c);
/*      */     }
/*      */     else {
/*      */       
/* 3209 */       c.moveToDom(oldAttr);
/* 3210 */       Cur.moveNode((Xobj)a, c);
/* 3211 */       removeNode(oldAttr);
/*      */     } 
/*      */     
/* 3214 */     c.release();
/*      */     
/* 3216 */     return oldAttr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Node _attributes_item(Dom e, int index) {
/*      */     Dom a;
/* 3225 */     Locale l = e.locale();
/*      */ 
/*      */ 
/*      */     
/* 3229 */     if (l.noSync()) { l.enter(); try { a = attributes_item(e, index); } finally { l.exit(); }  }
/* 3230 */     else { synchronized (l) { l.enter(); try { a = attributes_item(e, index); } finally { l.exit(); }  }
/*      */        }
/* 3232 */      return (Node)a;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom attributes_item(Dom e, int index) {
/* 3237 */     if (index < 0) {
/* 3238 */       return null;
/*      */     }
/* 3240 */     Cur c = e.tempCur();
/*      */     
/* 3242 */     Dom a = null;
/*      */     
/* 3244 */     while (c.toNextAttr()) {
/*      */       
/* 3246 */       if (index-- == 0) {
/*      */         
/* 3248 */         a = c.getDom();
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 3253 */     c.release();
/*      */     
/* 3255 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _processingInstruction_getData(Dom p) {
/* 3264 */     return _node_getNodeValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _processingInstruction_getTarget(Dom p) {
/* 3273 */     return _node_getNodeName(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _processingInstruction_setData(Dom p, String data) {
/* 3282 */     _node_setNodeValue(p, data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _attr_getSpecified(Dom a) {
/* 3292 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element _attr_getOwnerElement(Dom a) {
/*      */     Dom e;
/* 3301 */     Locale l = a.locale();
/*      */ 
/*      */ 
/*      */     
/* 3305 */     if (l.noSync()) { l.enter(); try { e = attr_getOwnerElement(a); } finally { l.exit(); }  }
/* 3306 */     else { synchronized (l) { l.enter(); try { e = attr_getOwnerElement(a); } finally { l.exit(); }  }
/*      */        }
/* 3308 */      return (Element)e;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom attr_getOwnerElement(Dom n) {
/* 3313 */     Cur c = n.tempCur();
/*      */     
/* 3315 */     if (!c.toParentRaw()) {
/*      */       
/* 3317 */       c.release();
/* 3318 */       return null;
/*      */     } 
/*      */     
/* 3321 */     Dom p = c.getDom();
/*      */     
/* 3323 */     c.release();
/*      */     
/* 3325 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _characterData_appendData(Dom cd, String arg) {
/* 3337 */     if (arg != null && arg.length() != 0) {
/* 3338 */       _node_setNodeValue(cd, _node_getNodeValue(cd) + arg);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _characterData_deleteData(Dom c, int offset, int count) {
/* 3347 */     String s = _characterData_getData(c);
/*      */     
/* 3349 */     if (offset < 0 || offset > s.length() || count < 0) {
/* 3350 */       throw new IndexSizeError();
/*      */     }
/* 3352 */     if (offset + count > s.length()) {
/* 3353 */       count = s.length() - offset;
/*      */     }
/* 3355 */     if (count > 0) {
/* 3356 */       _characterData_setData(c, s.substring(0, offset) + s.substring(offset + count));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _characterData_getData(Dom c) {
/* 3365 */     return _node_getNodeValue(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int _characterData_getLength(Dom c) {
/* 3374 */     return _characterData_getData(c).length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _characterData_insertData(Dom c, int offset, String arg) {
/* 3383 */     String s = _characterData_getData(c);
/*      */     
/* 3385 */     if (offset < 0 || offset > s.length()) {
/* 3386 */       throw new IndexSizeError();
/*      */     }
/* 3388 */     if (arg != null && arg.length() > 0) {
/* 3389 */       _characterData_setData(c, s.substring(0, offset) + arg + s.substring(offset));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _characterData_replaceData(Dom c, int offset, int count, String arg) {
/* 3398 */     String s = _characterData_getData(c);
/*      */     
/* 3400 */     if (offset < 0 || offset > s.length() || count < 0) {
/* 3401 */       throw new IndexSizeError();
/*      */     }
/* 3403 */     if (offset + count > s.length()) {
/* 3404 */       count = s.length() - offset;
/*      */     }
/* 3406 */     if (count > 0)
/*      */     {
/* 3408 */       _characterData_setData(c, s.substring(0, offset) + ((arg == null) ? "" : arg) + s.substring(offset + count));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _characterData_setData(Dom c, String data) {
/* 3420 */     _node_setNodeValue(c, data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _characterData_substringData(Dom c, int offset, int count) {
/* 3429 */     String s = _characterData_getData(c);
/*      */     
/* 3431 */     if (offset < 0 || offset > s.length() || count < 0) {
/* 3432 */       throw new IndexSizeError();
/*      */     }
/* 3434 */     if (offset + count > s.length()) {
/* 3435 */       count = s.length() - offset;
/*      */     }
/* 3437 */     return s.substring(offset, offset + count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Text _text_splitText(Dom t, int offset) {
/* 3446 */     assert t.nodeType() == 3;
/*      */     
/* 3448 */     String s = _characterData_getData(t);
/*      */     
/* 3450 */     if (offset < 0 || offset > s.length()) {
/* 3451 */       throw new IndexSizeError();
/*      */     }
/* 3453 */     _characterData_deleteData(t, offset, s.length() - offset);
/*      */ 
/*      */ 
/*      */     
/* 3457 */     Dom t2 = (Dom)_document_createTextNode(t, s.substring(offset));
/*      */     
/* 3459 */     Dom p = (Dom)_node_getParentNode(t);
/*      */     
/* 3461 */     if (p != null) {
/*      */       
/* 3463 */       _node_insertBefore(p, (Text)t2, _node_getNextSibling(t));
/* 3464 */       t.locale().invalidateDomCaches(p);
/*      */     } 
/*      */     
/* 3467 */     return (Text)t2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String _text_getWholeText(Dom t) {
/* 3476 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _text_isElementContentWhitespace(Dom t) {
/* 3485 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Text _text_replaceWholeText(Dom t, String content) {
/* 3494 */     throw new RuntimeException("DOM Level 3 Not implemented");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static XMLStreamReader _getXmlStreamReader(Dom n) {
/* 3503 */     Locale l = n.locale();
/*      */     
/* 3505 */     if (l.noSync()) { l.enter(); try { return getXmlStreamReader(n); } finally { l.exit(); }  }
/* 3506 */      synchronized (l) { l.enter(); try { return getXmlStreamReader(n); } finally { l.exit(); }
/*      */        }
/*      */      } public static XMLStreamReader getXmlStreamReader(Dom n) {
/*      */     XMLStreamReader xs;
/*      */     Cur c;
/*      */     CharNode cn;
/*      */     Cur cur1;
/* 3513 */     switch (n.nodeType()) {
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 11:
/* 3522 */         c = n.tempCur();
/* 3523 */         xs = Jsr173.newXmlStreamReader(c, null);
/* 3524 */         c.release();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3563 */         return xs;case 3: case 4: cn = (CharNode)n; if ((cur1 = cn.tempCur()) == null) { cur1 = n.locale().tempCur(); xs = Jsr173.newXmlStreamReader(cur1, cn._src, cn._off, cn._cch); } else { xs = Jsr173.newXmlStreamReader(cur1, cur1.getChars(cn._cch), cur1._offSrc, cur1._cchSrc); }  cur1.release(); return xs;
/*      */       case 5:
/*      */       case 6:
/*      */       case 10:
/*      */       case 12:
/*      */         throw new RuntimeException("Not impl");
/*      */     } 
/*      */     throw new RuntimeException("Unknown kind");
/*      */   } public static XmlCursor _getXmlCursor(Dom n) {
/* 3572 */     Locale l = n.locale();
/*      */     
/* 3574 */     if (l.noSync()) { l.enter(); try { return getXmlCursor(n); } finally { l.exit(); }  }
/* 3575 */      synchronized (l) { l.enter(); try { return getXmlCursor(n); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static XmlCursor getXmlCursor(Dom n) {
/* 3580 */     Cur c = n.tempCur();
/*      */     
/* 3582 */     Cursor xc = new Cursor(c);
/*      */     
/* 3584 */     c.release();
/*      */     
/* 3586 */     return xc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static XmlObject _getXmlObject(Dom n) {
/* 3595 */     Locale l = n.locale();
/*      */     
/* 3597 */     if (l.noSync()) { l.enter(); try { return getXmlObject(n); } finally { l.exit(); }  }
/* 3598 */      synchronized (l) { l.enter(); try { return getXmlObject(n); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static XmlObject getXmlObject(Dom n) {
/* 3603 */     Cur c = n.tempCur();
/*      */     
/* 3605 */     XmlObject x = c.getObject();
/*      */     
/* 3607 */     c.release();
/*      */     
/* 3609 */     return x;
/*      */   }
/*      */   static abstract class CharNode implements Dom, Node, CharacterData { private Locale _locale;
/*      */     CharNode _next;
/*      */     CharNode _prev;
/*      */     private Object _src;
/*      */     int _off;
/*      */     int _cch;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     public CharNode(Locale l) {
/* 3620 */       assert l != null;
/*      */       
/* 3622 */       this._locale = l;
/*      */     }
/*      */ 
/*      */     
/*      */     public QName getQName() {
/* 3627 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Locale locale() {
/* 3632 */       assert isValid();
/*      */       
/* 3634 */       return (this._locale == null) ? ((DomImpl.Dom)this._src).locale() : this._locale;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setChars(Object src, int off, int cch) {
/* 3639 */       assert CharUtil.isValid(src, off, cch);
/* 3640 */       assert this._locale != null || this._src instanceof DomImpl.Dom;
/*      */       
/* 3642 */       if (this._locale == null) {
/* 3643 */         this._locale = ((DomImpl.Dom)this._src).locale();
/*      */       }
/* 3645 */       this._src = src;
/* 3646 */       this._off = off;
/* 3647 */       this._cch = cch;
/*      */     }
/*      */ 
/*      */     
/*      */     public DomImpl.Dom getDom() {
/* 3652 */       assert isValid();
/*      */       
/* 3654 */       if (this._src instanceof DomImpl.Dom) {
/* 3655 */         return (DomImpl.Dom)this._src;
/*      */       }
/* 3657 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setDom(DomImpl.Dom d) {
/* 3662 */       assert d != null;
/*      */       
/* 3664 */       this._src = d;
/* 3665 */       this._locale = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Cur tempCur() {
/* 3670 */       assert isValid();
/*      */       
/* 3672 */       if (!(this._src instanceof DomImpl.Dom)) {
/* 3673 */         return null;
/*      */       }
/* 3675 */       Cur c = locale().tempCur();
/* 3676 */       c.moveToCharNode(this);
/*      */       
/* 3678 */       return c;
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean isValid() {
/* 3683 */       if (this._src instanceof DomImpl.Dom) {
/* 3684 */         return (this._locale == null);
/*      */       }
/* 3686 */       if (this._locale == null) {
/* 3687 */         return false;
/*      */       }
/* 3689 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public static boolean isOnList(CharNode nodes, CharNode node) {
/* 3694 */       assert node != null;
/*      */       
/* 3696 */       for (CharNode cn = nodes; cn != null; cn = cn._next) {
/* 3697 */         if (cn == node)
/* 3698 */           return true; 
/*      */       } 
/* 3700 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public static CharNode remove(CharNode nodes, CharNode node) {
/* 3705 */       assert isOnList(nodes, node);
/*      */       
/* 3707 */       if (nodes == node) {
/* 3708 */         nodes = node._next;
/*      */       } else {
/* 3710 */         node._prev._next = node._next;
/*      */       } 
/* 3712 */       if (node._next != null) {
/* 3713 */         node._next._prev = node._prev;
/*      */       }
/* 3715 */       node._prev = node._next = null;
/*      */       
/* 3717 */       return nodes;
/*      */     }
/*      */ 
/*      */     
/*      */     public static CharNode insertNode(CharNode nodes, CharNode newNode, CharNode before) {
/* 3722 */       assert !isOnList(nodes, newNode);
/* 3723 */       assert before == null || isOnList(nodes, before);
/* 3724 */       assert newNode != null;
/* 3725 */       assert newNode._prev == null && newNode._next == null;
/*      */       
/* 3727 */       if (nodes == null) {
/*      */         
/* 3729 */         assert before == null;
/* 3730 */         nodes = newNode;
/*      */       }
/* 3732 */       else if (nodes == before) {
/*      */         
/* 3734 */         nodes._prev = newNode;
/* 3735 */         newNode._next = nodes;
/* 3736 */         nodes = newNode;
/*      */       }
/*      */       else {
/*      */         
/* 3740 */         CharNode n = nodes;
/*      */         
/* 3742 */         while (n._next != before) {
/* 3743 */           n = n._next;
/*      */         }
/* 3745 */         if ((newNode._next = n._next) != null) {
/* 3746 */           n._next._prev = newNode;
/*      */         }
/* 3748 */         newNode._prev = n;
/* 3749 */         n._next = newNode;
/*      */       } 
/*      */       
/* 3752 */       return nodes;
/*      */     }
/*      */ 
/*      */     
/*      */     public static CharNode appendNode(CharNode nodes, CharNode newNode) {
/* 3757 */       return insertNode(nodes, newNode, null);
/*      */     }
/*      */ 
/*      */     
/*      */     public static CharNode appendNodes(CharNode nodes, CharNode newNodes) {
/* 3762 */       assert newNodes != null;
/* 3763 */       assert newNodes._prev == null;
/*      */       
/* 3765 */       if (nodes == null) {
/* 3766 */         return newNodes;
/*      */       }
/* 3768 */       CharNode n = nodes;
/*      */       
/* 3770 */       while (n._next != null) {
/* 3771 */         n = n._next;
/*      */       }
/* 3773 */       n._next = newNodes;
/* 3774 */       newNodes._prev = n;
/*      */       
/* 3776 */       return nodes;
/*      */     }
/*      */ 
/*      */     
/*      */     public static CharNode copyNodes(CharNode nodes, Object newSrc) {
/* 3781 */       CharNode newNodes = null;
/*      */       
/* 3783 */       for (CharNode n = null; nodes != null; nodes = nodes._next) {
/*      */         CharNode newNode;
/*      */ 
/*      */         
/* 3787 */         if (nodes instanceof DomImpl.TextNode) {
/* 3788 */           newNode = nodes.locale().createTextNode();
/*      */         } else {
/* 3790 */           newNode = nodes.locale().createCdataNode();
/*      */         } 
/*      */ 
/*      */         
/* 3794 */         newNode.setChars(newSrc, nodes._off, nodes._cch);
/*      */         
/* 3796 */         if (newNodes == null) {
/* 3797 */           newNodes = newNode;
/*      */         }
/* 3799 */         if (n != null) {
/*      */           
/* 3801 */           n._next = newNode;
/* 3802 */           newNode._prev = n;
/*      */         } 
/*      */         
/* 3805 */         n = newNode;
/*      */       } 
/*      */       
/* 3808 */       return newNodes;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean nodeCanHavePrefixUri() {
/* 3813 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isNodeAftertext() {
/* 3819 */       assert this._src instanceof Xobj : "this method is to only be used for nodes backed up by Xobjs";
/* 3820 */       Xobj src = (Xobj)this._src;
/* 3821 */       return (src._charNodesValue == null) ? true : ((src._charNodesAfter == null) ? false : isOnList(src._charNodesAfter, this));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void dump(PrintStream o, Object ref) {
/* 3827 */       if (this._src instanceof DomImpl.Dom) {
/* 3828 */         ((DomImpl.Dom)this._src).dump(o, ref);
/*      */       } else {
/* 3830 */         o.println("Lonely CharNode: \"" + CharUtil.getString(this._src, this._off, this._cch) + "\"");
/*      */       } 
/*      */     }
/*      */     
/*      */     public void dump(PrintStream o) {
/* 3835 */       dump(o, this);
/*      */     }
/*      */ 
/*      */     
/*      */     public void dump() {
/* 3840 */       dump(System.out);
/*      */     }
/*      */     
/* 3843 */     public Node appendChild(Node newChild) { return DomImpl._node_appendChild(this, newChild); }
/* 3844 */     public Node cloneNode(boolean deep) { return DomImpl._node_cloneNode(this, deep); }
/* 3845 */     public NamedNodeMap getAttributes() { return null; }
/* 3846 */     public NodeList getChildNodes() { return DomImpl._emptyNodeList; }
/* 3847 */     public Node getParentNode() { return DomImpl._node_getParentNode(this); }
/* 3848 */     public Node removeChild(Node oldChild) { return DomImpl._node_removeChild(this, oldChild); }
/* 3849 */     public Node getFirstChild() { return null; }
/* 3850 */     public Node getLastChild() { return null; }
/* 3851 */     public String getLocalName() { return DomImpl._node_getLocalName(this); }
/* 3852 */     public String getNamespaceURI() { return DomImpl._node_getNamespaceURI(this); }
/* 3853 */     public Node getNextSibling() { return DomImpl._node_getNextSibling(this); }
/* 3854 */     public String getNodeName() { return DomImpl._node_getNodeName(this); }
/* 3855 */     public short getNodeType() { return DomImpl._node_getNodeType(this); }
/* 3856 */     public String getNodeValue() { return DomImpl._node_getNodeValue(this); }
/* 3857 */     public Document getOwnerDocument() { return DomImpl._node_getOwnerDocument(this); }
/* 3858 */     public String getPrefix() { return DomImpl._node_getPrefix(this); }
/* 3859 */     public Node getPreviousSibling() { return DomImpl._node_getPreviousSibling(this); }
/* 3860 */     public boolean hasAttributes() { return false; }
/* 3861 */     public boolean hasChildNodes() { return false; }
/* 3862 */     public Node insertBefore(Node newChild, Node refChild) { return DomImpl._node_insertBefore(this, newChild, refChild); }
/* 3863 */     public boolean isSupported(String feature, String version) { return DomImpl._node_isSupported(this, feature, version); }
/* 3864 */     public void normalize() { DomImpl._node_normalize(this); }
/* 3865 */     public Node replaceChild(Node newChild, Node oldChild) { return DomImpl._node_replaceChild(this, newChild, oldChild); }
/* 3866 */     public void setNodeValue(String nodeValue) { DomImpl._node_setNodeValue(this, nodeValue); } public void setPrefix(String prefix) {
/* 3867 */       DomImpl._node_setPrefix(this, prefix);
/*      */     }
/*      */     
/* 3870 */     public Object getUserData(String key) { return DomImpl._node_getUserData(this, key); }
/* 3871 */     public Object setUserData(String key, Object data, UserDataHandler handler) { return DomImpl._node_setUserData(this, key, data, handler); }
/* 3872 */     public Object getFeature(String feature, String version) { return DomImpl._node_getFeature(this, feature, version); }
/* 3873 */     public boolean isEqualNode(Node arg) { return DomImpl._node_isEqualNode(this, arg); }
/* 3874 */     public boolean isSameNode(Node arg) { return DomImpl._node_isSameNode(this, arg); }
/* 3875 */     public String lookupNamespaceURI(String prefix) { return DomImpl._node_lookupNamespaceURI(this, prefix); }
/* 3876 */     public String lookupPrefix(String namespaceURI) { return DomImpl._node_lookupPrefix(this, namespaceURI); }
/* 3877 */     public boolean isDefaultNamespace(String namespaceURI) { return DomImpl._node_isDefaultNamespace(this, namespaceURI); }
/* 3878 */     public void setTextContent(String textContent) { DomImpl._node_setTextContent(this, textContent); }
/* 3879 */     public String getTextContent() { return DomImpl._node_getTextContent(this); }
/* 3880 */     public short compareDocumentPosition(Node other) { return DomImpl._node_compareDocumentPosition(this, other); } public String getBaseURI() {
/* 3881 */       return DomImpl._node_getBaseURI(this);
/*      */     }
/* 3883 */     public void appendData(String arg) { DomImpl._characterData_appendData(this, arg); }
/* 3884 */     public void deleteData(int offset, int count) { DomImpl._characterData_deleteData(this, offset, count); }
/* 3885 */     public String getData() { return DomImpl._characterData_getData(this); }
/* 3886 */     public int getLength() { return DomImpl._characterData_getLength(this); }
/* 3887 */     public void insertData(int offset, String arg) { DomImpl._characterData_insertData(this, offset, arg); }
/* 3888 */     public void replaceData(int offset, int count, String arg) { DomImpl._characterData_replaceData(this, offset, count, arg); }
/* 3889 */     public void setData(String data) { DomImpl._characterData_setData(this, data); } public String substringData(int offset, int count) {
/* 3890 */       return DomImpl._characterData_substringData(this, offset, count);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TextNode
/*      */     extends CharNode
/*      */     implements Text
/*      */   {
/*      */     TextNode(Locale l) {
/* 3907 */       super(l);
/*      */     }
/*      */     public int nodeType() {
/* 3910 */       return 3;
/*      */     } public String name() {
/* 3912 */       return "#text";
/*      */     }
/* 3914 */     public Text splitText(int offset) { return DomImpl._text_splitText(this, offset); }
/* 3915 */     public String getWholeText() { return DomImpl._text_getWholeText(this); }
/* 3916 */     public boolean isElementContentWhitespace() { return DomImpl._text_isElementContentWhitespace(this); } public Text replaceWholeText(String content) {
/* 3917 */       return DomImpl._text_replaceWholeText(this, content);
/*      */     }
/*      */   }
/*      */   
/*      */   static class CdataNode
/*      */     extends TextNode implements CDATASection {
/*      */     CdataNode(Locale l) {
/* 3924 */       super(l);
/*      */     }
/*      */     public int nodeType() {
/* 3927 */       return 4;
/*      */     } public String name() {
/* 3929 */       return "#cdata-section";
/*      */     }
/*      */   }
/*      */   
/*      */   static class SaajTextNode
/*      */     extends TextNode implements Text {
/*      */     SaajTextNode(Locale l) {
/* 3936 */       super(l);
/*      */     }
/*      */     public boolean isComment() {
/* 3939 */       return DomImpl._soapText_isComment(this);
/*      */     }
/* 3941 */     public void detachNode() { DomImpl._soapNode_detachNode(this); }
/* 3942 */     public void recycleNode() { DomImpl._soapNode_recycleNode(this); }
/* 3943 */     public String getValue() { return DomImpl._soapNode_getValue(this); }
/* 3944 */     public void setValue(String value) { DomImpl._soapNode_setValue(this, value); }
/* 3945 */     public SOAPElement getParentElement() { return DomImpl._soapNode_getParentElement(this); } public void setParentElement(SOAPElement p) {
/* 3946 */       DomImpl._soapNode_setParentElement(this, p);
/*      */     }
/*      */   }
/*      */   
/*      */   static class SaajCdataNode
/*      */     extends CdataNode implements Text {
/*      */     public SaajCdataNode(Locale l) {
/* 3953 */       super(l);
/*      */     }
/*      */     public boolean isComment() {
/* 3956 */       return DomImpl._soapText_isComment(this);
/*      */     }
/* 3958 */     public void detachNode() { DomImpl._soapNode_detachNode(this); }
/* 3959 */     public void recycleNode() { DomImpl._soapNode_recycleNode(this); }
/* 3960 */     public String getValue() { return DomImpl._soapNode_getValue(this); }
/* 3961 */     public void setValue(String value) { DomImpl._soapNode_setValue(this, value); }
/* 3962 */     public SOAPElement getParentElement() { return DomImpl._soapNode_getParentElement(this); } public void setParentElement(SOAPElement p) {
/* 3963 */       DomImpl._soapNode_setParentElement(this, p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean _soapText_isComment(Dom n) {
/* 3972 */     Locale l = n.locale();
/*      */     
/* 3974 */     Text text = (Text)n;
/*      */     
/* 3976 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapText_isComment(text); } finally { l.exit(); }  }
/* 3977 */      synchronized (l) { l.enter(); try { return l._saaj.soapText_isComment(text); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _soapNode_detachNode(Dom n) {
/* 3986 */     Locale l = n.locale();
/*      */     
/* 3988 */     Node node = (Node)n;
/*      */     
/* 3990 */     if (l.noSync()) { l.enter(); try { l._saaj.soapNode_detachNode(node); } finally { l.exit(); }  }
/* 3991 */     else { synchronized (l) { l.enter(); try { l._saaj.soapNode_detachNode(node); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void _soapNode_recycleNode(Dom n) {
/* 3996 */     Locale l = n.locale();
/*      */     
/* 3998 */     Node node = (Node)n;
/*      */     
/* 4000 */     if (l.noSync()) { l.enter(); try { l._saaj.soapNode_recycleNode(node); } finally { l.exit(); }  }
/* 4001 */     else { synchronized (l) { l.enter(); try { l._saaj.soapNode_recycleNode(node); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static String _soapNode_getValue(Dom n) {
/* 4006 */     Locale l = n.locale();
/*      */     
/* 4008 */     Node node = (Node)n;
/*      */     
/* 4010 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapNode_getValue(node); } finally { l.exit(); }  }
/* 4011 */      synchronized (l) { l.enter(); try { return l._saaj.soapNode_getValue(node); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static void _soapNode_setValue(Dom n, String value) {
/* 4016 */     Locale l = n.locale();
/*      */     
/* 4018 */     Node node = (Node)n;
/*      */     
/* 4020 */     if (l.noSync()) { l.enter(); try { l._saaj.soapNode_setValue(node, value); } finally { l.exit(); }  }
/* 4021 */     else { synchronized (l) { l.enter(); try { l._saaj.soapNode_setValue(node, value); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static SOAPElement _soapNode_getParentElement(Dom n) {
/* 4026 */     Locale l = n.locale();
/*      */     
/* 4028 */     Node node = (Node)n;
/*      */     
/* 4030 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapNode_getParentElement(node); } finally { l.exit(); }  }
/* 4031 */      synchronized (l) { l.enter(); try { return l._saaj.soapNode_getParentElement(node); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static void _soapNode_setParentElement(Dom n, SOAPElement p) {
/* 4036 */     Locale l = n.locale();
/*      */     
/* 4038 */     Node node = (Node)n;
/*      */     
/* 4040 */     if (l.noSync()) { l.enter(); try { l._saaj.soapNode_setParentElement(node, p); } finally { l.exit(); }  }
/* 4041 */     else { synchronized (l) { l.enter(); try { l._saaj.soapNode_setParentElement(node, p); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _soapElement_removeContents(Dom d) {
/* 4050 */     Locale l = d.locale();
/*      */     
/* 4052 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4054 */     if (l.noSync()) { l.enter(); try { l._saaj.soapElement_removeContents(se); } finally { l.exit(); }  }
/* 4055 */     else { synchronized (l) { l.enter(); try { l._saaj.soapElement_removeContents(se); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static String _soapElement_getEncodingStyle(Dom d) {
/* 4060 */     Locale l = d.locale();
/*      */     
/* 4062 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4064 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getEncodingStyle(se); } finally { l.exit(); }  }
/* 4065 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getEncodingStyle(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static void _soapElement_setEncodingStyle(Dom d, String encodingStyle) {
/* 4070 */     Locale l = d.locale();
/*      */     
/* 4072 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4074 */     if (l.noSync()) { l.enter(); try { l._saaj.soapElement_setEncodingStyle(se, encodingStyle); } finally { l.exit(); }  }
/* 4075 */     else { synchronized (l) { l.enter(); try { l._saaj.soapElement_setEncodingStyle(se, encodingStyle); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static boolean _soapElement_removeNamespaceDeclaration(Dom d, String prefix) {
/* 4080 */     Locale l = d.locale();
/*      */     
/* 4082 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4084 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_removeNamespaceDeclaration(se, prefix); } finally { l.exit(); }  }
/* 4085 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_removeNamespaceDeclaration(se, prefix); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator _soapElement_getAllAttributes(Dom d) {
/* 4090 */     Locale l = d.locale();
/*      */     
/* 4092 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4094 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getAllAttributes(se); } finally { l.exit(); }  }
/* 4095 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getAllAttributes(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator _soapElement_getChildElements(Dom d) {
/* 4100 */     Locale l = d.locale();
/*      */     
/* 4102 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4104 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getChildElements(se); } finally { l.exit(); }  }
/* 4105 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getChildElements(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator _soapElement_getNamespacePrefixes(Dom d) {
/* 4110 */     Locale l = d.locale();
/*      */     
/* 4112 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4114 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getNamespacePrefixes(se); } finally { l.exit(); }  }
/* 4115 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getNamespacePrefixes(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPElement _soapElement_addAttribute(Dom d, Name name, String value) throws SOAPException {
/* 4120 */     Locale l = d.locale();
/*      */     
/* 4122 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4124 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_addAttribute(se, name, value); } finally { l.exit(); }  }
/* 4125 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_addAttribute(se, name, value); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPElement _soapElement_addChildElement(Dom d, SOAPElement oldChild) throws SOAPException {
/* 4130 */     Locale l = d.locale();
/*      */     
/* 4132 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4134 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, oldChild); } finally { l.exit(); }  }
/* 4135 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, oldChild); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPElement _soapElement_addChildElement(Dom d, Name name) throws SOAPException {
/* 4140 */     Locale l = d.locale();
/*      */     
/* 4142 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4144 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, name); } finally { l.exit(); }  }
/* 4145 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPElement _soapElement_addChildElement(Dom d, String localName) throws SOAPException {
/* 4150 */     Locale l = d.locale();
/*      */     
/* 4152 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4154 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, localName); } finally { l.exit(); }  }
/* 4155 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, localName); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPElement _soapElement_addChildElement(Dom d, String localName, String prefix) throws SOAPException {
/* 4160 */     Locale l = d.locale();
/*      */     
/* 4162 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4164 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, localName, prefix); } finally { l.exit(); }  }
/* 4165 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, localName, prefix); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPElement _soapElement_addChildElement(Dom d, String localName, String prefix, String uri) throws SOAPException {
/* 4170 */     Locale l = d.locale();
/*      */     
/* 4172 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4174 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, localName, prefix, uri); } finally { l.exit(); }  }
/* 4175 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_addChildElement(se, localName, prefix, uri); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPElement _soapElement_addNamespaceDeclaration(Dom d, String prefix, String uri) {
/* 4180 */     Locale l = d.locale();
/*      */     
/* 4182 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4184 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_addNamespaceDeclaration(se, prefix, uri); } finally { l.exit(); }  }
/* 4185 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_addNamespaceDeclaration(se, prefix, uri); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPElement _soapElement_addTextNode(Dom d, String data) {
/* 4190 */     Locale l = d.locale();
/*      */     
/* 4192 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4194 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_addTextNode(se, data); } finally { l.exit(); }  }
/* 4195 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_addTextNode(se, data); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static String _soapElement_getAttributeValue(Dom d, Name name) {
/* 4200 */     Locale l = d.locale();
/*      */     
/* 4202 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4204 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getAttributeValue(se, name); } finally { l.exit(); }  }
/* 4205 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getAttributeValue(se, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator _soapElement_getChildElements(Dom d, Name name) {
/* 4210 */     Locale l = d.locale();
/*      */     
/* 4212 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4214 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getChildElements(se, name); } finally { l.exit(); }  }
/* 4215 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getChildElements(se, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Name _soapElement_getElementName(Dom d) {
/* 4220 */     Locale l = d.locale();
/*      */     
/* 4222 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4224 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getElementName(se); } finally { l.exit(); }  }
/* 4225 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getElementName(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static String _soapElement_getNamespaceURI(Dom d, String prefix) {
/* 4230 */     Locale l = d.locale();
/*      */     
/* 4232 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4234 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getNamespaceURI(se, prefix); } finally { l.exit(); }  }
/* 4235 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getNamespaceURI(se, prefix); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator _soapElement_getVisibleNamespacePrefixes(Dom d) {
/* 4240 */     Locale l = d.locale();
/*      */     
/* 4242 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4244 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_getVisibleNamespacePrefixes(se); } finally { l.exit(); }  }
/* 4245 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_getVisibleNamespacePrefixes(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static boolean _soapElement_removeAttribute(Dom d, Name name) {
/* 4250 */     Locale l = d.locale();
/*      */     
/* 4252 */     SOAPElement se = (SOAPElement)d;
/*      */     
/* 4254 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapElement_removeAttribute(se, name); } finally { l.exit(); }  }
/* 4255 */      synchronized (l) { l.enter(); try { return l._saaj.soapElement_removeAttribute(se, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SOAPBody _soapEnvelope_addBody(Dom d) throws SOAPException {
/* 4264 */     Locale l = d.locale();
/*      */     
/* 4266 */     SOAPEnvelope se = (SOAPEnvelope)d;
/*      */     
/* 4268 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapEnvelope_addBody(se); } finally { l.exit(); }  }
/* 4269 */      synchronized (l) { l.enter(); try { return l._saaj.soapEnvelope_addBody(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPBody _soapEnvelope_getBody(Dom d) throws SOAPException {
/* 4274 */     Locale l = d.locale();
/*      */     
/* 4276 */     SOAPEnvelope se = (SOAPEnvelope)d;
/*      */     
/* 4278 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapEnvelope_getBody(se); } finally { l.exit(); }  }
/* 4279 */      synchronized (l) { l.enter(); try { return l._saaj.soapEnvelope_getBody(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPHeader _soapEnvelope_getHeader(Dom d) throws SOAPException {
/* 4284 */     Locale l = d.locale();
/*      */     
/* 4286 */     SOAPEnvelope se = (SOAPEnvelope)d;
/*      */     
/* 4288 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapEnvelope_getHeader(se); } finally { l.exit(); }  }
/* 4289 */      synchronized (l) { l.enter(); try { return l._saaj.soapEnvelope_getHeader(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPHeader _soapEnvelope_addHeader(Dom d) throws SOAPException {
/* 4294 */     Locale l = d.locale();
/*      */     
/* 4296 */     SOAPEnvelope se = (SOAPEnvelope)d;
/*      */     
/* 4298 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapEnvelope_addHeader(se); } finally { l.exit(); }  }
/* 4299 */      synchronized (l) { l.enter(); try { return l._saaj.soapEnvelope_addHeader(se); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Name _soapEnvelope_createName(Dom d, String localName) {
/* 4304 */     Locale l = d.locale();
/*      */     
/* 4306 */     SOAPEnvelope se = (SOAPEnvelope)d;
/*      */     
/* 4308 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapEnvelope_createName(se, localName); } finally { l.exit(); }  }
/* 4309 */      synchronized (l) { l.enter(); try { return l._saaj.soapEnvelope_createName(se, localName); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Name _soapEnvelope_createName(Dom d, String localName, String prefix, String namespaceURI) {
/* 4314 */     Locale l = d.locale();
/*      */     
/* 4316 */     SOAPEnvelope se = (SOAPEnvelope)d;
/*      */     
/* 4318 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapEnvelope_createName(se, localName, prefix, namespaceURI); } finally { l.exit(); }  }
/* 4319 */      synchronized (l) { l.enter(); try { return l._saaj.soapEnvelope_createName(se, localName, prefix, namespaceURI); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Iterator soapHeader_examineAllHeaderElements(Dom d) {
/* 4328 */     Locale l = d.locale();
/*      */     
/* 4330 */     SOAPHeader sh = (SOAPHeader)d;
/*      */     
/* 4332 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapHeader_examineAllHeaderElements(sh); } finally { l.exit(); }  }
/* 4333 */      synchronized (l) { l.enter(); try { return l._saaj.soapHeader_examineAllHeaderElements(sh); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator soapHeader_extractAllHeaderElements(Dom d) {
/* 4338 */     Locale l = d.locale();
/*      */     
/* 4340 */     SOAPHeader sh = (SOAPHeader)d;
/*      */     
/* 4342 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapHeader_extractAllHeaderElements(sh); } finally { l.exit(); }  }
/* 4343 */      synchronized (l) { l.enter(); try { return l._saaj.soapHeader_extractAllHeaderElements(sh); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator soapHeader_examineHeaderElements(Dom d, String actor) {
/* 4348 */     Locale l = d.locale();
/*      */     
/* 4350 */     SOAPHeader sh = (SOAPHeader)d;
/*      */     
/* 4352 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapHeader_examineHeaderElements(sh, actor); } finally { l.exit(); }  }
/* 4353 */      synchronized (l) { l.enter(); try { return l._saaj.soapHeader_examineHeaderElements(sh, actor); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator soapHeader_examineMustUnderstandHeaderElements(Dom d, String mustUnderstandString) {
/* 4358 */     Locale l = d.locale();
/*      */     
/* 4360 */     SOAPHeader sh = (SOAPHeader)d;
/*      */     
/* 4362 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapHeader_examineMustUnderstandHeaderElements(sh, mustUnderstandString); } finally { l.exit(); }  }
/* 4363 */      synchronized (l) { l.enter(); try { return l._saaj.soapHeader_examineMustUnderstandHeaderElements(sh, mustUnderstandString); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator soapHeader_extractHeaderElements(Dom d, String actor) {
/* 4368 */     Locale l = d.locale();
/*      */     
/* 4370 */     SOAPHeader sh = (SOAPHeader)d;
/*      */     
/* 4372 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapHeader_extractHeaderElements(sh, actor); } finally { l.exit(); }  }
/* 4373 */      synchronized (l) { l.enter(); try { return l._saaj.soapHeader_extractHeaderElements(sh, actor); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPHeaderElement soapHeader_addHeaderElement(Dom d, Name name) {
/* 4378 */     Locale l = d.locale();
/*      */     
/* 4380 */     SOAPHeader sh = (SOAPHeader)d;
/*      */     
/* 4382 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapHeader_addHeaderElement(sh, name); } finally { l.exit(); }  }
/* 4383 */      synchronized (l) { l.enter(); try { return l._saaj.soapHeader_addHeaderElement(sh, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean soapBody_hasFault(Dom d) {
/* 4392 */     Locale l = d.locale();
/*      */     
/* 4394 */     SOAPBody sb = (SOAPBody)d;
/*      */     
/* 4396 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapBody_hasFault(sb); } finally { l.exit(); }  }
/* 4397 */      synchronized (l) { l.enter(); try { return l._saaj.soapBody_hasFault(sb); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPFault soapBody_addFault(Dom d) throws SOAPException {
/* 4402 */     Locale l = d.locale();
/*      */     
/* 4404 */     SOAPBody sb = (SOAPBody)d;
/*      */     
/* 4406 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapBody_addFault(sb); } finally { l.exit(); }  }
/* 4407 */      synchronized (l) { l.enter(); try { return l._saaj.soapBody_addFault(sb); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPFault soapBody_getFault(Dom d) {
/* 4412 */     Locale l = d.locale();
/*      */     
/* 4414 */     SOAPBody sb = (SOAPBody)d;
/*      */     
/* 4416 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapBody_getFault(sb); } finally { l.exit(); }  }
/* 4417 */      synchronized (l) { l.enter(); try { return l._saaj.soapBody_getFault(sb); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPBodyElement soapBody_addBodyElement(Dom d, Name name) {
/* 4422 */     Locale l = d.locale();
/*      */     
/* 4424 */     SOAPBody sb = (SOAPBody)d;
/*      */     
/* 4426 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapBody_addBodyElement(sb, name); } finally { l.exit(); }  }
/* 4427 */      synchronized (l) { l.enter(); try { return l._saaj.soapBody_addBodyElement(sb, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPBodyElement soapBody_addDocument(Dom d, Document document) {
/* 4432 */     Locale l = d.locale();
/*      */     
/* 4434 */     SOAPBody sb = (SOAPBody)d;
/*      */     
/* 4436 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapBody_addDocument(sb, document); } finally { l.exit(); }  }
/* 4437 */      synchronized (l) { l.enter(); try { return l._saaj.soapBody_addDocument(sb, document); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPFault soapBody_addFault(Dom d, Name name, String s) throws SOAPException {
/* 4442 */     Locale l = d.locale();
/*      */     
/* 4444 */     SOAPBody sb = (SOAPBody)d;
/*      */     
/* 4446 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapBody_addFault(sb, name, s); } finally { l.exit(); }  }
/* 4447 */      synchronized (l) { l.enter(); try { return l._saaj.soapBody_addFault(sb, name, s); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPFault soapBody_addFault(Dom d, Name faultCode, String faultString, Locale locale) throws SOAPException {
/* 4452 */     Locale l = d.locale();
/*      */     
/* 4454 */     SOAPBody sb = (SOAPBody)d;
/*      */     
/* 4456 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapBody_addFault(sb, faultCode, faultString, locale); } finally { l.exit(); }  }
/* 4457 */      synchronized (l) { l.enter(); try { return l._saaj.soapBody_addFault(sb, faultCode, faultString, locale); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void soapFault_setFaultString(Dom d, String faultString) {
/* 4466 */     Locale l = d.locale();
/*      */     
/* 4468 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4470 */     if (l.noSync()) { l.enter(); try { l._saaj.soapFault_setFaultString(sf, faultString); } finally { l.exit(); }  }
/* 4471 */     else { synchronized (l) { l.enter(); try { l._saaj.soapFault_setFaultString(sf, faultString); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void soapFault_setFaultString(Dom d, String faultString, Locale locale) {
/* 4476 */     Locale l = d.locale();
/*      */     
/* 4478 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4480 */     if (l.noSync()) { l.enter(); try { l._saaj.soapFault_setFaultString(sf, faultString, locale); } finally { l.exit(); }  }
/* 4481 */     else { synchronized (l) { l.enter(); try { l._saaj.soapFault_setFaultString(sf, faultString, locale); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void soapFault_setFaultCode(Dom d, Name faultCodeName) throws SOAPException {
/* 4486 */     Locale l = d.locale();
/*      */     
/* 4488 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4490 */     if (l.noSync()) { l.enter(); try { l._saaj.soapFault_setFaultCode(sf, faultCodeName); } finally { l.exit(); }  }
/* 4491 */     else { synchronized (l) { l.enter(); try { l._saaj.soapFault_setFaultCode(sf, faultCodeName); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void soapFault_setFaultActor(Dom d, String faultActorString) {
/* 4496 */     Locale l = d.locale();
/*      */     
/* 4498 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4500 */     if (l.noSync()) { l.enter(); try { l._saaj.soapFault_setFaultActor(sf, faultActorString); } finally { l.exit(); }  }
/* 4501 */     else { synchronized (l) { l.enter(); try { l._saaj.soapFault_setFaultActor(sf, faultActorString); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static String soapFault_getFaultActor(Dom d) {
/* 4506 */     Locale l = d.locale();
/*      */     
/* 4508 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4510 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapFault_getFaultActor(sf); } finally { l.exit(); }  }
/* 4511 */      synchronized (l) { l.enter(); try { return l._saaj.soapFault_getFaultActor(sf); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static String soapFault_getFaultCode(Dom d) {
/* 4516 */     Locale l = d.locale();
/*      */     
/* 4518 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4520 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapFault_getFaultCode(sf); } finally { l.exit(); }  }
/* 4521 */      synchronized (l) { l.enter(); try { return l._saaj.soapFault_getFaultCode(sf); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static void soapFault_setFaultCode(Dom d, String faultCode) throws SOAPException {
/* 4526 */     Locale l = d.locale();
/*      */     
/* 4528 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4530 */     if (l.noSync()) { l.enter(); try { l._saaj.soapFault_setFaultCode(sf, faultCode); } finally { l.exit(); }  }
/* 4531 */     else { synchronized (l) { l.enter(); try { l._saaj.soapFault_setFaultCode(sf, faultCode); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static Locale soapFault_getFaultStringLocale(Dom d) {
/* 4536 */     Locale l = d.locale();
/*      */     
/* 4538 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4540 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapFault_getFaultStringLocale(sf); } finally { l.exit(); }  }
/* 4541 */      synchronized (l) { l.enter(); try { return l._saaj.soapFault_getFaultStringLocale(sf); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Name soapFault_getFaultCodeAsName(Dom d) {
/* 4546 */     Locale l = d.locale();
/*      */     
/* 4548 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4550 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapFault_getFaultCodeAsName(sf); } finally { l.exit(); }  }
/* 4551 */      synchronized (l) { l.enter(); try { return l._saaj.soapFault_getFaultCodeAsName(sf); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static String soapFault_getFaultString(Dom d) {
/* 4556 */     Locale l = d.locale();
/*      */     
/* 4558 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4560 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapFault_getFaultString(sf); } finally { l.exit(); }  }
/* 4561 */      synchronized (l) { l.enter(); try { return l._saaj.soapFault_getFaultString(sf); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Detail soapFault_addDetail(Dom d) throws SOAPException {
/* 4566 */     Locale l = d.locale();
/*      */     
/* 4568 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4570 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapFault_addDetail(sf); } finally { l.exit(); }  }
/* 4571 */      synchronized (l) { l.enter(); try { return l._saaj.soapFault_addDetail(sf); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Detail soapFault_getDetail(Dom d) {
/* 4576 */     Locale l = d.locale();
/*      */     
/* 4578 */     SOAPFault sf = (SOAPFault)d;
/*      */     
/* 4580 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapFault_getDetail(sf); } finally { l.exit(); }  }
/* 4581 */      synchronized (l) { l.enter(); try { return l._saaj.soapFault_getDetail(sf); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void soapHeaderElement_setMustUnderstand(Dom d, boolean mustUnderstand) {
/* 4590 */     Locale l = d.locale();
/*      */     
/* 4592 */     SOAPHeaderElement she = (SOAPHeaderElement)d;
/*      */     
/* 4594 */     if (l.noSync()) { l.enter(); try { l._saaj.soapHeaderElement_setMustUnderstand(she, mustUnderstand); } finally { l.exit(); }  }
/* 4595 */     else { synchronized (l) { l.enter(); try { l._saaj.soapHeaderElement_setMustUnderstand(she, mustUnderstand); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static boolean soapHeaderElement_getMustUnderstand(Dom d) {
/* 4600 */     Locale l = d.locale();
/*      */     
/* 4602 */     SOAPHeaderElement she = (SOAPHeaderElement)d;
/*      */     
/* 4604 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapHeaderElement_getMustUnderstand(she); } finally { l.exit(); }  }
/* 4605 */      synchronized (l) { l.enter(); try { return l._saaj.soapHeaderElement_getMustUnderstand(she); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static void soapHeaderElement_setActor(Dom d, String actor) {
/* 4610 */     Locale l = d.locale();
/*      */     
/* 4612 */     SOAPHeaderElement she = (SOAPHeaderElement)d;
/*      */     
/* 4614 */     if (l.noSync()) { l.enter(); try { l._saaj.soapHeaderElement_setActor(she, actor); } finally { l.exit(); }  }
/* 4615 */     else { synchronized (l) { l.enter(); try { l._saaj.soapHeaderElement_setActor(she, actor); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static String soapHeaderElement_getActor(Dom d) {
/* 4620 */     Locale l = d.locale();
/*      */     
/* 4622 */     SOAPHeaderElement she = (SOAPHeaderElement)d;
/*      */     
/* 4624 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapHeaderElement_getActor(she); } finally { l.exit(); }  }
/* 4625 */      synchronized (l) { l.enter(); try { return l._saaj.soapHeaderElement_getActor(she); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DetailEntry detail_addDetailEntry(Dom d, Name name) {
/* 4634 */     Locale l = d.locale();
/*      */     
/* 4636 */     Detail detail = (Detail)d;
/*      */     
/* 4638 */     if (l.noSync()) { l.enter(); try { return l._saaj.detail_addDetailEntry(detail, name); } finally { l.exit(); }  }
/* 4639 */      synchronized (l) { l.enter(); try { return l._saaj.detail_addDetailEntry(detail, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator detail_getDetailEntries(Dom d) {
/* 4644 */     Locale l = d.locale();
/*      */     
/* 4646 */     Detail detail = (Detail)d;
/*      */     
/* 4648 */     if (l.noSync()) { l.enter(); try { return l._saaj.detail_getDetailEntries(detail); } finally { l.exit(); }  }
/* 4649 */      synchronized (l) { l.enter(); try { return l._saaj.detail_getDetailEntries(detail); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void _soapPart_removeAllMimeHeaders(Dom d) {
/* 4658 */     Locale l = d.locale();
/*      */     
/* 4660 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4662 */     if (l.noSync()) { l.enter(); try { l._saaj.soapPart_removeAllMimeHeaders(sp); } finally { l.exit(); }  }
/* 4663 */     else { synchronized (l) { l.enter(); try { l._saaj.soapPart_removeAllMimeHeaders(sp); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void _soapPart_removeMimeHeader(Dom d, String name) {
/* 4668 */     Locale l = d.locale();
/*      */     
/* 4670 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4672 */     if (l.noSync()) { l.enter(); try { l._saaj.soapPart_removeMimeHeader(sp, name); } finally { l.exit(); }  }
/* 4673 */     else { synchronized (l) { l.enter(); try { l._saaj.soapPart_removeMimeHeader(sp, name); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static Iterator _soapPart_getAllMimeHeaders(Dom d) {
/* 4678 */     Locale l = d.locale();
/*      */     
/* 4680 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4682 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapPart_getAllMimeHeaders(sp); } finally { l.exit(); }  }
/* 4683 */      synchronized (l) { l.enter(); try { return l._saaj.soapPart_getAllMimeHeaders(sp); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static SOAPEnvelope _soapPart_getEnvelope(Dom d) {
/* 4688 */     Locale l = d.locale();
/*      */     
/* 4690 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4692 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapPart_getEnvelope(sp); } finally { l.exit(); }  }
/* 4693 */      synchronized (l) { l.enter(); try { return l._saaj.soapPart_getEnvelope(sp); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Source _soapPart_getContent(Dom d) {
/* 4698 */     Locale l = d.locale();
/*      */     
/* 4700 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4702 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapPart_getContent(sp); } finally { l.exit(); }  }
/* 4703 */      synchronized (l) { l.enter(); try { return l._saaj.soapPart_getContent(sp); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static void _soapPart_setContent(Dom d, Source source) {
/* 4708 */     Locale l = d.locale();
/*      */     
/* 4710 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4712 */     if (l.noSync()) { l.enter(); try { l._saaj.soapPart_setContent(sp, source); } finally { l.exit(); }  }
/* 4713 */     else { synchronized (l) { l.enter(); try { l._saaj.soapPart_setContent(sp, source); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static String[] _soapPart_getMimeHeader(Dom d, String name) {
/* 4718 */     Locale l = d.locale();
/*      */     
/* 4720 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4722 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapPart_getMimeHeader(sp, name); } finally { l.exit(); }  }
/* 4723 */      synchronized (l) { l.enter(); try { return l._saaj.soapPart_getMimeHeader(sp, name); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static void _soapPart_addMimeHeader(Dom d, String name, String value) {
/* 4728 */     Locale l = d.locale();
/*      */     
/* 4730 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4732 */     if (l.noSync()) { l.enter(); try { l._saaj.soapPart_addMimeHeader(sp, name, value); } finally { l.exit(); }  }
/* 4733 */     else { synchronized (l) { l.enter(); try { l._saaj.soapPart_addMimeHeader(sp, name, value); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void _soapPart_setMimeHeader(Dom d, String name, String value) {
/* 4738 */     Locale l = d.locale();
/*      */     
/* 4740 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4742 */     if (l.noSync()) { l.enter(); try { l._saaj.soapPart_setMimeHeader(sp, name, value); } finally { l.exit(); }  }
/* 4743 */     else { synchronized (l) { l.enter(); try { l._saaj.soapPart_setMimeHeader(sp, name, value); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static Iterator _soapPart_getMatchingMimeHeaders(Dom d, String[] names) {
/* 4748 */     Locale l = d.locale();
/*      */     
/* 4750 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4752 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapPart_getMatchingMimeHeaders(sp, names); } finally { l.exit(); }  }
/* 4753 */      synchronized (l) { l.enter(); try { return l._saaj.soapPart_getMatchingMimeHeaders(sp, names); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Iterator _soapPart_getNonMatchingMimeHeaders(Dom d, String[] names) {
/* 4758 */     Locale l = d.locale();
/*      */     
/* 4760 */     SOAPPart sp = (SOAPPart)d;
/*      */     
/* 4762 */     if (l.noSync()) { l.enter(); try { return l._saaj.soapPart_getNonMatchingMimeHeaders(sp, names); } finally { l.exit(); }  }
/* 4763 */      synchronized (l) { l.enter(); try { return l._saaj.soapPart_getNonMatchingMimeHeaders(sp, names); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private static class SaajData
/*      */   {
/*      */     Object _obj;
/*      */     
/*      */     private SaajData() {}
/*      */   }
/*      */   
/*      */   public static void saajCallback_setSaajData(Dom d, Object o) {
/* 4777 */     Locale l = d.locale();
/*      */     
/* 4779 */     if (l.noSync()) { l.enter(); try { impl_saajCallback_setSaajData(d, o); } finally { l.exit(); }  }
/* 4780 */     else { synchronized (l) { l.enter(); try { impl_saajCallback_setSaajData(d, o); } finally { l.exit(); }
/*      */          }
/*      */        }
/*      */   
/*      */   } public static void impl_saajCallback_setSaajData(Dom d, Object o) {
/* 4785 */     Locale l = d.locale();
/*      */     
/* 4787 */     Cur c = l.tempCur();
/*      */     
/* 4789 */     c.moveToDom(d);
/*      */     
/* 4791 */     SaajData sd = null;
/*      */     
/* 4793 */     if (o != null) {
/*      */       
/* 4795 */       sd = (SaajData)c.getBookmark(SaajData.class);
/*      */       
/* 4797 */       if (sd == null) {
/* 4798 */         sd = new SaajData();
/*      */       }
/* 4800 */       sd._obj = o;
/*      */     } 
/*      */     
/* 4803 */     c.setBookmark(SaajData.class, sd);
/*      */     
/* 4805 */     c.release();
/*      */   }
/*      */ 
/*      */   
/*      */   public static Object saajCallback_getSaajData(Dom d) {
/* 4810 */     Locale l = d.locale();
/*      */     
/* 4812 */     if (l.noSync()) { l.enter(); try { return impl_saajCallback_getSaajData(d); } finally { l.exit(); }  }
/* 4813 */      synchronized (l) { l.enter(); try { return impl_saajCallback_getSaajData(d); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */   public static Object impl_saajCallback_getSaajData(Dom d) {
/* 4818 */     Locale l = d.locale();
/*      */     
/* 4820 */     Cur c = l.tempCur();
/*      */     
/* 4822 */     c.moveToDom(d);
/*      */     
/* 4824 */     SaajData sd = (SaajData)c.getBookmark(SaajData.class);
/*      */     
/* 4826 */     Object o = (sd == null) ? null : sd._obj;
/*      */     
/* 4828 */     c.release();
/*      */     
/* 4830 */     return o;
/*      */   }
/*      */   
/*      */   public static Element saajCallback_createSoapElement(Dom d, QName name, QName parentName) {
/*      */     Dom e;
/* 4835 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/* 4839 */     if (l.noSync()) { l.enter(); try { e = impl_saajCallback_createSoapElement(d, name, parentName); } finally { l.exit(); }  }
/* 4840 */     else { synchronized (l) { l.enter(); try { e = impl_saajCallback_createSoapElement(d, name, parentName); } finally { l.exit(); }  }
/*      */        }
/* 4842 */      return (Element)e;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Dom impl_saajCallback_createSoapElement(Dom d, QName name, QName parentName) {
/* 4847 */     Cur c = d.locale().tempCur();
/*      */     
/* 4849 */     c.createElement(name, parentName);
/*      */     
/* 4851 */     Dom e = c.getDom();
/*      */     
/* 4853 */     c.release();
/*      */     
/* 4855 */     return e;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Element saajCallback_importSoapElement(Dom d, Element elem, boolean deep, QName parentName) {
/*      */     Dom e;
/* 4861 */     Locale l = d.locale();
/*      */ 
/*      */ 
/*      */     
/* 4865 */     if (l.noSync()) { l.enter(); try { e = impl_saajCallback_importSoapElement(d, elem, deep, parentName); } finally { l.exit(); }  }
/* 4866 */     else { synchronized (l) { l.enter(); try { e = impl_saajCallback_importSoapElement(d, elem, deep, parentName); } finally { l.exit(); }  }
/*      */        }
/* 4868 */      return (Element)e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Dom impl_saajCallback_importSoapElement(Dom d, Element elem, boolean deep, QName parentName) {
/* 4878 */     throw new RuntimeException("Not impl");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Text saajCallback_ensureSoapTextNode(Dom d) {
/* 4884 */     Locale l = d.locale();
/*      */     
/* 4886 */     if (l.noSync()) { l.enter(); try { return impl_saajCallback_ensureSoapTextNode(d); } finally { l.exit(); }  }
/* 4887 */      synchronized (l) { l.enter(); try { return impl_saajCallback_ensureSoapTextNode(d); } finally { l.exit(); }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Text impl_saajCallback_ensureSoapTextNode(Dom d) {
/* 4903 */     return null;
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\DomImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */