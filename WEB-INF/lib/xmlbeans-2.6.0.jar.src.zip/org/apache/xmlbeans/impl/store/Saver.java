/*      */ package org.apache.xmlbeans.impl.store;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.SystemProperties;
/*      */ import org.apache.xmlbeans.XmlDocumentProperties;
/*      */ import org.apache.xmlbeans.XmlOptionCharEscapeMap;
/*      */ import org.apache.xmlbeans.XmlOptions;
/*      */ import org.apache.xmlbeans.impl.common.EncodingMap;
/*      */ import org.apache.xmlbeans.impl.common.GenericXmlInputStream;
/*      */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*      */ import org.apache.xmlbeans.impl.common.XmlEventBase;
/*      */ import org.apache.xmlbeans.impl.common.XmlNameImpl;
/*      */ import org.apache.xmlbeans.xml.stream.Attribute;
/*      */ import org.apache.xmlbeans.xml.stream.AttributeIterator;
/*      */ import org.apache.xmlbeans.xml.stream.CharacterData;
/*      */ import org.apache.xmlbeans.xml.stream.Comment;
/*      */ import org.apache.xmlbeans.xml.stream.EndDocument;
/*      */ import org.apache.xmlbeans.xml.stream.EndElement;
/*      */ import org.apache.xmlbeans.xml.stream.Location;
/*      */ import org.apache.xmlbeans.xml.stream.ProcessingInstruction;
/*      */ import org.apache.xmlbeans.xml.stream.StartDocument;
/*      */ import org.apache.xmlbeans.xml.stream.StartElement;
/*      */ import org.apache.xmlbeans.xml.stream.StartPrefixMapping;
/*      */ import org.apache.xmlbeans.xml.stream.XMLEvent;
/*      */ import org.apache.xmlbeans.xml.stream.XMLName;
/*      */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*      */ import org.xml.sax.ContentHandler;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.ext.LexicalHandler;
/*      */ import org.xml.sax.helpers.AttributesImpl;
/*      */ 
/*      */ abstract class Saver {
/*      */   static final int ROOT = 1;
/*      */   static final int ELEM = 2;
/*      */   static final int ATTR = 3;
/*      */   static final int COMMENT = 4;
/*      */   static final int PROCINST = 5;
/*      */   static final int TEXT = 0;
/*      */   private final Locale _locale;
/*      */   private final long _version;
/*      */   private SaveCur _cur;
/*      */   private List _ancestorNamespaces;
/*      */   private Map _suggestedPrefixes;
/*      */   protected XmlOptionCharEscapeMap _replaceChar;
/*      */   private boolean _useDefaultNamespace;
/*      */   private Map _preComputedNamespaces;
/*      */   private boolean _saveNamespacesFirst;
/*      */   private ArrayList _attrNames;
/*      */   private ArrayList _attrValues;
/*      */   private ArrayList _namespaceStack;
/*      */   private int _currentMapping;
/*      */   private HashMap _uriMap;
/*      */   private HashMap _prefixMap;
/*      */   private String _initialDefaultUri;
/*      */   
/*      */   protected void syntheticNamespace(String prefix, String uri, boolean considerDefault) {}
/*      */   
/*      */   Saver(Cur c, XmlOptions options) {
/*   72 */     assert c._locale.entered();
/*      */     
/*   74 */     options = XmlOptions.maskNull(options);
/*      */     
/*   76 */     this._cur = createSaveCur(c, options);
/*      */     
/*   78 */     this._locale = c._locale;
/*   79 */     this._version = this._locale.version();
/*      */     
/*   81 */     this._namespaceStack = new ArrayList();
/*   82 */     this._uriMap = new HashMap();
/*   83 */     this._prefixMap = new HashMap();
/*      */     
/*   85 */     this._attrNames = new ArrayList();
/*   86 */     this._attrValues = new ArrayList();
/*      */ 
/*      */ 
/*      */     
/*   90 */     addMapping("xml", "http://www.w3.org/XML/1998/namespace");
/*      */     
/*   92 */     if (options.hasOption("SAVE_IMPLICIT_NAMESPACES")) {
/*      */       
/*   94 */       Map m = (Map)options.get("SAVE_IMPLICIT_NAMESPACES");
/*      */       
/*   96 */       for (Iterator i = m.keySet().iterator(); i.hasNext(); ) {
/*      */         
/*   98 */         String prefix = i.next();
/*   99 */         addMapping(prefix, (String)m.get(prefix));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  104 */     if (options.hasOption("SAVE_SUBSTITUTE_CHARACTERS"))
/*      */     {
/*  106 */       this._replaceChar = (XmlOptionCharEscapeMap)options.get("SAVE_SUBSTITUTE_CHARACTERS");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  112 */     if (getNamespaceForPrefix("") == null) {
/*      */       
/*  114 */       this._initialDefaultUri = new String("");
/*  115 */       addMapping("", this._initialDefaultUri);
/*      */     } 
/*      */     
/*  118 */     if (options.hasOption("SAVE_AGGRESSIVE_NAMESPACES") && !(this instanceof SynthNamespaceSaver)) {
/*      */ 
/*      */       
/*  121 */       SynthNamespaceSaver saver = new SynthNamespaceSaver(c, options);
/*      */       
/*  123 */       while (saver.process());
/*      */ 
/*      */       
/*  126 */       if (!saver._synthNamespaces.isEmpty()) {
/*  127 */         this._preComputedNamespaces = saver._synthNamespaces;
/*      */       }
/*      */     } 
/*  130 */     this._useDefaultNamespace = options.hasOption("SAVE_USE_DEFAULT_NAMESPACE");
/*      */ 
/*      */     
/*  133 */     this._saveNamespacesFirst = options.hasOption("SAVE_NAMESPACES_FIRST");
/*      */     
/*  135 */     if (options.hasOption("SAVE_SUGGESTED_PREFIXES")) {
/*  136 */       this._suggestedPrefixes = (Map)options.get("SAVE_SUGGESTED_PREFIXES");
/*      */     }
/*  138 */     this._ancestorNamespaces = this._cur.getAncestorNamespaces();
/*      */   }
/*      */ 
/*      */   
/*      */   private static SaveCur createSaveCur(Cur c, XmlOptions options) {
/*  143 */     QName synthName = (QName)options.get("SAVE_SYNTHETIC_DOCUMENT_ELEMENT");
/*      */     
/*  145 */     QName fragName = synthName;
/*      */     
/*  147 */     if (fragName == null)
/*      */     {
/*  149 */       fragName = options.hasOption("SAVE_USE_OPEN_FRAGMENT") ? Locale._openuriFragment : Locale._xmlFragment;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  155 */     boolean saveInner = (options.hasOption("SAVE_INNER") && !options.hasOption("SAVE_OUTER"));
/*      */ 
/*      */ 
/*      */     
/*  159 */     Cur start = c.tempCur();
/*  160 */     Cur end = c.tempCur();
/*      */     
/*  162 */     SaveCur cur = null;
/*      */     
/*  164 */     int k = c.kind();
/*      */     
/*  166 */     switch (k) {
/*      */ 
/*      */       
/*      */       case 1:
/*  170 */         positionToInner(c, start, end);
/*      */         
/*  172 */         if (Locale.isFragment(start, end)) {
/*  173 */           cur = new FragSaveCur(start, end, fragName); break;
/*  174 */         }  if (synthName != null) {
/*  175 */           cur = new FragSaveCur(start, end, synthName); break;
/*      */         } 
/*  177 */         cur = new DocSaveCur(c);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  184 */         if (saveInner) {
/*      */           
/*  186 */           positionToInner(c, start, end);
/*      */           
/*  188 */           cur = new FragSaveCur(start, end, Locale.isFragment(start, end) ? fragName : synthName);
/*      */           
/*      */           break;
/*      */         } 
/*  192 */         if (synthName != null) {
/*      */           
/*  194 */           positionToInner(c, start, end);
/*      */           
/*  196 */           cur = new FragSaveCur(start, end, synthName);
/*      */           
/*      */           break;
/*      */         } 
/*  200 */         start.moveToCur(c);
/*  201 */         end.moveToCur(c);
/*  202 */         end.skip();
/*      */         
/*  204 */         cur = new FragSaveCur(start, end, null);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  211 */     if (cur == null) {
/*      */       
/*  213 */       assert k < 0 || k == 3 || k == 4 || k == 5 || k == 0;
/*      */       
/*  215 */       if (k < 0) {
/*      */ 
/*      */         
/*  218 */         start.moveToCur(c);
/*  219 */         end.moveToCur(c);
/*      */       }
/*  221 */       else if (k == 0) {
/*      */         
/*  223 */         start.moveToCur(c);
/*  224 */         end.moveToCur(c);
/*  225 */         end.next();
/*      */       }
/*  227 */       else if (saveInner) {
/*      */         
/*  229 */         start.moveToCur(c);
/*  230 */         start.next();
/*      */         
/*  232 */         end.moveToCur(c);
/*  233 */         end.toEnd();
/*      */       }
/*  235 */       else if (k == 3) {
/*      */         
/*  237 */         start.moveToCur(c);
/*  238 */         end.moveToCur(c);
/*      */       }
/*      */       else {
/*      */         
/*  242 */         assert k == 4 || k == 5;
/*      */         
/*  244 */         start.moveToCur(c);
/*  245 */         end.moveToCur(c);
/*  246 */         end.skip();
/*      */       } 
/*      */       
/*  249 */       cur = new FragSaveCur(start, end, fragName);
/*      */     } 
/*      */     
/*  252 */     String filterPI = (String)options.get("SAVE_FILTER_PROCINST");
/*      */     
/*  254 */     if (filterPI != null) {
/*  255 */       cur = new FilterPiSaveCur(cur, filterPI);
/*      */     }
/*  257 */     if (options.hasOption("SAVE_PRETTY_PRINT")) {
/*  258 */       cur = new PrettySaveCur(cur, options);
/*      */     }
/*  260 */     start.release();
/*  261 */     end.release();
/*      */     
/*  263 */     return cur;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void positionToInner(Cur c, Cur start, Cur end) {
/*  268 */     assert c.isContainer();
/*      */     
/*  270 */     start.moveToCur(c);
/*      */     
/*  272 */     if (!start.toFirstAttr()) {
/*  273 */       start.next();
/*      */     }
/*  275 */     end.moveToCur(c);
/*  276 */     end.toEnd();
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean saveNamespacesFirst() {
/*  281 */     return this._saveNamespacesFirst;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void enterLocale() {
/*  286 */     this._locale.enter();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void exitLocale() {
/*  291 */     this._locale.exit();
/*      */   }
/*      */   
/*      */   protected final boolean process()
/*      */   {
/*  296 */     assert this._locale.entered();
/*      */     
/*  298 */     if (this._cur == null) {
/*  299 */       return false;
/*      */     }
/*  301 */     if (this._version != this._locale.version()) {
/*  302 */       throw new ConcurrentModificationException("Document changed during save");
/*      */     }
/*  304 */     switch (this._cur.kind()) {
/*      */       case 1:
/*  306 */         processRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  326 */         this._cur.next();
/*      */         
/*  328 */         return true;case 2: processElement(); this._cur.next(); return true;case -2: processFinish(); this._cur.next(); return true;case 0: emitText(this._cur); this._cur.next(); return true;case 4: emitComment(this._cur); this._cur.toEnd(); this._cur.next(); return true;case 5: emitProcinst(this._cur); this._cur.toEnd(); this._cur.next(); return true;
/*      */       case -1:
/*      */         emitEndDoc(this._cur); this._cur.release(); this._cur = null;
/*      */         return true;
/*      */     } 
/*  333 */     throw new RuntimeException("Unexpected kind"); } private final void processFinish() { emitFinish(this._cur);
/*  334 */     popMappings(); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void processRoot() {
/*  339 */     assert this._cur.isRoot();
/*      */     
/*  341 */     XmlDocumentProperties props = this._cur.getDocProps();
/*  342 */     String systemId = null;
/*  343 */     String docTypeName = null;
/*  344 */     if (props != null) {
/*      */       
/*  346 */       systemId = props.getDoctypeSystemId();
/*  347 */       docTypeName = props.getDoctypeName();
/*      */     } 
/*      */     
/*  350 */     if (systemId != null || docTypeName != null) {
/*      */       
/*  352 */       if (docTypeName == null) {
/*      */         
/*  354 */         this._cur.push();
/*  355 */         while (!this._cur.isElem() && this._cur.next());
/*      */         
/*  357 */         if (this._cur.isElem())
/*  358 */           docTypeName = this._cur.getName().getLocalPart(); 
/*  359 */         this._cur.pop();
/*      */       } 
/*      */       
/*  362 */       String publicId = props.getDoctypePublicId();
/*      */       
/*  364 */       if (docTypeName != null) {
/*      */         
/*  366 */         QName rootElemName = this._cur.getName();
/*      */         
/*  368 */         if (rootElemName == null) {
/*      */           
/*  370 */           this._cur.push();
/*  371 */           while (!this._cur.isFinish()) {
/*      */             
/*  373 */             if (this._cur.isElem()) {
/*      */               
/*  375 */               rootElemName = this._cur.getName();
/*      */               break;
/*      */             } 
/*  378 */             this._cur.next();
/*      */           } 
/*  380 */           this._cur.pop();
/*      */         } 
/*      */         
/*  383 */         if (rootElemName != null && docTypeName.equals(rootElemName.getLocalPart())) {
/*      */           
/*  385 */           emitDocType(docTypeName, publicId, systemId);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*  391 */     emitStartDoc(this._cur);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void processElement() {
/*  396 */     assert this._cur.isElem() && this._cur.getName() != null;
/*      */     
/*  398 */     QName name = this._cur.getName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  404 */     boolean ensureDefaultEmpty = (name.getNamespaceURI().length() == 0);
/*      */     
/*  406 */     pushMappings(this._cur, ensureDefaultEmpty);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  419 */     ensureMapping(name.getNamespaceURI(), name.getPrefix(), !ensureDefaultEmpty, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  425 */     this._attrNames.clear();
/*  426 */     this._attrValues.clear();
/*      */     
/*  428 */     this._cur.push();
/*      */ 
/*      */     
/*  431 */     for (boolean A = this._cur.toFirstAttr(); A; A = this._cur.toNextAttr()) {
/*      */       
/*  433 */       if (this._cur.isNormalAttr()) {
/*      */         
/*  435 */         QName attrName = this._cur.getName();
/*      */         
/*  437 */         this._attrNames.add(attrName);
/*      */         
/*  439 */         int i = this._attrNames.size() - 2; while (true) { if (i >= 0) {
/*      */             
/*  441 */             if (this._attrNames.get(i).equals(attrName)) {
/*      */               
/*  443 */               this._attrNames.remove(this._attrNames.size() - 1); break;
/*      */             } 
/*      */             i--;
/*      */             continue;
/*      */           } 
/*  448 */           this._attrValues.add(this._cur.getAttrValue());
/*      */           
/*  450 */           ensureMapping(attrName.getNamespaceURI(), attrName.getPrefix(), false, true); break; }
/*      */       
/*      */       } 
/*      */     } 
/*  454 */     this._cur.pop();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  461 */     if (this._preComputedNamespaces != null) {
/*      */       
/*  463 */       for (Iterator i = this._preComputedNamespaces.keySet().iterator(); i.hasNext(); ) {
/*      */         
/*  465 */         String uri = i.next();
/*  466 */         String prefix = (String)this._preComputedNamespaces.get(uri);
/*  467 */         boolean considerDefault = (prefix.length() == 0 && !ensureDefaultEmpty);
/*      */         
/*  469 */         ensureMapping(uri, prefix, considerDefault, false);
/*      */       } 
/*      */ 
/*      */       
/*  473 */       this._preComputedNamespaces = null;
/*      */     } 
/*      */     
/*  476 */     if (emitElement(this._cur, this._attrNames, this._attrValues)) {
/*      */       
/*  478 */       popMappings();
/*  479 */       this._cur.toEnd();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean hasMappings() {
/*  494 */     int i = this._namespaceStack.size();
/*      */     
/*  496 */     return (i > 0 && this._namespaceStack.get(i - 1) != null);
/*      */   }
/*      */ 
/*      */   
/*      */   void iterateMappings() {
/*  501 */     this._currentMapping = this._namespaceStack.size();
/*      */     
/*  503 */     while (this._currentMapping > 0 && this._namespaceStack.get(this._currentMapping - 1) != null) {
/*  504 */       this._currentMapping -= 8;
/*      */     }
/*      */   }
/*      */   
/*      */   boolean hasMapping() {
/*  509 */     return (this._currentMapping < this._namespaceStack.size());
/*      */   }
/*      */ 
/*      */   
/*      */   void nextMapping() {
/*  514 */     this._currentMapping += 8;
/*      */   }
/*      */ 
/*      */   
/*      */   String mappingPrefix() {
/*  519 */     assert hasMapping();
/*  520 */     return this._namespaceStack.get(this._currentMapping + 6);
/*      */   }
/*      */ 
/*      */   
/*      */   String mappingUri() {
/*  525 */     assert hasMapping();
/*  526 */     return this._namespaceStack.get(this._currentMapping + 7);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void pushMappings(SaveCur c, boolean ensureDefaultEmpty) {
/*  531 */     assert c.isContainer();
/*      */     
/*  533 */     this._namespaceStack.add(null);
/*      */     
/*  535 */     c.push();
/*      */ 
/*      */     
/*  538 */     for (boolean A = c.toFirstAttr(); A; A = c.toNextAttr()) {
/*  539 */       if (c.isXmlns())
/*  540 */         addNewFrameMapping(c.getXmlnsPrefix(), c.getXmlnsUri(), ensureDefaultEmpty); 
/*      */     } 
/*  542 */     c.pop();
/*      */     
/*  544 */     if (this._ancestorNamespaces != null) {
/*      */       
/*  546 */       for (int i = 0; i < this._ancestorNamespaces.size(); i += 2) {
/*      */         
/*  548 */         String prefix = this._ancestorNamespaces.get(i);
/*  549 */         String uri = this._ancestorNamespaces.get(i + 1);
/*      */         
/*  551 */         addNewFrameMapping(prefix, uri, ensureDefaultEmpty);
/*      */       } 
/*      */       
/*  554 */       this._ancestorNamespaces = null;
/*      */     } 
/*      */     
/*  557 */     if (ensureDefaultEmpty) {
/*      */       
/*  559 */       String defaultUri = (String)this._prefixMap.get("");
/*      */ 
/*      */       
/*  562 */       assert defaultUri != null;
/*      */       
/*  564 */       if (defaultUri.length() > 0) {
/*  565 */         addMapping("", "");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void addNewFrameMapping(String prefix, String uri, boolean ensureDefaultEmpty) {
/*  575 */     if ((prefix.length() == 0 || uri.length() > 0) && (!ensureDefaultEmpty || prefix.length() > 0 || uri.length() == 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  580 */       iterateMappings(); for (; hasMapping(); nextMapping()) {
/*  581 */         if (mappingPrefix().equals(prefix)) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  588 */       if (uri.equals(getNamespaceForPrefix(prefix))) {
/*      */         return;
/*      */       }
/*  591 */       addMapping(prefix, uri);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void addMapping(String prefix, String uri) {
/*  597 */     assert uri != null;
/*  598 */     assert prefix != null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  604 */     String renameUri = (String)this._prefixMap.get(prefix);
/*  605 */     String renamePrefix = null;
/*      */     
/*  607 */     if (renameUri != null)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  612 */       if (renameUri.equals(uri)) {
/*  613 */         renameUri = null;
/*      */       } else {
/*      */         
/*  616 */         int i = this._namespaceStack.size();
/*      */         
/*  618 */         while (i > 0) {
/*      */           
/*  620 */           if (this._namespaceStack.get(i - 1) == null) {
/*      */             
/*  622 */             i--;
/*      */             
/*      */             continue;
/*      */           } 
/*  626 */           if (this._namespaceStack.get(i - 7).equals(renameUri)) {
/*      */             
/*  628 */             renamePrefix = this._namespaceStack.get(i - 8);
/*      */             
/*  630 */             if (renamePrefix == null || !renamePrefix.equals(prefix)) {
/*      */               break;
/*      */             }
/*      */           } 
/*  634 */           i -= 8;
/*      */         } 
/*      */         
/*  637 */         assert i > 0;
/*      */       } 
/*      */     }
/*      */     
/*  641 */     this._namespaceStack.add(this._uriMap.get(uri));
/*  642 */     this._namespaceStack.add(uri);
/*      */     
/*  644 */     if (renameUri != null) {
/*      */       
/*  646 */       this._namespaceStack.add(this._uriMap.get(renameUri));
/*  647 */       this._namespaceStack.add(renameUri);
/*      */     }
/*      */     else {
/*      */       
/*  651 */       this._namespaceStack.add(null);
/*  652 */       this._namespaceStack.add(null);
/*      */     } 
/*      */     
/*  655 */     this._namespaceStack.add(prefix);
/*  656 */     this._namespaceStack.add(this._prefixMap.get(prefix));
/*      */     
/*  658 */     this._namespaceStack.add(prefix);
/*  659 */     this._namespaceStack.add(uri);
/*      */     
/*  661 */     this._uriMap.put(uri, prefix);
/*  662 */     this._prefixMap.put(prefix, uri);
/*      */     
/*  664 */     if (renameUri != null) {
/*  665 */       this._uriMap.put(renameUri, renamePrefix);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void popMappings() {
/*      */     while (true) {
/*  672 */       int i = this._namespaceStack.size();
/*      */       
/*  674 */       if (i == 0) {
/*      */         break;
/*      */       }
/*  677 */       if (this._namespaceStack.get(i - 1) == null) {
/*      */         
/*  679 */         this._namespaceStack.remove(i - 1);
/*      */         
/*      */         break;
/*      */       } 
/*  683 */       Object oldUri = this._namespaceStack.get(i - 7);
/*  684 */       Object oldPrefix = this._namespaceStack.get(i - 8);
/*      */       
/*  686 */       if (oldPrefix == null) {
/*  687 */         this._uriMap.remove(oldUri);
/*      */       } else {
/*  689 */         this._uriMap.put(oldUri, oldPrefix);
/*      */       } 
/*  691 */       oldPrefix = this._namespaceStack.get(i - 4);
/*  692 */       oldUri = this._namespaceStack.get(i - 3);
/*      */       
/*  694 */       if (oldUri == null) {
/*  695 */         this._prefixMap.remove(oldPrefix);
/*      */       } else {
/*  697 */         this._prefixMap.put(oldPrefix, oldUri);
/*      */       } 
/*  699 */       String uri = this._namespaceStack.get(i - 5);
/*      */       
/*  701 */       if (uri != null) {
/*  702 */         this._uriMap.put(uri, this._namespaceStack.get(i - 6));
/*      */       }
/*      */       
/*  705 */       this._namespaceStack.remove(i - 1);
/*  706 */       this._namespaceStack.remove(i - 2);
/*  707 */       this._namespaceStack.remove(i - 3);
/*  708 */       this._namespaceStack.remove(i - 4);
/*  709 */       this._namespaceStack.remove(i - 5);
/*  710 */       this._namespaceStack.remove(i - 6);
/*  711 */       this._namespaceStack.remove(i - 7);
/*  712 */       this._namespaceStack.remove(i - 8);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void dumpMappings() {
/*  718 */     for (int i = this._namespaceStack.size(); i > 0; ) {
/*      */       
/*  720 */       if (this._namespaceStack.get(i - 1) == null) {
/*      */         
/*  722 */         System.out.println("----------------");
/*  723 */         i--;
/*      */         
/*      */         continue;
/*      */       } 
/*  727 */       System.out.print("Mapping: ");
/*  728 */       System.out.print(this._namespaceStack.get(i - 2));
/*  729 */       System.out.print(" -> ");
/*  730 */       System.out.print(this._namespaceStack.get(i - 1));
/*  731 */       System.out.println();
/*      */       
/*  733 */       System.out.print("Prefix Undo: ");
/*  734 */       System.out.print(this._namespaceStack.get(i - 4));
/*  735 */       System.out.print(" -> ");
/*  736 */       System.out.print(this._namespaceStack.get(i - 3));
/*  737 */       System.out.println();
/*      */       
/*  739 */       System.out.print("Uri Rename: ");
/*  740 */       System.out.print(this._namespaceStack.get(i - 5));
/*  741 */       System.out.print(" -> ");
/*  742 */       System.out.print(this._namespaceStack.get(i - 6));
/*  743 */       System.out.println();
/*      */       
/*  745 */       System.out.print("UriUndo: ");
/*  746 */       System.out.print(this._namespaceStack.get(i - 7));
/*  747 */       System.out.print(" -> ");
/*  748 */       System.out.print(this._namespaceStack.get(i - 8));
/*  749 */       System.out.println();
/*      */       
/*  751 */       System.out.println();
/*      */       
/*  753 */       i -= 8;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String ensureMapping(String uri, String candidatePrefix, boolean considerCreatingDefault, boolean mustHavePrefix) {
/*  761 */     assert uri != null;
/*      */ 
/*      */ 
/*      */     
/*  765 */     if (uri.length() == 0) {
/*  766 */       return null;
/*      */     }
/*  768 */     String prefix = (String)this._uriMap.get(uri);
/*      */     
/*  770 */     if (prefix != null && (prefix.length() > 0 || !mustHavePrefix)) {
/*  771 */       return prefix;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  782 */     if (candidatePrefix != null && candidatePrefix.length() == 0) {
/*  783 */       candidatePrefix = null;
/*      */     }
/*  785 */     if (candidatePrefix == null || !tryPrefix(candidatePrefix))
/*      */     {
/*  787 */       if (this._suggestedPrefixes != null && this._suggestedPrefixes.containsKey(uri) && tryPrefix((String)this._suggestedPrefixes.get(uri))) {
/*      */ 
/*      */ 
/*      */         
/*  791 */         candidatePrefix = (String)this._suggestedPrefixes.get(uri);
/*      */       }
/*  793 */       else if (considerCreatingDefault && this._useDefaultNamespace && tryPrefix("")) {
/*  794 */         candidatePrefix = "";
/*      */       } else {
/*      */         
/*  797 */         String basePrefix = QNameHelper.suggestPrefix(uri);
/*  798 */         candidatePrefix = basePrefix;
/*      */         
/*  800 */         int i = 1;
/*      */         
/*  802 */         for (; !tryPrefix(candidatePrefix); i++)
/*      */         {
/*      */           
/*  805 */           candidatePrefix = basePrefix + i;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  810 */     assert candidatePrefix != null;
/*      */     
/*  812 */     syntheticNamespace(candidatePrefix, uri, considerCreatingDefault);
/*      */     
/*  814 */     addMapping(candidatePrefix, uri);
/*      */     
/*  816 */     return candidatePrefix;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String getUriMapping(String uri) {
/*  821 */     assert this._uriMap.get(uri) != null;
/*  822 */     return (String)this._uriMap.get(uri);
/*      */   }
/*      */ 
/*      */   
/*      */   String getNonDefaultUriMapping(String uri) {
/*  827 */     String prefix = (String)this._uriMap.get(uri);
/*      */     
/*  829 */     if (prefix != null && prefix.length() > 0) {
/*  830 */       return prefix;
/*      */     }
/*  832 */     for (Iterator keys = this._prefixMap.keySet().iterator(); keys.hasNext(); ) {
/*      */       
/*  834 */       prefix = keys.next();
/*      */       
/*  836 */       if (prefix.length() > 0 && this._prefixMap.get(prefix).equals(uri)) {
/*  837 */         return prefix;
/*      */       }
/*      */     } 
/*  840 */     assert false : "Could not find non-default mapping";
/*      */     
/*  842 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean tryPrefix(String prefix) {
/*  847 */     if (prefix == null || Locale.beginsWithXml(prefix)) {
/*  848 */       return false;
/*      */     }
/*  850 */     String existingUri = (String)this._prefixMap.get(prefix);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  859 */     if (existingUri != null && (prefix.length() > 0 || existingUri != this._initialDefaultUri)) {
/*  860 */       return false;
/*      */     }
/*  862 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getNamespaceForPrefix(String prefix) {
/*  867 */     assert !prefix.equals("xml") || this._prefixMap.get(prefix).equals("http://www.w3.org/XML/1998/namespace");
/*      */     
/*  869 */     return (String)this._prefixMap.get(prefix);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Map getPrefixMap() {
/*  874 */     return this._prefixMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class SynthNamespaceSaver
/*      */     extends Saver
/*      */   {
/*  883 */     LinkedHashMap _synthNamespaces = new LinkedHashMap();
/*      */ 
/*      */     
/*      */     SynthNamespaceSaver(Cur c, XmlOptions options) {
/*  887 */       super(c, options);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void syntheticNamespace(String prefix, String uri, boolean considerCreatingDefault) {
/*  893 */       this._synthNamespaces.put(uri, considerCreatingDefault ? "" : prefix);
/*      */     }
/*      */     
/*      */     protected boolean emitElement(Saver.SaveCur c, ArrayList attrNames, ArrayList attrValues) {
/*  897 */       return false;
/*      */     }
/*      */     protected void emitFinish(Saver.SaveCur c) {}
/*      */     protected void emitText(Saver.SaveCur c) {}
/*      */     protected void emitComment(Saver.SaveCur c) {}
/*      */     protected void emitProcinst(Saver.SaveCur c) {}
/*      */     protected void emitDocType(String docTypeName, String publicId, String systemId) {}
/*      */     protected void emitStartDoc(Saver.SaveCur c) {}
/*      */     protected void emitEndDoc(Saver.SaveCur c) {} }
/*      */   static final class TextSaver extends Saver { private static final int _initialBufSize = 4096; private int _cdataLengthThreshold; private int _cdataEntityCountThreshold; private boolean _useCDataBookmarks;
/*      */     private boolean _isPrettyPrint;
/*      */     private int _lastEmitIn;
/*      */     private int _lastEmitCch;
/*      */     private int _free;
/*      */     private int _in;
/*      */     private int _out;
/*      */     private char[] _buf;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*  916 */     TextSaver(Cur c, XmlOptions options, String encoding) { super(c, options);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1879 */       this._cdataLengthThreshold = 32;
/* 1880 */       this._cdataEntityCountThreshold = 5;
/* 1881 */       this._useCDataBookmarks = false;
/* 1882 */       this._isPrettyPrint = false; boolean noSaveDecl = (options != null && options.hasOption("SAVE_NO_XML_DECL")); if (options != null && options.hasOption("SAVE_CDATA_LENGTH_THRESHOLD")) this._cdataLengthThreshold = ((Integer)options.get("SAVE_CDATA_LENGTH_THRESHOLD")).intValue();  if (options != null && options.hasOption("SAVE_CDATA_ENTITY_COUNT_THRESHOLD")) this._cdataEntityCountThreshold = ((Integer)options.get("SAVE_CDATA_ENTITY_COUNT_THRESHOLD")).intValue();  if (options != null && options.hasOption("LOAD_SAVE_CDATA_BOOKMARKS")) this._useCDataBookmarks = true;  if (options != null && options.hasOption("SAVE_PRETTY_PRINT")) this._isPrettyPrint = true;  this._in = this._out = 0; this._free = 0; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; if (encoding != null && !noSaveDecl) { XmlDocumentProperties props = Locale.getDocProps(c, false); String version = (props == null) ? null : props.getVersion(); if (version == null) version = "1.0";  emit("<?xml version=\""); emit(version); emit("\" encoding=\"" + encoding + "\"?>" + _newLine); }  }
/*      */     protected boolean emitElement(Saver.SaveCur c, ArrayList attrNames, ArrayList attrValues) { assert c.isElem(); emit('<'); emitName(c.getName(), false); if (saveNamespacesFirst()) emitNamespacesHelper();  for (int i = 0; i < attrNames.size(); i++) emitAttrHelper(attrNames.get(i), attrValues.get(i));  if (!saveNamespacesFirst()) emitNamespacesHelper();  if (!c.hasChildren() && !c.hasText()) { emit('/', '>'); return true; }  emit('>'); return false; }
/*      */     protected void emitFinish(Saver.SaveCur c) { emit('<', '/'); emitName(c.getName(), false); emit('>'); }
/*      */     protected void emitXmlns(String prefix, String uri) { assert prefix != null; assert uri != null; emit("xmlns"); if (prefix.length() > 0) { emit(':'); emit(prefix); }  emit('=', '"'); emit(uri); entitizeAttrValue(false); emit('"'); }
/*      */     private void emitNamespacesHelper() { iterateMappings(); for (; hasMapping(); nextMapping()) { emit(' '); emitXmlns(mappingPrefix(), mappingUri()); }  }
/*      */     private void emitAttrHelper(QName attrName, String attrValue) { emit(' '); emitName(attrName, true); emit('=', '"'); emit(attrValue); entitizeAttrValue(true); emit('"'); }
/*      */     protected void emitText(Saver.SaveCur c) { assert c.isText(); boolean forceCData = (this._useCDataBookmarks && c.isTextCData()); emit(c); entitizeContent(forceCData); }
/*      */     protected void emitComment(Saver.SaveCur c) { assert c.isComment(); emit("<!--"); c.push(); c.next(); emit(c); c.pop(); entitizeComment(); emit("-->"); }
/*      */     protected void emitProcinst(Saver.SaveCur c) { assert c.isProcinst(); emit("<?"); emit(c.getName().getLocalPart()); c.push(); c.next(); if (c.isText()) { emit(" "); emit(c); entitizeProcinst(); }  c.pop(); emit("?>"); }
/*      */     private void emitLiteral(String literal) { if (literal.indexOf("\"") < 0) { emit('"'); emit(literal); emit('"'); } else { emit('\''); emit(literal); emit('\''); }  }
/*      */     protected void emitDocType(String docTypeName, String publicId, String systemId) { assert docTypeName != null; emit("<!DOCTYPE "); emit(docTypeName); if (publicId == null && systemId != null) { emit(" SYSTEM "); emitLiteral(systemId); } else if (publicId != null) { emit(" PUBLIC "); emitLiteral(publicId); emit(" "); emitLiteral(systemId); }  emit(">"); emit(_newLine); }
/*      */     protected void emitStartDoc(Saver.SaveCur c) {}
/*      */     protected void emitEndDoc(Saver.SaveCur c) {}
/*      */     private void emitName(QName name, boolean needsPrefix) { assert name != null; String uri = name.getNamespaceURI(); assert uri != null; if (uri.length() != 0) { String prefix = name.getPrefix(); String mappedUri = getNamespaceForPrefix(prefix); if (mappedUri == null || !mappedUri.equals(uri)) prefix = getUriMapping(uri);  if (needsPrefix && prefix.length() == 0) prefix = getNonDefaultUriMapping(uri);  if (prefix.length() > 0) { emit(prefix); emit(':'); }  }  assert name.getLocalPart().length() > 0; emit(name.getLocalPart()); }
/*      */     private void emit(char ch) { assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; preEmit(1); this._buf[this._in] = ch; this._in = (this._in + 1) % this._buf.length; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; }
/*      */     private void emit(char ch1, char ch2) { if (preEmit(2)) return;  this._buf[this._in] = ch1; this._in = (this._in + 1) % this._buf.length; this._buf[this._in] = ch2; this._in = (this._in + 1) % this._buf.length; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; }
/*      */     private void emit(String s) { assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; int cch = (s == null) ? 0 : s.length(); if (preEmit(cch)) return;  int chunk; if (this._in <= this._out || cch < (chunk = this._buf.length - this._in)) { s.getChars(0, cch, this._buf, this._in); this._in += cch; } else { s.getChars(0, chunk, this._buf, this._in); s.getChars(chunk, cch, this._buf, 0); this._in = (this._in + cch) % this._buf.length; }  assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; }
/*      */     private void emit(Saver.SaveCur c) { if (c.isText()) { Object src = c.getChars(); int cch = c._cchSrc; if (preEmit(cch)) return;  int chunk; if (this._in <= this._out || cch < (chunk = this._buf.length - this._in)) { CharUtil.getChars(this._buf, this._in, src, c._offSrc, cch); this._in += cch; } else { CharUtil.getChars(this._buf, this._in, src, c._offSrc, chunk); CharUtil.getChars(this._buf, 0, src, c._offSrc + chunk, cch - chunk); this._in = (this._in + cch) % this._buf.length; }  } else { preEmit(0); }  }
/*      */     private boolean preEmit(int cch) { assert cch >= 0; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; this._lastEmitCch = cch; if (cch == 0) return true;  if (this._free <= cch) resize(cch, -1);  assert cch <= this._free; int used = getAvailable(); if (used == 0) { assert this._in == this._out; assert this._free == this._buf.length; this._in = this._out = 0; }  this._lastEmitIn = this._in; this._free -= cch; assert this._free >= 0; assert this._buf == null || this._free == ((this._in >= this._out) ? (this._buf.length - this._in - this._out) : (this._out - this._in)) - cch : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; assert (this._out > this._in && this._free == this._out - this._in - cch) || (this._out == this._in && this._free == this._buf.length - cch) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; return false; } private void entitizeContent(boolean forceCData) { assert this._free >= 0; if (this._lastEmitCch == 0) return;  int i = this._lastEmitIn; int n = this._buf.length; boolean hasCharToBeReplaced = false; int count = 0; char prevChar = Character.MIN_VALUE; char prevPrevChar = Character.MIN_VALUE; for (int cch = this._lastEmitCch; cch > 0; cch--) { char ch = this._buf[i]; if (ch == '<' || ch == '&') { count++; } else if (prevPrevChar == ']' && prevChar == ']' && ch == '>') { hasCharToBeReplaced = true; } else if (isBadChar(ch) || isEscapedChar(ch) || (!this._isPrettyPrint && ch == '\r')) { hasCharToBeReplaced = true; }  if (++i == n) i = 0;  prevPrevChar = prevChar; prevChar = ch; }  if (!forceCData && count == 0 && !hasCharToBeReplaced && count < this._cdataEntityCountThreshold) return;  i = this._lastEmitIn; if (forceCData || (this._lastEmitCch > this._cdataLengthThreshold && count > this._cdataEntityCountThreshold)) { boolean lastWasBracket = (this._buf[i] == ']'); i = replace(i, "<![CDATA[" + this._buf[i]); boolean secondToLastWasBracket = lastWasBracket; lastWasBracket = (this._buf[i] == ']'); if (++i == this._buf.length) i = 0;  for (int j = this._lastEmitCch; j > 0; j--) { char ch = this._buf[i]; if (ch == '>' && secondToLastWasBracket && lastWasBracket) { i = replace(i, "]]>><![CDATA["); } else if (isBadChar(ch)) { i = replace(i, "?"); } else { i++; }  secondToLastWasBracket = lastWasBracket; lastWasBracket = (ch == ']'); if (i == this._buf.length) i = 0;  }  emit("]]>"); } else { char ch = Character.MIN_VALUE, ch_1 = Character.MIN_VALUE; for (int j = this._lastEmitCch; j > 0; j--) { char ch_2 = ch_1; ch_1 = ch; ch = this._buf[i]; if (ch == '<') { i = replace(i, "&lt;"); } else if (ch == '&') { i = replace(i, "&amp;"); } else if (ch == '>' && ch_1 == ']' && ch_2 == ']') { i = replace(i, "&gt;"); } else if (isBadChar(ch)) { i = replace(i, "?"); } else if (!this._isPrettyPrint && ch == '\r') { i = replace(i, "&#13;"); } else if (isEscapedChar(ch)) { i = replace(i, this._replaceChar.getEscapedString(ch)); } else { i++; }  if (i == this._buf.length) i = 0;  }  }  } private void entitizeAttrValue(boolean replaceEscapedChar) { if (this._lastEmitCch == 0) return;  int i = this._lastEmitIn; for (int cch = this._lastEmitCch; cch > 0; cch--) { char ch = this._buf[i]; if (ch == '<') { i = replace(i, "&lt;"); } else if (ch == '&') { i = replace(i, "&amp;"); } else if (ch == '"') { i = replace(i, "&quot;"); } else if (isEscapedChar(ch)) { if (replaceEscapedChar) i = replace(i, this._replaceChar.getEscapedString(ch));  } else { i++; }  if (i == this._buf.length) i = 0;  }  } private void entitizeComment() { if (this._lastEmitCch == 0) return;  int i = this._lastEmitIn; boolean lastWasDash = false; for (int cch = this._lastEmitCch; cch > 0; cch--) { char ch = this._buf[i]; if (isBadChar(ch)) { i = replace(i, "?"); } else if (ch == '-') { if (lastWasDash) { i = replace(i, " "); lastWasDash = false; } else { lastWasDash = true; i++; }  } else { lastWasDash = false; i++; }  if (i == this._buf.length) i = 0;  }  int offset = (this._lastEmitIn + this._lastEmitCch - 1) % this._buf.length; if (this._buf[offset] == '-') i = replace(offset, " ");  } private void entitizeProcinst() { if (this._lastEmitCch == 0) return;  int i = this._lastEmitIn; boolean lastWasQuestion = false; for (int cch = this._lastEmitCch; cch > 0; cch--) { char ch = this._buf[i]; if (isBadChar(ch)) i = replace(i, "?");  if (ch == '>') { if (lastWasQuestion) { i = replace(i, " "); } else { i++; }  lastWasQuestion = false; } else { lastWasQuestion = (ch == '?'); i++; }  if (i == this._buf.length) i = 0;  }  } private boolean isBadChar(char ch) { return ((ch < ' ' || ch > '퟿') && (ch < '' || ch > '�') && (ch < 65536 || ch > 1114111) && ch != '\t' && ch != '\n' && ch != '\r'); } private boolean isEscapedChar(char ch) { return (null != this._replaceChar && this._replaceChar.containsChar(ch)); } private int replace(int i, String replacement) { assert replacement.length() > 0; int dCch = replacement.length() - 1; if (dCch == 0) { this._buf[i] = replacement.charAt(0); return i + 1; }  assert this._free >= 0; if (dCch > this._free) i = resize(dCch, i);  assert this._free >= 0; assert this._free >= dCch; assert getAvailable() > 0; int charsToCopy = dCch + 1; if (this._out > this._in && i >= this._out) { System.arraycopy(this._buf, this._out, this._buf, this._out - dCch, i - this._out); this._out -= dCch; i -= dCch; } else { assert i < this._in; int availableEndChunk = this._buf.length - this._in; if (dCch <= availableEndChunk) { System.arraycopy(this._buf, i, this._buf, i + dCch, this._in - i); this._in = (this._in + dCch) % this._buf.length; } else if (dCch <= availableEndChunk + this._in - i - 1) { int numToCopyToStart = dCch - availableEndChunk; System.arraycopy(this._buf, this._in - numToCopyToStart, this._buf, 0, numToCopyToStart); System.arraycopy(this._buf, i + 1, this._buf, i + 1 + dCch, this._in - i - 1 - numToCopyToStart); this._in = numToCopyToStart; } else { int numToCopyToStart = this._in - i - 1; charsToCopy = availableEndChunk + this._in - i; System.arraycopy(this._buf, this._in - numToCopyToStart, this._buf, dCch - charsToCopy + 1, numToCopyToStart); replacement.getChars(charsToCopy, dCch + 1, this._buf, 0); this._in = numToCopyToStart + dCch - charsToCopy + 1; }  }  replacement.getChars(0, charsToCopy, this._buf, i); this._free -= dCch; assert this._free >= 0; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; return (i + dCch + 1) % this._buf.length; } private int ensure(int cch) { if (cch <= 0) cch = 1;  int available = getAvailable(); for (; available < cch && process(); available = getAvailable()); assert available == getAvailable(); return available; } int getAvailable() { return (this._buf == null) ? 0 : (this._buf.length - this._free); } private int resize(int cch, int i) { assert this._free >= 0; assert cch > 0; assert cch >= this._free; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; int newLen = (this._buf == null) ? 4096 : (this._buf.length * 2); int used = getAvailable(); while (newLen - used < cch) newLen *= 2;  char[] newBuf = new char[newLen]; if (used > 0) { if (this._in > this._out) { assert i == -1 || (i >= this._out && i < this._in); System.arraycopy(this._buf, this._out, newBuf, 0, used); i -= this._out; } else { assert i == -1 || i >= this._out || i < this._in; System.arraycopy(this._buf, this._out, newBuf, 0, used - this._in); System.arraycopy(this._buf, 0, newBuf, used - this._in, this._in); i = (i >= this._out) ? (i - this._out) : (i + this._out); }  this._out = 0; this._in = used; this._free += newBuf.length - this._buf.length; } else { this._free = newBuf.length; assert this._in == 0 && this._out == 0; assert i == -1; }  this._buf = newBuf; assert this._free >= 0; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; return i; } public int read() { if (ensure(1) == 0) return -1;  assert getAvailable() > 0; int ch = this._buf[this._out]; this._out = (this._out + 1) % this._buf.length; this._free++; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; return ch; } public int read(char[] cbuf, int off, int len) { int n; if ((n = ensure(len)) == 0) return -1;  if (cbuf == null || len <= 0) return 0;  if (n < len) len = n;  if (this._out < this._in) { System.arraycopy(this._buf, this._out, cbuf, off, len); } else { int chunk = this._buf.length - this._out; if (chunk >= len) { System.arraycopy(this._buf, this._out, cbuf, off, len); } else { System.arraycopy(this._buf, this._out, cbuf, off, chunk); System.arraycopy(this._buf, 0, cbuf, off + chunk, len - chunk); }  }  this._out = (this._out + len) % this._buf.length; this._free += len; assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; assert this._free >= 0; return len; } public int write(Writer writer, int cchMin) { while (getAvailable() < cchMin) { if (!process()) break;  }  int charsAvailable = getAvailable(); if (charsAvailable > 0) { assert this._out == 0; assert this._in >= this._out : "_in:" + this._in + " < _out:" + this._out; assert this._free == this._buf.length - this._in; try { writer.write(this._buf, 0, charsAvailable); writer.flush(); } catch (IOException e) { throw new RuntimeException(e); }  this._free += charsAvailable; assert this._free >= 0; this._in = 0; }  assert (this._out > this._in && this._free == this._out - this._in) || (this._out == this._in && this._free == this._buf.length) || (this._out == this._in && this._free == 0) : "_buf.length:" + this._buf.length + " _in:" + this._in + " _out:" + this._out + " _free:" + this._free; return charsAvailable; } public String saveToString() { while (process()); assert this._out == 0; int available = getAvailable(); return (available == 0) ? "" : new String(this._buf, this._out, available); } }
/*      */    static final class OptimizedForSpeedSaver extends Saver
/*      */   {
/* 1903 */     private char[] _buf = new char[1024];
/*      */     Writer _w;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     private static class SaverIOException
/*      */       extends RuntimeException
/*      */     {
/*      */       SaverIOException(IOException e) {
/* 1911 */         super(e);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     OptimizedForSpeedSaver(Cur cur, Writer writer) {
/* 1918 */       super(cur, XmlOptions.maskNull(null));
/* 1919 */       this._w = writer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static void save(Cur cur, Writer writer) throws IOException {
/*      */       try {
/* 1927 */         Saver saver = new OptimizedForSpeedSaver(cur, writer);
/* 1928 */         while (saver.process());
/*      */       
/*      */       }
/* 1931 */       catch (SaverIOException e) {
/*      */         
/* 1933 */         throw (IOException)e.getCause();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void emit(String s) {
/*      */       try {
/* 1941 */         this._w.write(s);
/*      */       }
/* 1943 */       catch (IOException e) {
/*      */         
/* 1945 */         throw new SaverIOException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void emit(char c) {
/*      */       try {
/* 1953 */         this._buf[0] = c;
/* 1954 */         this._w.write(this._buf, 0, 1);
/*      */       }
/* 1956 */       catch (IOException e) {
/*      */         
/* 1958 */         throw new SaverIOException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void emit(char c1, char c2) {
/*      */       try {
/* 1966 */         this._buf[0] = c1;
/* 1967 */         this._buf[1] = c2;
/* 1968 */         this._w.write(this._buf, 0, 2);
/*      */       }
/* 1970 */       catch (IOException e) {
/*      */         
/* 1972 */         throw new SaverIOException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void emit(char[] buf, int start, int len) {
/*      */       try {
/* 1980 */         this._w.write(buf, start, len);
/*      */       }
/* 1982 */       catch (IOException e) {
/*      */         
/* 1984 */         throw new SaverIOException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean emitElement(Saver.SaveCur c, ArrayList attrNames, ArrayList attrValues) {
/* 1990 */       assert c.isElem();
/*      */       
/* 1992 */       emit('<');
/* 1993 */       emitName(c.getName(), false);
/*      */       
/* 1995 */       for (int i = 0; i < attrNames.size(); i++) {
/* 1996 */         emitAttrHelper(attrNames.get(i), attrValues.get(i));
/*      */       }
/* 1998 */       if (!saveNamespacesFirst()) {
/* 1999 */         emitNamespacesHelper();
/*      */       }
/* 2001 */       if (!c.hasChildren() && !c.hasText()) {
/*      */         
/* 2003 */         emit('/', '>');
/* 2004 */         return true;
/*      */       } 
/*      */ 
/*      */       
/* 2008 */       emit('>');
/* 2009 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void emitFinish(Saver.SaveCur c) {
/* 2015 */       emit('<', '/');
/* 2016 */       emitName(c.getName(), false);
/* 2017 */       emit('>');
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitXmlns(String prefix, String uri) {
/* 2022 */       assert prefix != null;
/* 2023 */       assert uri != null;
/*      */       
/* 2025 */       emit("xmlns");
/*      */       
/* 2027 */       if (prefix.length() > 0) {
/*      */         
/* 2029 */         emit(':');
/* 2030 */         emit(prefix);
/*      */       } 
/*      */       
/* 2033 */       emit('=', '"');
/*      */ 
/*      */       
/* 2036 */       emitAttrValue(uri);
/*      */       
/* 2038 */       emit('"');
/*      */     }
/*      */ 
/*      */     
/*      */     private void emitNamespacesHelper() {
/* 2043 */       iterateMappings(); for (; hasMapping(); nextMapping()) {
/*      */         
/* 2045 */         emit(' ');
/* 2046 */         emitXmlns(mappingPrefix(), mappingUri());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void emitAttrHelper(QName attrName, String attrValue) {
/* 2052 */       emit(' ');
/* 2053 */       emitName(attrName, true);
/* 2054 */       emit('=', '"');
/* 2055 */       emitAttrValue(attrValue);
/*      */       
/* 2057 */       emit('"');
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitComment(Saver.SaveCur c) {
/* 2062 */       assert c.isComment();
/*      */       
/* 2064 */       emit("<!--");
/*      */       
/* 2066 */       c.push();
/* 2067 */       c.next();
/*      */       
/* 2069 */       emitCommentText(c);
/*      */       
/* 2071 */       c.pop();
/*      */       
/* 2073 */       emit("-->");
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitProcinst(Saver.SaveCur c) {
/* 2078 */       assert c.isProcinst();
/*      */       
/* 2080 */       emit("<?");
/*      */ 
/*      */       
/* 2083 */       emit(c.getName().getLocalPart());
/*      */       
/* 2085 */       c.push();
/*      */       
/* 2087 */       c.next();
/*      */       
/* 2089 */       if (c.isText()) {
/*      */         
/* 2091 */         emit(' ');
/* 2092 */         emitPiText(c);
/*      */       } 
/*      */       
/* 2095 */       c.pop();
/*      */       
/* 2097 */       emit("?>");
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitDocType(String docTypeName, String publicId, String systemId) {
/* 2102 */       assert docTypeName != null;
/*      */       
/* 2104 */       emit("<!DOCTYPE ");
/* 2105 */       emit(docTypeName);
/*      */       
/* 2107 */       if (publicId == null && systemId != null) {
/*      */         
/* 2109 */         emit(" SYSTEM ");
/* 2110 */         emitLiteral(systemId);
/*      */       }
/* 2112 */       else if (publicId != null) {
/*      */         
/* 2114 */         emit(" PUBLIC ");
/* 2115 */         emitLiteral(publicId);
/* 2116 */         emit(' ');
/* 2117 */         emitLiteral(systemId);
/*      */       } 
/*      */       
/* 2120 */       emit('>');
/* 2121 */       emit(_newLine);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void emitStartDoc(Saver.SaveCur c) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void emitEndDoc(Saver.SaveCur c) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void emitName(QName name, boolean needsPrefix) {
/* 2138 */       assert name != null;
/*      */       
/* 2140 */       String uri = name.getNamespaceURI();
/*      */       
/* 2142 */       assert uri != null;
/*      */       
/* 2144 */       if (uri.length() != 0) {
/*      */         
/* 2146 */         String prefix = name.getPrefix();
/* 2147 */         String mappedUri = getNamespaceForPrefix(prefix);
/*      */         
/* 2149 */         if (mappedUri == null || !mappedUri.equals(uri)) {
/* 2150 */           prefix = getUriMapping(uri);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2159 */         if (needsPrefix && prefix.length() == 0) {
/* 2160 */           prefix = getNonDefaultUriMapping(uri);
/*      */         }
/* 2162 */         if (prefix.length() > 0) {
/*      */           
/* 2164 */           emit(prefix);
/* 2165 */           emit(':');
/*      */         } 
/*      */       } 
/*      */       
/* 2169 */       assert name.getLocalPart().length() > 0;
/*      */       
/* 2171 */       emit(name.getLocalPart());
/*      */     }
/*      */ 
/*      */     
/*      */     private void emitAttrValue(CharSequence attVal) {
/* 2176 */       int len = attVal.length();
/*      */       
/* 2178 */       for (int i = 0; i < len; i++) {
/*      */         
/* 2180 */         char ch = attVal.charAt(i);
/*      */         
/* 2182 */         if (ch == '<') {
/* 2183 */           emit("&lt;");
/* 2184 */         } else if (ch == '&') {
/* 2185 */           emit("&amp;");
/* 2186 */         } else if (ch == '"') {
/* 2187 */           emit("&quot;");
/*      */         } else {
/* 2189 */           emit(ch);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean isBadChar(char ch) {
/* 2199 */       return ((ch < ' ' || ch > '퟿') && (ch < '' || ch > '�') && (ch < 65536 || ch > 1114111) && ch != '\t' && ch != '\n' && ch != '\r');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void emitLiteral(String literal) {
/* 2211 */       if (literal.indexOf("\"") < 0) {
/*      */         
/* 2213 */         emit('"');
/* 2214 */         emit(literal);
/* 2215 */         emit('"');
/*      */       }
/*      */       else {
/*      */         
/* 2219 */         emit('\'');
/* 2220 */         emit(literal);
/* 2221 */         emit('\'');
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitText(Saver.SaveCur c) {
/* 2227 */       assert c.isText();
/*      */       
/* 2229 */       Object src = c.getChars();
/* 2230 */       int cch = c._cchSrc;
/* 2231 */       int off = c._offSrc;
/* 2232 */       int index = 0;
/* 2233 */       int indexLimit = 0;
/* 2234 */       while (index < cch) {
/*      */         
/* 2236 */         indexLimit = (index + 512 > cch) ? cch : (index + 512);
/* 2237 */         CharUtil.getChars(this._buf, 0, src, off + index, indexLimit - index);
/* 2238 */         entitizeAndWriteText(indexLimit - index);
/* 2239 */         index = indexLimit;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitPiText(Saver.SaveCur c) {
/* 2245 */       assert c.isText();
/*      */       
/* 2247 */       Object src = c.getChars();
/* 2248 */       int cch = c._cchSrc;
/* 2249 */       int off = c._offSrc;
/* 2250 */       int index = 0;
/* 2251 */       int indexLimit = 0;
/* 2252 */       while (index < cch) {
/*      */         
/* 2254 */         indexLimit = (index + 512 > cch) ? cch : 512;
/* 2255 */         CharUtil.getChars(this._buf, 0, src, off + index, indexLimit);
/* 2256 */         entitizeAndWritePIText(indexLimit - index);
/* 2257 */         index = indexLimit;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitCommentText(Saver.SaveCur c) {
/* 2263 */       assert c.isText();
/*      */       
/* 2265 */       Object src = c.getChars();
/* 2266 */       int cch = c._cchSrc;
/* 2267 */       int off = c._offSrc;
/* 2268 */       int index = 0;
/* 2269 */       int indexLimit = 0;
/* 2270 */       while (index < cch) {
/*      */         
/* 2272 */         indexLimit = (index + 512 > cch) ? cch : 512;
/* 2273 */         CharUtil.getChars(this._buf, 0, src, off + index, indexLimit);
/* 2274 */         entitizeAndWriteCommentText(indexLimit - index);
/* 2275 */         index = indexLimit;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void entitizeAndWriteText(int bufLimit) {
/* 2281 */       int index = 0;
/* 2282 */       for (int i = 0; i < bufLimit; i++) {
/*      */         
/* 2284 */         char c = this._buf[i];
/* 2285 */         switch (c) {
/*      */           
/*      */           case '<':
/* 2288 */             emit(this._buf, index, i - index);
/* 2289 */             emit("&lt;");
/* 2290 */             index = i + 1;
/*      */             break;
/*      */           case '&':
/* 2293 */             emit(this._buf, index, i - index);
/* 2294 */             emit("&amp;");
/* 2295 */             index = i + 1;
/*      */             break;
/*      */         } 
/*      */       } 
/* 2299 */       emit(this._buf, index, bufLimit - index);
/*      */     }
/*      */ 
/*      */     
/*      */     private void entitizeAndWriteCommentText(int bufLimit) {
/* 2304 */       boolean lastWasDash = false;
/*      */       
/* 2306 */       for (int i = 0; i < bufLimit; i++) {
/*      */         
/* 2308 */         char ch = this._buf[i];
/*      */         
/* 2310 */         if (isBadChar(ch)) {
/* 2311 */           this._buf[i] = '?';
/* 2312 */         } else if (ch == '-') {
/*      */           
/* 2314 */           if (lastWasDash)
/*      */           {
/*      */             
/* 2317 */             this._buf[i] = ' ';
/* 2318 */             lastWasDash = false;
/*      */           }
/*      */           else
/*      */           {
/* 2322 */             lastWasDash = true;
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 2327 */           lastWasDash = false;
/*      */         } 
/*      */         
/* 2330 */         if (i == this._buf.length) {
/* 2331 */           i = 0;
/*      */         }
/*      */       } 
/* 2334 */       if (this._buf[bufLimit - 1] == '-') {
/* 2335 */         this._buf[bufLimit - 1] = ' ';
/*      */       }
/* 2337 */       emit(this._buf, 0, bufLimit);
/*      */     }
/*      */ 
/*      */     
/*      */     private void entitizeAndWritePIText(int bufLimit) {
/* 2342 */       boolean lastWasQuestion = false;
/*      */       
/* 2344 */       for (int i = 0; i < bufLimit; i++) {
/*      */         
/* 2346 */         char ch = this._buf[i];
/*      */         
/* 2348 */         if (isBadChar(ch)) {
/*      */           
/* 2350 */           this._buf[i] = '?';
/* 2351 */           ch = '?';
/*      */         } 
/*      */         
/* 2354 */         if (ch == '>') {
/*      */ 
/*      */           
/* 2357 */           if (lastWasQuestion) {
/* 2358 */             this._buf[i] = ' ';
/*      */           }
/* 2360 */           lastWasQuestion = false;
/*      */         }
/*      */         else {
/*      */           
/* 2364 */           lastWasQuestion = (ch == '?');
/*      */         } 
/*      */       } 
/* 2367 */       emit(this._buf, 0, bufLimit);
/*      */     } }
/*      */   
/*      */   static final class TextReader extends Reader { private Locale _locale;
/*      */     private Saver.TextSaver _textSaver;
/*      */     private boolean _closed;
/*      */     
/*      */     TextReader(Cur c, XmlOptions options) {
/* 2375 */       this._textSaver = new Saver.TextSaver(c, options, null);
/* 2376 */       this._locale = c._locale;
/* 2377 */       this._closed = false;
/*      */     }
/*      */     public void close() throws IOException {
/* 2380 */       this._closed = true;
/*      */     } public boolean ready() throws IOException {
/* 2382 */       return !this._closed;
/*      */     }
/*      */     
/*      */     public int read() throws IOException {
/* 2386 */       checkClosed();
/*      */       
/* 2388 */       if (this._locale.noSync()) { this._locale.enter(); try { return this._textSaver.read(); } finally { this._locale.exit(); }  }
/* 2389 */        synchronized (this._locale) { this._locale.enter(); try { return this._textSaver.read(); } finally { this._locale.exit(); }
/*      */          }
/*      */     
/*      */     }
/*      */     public int read(char[] cbuf) throws IOException {
/* 2394 */       checkClosed();
/*      */       
/* 2396 */       if (this._locale.noSync()) { this._locale.enter(); try { return this._textSaver.read(cbuf, 0, (cbuf == null) ? 0 : cbuf.length); } finally { this._locale.exit(); }  }
/* 2397 */        synchronized (this._locale) { this._locale.enter(); try { return this._textSaver.read(cbuf, 0, (cbuf == null) ? 0 : cbuf.length); } finally { this._locale.exit(); }
/*      */          }
/*      */     
/*      */     }
/*      */     public int read(char[] cbuf, int off, int len) throws IOException {
/* 2402 */       checkClosed();
/*      */       
/* 2404 */       if (this._locale.noSync()) { this._locale.enter(); try { return this._textSaver.read(cbuf, off, len); } finally { this._locale.exit(); }  }
/* 2405 */        synchronized (this._locale) { this._locale.enter(); try { return this._textSaver.read(cbuf, off, len); } finally { this._locale.exit(); }
/*      */          }
/*      */     
/*      */     }
/*      */     private void checkClosed() throws IOException {
/* 2410 */       if (this._closed)
/* 2411 */         throw new IOException("Reader has been closed"); 
/*      */     } }
/*      */   
/*      */   static final class InputStreamSaver extends InputStream {
/*      */     private Locale _locale;
/*      */     private boolean _closed;
/*      */     private OutputStreamImpl _outStreamImpl;
/*      */     private Saver.TextSaver _textSaver;
/*      */     private OutputStreamWriter _converter;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     InputStreamSaver(Cur c, XmlOptions options) {
/* 2423 */       this._locale = c._locale;
/*      */       
/* 2425 */       this._closed = false;
/*      */       
/* 2427 */       assert this._locale.entered();
/*      */       
/* 2429 */       options = XmlOptions.maskNull(options);
/*      */       
/* 2431 */       this._outStreamImpl = new OutputStreamImpl();
/*      */       
/* 2433 */       String encoding = null;
/*      */       
/* 2435 */       XmlDocumentProperties props = Locale.getDocProps(c, false);
/*      */       
/* 2437 */       if (props != null && props.getEncoding() != null) {
/* 2438 */         encoding = EncodingMap.getIANA2JavaMapping(props.getEncoding());
/*      */       }
/* 2440 */       if (options.hasOption("CHARACTER_ENCODING")) {
/* 2441 */         encoding = (String)options.get("CHARACTER_ENCODING");
/*      */       }
/* 2443 */       if (encoding != null) {
/*      */         
/* 2445 */         String ianaEncoding = EncodingMap.getJava2IANAMapping(encoding);
/*      */         
/* 2447 */         if (ianaEncoding != null) {
/* 2448 */           encoding = ianaEncoding;
/*      */         }
/*      */       } 
/* 2451 */       if (encoding == null) {
/* 2452 */         encoding = EncodingMap.getJava2IANAMapping("UTF8");
/*      */       }
/* 2454 */       String javaEncoding = EncodingMap.getIANA2JavaMapping(encoding);
/*      */       
/* 2456 */       if (javaEncoding == null) {
/* 2457 */         throw new IllegalStateException("Unknown encoding: " + encoding);
/*      */       }
/*      */       
/*      */       try {
/* 2461 */         this._converter = new OutputStreamWriter(this._outStreamImpl, javaEncoding);
/*      */       }
/* 2463 */       catch (UnsupportedEncodingException e) {
/*      */         
/* 2465 */         throw new RuntimeException(e);
/*      */       } 
/*      */       
/* 2468 */       this._textSaver = new Saver.TextSaver(c, options, encoding);
/*      */     }
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 2473 */       this._closed = true;
/*      */     }
/*      */ 
/*      */     
/*      */     private void checkClosed() throws IOException {
/* 2478 */       if (this._closed) {
/* 2479 */         throw new IOException("Stream closed");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int read() throws IOException {
/* 2487 */       checkClosed();
/*      */       
/* 2489 */       if (this._locale.noSync()) { this._locale.enter(); try { return this._outStreamImpl.read(); } finally { this._locale.exit(); }  }
/* 2490 */        synchronized (this._locale) { this._locale.enter(); try { return this._outStreamImpl.read(); } finally { this._locale.exit(); }
/*      */          }
/*      */     
/*      */     }
/*      */     public int read(byte[] bbuf, int off, int len) throws IOException {
/* 2495 */       checkClosed();
/*      */       
/* 2497 */       if (bbuf == null) {
/* 2498 */         throw new NullPointerException("buf to read into is null");
/*      */       }
/* 2500 */       if (off < 0 || off > bbuf.length) {
/* 2501 */         throw new IndexOutOfBoundsException("Offset is not within buf");
/*      */       }
/* 2503 */       if (this._locale.noSync()) { this._locale.enter(); try { return this._outStreamImpl.read(bbuf, off, len); } finally { this._locale.exit(); }  }
/* 2504 */        synchronized (this._locale) { this._locale.enter(); try { return this._outStreamImpl.read(bbuf, off, len); } finally { this._locale.exit(); }
/*      */          }
/*      */     
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int ensure(int cbyte) {
/* 2513 */       if (cbyte <= 0) {
/* 2514 */         cbyte = 1;
/*      */       }
/* 2516 */       int bytesAvailable = this._outStreamImpl.getAvailable();
/*      */       
/* 2518 */       for (; bytesAvailable < cbyte; 
/* 2519 */         bytesAvailable = this._outStreamImpl.getAvailable()) {
/*      */         
/* 2521 */         if (this._textSaver.write(this._converter, 2048) < 2048) {
/*      */           break;
/*      */         }
/*      */       } 
/* 2525 */       bytesAvailable = this._outStreamImpl.getAvailable();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2530 */       return bytesAvailable;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int available() throws IOException {
/* 2536 */       if (this._locale.noSync()) {
/* 2537 */         this._locale.enter(); 
/* 2538 */         try { return ensure(1024); }
/* 2539 */         finally { this._locale.exit(); }
/*      */       
/* 2541 */       }  synchronized (this._locale) {
/* 2542 */         this._locale.enter(); try { return ensure(1024); } finally { this._locale.exit(); }
/*      */       
/*      */       } 
/*      */     }
/*      */     private final class OutputStreamImpl extends OutputStream { private static final int _initialBufSize = 4096; private int _free; private int _in; private int _out; private byte[] _buf; static final boolean $assertionsDisabled; private final Saver.InputStreamSaver this$0;
/*      */       private OutputStreamImpl() {}
/*      */       int read() {
/* 2549 */         if (Saver.InputStreamSaver.this.ensure(1) == 0) {
/* 2550 */           return -1;
/*      */         }
/* 2552 */         assert getAvailable() > 0;
/*      */         
/* 2554 */         int bite = this._buf[this._out];
/*      */         
/* 2556 */         this._out = (this._out + 1) % this._buf.length;
/* 2557 */         this._free++;
/*      */         
/* 2559 */         return bite;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       int read(byte[] bbuf, int off, int len) {
/*      */         int n;
/* 2570 */         if ((n = Saver.InputStreamSaver.this.ensure(len)) == 0) {
/* 2571 */           return -1;
/*      */         }
/* 2573 */         if (bbuf == null || len <= 0) {
/* 2574 */           return 0;
/*      */         }
/* 2576 */         if (n < len) {
/* 2577 */           len = n;
/*      */         }
/* 2579 */         if (this._out < this._in) {
/*      */           
/* 2581 */           System.arraycopy(this._buf, this._out, bbuf, off, len);
/*      */         }
/*      */         else {
/*      */           
/* 2585 */           int chunk = this._buf.length - this._out;
/*      */           
/* 2587 */           if (chunk >= len) {
/* 2588 */             System.arraycopy(this._buf, this._out, bbuf, off, len);
/*      */           } else {
/*      */             
/* 2591 */             System.arraycopy(this._buf, this._out, bbuf, off, chunk);
/*      */             
/* 2593 */             System.arraycopy(this._buf, 0, bbuf, off + chunk, len - chunk);
/*      */           } 
/*      */         } 
/*      */         
/* 2597 */         this._out = (this._out + len) % this._buf.length;
/* 2598 */         this._free += len;
/*      */ 
/*      */         
/* 2601 */         return len;
/*      */       }
/*      */ 
/*      */       
/*      */       int getAvailable() {
/* 2606 */         return (this._buf == null) ? 0 : (this._buf.length - this._free);
/*      */       }
/*      */ 
/*      */       
/*      */       public void write(int bite) {
/* 2611 */         if (this._free == 0) {
/* 2612 */           resize(1);
/*      */         }
/* 2614 */         assert this._free > 0;
/*      */         
/* 2616 */         this._buf[this._in] = (byte)bite;
/*      */         
/* 2618 */         this._in = (this._in + 1) % this._buf.length;
/* 2619 */         this._free--;
/*      */       }
/*      */ 
/*      */       
/*      */       public void write(byte[] buf, int off, int cbyte) {
/* 2624 */         assert cbyte >= 0;
/*      */         
/* 2626 */         if (cbyte == 0) {
/*      */           return;
/*      */         }
/* 2629 */         if (this._free < cbyte) {
/* 2630 */           resize(cbyte);
/*      */         }
/* 2632 */         if (this._in == this._out) {
/*      */           
/* 2634 */           assert getAvailable() == 0;
/* 2635 */           assert this._free == this._buf.length - getAvailable();
/* 2636 */           this._in = this._out = 0;
/*      */         } 
/*      */         
/* 2639 */         int chunk = this._buf.length - this._in;
/*      */         
/* 2641 */         if (this._in <= this._out || cbyte < chunk) {
/*      */           
/* 2643 */           System.arraycopy(buf, off, this._buf, this._in, cbyte);
/* 2644 */           this._in += cbyte;
/*      */         }
/*      */         else {
/*      */           
/* 2648 */           System.arraycopy(buf, off, this._buf, this._in, chunk);
/*      */           
/* 2650 */           System.arraycopy(buf, off + chunk, this._buf, 0, cbyte - chunk);
/*      */ 
/*      */           
/* 2653 */           this._in = (this._in + cbyte) % this._buf.length;
/*      */         } 
/*      */         
/* 2656 */         this._free -= cbyte;
/*      */       }
/*      */ 
/*      */       
/*      */       void resize(int cbyte) {
/* 2661 */         assert cbyte > this._free : cbyte + " !> " + this._free;
/*      */         
/* 2663 */         int newLen = (this._buf == null) ? 4096 : (this._buf.length * 2);
/* 2664 */         int used = getAvailable();
/*      */         
/* 2666 */         while (newLen - used < cbyte) {
/* 2667 */           newLen *= 2;
/*      */         }
/* 2669 */         byte[] newBuf = new byte[newLen];
/*      */         
/* 2671 */         if (used > 0) {
/*      */           
/* 2673 */           if (this._in > this._out) {
/* 2674 */             System.arraycopy(this._buf, this._out, newBuf, 0, used);
/*      */           } else {
/*      */             
/* 2677 */             System.arraycopy(this._buf, this._out, newBuf, 0, used - this._in);
/*      */ 
/*      */             
/* 2680 */             System.arraycopy(this._buf, 0, newBuf, used - this._in, this._in);
/*      */           } 
/*      */ 
/*      */           
/* 2684 */           this._out = 0;
/* 2685 */           this._in = used;
/* 2686 */           this._free += newBuf.length - this._buf.length;
/*      */         }
/*      */         else {
/*      */           
/* 2690 */           this._free = newBuf.length;
/* 2691 */           assert this._in == this._out;
/*      */         } 
/*      */         
/* 2694 */         this._buf = newBuf;
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class XmlInputStreamSaver
/*      */     extends Saver
/*      */   {
/*      */     private XmlEventImpl _in;
/*      */ 
/*      */     
/*      */     private XmlEventImpl _out;
/*      */ 
/*      */     
/*      */     static final boolean $assertionsDisabled;
/*      */ 
/*      */ 
/*      */     
/*      */     XmlInputStreamSaver(Cur c, XmlOptions options) {
/* 2716 */       super(c, options);
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean emitElement(Saver.SaveCur c, ArrayList attrNames, ArrayList attrValues) {
/* 2721 */       assert c.isElem();
/*      */       
/* 2723 */       iterateMappings(); for (; hasMapping(); nextMapping())
/*      */       {
/* 2725 */         enqueue(new StartPrefixMappingImpl(mappingPrefix(), mappingUri()));
/*      */       }
/*      */       
/* 2728 */       StartElementImpl.AttributeImpl lastAttr = null;
/* 2729 */       StartElementImpl.AttributeImpl attributes = null;
/* 2730 */       StartElementImpl.AttributeImpl namespaces = null;
/*      */       
/* 2732 */       for (int i = 0; i < attrNames.size(); i++) {
/*      */         
/* 2734 */         XMLName attXMLName = computeName(attrNames.get(i), this, true);
/* 2735 */         StartElementImpl.AttributeImpl attr = new StartElementImpl.NormalAttributeImpl(attXMLName, attrValues.get(i));
/*      */ 
/*      */         
/* 2738 */         if (attributes == null) {
/* 2739 */           attributes = attr;
/*      */         } else {
/* 2741 */           lastAttr._next = attr;
/*      */         } 
/* 2743 */         lastAttr = attr;
/*      */       } 
/*      */       
/* 2746 */       lastAttr = null;
/*      */       
/* 2748 */       iterateMappings(); for (; hasMapping(); nextMapping()) {
/*      */         
/* 2750 */         String prefix = mappingPrefix();
/* 2751 */         String uri = mappingUri();
/*      */         
/* 2753 */         StartElementImpl.AttributeImpl attr = new StartElementImpl.XmlnsAttributeImpl(prefix, uri);
/*      */ 
/*      */         
/* 2756 */         if (namespaces == null) {
/* 2757 */           namespaces = attr;
/*      */         } else {
/* 2759 */           lastAttr._next = attr;
/*      */         } 
/* 2761 */         lastAttr = attr;
/*      */       } 
/*      */ 
/*      */       
/* 2765 */       QName name = c.getName();
/* 2766 */       enqueue(new StartElementImpl(computeName(name, this, false), attributes, namespaces, getPrefixMap()));
/*      */       
/* 2768 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitFinish(Saver.SaveCur c) {
/* 2773 */       if (c.isRoot()) {
/* 2774 */         enqueue(new EndDocumentImpl());
/*      */       } else {
/*      */         
/* 2777 */         XMLName xmlName = computeName(c.getName(), this, false);
/* 2778 */         enqueue(new EndElementImpl(xmlName));
/*      */       } 
/*      */       
/* 2781 */       emitEndPrefixMappings();
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitText(Saver.SaveCur c) {
/* 2786 */       assert c.isText();
/* 2787 */       Object src = c.getChars();
/* 2788 */       int cch = c._cchSrc;
/* 2789 */       int off = c._offSrc;
/*      */       
/* 2791 */       enqueue(new CharacterDataImpl(src, cch, off));
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitComment(Saver.SaveCur c) {
/* 2796 */       enqueue(new CommentImpl(c.getChars(), c._cchSrc, c._offSrc));
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitProcinst(Saver.SaveCur c) {
/* 2801 */       String target = null;
/* 2802 */       QName name = c.getName();
/*      */       
/* 2804 */       if (name != null) {
/* 2805 */         target = name.getLocalPart();
/*      */       }
/* 2807 */       enqueue(new ProcessingInstructionImpl(target, c.getChars(), c._cchSrc, c._offSrc));
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitDocType(String doctypeName, String publicID, String systemID) {
/* 2812 */       enqueue(new StartDocumentImpl(systemID, null, true, null));
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitStartDoc(Saver.SaveCur c) {
/* 2817 */       emitDocType((String)null, (String)null, (String)null);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitEndDoc(Saver.SaveCur c) {
/* 2822 */       enqueue(new EndDocumentImpl());
/*      */     }
/*      */ 
/*      */     
/*      */     XMLEvent dequeue() {
/* 2827 */       if (this._out == null) {
/*      */         
/* 2829 */         enterLocale();
/*      */         
/*      */         try {
/* 2832 */           if (!process()) {
/* 2833 */             return null;
/*      */           }
/*      */         } finally {
/*      */           
/* 2837 */           exitLocale();
/*      */         } 
/*      */       } 
/*      */       
/* 2841 */       if (this._out == null) {
/* 2842 */         return null;
/*      */       }
/* 2844 */       XmlEventImpl e = this._out;
/*      */       
/* 2846 */       if ((this._out = this._out._next) == null) {
/* 2847 */         this._in = null;
/*      */       }
/* 2849 */       return (XMLEvent)e;
/*      */     }
/*      */ 
/*      */     
/*      */     private void enqueue(XmlEventImpl e) {
/* 2854 */       assert e._next == null;
/*      */       
/* 2856 */       if (this._in == null) {
/*      */         
/* 2858 */         assert this._out == null;
/* 2859 */         this._out = this._in = e;
/*      */       }
/*      */       else {
/*      */         
/* 2863 */         this._in._next = e;
/* 2864 */         this._in = e;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void emitEndPrefixMappings() {
/* 2874 */       iterateMappings(); for (; hasMapping(); nextMapping()) {
/*      */         
/* 2876 */         String prevPrefixUri = null;
/* 2877 */         String prefix = mappingPrefix();
/* 2878 */         String uri = mappingUri();
/*      */         
/* 2880 */         if (prevPrefixUri == null) {
/* 2881 */           enqueue(new EndPrefixMappingImpl(prefix));
/*      */         } else {
/*      */           
/* 2884 */           enqueue(new ChangePrefixMappingImpl(prefix, uri, prevPrefixUri));
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static XMLName computeName(QName name, Saver saver, boolean needsPrefix) {
/* 2895 */       String uri = name.getNamespaceURI();
/* 2896 */       String local = name.getLocalPart();
/*      */       
/* 2898 */       assert uri != null;
/* 2899 */       assert local.length() > 0;
/*      */       
/* 2901 */       String prefix = null;
/*      */       
/* 2903 */       if (uri != null && uri.length() != 0) {
/*      */         
/* 2905 */         prefix = name.getPrefix();
/* 2906 */         String mappedUri = saver.getNamespaceForPrefix(prefix);
/*      */         
/* 2908 */         if (mappedUri == null || !mappedUri.equals(uri)) {
/* 2909 */           prefix = saver.getUriMapping(uri);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2918 */         if (needsPrefix && prefix.length() == 0) {
/* 2919 */           prefix = saver.getNonDefaultUriMapping(uri);
/*      */         }
/*      */       } 
/*      */       
/* 2923 */       return (XMLName)new XmlNameImpl(uri, local, prefix);
/*      */     }
/*      */     
/*      */     private static abstract class XmlEventImpl extends XmlEventBase {
/*      */       XmlEventImpl _next;
/*      */       
/*      */       XmlEventImpl(int type) {
/* 2930 */         super(type);
/*      */       }
/*      */ 
/*      */       
/*      */       public XMLName getName() {
/* 2935 */         return null;
/*      */       }
/*      */ 
/*      */       
/*      */       public XMLName getSchemaType() {
/* 2940 */         throw new RuntimeException("NYI");
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean hasName() {
/* 2945 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public final Location getLocation() {
/* 2951 */         return null;
/*      */       }
/*      */     }
/*      */     
/*      */     private static class StartDocumentImpl extends XmlEventImpl implements StartDocument {
/*      */       String _systemID;
/*      */       String _encoding;
/*      */       boolean _standAlone;
/*      */       String _version;
/*      */       
/*      */       StartDocumentImpl(String systemID, String encoding, boolean isStandAlone, String version) {
/* 2962 */         super(256);
/* 2963 */         this._systemID = systemID;
/* 2964 */         this._encoding = encoding;
/* 2965 */         this._standAlone = isStandAlone;
/* 2966 */         this._version = version;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getSystemId() {
/* 2971 */         return this._systemID;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getCharacterEncodingScheme() {
/* 2976 */         return this._encoding;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean isStandalone() {
/* 2981 */         return this._standAlone;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getVersion() {
/* 2986 */         return this._version;
/*      */       }
/*      */     }
/*      */     
/*      */     private static class StartElementImpl
/*      */       extends XmlEventImpl
/*      */       implements StartElement
/*      */     {
/*      */       private XMLName _name;
/*      */       private Map _prefixMap;
/*      */       private AttributeImpl _attributes;
/*      */       private AttributeImpl _namespaces;
/*      */       
/*      */       StartElementImpl(XMLName name, AttributeImpl attributes, AttributeImpl namespaces, Map prefixMap) {
/* 3000 */         super(2);
/*      */         
/* 3002 */         this._name = name;
/* 3003 */         this._attributes = attributes;
/* 3004 */         this._namespaces = namespaces;
/* 3005 */         this._prefixMap = prefixMap;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean hasName() {
/* 3010 */         return true;
/*      */       }
/*      */ 
/*      */       
/*      */       public XMLName getName() {
/* 3015 */         return this._name;
/*      */       }
/*      */ 
/*      */       
/*      */       public AttributeIterator getAttributes() {
/* 3020 */         return new AttributeIteratorImpl(this._attributes, null);
/*      */       }
/*      */ 
/*      */       
/*      */       public AttributeIterator getNamespaces() {
/* 3025 */         return new AttributeIteratorImpl(null, this._namespaces);
/*      */       }
/*      */ 
/*      */       
/*      */       public AttributeIterator getAttributesAndNamespaces() {
/* 3030 */         return new AttributeIteratorImpl(this._attributes, this._namespaces);
/*      */       }
/*      */ 
/*      */       
/*      */       public Attribute getAttributeByName(XMLName xmlName) {
/* 3035 */         for (AttributeImpl a = this._attributes; a != null; a = a._next) {
/*      */           
/* 3037 */           if (xmlName.equals(a.getName())) {
/* 3038 */             return a;
/*      */           }
/*      */         } 
/* 3041 */         return null;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getNamespaceUri(String prefix) {
/* 3046 */         return (String)this._prefixMap.get((prefix == null) ? "" : prefix);
/*      */       }
/*      */ 
/*      */       
/*      */       public Map getNamespaceMap() {
/* 3051 */         return this._prefixMap;
/*      */       }
/*      */       
/*      */       private static class AttributeIteratorImpl implements AttributeIterator {
/*      */         private Saver.XmlInputStreamSaver.StartElementImpl.AttributeImpl _attributes;
/*      */         private Saver.XmlInputStreamSaver.StartElementImpl.AttributeImpl _namespaces;
/*      */         
/*      */         AttributeIteratorImpl(Saver.XmlInputStreamSaver.StartElementImpl.AttributeImpl attributes, Saver.XmlInputStreamSaver.StartElementImpl.AttributeImpl namespaces) {
/* 3059 */           this._attributes = attributes;
/* 3060 */           this._namespaces = namespaces;
/*      */         }
/*      */ 
/*      */         
/*      */         public Object monitor() {
/* 3065 */           return this;
/*      */         }
/*      */ 
/*      */         
/*      */         public Attribute next() {
/* 3070 */           synchronized (monitor()) {
/*      */             
/* 3072 */             checkVersion();
/*      */             
/* 3074 */             Saver.XmlInputStreamSaver.StartElementImpl.AttributeImpl attr = null;
/*      */             
/* 3076 */             if (this._attributes != null) {
/*      */               
/* 3078 */               attr = this._attributes;
/* 3079 */               this._attributes = attr._next;
/*      */             }
/* 3081 */             else if (this._namespaces != null) {
/*      */               
/* 3083 */               attr = this._namespaces;
/* 3084 */               this._namespaces = attr._next;
/*      */             } 
/*      */             
/* 3087 */             return attr;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean hasNext() {
/* 3093 */           synchronized (monitor()) {
/*      */             
/* 3095 */             checkVersion();
/*      */             
/* 3097 */             return (this._attributes != null || this._namespaces != null);
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public Attribute peek() {
/* 3103 */           synchronized (monitor()) {
/*      */             
/* 3105 */             checkVersion();
/*      */             
/* 3107 */             if (this._attributes != null)
/* 3108 */               return this._attributes; 
/* 3109 */             if (this._namespaces != null) {
/* 3110 */               return this._namespaces;
/*      */             }
/* 3112 */             return null;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public void skip() {
/* 3118 */           synchronized (monitor()) {
/*      */             
/* 3120 */             checkVersion();
/*      */             
/* 3122 */             if (this._attributes != null) {
/* 3123 */               this._attributes = this._attributes._next;
/* 3124 */             } else if (this._namespaces != null) {
/* 3125 */               this._namespaces = this._namespaces._next;
/*      */             } 
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final void checkVersion() {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private static abstract class AttributeImpl
/*      */         implements Attribute
/*      */       {
/*      */         AttributeImpl _next;
/*      */ 
/*      */ 
/*      */         
/*      */         protected XMLName _name;
/*      */ 
/*      */ 
/*      */         
/*      */         public XMLName getName() {
/* 3151 */           return this._name;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public String getType() {
/* 3158 */           return "CDATA";
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public XMLName getSchemaType() {
/* 3164 */           return null;
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       private static class XmlnsAttributeImpl
/*      */         extends AttributeImpl
/*      */       {
/*      */         private String _uri;
/*      */ 
/*      */         
/*      */         XmlnsAttributeImpl(String prefix, String uri) {
/*      */           String local;
/* 3177 */           this._uri = uri;
/*      */ 
/*      */ 
/*      */           
/* 3181 */           if (prefix.length() == 0) {
/*      */             
/* 3183 */             prefix = null;
/* 3184 */             local = "xmlns";
/*      */           }
/*      */           else {
/*      */             
/* 3188 */             local = prefix;
/* 3189 */             prefix = "xmlns";
/*      */           } 
/*      */           
/* 3192 */           this._name = (XMLName)new XmlNameImpl(null, local, prefix);
/*      */         }
/*      */ 
/*      */         
/*      */         public String getValue() {
/* 3197 */           return this._uri;
/*      */         }
/*      */       }
/*      */       
/*      */       private static class NormalAttributeImpl
/*      */         extends AttributeImpl
/*      */       {
/*      */         private String _value;
/*      */         
/*      */         NormalAttributeImpl(XMLName name, String value) {
/* 3207 */           this._name = name;
/* 3208 */           this._value = value;
/*      */         }
/*      */         
/*      */         public String getValue()
/*      */         {
/* 3213 */           return this._value; } } } private static abstract class AttributeImpl implements Attribute { AttributeImpl _next; protected XMLName _name; public XMLName getName() { return this._name; } public String getType() { return "CDATA"; } public XMLName getSchemaType() { return null; } } private static class XmlnsAttributeImpl extends StartElementImpl.AttributeImpl { private String _uri; XmlnsAttributeImpl(String prefix, String uri) { String local; this._uri = uri; if (prefix.length() == 0) { prefix = null; local = "xmlns"; } else { local = prefix; prefix = "xmlns"; }  this._name = (XMLName)new XmlNameImpl(null, local, prefix); } public String getValue() { return this._uri; } } private static class NormalAttributeImpl extends StartElementImpl.AttributeImpl { private String _value; NormalAttributeImpl(XMLName name, String value) { this._name = name; this._value = value; } public String getValue() { return this._value; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static class StartPrefixMappingImpl
/*      */       extends XmlEventImpl
/*      */       implements StartPrefixMapping
/*      */     {
/*      */       private String _prefix;
/*      */ 
/*      */       
/*      */       private String _uri;
/*      */ 
/*      */ 
/*      */       
/*      */       StartPrefixMappingImpl(String prefix, String uri) {
/* 3231 */         super(1024);
/*      */         
/* 3233 */         this._prefix = prefix;
/* 3234 */         this._uri = uri;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getNamespaceUri() {
/* 3239 */         return this._uri;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getPrefix() {
/* 3244 */         return this._prefix;
/*      */       }
/*      */     }
/*      */     
/*      */     private static class ChangePrefixMappingImpl
/*      */       extends XmlEventImpl implements ChangePrefixMapping {
/*      */       private String _oldUri;
/*      */       private String _newUri;
/*      */       private String _prefix;
/*      */       
/*      */       ChangePrefixMappingImpl(String prefix, String oldUri, String newUri) {
/* 3255 */         super(4096);
/*      */         
/* 3257 */         this._oldUri = oldUri;
/* 3258 */         this._newUri = newUri;
/* 3259 */         this._prefix = prefix;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getOldNamespaceUri() {
/* 3264 */         return this._oldUri;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getNewNamespaceUri() {
/* 3269 */         return this._newUri;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getPrefix() {
/* 3274 */         return this._prefix;
/*      */       }
/*      */     }
/*      */     
/*      */     private static class EndPrefixMappingImpl
/*      */       extends XmlEventImpl
/*      */       implements EndPrefixMapping
/*      */     {
/*      */       private String _prefix;
/*      */       
/*      */       EndPrefixMappingImpl(String prefix) {
/* 3285 */         super(2048);
/* 3286 */         this._prefix = prefix;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getPrefix() {
/* 3291 */         return this._prefix;
/*      */       }
/*      */     }
/*      */     
/*      */     private static class EndElementImpl
/*      */       extends XmlEventImpl
/*      */       implements EndElement
/*      */     {
/*      */       private XMLName _name;
/*      */       
/*      */       EndElementImpl(XMLName name) {
/* 3302 */         super(4);
/*      */         
/* 3304 */         this._name = name;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean hasName() {
/* 3309 */         return true;
/*      */       }
/*      */ 
/*      */       
/*      */       public XMLName getName() {
/* 3314 */         return this._name;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static class EndDocumentImpl
/*      */       extends XmlEventImpl
/*      */       implements EndDocument
/*      */     {
/*      */       EndDocumentImpl() {
/* 3325 */         super(512);
/*      */       } }
/*      */     
/*      */     private static class TripletEventImpl extends XmlEventImpl implements CharacterData {
/*      */       private Object _obj;
/*      */       private int _cch;
/*      */       private int _off;
/*      */       
/*      */       TripletEventImpl(int eventType, Object obj, int cch, int off) {
/* 3334 */         super(eventType);
/* 3335 */         this._obj = obj;
/* 3336 */         this._cch = cch;
/* 3337 */         this._off = off;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getContent() {
/* 3342 */         return CharUtil.getString(this._obj, this._off, this._cch);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean hasContent() {
/* 3347 */         return (this._cch > 0);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static class CharacterDataImpl
/*      */       extends TripletEventImpl
/*      */       implements CharacterData
/*      */     {
/*      */       CharacterDataImpl(Object obj, int cch, int off) {
/* 3360 */         super(16, obj, cch, off);
/*      */       }
/*      */     }
/*      */     
/*      */     private static class CommentImpl
/*      */       extends TripletEventImpl
/*      */       implements Comment
/*      */     {
/*      */       CommentImpl(Object obj, int cch, int off) {
/* 3369 */         super(32, obj, cch, off);
/*      */       }
/*      */     }
/*      */     
/*      */     private static class ProcessingInstructionImpl
/*      */       extends TripletEventImpl implements ProcessingInstruction {
/*      */       private String _target;
/*      */       
/*      */       ProcessingInstructionImpl(String target, Object obj, int cch, int off) {
/* 3378 */         super(8, obj, cch, off);
/* 3379 */         this._target = target;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getTarget() {
/* 3384 */         return this._target;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getData() {
/* 3389 */         return getContent();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static final class XmlInputStreamImpl
/*      */     extends GenericXmlInputStream
/*      */   {
/*      */     private Saver.XmlInputStreamSaver _xmlInputStreamSaver;
/*      */ 
/*      */     
/*      */     XmlInputStreamImpl(Cur cur, XmlOptions options) {
/* 3402 */       this._xmlInputStreamSaver = new Saver.XmlInputStreamSaver(cur, options);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3408 */       this._xmlInputStreamSaver.process();
/*      */     }
/*      */ 
/*      */     
/*      */     protected XMLEvent nextEvent() throws XMLStreamException {
/* 3413 */       return this._xmlInputStreamSaver.dequeue();
/*      */     } }
/*      */   
/*      */   static final class SaxSaver extends Saver { private ContentHandler _contentHandler;
/*      */     private LexicalHandler _lexicalHandler;
/*      */     private AttributesImpl _attributes;
/*      */     private char[] _buf;
/*      */     private boolean _nsAsAttrs;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     SaxSaver(Cur c, XmlOptions options, ContentHandler ch, LexicalHandler lh) throws SAXException {
/* 3424 */       super(c, options);
/*      */       
/* 3426 */       this._contentHandler = ch;
/* 3427 */       this._lexicalHandler = lh;
/*      */       
/* 3429 */       this._attributes = new AttributesImpl();
/* 3430 */       this._nsAsAttrs = !options.hasOption("SAVE_SAX_NO_NSDECLS_IN_ATTRIBUTES");
/*      */       
/* 3432 */       this._contentHandler.startDocument();
/*      */ 
/*      */       
/*      */       try {
/* 3436 */         while (process());
/*      */       
/*      */       }
/* 3439 */       catch (SaverSAXException e) {
/*      */         
/* 3441 */         throw e._saxException;
/*      */       } 
/*      */       
/* 3444 */       this._contentHandler.endDocument();
/*      */     }
/*      */     
/*      */     private class SaverSAXException extends RuntimeException { SAXException _saxException;
/*      */       private final Saver.SaxSaver this$0;
/*      */       
/*      */       SaverSAXException(SAXException e) {
/* 3451 */         this._saxException = e;
/*      */       } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String getPrefixedName(QName name) {
/* 3459 */       String uri = name.getNamespaceURI();
/* 3460 */       String local = name.getLocalPart();
/*      */       
/* 3462 */       if (uri.length() == 0) {
/* 3463 */         return local;
/*      */       }
/* 3465 */       String prefix = getUriMapping(uri);
/*      */       
/* 3467 */       if (prefix.length() == 0) {
/* 3468 */         return local;
/*      */       }
/* 3470 */       return prefix + ":" + local;
/*      */     }
/*      */ 
/*      */     
/*      */     private void emitNamespacesHelper() {
/* 3475 */       iterateMappings(); for (; hasMapping(); nextMapping()) {
/*      */         
/* 3477 */         String prefix = mappingPrefix();
/* 3478 */         String uri = mappingUri();
/*      */ 
/*      */         
/*      */         try {
/* 3482 */           this._contentHandler.startPrefixMapping(prefix, uri);
/*      */         }
/* 3484 */         catch (SAXException e) {
/*      */           
/* 3486 */           throw new SaverSAXException(e);
/*      */         } 
/*      */         
/* 3489 */         if (this._nsAsAttrs)
/* 3490 */           if (prefix == null || prefix.length() == 0) {
/* 3491 */             this._attributes.addAttribute("http://www.w3.org/2000/xmlns/", "xmlns", "xmlns", "CDATA", uri);
/*      */           } else {
/* 3493 */             this._attributes.addAttribute("http://www.w3.org/2000/xmlns/", prefix, "xmlns:" + prefix, "CDATA", uri);
/*      */           }  
/*      */       } 
/*      */     }
/*      */     
/*      */     protected boolean emitElement(Saver.SaveCur c, ArrayList attrNames, ArrayList attrValues) {
/* 3499 */       this._attributes.clear();
/*      */       
/* 3501 */       if (saveNamespacesFirst()) {
/* 3502 */         emitNamespacesHelper();
/*      */       }
/* 3504 */       for (int i = 0; i < attrNames.size(); i++) {
/*      */         
/* 3506 */         QName name = attrNames.get(i);
/*      */         
/* 3508 */         this._attributes.addAttribute(name.getNamespaceURI(), name.getLocalPart(), getPrefixedName(name), "CDATA", attrValues.get(i));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3513 */       if (!saveNamespacesFirst()) {
/* 3514 */         emitNamespacesHelper();
/*      */       }
/* 3516 */       QName elemName = c.getName();
/*      */ 
/*      */       
/*      */       try {
/* 3520 */         this._contentHandler.startElement(elemName.getNamespaceURI(), elemName.getLocalPart(), getPrefixedName(elemName), this._attributes);
/*      */ 
/*      */       
/*      */       }
/* 3524 */       catch (SAXException e) {
/*      */         
/* 3526 */         throw new SaverSAXException(e);
/*      */       } 
/*      */       
/* 3529 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitFinish(Saver.SaveCur c) {
/* 3534 */       QName name = c.getName();
/*      */ 
/*      */       
/*      */       try {
/* 3538 */         this._contentHandler.endElement(name.getNamespaceURI(), name.getLocalPart(), getPrefixedName(name));
/*      */ 
/*      */         
/* 3541 */         iterateMappings(); for (; hasMapping(); nextMapping()) {
/* 3542 */           this._contentHandler.endPrefixMapping(mappingPrefix());
/*      */         }
/* 3544 */       } catch (SAXException e) {
/*      */         
/* 3546 */         throw new SaverSAXException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitText(Saver.SaveCur c) {
/* 3552 */       assert c.isText();
/*      */       
/* 3554 */       Object src = c.getChars();
/*      */ 
/*      */       
/*      */       try {
/* 3558 */         if (src instanceof char[]) {
/*      */ 
/*      */           
/* 3561 */           this._contentHandler.characters((char[])src, c._offSrc, c._cchSrc);
/*      */         }
/*      */         else {
/*      */           
/* 3565 */           if (this._buf == null) {
/* 3566 */             this._buf = new char[1024];
/*      */           }
/* 3568 */           while (c._cchSrc > 0)
/*      */           {
/* 3570 */             int cch = Math.min(this._buf.length, c._cchSrc);
/*      */             
/* 3572 */             CharUtil.getChars(this._buf, 0, src, c._offSrc, cch);
/*      */             
/* 3574 */             this._contentHandler.characters(this._buf, 0, cch);
/*      */             
/* 3576 */             c._offSrc += cch;
/* 3577 */             c._cchSrc -= cch;
/*      */           }
/*      */         
/*      */         } 
/* 3581 */       } catch (SAXException e) {
/*      */         
/* 3583 */         throw new SaverSAXException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitComment(Saver.SaveCur c) {
/* 3589 */       if (this._lexicalHandler != null) {
/*      */         
/* 3591 */         c.push();
/*      */         
/* 3593 */         c.next();
/*      */ 
/*      */         
/*      */         try {
/* 3597 */           if (!c.isText()) {
/* 3598 */             this._lexicalHandler.comment(null, 0, 0);
/*      */           } else {
/*      */             
/* 3601 */             Object src = c.getChars();
/*      */             
/* 3603 */             if (src instanceof char[])
/*      */             {
/*      */               
/* 3606 */               this._lexicalHandler.comment((char[])src, c._offSrc, c._cchSrc);
/*      */             }
/*      */             else
/*      */             {
/* 3610 */               if (this._buf == null || this._buf.length < c._cchSrc) {
/* 3611 */                 this._buf = new char[Math.max(1024, c._cchSrc)];
/*      */               }
/* 3613 */               CharUtil.getChars(this._buf, 0, src, c._offSrc, c._cchSrc);
/*      */               
/* 3615 */               this._lexicalHandler.comment(this._buf, 0, c._cchSrc);
/*      */             }
/*      */           
/*      */           } 
/* 3619 */         } catch (SAXException e) {
/*      */           
/* 3621 */           throw new SaverSAXException(e);
/*      */         } 
/*      */         
/* 3624 */         c.pop();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitProcinst(Saver.SaveCur c) {
/* 3630 */       String target = c.getName().getLocalPart();
/*      */       
/* 3632 */       c.push();
/*      */       
/* 3634 */       c.next();
/*      */       
/* 3636 */       String value = CharUtil.getString(c.getChars(), c._offSrc, c._cchSrc);
/*      */       
/* 3638 */       c.pop();
/*      */ 
/*      */       
/*      */       try {
/* 3642 */         this._contentHandler.processingInstruction(c.getName().getLocalPart(), value);
/*      */       }
/* 3644 */       catch (SAXException e) {
/*      */         
/* 3646 */         throw new SaverSAXException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void emitDocType(String docTypeName, String publicId, String systemId) {
/* 3652 */       if (this._lexicalHandler != null) {
/*      */         
/*      */         try {
/*      */           
/* 3656 */           this._lexicalHandler.startDTD(docTypeName, publicId, systemId);
/* 3657 */           this._lexicalHandler.endDTD();
/*      */         }
/* 3659 */         catch (SAXException e) {
/*      */           
/* 3661 */           throw new SaverSAXException(e);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void emitStartDoc(Saver.SaveCur c) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void emitEndDoc(Saver.SaveCur c) {} }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class SaveCur
/*      */   {
/*      */     int _offSrc;
/*      */ 
/*      */     
/*      */     int _cchSrc;
/*      */ 
/*      */ 
/*      */     
/*      */     final boolean isRoot() {
/* 3689 */       return (kind() == 1);
/* 3690 */     } final boolean isElem() { return (kind() == 2); }
/* 3691 */     final boolean isAttr() { return (kind() == 3); }
/* 3692 */     final boolean isText() { return (kind() == 0); }
/* 3693 */     final boolean isComment() { return (kind() == 4); }
/* 3694 */     final boolean isProcinst() { return (kind() == 5); }
/* 3695 */     final boolean isFinish() { return Cur.kindIsFinish(kind()); }
/* 3696 */     final boolean isContainer() { return Cur.kindIsContainer(kind()); } final boolean isNormalAttr() {
/* 3697 */       return (kind() == 3 && !isXmlns());
/*      */     } final boolean skip() {
/* 3699 */       toEnd(); return next();
/*      */     }
/*      */     abstract void release();
/*      */     abstract int kind();
/*      */     abstract QName getName();
/*      */     abstract String getXmlnsPrefix();
/*      */     
/*      */     abstract String getXmlnsUri();
/*      */     
/*      */     abstract boolean isXmlns();
/*      */     
/*      */     abstract boolean hasChildren();
/*      */     
/*      */     abstract boolean hasText();
/*      */     
/*      */     abstract boolean isTextCData();
/*      */     
/*      */     abstract boolean toFirstAttr();
/*      */     
/*      */     abstract boolean toNextAttr();
/*      */     
/*      */     abstract String getAttrValue();
/*      */     
/*      */     abstract boolean next();
/*      */     
/*      */     abstract void toEnd();
/*      */     
/*      */     abstract void push();
/*      */     
/*      */     abstract void pop();
/*      */     
/*      */     abstract Object getChars();
/*      */     
/*      */     abstract List getAncestorNamespaces();
/*      */     
/*      */     abstract XmlDocumentProperties getDocProps(); }
/*      */   
/*      */   private static final class DocSaveCur extends SaveCur { private Cur _cur;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     DocSaveCur(Cur c) {
/* 3740 */       assert c.isRoot();
/* 3741 */       this._cur = c.weakCur(this);
/*      */     }
/*      */ 
/*      */     
/*      */     void release() {
/* 3746 */       this._cur.release();
/* 3747 */       this._cur = null;
/*      */     }
/*      */     int kind() {
/* 3750 */       return this._cur.kind();
/*      */     }
/* 3752 */     QName getName() { return this._cur.getName(); }
/* 3753 */     String getXmlnsPrefix() { return this._cur.getXmlnsPrefix(); } String getXmlnsUri() {
/* 3754 */       return this._cur.getXmlnsUri();
/*      */     } boolean isXmlns() {
/* 3756 */       return this._cur.isXmlns();
/*      */     }
/* 3758 */     boolean hasChildren() { return this._cur.hasChildren(); }
/* 3759 */     boolean hasText() { return this._cur.hasText(); } boolean isTextCData() {
/* 3760 */       return this._cur.isTextCData();
/*      */     }
/* 3762 */     boolean toFirstAttr() { return this._cur.toFirstAttr(); }
/* 3763 */     boolean toNextAttr() { return this._cur.toNextAttr(); } String getAttrValue() {
/* 3764 */       assert this._cur.isAttr(); return this._cur.getValueAsString();
/*      */     }
/* 3766 */     void toEnd() { this._cur.toEnd(); } boolean next() {
/* 3767 */       return this._cur.next();
/*      */     }
/* 3769 */     void push() { this._cur.push(); } void pop() {
/* 3770 */       this._cur.pop();
/*      */     } List getAncestorNamespaces() {
/* 3772 */       return null;
/*      */     }
/*      */     
/*      */     Object getChars() {
/* 3776 */       Object o = this._cur.getChars(-1);
/*      */       
/* 3778 */       this._offSrc = this._cur._offSrc;
/* 3779 */       this._cchSrc = this._cur._cchSrc;
/*      */       
/* 3781 */       return o;
/*      */     }
/*      */     XmlDocumentProperties getDocProps() {
/* 3784 */       return Locale.getDocProps(this._cur, false);
/*      */     } }
/*      */ 
/*      */   
/*      */   private static abstract class FilterSaveCur extends SaveCur {
/*      */     private Saver.SaveCur _cur;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     FilterSaveCur(Saver.SaveCur c) {
/* 3793 */       assert c.isRoot();
/* 3794 */       this._cur = c;
/*      */     }
/*      */ 
/*      */     
/*      */     protected abstract boolean filter();
/*      */ 
/*      */     
/*      */     void release() {
/* 3802 */       this._cur.release();
/* 3803 */       this._cur = null;
/*      */     }
/*      */     int kind() {
/* 3806 */       return this._cur.kind();
/*      */     }
/* 3808 */     QName getName() { return this._cur.getName(); }
/* 3809 */     String getXmlnsPrefix() { return this._cur.getXmlnsPrefix(); } String getXmlnsUri() {
/* 3810 */       return this._cur.getXmlnsUri();
/*      */     } boolean isXmlns() {
/* 3812 */       return this._cur.isXmlns();
/*      */     }
/* 3814 */     boolean hasChildren() { return this._cur.hasChildren(); }
/* 3815 */     boolean hasText() { return this._cur.hasText(); } boolean isTextCData() {
/* 3816 */       return this._cur.isTextCData();
/*      */     }
/* 3818 */     boolean toFirstAttr() { return this._cur.toFirstAttr(); }
/* 3819 */     boolean toNextAttr() { return this._cur.toNextAttr(); } String getAttrValue() {
/* 3820 */       return this._cur.getAttrValue();
/*      */     } void toEnd() {
/* 3822 */       this._cur.toEnd();
/*      */     }
/*      */     
/*      */     boolean next() {
/* 3826 */       if (!this._cur.next()) {
/* 3827 */         return false;
/*      */       }
/* 3829 */       if (!filter()) {
/* 3830 */         return true;
/*      */       }
/* 3832 */       assert !isRoot() && !isText() && !isAttr();
/*      */       
/* 3834 */       toEnd();
/*      */       
/* 3836 */       return next();
/*      */     }
/*      */     
/* 3839 */     void push() { this._cur.push(); } void pop() {
/* 3840 */       this._cur.pop();
/*      */     } List getAncestorNamespaces() {
/* 3842 */       return this._cur.getAncestorNamespaces();
/*      */     }
/*      */     
/*      */     Object getChars() {
/* 3846 */       Object o = this._cur.getChars();
/*      */       
/* 3848 */       this._offSrc = this._cur._offSrc;
/* 3849 */       this._cchSrc = this._cur._cchSrc;
/*      */       
/* 3851 */       return o;
/*      */     }
/*      */     XmlDocumentProperties getDocProps() {
/* 3854 */       return this._cur.getDocProps();
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class FilterPiSaveCur
/*      */     extends FilterSaveCur {
/*      */     private String _piTarget;
/*      */     
/*      */     FilterPiSaveCur(Saver.SaveCur c, String target) {
/* 3863 */       super(c);
/*      */       
/* 3865 */       this._piTarget = target;
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean filter() {
/* 3870 */       return (kind() == 5 && getName().getLocalPart().equals(this._piTarget));
/*      */     } }
/*      */   private static final class FragSaveCur extends SaveCur { private Cur _cur; private Cur _end; private ArrayList _ancestorNamespaces; private QName _elem; private boolean _saveAttr; private static final int ROOT_START = 1; private static final int ELEM_START = 2; private static final int ROOT_END = 3; private static final int ELEM_END = 4;
/*      */     private static final int CUR = 5;
/*      */     private int _state;
/*      */     private int[] _stateStack;
/*      */     private int _stateStackSize;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     FragSaveCur(Cur start, Cur end, QName synthElem) {
/* 3880 */       this._saveAttr = (start.isAttr() && start.isSamePos(end));
/*      */       
/* 3882 */       this._cur = start.weakCur(this);
/* 3883 */       this._end = end.weakCur(this);
/*      */       
/* 3885 */       this._elem = synthElem;
/*      */       
/* 3887 */       this._state = 1;
/*      */       
/* 3889 */       this._stateStack = new int[8];
/*      */       
/* 3891 */       start.push();
/* 3892 */       computeAncestorNamespaces(start);
/* 3893 */       start.pop();
/*      */     }
/*      */ 
/*      */     
/*      */     List getAncestorNamespaces() {
/* 3898 */       return this._ancestorNamespaces;
/*      */     }
/*      */ 
/*      */     
/*      */     private void computeAncestorNamespaces(Cur c) {
/* 3903 */       this._ancestorNamespaces = new ArrayList();
/*      */       
/* 3905 */       while (c.toParentRaw()) {
/*      */         
/* 3907 */         if (c.toFirstAttr()) {
/*      */           
/*      */           do
/*      */           {
/* 3911 */             if (!c.isXmlns())
/*      */               continue; 
/* 3913 */             String prefix = c.getXmlnsPrefix();
/* 3914 */             String uri = c.getXmlnsUri();
/*      */ 
/*      */ 
/*      */             
/* 3918 */             if (uri.length() <= 0 && prefix.length() != 0)
/*      */               continue; 
/* 3920 */             this._ancestorNamespaces.add(c.getXmlnsPrefix());
/* 3921 */             this._ancestorNamespaces.add(c.getXmlnsUri());
/*      */ 
/*      */           
/*      */           }
/* 3925 */           while (c.toNextAttr());
/*      */           
/* 3927 */           c.toParent();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void release() {
/* 3938 */       this._cur.release();
/* 3939 */       this._cur = null;
/*      */       
/* 3941 */       this._end.release();
/* 3942 */       this._end = null;
/*      */     }
/*      */ 
/*      */     
/*      */     int kind() {
/* 3947 */       switch (this._state) {
/*      */         case 1:
/* 3949 */           return 1;
/* 3950 */         case 2: return 2;
/* 3951 */         case 4: return -2;
/* 3952 */         case 3: return -1;
/*      */       } 
/*      */       
/* 3955 */       assert this._state == 5;
/*      */       
/* 3957 */       return this._cur.kind();
/*      */     }
/*      */ 
/*      */     
/*      */     QName getName() {
/* 3962 */       switch (this._state) {
/*      */         case 1:
/*      */         case 3:
/* 3965 */           return null;
/*      */         case 2: case 4:
/* 3967 */           return this._elem;
/*      */       } 
/*      */       
/* 3970 */       assert this._state == 5;
/*      */       
/* 3972 */       return this._cur.getName();
/*      */     }
/*      */ 
/*      */     
/*      */     String getXmlnsPrefix() {
/* 3977 */       assert this._state == 5 && this._cur.isAttr();
/* 3978 */       return this._cur.getXmlnsPrefix();
/*      */     }
/*      */ 
/*      */     
/*      */     String getXmlnsUri() {
/* 3983 */       assert this._state == 5 && this._cur.isAttr();
/* 3984 */       return this._cur.getXmlnsUri();
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isXmlns() {
/* 3989 */       assert this._state == 5 && this._cur.isAttr();
/* 3990 */       return this._cur.isXmlns();
/*      */     }
/*      */ 
/*      */     
/*      */     boolean hasChildren() {
/* 3995 */       boolean hasChildren = false;
/*      */       
/* 3997 */       if (isContainer()) {
/*      */         
/* 3999 */         push();
/* 4000 */         next();
/*      */         
/* 4002 */         if (!isText() && !isFinish()) {
/* 4003 */           hasChildren = true;
/*      */         }
/* 4005 */         pop();
/*      */       } 
/*      */       
/* 4008 */       return hasChildren;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean hasText() {
/* 4013 */       boolean hasText = false;
/*      */       
/* 4015 */       if (isContainer()) {
/*      */         
/* 4017 */         push();
/* 4018 */         next();
/*      */         
/* 4020 */         if (isText()) {
/* 4021 */           hasText = true;
/*      */         }
/* 4023 */         pop();
/*      */       } 
/*      */       
/* 4026 */       return hasText;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isTextCData() {
/* 4031 */       return this._cur.isTextCData();
/*      */     }
/*      */ 
/*      */     
/*      */     Object getChars() {
/* 4036 */       assert this._state == 5 && this._cur.isText();
/*      */       
/* 4038 */       Object src = this._cur.getChars(-1);
/*      */       
/* 4040 */       this._offSrc = this._cur._offSrc;
/* 4041 */       this._cchSrc = this._cur._cchSrc;
/*      */       
/* 4043 */       return src;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean next() {
/* 4048 */       switch (this._state) {
/*      */ 
/*      */         
/*      */         case 1:
/* 4052 */           this._state = (this._elem == null) ? 5 : 2;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 4058 */           if (this._saveAttr) {
/* 4059 */             this._state = 4;
/*      */             break;
/*      */           } 
/* 4062 */           if (this._cur.isAttr()) {
/*      */             
/* 4064 */             this._cur.toParent();
/* 4065 */             this._cur.next();
/*      */           } 
/*      */           
/* 4068 */           if (this._cur.isSamePos(this._end)) {
/* 4069 */             this._state = 4; break;
/*      */           } 
/* 4071 */           this._state = 5;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/* 4079 */           assert !this._cur.isAttr();
/*      */           
/* 4081 */           this._cur.next();
/*      */           
/* 4083 */           if (this._cur.isSamePos(this._end)) {
/* 4084 */             this._state = (this._elem == null) ? 3 : 4;
/*      */           }
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/* 4091 */           this._state = 3;
/*      */           break;
/*      */         
/*      */         case 3:
/* 4095 */           return false;
/*      */       } 
/*      */       
/* 4098 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     void toEnd() {
/* 4103 */       switch (this._state) {
/*      */         case 1:
/* 4105 */           this._state = 3; return;
/* 4106 */         case 2: this._state = 4; return;
/*      */         case 3:
/*      */         case 4:
/*      */           return;
/*      */       } 
/* 4111 */       assert this._state == 5 && !this._cur.isAttr() && !this._cur.isText();
/*      */       
/* 4113 */       this._cur.toEnd();
/*      */     }
/*      */ 
/*      */     
/*      */     boolean toFirstAttr() {
/* 4118 */       switch (this._state) {
/*      */         case 1:
/*      */         case 3:
/*      */         case 4:
/* 4122 */           return false;
/* 4123 */         case 5: return this._cur.toFirstAttr();
/*      */       } 
/*      */       
/* 4126 */       assert this._state == 2;
/*      */       
/* 4128 */       if (!this._cur.isAttr()) {
/* 4129 */         return false;
/*      */       }
/* 4131 */       this._state = 5;
/*      */       
/* 4133 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean toNextAttr() {
/* 4138 */       assert this._state == 5;
/* 4139 */       return (!this._saveAttr && this._cur.toNextAttr());
/*      */     }
/*      */ 
/*      */     
/*      */     String getAttrValue() {
/* 4144 */       assert this._state == 5 && this._cur.isAttr();
/* 4145 */       return this._cur.getValueAsString();
/*      */     }
/*      */ 
/*      */     
/*      */     void push() {
/* 4150 */       if (this._stateStackSize == this._stateStack.length) {
/*      */         
/* 4152 */         int[] newStateStack = new int[this._stateStackSize * 2];
/* 4153 */         System.arraycopy(this._stateStack, 0, newStateStack, 0, this._stateStackSize);
/* 4154 */         this._stateStack = newStateStack;
/*      */       } 
/*      */       
/* 4157 */       this._stateStack[this._stateStackSize++] = this._state;
/* 4158 */       this._cur.push();
/*      */     }
/*      */ 
/*      */     
/*      */     void pop() {
/* 4163 */       this._cur.pop();
/* 4164 */       this._state = this._stateStack[--this._stateStackSize];
/*      */     }
/*      */     XmlDocumentProperties getDocProps() {
/* 4167 */       return Locale.getDocProps(this._cur, false);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class PrettySaveCur
/*      */     extends SaveCur
/*      */   {
/*      */     private Saver.SaveCur _cur;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int _prettyIndent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int _prettyOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String _txt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private StringBuffer _sb;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int _depth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ArrayList _stack;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean _isTextCData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean _useCDataBookmarks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static final boolean $assertionsDisabled;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     PrettySaveCur(Saver.SaveCur c, XmlOptions options) {
/* 4398 */       this._isTextCData = false;
/* 4399 */       this._useCDataBookmarks = false; this._sb = new StringBuffer(); this._stack = new ArrayList(); this._cur = c; assert options != null; this._prettyIndent = 2; if (options.hasOption("SAVE_PRETTY_PRINT_INDENT"))
/*      */         this._prettyIndent = ((Integer)options.get("SAVE_PRETTY_PRINT_INDENT")).intValue();  if (options.hasOption("SAVE_PRETTY_PRINT_OFFSET"))
/*      */         this._prettyOffset = ((Integer)options.get("SAVE_PRETTY_PRINT_OFFSET")).intValue();  if (options.hasOption("LOAD_SAVE_CDATA_BOOKMARKS"))
/*      */         this._useCDataBookmarks = true; 
/*      */     } List getAncestorNamespaces() { return this._cur.getAncestorNamespaces(); }
/*      */     void release() { this._cur.release(); }
/*      */     int kind() { return (this._txt == null) ? this._cur.kind() : 0; }
/*      */     QName getName() { assert this._txt == null; return this._cur.getName(); }
/*      */     String getXmlnsPrefix() { assert this._txt == null; return this._cur.getXmlnsPrefix(); }
/*      */     String getXmlnsUri() { assert this._txt == null; return this._cur.getXmlnsUri(); }
/*      */     boolean isXmlns() { return (this._txt == null) ? this._cur.isXmlns() : false; }
/*      */     boolean hasChildren() { return (this._txt == null) ? this._cur.hasChildren() : false; }
/*      */     boolean hasText() { return (this._txt == null) ? this._cur.hasText() : false; }
/*      */     boolean isTextCData() { return (this._txt == null) ? ((this._useCDataBookmarks && this._cur.isTextCData())) : this._isTextCData; }
/*      */     boolean toFirstAttr() { assert this._txt == null; return this._cur.toFirstAttr(); }
/*      */     boolean toNextAttr() { assert this._txt == null; return this._cur.toNextAttr(); }
/*      */     String getAttrValue() { assert this._txt == null; return this._cur.getAttrValue(); }
/*      */     void toEnd() { assert this._txt == null; this._cur.toEnd(); if (this._cur.kind() == -2)
/*      */         this._depth--;  }
/*      */     boolean next() { int k; if (this._txt != null) { assert this._txt.length() > 0; assert !this._cur.isText(); this._txt = null; this._isTextCData = false; k = this._cur.kind(); } else { int prevKind = k = this._cur.kind(); if (!this._cur.next())
/*      */           return false;  this._sb.delete(0, this._sb.length()); assert this._txt == null; if (this._cur.isText()) { this._isTextCData = (this._useCDataBookmarks && this._cur.isTextCData()); CharUtil.getString(this._sb, this._cur.getChars(), this._cur._offSrc, this._cur._cchSrc); this._cur.next(); trim(this._sb); }  k = this._cur.kind(); if (this._prettyIndent >= 0 && prevKind != 4 && prevKind != 5 && (prevKind != 2 || k != -2)) { if (this._sb.length() > 0) { this._sb.insert(0, Saver._newLine); spaces(this._sb, Saver._newLine.length(), this._prettyOffset + this._prettyIndent * this._depth); }  if (k != -1) { if (prevKind != 1)
/*      */               this._sb.append(Saver._newLine);  int d = (k < 0) ? (this._depth - 1) : this._depth; spaces(this._sb, this._sb.length(), this._prettyOffset + this._prettyIndent * d); }  }  if (this._sb.length() > 0) { this._txt = this._sb.toString(); k = 0; }  }  if (k == 2) { this._depth++; } else if (k == -2) { this._depth--; }  return true; }
/*      */     void push() { this._cur.push(); this._stack.add(this._txt); this._stack.add(new Integer(this._depth)); this._isTextCData = false; }
/*      */     void pop() { this._cur.pop(); this._depth = ((Integer)this._stack.remove(this._stack.size() - 1)).intValue(); this._txt = this._stack.remove(this._stack.size() - 1); this._isTextCData = false; }
/*      */     Object getChars() { if (this._txt != null) { this._offSrc = 0; this._cchSrc = this._txt.length(); return this._txt; }
/*      */        Object o = this._cur.getChars(); this._offSrc = this._cur._offSrc; this._cchSrc = this._cur._cchSrc; return o; }
/*      */     XmlDocumentProperties getDocProps() { return this._cur.getDocProps(); }
/*      */     static void spaces(StringBuffer sb, int offset, int count) { while (count-- > 0)
/*      */         sb.insert(offset, ' ');  }
/* 4428 */     static void trim(StringBuffer sb) { int i; for (i = 0; i < sb.length() && CharUtil.isWhiteSpace(sb.charAt(i)); i++); sb.delete(0, i); for (i = sb.length(); i > 0 && CharUtil.isWhiteSpace(sb.charAt(i - 1)); i--); sb.delete(i, sb.length()); } } static final String _newLine = (SystemProperties.getProperty("line.separator") == null) ? "\n" : SystemProperties.getProperty("line.separator");
/*      */   static final boolean $assertionsDisabled;
/*      */   
/*      */   protected abstract boolean emitElement(SaveCur paramSaveCur, ArrayList paramArrayList1, ArrayList paramArrayList2);
/*      */   
/*      */   protected abstract void emitFinish(SaveCur paramSaveCur);
/*      */   
/*      */   protected abstract void emitText(SaveCur paramSaveCur);
/*      */   
/*      */   protected abstract void emitComment(SaveCur paramSaveCur);
/*      */   
/*      */   protected abstract void emitProcinst(SaveCur paramSaveCur);
/*      */   
/*      */   protected abstract void emitDocType(String paramString1, String paramString2, String paramString3);
/*      */   
/*      */   protected abstract void emitStartDoc(SaveCur paramSaveCur);
/*      */   
/*      */   protected abstract void emitEndDoc(SaveCur paramSaveCur);
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\store\Saver.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */