/*    */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlNonNegativeInteger;
/*    */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*    */ import org.apache.xmlbeans.impl.values.XmlUnionImpl;
/*    */ import org.apache.xmlbeans.impl.xb.xsdschema.AllNNI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllNNIImpl
/*    */   extends XmlUnionImpl
/*    */   implements AllNNI, XmlNonNegativeInteger, AllNNI.Member
/*    */ {
/*    */   public AllNNIImpl(SchemaType sType) {
/* 21 */     super(sType, false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected AllNNIImpl(SchemaType sType, boolean b) {
/* 26 */     super(sType, b);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class MemberImpl
/*    */     extends JavaStringEnumerationHolderEx
/*    */     implements AllNNI.Member
/*    */   {
/*    */     public MemberImpl(SchemaType sType) {
/* 38 */       super(sType, false);
/*    */     }
/*    */ 
/*    */     
/*    */     protected MemberImpl(SchemaType sType, boolean b) {
/* 43 */       super(sType, b);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AllNNIImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */