/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlNonNegativeInteger;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AllNNI;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.AnyDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnyDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements AnyDocument
/*     */ {
/*     */   public AnyDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName ANY$0 = new QName("http://www.w3.org/2001/XMLSchema", "any");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnyDocument.Any getAny() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       AnyDocument.Any target = null;
/*  36 */       target = (AnyDocument.Any)get_store().find_element_user(ANY$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAny(AnyDocument.Any any) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       AnyDocument.Any target = null;
/*  54 */       target = (AnyDocument.Any)get_store().find_element_user(ANY$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (AnyDocument.Any)get_store().add_element_user(ANY$0);
/*     */       }
/*  59 */       target.set((XmlObject)any);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnyDocument.Any addNewAny() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       AnyDocument.Any target = null;
/*  72 */       target = (AnyDocument.Any)get_store().add_element_user(ANY$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AnyImpl
/*     */     extends WildcardImpl
/*     */     implements AnyDocument.Any
/*     */   {
/*     */     public AnyImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName MINOCCURS$0 = new QName("", "minOccurs");
/*     */     
/*  91 */     private static final QName MAXOCCURS$2 = new QName("", "maxOccurs");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BigInteger getMinOccurs() {
/* 100 */       synchronized (monitor()) {
/*     */         
/* 102 */         check_orphaned();
/* 103 */         SimpleValue target = null;
/* 104 */         target = (SimpleValue)get_store().find_attribute_user(MINOCCURS$0);
/* 105 */         if (target == null)
/*     */         {
/* 107 */           target = (SimpleValue)get_default_attribute_value(MINOCCURS$0);
/*     */         }
/* 109 */         if (target == null)
/*     */         {
/* 111 */           return null;
/*     */         }
/* 113 */         return target.getBigIntegerValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlNonNegativeInteger xgetMinOccurs() {
/* 122 */       synchronized (monitor()) {
/*     */         
/* 124 */         check_orphaned();
/* 125 */         XmlNonNegativeInteger target = null;
/* 126 */         target = (XmlNonNegativeInteger)get_store().find_attribute_user(MINOCCURS$0);
/* 127 */         if (target == null)
/*     */         {
/* 129 */           target = (XmlNonNegativeInteger)get_default_attribute_value(MINOCCURS$0);
/*     */         }
/* 131 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetMinOccurs() {
/* 140 */       synchronized (monitor()) {
/*     */         
/* 142 */         check_orphaned();
/* 143 */         return (get_store().find_attribute_user(MINOCCURS$0) != null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setMinOccurs(BigInteger minOccurs) {
/* 152 */       synchronized (monitor()) {
/*     */         
/* 154 */         check_orphaned();
/* 155 */         SimpleValue target = null;
/* 156 */         target = (SimpleValue)get_store().find_attribute_user(MINOCCURS$0);
/* 157 */         if (target == null)
/*     */         {
/* 159 */           target = (SimpleValue)get_store().add_attribute_user(MINOCCURS$0);
/*     */         }
/* 161 */         target.setBigIntegerValue(minOccurs);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetMinOccurs(XmlNonNegativeInteger minOccurs) {
/* 170 */       synchronized (monitor()) {
/*     */         
/* 172 */         check_orphaned();
/* 173 */         XmlNonNegativeInteger target = null;
/* 174 */         target = (XmlNonNegativeInteger)get_store().find_attribute_user(MINOCCURS$0);
/* 175 */         if (target == null)
/*     */         {
/* 177 */           target = (XmlNonNegativeInteger)get_store().add_attribute_user(MINOCCURS$0);
/*     */         }
/* 179 */         target.set((XmlObject)minOccurs);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetMinOccurs() {
/* 188 */       synchronized (monitor()) {
/*     */         
/* 190 */         check_orphaned();
/* 191 */         get_store().remove_attribute(MINOCCURS$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getMaxOccurs() {
/* 200 */       synchronized (monitor()) {
/*     */         
/* 202 */         check_orphaned();
/* 203 */         SimpleValue target = null;
/* 204 */         target = (SimpleValue)get_store().find_attribute_user(MAXOCCURS$2);
/* 205 */         if (target == null)
/*     */         {
/* 207 */           target = (SimpleValue)get_default_attribute_value(MAXOCCURS$2);
/*     */         }
/* 209 */         if (target == null)
/*     */         {
/* 211 */           return null;
/*     */         }
/* 213 */         return target.getObjectValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AllNNI xgetMaxOccurs() {
/* 222 */       synchronized (monitor()) {
/*     */         
/* 224 */         check_orphaned();
/* 225 */         AllNNI target = null;
/* 226 */         target = (AllNNI)get_store().find_attribute_user(MAXOCCURS$2);
/* 227 */         if (target == null)
/*     */         {
/* 229 */           target = (AllNNI)get_default_attribute_value(MAXOCCURS$2);
/*     */         }
/* 231 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetMaxOccurs() {
/* 240 */       synchronized (monitor()) {
/*     */         
/* 242 */         check_orphaned();
/* 243 */         return (get_store().find_attribute_user(MAXOCCURS$2) != null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setMaxOccurs(Object maxOccurs) {
/* 252 */       synchronized (monitor()) {
/*     */         
/* 254 */         check_orphaned();
/* 255 */         SimpleValue target = null;
/* 256 */         target = (SimpleValue)get_store().find_attribute_user(MAXOCCURS$2);
/* 257 */         if (target == null)
/*     */         {
/* 259 */           target = (SimpleValue)get_store().add_attribute_user(MAXOCCURS$2);
/*     */         }
/* 261 */         target.setObjectValue(maxOccurs);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetMaxOccurs(AllNNI maxOccurs) {
/* 270 */       synchronized (monitor()) {
/*     */         
/* 272 */         check_orphaned();
/* 273 */         AllNNI target = null;
/* 274 */         target = (AllNNI)get_store().find_attribute_user(MAXOCCURS$2);
/* 275 */         if (target == null)
/*     */         {
/* 277 */           target = (AllNNI)get_store().add_attribute_user(MAXOCCURS$2);
/*     */         }
/* 279 */         target.set((XmlObject)maxOccurs);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetMaxOccurs() {
/* 288 */       synchronized (monitor()) {
/*     */         
/* 290 */         check_orphaned();
/* 291 */         get_store().remove_attribute(MAXOCCURS$2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\AnyDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */