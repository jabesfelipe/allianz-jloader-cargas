/*     */ package org.apache.xmlbeans.impl.xb.ltgfmt.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*     */ import org.apache.xmlbeans.XmlBoolean;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.Code;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.FileDesc;
/*     */ 
/*     */ public class FileDescImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements FileDesc {
/*     */   public FileDescImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName CODE$0 = new QName("http://www.bea.com/2003/05/xmlbean/ltgfmt", "code");
/*     */   
/*  24 */   private static final QName TSDIR$2 = new QName("", "tsDir");
/*     */   
/*  26 */   private static final QName FOLDER$4 = new QName("", "folder");
/*     */   
/*  28 */   private static final QName FILENAME$6 = new QName("", "fileName");
/*     */   
/*  30 */   private static final QName ROLE$8 = new QName("", "role");
/*     */   
/*  32 */   private static final QName VALIDITY$10 = new QName("", "validity");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Code getCode() {
/*  41 */     synchronized (monitor()) {
/*     */       
/*  43 */       check_orphaned();
/*  44 */       Code target = null;
/*  45 */       target = (Code)get_store().find_element_user(CODE$0, 0);
/*  46 */       if (target == null)
/*     */       {
/*  48 */         return null;
/*     */       }
/*  50 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetCode() {
/*  59 */     synchronized (monitor()) {
/*     */       
/*  61 */       check_orphaned();
/*  62 */       return (get_store().count_elements(CODE$0) != 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCode(Code code) {
/*  71 */     synchronized (monitor()) {
/*     */       
/*  73 */       check_orphaned();
/*  74 */       Code target = null;
/*  75 */       target = (Code)get_store().find_element_user(CODE$0, 0);
/*  76 */       if (target == null)
/*     */       {
/*  78 */         target = (Code)get_store().add_element_user(CODE$0);
/*     */       }
/*  80 */       target.set((XmlObject)code);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Code addNewCode() {
/*  89 */     synchronized (monitor()) {
/*     */       
/*  91 */       check_orphaned();
/*  92 */       Code target = null;
/*  93 */       target = (Code)get_store().add_element_user(CODE$0);
/*  94 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetCode() {
/* 103 */     synchronized (monitor()) {
/*     */       
/* 105 */       check_orphaned();
/* 106 */       get_store().remove_element(CODE$0, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTsDir() {
/* 115 */     synchronized (monitor()) {
/*     */       
/* 117 */       check_orphaned();
/* 118 */       SimpleValue target = null;
/* 119 */       target = (SimpleValue)get_store().find_attribute_user(TSDIR$2);
/* 120 */       if (target == null)
/*     */       {
/* 122 */         return null;
/*     */       }
/* 124 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlToken xgetTsDir() {
/* 133 */     synchronized (monitor()) {
/*     */       
/* 135 */       check_orphaned();
/* 136 */       XmlToken target = null;
/* 137 */       target = (XmlToken)get_store().find_attribute_user(TSDIR$2);
/* 138 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetTsDir() {
/* 147 */     synchronized (monitor()) {
/*     */       
/* 149 */       check_orphaned();
/* 150 */       return (get_store().find_attribute_user(TSDIR$2) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTsDir(String tsDir) {
/* 159 */     synchronized (monitor()) {
/*     */       
/* 161 */       check_orphaned();
/* 162 */       SimpleValue target = null;
/* 163 */       target = (SimpleValue)get_store().find_attribute_user(TSDIR$2);
/* 164 */       if (target == null)
/*     */       {
/* 166 */         target = (SimpleValue)get_store().add_attribute_user(TSDIR$2);
/*     */       }
/* 168 */       target.setStringValue(tsDir);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetTsDir(XmlToken tsDir) {
/* 177 */     synchronized (monitor()) {
/*     */       
/* 179 */       check_orphaned();
/* 180 */       XmlToken target = null;
/* 181 */       target = (XmlToken)get_store().find_attribute_user(TSDIR$2);
/* 182 */       if (target == null)
/*     */       {
/* 184 */         target = (XmlToken)get_store().add_attribute_user(TSDIR$2);
/*     */       }
/* 186 */       target.set((XmlObject)tsDir);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetTsDir() {
/* 195 */     synchronized (monitor()) {
/*     */       
/* 197 */       check_orphaned();
/* 198 */       get_store().remove_attribute(TSDIR$2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFolder() {
/* 207 */     synchronized (monitor()) {
/*     */       
/* 209 */       check_orphaned();
/* 210 */       SimpleValue target = null;
/* 211 */       target = (SimpleValue)get_store().find_attribute_user(FOLDER$4);
/* 212 */       if (target == null)
/*     */       {
/* 214 */         return null;
/*     */       }
/* 216 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlToken xgetFolder() {
/* 225 */     synchronized (monitor()) {
/*     */       
/* 227 */       check_orphaned();
/* 228 */       XmlToken target = null;
/* 229 */       target = (XmlToken)get_store().find_attribute_user(FOLDER$4);
/* 230 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetFolder() {
/* 239 */     synchronized (monitor()) {
/*     */       
/* 241 */       check_orphaned();
/* 242 */       return (get_store().find_attribute_user(FOLDER$4) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFolder(String folder) {
/* 251 */     synchronized (monitor()) {
/*     */       
/* 253 */       check_orphaned();
/* 254 */       SimpleValue target = null;
/* 255 */       target = (SimpleValue)get_store().find_attribute_user(FOLDER$4);
/* 256 */       if (target == null)
/*     */       {
/* 258 */         target = (SimpleValue)get_store().add_attribute_user(FOLDER$4);
/*     */       }
/* 260 */       target.setStringValue(folder);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetFolder(XmlToken folder) {
/* 269 */     synchronized (monitor()) {
/*     */       
/* 271 */       check_orphaned();
/* 272 */       XmlToken target = null;
/* 273 */       target = (XmlToken)get_store().find_attribute_user(FOLDER$4);
/* 274 */       if (target == null)
/*     */       {
/* 276 */         target = (XmlToken)get_store().add_attribute_user(FOLDER$4);
/*     */       }
/* 278 */       target.set((XmlObject)folder);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetFolder() {
/* 287 */     synchronized (monitor()) {
/*     */       
/* 289 */       check_orphaned();
/* 290 */       get_store().remove_attribute(FOLDER$4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileName() {
/* 299 */     synchronized (monitor()) {
/*     */       
/* 301 */       check_orphaned();
/* 302 */       SimpleValue target = null;
/* 303 */       target = (SimpleValue)get_store().find_attribute_user(FILENAME$6);
/* 304 */       if (target == null)
/*     */       {
/* 306 */         return null;
/*     */       }
/* 308 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlToken xgetFileName() {
/* 317 */     synchronized (monitor()) {
/*     */       
/* 319 */       check_orphaned();
/* 320 */       XmlToken target = null;
/* 321 */       target = (XmlToken)get_store().find_attribute_user(FILENAME$6);
/* 322 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetFileName() {
/* 331 */     synchronized (monitor()) {
/*     */       
/* 333 */       check_orphaned();
/* 334 */       return (get_store().find_attribute_user(FILENAME$6) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileName(String fileName) {
/* 343 */     synchronized (monitor()) {
/*     */       
/* 345 */       check_orphaned();
/* 346 */       SimpleValue target = null;
/* 347 */       target = (SimpleValue)get_store().find_attribute_user(FILENAME$6);
/* 348 */       if (target == null)
/*     */       {
/* 350 */         target = (SimpleValue)get_store().add_attribute_user(FILENAME$6);
/*     */       }
/* 352 */       target.setStringValue(fileName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetFileName(XmlToken fileName) {
/* 361 */     synchronized (monitor()) {
/*     */       
/* 363 */       check_orphaned();
/* 364 */       XmlToken target = null;
/* 365 */       target = (XmlToken)get_store().find_attribute_user(FILENAME$6);
/* 366 */       if (target == null)
/*     */       {
/* 368 */         target = (XmlToken)get_store().add_attribute_user(FILENAME$6);
/*     */       }
/* 370 */       target.set((XmlObject)fileName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetFileName() {
/* 379 */     synchronized (monitor()) {
/*     */       
/* 381 */       check_orphaned();
/* 382 */       get_store().remove_attribute(FILENAME$6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileDesc.Role.Enum getRole() {
/* 391 */     synchronized (monitor()) {
/*     */       
/* 393 */       check_orphaned();
/* 394 */       SimpleValue target = null;
/* 395 */       target = (SimpleValue)get_store().find_attribute_user(ROLE$8);
/* 396 */       if (target == null)
/*     */       {
/* 398 */         return null;
/*     */       }
/* 400 */       return (FileDesc.Role.Enum)target.getEnumValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileDesc.Role xgetRole() {
/* 409 */     synchronized (monitor()) {
/*     */       
/* 411 */       check_orphaned();
/* 412 */       FileDesc.Role target = null;
/* 413 */       target = (FileDesc.Role)get_store().find_attribute_user(ROLE$8);
/* 414 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetRole() {
/* 423 */     synchronized (monitor()) {
/*     */       
/* 425 */       check_orphaned();
/* 426 */       return (get_store().find_attribute_user(ROLE$8) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRole(FileDesc.Role.Enum role) {
/* 435 */     synchronized (monitor()) {
/*     */       
/* 437 */       check_orphaned();
/* 438 */       SimpleValue target = null;
/* 439 */       target = (SimpleValue)get_store().find_attribute_user(ROLE$8);
/* 440 */       if (target == null)
/*     */       {
/* 442 */         target = (SimpleValue)get_store().add_attribute_user(ROLE$8);
/*     */       }
/* 444 */       target.setEnumValue((StringEnumAbstractBase)role);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetRole(FileDesc.Role role) {
/* 453 */     synchronized (monitor()) {
/*     */       
/* 455 */       check_orphaned();
/* 456 */       FileDesc.Role target = null;
/* 457 */       target = (FileDesc.Role)get_store().find_attribute_user(ROLE$8);
/* 458 */       if (target == null)
/*     */       {
/* 460 */         target = (FileDesc.Role)get_store().add_attribute_user(ROLE$8);
/*     */       }
/* 462 */       target.set((XmlObject)role);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetRole() {
/* 471 */     synchronized (monitor()) {
/*     */       
/* 473 */       check_orphaned();
/* 474 */       get_store().remove_attribute(ROLE$8);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getValidity() {
/* 483 */     synchronized (monitor()) {
/*     */       
/* 485 */       check_orphaned();
/* 486 */       SimpleValue target = null;
/* 487 */       target = (SimpleValue)get_store().find_attribute_user(VALIDITY$10);
/* 488 */       if (target == null)
/*     */       {
/* 490 */         return false;
/*     */       }
/* 492 */       return target.getBooleanValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlBoolean xgetValidity() {
/* 501 */     synchronized (monitor()) {
/*     */       
/* 503 */       check_orphaned();
/* 504 */       XmlBoolean target = null;
/* 505 */       target = (XmlBoolean)get_store().find_attribute_user(VALIDITY$10);
/* 506 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetValidity() {
/* 515 */     synchronized (monitor()) {
/*     */       
/* 517 */       check_orphaned();
/* 518 */       return (get_store().find_attribute_user(VALIDITY$10) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidity(boolean validity) {
/* 527 */     synchronized (monitor()) {
/*     */       
/* 529 */       check_orphaned();
/* 530 */       SimpleValue target = null;
/* 531 */       target = (SimpleValue)get_store().find_attribute_user(VALIDITY$10);
/* 532 */       if (target == null)
/*     */       {
/* 534 */         target = (SimpleValue)get_store().add_attribute_user(VALIDITY$10);
/*     */       }
/* 536 */       target.setBooleanValue(validity);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetValidity(XmlBoolean validity) {
/* 545 */     synchronized (monitor()) {
/*     */       
/* 547 */       check_orphaned();
/* 548 */       XmlBoolean target = null;
/* 549 */       target = (XmlBoolean)get_store().find_attribute_user(VALIDITY$10);
/* 550 */       if (target == null)
/*     */       {
/* 552 */         target = (XmlBoolean)get_store().add_attribute_user(VALIDITY$10);
/*     */       }
/* 554 */       target.set((XmlObject)validity);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetValidity() {
/* 563 */     synchronized (monitor()) {
/*     */       
/* 565 */       check_orphaned();
/* 566 */       get_store().remove_attribute(VALIDITY$10);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class RoleImpl
/*     */     extends JavaStringEnumerationHolderEx
/*     */     implements FileDesc.Role
/*     */   {
/*     */     public RoleImpl(SchemaType sType) {
/* 579 */       super(sType, false);
/*     */     }
/*     */ 
/*     */     
/*     */     protected RoleImpl(SchemaType sType, boolean b) {
/* 584 */       super(sType, b);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\ltgfmt\impl\FileDescImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */