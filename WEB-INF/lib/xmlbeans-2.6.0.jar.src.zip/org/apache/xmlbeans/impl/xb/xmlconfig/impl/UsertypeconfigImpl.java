/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Usertypeconfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UsertypeconfigImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements Usertypeconfig
/*     */ {
/*     */   public UsertypeconfigImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName STATICHANDLER$0 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "staticHandler");
/*     */   
/*  24 */   private static final QName NAME$2 = new QName("", "name");
/*     */   
/*  26 */   private static final QName JAVANAME$4 = new QName("", "javaname");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStaticHandler() {
/*  35 */     synchronized (monitor()) {
/*     */       
/*  37 */       check_orphaned();
/*  38 */       SimpleValue target = null;
/*  39 */       target = (SimpleValue)get_store().find_element_user(STATICHANDLER$0, 0);
/*  40 */       if (target == null)
/*     */       {
/*  42 */         return null;
/*     */       }
/*  44 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetStaticHandler() {
/*  53 */     synchronized (monitor()) {
/*     */       
/*  55 */       check_orphaned();
/*  56 */       XmlString target = null;
/*  57 */       target = (XmlString)get_store().find_element_user(STATICHANDLER$0, 0);
/*  58 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStaticHandler(String staticHandler) {
/*  67 */     synchronized (monitor()) {
/*     */       
/*  69 */       check_orphaned();
/*  70 */       SimpleValue target = null;
/*  71 */       target = (SimpleValue)get_store().find_element_user(STATICHANDLER$0, 0);
/*  72 */       if (target == null)
/*     */       {
/*  74 */         target = (SimpleValue)get_store().add_element_user(STATICHANDLER$0);
/*     */       }
/*  76 */       target.setStringValue(staticHandler);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetStaticHandler(XmlString staticHandler) {
/*  85 */     synchronized (monitor()) {
/*     */       
/*  87 */       check_orphaned();
/*  88 */       XmlString target = null;
/*  89 */       target = (XmlString)get_store().find_element_user(STATICHANDLER$0, 0);
/*  90 */       if (target == null)
/*     */       {
/*  92 */         target = (XmlString)get_store().add_element_user(STATICHANDLER$0);
/*     */       }
/*  94 */       target.set((XmlObject)staticHandler);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getName() {
/* 103 */     synchronized (monitor()) {
/*     */       
/* 105 */       check_orphaned();
/* 106 */       SimpleValue target = null;
/* 107 */       target = (SimpleValue)get_store().find_attribute_user(NAME$2);
/* 108 */       if (target == null)
/*     */       {
/* 110 */         return null;
/*     */       }
/* 112 */       return target.getQNameValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlQName xgetName() {
/* 121 */     synchronized (monitor()) {
/*     */       
/* 123 */       check_orphaned();
/* 124 */       XmlQName target = null;
/* 125 */       target = (XmlQName)get_store().find_attribute_user(NAME$2);
/* 126 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetName() {
/* 135 */     synchronized (monitor()) {
/*     */       
/* 137 */       check_orphaned();
/* 138 */       return (get_store().find_attribute_user(NAME$2) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(QName name) {
/* 147 */     synchronized (monitor()) {
/*     */       
/* 149 */       check_orphaned();
/* 150 */       SimpleValue target = null;
/* 151 */       target = (SimpleValue)get_store().find_attribute_user(NAME$2);
/* 152 */       if (target == null)
/*     */       {
/* 154 */         target = (SimpleValue)get_store().add_attribute_user(NAME$2);
/*     */       }
/* 156 */       target.setQNameValue(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetName(XmlQName name) {
/* 165 */     synchronized (monitor()) {
/*     */       
/* 167 */       check_orphaned();
/* 168 */       XmlQName target = null;
/* 169 */       target = (XmlQName)get_store().find_attribute_user(NAME$2);
/* 170 */       if (target == null)
/*     */       {
/* 172 */         target = (XmlQName)get_store().add_attribute_user(NAME$2);
/*     */       }
/* 174 */       target.set((XmlObject)name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetName() {
/* 183 */     synchronized (monitor()) {
/*     */       
/* 185 */       check_orphaned();
/* 186 */       get_store().remove_attribute(NAME$2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaname() {
/* 195 */     synchronized (monitor()) {
/*     */       
/* 197 */       check_orphaned();
/* 198 */       SimpleValue target = null;
/* 199 */       target = (SimpleValue)get_store().find_attribute_user(JAVANAME$4);
/* 200 */       if (target == null)
/*     */       {
/* 202 */         return null;
/*     */       }
/* 204 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlString xgetJavaname() {
/* 213 */     synchronized (monitor()) {
/*     */       
/* 215 */       check_orphaned();
/* 216 */       XmlString target = null;
/* 217 */       target = (XmlString)get_store().find_attribute_user(JAVANAME$4);
/* 218 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetJavaname() {
/* 227 */     synchronized (monitor()) {
/*     */       
/* 229 */       check_orphaned();
/* 230 */       return (get_store().find_attribute_user(JAVANAME$4) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaname(String javaname) {
/* 239 */     synchronized (monitor()) {
/*     */       
/* 241 */       check_orphaned();
/* 242 */       SimpleValue target = null;
/* 243 */       target = (SimpleValue)get_store().find_attribute_user(JAVANAME$4);
/* 244 */       if (target == null)
/*     */       {
/* 246 */         target = (SimpleValue)get_store().add_attribute_user(JAVANAME$4);
/*     */       }
/* 248 */       target.setStringValue(javaname);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetJavaname(XmlString javaname) {
/* 257 */     synchronized (monitor()) {
/*     */       
/* 259 */       check_orphaned();
/* 260 */       XmlString target = null;
/* 261 */       target = (XmlString)get_store().find_attribute_user(JAVANAME$4);
/* 262 */       if (target == null)
/*     */       {
/* 264 */         target = (XmlString)get_store().add_attribute_user(JAVANAME$4);
/*     */       }
/* 266 */       target.set((XmlObject)javaname);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetJavaname() {
/* 275 */     synchronized (monitor()) {
/*     */       
/* 277 */       check_orphaned();
/* 278 */       get_store().remove_attribute(JAVANAME$4);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\impl\UsertypeconfigImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */