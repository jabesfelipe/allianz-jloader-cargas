/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface Qnametargetlist
/*     */   extends XmlAnySimpleType {
/*     */   List getListValue();
/*     */   
/*     */   List xgetListValue();
/*     */   
/*     */   void setListValue(List paramList);
/*     */   
/*  27 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnametargetlist == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnametargetlist = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.Qnametargetlist")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnametargetlist).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("qnametargetlist16actype");
/*     */   
/*     */   List listValue();
/*     */   
/*     */   List xlistValue();
/*     */   
/*     */   void set(List paramList);
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static Qnametargetlist newValue(Object obj) {
/*  38 */       return (Qnametargetlist)Qnametargetlist.type.newValue(obj);
/*     */     }
/*     */     public static Qnametargetlist newInstance() {
/*  41 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().newInstance(Qnametargetlist.type, null);
/*     */     }
/*     */     public static Qnametargetlist newInstance(XmlOptions options) {
/*  44 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().newInstance(Qnametargetlist.type, options);
/*     */     }
/*     */     
/*     */     public static Qnametargetlist parse(String xmlAsString) throws XmlException {
/*  48 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(xmlAsString, Qnametargetlist.type, null);
/*     */     }
/*     */     public static Qnametargetlist parse(String xmlAsString, XmlOptions options) throws XmlException {
/*  51 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(xmlAsString, Qnametargetlist.type, options);
/*     */     }
/*     */     
/*     */     public static Qnametargetlist parse(File file) throws XmlException, IOException {
/*  55 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(file, Qnametargetlist.type, null);
/*     */     }
/*     */     public static Qnametargetlist parse(File file, XmlOptions options) throws XmlException, IOException {
/*  58 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(file, Qnametargetlist.type, options);
/*     */     }
/*     */     public static Qnametargetlist parse(URL u) throws XmlException, IOException {
/*  61 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(u, Qnametargetlist.type, null);
/*     */     }
/*     */     public static Qnametargetlist parse(URL u, XmlOptions options) throws XmlException, IOException {
/*  64 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(u, Qnametargetlist.type, options);
/*     */     }
/*     */     public static Qnametargetlist parse(InputStream is) throws XmlException, IOException {
/*  67 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(is, Qnametargetlist.type, null);
/*     */     }
/*     */     public static Qnametargetlist parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/*  70 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(is, Qnametargetlist.type, options);
/*     */     }
/*     */     public static Qnametargetlist parse(Reader r) throws XmlException, IOException {
/*  73 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(r, Qnametargetlist.type, null);
/*     */     }
/*     */     public static Qnametargetlist parse(Reader r, XmlOptions options) throws XmlException, IOException {
/*  76 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(r, Qnametargetlist.type, options);
/*     */     }
/*     */     public static Qnametargetlist parse(XMLStreamReader sr) throws XmlException {
/*  79 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(sr, Qnametargetlist.type, null);
/*     */     }
/*     */     public static Qnametargetlist parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/*  82 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(sr, Qnametargetlist.type, options);
/*     */     }
/*     */     public static Qnametargetlist parse(Node node) throws XmlException {
/*  85 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(node, Qnametargetlist.type, null);
/*     */     }
/*     */     public static Qnametargetlist parse(Node node, XmlOptions options) throws XmlException {
/*  88 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(node, Qnametargetlist.type, options);
/*     */     }
/*     */     
/*     */     public static Qnametargetlist parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/*  92 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(xis, Qnametargetlist.type, null);
/*     */     }
/*     */     
/*     */     public static Qnametargetlist parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/*  96 */       return (Qnametargetlist)XmlBeans.getContextTypeLoader().parse(xis, Qnametargetlist.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 100 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Qnametargetlist.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 104 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Qnametargetlist.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\Qnametargetlist.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */