/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ public interface NamespaceList
/*     */   extends XmlAnySimpleType
/*     */ {
/*     */   Object getObjectValue();
/*     */   
/*  27 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.NamespaceList")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("namespacelist20datype");
/*     */   
/*     */   void setObjectValue(Object paramObject);
/*     */   
/*     */   Object objectValue();
/*     */   
/*     */   void objectSet(Object paramObject);
/*     */   
/*     */   SchemaType instanceType();
/*     */   
/*  37 */   public static interface Member extends XmlToken { public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member == null) ? (NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member = NamespaceList.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.NamespaceList$Member")) : NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("anonc6fftype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     public static final Enum ANY = Enum.forString("##any");
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int INT_ANY = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     StringEnumAbstractBase enumValue();
/*     */ 
/*     */ 
/*     */     
/*     */     void set(StringEnumAbstractBase param1StringEnumAbstractBase);
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Enum
/*     */       extends StringEnumAbstractBase
/*     */     {
/*     */       static final int INT_ANY = 1;
/*     */ 
/*     */ 
/*     */       
/*     */       public static Enum forString(String s) {
/*  68 */         return (Enum)table.forString(s);
/*     */       }
/*     */ 
/*     */       
/*     */       public static Enum forInt(int i) {
/*  73 */         return (Enum)table.forInt(i);
/*     */       }
/*     */       private Enum(String s, int i) {
/*  76 */         super(s, i);
/*     */       }
/*     */ 
/*     */       
/*  80 */       public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table((StringEnumAbstractBase[])new Enum[] { new Enum("##any", 1) });
/*     */ 
/*     */ 
/*     */       
/*     */       private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */       
/*     */       private Object readResolve() {
/*  89 */         return forInt(intValue());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static NamespaceList.Member newValue(Object obj) {
/* 100 */         return (NamespaceList.Member)NamespaceList.Member.type.newValue(obj);
/*     */       }
/*     */       public static NamespaceList.Member newInstance() {
/* 103 */         return (NamespaceList.Member)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.Member.type, null);
/*     */       }
/*     */       public static NamespaceList.Member newInstance(XmlOptions options) {
/* 106 */         return (NamespaceList.Member)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.Member.type, options);
/*     */       }
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Member2
/*     */     extends XmlAnySimpleType
/*     */   {
/* 128 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2 == null) ? (NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2 = NamespaceList.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.NamespaceList$Member2")) : NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("anon5680type");
/*     */     
/*     */     List getListValue();
/*     */     
/*     */     List xgetListValue();
/*     */     
/*     */     void setListValue(List param1List);
/*     */     
/*     */     List listValue();
/*     */     
/*     */     List xlistValue();
/*     */     
/*     */     void set(List param1List);
/*     */     
/*     */     public static interface Item
/*     */       extends XmlAnySimpleType
/*     */     {
/*     */       Object getObjectValue();
/*     */       
/* 147 */       public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2$Item == null) ? (NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2$Item = NamespaceList.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.NamespaceList$Member2$Item")) : NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2$Item).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("anon0798type");
/*     */       
/*     */       void setObjectValue(Object param2Object);
/*     */       
/*     */       Object objectValue();
/*     */       
/*     */       void objectSet(Object param2Object);
/*     */       
/*     */       SchemaType instanceType();
/*     */       
/* 157 */       public static interface Member extends XmlToken { public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2$Item$Member == null) ? (NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2$Item$Member = NamespaceList.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.NamespaceList$Member2$Item$Member")) : NamespaceList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespaceList$Member2$Item$Member).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("anon1dd3type");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 163 */         public static final Enum LOCAL = Enum.forString("##local");
/*     */ 
/*     */ 
/*     */         
/*     */         public static final int INT_LOCAL = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         StringEnumAbstractBase enumValue();
/*     */ 
/*     */ 
/*     */         
/*     */         void set(StringEnumAbstractBase param3StringEnumAbstractBase);
/*     */ 
/*     */ 
/*     */         
/*     */         public static final class Enum
/*     */           extends StringEnumAbstractBase
/*     */         {
/*     */           static final int INT_LOCAL = 1;
/*     */ 
/*     */ 
/*     */           
/*     */           public static Enum forString(String s) {
/* 188 */             return (Enum)table.forString(s);
/*     */           }
/*     */ 
/*     */           
/*     */           public static Enum forInt(int i) {
/* 193 */             return (Enum)table.forInt(i);
/*     */           }
/*     */           private Enum(String s, int i) {
/* 196 */             super(s, i);
/*     */           }
/*     */ 
/*     */           
/* 200 */           public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table((StringEnumAbstractBase[])new Enum[] { new Enum("##local", 1) });
/*     */ 
/*     */ 
/*     */           
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */           
/*     */           private Object readResolve() {
/* 209 */             return forInt(intValue());
/*     */           }
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public static final class Factory
/*     */         {
/*     */           public static NamespaceList.Member2.Item.Member newValue(Object obj) {
/* 220 */             return (NamespaceList.Member2.Item.Member)NamespaceList.Member2.Item.Member.type.newValue(obj);
/*     */           }
/*     */           public static NamespaceList.Member2.Item.Member newInstance() {
/* 223 */             return (NamespaceList.Member2.Item.Member)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.Member2.Item.Member.type, null);
/*     */           }
/*     */           public static NamespaceList.Member2.Item.Member newInstance(XmlOptions options) {
/* 226 */             return (NamespaceList.Member2.Item.Member)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.Member2.Item.Member.type, options);
/*     */           }
/*     */         } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public static final class Factory
/*     */       {
/*     */         public static NamespaceList.Member2.Item newValue(Object obj) {
/* 240 */           return (NamespaceList.Member2.Item)NamespaceList.Member2.Item.type.newValue(obj);
/*     */         }
/*     */         public static NamespaceList.Member2.Item newInstance() {
/* 243 */           return (NamespaceList.Member2.Item)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.Member2.Item.type, null);
/*     */         }
/*     */         public static NamespaceList.Member2.Item newInstance(XmlOptions options) {
/* 246 */           return (NamespaceList.Member2.Item)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.Member2.Item.type, options);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static NamespaceList.Member2 newValue(Object obj) {
/* 260 */         return (NamespaceList.Member2)NamespaceList.Member2.type.newValue(obj);
/*     */       }
/*     */       public static NamespaceList.Member2 newInstance() {
/* 263 */         return (NamespaceList.Member2)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.Member2.type, null);
/*     */       }
/*     */       public static NamespaceList.Member2 newInstance(XmlOptions options) {
/* 266 */         return (NamespaceList.Member2)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.Member2.type, options);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static NamespaceList newValue(Object obj) {
/* 280 */       return (NamespaceList)NamespaceList.type.newValue(obj);
/*     */     }
/*     */     public static NamespaceList newInstance() {
/* 283 */       return (NamespaceList)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.type, null);
/*     */     }
/*     */     public static NamespaceList newInstance(XmlOptions options) {
/* 286 */       return (NamespaceList)XmlBeans.getContextTypeLoader().newInstance(NamespaceList.type, options);
/*     */     }
/*     */     
/*     */     public static NamespaceList parse(String xmlAsString) throws XmlException {
/* 290 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(xmlAsString, NamespaceList.type, null);
/*     */     }
/*     */     public static NamespaceList parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 293 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(xmlAsString, NamespaceList.type, options);
/*     */     }
/*     */     
/*     */     public static NamespaceList parse(File file) throws XmlException, IOException {
/* 297 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(file, NamespaceList.type, null);
/*     */     }
/*     */     public static NamespaceList parse(File file, XmlOptions options) throws XmlException, IOException {
/* 300 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(file, NamespaceList.type, options);
/*     */     }
/*     */     public static NamespaceList parse(URL u) throws XmlException, IOException {
/* 303 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(u, NamespaceList.type, null);
/*     */     }
/*     */     public static NamespaceList parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 306 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(u, NamespaceList.type, options);
/*     */     }
/*     */     public static NamespaceList parse(InputStream is) throws XmlException, IOException {
/* 309 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(is, NamespaceList.type, null);
/*     */     }
/*     */     public static NamespaceList parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 312 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(is, NamespaceList.type, options);
/*     */     }
/*     */     public static NamespaceList parse(Reader r) throws XmlException, IOException {
/* 315 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(r, NamespaceList.type, null);
/*     */     }
/*     */     public static NamespaceList parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 318 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(r, NamespaceList.type, options);
/*     */     }
/*     */     public static NamespaceList parse(XMLStreamReader sr) throws XmlException {
/* 321 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(sr, NamespaceList.type, null);
/*     */     }
/*     */     public static NamespaceList parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 324 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(sr, NamespaceList.type, options);
/*     */     }
/*     */     public static NamespaceList parse(Node node) throws XmlException {
/* 327 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(node, NamespaceList.type, null);
/*     */     }
/*     */     public static NamespaceList parse(Node node, XmlOptions options) throws XmlException {
/* 330 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(node, NamespaceList.type, options);
/*     */     }
/*     */     
/*     */     public static NamespaceList parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 334 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(xis, NamespaceList.type, null);
/*     */     }
/*     */     
/*     */     public static NamespaceList parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 338 */       return (NamespaceList)XmlBeans.getContextTypeLoader().parse(xis, NamespaceList.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 342 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, NamespaceList.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 346 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, NamespaceList.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\NamespaceList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */