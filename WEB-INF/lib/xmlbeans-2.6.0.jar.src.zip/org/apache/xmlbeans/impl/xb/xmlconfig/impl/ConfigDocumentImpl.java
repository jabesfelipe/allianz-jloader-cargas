/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Extensionconfig;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Nsconfig;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Qnameconfig;
/*     */ import org.apache.xmlbeans.impl.xb.xmlconfig.Usertypeconfig;
/*     */ 
/*     */ public class ConfigDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements ConfigDocument
/*     */ {
/*     */   public ConfigDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName CONFIG$0 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "config");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigDocument.Config getConfig() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       ConfigDocument.Config target = null;
/*  36 */       target = (ConfigDocument.Config)get_store().find_element_user(CONFIG$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfig(ConfigDocument.Config config) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       ConfigDocument.Config target = null;
/*  54 */       target = (ConfigDocument.Config)get_store().find_element_user(CONFIG$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (ConfigDocument.Config)get_store().add_element_user(CONFIG$0);
/*     */       }
/*  59 */       target.set((XmlObject)config);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigDocument.Config addNewConfig() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       ConfigDocument.Config target = null;
/*  72 */       target = (ConfigDocument.Config)get_store().add_element_user(CONFIG$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ConfigImpl
/*     */     extends XmlComplexContentImpl
/*     */     implements ConfigDocument.Config
/*     */   {
/*     */     public ConfigImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName NAMESPACE$0 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "namespace");
/*     */     
/*  91 */     private static final QName QNAME$2 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "qname");
/*     */     
/*  93 */     private static final QName EXTENSION$4 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "extension");
/*     */     
/*  95 */     private static final QName USERTYPE$6 = new QName("http://xml.apache.org/xmlbeans/2004/02/xbean/config", "usertype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Nsconfig[] getNamespaceArray() {
/* 104 */       synchronized (monitor()) {
/*     */         
/* 106 */         check_orphaned();
/* 107 */         List targetList = new ArrayList();
/* 108 */         get_store().find_all_element_users(NAMESPACE$0, targetList);
/* 109 */         Nsconfig[] result = new Nsconfig[targetList.size()];
/* 110 */         targetList.toArray((Object[])result);
/* 111 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Nsconfig getNamespaceArray(int i) {
/* 120 */       synchronized (monitor()) {
/*     */         
/* 122 */         check_orphaned();
/* 123 */         Nsconfig target = null;
/* 124 */         target = (Nsconfig)get_store().find_element_user(NAMESPACE$0, i);
/* 125 */         if (target == null)
/*     */         {
/* 127 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 129 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfNamespaceArray() {
/* 138 */       synchronized (monitor()) {
/*     */         
/* 140 */         check_orphaned();
/* 141 */         return get_store().count_elements(NAMESPACE$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setNamespaceArray(Nsconfig[] namespaceArray) {
/* 150 */       synchronized (monitor()) {
/*     */         
/* 152 */         check_orphaned();
/* 153 */         arraySetterHelper((XmlObject[])namespaceArray, NAMESPACE$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setNamespaceArray(int i, Nsconfig namespace) {
/* 162 */       synchronized (monitor()) {
/*     */         
/* 164 */         check_orphaned();
/* 165 */         Nsconfig target = null;
/* 166 */         target = (Nsconfig)get_store().find_element_user(NAMESPACE$0, i);
/* 167 */         if (target == null)
/*     */         {
/* 169 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 171 */         target.set((XmlObject)namespace);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Nsconfig insertNewNamespace(int i) {
/* 180 */       synchronized (monitor()) {
/*     */         
/* 182 */         check_orphaned();
/* 183 */         Nsconfig target = null;
/* 184 */         target = (Nsconfig)get_store().insert_element_user(NAMESPACE$0, i);
/* 185 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Nsconfig addNewNamespace() {
/* 194 */       synchronized (monitor()) {
/*     */         
/* 196 */         check_orphaned();
/* 197 */         Nsconfig target = null;
/* 198 */         target = (Nsconfig)get_store().add_element_user(NAMESPACE$0);
/* 199 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeNamespace(int i) {
/* 208 */       synchronized (monitor()) {
/*     */         
/* 210 */         check_orphaned();
/* 211 */         get_store().remove_element(NAMESPACE$0, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Qnameconfig[] getQnameArray() {
/* 220 */       synchronized (monitor()) {
/*     */         
/* 222 */         check_orphaned();
/* 223 */         List targetList = new ArrayList();
/* 224 */         get_store().find_all_element_users(QNAME$2, targetList);
/* 225 */         Qnameconfig[] result = new Qnameconfig[targetList.size()];
/* 226 */         targetList.toArray((Object[])result);
/* 227 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Qnameconfig getQnameArray(int i) {
/* 236 */       synchronized (monitor()) {
/*     */         
/* 238 */         check_orphaned();
/* 239 */         Qnameconfig target = null;
/* 240 */         target = (Qnameconfig)get_store().find_element_user(QNAME$2, i);
/* 241 */         if (target == null)
/*     */         {
/* 243 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 245 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfQnameArray() {
/* 254 */       synchronized (monitor()) {
/*     */         
/* 256 */         check_orphaned();
/* 257 */         return get_store().count_elements(QNAME$2);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setQnameArray(Qnameconfig[] qnameArray) {
/* 266 */       synchronized (monitor()) {
/*     */         
/* 268 */         check_orphaned();
/* 269 */         arraySetterHelper((XmlObject[])qnameArray, QNAME$2);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setQnameArray(int i, Qnameconfig qname) {
/* 278 */       synchronized (monitor()) {
/*     */         
/* 280 */         check_orphaned();
/* 281 */         Qnameconfig target = null;
/* 282 */         target = (Qnameconfig)get_store().find_element_user(QNAME$2, i);
/* 283 */         if (target == null)
/*     */         {
/* 285 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 287 */         target.set((XmlObject)qname);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Qnameconfig insertNewQname(int i) {
/* 296 */       synchronized (monitor()) {
/*     */         
/* 298 */         check_orphaned();
/* 299 */         Qnameconfig target = null;
/* 300 */         target = (Qnameconfig)get_store().insert_element_user(QNAME$2, i);
/* 301 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Qnameconfig addNewQname() {
/* 310 */       synchronized (monitor()) {
/*     */         
/* 312 */         check_orphaned();
/* 313 */         Qnameconfig target = null;
/* 314 */         target = (Qnameconfig)get_store().add_element_user(QNAME$2);
/* 315 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeQname(int i) {
/* 324 */       synchronized (monitor()) {
/*     */         
/* 326 */         check_orphaned();
/* 327 */         get_store().remove_element(QNAME$2, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Extensionconfig[] getExtensionArray() {
/* 336 */       synchronized (monitor()) {
/*     */         
/* 338 */         check_orphaned();
/* 339 */         List targetList = new ArrayList();
/* 340 */         get_store().find_all_element_users(EXTENSION$4, targetList);
/* 341 */         Extensionconfig[] result = new Extensionconfig[targetList.size()];
/* 342 */         targetList.toArray((Object[])result);
/* 343 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Extensionconfig getExtensionArray(int i) {
/* 352 */       synchronized (monitor()) {
/*     */         
/* 354 */         check_orphaned();
/* 355 */         Extensionconfig target = null;
/* 356 */         target = (Extensionconfig)get_store().find_element_user(EXTENSION$4, i);
/* 357 */         if (target == null)
/*     */         {
/* 359 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 361 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfExtensionArray() {
/* 370 */       synchronized (monitor()) {
/*     */         
/* 372 */         check_orphaned();
/* 373 */         return get_store().count_elements(EXTENSION$4);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setExtensionArray(Extensionconfig[] extensionArray) {
/* 382 */       synchronized (monitor()) {
/*     */         
/* 384 */         check_orphaned();
/* 385 */         arraySetterHelper((XmlObject[])extensionArray, EXTENSION$4);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setExtensionArray(int i, Extensionconfig extension) {
/* 394 */       synchronized (monitor()) {
/*     */         
/* 396 */         check_orphaned();
/* 397 */         Extensionconfig target = null;
/* 398 */         target = (Extensionconfig)get_store().find_element_user(EXTENSION$4, i);
/* 399 */         if (target == null)
/*     */         {
/* 401 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 403 */         target.set((XmlObject)extension);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Extensionconfig insertNewExtension(int i) {
/* 412 */       synchronized (monitor()) {
/*     */         
/* 414 */         check_orphaned();
/* 415 */         Extensionconfig target = null;
/* 416 */         target = (Extensionconfig)get_store().insert_element_user(EXTENSION$4, i);
/* 417 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Extensionconfig addNewExtension() {
/* 426 */       synchronized (monitor()) {
/*     */         
/* 428 */         check_orphaned();
/* 429 */         Extensionconfig target = null;
/* 430 */         target = (Extensionconfig)get_store().add_element_user(EXTENSION$4);
/* 431 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeExtension(int i) {
/* 440 */       synchronized (monitor()) {
/*     */         
/* 442 */         check_orphaned();
/* 443 */         get_store().remove_element(EXTENSION$4, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Usertypeconfig[] getUsertypeArray() {
/* 452 */       synchronized (monitor()) {
/*     */         
/* 454 */         check_orphaned();
/* 455 */         List targetList = new ArrayList();
/* 456 */         get_store().find_all_element_users(USERTYPE$6, targetList);
/* 457 */         Usertypeconfig[] result = new Usertypeconfig[targetList.size()];
/* 458 */         targetList.toArray((Object[])result);
/* 459 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Usertypeconfig getUsertypeArray(int i) {
/* 468 */       synchronized (monitor()) {
/*     */         
/* 470 */         check_orphaned();
/* 471 */         Usertypeconfig target = null;
/* 472 */         target = (Usertypeconfig)get_store().find_element_user(USERTYPE$6, i);
/* 473 */         if (target == null)
/*     */         {
/* 475 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 477 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfUsertypeArray() {
/* 486 */       synchronized (monitor()) {
/*     */         
/* 488 */         check_orphaned();
/* 489 */         return get_store().count_elements(USERTYPE$6);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setUsertypeArray(Usertypeconfig[] usertypeArray) {
/* 498 */       synchronized (monitor()) {
/*     */         
/* 500 */         check_orphaned();
/* 501 */         arraySetterHelper((XmlObject[])usertypeArray, USERTYPE$6);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setUsertypeArray(int i, Usertypeconfig usertype) {
/* 510 */       synchronized (monitor()) {
/*     */         
/* 512 */         check_orphaned();
/* 513 */         Usertypeconfig target = null;
/* 514 */         target = (Usertypeconfig)get_store().find_element_user(USERTYPE$6, i);
/* 515 */         if (target == null)
/*     */         {
/* 517 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 519 */         target.set((XmlObject)usertype);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Usertypeconfig insertNewUsertype(int i) {
/* 528 */       synchronized (monitor()) {
/*     */         
/* 530 */         check_orphaned();
/* 531 */         Usertypeconfig target = null;
/* 532 */         target = (Usertypeconfig)get_store().insert_element_user(USERTYPE$6, i);
/* 533 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Usertypeconfig addNewUsertype() {
/* 542 */       synchronized (monitor()) {
/*     */         
/* 544 */         check_orphaned();
/* 545 */         Usertypeconfig target = null;
/* 546 */         target = (Usertypeconfig)get_store().add_element_user(USERTYPE$6);
/* 547 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeUsertype(int i) {
/* 556 */       synchronized (monitor()) {
/*     */         
/* 558 */         check_orphaned();
/* 559 */         get_store().remove_element(USERTYPE$6, i);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\impl\ConfigDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */