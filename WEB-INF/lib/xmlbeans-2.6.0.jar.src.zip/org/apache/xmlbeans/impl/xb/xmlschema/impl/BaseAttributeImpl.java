/*     */ package org.apache.xmlbeans.impl.xb.xmlschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlAnyURI;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xmlschema.BaseAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseAttributeImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements BaseAttribute
/*     */ {
/*     */   public BaseAttributeImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName BASE$0 = new QName("http://www.w3.org/XML/1998/namespace", "base");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBase() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       SimpleValue target = null;
/*  36 */       target = (SimpleValue)get_store().find_attribute_user(BASE$0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlAnyURI xgetBase() {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       XmlAnyURI target = null;
/*  54 */       target = (XmlAnyURI)get_store().find_attribute_user(BASE$0);
/*  55 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetBase() {
/*  64 */     synchronized (monitor()) {
/*     */       
/*  66 */       check_orphaned();
/*  67 */       return (get_store().find_attribute_user(BASE$0) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBase(String base) {
/*  76 */     synchronized (monitor()) {
/*     */       
/*  78 */       check_orphaned();
/*  79 */       SimpleValue target = null;
/*  80 */       target = (SimpleValue)get_store().find_attribute_user(BASE$0);
/*  81 */       if (target == null)
/*     */       {
/*  83 */         target = (SimpleValue)get_store().add_attribute_user(BASE$0);
/*     */       }
/*  85 */       target.setStringValue(base);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetBase(XmlAnyURI base) {
/*  94 */     synchronized (monitor()) {
/*     */       
/*  96 */       check_orphaned();
/*  97 */       XmlAnyURI target = null;
/*  98 */       target = (XmlAnyURI)get_store().find_attribute_user(BASE$0);
/*  99 */       if (target == null)
/*     */       {
/* 101 */         target = (XmlAnyURI)get_store().add_attribute_user(BASE$0);
/*     */       }
/* 103 */       target.set((XmlObject)base);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetBase() {
/* 112 */     synchronized (monitor()) {
/*     */       
/* 114 */       check_orphaned();
/* 115 */       get_store().remove_attribute(BASE$0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlschema\impl\BaseAttributeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */