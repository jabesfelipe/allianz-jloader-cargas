/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlQName;
/*     */ import org.apache.xmlbeans.XmlString;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface Usertypeconfig extends XmlObject {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Usertypeconfig == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Usertypeconfig = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.Usertypeconfig")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Usertypeconfig).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("usertypeconfig7bbatype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getStaticHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlString xgetStaticHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setStaticHandler(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetStaticHandler(XmlString paramXmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   QName getName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlQName xgetName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setName(QName paramQName);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetName(XmlQName paramXmlQName);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getJavaname();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlString xgetJavaname();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetJavaname();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setJavaname(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetJavaname(XmlString paramXmlString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetJavaname();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static Usertypeconfig newInstance() {
/* 109 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().newInstance(Usertypeconfig.type, null);
/*     */     }
/*     */     public static Usertypeconfig newInstance(XmlOptions options) {
/* 112 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().newInstance(Usertypeconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Usertypeconfig parse(String xmlAsString) throws XmlException {
/* 116 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(xmlAsString, Usertypeconfig.type, null);
/*     */     }
/*     */     public static Usertypeconfig parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 119 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(xmlAsString, Usertypeconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Usertypeconfig parse(File file) throws XmlException, IOException {
/* 123 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(file, Usertypeconfig.type, null);
/*     */     }
/*     */     public static Usertypeconfig parse(File file, XmlOptions options) throws XmlException, IOException {
/* 126 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(file, Usertypeconfig.type, options);
/*     */     }
/*     */     public static Usertypeconfig parse(URL u) throws XmlException, IOException {
/* 129 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(u, Usertypeconfig.type, null);
/*     */     }
/*     */     public static Usertypeconfig parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 132 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(u, Usertypeconfig.type, options);
/*     */     }
/*     */     public static Usertypeconfig parse(InputStream is) throws XmlException, IOException {
/* 135 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(is, Usertypeconfig.type, null);
/*     */     }
/*     */     public static Usertypeconfig parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 138 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(is, Usertypeconfig.type, options);
/*     */     }
/*     */     public static Usertypeconfig parse(Reader r) throws XmlException, IOException {
/* 141 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(r, Usertypeconfig.type, null);
/*     */     }
/*     */     public static Usertypeconfig parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 144 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(r, Usertypeconfig.type, options);
/*     */     }
/*     */     public static Usertypeconfig parse(XMLStreamReader sr) throws XmlException {
/* 147 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(sr, Usertypeconfig.type, null);
/*     */     }
/*     */     public static Usertypeconfig parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 150 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(sr, Usertypeconfig.type, options);
/*     */     }
/*     */     public static Usertypeconfig parse(Node node) throws XmlException {
/* 153 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(node, Usertypeconfig.type, null);
/*     */     }
/*     */     public static Usertypeconfig parse(Node node, XmlOptions options) throws XmlException {
/* 156 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(node, Usertypeconfig.type, options);
/*     */     }
/*     */     
/*     */     public static Usertypeconfig parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 160 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(xis, Usertypeconfig.type, null);
/*     */     }
/*     */     
/*     */     public static Usertypeconfig parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 164 */       return (Usertypeconfig)XmlBeans.getContextTypeLoader().parse(xis, Usertypeconfig.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 168 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Usertypeconfig.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 172 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Usertypeconfig.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\Usertypeconfig.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */