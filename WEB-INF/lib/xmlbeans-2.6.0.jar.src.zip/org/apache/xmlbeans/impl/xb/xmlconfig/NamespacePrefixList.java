/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface NamespacePrefixList
/*     */   extends XmlAnySimpleType {
/*     */   List getListValue();
/*     */   
/*     */   List xgetListValue();
/*     */   
/*     */   void setListValue(List paramList);
/*     */   
/*  27 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespacePrefixList == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespacePrefixList = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.NamespacePrefixList")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$NamespacePrefixList).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("namespaceprefixlistec0ctype");
/*     */   
/*     */   List listValue();
/*     */   
/*     */   List xlistValue();
/*     */   
/*     */   void set(List paramList);
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static NamespacePrefixList newValue(Object obj) {
/*  38 */       return (NamespacePrefixList)NamespacePrefixList.type.newValue(obj);
/*     */     }
/*     */     public static NamespacePrefixList newInstance() {
/*  41 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().newInstance(NamespacePrefixList.type, null);
/*     */     }
/*     */     public static NamespacePrefixList newInstance(XmlOptions options) {
/*  44 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().newInstance(NamespacePrefixList.type, options);
/*     */     }
/*     */     
/*     */     public static NamespacePrefixList parse(String xmlAsString) throws XmlException {
/*  48 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(xmlAsString, NamespacePrefixList.type, null);
/*     */     }
/*     */     public static NamespacePrefixList parse(String xmlAsString, XmlOptions options) throws XmlException {
/*  51 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(xmlAsString, NamespacePrefixList.type, options);
/*     */     }
/*     */     
/*     */     public static NamespacePrefixList parse(File file) throws XmlException, IOException {
/*  55 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(file, NamespacePrefixList.type, null);
/*     */     }
/*     */     public static NamespacePrefixList parse(File file, XmlOptions options) throws XmlException, IOException {
/*  58 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(file, NamespacePrefixList.type, options);
/*     */     }
/*     */     public static NamespacePrefixList parse(URL u) throws XmlException, IOException {
/*  61 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(u, NamespacePrefixList.type, null);
/*     */     }
/*     */     public static NamespacePrefixList parse(URL u, XmlOptions options) throws XmlException, IOException {
/*  64 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(u, NamespacePrefixList.type, options);
/*     */     }
/*     */     public static NamespacePrefixList parse(InputStream is) throws XmlException, IOException {
/*  67 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(is, NamespacePrefixList.type, null);
/*     */     }
/*     */     public static NamespacePrefixList parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/*  70 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(is, NamespacePrefixList.type, options);
/*     */     }
/*     */     public static NamespacePrefixList parse(Reader r) throws XmlException, IOException {
/*  73 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(r, NamespacePrefixList.type, null);
/*     */     }
/*     */     public static NamespacePrefixList parse(Reader r, XmlOptions options) throws XmlException, IOException {
/*  76 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(r, NamespacePrefixList.type, options);
/*     */     }
/*     */     public static NamespacePrefixList parse(XMLStreamReader sr) throws XmlException {
/*  79 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(sr, NamespacePrefixList.type, null);
/*     */     }
/*     */     public static NamespacePrefixList parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/*  82 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(sr, NamespacePrefixList.type, options);
/*     */     }
/*     */     public static NamespacePrefixList parse(Node node) throws XmlException {
/*  85 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(node, NamespacePrefixList.type, null);
/*     */     }
/*     */     public static NamespacePrefixList parse(Node node, XmlOptions options) throws XmlException {
/*  88 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(node, NamespacePrefixList.type, options);
/*     */     }
/*     */     
/*     */     public static NamespacePrefixList parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/*  92 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(xis, NamespacePrefixList.type, null);
/*     */     }
/*     */     
/*     */     public static NamespacePrefixList parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/*  96 */       return (NamespacePrefixList)XmlBeans.getContextTypeLoader().parse(xis, NamespacePrefixList.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 100 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, NamespacePrefixList.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 104 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, NamespacePrefixList.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\NamespacePrefixList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */