/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.JavaStringHolderEx;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.FieldDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements FieldDocument
/*     */ {
/*     */   public FieldDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName FIELD$0 = new QName("http://www.w3.org/2001/XMLSchema", "field");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldDocument.Field getField() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       FieldDocument.Field target = null;
/*  36 */       target = (FieldDocument.Field)get_store().find_element_user(FIELD$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setField(FieldDocument.Field field) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       FieldDocument.Field target = null;
/*  54 */       target = (FieldDocument.Field)get_store().find_element_user(FIELD$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (FieldDocument.Field)get_store().add_element_user(FIELD$0);
/*     */       }
/*  59 */       target.set((XmlObject)field);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldDocument.Field addNewField() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       FieldDocument.Field target = null;
/*  72 */       target = (FieldDocument.Field)get_store().add_element_user(FIELD$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FieldImpl
/*     */     extends AnnotatedImpl
/*     */     implements FieldDocument.Field
/*     */   {
/*     */     public FieldImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName XPATH$0 = new QName("", "xpath");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getXpath() {
/*  98 */       synchronized (monitor()) {
/*     */         
/* 100 */         check_orphaned();
/* 101 */         SimpleValue target = null;
/* 102 */         target = (SimpleValue)get_store().find_attribute_user(XPATH$0);
/* 103 */         if (target == null)
/*     */         {
/* 105 */           return null;
/*     */         }
/* 107 */         return target.getStringValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldDocument.Field.Xpath xgetXpath() {
/* 116 */       synchronized (monitor()) {
/*     */         
/* 118 */         check_orphaned();
/* 119 */         FieldDocument.Field.Xpath target = null;
/* 120 */         target = (FieldDocument.Field.Xpath)get_store().find_attribute_user(XPATH$0);
/* 121 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setXpath(String xpath) {
/* 130 */       synchronized (monitor()) {
/*     */         
/* 132 */         check_orphaned();
/* 133 */         SimpleValue target = null;
/* 134 */         target = (SimpleValue)get_store().find_attribute_user(XPATH$0);
/* 135 */         if (target == null)
/*     */         {
/* 137 */           target = (SimpleValue)get_store().add_attribute_user(XPATH$0);
/*     */         }
/* 139 */         target.setStringValue(xpath);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetXpath(FieldDocument.Field.Xpath xpath) {
/* 148 */       synchronized (monitor()) {
/*     */         
/* 150 */         check_orphaned();
/* 151 */         FieldDocument.Field.Xpath target = null;
/* 152 */         target = (FieldDocument.Field.Xpath)get_store().find_attribute_user(XPATH$0);
/* 153 */         if (target == null)
/*     */         {
/* 155 */           target = (FieldDocument.Field.Xpath)get_store().add_attribute_user(XPATH$0);
/*     */         }
/* 157 */         target.set((XmlObject)xpath);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class XpathImpl
/*     */       extends JavaStringHolderEx
/*     */       implements FieldDocument.Field.Xpath
/*     */     {
/*     */       public XpathImpl(SchemaType sType) {
/* 170 */         super(sType, false);
/*     */       }
/*     */ 
/*     */       
/*     */       protected XpathImpl(SchemaType sType, boolean b) {
/* 175 */         super(sType, b);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\FieldDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */