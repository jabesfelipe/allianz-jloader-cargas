/*     */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlAnyURI;
/*     */ import org.apache.xmlbeans.XmlLanguage;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xsdschema.DocumentationDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentationDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements DocumentationDocument
/*     */ {
/*     */   public DocumentationDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName DOCUMENTATION$0 = new QName("http://www.w3.org/2001/XMLSchema", "documentation");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentationDocument.Documentation getDocumentation() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       DocumentationDocument.Documentation target = null;
/*  36 */       target = (DocumentationDocument.Documentation)get_store().find_element_user(DOCUMENTATION$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocumentation(DocumentationDocument.Documentation documentation) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       DocumentationDocument.Documentation target = null;
/*  54 */       target = (DocumentationDocument.Documentation)get_store().find_element_user(DOCUMENTATION$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (DocumentationDocument.Documentation)get_store().add_element_user(DOCUMENTATION$0);
/*     */       }
/*  59 */       target.set((XmlObject)documentation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentationDocument.Documentation addNewDocumentation() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       DocumentationDocument.Documentation target = null;
/*  72 */       target = (DocumentationDocument.Documentation)get_store().add_element_user(DOCUMENTATION$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DocumentationImpl
/*     */     extends XmlComplexContentImpl
/*     */     implements DocumentationDocument.Documentation
/*     */   {
/*     */     public DocumentationImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName SOURCE$0 = new QName("", "source");
/*     */     
/*  91 */     private static final QName LANG$2 = new QName("http://www.w3.org/XML/1998/namespace", "lang");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getSource() {
/* 100 */       synchronized (monitor()) {
/*     */         
/* 102 */         check_orphaned();
/* 103 */         SimpleValue target = null;
/* 104 */         target = (SimpleValue)get_store().find_attribute_user(SOURCE$0);
/* 105 */         if (target == null)
/*     */         {
/* 107 */           return null;
/*     */         }
/* 109 */         return target.getStringValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlAnyURI xgetSource() {
/* 118 */       synchronized (monitor()) {
/*     */         
/* 120 */         check_orphaned();
/* 121 */         XmlAnyURI target = null;
/* 122 */         target = (XmlAnyURI)get_store().find_attribute_user(SOURCE$0);
/* 123 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetSource() {
/* 132 */       synchronized (monitor()) {
/*     */         
/* 134 */         check_orphaned();
/* 135 */         return (get_store().find_attribute_user(SOURCE$0) != null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setSource(String source) {
/* 144 */       synchronized (monitor()) {
/*     */         
/* 146 */         check_orphaned();
/* 147 */         SimpleValue target = null;
/* 148 */         target = (SimpleValue)get_store().find_attribute_user(SOURCE$0);
/* 149 */         if (target == null)
/*     */         {
/* 151 */           target = (SimpleValue)get_store().add_attribute_user(SOURCE$0);
/*     */         }
/* 153 */         target.setStringValue(source);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetSource(XmlAnyURI source) {
/* 162 */       synchronized (monitor()) {
/*     */         
/* 164 */         check_orphaned();
/* 165 */         XmlAnyURI target = null;
/* 166 */         target = (XmlAnyURI)get_store().find_attribute_user(SOURCE$0);
/* 167 */         if (target == null)
/*     */         {
/* 169 */           target = (XmlAnyURI)get_store().add_attribute_user(SOURCE$0);
/*     */         }
/* 171 */         target.set((XmlObject)source);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetSource() {
/* 180 */       synchronized (monitor()) {
/*     */         
/* 182 */         check_orphaned();
/* 183 */         get_store().remove_attribute(SOURCE$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getLang() {
/* 192 */       synchronized (monitor()) {
/*     */         
/* 194 */         check_orphaned();
/* 195 */         SimpleValue target = null;
/* 196 */         target = (SimpleValue)get_store().find_attribute_user(LANG$2);
/* 197 */         if (target == null)
/*     */         {
/* 199 */           return null;
/*     */         }
/* 201 */         return target.getStringValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlLanguage xgetLang() {
/* 210 */       synchronized (monitor()) {
/*     */         
/* 212 */         check_orphaned();
/* 213 */         XmlLanguage target = null;
/* 214 */         target = (XmlLanguage)get_store().find_attribute_user(LANG$2);
/* 215 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetLang() {
/* 224 */       synchronized (monitor()) {
/*     */         
/* 226 */         check_orphaned();
/* 227 */         return (get_store().find_attribute_user(LANG$2) != null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setLang(String lang) {
/* 236 */       synchronized (monitor()) {
/*     */         
/* 238 */         check_orphaned();
/* 239 */         SimpleValue target = null;
/* 240 */         target = (SimpleValue)get_store().find_attribute_user(LANG$2);
/* 241 */         if (target == null)
/*     */         {
/* 243 */           target = (SimpleValue)get_store().add_attribute_user(LANG$2);
/*     */         }
/* 245 */         target.setStringValue(lang);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetLang(XmlLanguage lang) {
/* 254 */       synchronized (monitor()) {
/*     */         
/* 256 */         check_orphaned();
/* 257 */         XmlLanguage target = null;
/* 258 */         target = (XmlLanguage)get_store().find_attribute_user(LANG$2);
/* 259 */         if (target == null)
/*     */         {
/* 261 */           target = (XmlLanguage)get_store().add_attribute_user(LANG$2);
/*     */         }
/* 263 */         target.set((XmlObject)lang);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetLang() {
/* 272 */       synchronized (monitor()) {
/*     */         
/* 274 */         check_orphaned();
/* 275 */         get_store().remove_attribute(LANG$2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\DocumentationDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */