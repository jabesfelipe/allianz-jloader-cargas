/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface Qnametargetenum extends XmlToken {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnametargetenum == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnametargetenum = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.Qnametargetenum")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$Qnametargetenum).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("qnametargetenum9f8ftype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  24 */   public static final Enum TYPE = Enum.forString("type");
/*  25 */   public static final Enum DOCUMENT_TYPE = Enum.forString("document-type");
/*  26 */   public static final Enum ACCESSOR_ELEMENT = Enum.forString("accessor-element");
/*  27 */   public static final Enum ACCESSOR_ATTRIBUTE = Enum.forString("accessor-attribute");
/*     */   
/*     */   public static final int INT_TYPE = 1;
/*     */   
/*     */   public static final int INT_DOCUMENT_TYPE = 2;
/*     */   
/*     */   public static final int INT_ACCESSOR_ELEMENT = 3;
/*     */   
/*     */   public static final int INT_ACCESSOR_ATTRIBUTE = 4;
/*     */ 
/*     */   
/*     */   StringEnumAbstractBase enumValue();
/*     */ 
/*     */   
/*     */   void set(StringEnumAbstractBase paramStringEnumAbstractBase);
/*     */ 
/*     */   
/*     */   public static final class Enum
/*     */     extends StringEnumAbstractBase
/*     */   {
/*     */     static final int INT_TYPE = 1;
/*     */     
/*     */     static final int INT_DOCUMENT_TYPE = 2;
/*     */     
/*     */     static final int INT_ACCESSOR_ELEMENT = 3;
/*     */     static final int INT_ACCESSOR_ATTRIBUTE = 4;
/*     */     
/*     */     public static Enum forString(String s) {
/*  55 */       return (Enum)table.forString(s);
/*     */     }
/*     */ 
/*     */     
/*     */     public static Enum forInt(int i) {
/*  60 */       return (Enum)table.forInt(i);
/*     */     }
/*     */     private Enum(String s, int i) {
/*  63 */       super(s, i);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table((StringEnumAbstractBase[])new Enum[] { new Enum("type", 1), new Enum("document-type", 2), new Enum("accessor-element", 3), new Enum("accessor-attribute", 4) });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object readResolve() {
/*  82 */       return forInt(intValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static Qnametargetenum newValue(Object obj) {
/*  93 */       return (Qnametargetenum)Qnametargetenum.type.newValue(obj);
/*     */     }
/*     */     public static Qnametargetenum newInstance() {
/*  96 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().newInstance(Qnametargetenum.type, null);
/*     */     }
/*     */     public static Qnametargetenum newInstance(XmlOptions options) {
/*  99 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().newInstance(Qnametargetenum.type, options);
/*     */     }
/*     */     
/*     */     public static Qnametargetenum parse(String xmlAsString) throws XmlException {
/* 103 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(xmlAsString, Qnametargetenum.type, null);
/*     */     }
/*     */     public static Qnametargetenum parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 106 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(xmlAsString, Qnametargetenum.type, options);
/*     */     }
/*     */     
/*     */     public static Qnametargetenum parse(File file) throws XmlException, IOException {
/* 110 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(file, Qnametargetenum.type, null);
/*     */     }
/*     */     public static Qnametargetenum parse(File file, XmlOptions options) throws XmlException, IOException {
/* 113 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(file, Qnametargetenum.type, options);
/*     */     }
/*     */     public static Qnametargetenum parse(URL u) throws XmlException, IOException {
/* 116 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(u, Qnametargetenum.type, null);
/*     */     }
/*     */     public static Qnametargetenum parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 119 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(u, Qnametargetenum.type, options);
/*     */     }
/*     */     public static Qnametargetenum parse(InputStream is) throws XmlException, IOException {
/* 122 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(is, Qnametargetenum.type, null);
/*     */     }
/*     */     public static Qnametargetenum parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 125 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(is, Qnametargetenum.type, options);
/*     */     }
/*     */     public static Qnametargetenum parse(Reader r) throws XmlException, IOException {
/* 128 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(r, Qnametargetenum.type, null);
/*     */     }
/*     */     public static Qnametargetenum parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 131 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(r, Qnametargetenum.type, options);
/*     */     }
/*     */     public static Qnametargetenum parse(XMLStreamReader sr) throws XmlException {
/* 134 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(sr, Qnametargetenum.type, null);
/*     */     }
/*     */     public static Qnametargetenum parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 137 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(sr, Qnametargetenum.type, options);
/*     */     }
/*     */     public static Qnametargetenum parse(Node node) throws XmlException {
/* 140 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(node, Qnametargetenum.type, null);
/*     */     }
/*     */     public static Qnametargetenum parse(Node node, XmlOptions options) throws XmlException {
/* 143 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(node, Qnametargetenum.type, options);
/*     */     }
/*     */     
/*     */     public static Qnametargetenum parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 147 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(xis, Qnametargetenum.type, null);
/*     */     }
/*     */     
/*     */     public static Qnametargetenum parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 151 */       return (Qnametargetenum)XmlBeans.getContextTypeLoader().parse(xis, Qnametargetenum.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 155 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Qnametargetenum.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 159 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, Qnametargetenum.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\Qnametargetenum.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */