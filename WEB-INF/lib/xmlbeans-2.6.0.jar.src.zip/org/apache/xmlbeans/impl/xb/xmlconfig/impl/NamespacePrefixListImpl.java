/*    */ package org.apache.xmlbeans.impl.xb.xmlconfig.impl;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.impl.values.XmlListImpl;
/*    */ import org.apache.xmlbeans.impl.xb.xmlconfig.NamespacePrefixList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamespacePrefixListImpl
/*    */   extends XmlListImpl
/*    */   implements NamespacePrefixList
/*    */ {
/*    */   public NamespacePrefixListImpl(SchemaType sType) {
/* 19 */     super(sType, false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected NamespacePrefixListImpl(SchemaType sType, boolean b) {
/* 24 */     super(sType, b);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\impl\NamespacePrefixListImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */