/*      */ package org.apache.xmlbeans.impl.xb.xsdschema.impl;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.SimpleValue;
/*      */ import org.apache.xmlbeans.XmlBoolean;
/*      */ import org.apache.xmlbeans.XmlNonNegativeInteger;
/*      */ import org.apache.xmlbeans.XmlObject;
/*      */ import org.apache.xmlbeans.XmlQName;
/*      */ import org.apache.xmlbeans.XmlString;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.AllNNI;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.DerivationSet;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.FormChoice;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.Keybase;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.KeyrefDocument;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalComplexType;
/*      */ import org.apache.xmlbeans.impl.xb.xsdschema.LocalSimpleType;
/*      */ 
/*      */ public class ElementImpl extends AnnotatedImpl implements Element {
/*      */   public ElementImpl(SchemaType sType) {
/*   19 */     super(sType);
/*      */   }
/*      */   
/*   22 */   private static final QName SIMPLETYPE$0 = new QName("http://www.w3.org/2001/XMLSchema", "simpleType");
/*      */   
/*   24 */   private static final QName COMPLEXTYPE$2 = new QName("http://www.w3.org/2001/XMLSchema", "complexType");
/*      */   
/*   26 */   private static final QName UNIQUE$4 = new QName("http://www.w3.org/2001/XMLSchema", "unique");
/*      */   
/*   28 */   private static final QName KEY$6 = new QName("http://www.w3.org/2001/XMLSchema", "key");
/*      */   
/*   30 */   private static final QName KEYREF$8 = new QName("http://www.w3.org/2001/XMLSchema", "keyref");
/*      */   
/*   32 */   private static final QName NAME$10 = new QName("", "name");
/*      */   
/*   34 */   private static final QName REF$12 = new QName("", "ref");
/*      */   
/*   36 */   private static final QName TYPE$14 = new QName("", "type");
/*      */   
/*   38 */   private static final QName SUBSTITUTIONGROUP$16 = new QName("", "substitutionGroup");
/*      */   
/*   40 */   private static final QName MINOCCURS$18 = new QName("", "minOccurs");
/*      */   
/*   42 */   private static final QName MAXOCCURS$20 = new QName("", "maxOccurs");
/*      */   
/*   44 */   private static final QName DEFAULT$22 = new QName("", "default");
/*      */   
/*   46 */   private static final QName FIXED$24 = new QName("", "fixed");
/*      */   
/*   48 */   private static final QName NILLABLE$26 = new QName("", "nillable");
/*      */   
/*   50 */   private static final QName ABSTRACT$28 = new QName("", "abstract");
/*      */   
/*   52 */   private static final QName FINAL$30 = new QName("", "final");
/*      */   
/*   54 */   private static final QName BLOCK$32 = new QName("", "block");
/*      */   
/*   56 */   private static final QName FORM$34 = new QName("", "form");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalSimpleType getSimpleType() {
/*   65 */     synchronized (monitor()) {
/*      */       
/*   67 */       check_orphaned();
/*   68 */       LocalSimpleType target = null;
/*   69 */       target = (LocalSimpleType)get_store().find_element_user(SIMPLETYPE$0, 0);
/*   70 */       if (target == null)
/*      */       {
/*   72 */         return null;
/*      */       }
/*   74 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetSimpleType() {
/*   83 */     synchronized (monitor()) {
/*      */       
/*   85 */       check_orphaned();
/*   86 */       return (get_store().count_elements(SIMPLETYPE$0) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSimpleType(LocalSimpleType simpleType) {
/*   95 */     synchronized (monitor()) {
/*      */       
/*   97 */       check_orphaned();
/*   98 */       LocalSimpleType target = null;
/*   99 */       target = (LocalSimpleType)get_store().find_element_user(SIMPLETYPE$0, 0);
/*  100 */       if (target == null)
/*      */       {
/*  102 */         target = (LocalSimpleType)get_store().add_element_user(SIMPLETYPE$0);
/*      */       }
/*  104 */       target.set((XmlObject)simpleType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalSimpleType addNewSimpleType() {
/*  113 */     synchronized (monitor()) {
/*      */       
/*  115 */       check_orphaned();
/*  116 */       LocalSimpleType target = null;
/*  117 */       target = (LocalSimpleType)get_store().add_element_user(SIMPLETYPE$0);
/*  118 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetSimpleType() {
/*  127 */     synchronized (monitor()) {
/*      */       
/*  129 */       check_orphaned();
/*  130 */       get_store().remove_element(SIMPLETYPE$0, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalComplexType getComplexType() {
/*  139 */     synchronized (monitor()) {
/*      */       
/*  141 */       check_orphaned();
/*  142 */       LocalComplexType target = null;
/*  143 */       target = (LocalComplexType)get_store().find_element_user(COMPLEXTYPE$2, 0);
/*  144 */       if (target == null)
/*      */       {
/*  146 */         return null;
/*      */       }
/*  148 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetComplexType() {
/*  157 */     synchronized (monitor()) {
/*      */       
/*  159 */       check_orphaned();
/*  160 */       return (get_store().count_elements(COMPLEXTYPE$2) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComplexType(LocalComplexType complexType) {
/*  169 */     synchronized (monitor()) {
/*      */       
/*  171 */       check_orphaned();
/*  172 */       LocalComplexType target = null;
/*  173 */       target = (LocalComplexType)get_store().find_element_user(COMPLEXTYPE$2, 0);
/*  174 */       if (target == null)
/*      */       {
/*  176 */         target = (LocalComplexType)get_store().add_element_user(COMPLEXTYPE$2);
/*      */       }
/*  178 */       target.set((XmlObject)complexType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalComplexType addNewComplexType() {
/*  187 */     synchronized (monitor()) {
/*      */       
/*  189 */       check_orphaned();
/*  190 */       LocalComplexType target = null;
/*  191 */       target = (LocalComplexType)get_store().add_element_user(COMPLEXTYPE$2);
/*  192 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetComplexType() {
/*  201 */     synchronized (monitor()) {
/*      */       
/*  203 */       check_orphaned();
/*  204 */       get_store().remove_element(COMPLEXTYPE$2, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Keybase[] getUniqueArray() {
/*  213 */     synchronized (monitor()) {
/*      */       
/*  215 */       check_orphaned();
/*  216 */       List targetList = new ArrayList();
/*  217 */       get_store().find_all_element_users(UNIQUE$4, targetList);
/*  218 */       Keybase[] result = new Keybase[targetList.size()];
/*  219 */       targetList.toArray((Object[])result);
/*  220 */       return result;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Keybase getUniqueArray(int i) {
/*  229 */     synchronized (monitor()) {
/*      */       
/*  231 */       check_orphaned();
/*  232 */       Keybase target = null;
/*  233 */       target = (Keybase)get_store().find_element_user(UNIQUE$4, i);
/*  234 */       if (target == null)
/*      */       {
/*  236 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  238 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sizeOfUniqueArray() {
/*  247 */     synchronized (monitor()) {
/*      */       
/*  249 */       check_orphaned();
/*  250 */       return get_store().count_elements(UNIQUE$4);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUniqueArray(Keybase[] uniqueArray) {
/*  259 */     synchronized (monitor()) {
/*      */       
/*  261 */       check_orphaned();
/*  262 */       arraySetterHelper((XmlObject[])uniqueArray, UNIQUE$4);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUniqueArray(int i, Keybase unique) {
/*  271 */     synchronized (monitor()) {
/*      */       
/*  273 */       check_orphaned();
/*  274 */       Keybase target = null;
/*  275 */       target = (Keybase)get_store().find_element_user(UNIQUE$4, i);
/*  276 */       if (target == null)
/*      */       {
/*  278 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  280 */       target.set((XmlObject)unique);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Keybase insertNewUnique(int i) {
/*  289 */     synchronized (monitor()) {
/*      */       
/*  291 */       check_orphaned();
/*  292 */       Keybase target = null;
/*  293 */       target = (Keybase)get_store().insert_element_user(UNIQUE$4, i);
/*  294 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Keybase addNewUnique() {
/*  303 */     synchronized (monitor()) {
/*      */       
/*  305 */       check_orphaned();
/*  306 */       Keybase target = null;
/*  307 */       target = (Keybase)get_store().add_element_user(UNIQUE$4);
/*  308 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeUnique(int i) {
/*  317 */     synchronized (monitor()) {
/*      */       
/*  319 */       check_orphaned();
/*  320 */       get_store().remove_element(UNIQUE$4, i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Keybase[] getKeyArray() {
/*  329 */     synchronized (monitor()) {
/*      */       
/*  331 */       check_orphaned();
/*  332 */       List targetList = new ArrayList();
/*  333 */       get_store().find_all_element_users(KEY$6, targetList);
/*  334 */       Keybase[] result = new Keybase[targetList.size()];
/*  335 */       targetList.toArray((Object[])result);
/*  336 */       return result;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Keybase getKeyArray(int i) {
/*  345 */     synchronized (monitor()) {
/*      */       
/*  347 */       check_orphaned();
/*  348 */       Keybase target = null;
/*  349 */       target = (Keybase)get_store().find_element_user(KEY$6, i);
/*  350 */       if (target == null)
/*      */       {
/*  352 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  354 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sizeOfKeyArray() {
/*  363 */     synchronized (monitor()) {
/*      */       
/*  365 */       check_orphaned();
/*  366 */       return get_store().count_elements(KEY$6);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyArray(Keybase[] keyArray) {
/*  375 */     synchronized (monitor()) {
/*      */       
/*  377 */       check_orphaned();
/*  378 */       arraySetterHelper((XmlObject[])keyArray, KEY$6);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyArray(int i, Keybase key) {
/*  387 */     synchronized (monitor()) {
/*      */       
/*  389 */       check_orphaned();
/*  390 */       Keybase target = null;
/*  391 */       target = (Keybase)get_store().find_element_user(KEY$6, i);
/*  392 */       if (target == null)
/*      */       {
/*  394 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  396 */       target.set((XmlObject)key);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Keybase insertNewKey(int i) {
/*  405 */     synchronized (monitor()) {
/*      */       
/*  407 */       check_orphaned();
/*  408 */       Keybase target = null;
/*  409 */       target = (Keybase)get_store().insert_element_user(KEY$6, i);
/*  410 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Keybase addNewKey() {
/*  419 */     synchronized (monitor()) {
/*      */       
/*  421 */       check_orphaned();
/*  422 */       Keybase target = null;
/*  423 */       target = (Keybase)get_store().add_element_user(KEY$6);
/*  424 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeKey(int i) {
/*  433 */     synchronized (monitor()) {
/*      */       
/*  435 */       check_orphaned();
/*  436 */       get_store().remove_element(KEY$6, i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public KeyrefDocument.Keyref[] getKeyrefArray() {
/*  445 */     synchronized (monitor()) {
/*      */       
/*  447 */       check_orphaned();
/*  448 */       List targetList = new ArrayList();
/*  449 */       get_store().find_all_element_users(KEYREF$8, targetList);
/*  450 */       KeyrefDocument.Keyref[] result = new KeyrefDocument.Keyref[targetList.size()];
/*  451 */       targetList.toArray((Object[])result);
/*  452 */       return result;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public KeyrefDocument.Keyref getKeyrefArray(int i) {
/*  461 */     synchronized (monitor()) {
/*      */       
/*  463 */       check_orphaned();
/*  464 */       KeyrefDocument.Keyref target = null;
/*  465 */       target = (KeyrefDocument.Keyref)get_store().find_element_user(KEYREF$8, i);
/*  466 */       if (target == null)
/*      */       {
/*  468 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  470 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sizeOfKeyrefArray() {
/*  479 */     synchronized (monitor()) {
/*      */       
/*  481 */       check_orphaned();
/*  482 */       return get_store().count_elements(KEYREF$8);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyrefArray(KeyrefDocument.Keyref[] keyrefArray) {
/*  491 */     synchronized (monitor()) {
/*      */       
/*  493 */       check_orphaned();
/*  494 */       arraySetterHelper((XmlObject[])keyrefArray, KEYREF$8);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyrefArray(int i, KeyrefDocument.Keyref keyref) {
/*  503 */     synchronized (monitor()) {
/*      */       
/*  505 */       check_orphaned();
/*  506 */       KeyrefDocument.Keyref target = null;
/*  507 */       target = (KeyrefDocument.Keyref)get_store().find_element_user(KEYREF$8, i);
/*  508 */       if (target == null)
/*      */       {
/*  510 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  512 */       target.set((XmlObject)keyref);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public KeyrefDocument.Keyref insertNewKeyref(int i) {
/*  521 */     synchronized (monitor()) {
/*      */       
/*  523 */       check_orphaned();
/*  524 */       KeyrefDocument.Keyref target = null;
/*  525 */       target = (KeyrefDocument.Keyref)get_store().insert_element_user(KEYREF$8, i);
/*  526 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public KeyrefDocument.Keyref addNewKeyref() {
/*  535 */     synchronized (monitor()) {
/*      */       
/*  537 */       check_orphaned();
/*  538 */       KeyrefDocument.Keyref target = null;
/*  539 */       target = (KeyrefDocument.Keyref)get_store().add_element_user(KEYREF$8);
/*  540 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeKeyref(int i) {
/*  549 */     synchronized (monitor()) {
/*      */       
/*  551 */       check_orphaned();
/*  552 */       get_store().remove_element(KEYREF$8, i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  561 */     synchronized (monitor()) {
/*      */       
/*  563 */       check_orphaned();
/*  564 */       SimpleValue target = null;
/*  565 */       target = (SimpleValue)get_store().find_attribute_user(NAME$10);
/*  566 */       if (target == null)
/*      */       {
/*  568 */         return null;
/*      */       }
/*  570 */       return target.getStringValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlNCName xgetName() {
/*  579 */     synchronized (monitor()) {
/*      */       
/*  581 */       check_orphaned();
/*  582 */       XmlNCName target = null;
/*  583 */       target = (XmlNCName)get_store().find_attribute_user(NAME$10);
/*  584 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetName() {
/*  593 */     synchronized (monitor()) {
/*      */       
/*  595 */       check_orphaned();
/*  596 */       return (get_store().find_attribute_user(NAME$10) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String name) {
/*  605 */     synchronized (monitor()) {
/*      */       
/*  607 */       check_orphaned();
/*  608 */       SimpleValue target = null;
/*  609 */       target = (SimpleValue)get_store().find_attribute_user(NAME$10);
/*  610 */       if (target == null)
/*      */       {
/*  612 */         target = (SimpleValue)get_store().add_attribute_user(NAME$10);
/*      */       }
/*  614 */       target.setStringValue(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetName(XmlNCName name) {
/*  623 */     synchronized (monitor()) {
/*      */       
/*  625 */       check_orphaned();
/*  626 */       XmlNCName target = null;
/*  627 */       target = (XmlNCName)get_store().find_attribute_user(NAME$10);
/*  628 */       if (target == null)
/*      */       {
/*  630 */         target = (XmlNCName)get_store().add_attribute_user(NAME$10);
/*      */       }
/*  632 */       target.set((XmlObject)name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetName() {
/*  641 */     synchronized (monitor()) {
/*      */       
/*  643 */       check_orphaned();
/*  644 */       get_store().remove_attribute(NAME$10);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QName getRef() {
/*  653 */     synchronized (monitor()) {
/*      */       
/*  655 */       check_orphaned();
/*  656 */       SimpleValue target = null;
/*  657 */       target = (SimpleValue)get_store().find_attribute_user(REF$12);
/*  658 */       if (target == null)
/*      */       {
/*  660 */         return null;
/*      */       }
/*  662 */       return target.getQNameValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlQName xgetRef() {
/*  671 */     synchronized (monitor()) {
/*      */       
/*  673 */       check_orphaned();
/*  674 */       XmlQName target = null;
/*  675 */       target = (XmlQName)get_store().find_attribute_user(REF$12);
/*  676 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetRef() {
/*  685 */     synchronized (monitor()) {
/*      */       
/*  687 */       check_orphaned();
/*  688 */       return (get_store().find_attribute_user(REF$12) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(QName ref) {
/*  697 */     synchronized (monitor()) {
/*      */       
/*  699 */       check_orphaned();
/*  700 */       SimpleValue target = null;
/*  701 */       target = (SimpleValue)get_store().find_attribute_user(REF$12);
/*  702 */       if (target == null)
/*      */       {
/*  704 */         target = (SimpleValue)get_store().add_attribute_user(REF$12);
/*      */       }
/*  706 */       target.setQNameValue(ref);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetRef(XmlQName ref) {
/*  715 */     synchronized (monitor()) {
/*      */       
/*  717 */       check_orphaned();
/*  718 */       XmlQName target = null;
/*  719 */       target = (XmlQName)get_store().find_attribute_user(REF$12);
/*  720 */       if (target == null)
/*      */       {
/*  722 */         target = (XmlQName)get_store().add_attribute_user(REF$12);
/*      */       }
/*  724 */       target.set((XmlObject)ref);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetRef() {
/*  733 */     synchronized (monitor()) {
/*      */       
/*  735 */       check_orphaned();
/*  736 */       get_store().remove_attribute(REF$12);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QName getType() {
/*  745 */     synchronized (monitor()) {
/*      */       
/*  747 */       check_orphaned();
/*  748 */       SimpleValue target = null;
/*  749 */       target = (SimpleValue)get_store().find_attribute_user(TYPE$14);
/*  750 */       if (target == null)
/*      */       {
/*  752 */         return null;
/*      */       }
/*  754 */       return target.getQNameValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlQName xgetType() {
/*  763 */     synchronized (monitor()) {
/*      */       
/*  765 */       check_orphaned();
/*  766 */       XmlQName target = null;
/*  767 */       target = (XmlQName)get_store().find_attribute_user(TYPE$14);
/*  768 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetType() {
/*  777 */     synchronized (monitor()) {
/*      */       
/*  779 */       check_orphaned();
/*  780 */       return (get_store().find_attribute_user(TYPE$14) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setType(QName type) {
/*  789 */     synchronized (monitor()) {
/*      */       
/*  791 */       check_orphaned();
/*  792 */       SimpleValue target = null;
/*  793 */       target = (SimpleValue)get_store().find_attribute_user(TYPE$14);
/*  794 */       if (target == null)
/*      */       {
/*  796 */         target = (SimpleValue)get_store().add_attribute_user(TYPE$14);
/*      */       }
/*  798 */       target.setQNameValue(type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetType(XmlQName type) {
/*  807 */     synchronized (monitor()) {
/*      */       
/*  809 */       check_orphaned();
/*  810 */       XmlQName target = null;
/*  811 */       target = (XmlQName)get_store().find_attribute_user(TYPE$14);
/*  812 */       if (target == null)
/*      */       {
/*  814 */         target = (XmlQName)get_store().add_attribute_user(TYPE$14);
/*      */       }
/*  816 */       target.set((XmlObject)type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetType() {
/*  825 */     synchronized (monitor()) {
/*      */       
/*  827 */       check_orphaned();
/*  828 */       get_store().remove_attribute(TYPE$14);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QName getSubstitutionGroup() {
/*  837 */     synchronized (monitor()) {
/*      */       
/*  839 */       check_orphaned();
/*  840 */       SimpleValue target = null;
/*  841 */       target = (SimpleValue)get_store().find_attribute_user(SUBSTITUTIONGROUP$16);
/*  842 */       if (target == null)
/*      */       {
/*  844 */         return null;
/*      */       }
/*  846 */       return target.getQNameValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlQName xgetSubstitutionGroup() {
/*  855 */     synchronized (monitor()) {
/*      */       
/*  857 */       check_orphaned();
/*  858 */       XmlQName target = null;
/*  859 */       target = (XmlQName)get_store().find_attribute_user(SUBSTITUTIONGROUP$16);
/*  860 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetSubstitutionGroup() {
/*  869 */     synchronized (monitor()) {
/*      */       
/*  871 */       check_orphaned();
/*  872 */       return (get_store().find_attribute_user(SUBSTITUTIONGROUP$16) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubstitutionGroup(QName substitutionGroup) {
/*  881 */     synchronized (monitor()) {
/*      */       
/*  883 */       check_orphaned();
/*  884 */       SimpleValue target = null;
/*  885 */       target = (SimpleValue)get_store().find_attribute_user(SUBSTITUTIONGROUP$16);
/*  886 */       if (target == null)
/*      */       {
/*  888 */         target = (SimpleValue)get_store().add_attribute_user(SUBSTITUTIONGROUP$16);
/*      */       }
/*  890 */       target.setQNameValue(substitutionGroup);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetSubstitutionGroup(XmlQName substitutionGroup) {
/*  899 */     synchronized (monitor()) {
/*      */       
/*  901 */       check_orphaned();
/*  902 */       XmlQName target = null;
/*  903 */       target = (XmlQName)get_store().find_attribute_user(SUBSTITUTIONGROUP$16);
/*  904 */       if (target == null)
/*      */       {
/*  906 */         target = (XmlQName)get_store().add_attribute_user(SUBSTITUTIONGROUP$16);
/*      */       }
/*  908 */       target.set((XmlObject)substitutionGroup);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetSubstitutionGroup() {
/*  917 */     synchronized (monitor()) {
/*      */       
/*  919 */       check_orphaned();
/*  920 */       get_store().remove_attribute(SUBSTITUTIONGROUP$16);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getMinOccurs() {
/*  929 */     synchronized (monitor()) {
/*      */       
/*  931 */       check_orphaned();
/*  932 */       SimpleValue target = null;
/*  933 */       target = (SimpleValue)get_store().find_attribute_user(MINOCCURS$18);
/*  934 */       if (target == null)
/*      */       {
/*  936 */         target = (SimpleValue)get_default_attribute_value(MINOCCURS$18);
/*      */       }
/*  938 */       if (target == null)
/*      */       {
/*  940 */         return null;
/*      */       }
/*  942 */       return target.getBigIntegerValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlNonNegativeInteger xgetMinOccurs() {
/*  951 */     synchronized (monitor()) {
/*      */       
/*  953 */       check_orphaned();
/*  954 */       XmlNonNegativeInteger target = null;
/*  955 */       target = (XmlNonNegativeInteger)get_store().find_attribute_user(MINOCCURS$18);
/*  956 */       if (target == null)
/*      */       {
/*  958 */         target = (XmlNonNegativeInteger)get_default_attribute_value(MINOCCURS$18);
/*      */       }
/*  960 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetMinOccurs() {
/*  969 */     synchronized (monitor()) {
/*      */       
/*  971 */       check_orphaned();
/*  972 */       return (get_store().find_attribute_user(MINOCCURS$18) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMinOccurs(BigInteger minOccurs) {
/*  981 */     synchronized (monitor()) {
/*      */       
/*  983 */       check_orphaned();
/*  984 */       SimpleValue target = null;
/*  985 */       target = (SimpleValue)get_store().find_attribute_user(MINOCCURS$18);
/*  986 */       if (target == null)
/*      */       {
/*  988 */         target = (SimpleValue)get_store().add_attribute_user(MINOCCURS$18);
/*      */       }
/*  990 */       target.setBigIntegerValue(minOccurs);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetMinOccurs(XmlNonNegativeInteger minOccurs) {
/*  999 */     synchronized (monitor()) {
/*      */       
/* 1001 */       check_orphaned();
/* 1002 */       XmlNonNegativeInteger target = null;
/* 1003 */       target = (XmlNonNegativeInteger)get_store().find_attribute_user(MINOCCURS$18);
/* 1004 */       if (target == null)
/*      */       {
/* 1006 */         target = (XmlNonNegativeInteger)get_store().add_attribute_user(MINOCCURS$18);
/*      */       }
/* 1008 */       target.set((XmlObject)minOccurs);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetMinOccurs() {
/* 1017 */     synchronized (monitor()) {
/*      */       
/* 1019 */       check_orphaned();
/* 1020 */       get_store().remove_attribute(MINOCCURS$18);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getMaxOccurs() {
/* 1029 */     synchronized (monitor()) {
/*      */       
/* 1031 */       check_orphaned();
/* 1032 */       SimpleValue target = null;
/* 1033 */       target = (SimpleValue)get_store().find_attribute_user(MAXOCCURS$20);
/* 1034 */       if (target == null)
/*      */       {
/* 1036 */         target = (SimpleValue)get_default_attribute_value(MAXOCCURS$20);
/*      */       }
/* 1038 */       if (target == null)
/*      */       {
/* 1040 */         return null;
/*      */       }
/* 1042 */       return target.getObjectValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AllNNI xgetMaxOccurs() {
/* 1051 */     synchronized (monitor()) {
/*      */       
/* 1053 */       check_orphaned();
/* 1054 */       AllNNI target = null;
/* 1055 */       target = (AllNNI)get_store().find_attribute_user(MAXOCCURS$20);
/* 1056 */       if (target == null)
/*      */       {
/* 1058 */         target = (AllNNI)get_default_attribute_value(MAXOCCURS$20);
/*      */       }
/* 1060 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetMaxOccurs() {
/* 1069 */     synchronized (monitor()) {
/*      */       
/* 1071 */       check_orphaned();
/* 1072 */       return (get_store().find_attribute_user(MAXOCCURS$20) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxOccurs(Object maxOccurs) {
/* 1081 */     synchronized (monitor()) {
/*      */       
/* 1083 */       check_orphaned();
/* 1084 */       SimpleValue target = null;
/* 1085 */       target = (SimpleValue)get_store().find_attribute_user(MAXOCCURS$20);
/* 1086 */       if (target == null)
/*      */       {
/* 1088 */         target = (SimpleValue)get_store().add_attribute_user(MAXOCCURS$20);
/*      */       }
/* 1090 */       target.setObjectValue(maxOccurs);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetMaxOccurs(AllNNI maxOccurs) {
/* 1099 */     synchronized (monitor()) {
/*      */       
/* 1101 */       check_orphaned();
/* 1102 */       AllNNI target = null;
/* 1103 */       target = (AllNNI)get_store().find_attribute_user(MAXOCCURS$20);
/* 1104 */       if (target == null)
/*      */       {
/* 1106 */         target = (AllNNI)get_store().add_attribute_user(MAXOCCURS$20);
/*      */       }
/* 1108 */       target.set((XmlObject)maxOccurs);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetMaxOccurs() {
/* 1117 */     synchronized (monitor()) {
/*      */       
/* 1119 */       check_orphaned();
/* 1120 */       get_store().remove_attribute(MAXOCCURS$20);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDefault() {
/* 1129 */     synchronized (monitor()) {
/*      */       
/* 1131 */       check_orphaned();
/* 1132 */       SimpleValue target = null;
/* 1133 */       target = (SimpleValue)get_store().find_attribute_user(DEFAULT$22);
/* 1134 */       if (target == null)
/*      */       {
/* 1136 */         return null;
/*      */       }
/* 1138 */       return target.getStringValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlString xgetDefault() {
/* 1147 */     synchronized (monitor()) {
/*      */       
/* 1149 */       check_orphaned();
/* 1150 */       XmlString target = null;
/* 1151 */       target = (XmlString)get_store().find_attribute_user(DEFAULT$22);
/* 1152 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetDefault() {
/* 1161 */     synchronized (monitor()) {
/*      */       
/* 1163 */       check_orphaned();
/* 1164 */       return (get_store().find_attribute_user(DEFAULT$22) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefault(String xdefault) {
/* 1173 */     synchronized (monitor()) {
/*      */       
/* 1175 */       check_orphaned();
/* 1176 */       SimpleValue target = null;
/* 1177 */       target = (SimpleValue)get_store().find_attribute_user(DEFAULT$22);
/* 1178 */       if (target == null)
/*      */       {
/* 1180 */         target = (SimpleValue)get_store().add_attribute_user(DEFAULT$22);
/*      */       }
/* 1182 */       target.setStringValue(xdefault);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetDefault(XmlString xdefault) {
/* 1191 */     synchronized (monitor()) {
/*      */       
/* 1193 */       check_orphaned();
/* 1194 */       XmlString target = null;
/* 1195 */       target = (XmlString)get_store().find_attribute_user(DEFAULT$22);
/* 1196 */       if (target == null)
/*      */       {
/* 1198 */         target = (XmlString)get_store().add_attribute_user(DEFAULT$22);
/*      */       }
/* 1200 */       target.set((XmlObject)xdefault);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetDefault() {
/* 1209 */     synchronized (monitor()) {
/*      */       
/* 1211 */       check_orphaned();
/* 1212 */       get_store().remove_attribute(DEFAULT$22);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFixed() {
/* 1221 */     synchronized (monitor()) {
/*      */       
/* 1223 */       check_orphaned();
/* 1224 */       SimpleValue target = null;
/* 1225 */       target = (SimpleValue)get_store().find_attribute_user(FIXED$24);
/* 1226 */       if (target == null)
/*      */       {
/* 1228 */         return null;
/*      */       }
/* 1230 */       return target.getStringValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlString xgetFixed() {
/* 1239 */     synchronized (monitor()) {
/*      */       
/* 1241 */       check_orphaned();
/* 1242 */       XmlString target = null;
/* 1243 */       target = (XmlString)get_store().find_attribute_user(FIXED$24);
/* 1244 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetFixed() {
/* 1253 */     synchronized (monitor()) {
/*      */       
/* 1255 */       check_orphaned();
/* 1256 */       return (get_store().find_attribute_user(FIXED$24) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixed(String fixed) {
/* 1265 */     synchronized (monitor()) {
/*      */       
/* 1267 */       check_orphaned();
/* 1268 */       SimpleValue target = null;
/* 1269 */       target = (SimpleValue)get_store().find_attribute_user(FIXED$24);
/* 1270 */       if (target == null)
/*      */       {
/* 1272 */         target = (SimpleValue)get_store().add_attribute_user(FIXED$24);
/*      */       }
/* 1274 */       target.setStringValue(fixed);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetFixed(XmlString fixed) {
/* 1283 */     synchronized (monitor()) {
/*      */       
/* 1285 */       check_orphaned();
/* 1286 */       XmlString target = null;
/* 1287 */       target = (XmlString)get_store().find_attribute_user(FIXED$24);
/* 1288 */       if (target == null)
/*      */       {
/* 1290 */         target = (XmlString)get_store().add_attribute_user(FIXED$24);
/*      */       }
/* 1292 */       target.set((XmlObject)fixed);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetFixed() {
/* 1301 */     synchronized (monitor()) {
/*      */       
/* 1303 */       check_orphaned();
/* 1304 */       get_store().remove_attribute(FIXED$24);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getNillable() {
/* 1313 */     synchronized (monitor()) {
/*      */       
/* 1315 */       check_orphaned();
/* 1316 */       SimpleValue target = null;
/* 1317 */       target = (SimpleValue)get_store().find_attribute_user(NILLABLE$26);
/* 1318 */       if (target == null)
/*      */       {
/* 1320 */         target = (SimpleValue)get_default_attribute_value(NILLABLE$26);
/*      */       }
/* 1322 */       if (target == null)
/*      */       {
/* 1324 */         return false;
/*      */       }
/* 1326 */       return target.getBooleanValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlBoolean xgetNillable() {
/* 1335 */     synchronized (monitor()) {
/*      */       
/* 1337 */       check_orphaned();
/* 1338 */       XmlBoolean target = null;
/* 1339 */       target = (XmlBoolean)get_store().find_attribute_user(NILLABLE$26);
/* 1340 */       if (target == null)
/*      */       {
/* 1342 */         target = (XmlBoolean)get_default_attribute_value(NILLABLE$26);
/*      */       }
/* 1344 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetNillable() {
/* 1353 */     synchronized (monitor()) {
/*      */       
/* 1355 */       check_orphaned();
/* 1356 */       return (get_store().find_attribute_user(NILLABLE$26) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNillable(boolean nillable) {
/* 1365 */     synchronized (monitor()) {
/*      */       
/* 1367 */       check_orphaned();
/* 1368 */       SimpleValue target = null;
/* 1369 */       target = (SimpleValue)get_store().find_attribute_user(NILLABLE$26);
/* 1370 */       if (target == null)
/*      */       {
/* 1372 */         target = (SimpleValue)get_store().add_attribute_user(NILLABLE$26);
/*      */       }
/* 1374 */       target.setBooleanValue(nillable);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetNillable(XmlBoolean nillable) {
/* 1383 */     synchronized (monitor()) {
/*      */       
/* 1385 */       check_orphaned();
/* 1386 */       XmlBoolean target = null;
/* 1387 */       target = (XmlBoolean)get_store().find_attribute_user(NILLABLE$26);
/* 1388 */       if (target == null)
/*      */       {
/* 1390 */         target = (XmlBoolean)get_store().add_attribute_user(NILLABLE$26);
/*      */       }
/* 1392 */       target.set((XmlObject)nillable);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetNillable() {
/* 1401 */     synchronized (monitor()) {
/*      */       
/* 1403 */       check_orphaned();
/* 1404 */       get_store().remove_attribute(NILLABLE$26);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAbstract() {
/* 1413 */     synchronized (monitor()) {
/*      */       
/* 1415 */       check_orphaned();
/* 1416 */       SimpleValue target = null;
/* 1417 */       target = (SimpleValue)get_store().find_attribute_user(ABSTRACT$28);
/* 1418 */       if (target == null)
/*      */       {
/* 1420 */         target = (SimpleValue)get_default_attribute_value(ABSTRACT$28);
/*      */       }
/* 1422 */       if (target == null)
/*      */       {
/* 1424 */         return false;
/*      */       }
/* 1426 */       return target.getBooleanValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlBoolean xgetAbstract() {
/* 1435 */     synchronized (monitor()) {
/*      */       
/* 1437 */       check_orphaned();
/* 1438 */       XmlBoolean target = null;
/* 1439 */       target = (XmlBoolean)get_store().find_attribute_user(ABSTRACT$28);
/* 1440 */       if (target == null)
/*      */       {
/* 1442 */         target = (XmlBoolean)get_default_attribute_value(ABSTRACT$28);
/*      */       }
/* 1444 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetAbstract() {
/* 1453 */     synchronized (monitor()) {
/*      */       
/* 1455 */       check_orphaned();
/* 1456 */       return (get_store().find_attribute_user(ABSTRACT$28) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAbstract(boolean xabstract) {
/* 1465 */     synchronized (monitor()) {
/*      */       
/* 1467 */       check_orphaned();
/* 1468 */       SimpleValue target = null;
/* 1469 */       target = (SimpleValue)get_store().find_attribute_user(ABSTRACT$28);
/* 1470 */       if (target == null)
/*      */       {
/* 1472 */         target = (SimpleValue)get_store().add_attribute_user(ABSTRACT$28);
/*      */       }
/* 1474 */       target.setBooleanValue(xabstract);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetAbstract(XmlBoolean xabstract) {
/* 1483 */     synchronized (monitor()) {
/*      */       
/* 1485 */       check_orphaned();
/* 1486 */       XmlBoolean target = null;
/* 1487 */       target = (XmlBoolean)get_store().find_attribute_user(ABSTRACT$28);
/* 1488 */       if (target == null)
/*      */       {
/* 1490 */         target = (XmlBoolean)get_store().add_attribute_user(ABSTRACT$28);
/*      */       }
/* 1492 */       target.set((XmlObject)xabstract);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetAbstract() {
/* 1501 */     synchronized (monitor()) {
/*      */       
/* 1503 */       check_orphaned();
/* 1504 */       get_store().remove_attribute(ABSTRACT$28);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getFinal() {
/* 1513 */     synchronized (monitor()) {
/*      */       
/* 1515 */       check_orphaned();
/* 1516 */       SimpleValue target = null;
/* 1517 */       target = (SimpleValue)get_store().find_attribute_user(FINAL$30);
/* 1518 */       if (target == null)
/*      */       {
/* 1520 */         return null;
/*      */       }
/* 1522 */       return target.getObjectValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DerivationSet xgetFinal() {
/* 1531 */     synchronized (monitor()) {
/*      */       
/* 1533 */       check_orphaned();
/* 1534 */       DerivationSet target = null;
/* 1535 */       target = (DerivationSet)get_store().find_attribute_user(FINAL$30);
/* 1536 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetFinal() {
/* 1545 */     synchronized (monitor()) {
/*      */       
/* 1547 */       check_orphaned();
/* 1548 */       return (get_store().find_attribute_user(FINAL$30) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFinal(Object xfinal) {
/* 1557 */     synchronized (monitor()) {
/*      */       
/* 1559 */       check_orphaned();
/* 1560 */       SimpleValue target = null;
/* 1561 */       target = (SimpleValue)get_store().find_attribute_user(FINAL$30);
/* 1562 */       if (target == null)
/*      */       {
/* 1564 */         target = (SimpleValue)get_store().add_attribute_user(FINAL$30);
/*      */       }
/* 1566 */       target.setObjectValue(xfinal);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetFinal(DerivationSet xfinal) {
/* 1575 */     synchronized (monitor()) {
/*      */       
/* 1577 */       check_orphaned();
/* 1578 */       DerivationSet target = null;
/* 1579 */       target = (DerivationSet)get_store().find_attribute_user(FINAL$30);
/* 1580 */       if (target == null)
/*      */       {
/* 1582 */         target = (DerivationSet)get_store().add_attribute_user(FINAL$30);
/*      */       }
/* 1584 */       target.set((XmlObject)xfinal);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetFinal() {
/* 1593 */     synchronized (monitor()) {
/*      */       
/* 1595 */       check_orphaned();
/* 1596 */       get_store().remove_attribute(FINAL$30);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getBlock() {
/* 1605 */     synchronized (monitor()) {
/*      */       
/* 1607 */       check_orphaned();
/* 1608 */       SimpleValue target = null;
/* 1609 */       target = (SimpleValue)get_store().find_attribute_user(BLOCK$32);
/* 1610 */       if (target == null)
/*      */       {
/* 1612 */         return null;
/*      */       }
/* 1614 */       return target.getObjectValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BlockSet xgetBlock() {
/* 1623 */     synchronized (monitor()) {
/*      */       
/* 1625 */       check_orphaned();
/* 1626 */       BlockSet target = null;
/* 1627 */       target = (BlockSet)get_store().find_attribute_user(BLOCK$32);
/* 1628 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetBlock() {
/* 1637 */     synchronized (monitor()) {
/*      */       
/* 1639 */       check_orphaned();
/* 1640 */       return (get_store().find_attribute_user(BLOCK$32) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlock(Object block) {
/* 1649 */     synchronized (monitor()) {
/*      */       
/* 1651 */       check_orphaned();
/* 1652 */       SimpleValue target = null;
/* 1653 */       target = (SimpleValue)get_store().find_attribute_user(BLOCK$32);
/* 1654 */       if (target == null)
/*      */       {
/* 1656 */         target = (SimpleValue)get_store().add_attribute_user(BLOCK$32);
/*      */       }
/* 1658 */       target.setObjectValue(block);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetBlock(BlockSet block) {
/* 1667 */     synchronized (monitor()) {
/*      */       
/* 1669 */       check_orphaned();
/* 1670 */       BlockSet target = null;
/* 1671 */       target = (BlockSet)get_store().find_attribute_user(BLOCK$32);
/* 1672 */       if (target == null)
/*      */       {
/* 1674 */         target = (BlockSet)get_store().add_attribute_user(BLOCK$32);
/*      */       }
/* 1676 */       target.set((XmlObject)block);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetBlock() {
/* 1685 */     synchronized (monitor()) {
/*      */       
/* 1687 */       check_orphaned();
/* 1688 */       get_store().remove_attribute(BLOCK$32);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FormChoice.Enum getForm() {
/* 1697 */     synchronized (monitor()) {
/*      */       
/* 1699 */       check_orphaned();
/* 1700 */       SimpleValue target = null;
/* 1701 */       target = (SimpleValue)get_store().find_attribute_user(FORM$34);
/* 1702 */       if (target == null)
/*      */       {
/* 1704 */         return null;
/*      */       }
/* 1706 */       return (FormChoice.Enum)target.getEnumValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FormChoice xgetForm() {
/* 1715 */     synchronized (monitor()) {
/*      */       
/* 1717 */       check_orphaned();
/* 1718 */       FormChoice target = null;
/* 1719 */       target = (FormChoice)get_store().find_attribute_user(FORM$34);
/* 1720 */       return target;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSetForm() {
/* 1729 */     synchronized (monitor()) {
/*      */       
/* 1731 */       check_orphaned();
/* 1732 */       return (get_store().find_attribute_user(FORM$34) != null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setForm(FormChoice.Enum form) {
/* 1741 */     synchronized (monitor()) {
/*      */       
/* 1743 */       check_orphaned();
/* 1744 */       SimpleValue target = null;
/* 1745 */       target = (SimpleValue)get_store().find_attribute_user(FORM$34);
/* 1746 */       if (target == null)
/*      */       {
/* 1748 */         target = (SimpleValue)get_store().add_attribute_user(FORM$34);
/*      */       }
/* 1750 */       target.setEnumValue((StringEnumAbstractBase)form);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void xsetForm(FormChoice form) {
/* 1759 */     synchronized (monitor()) {
/*      */       
/* 1761 */       check_orphaned();
/* 1762 */       FormChoice target = null;
/* 1763 */       target = (FormChoice)get_store().find_attribute_user(FORM$34);
/* 1764 */       if (target == null)
/*      */       {
/* 1766 */         target = (FormChoice)get_store().add_attribute_user(FORM$34);
/*      */       }
/* 1768 */       target.set((XmlObject)form);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetForm() {
/* 1777 */     synchronized (monitor()) {
/*      */       
/* 1779 */       check_orphaned();
/* 1780 */       get_store().remove_attribute(FORM$34);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdschema\impl\ElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */