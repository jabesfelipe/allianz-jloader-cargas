/*     */ package org.apache.xmlbeans.impl.xb.ltgfmt.impl;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.ltgfmt.Code;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements Code
/*     */ {
/*     */   public CodeImpl(SchemaType sType) {
/*  19 */     super(sType);
/*     */   }
/*     */   
/*  22 */   private static final QName ID$0 = new QName("", "ID");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getID() {
/*  31 */     synchronized (monitor()) {
/*     */       
/*  33 */       check_orphaned();
/*  34 */       SimpleValue target = null;
/*  35 */       target = (SimpleValue)get_store().find_attribute_user(ID$0);
/*  36 */       if (target == null)
/*     */       {
/*  38 */         return null;
/*     */       }
/*  40 */       return target.getStringValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlToken xgetID() {
/*  49 */     synchronized (monitor()) {
/*     */       
/*  51 */       check_orphaned();
/*  52 */       XmlToken target = null;
/*  53 */       target = (XmlToken)get_store().find_attribute_user(ID$0);
/*  54 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetID() {
/*  63 */     synchronized (monitor()) {
/*     */       
/*  65 */       check_orphaned();
/*  66 */       return (get_store().find_attribute_user(ID$0) != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setID(String id) {
/*  75 */     synchronized (monitor()) {
/*     */       
/*  77 */       check_orphaned();
/*  78 */       SimpleValue target = null;
/*  79 */       target = (SimpleValue)get_store().find_attribute_user(ID$0);
/*  80 */       if (target == null)
/*     */       {
/*  82 */         target = (SimpleValue)get_store().add_attribute_user(ID$0);
/*     */       }
/*  84 */       target.setStringValue(id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xsetID(XmlToken id) {
/*  93 */     synchronized (monitor()) {
/*     */       
/*  95 */       check_orphaned();
/*  96 */       XmlToken target = null;
/*  97 */       target = (XmlToken)get_store().find_attribute_user(ID$0);
/*  98 */       if (target == null)
/*     */       {
/* 100 */         target = (XmlToken)get_store().add_attribute_user(ID$0);
/*     */       }
/* 102 */       target.set((XmlObject)id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetID() {
/* 111 */     synchronized (monitor()) {
/*     */       
/* 113 */       check_orphaned();
/* 114 */       get_store().remove_attribute(ID$0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\ltgfmt\impl\CodeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */