/*     */ package org.apache.xmlbeans.impl.xb.xsdownload.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
/*     */ import org.apache.xmlbeans.impl.xb.xsdownload.DownloadedSchemaEntry;
/*     */ import org.apache.xmlbeans.impl.xb.xsdownload.DownloadedSchemasDocument;
/*     */ 
/*     */ 
/*     */ public class DownloadedSchemasDocumentImpl
/*     */   extends XmlComplexContentImpl
/*     */   implements DownloadedSchemasDocument
/*     */ {
/*     */   public DownloadedSchemasDocumentImpl(SchemaType sType) {
/*  20 */     super(sType);
/*     */   }
/*     */   
/*  23 */   private static final QName DOWNLOADEDSCHEMAS$0 = new QName("http://www.bea.com/2003/01/xmlbean/xsdownload", "downloaded-schemas");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DownloadedSchemasDocument.DownloadedSchemas getDownloadedSchemas() {
/*  32 */     synchronized (monitor()) {
/*     */       
/*  34 */       check_orphaned();
/*  35 */       DownloadedSchemasDocument.DownloadedSchemas target = null;
/*  36 */       target = (DownloadedSchemasDocument.DownloadedSchemas)get_store().find_element_user(DOWNLOADEDSCHEMAS$0, 0);
/*  37 */       if (target == null)
/*     */       {
/*  39 */         return null;
/*     */       }
/*  41 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDownloadedSchemas(DownloadedSchemasDocument.DownloadedSchemas downloadedSchemas) {
/*  50 */     synchronized (monitor()) {
/*     */       
/*  52 */       check_orphaned();
/*  53 */       DownloadedSchemasDocument.DownloadedSchemas target = null;
/*  54 */       target = (DownloadedSchemasDocument.DownloadedSchemas)get_store().find_element_user(DOWNLOADEDSCHEMAS$0, 0);
/*  55 */       if (target == null)
/*     */       {
/*  57 */         target = (DownloadedSchemasDocument.DownloadedSchemas)get_store().add_element_user(DOWNLOADEDSCHEMAS$0);
/*     */       }
/*  59 */       target.set((XmlObject)downloadedSchemas);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DownloadedSchemasDocument.DownloadedSchemas addNewDownloadedSchemas() {
/*  68 */     synchronized (monitor()) {
/*     */       
/*  70 */       check_orphaned();
/*  71 */       DownloadedSchemasDocument.DownloadedSchemas target = null;
/*  72 */       target = (DownloadedSchemasDocument.DownloadedSchemas)get_store().add_element_user(DOWNLOADEDSCHEMAS$0);
/*  73 */       return target;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DownloadedSchemasImpl
/*     */     extends XmlComplexContentImpl
/*     */     implements DownloadedSchemasDocument.DownloadedSchemas
/*     */   {
/*     */     public DownloadedSchemasImpl(SchemaType sType) {
/*  86 */       super(sType);
/*     */     }
/*     */     
/*  89 */     private static final QName ENTRY$0 = new QName("http://www.bea.com/2003/01/xmlbean/xsdownload", "entry");
/*     */     
/*  91 */     private static final QName DEFAULTDIRECTORY$2 = new QName("", "defaultDirectory");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DownloadedSchemaEntry[] getEntryArray() {
/* 100 */       synchronized (monitor()) {
/*     */         
/* 102 */         check_orphaned();
/* 103 */         List targetList = new ArrayList();
/* 104 */         get_store().find_all_element_users(ENTRY$0, targetList);
/* 105 */         DownloadedSchemaEntry[] result = new DownloadedSchemaEntry[targetList.size()];
/* 106 */         targetList.toArray((Object[])result);
/* 107 */         return result;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DownloadedSchemaEntry getEntryArray(int i) {
/* 116 */       synchronized (monitor()) {
/*     */         
/* 118 */         check_orphaned();
/* 119 */         DownloadedSchemaEntry target = null;
/* 120 */         target = (DownloadedSchemaEntry)get_store().find_element_user(ENTRY$0, i);
/* 121 */         if (target == null)
/*     */         {
/* 123 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 125 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int sizeOfEntryArray() {
/* 134 */       synchronized (monitor()) {
/*     */         
/* 136 */         check_orphaned();
/* 137 */         return get_store().count_elements(ENTRY$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setEntryArray(DownloadedSchemaEntry[] entryArray) {
/* 146 */       synchronized (monitor()) {
/*     */         
/* 148 */         check_orphaned();
/* 149 */         arraySetterHelper((XmlObject[])entryArray, ENTRY$0);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setEntryArray(int i, DownloadedSchemaEntry entry) {
/* 158 */       synchronized (monitor()) {
/*     */         
/* 160 */         check_orphaned();
/* 161 */         DownloadedSchemaEntry target = null;
/* 162 */         target = (DownloadedSchemaEntry)get_store().find_element_user(ENTRY$0, i);
/* 163 */         if (target == null)
/*     */         {
/* 165 */           throw new IndexOutOfBoundsException();
/*     */         }
/* 167 */         target.set((XmlObject)entry);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DownloadedSchemaEntry insertNewEntry(int i) {
/* 176 */       synchronized (monitor()) {
/*     */         
/* 178 */         check_orphaned();
/* 179 */         DownloadedSchemaEntry target = null;
/* 180 */         target = (DownloadedSchemaEntry)get_store().insert_element_user(ENTRY$0, i);
/* 181 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DownloadedSchemaEntry addNewEntry() {
/* 190 */       synchronized (monitor()) {
/*     */         
/* 192 */         check_orphaned();
/* 193 */         DownloadedSchemaEntry target = null;
/* 194 */         target = (DownloadedSchemaEntry)get_store().add_element_user(ENTRY$0);
/* 195 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeEntry(int i) {
/* 204 */       synchronized (monitor()) {
/*     */         
/* 206 */         check_orphaned();
/* 207 */         get_store().remove_element(ENTRY$0, i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDefaultDirectory() {
/* 216 */       synchronized (monitor()) {
/*     */         
/* 218 */         check_orphaned();
/* 219 */         SimpleValue target = null;
/* 220 */         target = (SimpleValue)get_store().find_attribute_user(DEFAULTDIRECTORY$2);
/* 221 */         if (target == null)
/*     */         {
/* 223 */           return null;
/*     */         }
/* 225 */         return target.getStringValue();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public XmlToken xgetDefaultDirectory() {
/* 234 */       synchronized (monitor()) {
/*     */         
/* 236 */         check_orphaned();
/* 237 */         XmlToken target = null;
/* 238 */         target = (XmlToken)get_store().find_attribute_user(DEFAULTDIRECTORY$2);
/* 239 */         return target;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSetDefaultDirectory() {
/* 248 */       synchronized (monitor()) {
/*     */         
/* 250 */         check_orphaned();
/* 251 */         return (get_store().find_attribute_user(DEFAULTDIRECTORY$2) != null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setDefaultDirectory(String defaultDirectory) {
/* 260 */       synchronized (monitor()) {
/*     */         
/* 262 */         check_orphaned();
/* 263 */         SimpleValue target = null;
/* 264 */         target = (SimpleValue)get_store().find_attribute_user(DEFAULTDIRECTORY$2);
/* 265 */         if (target == null)
/*     */         {
/* 267 */           target = (SimpleValue)get_store().add_attribute_user(DEFAULTDIRECTORY$2);
/*     */         }
/* 269 */         target.setStringValue(defaultDirectory);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void xsetDefaultDirectory(XmlToken defaultDirectory) {
/* 278 */       synchronized (monitor()) {
/*     */         
/* 280 */         check_orphaned();
/* 281 */         XmlToken target = null;
/* 282 */         target = (XmlToken)get_store().find_attribute_user(DEFAULTDIRECTORY$2);
/* 283 */         if (target == null)
/*     */         {
/* 285 */           target = (XmlToken)get_store().add_attribute_user(DEFAULTDIRECTORY$2);
/*     */         }
/* 287 */         target.set((XmlObject)defaultDirectory);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void unsetDefaultDirectory() {
/* 296 */       synchronized (monitor()) {
/*     */         
/* 298 */         check_orphaned();
/* 299 */         get_store().remove_attribute(DEFAULTDIRECTORY$2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdownload\impl\DownloadedSchemasDocumentImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */