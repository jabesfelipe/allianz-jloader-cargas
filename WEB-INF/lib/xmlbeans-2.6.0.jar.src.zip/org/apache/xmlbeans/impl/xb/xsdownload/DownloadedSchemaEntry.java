/*     */ package org.apache.xmlbeans.impl.xb.xsdownload;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.XmlAnyURI;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface DownloadedSchemaEntry extends XmlObject {
/*  18 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemaEntry == null) ? (null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemaEntry = null.class$("org.apache.xmlbeans.impl.xb.xsdownload.DownloadedSchemaEntry")) : null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemaEntry).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("downloadedschemaentry1c75type");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getFilename();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlToken xgetFilename();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFilename(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetFilename(XmlToken paramXmlToken);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getSha1();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlToken xgetSha1();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSha1(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetSha1(XmlToken paramXmlToken);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] getSchemaLocationArray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getSchemaLocationArray(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlAnyURI[] xgetSchemaLocationArray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlAnyURI xgetSchemaLocationArray(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int sizeOfSchemaLocationArray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSchemaLocationArray(String[] paramArrayOfString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSchemaLocationArray(int paramInt, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetSchemaLocationArray(XmlAnyURI[] paramArrayOfXmlAnyURI);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetSchemaLocationArray(int paramInt, XmlAnyURI paramXmlAnyURI);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void insertSchemaLocation(int paramInt, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addSchemaLocation(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlAnyURI insertNewSchemaLocation(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlAnyURI addNewSchemaLocation();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeSchemaLocation(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getNamespace();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XmlAnyURI xgetNamespace();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSetNamespace();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setNamespace(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void xsetNamespace(XmlAnyURI paramXmlAnyURI);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsetNamespace();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static DownloadedSchemaEntry newInstance() {
/* 169 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().newInstance(DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     public static DownloadedSchemaEntry newInstance(XmlOptions options) {
/* 172 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().newInstance(DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     
/*     */     public static DownloadedSchemaEntry parse(String xmlAsString) throws XmlException {
/* 176 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(xmlAsString, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 179 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(xmlAsString, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     
/*     */     public static DownloadedSchemaEntry parse(File file) throws XmlException, IOException {
/* 183 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(file, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(File file, XmlOptions options) throws XmlException, IOException {
/* 186 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(file, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(URL u) throws XmlException, IOException {
/* 189 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(u, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 192 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(u, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(InputStream is) throws XmlException, IOException {
/* 195 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(is, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 198 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(is, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(Reader r) throws XmlException, IOException {
/* 201 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(r, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 204 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(r, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(XMLStreamReader sr) throws XmlException {
/* 207 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(sr, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 210 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(sr, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(Node node) throws XmlException {
/* 213 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(node, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     public static DownloadedSchemaEntry parse(Node node, XmlOptions options) throws XmlException {
/* 216 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(node, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     
/*     */     public static DownloadedSchemaEntry parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 220 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(xis, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     
/*     */     public static DownloadedSchemaEntry parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 224 */       return (DownloadedSchemaEntry)XmlBeans.getContextTypeLoader().parse(xis, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 228 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, DownloadedSchemaEntry.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 232 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, DownloadedSchemaEntry.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdownload\DownloadedSchemaEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */