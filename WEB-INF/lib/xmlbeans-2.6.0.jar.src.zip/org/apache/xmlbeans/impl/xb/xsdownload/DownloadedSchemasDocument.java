/*     */ package org.apache.xmlbeans.impl.xb.xsdownload;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public interface DownloadedSchemasDocument extends XmlObject {
/*  19 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemasDocument == null) ? (null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemasDocument = null.class$("org.apache.xmlbeans.impl.xb.xsdownload.DownloadedSchemasDocument")) : null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemasDocument).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("downloadedschemas2dd7doctype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DownloadedSchemas getDownloadedSchemas();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDownloadedSchemas(DownloadedSchemas paramDownloadedSchemas);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DownloadedSchemas addNewDownloadedSchemas();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface DownloadedSchemas
/*     */     extends XmlObject
/*     */   {
/*  44 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((DownloadedSchemasDocument.null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemasDocument$DownloadedSchemas == null) ? (DownloadedSchemasDocument.null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemasDocument$DownloadedSchemas = DownloadedSchemasDocument.null.class$("org.apache.xmlbeans.impl.xb.xsdownload.DownloadedSchemasDocument$DownloadedSchemas")) : DownloadedSchemasDocument.null.class$org$apache$xmlbeans$impl$xb$xsdownload$DownloadedSchemasDocument$DownloadedSchemas).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLTOOLS").resolveHandle("downloadedschemasb3efelemtype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DownloadedSchemaEntry[] getEntryArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DownloadedSchemaEntry getEntryArray(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int sizeOfEntryArray();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setEntryArray(DownloadedSchemaEntry[] param1ArrayOfDownloadedSchemaEntry);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setEntryArray(int param1Int, DownloadedSchemaEntry param1DownloadedSchemaEntry);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DownloadedSchemaEntry insertNewEntry(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DownloadedSchemaEntry addNewEntry();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeEntry(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getDefaultDirectory();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     XmlToken xgetDefaultDirectory();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isSetDefaultDirectory();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void setDefaultDirectory(String param1String);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void xsetDefaultDirectory(XmlToken param1XmlToken);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void unsetDefaultDirectory();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static DownloadedSchemasDocument.DownloadedSchemas newInstance() {
/* 125 */         return (DownloadedSchemasDocument.DownloadedSchemas)XmlBeans.getContextTypeLoader().newInstance(DownloadedSchemasDocument.DownloadedSchemas.type, null);
/*     */       }
/*     */       public static DownloadedSchemasDocument.DownloadedSchemas newInstance(XmlOptions options) {
/* 128 */         return (DownloadedSchemasDocument.DownloadedSchemas)XmlBeans.getContextTypeLoader().newInstance(DownloadedSchemasDocument.DownloadedSchemas.type, options);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static DownloadedSchemasDocument newInstance() {
/* 142 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().newInstance(DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     public static DownloadedSchemasDocument newInstance(XmlOptions options) {
/* 145 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().newInstance(DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     
/*     */     public static DownloadedSchemasDocument parse(String xmlAsString) throws XmlException {
/* 149 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(xmlAsString, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 152 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(xmlAsString, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     
/*     */     public static DownloadedSchemasDocument parse(File file) throws XmlException, IOException {
/* 156 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(file, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(File file, XmlOptions options) throws XmlException, IOException {
/* 159 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(file, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(URL u) throws XmlException, IOException {
/* 162 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(u, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 165 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(u, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(InputStream is) throws XmlException, IOException {
/* 168 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(is, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 171 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(is, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(Reader r) throws XmlException, IOException {
/* 174 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(r, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 177 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(r, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(XMLStreamReader sr) throws XmlException {
/* 180 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(sr, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 183 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(sr, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(Node node) throws XmlException {
/* 186 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(node, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     public static DownloadedSchemasDocument parse(Node node, XmlOptions options) throws XmlException {
/* 189 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(node, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     
/*     */     public static DownloadedSchemasDocument parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 193 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(xis, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     
/*     */     public static DownloadedSchemasDocument parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 197 */       return (DownloadedSchemasDocument)XmlBeans.getContextTypeLoader().parse(xis, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 201 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, DownloadedSchemasDocument.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 205 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, DownloadedSchemasDocument.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xsdownload\DownloadedSchemasDocument.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */