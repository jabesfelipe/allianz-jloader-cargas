/*     */ package org.apache.xmlbeans.impl.xb.xmlconfig;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlBeans;
/*     */ import org.apache.xmlbeans.XmlException;
/*     */ import org.apache.xmlbeans.XmlOptions;
/*     */ import org.apache.xmlbeans.XmlToken;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ public interface JavaNameList
/*     */   extends XmlAnySimpleType
/*     */ {
/*     */   Object getObjectValue();
/*     */   
/*  27 */   public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList == null) ? (null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList = null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.JavaNameList")) : null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("javanamelistbcfetype");
/*     */   
/*     */   void setObjectValue(Object paramObject);
/*     */   
/*     */   Object objectValue();
/*     */   
/*     */   void objectSet(Object paramObject);
/*     */   
/*     */   SchemaType instanceType();
/*     */   
/*  37 */   public static interface Member extends XmlToken { public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((JavaNameList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList$Member == null) ? (JavaNameList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList$Member = JavaNameList.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.JavaNameList$Member")) : JavaNameList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList$Member).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("anon3e39type");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     public static final Enum X = Enum.forString("*");
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int INT_X = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     StringEnumAbstractBase enumValue();
/*     */ 
/*     */ 
/*     */     
/*     */     void set(StringEnumAbstractBase param1StringEnumAbstractBase);
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Enum
/*     */       extends StringEnumAbstractBase
/*     */     {
/*     */       static final int INT_X = 1;
/*     */ 
/*     */ 
/*     */       
/*     */       public static Enum forString(String s) {
/*  68 */         return (Enum)table.forString(s);
/*     */       }
/*     */ 
/*     */       
/*     */       public static Enum forInt(int i) {
/*  73 */         return (Enum)table.forInt(i);
/*     */       }
/*     */       private Enum(String s, int i) {
/*  76 */         super(s, i);
/*     */       }
/*     */ 
/*     */       
/*  80 */       public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table((StringEnumAbstractBase[])new Enum[] { new Enum("*", 1) });
/*     */ 
/*     */ 
/*     */       
/*     */       private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */       
/*     */       private Object readResolve() {
/*  89 */         return forInt(intValue());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static JavaNameList.Member newValue(Object obj) {
/* 100 */         return (JavaNameList.Member)JavaNameList.Member.type.newValue(obj);
/*     */       }
/*     */       public static JavaNameList.Member newInstance() {
/* 103 */         return (JavaNameList.Member)XmlBeans.getContextTypeLoader().newInstance(JavaNameList.Member.type, null);
/*     */       }
/*     */       public static JavaNameList.Member newInstance(XmlOptions options) {
/* 106 */         return (JavaNameList.Member)XmlBeans.getContextTypeLoader().newInstance(JavaNameList.Member.type, options);
/*     */       }
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Member2
/*     */     extends XmlAnySimpleType
/*     */   {
/*     */     List getListValue();
/*     */ 
/*     */ 
/*     */     
/*     */     List xgetListValue();
/*     */ 
/*     */ 
/*     */     
/*     */     void setListValue(List param1List);
/*     */ 
/*     */ 
/*     */     
/* 128 */     public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(((JavaNameList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList$Member2 == null) ? (JavaNameList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList$Member2 = JavaNameList.null.class$("org.apache.xmlbeans.impl.xb.xmlconfig.JavaNameList$Member2")) : JavaNameList.null.class$org$apache$xmlbeans$impl$xb$xmlconfig$JavaNameList$Member2).getClassLoader(), "schemaorg_apache_xmlbeans.system.sXMLCONFIG").resolveHandle("anon3a98type");
/*     */     
/*     */     List listValue();
/*     */     
/*     */     List xlistValue();
/*     */     
/*     */     void set(List param1List);
/*     */     
/*     */     public static final class Factory
/*     */     {
/*     */       public static JavaNameList.Member2 newValue(Object obj) {
/* 139 */         return (JavaNameList.Member2)JavaNameList.Member2.type.newValue(obj);
/*     */       }
/*     */       public static JavaNameList.Member2 newInstance() {
/* 142 */         return (JavaNameList.Member2)XmlBeans.getContextTypeLoader().newInstance(JavaNameList.Member2.type, null);
/*     */       }
/*     */       public static JavaNameList.Member2 newInstance(XmlOptions options) {
/* 145 */         return (JavaNameList.Member2)XmlBeans.getContextTypeLoader().newInstance(JavaNameList.Member2.type, options);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Factory
/*     */   {
/*     */     public static JavaNameList newValue(Object obj) {
/* 159 */       return (JavaNameList)JavaNameList.type.newValue(obj);
/*     */     }
/*     */     public static JavaNameList newInstance() {
/* 162 */       return (JavaNameList)XmlBeans.getContextTypeLoader().newInstance(JavaNameList.type, null);
/*     */     }
/*     */     public static JavaNameList newInstance(XmlOptions options) {
/* 165 */       return (JavaNameList)XmlBeans.getContextTypeLoader().newInstance(JavaNameList.type, options);
/*     */     }
/*     */     
/*     */     public static JavaNameList parse(String xmlAsString) throws XmlException {
/* 169 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(xmlAsString, JavaNameList.type, null);
/*     */     }
/*     */     public static JavaNameList parse(String xmlAsString, XmlOptions options) throws XmlException {
/* 172 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(xmlAsString, JavaNameList.type, options);
/*     */     }
/*     */     
/*     */     public static JavaNameList parse(File file) throws XmlException, IOException {
/* 176 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(file, JavaNameList.type, null);
/*     */     }
/*     */     public static JavaNameList parse(File file, XmlOptions options) throws XmlException, IOException {
/* 179 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(file, JavaNameList.type, options);
/*     */     }
/*     */     public static JavaNameList parse(URL u) throws XmlException, IOException {
/* 182 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(u, JavaNameList.type, null);
/*     */     }
/*     */     public static JavaNameList parse(URL u, XmlOptions options) throws XmlException, IOException {
/* 185 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(u, JavaNameList.type, options);
/*     */     }
/*     */     public static JavaNameList parse(InputStream is) throws XmlException, IOException {
/* 188 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(is, JavaNameList.type, null);
/*     */     }
/*     */     public static JavaNameList parse(InputStream is, XmlOptions options) throws XmlException, IOException {
/* 191 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(is, JavaNameList.type, options);
/*     */     }
/*     */     public static JavaNameList parse(Reader r) throws XmlException, IOException {
/* 194 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(r, JavaNameList.type, null);
/*     */     }
/*     */     public static JavaNameList parse(Reader r, XmlOptions options) throws XmlException, IOException {
/* 197 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(r, JavaNameList.type, options);
/*     */     }
/*     */     public static JavaNameList parse(XMLStreamReader sr) throws XmlException {
/* 200 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(sr, JavaNameList.type, null);
/*     */     }
/*     */     public static JavaNameList parse(XMLStreamReader sr, XmlOptions options) throws XmlException {
/* 203 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(sr, JavaNameList.type, options);
/*     */     }
/*     */     public static JavaNameList parse(Node node) throws XmlException {
/* 206 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(node, JavaNameList.type, null);
/*     */     }
/*     */     public static JavaNameList parse(Node node, XmlOptions options) throws XmlException {
/* 209 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(node, JavaNameList.type, options);
/*     */     }
/*     */     
/*     */     public static JavaNameList parse(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 213 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(xis, JavaNameList.type, null);
/*     */     }
/*     */     
/*     */     public static JavaNameList parse(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 217 */       return (JavaNameList)XmlBeans.getContextTypeLoader().parse(xis, JavaNameList.type, options);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis) throws XmlException, XMLStreamException {
/* 221 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, JavaNameList.type, null);
/*     */     }
/*     */     
/*     */     public static XMLInputStream newValidatingXMLInputStream(XMLInputStream xis, XmlOptions options) throws XmlException, XMLStreamException {
/* 225 */       return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(xis, JavaNameList.type, options);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\xb\xmlconfig\JavaNameList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */