/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.apache.xmlbeans.GDate;
/*     */ import org.apache.xmlbeans.GDateBuilder;
/*     */ import org.apache.xmlbeans.GDateSpecification;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaGDateHolderEx
/*     */   extends XmlObjectBase
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   private GDate _value;
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   public JavaGDateHolderEx(SchemaType type, boolean complex) {
/*  34 */     this._schemaType = type;
/*  35 */     initComplexType(complex, false);
/*     */   }
/*     */   
/*     */   public SchemaType schemaType() {
/*  39 */     return this._schemaType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  48 */     return (this._value == null) ? "" : this._value.toString();
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*     */     GDate newVal;
/*  53 */     if (_validateOnSet()) {
/*  54 */       newVal = validateLexical(s, this._schemaType, _voorVc);
/*     */     } else {
/*  56 */       newVal = lex(s, this._schemaType, _voorVc);
/*     */     } 
/*  58 */     if (_validateOnSet() && newVal != null) {
/*  59 */       validateValue((GDateSpecification)newVal, this._schemaType, _voorVc);
/*     */     }
/*  61 */     this._value = newVal;
/*     */   }
/*     */ 
/*     */   
/*     */   public static GDate lex(String v, SchemaType sType, ValidationContext context) {
/*  66 */     GDate date = null;
/*     */ 
/*     */     
/*     */     try {
/*  70 */       date = new GDate(v);
/*     */     }
/*  72 */     catch (Exception e) {
/*     */       
/*  74 */       context.invalid("date", new Object[] { v });
/*     */     } 
/*     */     
/*  77 */     if (date != null)
/*     */     {
/*  79 */       if (date.getBuiltinTypeCode() != sType.getPrimitiveType().getBuiltinTypeCode()) {
/*     */         
/*  81 */         context.invalid("date", new Object[] { "wrong type: " + v });
/*  82 */         date = null;
/*     */       }
/*  84 */       else if (!date.isValid()) {
/*     */         
/*  86 */         context.invalid("date", new Object[] { v });
/*  87 */         date = null;
/*     */       } 
/*     */     }
/*     */     
/*  91 */     return date;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static GDate validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  97 */     GDate date = lex(v, sType, context);
/*     */     
/*  99 */     if (date != null && sType.hasPatternFacet() && 
/* 100 */       !sType.matchPatternFacet(v)) {
/* 101 */       context.invalid("cvc-datatype-valid.1.1", new Object[] { "date", v, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 104 */     return date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateValue(GDateSpecification v, SchemaType sType, ValidationContext context) {
/* 112 */     if (v.getBuiltinTypeCode() != sType.getPrimitiveType().getBuiltinTypeCode())
/* 113 */       context.invalid("date", new Object[] { "Date (" + v + ") does not have the set of fields required for " + QNameHelper.readable(sType) });  XmlAnySimpleType xmlAnySimpleType;
/*     */     GDate g;
/* 115 */     if ((xmlAnySimpleType = sType.getFacet(3)) != null && 
/* 116 */       v.compareToGDate((GDateSpecification)(g = ((XmlObjectBase)xmlAnySimpleType).gDateValue())) <= 0) {
/* 117 */       context.invalid("cvc-minExclusive-valid", new Object[] { "date", v, g, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 120 */     if ((xmlAnySimpleType = sType.getFacet(4)) != null && 
/* 121 */       v.compareToGDate((GDateSpecification)(g = ((XmlObjectBase)xmlAnySimpleType).gDateValue())) < 0) {
/* 122 */       context.invalid("cvc-minInclusive-valid", new Object[] { "date", v, g, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 125 */     if ((xmlAnySimpleType = sType.getFacet(6)) != null && 
/* 126 */       v.compareToGDate((GDateSpecification)(g = ((XmlObjectBase)xmlAnySimpleType).gDateValue())) >= 0) {
/* 127 */       context.invalid("cvc-maxExclusive-valid", new Object[] { "date", v, g, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 130 */     if ((xmlAnySimpleType = sType.getFacet(5)) != null && 
/* 131 */       v.compareToGDate((GDateSpecification)(g = ((XmlObjectBase)xmlAnySimpleType).gDateValue())) > 0) {
/* 132 */       context.invalid("cvc-maxInclusive-valid", new Object[] { "date", v, g, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 135 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 136 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 138 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/* 139 */         if (v.compareToGDate((GDateSpecification)((XmlObjectBase)arrayOfXmlAnySimpleType[i]).gDateValue()) == 0)
/*     */           return; 
/* 141 */       }  context.invalid("cvc-enumeration-valid", new Object[] { "date", v, QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_nil() {
/* 148 */     this._value = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntValue() {
/* 154 */     int code = schemaType().getPrimitiveType().getBuiltinTypeCode();
/*     */     
/* 156 */     if (code != 20 && code != 21 && code != 18)
/*     */     {
/*     */       
/* 159 */       throw new XmlValueOutOfRangeException();
/*     */     }
/* 161 */     check_dated();
/*     */     
/* 163 */     if (this._value == null) {
/* 164 */       return 0;
/*     */     }
/* 166 */     switch (code) {
/*     */       
/*     */       case 20:
/* 169 */         return this._value.getDay();
/*     */       case 21:
/* 171 */         return this._value.getMonth();
/*     */       case 18:
/* 173 */         return this._value.getYear();
/*     */     } 
/*     */     assert false;
/* 176 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GDate getGDateValue() {
/* 182 */     check_dated();
/*     */     
/* 184 */     if (this._value == null) {
/* 185 */       return null;
/*     */     }
/* 187 */     return this._value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Calendar getCalendarValue() {
/* 192 */     check_dated();
/*     */     
/* 194 */     if (this._value == null) {
/* 195 */       return null;
/*     */     }
/* 197 */     return (Calendar)this._value.getCalendar();
/*     */   }
/*     */ 
/*     */   
/*     */   public Date getDateValue() {
/* 202 */     check_dated();
/*     */     
/* 204 */     if (this._value == null) {
/* 205 */       return null;
/*     */     }
/* 207 */     return this._value.getDate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_int(int v) {
/* 213 */     int code = schemaType().getPrimitiveType().getBuiltinTypeCode();
/*     */     
/* 215 */     if (code != 20 && code != 21 && code != 18)
/*     */     {
/*     */       
/* 218 */       throw new XmlValueOutOfRangeException();
/*     */     }
/* 220 */     GDateBuilder value = new GDateBuilder();
/*     */     
/* 222 */     switch (code) {
/*     */       
/*     */       case 20:
/* 225 */         value.setDay(v); break;
/*     */       case 21:
/* 227 */         value.setMonth(v); break;
/*     */       case 18:
/* 229 */         value.setYear(v);
/*     */         break;
/*     */     } 
/* 232 */     if (_validateOnSet()) {
/* 233 */       validateValue((GDateSpecification)value, this._schemaType, _voorVc);
/*     */     }
/* 235 */     this._value = value.toGDate();
/*     */   }
/*     */   
/*     */   protected void set_GDate(GDateSpecification v) {
/*     */     GDate candidate;
/* 240 */     int code = schemaType().getPrimitiveType().getBuiltinTypeCode();
/*     */ 
/*     */ 
/*     */     
/* 244 */     if (v.isImmutable() && v instanceof GDate && v.getBuiltinTypeCode() == code) {
/* 245 */       candidate = (GDate)v;
/*     */     } else {
/*     */       GDateBuilder gDateBuilder;
/*     */       
/* 249 */       if (v.getBuiltinTypeCode() != code) {
/*     */         
/* 251 */         GDateBuilder gDateBuilder1 = new GDateBuilder(v);
/* 252 */         gDateBuilder1.setBuiltinTypeCode(code);
/* 253 */         gDateBuilder = gDateBuilder1;
/*     */       } 
/* 255 */       candidate = new GDate((GDateSpecification)gDateBuilder);
/*     */     } 
/*     */     
/* 258 */     if (_validateOnSet()) {
/* 259 */       validateValue((GDateSpecification)candidate, this._schemaType, _voorVc);
/*     */     }
/* 261 */     this._value = candidate;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_Calendar(Calendar c) {
/* 266 */     int code = schemaType().getPrimitiveType().getBuiltinTypeCode();
/*     */     
/* 268 */     GDateBuilder gDateBuilder = new GDateBuilder(c);
/* 269 */     gDateBuilder.setBuiltinTypeCode(code);
/* 270 */     GDate value = gDateBuilder.toGDate();
/*     */     
/* 272 */     if (_validateOnSet()) {
/* 273 */       validateValue((GDateSpecification)value, this._schemaType, _voorVc);
/*     */     }
/* 275 */     this._value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_Date(Date v) {
/* 280 */     int code = schemaType().getPrimitiveType().getBuiltinTypeCode();
/*     */     
/* 282 */     if ((code != 16 && code != 14) || v == null)
/*     */     {
/* 284 */       throw new XmlValueOutOfRangeException();
/*     */     }
/* 286 */     GDateBuilder gDateBuilder = new GDateBuilder(v);
/* 287 */     gDateBuilder.setBuiltinTypeCode(code);
/* 288 */     GDate value = gDateBuilder.toGDate();
/*     */     
/* 290 */     if (_validateOnSet()) {
/* 291 */       validateValue((GDateSpecification)value, this._schemaType, _voorVc);
/*     */     }
/* 293 */     this._value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compare_to(XmlObject obj) {
/* 300 */     return this._value.compareToGDate((GDateSpecification)((XmlObjectBase)obj).gDateValue());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject obj) {
/* 305 */     return this._value.equals(((XmlObjectBase)obj).gDateValue());
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 310 */     return this._value.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 315 */     validateLexical(lexical, schemaType(), ctx);
/* 316 */     validateValue((GDateSpecification)gDateValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaGDateHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */