/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.SimpleValue;
/*    */ import org.apache.xmlbeans.XmlObject;
/*    */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*    */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JavaLongHolder
/*    */   extends XmlObjectBase
/*    */ {
/*    */   private long _value;
/*    */   
/*    */   public SchemaType schemaType() {
/* 32 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_LONG;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String compute_text(NamespaceManager nsm) {
/* 39 */     return Long.toString(this._value);
/*    */   } protected void set_text(String s) {
/*    */     
/* 42 */     try { set_long(XsTypeConverter.lexLong(s)); }
/* 43 */     catch (Exception e) { throw new XmlValueOutOfRangeException("long", new Object[] { s }); }
/*    */   
/*    */   }
/*    */   protected void set_nil() {
/* 47 */     this._value = 0L;
/*    */   }
/*    */   
/*    */   public BigDecimal getBigDecimalValue() {
/* 51 */     check_dated(); return BigDecimal.valueOf(this._value);
/* 52 */   } public BigInteger getBigIntegerValue() { check_dated(); return BigInteger.valueOf(this._value); } public long getLongValue() {
/* 53 */     check_dated(); return this._value;
/*    */   }
/* 55 */   private static final BigInteger _max = BigInteger.valueOf(Long.MAX_VALUE);
/* 56 */   private static final BigInteger _min = BigInteger.valueOf(Long.MIN_VALUE);
/*    */   
/*    */   protected void set_BigDecimal(BigDecimal v) {
/* 59 */     set_BigInteger(v.toBigInteger());
/*    */   }
/*    */   protected void set_BigInteger(BigInteger v) {
/* 62 */     if (v.compareTo(_max) > 0 || v.compareTo(_min) < 0)
/* 63 */       throw new XmlValueOutOfRangeException(); 
/* 64 */     this._value = v.longValue();
/*    */   } protected void set_long(long l) {
/* 66 */     this._value = l;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int compare_to(XmlObject l) {
/* 71 */     if (((SimpleValue)l).instanceType().getDecimalSize() > 64) {
/* 72 */       return -l.compareTo(this);
/*    */     }
/* 74 */     return (this._value == ((XmlObjectBase)l).longValue()) ? 0 : ((this._value < ((XmlObjectBase)l).longValue()) ? -1 : 1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean equal_to(XmlObject l) {
/* 80 */     if (((SimpleValue)l).instanceType().getDecimalSize() > 64) {
/* 81 */       return l.valueEquals(this);
/*    */     }
/* 83 */     return (this._value == ((XmlObjectBase)l).longValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int value_hash_code() {
/* 92 */     return (int)((this._value >> 32L) * 19L + this._value);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaLongHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */