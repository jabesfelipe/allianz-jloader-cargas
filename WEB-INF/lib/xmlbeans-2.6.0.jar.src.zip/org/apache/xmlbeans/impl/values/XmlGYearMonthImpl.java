/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlGYearMonth;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlGYearMonthImpl
/*    */   extends JavaGDateHolderEx
/*    */   implements XmlGYearMonth
/*    */ {
/*    */   public XmlGYearMonthImpl() {
/* 24 */     super(XmlGYearMonth.type, false);
/*    */   } public XmlGYearMonthImpl(SchemaType type, boolean complex) {
/* 26 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlGYearMonthImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */