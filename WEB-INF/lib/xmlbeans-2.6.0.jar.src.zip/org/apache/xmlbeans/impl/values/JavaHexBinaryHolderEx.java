/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaHexBinaryHolderEx
/*     */   extends JavaHexBinaryHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public SchemaType schemaType() {
/*  31 */     return this._schemaType;
/*     */   }
/*     */   public JavaHexBinaryHolderEx(SchemaType type, boolean complex) {
/*  34 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */   
/*     */   protected int get_wscanon_rule() {
/*  38 */     return schemaType().getWhiteSpaceRule();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_text(String s) {
/*     */     byte[] v;
/*  45 */     if (_validateOnSet()) {
/*  46 */       v = validateLexical(s, schemaType(), _voorVc);
/*     */     } else {
/*  48 */       v = lex(s, _voorVc);
/*     */     } 
/*  50 */     if (_validateOnSet() && v != null) {
/*  51 */       validateValue(v, schemaType(), XmlObjectBase._voorVc);
/*     */     }
/*  53 */     super.set_ByteArray(v);
/*     */     
/*  55 */     this._value = v;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_ByteArray(byte[] v) {
/*  61 */     if (_validateOnSet()) {
/*  62 */       validateValue(v, schemaType(), _voorVc);
/*     */     }
/*  64 */     super.set_ByteArray(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateValue(byte[] v, SchemaType sType, ValidationContext context) {
/*     */     XmlAnySimpleType xmlAnySimpleType;
/*  72 */     if ((xmlAnySimpleType = sType.getFacet(0)) != null) {
/*     */       int i;
/*  74 */       if ((i = ((XmlObjectBase)xmlAnySimpleType).bigIntegerValue().intValue()) != v.length)
/*     */       {
/*  76 */         context.invalid("cvc-length-valid.1.2", new Object[] { "hexBinary", new Integer(v.length), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  81 */     if ((xmlAnySimpleType = sType.getFacet(1)) != null) {
/*     */       int i;
/*  83 */       if ((i = ((XmlObjectBase)xmlAnySimpleType).bigIntegerValue().intValue()) > v.length)
/*     */       {
/*  85 */         context.invalid("cvc-minLength-valid.1.2", new Object[] { "hexBinary", new Integer(v.length), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  90 */     if ((xmlAnySimpleType = sType.getFacet(2)) != null) {
/*     */       int i;
/*  92 */       if ((i = ((XmlObjectBase)xmlAnySimpleType).bigIntegerValue().intValue()) < v.length)
/*     */       {
/*  94 */         context.invalid("cvc-maxLength-valid.1.2", new Object[] { "hexBinary", new Integer(v.length), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  99 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/*     */     
/* 101 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       int i;
/* 103 */       label37: for (i = 0; i < arrayOfXmlAnySimpleType.length; ) {
/*     */         
/* 105 */         byte[] enumBytes = ((XmlObjectBase)arrayOfXmlAnySimpleType[i]).byteArrayValue();
/*     */         
/* 107 */         if (enumBytes.length != v.length) {
/*     */           i++; continue;
/*     */         } 
/* 110 */         for (int j = 0; j < enumBytes.length; j++) {
/* 111 */           if (enumBytes[j] != v[j]) {
/*     */             continue label37;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 117 */       if (i >= arrayOfXmlAnySimpleType.length) {
/* 118 */         context.invalid("cvc-enumeration-valid.b", new Object[] { "hexBinary", QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 125 */     validateLexical(lexical, schemaType(), ctx);
/* 126 */     validateValue(byteArrayValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaHexBinaryHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */