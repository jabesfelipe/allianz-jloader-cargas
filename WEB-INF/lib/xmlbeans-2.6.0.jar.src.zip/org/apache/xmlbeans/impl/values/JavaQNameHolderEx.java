/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.impl.common.PrefixResolver;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaQNameHolderEx
/*     */   extends JavaQNameHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public SchemaType schemaType() {
/*  34 */     return this._schemaType;
/*     */   }
/*     */   public JavaQNameHolderEx(SchemaType type, boolean complex) {
/*  37 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */   
/*     */   protected int get_wscanon_rule() {
/*  41 */     return schemaType().getWhiteSpaceRule();
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*     */     QName v;
/*  46 */     PrefixResolver resolver = NamespaceContext.getCurrent();
/*     */     
/*  48 */     if (resolver == null && has_store()) {
/*  49 */       resolver = get_store();
/*     */     }
/*     */     
/*  52 */     if (_validateOnSet()) {
/*     */       
/*  54 */       v = validateLexical(s, this._schemaType, _voorVc, resolver);
/*  55 */       if (v != null) {
/*  56 */         validateValue(v, this._schemaType, _voorVc);
/*     */       }
/*     */     } else {
/*  59 */       v = JavaQNameHolder.validateLexical(s, _voorVc, resolver);
/*     */     } 
/*  61 */     super.set_QName(v);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_QName(QName name) {
/*  66 */     if (_validateOnSet())
/*  67 */       validateValue(name, this._schemaType, _voorVc); 
/*  68 */     super.set_QName(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_xmlanysimple(XmlAnySimpleType value) {
/*     */     QName v;
/*  74 */     if (_validateOnSet()) {
/*     */       
/*  76 */       v = validateLexical(value.getStringValue(), this._schemaType, _voorVc, NamespaceContext.getCurrent());
/*     */       
/*  78 */       if (v != null) {
/*  79 */         validateValue(v, this._schemaType, _voorVc);
/*     */       }
/*     */     } else {
/*  82 */       v = JavaQNameHolder.validateLexical(value.getStringValue(), _voorVc, NamespaceContext.getCurrent());
/*     */     } 
/*  84 */     super.set_QName(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static QName validateLexical(String v, SchemaType sType, ValidationContext context, PrefixResolver resolver) {
/*  89 */     QName name = JavaQNameHolder.validateLexical(v, context, resolver);
/*     */ 
/*     */     
/*  92 */     if (sType.hasPatternFacet())
/*     */     {
/*  94 */       if (!sType.matchPatternFacet(v))
/*     */       {
/*     */         
/*  97 */         context.invalid("cvc-datatype-valid.1.1", new Object[] { "QName", v, QNameHelper.readable(sType) });
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     return name;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void validateValue(QName v, SchemaType sType, ValidationContext context) {
/* 127 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 128 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 130 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/* 131 */         if (v.equals(((XmlObjectBase)arrayOfXmlAnySimpleType[i]).getQNameValue()))
/*     */           return; 
/* 133 */       }  context.invalid("cvc-enumeration-valid", new Object[] { "QName", v, QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 140 */     validateValue(getQNameValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaQNameHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */