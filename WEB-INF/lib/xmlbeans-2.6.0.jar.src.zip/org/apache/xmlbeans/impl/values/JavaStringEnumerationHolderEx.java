/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.StringEnumAbstractBase;
/*    */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*    */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JavaStringEnumerationHolderEx
/*    */   extends JavaStringHolderEx
/*    */ {
/*    */   private StringEnumAbstractBase _val;
/*    */   
/*    */   public JavaStringEnumerationHolderEx(SchemaType type, boolean complex) {
/* 29 */     super(type, complex);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void set_text(String s) {
/* 37 */     StringEnumAbstractBase se = schemaType().enumForString(s);
/* 38 */     if (se == null) {
/* 39 */       throw new XmlValueOutOfRangeException("cvc-enumeration-valid", new Object[] { "string", s, QNameHelper.readable(schemaType()) });
/*    */     }
/*    */     
/* 42 */     super.set_text(s);
/* 43 */     this._val = se;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void validateLexical(String v, SchemaType sType, ValidationContext context) {
/* 48 */     JavaStringHolderEx.validateLexical(v, sType, context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void set_nil() {
/* 53 */     this._val = null;
/* 54 */     super.set_nil();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringEnumAbstractBase getEnumValue() {
/* 60 */     check_dated();
/* 61 */     return this._val;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void set_enum(StringEnumAbstractBase se) {
/* 66 */     Class ejc = schemaType().getEnumJavaClass();
/* 67 */     if (ejc != null && !se.getClass().equals(ejc)) {
/* 68 */       throw new XmlValueOutOfRangeException();
/*    */     }
/* 70 */     super.set_text(se.toString());
/* 71 */     this._val = se;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaStringEnumerationHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */