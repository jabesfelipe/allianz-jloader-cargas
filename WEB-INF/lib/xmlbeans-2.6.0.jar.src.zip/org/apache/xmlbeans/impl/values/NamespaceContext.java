/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import org.apache.xmlbeans.XmlCursor;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.PrefixResolver;
/*     */ import org.apache.xmlbeans.xml.stream.StartElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamespaceContext
/*     */   implements PrefixResolver
/*     */ {
/*     */   private static final int TYPE_STORE = 1;
/*     */   private static final int XML_OBJECT = 2;
/*     */   private static final int MAP = 3;
/*     */   private static final int START_ELEMENT = 4;
/*     */   private static final int RESOLVER = 5;
/*     */   private Object _obj;
/*     */   private int _code;
/*     */   
/*     */   public NamespaceContext(Map prefixToUriMap) {
/*  43 */     this._code = 3;
/*  44 */     this._obj = prefixToUriMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamespaceContext(TypeStore typeStore) {
/*  49 */     this._code = 1;
/*  50 */     this._obj = typeStore;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamespaceContext(XmlObject xmlObject) {
/*  55 */     this._code = 2;
/*  56 */     this._obj = xmlObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamespaceContext(StartElement start) {
/*  61 */     this._code = 4;
/*  62 */     this._obj = start;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamespaceContext(PrefixResolver resolver) {
/*  67 */     this._code = 5;
/*  68 */     this._obj = resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class NamespaceContextStack
/*     */   {
/*     */     NamespaceContext current;
/*     */ 
/*     */     
/*  78 */     ArrayList stack = new ArrayList();
/*     */     
/*     */     final void push(NamespaceContext next) {
/*  81 */       this.stack.add(this.current);
/*  82 */       this.current = next;
/*     */     }
/*     */     
/*     */     final void pop() {
/*  86 */       this.current = this.stack.get(this.stack.size() - 1);
/*  87 */       this.stack.remove(this.stack.size() - 1);
/*     */     }
/*     */     
/*     */     private NamespaceContextStack() {} }
/*  91 */   private static ThreadLocal tl_namespaceContextStack = new ThreadLocal();
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   private static NamespaceContextStack getNamespaceContextStack() {
/*  95 */     NamespaceContextStack namespaceContextStack = tl_namespaceContextStack.get();
/*  96 */     if (namespaceContextStack == null) {
/*     */       
/*  98 */       namespaceContextStack = new NamespaceContextStack();
/*  99 */       tl_namespaceContextStack.set(namespaceContextStack);
/*     */     } 
/* 101 */     return namespaceContextStack;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void push(NamespaceContext next) {
/* 106 */     getNamespaceContextStack().push(next);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void pop() {
/* 111 */     NamespaceContextStack nsContextStack = getNamespaceContextStack();
/* 112 */     nsContextStack.pop();
/*     */     
/* 114 */     if (nsContextStack.stack.size() == 0) {
/* 115 */       tl_namespaceContextStack.set(null);
/*     */     }
/*     */   }
/*     */   
/*     */   public static PrefixResolver getCurrent() {
/* 120 */     return (getNamespaceContextStack()).current;
/*     */   }
/*     */   public String getNamespaceForPrefix(String prefix) {
/*     */     Object obj;
/*     */     XmlCursor cur;
/* 125 */     if (prefix != null && prefix.equals("xml")) {
/* 126 */       return "http://www.w3.org/XML/1998/namespace";
/*     */     }
/* 128 */     switch (this._code) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 133 */         obj = this._obj;
/* 134 */         if (Proxy.isProxyClass(obj.getClass())) {
/* 135 */           obj = Proxy.getInvocationHandler(obj);
/*     */         }
/* 137 */         if (obj instanceof TypeStoreUser) {
/* 138 */           return ((TypeStoreUser)obj).get_store().getNamespaceForPrefix(prefix);
/*     */         }
/* 140 */         cur = ((XmlObject)this._obj).newCursor();
/* 141 */         if (cur != null) {
/*     */           
/* 143 */           if (cur.currentTokenType() == XmlCursor.TokenType.ATTR)
/* 144 */             cur.toParent();  
/* 145 */           try { return cur.namespaceForPrefix(prefix); }
/* 146 */           finally { cur.dispose(); }
/*     */         
/*     */         } 
/*     */       
/*     */       case 3:
/* 151 */         return (String)((Map)this._obj).get(prefix);
/*     */       
/*     */       case 1:
/* 154 */         return ((TypeStore)this._obj).getNamespaceForPrefix(prefix);
/*     */       
/*     */       case 4:
/* 157 */         return ((StartElement)this._obj).getNamespaceUri(prefix);
/*     */       
/*     */       case 5:
/* 160 */         return ((PrefixResolver)this._obj).getNamespaceForPrefix(prefix);
/*     */     } 
/*     */     
/* 163 */     assert false : "Improperly initialized NamespaceContext.";
/* 164 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\NamespaceContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */