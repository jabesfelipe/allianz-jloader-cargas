/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*     */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaDoubleHolder
/*     */   extends XmlObjectBase
/*     */ {
/*     */   double _value;
/*     */   
/*     */   public SchemaType schemaType() {
/*  31 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_DOUBLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  38 */     return serialize(this._value);
/*     */   }
/*     */   
/*     */   public static String serialize(double d) {
/*  42 */     if (d == Double.POSITIVE_INFINITY)
/*  43 */       return "INF"; 
/*  44 */     if (d == Double.NEGATIVE_INFINITY)
/*  45 */       return "-INF"; 
/*  46 */     if (d == Double.NaN) {
/*  47 */       return "NaN";
/*     */     }
/*  49 */     return Double.toString(d);
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*  53 */     set_double(validateLexical(s, _voorVc));
/*     */   }
/*     */ 
/*     */   
/*     */   public static double validateLexical(String v, ValidationContext context) {
/*     */     try {
/*  59 */       return XsTypeConverter.lexDouble(v);
/*     */     }
/*  61 */     catch (NumberFormatException e) {
/*     */       
/*  63 */       context.invalid("double", new Object[] { v });
/*     */       
/*  65 */       return Double.NaN;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void set_nil() {
/*  70 */     this._value = 0.0D;
/*     */   }
/*     */   
/*     */   public BigDecimal getBigDecimalValue() {
/*  74 */     check_dated(); return new BigDecimal(this._value);
/*  75 */   } public double getDoubleValue() { check_dated(); return this._value; } public float getFloatValue() {
/*  76 */     check_dated(); return (float)this._value;
/*     */   }
/*     */   
/*  79 */   protected void set_double(double v) { this._value = v; }
/*  80 */   protected void set_float(float v) { set_double(v); }
/*  81 */   protected void set_long(long v) { set_double(v); }
/*  82 */   protected void set_BigDecimal(BigDecimal v) { set_double(v.doubleValue()); } protected void set_BigInteger(BigInteger v) {
/*  83 */     set_double(v.doubleValue());
/*     */   }
/*     */ 
/*     */   
/*     */   protected int compare_to(XmlObject d) {
/*  88 */     return compare(this._value, ((XmlObjectBase)d).doubleValue());
/*     */   }
/*     */   
/*     */   static int compare(double thisValue, double thatValue) {
/*  92 */     if (thisValue < thatValue) return -1; 
/*  93 */     if (thisValue > thatValue) return 1;
/*     */     
/*  95 */     long thisBits = Double.doubleToLongBits(thisValue);
/*  96 */     long thatBits = Double.doubleToLongBits(thatValue);
/*     */     
/*  98 */     return (thisBits == thatBits) ? 0 : ((thisBits < thatBits) ? -1 : 1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject d) {
/* 103 */     return (compare(this._value, ((XmlObjectBase)d).doubleValue()) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 108 */     long v = Double.doubleToLongBits(this._value);
/* 109 */     return (int)((v >> 32L) * 19L + v);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaDoubleHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */