/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlBase64Binary;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*     */ import org.apache.xmlbeans.impl.util.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaBase64Holder
/*     */   extends XmlObjectBase
/*     */ {
/*     */   protected byte[] _value;
/*     */   
/*     */   public SchemaType schemaType() {
/*  36 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_BASE_64_BINARY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  45 */     return new String(Base64.encode(this._value));
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*  49 */     this._hashcached = false;
/*  50 */     if (_validateOnSet()) {
/*  51 */       this._value = validateLexical(s, schemaType(), _voorVc);
/*     */     } else {
/*  53 */       this._value = lex(s, _voorVc);
/*     */     } 
/*     */   }
/*     */   protected void set_nil() {
/*  57 */     this._hashcached = false;
/*  58 */     this._value = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] lex(String v, ValidationContext c) {
/*  63 */     byte[] vBytes = null;
/*     */     
/*     */     try {
/*  66 */       vBytes = v.getBytes("UTF-8");
/*     */     }
/*  68 */     catch (UnsupportedEncodingException uee) {}
/*     */ 
/*     */ 
/*     */     
/*  72 */     byte[] bytes = Base64.decode(vBytes);
/*     */     
/*  74 */     if (bytes == null)
/*     */     {
/*     */       
/*  77 */       c.invalid("base64Binary", new Object[] { "not encoded properly" });
/*     */     }
/*     */     
/*  80 */     return bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  85 */     byte[] bytes = lex(v, context);
/*  86 */     if (bytes == null) return null;
/*     */     
/*  88 */     if (!sType.matchPatternFacet(v)) {
/*     */       
/*  90 */       context.invalid("cvc-datatype-valid.1.1b", new Object[] { "base 64", QNameHelper.readable(sType) });
/*     */       
/*  92 */       return null;
/*     */     } 
/*     */     
/*  95 */     return bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getByteArrayValue() {
/* 100 */     check_dated();
/* 101 */     if (this._value == null) {
/* 102 */       return null;
/*     */     }
/* 104 */     byte[] result = new byte[this._value.length];
/* 105 */     System.arraycopy(this._value, 0, result, 0, this._value.length);
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_ByteArray(byte[] ba) {
/* 112 */     this._hashcached = false;
/* 113 */     this._value = new byte[ba.length];
/* 114 */     System.arraycopy(ba, 0, this._value, 0, ba.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject i) {
/* 120 */     byte[] ival = ((XmlBase64Binary)i).getByteArrayValue();
/* 121 */     return Arrays.equals(this._value, ival);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _hashcached = false;
/* 126 */   protected int hashcode = 0;
/*     */   
/*     */   protected static MessageDigest md5;
/*     */   
/*     */   static {
/*     */     try {
/* 132 */       md5 = MessageDigest.getInstance("MD5");
/*     */     }
/* 134 */     catch (NoSuchAlgorithmException e) {
/*     */       
/* 136 */       throw new IllegalStateException("Cannot find MD5 hash Algorithm");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 142 */     if (this._hashcached) {
/* 143 */       return this.hashcode;
/*     */     }
/* 145 */     this._hashcached = true;
/*     */     
/* 147 */     if (this._value == null) {
/* 148 */       return this.hashcode = 0;
/*     */     }
/* 150 */     byte[] res = md5.digest(this._value);
/* 151 */     return this.hashcode = res[0] << 24 + res[1] << 16 + res[2] << 8 + res[3];
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaBase64Holder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */