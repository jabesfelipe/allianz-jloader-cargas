/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*    */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JavaBooleanHolderEx
/*    */   extends JavaBooleanHolder
/*    */ {
/*    */   private SchemaType _schemaType;
/*    */   
/*    */   public SchemaType schemaType() {
/* 30 */     return this._schemaType;
/*    */   }
/*    */   
/*    */   public static boolean validateLexical(String v, SchemaType sType, ValidationContext context) {
/* 34 */     boolean b = JavaBooleanHolder.validateLexical(v, context);
/* 35 */     validatePattern(v, sType, context);
/* 36 */     return b;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void validatePattern(String v, SchemaType sType, ValidationContext context) {
/* 42 */     if (!sType.matchPatternFacet(v)) {
/* 43 */       context.invalid("cvc-datatype-valid.1.1", new Object[] { "boolean", v, QNameHelper.readable(sType) });
/*    */     }
/*    */   }
/*    */   
/*    */   public JavaBooleanHolderEx(SchemaType type, boolean complex) {
/* 48 */     this._schemaType = type; initComplexType(complex, false);
/*    */   }
/*    */   
/*    */   protected void set_text(String s) {
/* 52 */     if (_validateOnSet())
/* 53 */       validatePattern(s, this._schemaType, _voorVc); 
/* 54 */     super.set_text(s);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 59 */     validateLexical(lexical, schemaType(), ctx);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaBooleanHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */