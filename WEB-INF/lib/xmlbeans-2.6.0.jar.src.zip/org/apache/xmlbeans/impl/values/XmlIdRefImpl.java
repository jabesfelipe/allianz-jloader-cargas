/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlIDREF;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlIdRefImpl
/*    */   extends JavaStringHolderEx
/*    */   implements XmlIDREF
/*    */ {
/*    */   public XmlIdRefImpl() {
/* 25 */     super(XmlIDREF.type, false);
/*    */   } public XmlIdRefImpl(SchemaType type, boolean complex) {
/* 27 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlIdRefImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */