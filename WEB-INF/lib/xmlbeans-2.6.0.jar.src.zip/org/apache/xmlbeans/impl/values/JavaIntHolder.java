/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*     */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaIntHolder
/*     */   extends XmlObjectBase
/*     */ {
/*     */   private int _value;
/*     */   
/*     */   public SchemaType schemaType() {
/*  32 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_INT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String compute_text(NamespaceManager nsm) {
/*  39 */     return Long.toString(this._value);
/*     */   } protected void set_text(String s) {
/*     */     
/*  42 */     try { set_int(XsTypeConverter.lexInt(s)); }
/*  43 */     catch (Exception e) { throw new XmlValueOutOfRangeException("int", new Object[] { s }); }
/*     */   
/*     */   }
/*     */   protected void set_nil() {
/*  47 */     this._value = 0;
/*     */   }
/*     */   
/*  50 */   public BigDecimal getBigDecimalValue() { check_dated(); return new BigDecimal(this._value); }
/*  51 */   public BigInteger getBigIntegerValue() { check_dated(); return BigInteger.valueOf(this._value); }
/*  52 */   public long getLongValue() { check_dated(); return this._value; } public int getIntValue() {
/*  53 */     check_dated(); return this._value;
/*     */   }
/*  55 */   static final BigInteger _max = BigInteger.valueOf(2147483647L);
/*  56 */   static final BigInteger _min = BigInteger.valueOf(-2147483648L);
/*     */   
/*     */   protected void set_BigDecimal(BigDecimal v) {
/*  59 */     set_BigInteger(v.toBigInteger());
/*     */   }
/*     */   protected void set_BigInteger(BigInteger v) {
/*  62 */     if (v.compareTo(_max) > 0 || v.compareTo(_min) < 0)
/*  63 */       throw new XmlValueOutOfRangeException(); 
/*  64 */     set_int(v.intValue());
/*     */   }
/*     */   
/*     */   protected void set_long(long l) {
/*  68 */     if (l > 2147483647L || l < -2147483648L)
/*  69 */       throw new XmlValueOutOfRangeException(); 
/*  70 */     set_int((int)l);
/*     */   }
/*     */   
/*     */   protected void set_int(int i) {
/*  74 */     this._value = i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compare_to(XmlObject i) {
/*  80 */     if (((SimpleValue)i).instanceType().getDecimalSize() > 32) {
/*  81 */       return -i.compareTo(this);
/*     */     }
/*  83 */     return (this._value == ((XmlObjectBase)i).intValue()) ? 0 : ((this._value < ((XmlObjectBase)i).intValue()) ? -1 : 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject i) {
/*  89 */     if (((SimpleValue)i).instanceType().getDecimalSize() > 32) {
/*  90 */       return i.valueEquals(this);
/*     */     }
/*  92 */     return (this._value == ((XmlObjectBase)i).intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 101 */     return this._value;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaIntHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */