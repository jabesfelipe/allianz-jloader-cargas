/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlIntegerRestriction
/*    */   extends JavaIntegerHolderEx
/*    */   implements XmlInteger
/*    */ {
/*    */   public XmlIntegerRestriction(SchemaType type, boolean complex) {
/* 24 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlIntegerRestriction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */