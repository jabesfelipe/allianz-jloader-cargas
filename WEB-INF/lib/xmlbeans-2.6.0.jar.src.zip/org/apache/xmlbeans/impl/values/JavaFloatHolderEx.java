/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaFloatHolderEx
/*     */   extends JavaFloatHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public JavaFloatHolderEx(SchemaType type, boolean complex) {
/*  29 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType schemaType() {
/*  34 */     return this._schemaType;
/*     */   }
/*     */   
/*     */   protected void set_float(float v) {
/*  38 */     if (_validateOnSet())
/*  39 */       validateValue(v, this._schemaType, _voorVc); 
/*  40 */     super.set_float(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static float validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  45 */     float f = JavaFloatHolder.validateLexical(v, context);
/*     */     
/*  47 */     if (!sType.matchPatternFacet(v)) {
/*  48 */       context.invalid("cvc-datatype-valid.1.1", new Object[] { "float", v, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/*  51 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateValue(float v, SchemaType sType, ValidationContext context) {
/*     */     XmlAnySimpleType xmlAnySimpleType;
/*  59 */     if ((xmlAnySimpleType = sType.getFacet(3)) != null) {
/*     */       float f;
/*  61 */       if (compare(v, f = ((XmlObjectBase)xmlAnySimpleType).floatValue()) <= 0)
/*     */       {
/*  63 */         context.invalid("cvc-minExclusive-valid", new Object[] { "float", new Float(v), new Float(f), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  68 */     if ((xmlAnySimpleType = sType.getFacet(4)) != null) {
/*     */       float f;
/*  70 */       if (compare(v, f = ((XmlObjectBase)xmlAnySimpleType).floatValue()) < 0)
/*     */       {
/*  72 */         context.invalid("cvc-minInclusive-valid", new Object[] { "float", new Float(v), new Float(f), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  77 */     if ((xmlAnySimpleType = sType.getFacet(5)) != null) {
/*     */       float f;
/*  79 */       if (compare(v, f = ((XmlObjectBase)xmlAnySimpleType).floatValue()) > 0)
/*     */       {
/*  81 */         context.invalid("cvc-maxInclusive-valid", new Object[] { "float", new Float(v), new Float(f), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  86 */     if ((xmlAnySimpleType = sType.getFacet(6)) != null) {
/*     */       float f;
/*  88 */       if (compare(v, f = ((XmlObjectBase)xmlAnySimpleType).floatValue()) >= 0)
/*     */       {
/*  90 */         context.invalid("cvc-maxExclusive-valid", new Object[] { "float", new Float(v), new Float(f), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  95 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/*  96 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/*  98 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/*  99 */         if (compare(v, ((XmlObjectBase)arrayOfXmlAnySimpleType[i]).floatValue()) == 0)
/*     */           return; 
/* 101 */       }  context.invalid("cvc-enumeration-valid", new Object[] { "float", new Float(v), QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 108 */     validateLexical(lexical, schemaType(), ctx);
/* 109 */     validateValue(floatValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaFloatHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */