/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaBase64HolderEx
/*     */   extends JavaBase64Holder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public SchemaType schemaType() {
/*  29 */     return this._schemaType;
/*     */   }
/*     */   public JavaBase64HolderEx(SchemaType type, boolean complex) {
/*  32 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */   
/*     */   protected int get_wscanon_rule() {
/*  36 */     return schemaType().getWhiteSpaceRule();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_text(String s) {
/*     */     byte[] v;
/*  43 */     if (_validateOnSet()) {
/*  44 */       v = validateLexical(s, schemaType(), _voorVc);
/*     */     } else {
/*  46 */       v = lex(s, _voorVc);
/*     */     } 
/*  48 */     if (v != null && _validateOnSet()) {
/*  49 */       validateValue(v, schemaType(), XmlObjectBase._voorVc);
/*     */     }
/*  51 */     super.set_ByteArray(v);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_ByteArray(byte[] v) {
/*  57 */     if (_validateOnSet()) {
/*  58 */       validateValue(v, schemaType(), _voorVc);
/*     */     }
/*  60 */     super.set_ByteArray(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateValue(byte[] v, SchemaType sType, ValidationContext context) {
/*     */     XmlAnySimpleType xmlAnySimpleType;
/*  68 */     if ((xmlAnySimpleType = sType.getFacet(0)) != null) {
/*     */       int i;
/*  70 */       if ((i = ((XmlObjectBase)xmlAnySimpleType).bigIntegerValue().intValue()) != v.length)
/*     */       {
/*  72 */         context.invalid("cvc-length-valid.1.2", new Object[] { "base64Binary", new Integer(v.length), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  77 */     if ((xmlAnySimpleType = sType.getFacet(1)) != null) {
/*     */       int i;
/*  79 */       if ((i = ((XmlObjectBase)xmlAnySimpleType).bigIntegerValue().intValue()) > v.length)
/*     */       {
/*  81 */         context.invalid("cvc-minLength-valid.1.2", new Object[] { "base64Binary", new Integer(v.length), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  86 */     if ((xmlAnySimpleType = sType.getFacet(2)) != null) {
/*     */       int i;
/*  88 */       if ((i = ((XmlObjectBase)xmlAnySimpleType).bigIntegerValue().intValue()) < v.length)
/*     */       {
/*  90 */         context.invalid("cvc-maxLength-valid.1.2", new Object[] { "base64Binary", new Integer(v.length), new Integer(i), QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  95 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/*     */     
/*  97 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       int i;
/*  99 */       label37: for (i = 0; i < arrayOfXmlAnySimpleType.length; ) {
/*     */         
/* 101 */         byte[] enumBytes = ((XmlObjectBase)arrayOfXmlAnySimpleType[i]).byteArrayValue();
/*     */         
/* 103 */         if (enumBytes.length != v.length) {
/*     */           i++; continue;
/*     */         } 
/* 106 */         for (int j = 0; j < enumBytes.length; j++) {
/* 107 */           if (enumBytes[j] != v[j]) {
/*     */             continue label37;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 113 */       if (i >= arrayOfXmlAnySimpleType.length) {
/* 114 */         context.invalid("cvc-enumeration-valid.b", new Object[] { "base64Binary", QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 121 */     validateLexical(lexical, schemaType(), ctx);
/* 122 */     validateValue(byteArrayValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaBase64HolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */