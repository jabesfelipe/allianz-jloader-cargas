/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaUriHolderEx
/*     */   extends JavaUriHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public SchemaType schemaType() {
/*  30 */     return this._schemaType;
/*     */   }
/*     */   public JavaUriHolderEx(SchemaType type, boolean complex) {
/*  33 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */   
/*     */   protected int get_wscanon_rule() {
/*  37 */     return schemaType().getWhiteSpaceRule();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_text(String s) {
/*  42 */     if (_validateOnSet()) {
/*     */       
/*  44 */       if (!check(s, this._schemaType)) {
/*  45 */         throw new XmlValueOutOfRangeException();
/*     */       }
/*  47 */       if (!this._schemaType.matchPatternFacet(s)) {
/*  48 */         throw new XmlValueOutOfRangeException();
/*     */       }
/*     */     } 
/*  51 */     super.set_text(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  65 */     XmlAnyUriImpl.validateLexical(v, context);
/*     */     
/*  67 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/*     */     
/*  69 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       int j;
/*     */ 
/*     */       
/*  73 */       for (j = 0; j < arrayOfXmlAnySimpleType.length; j++) {
/*     */         
/*  75 */         String e = ((SimpleValue)arrayOfXmlAnySimpleType[j]).getStringValue();
/*     */         
/*  77 */         if (e.equals(v)) {
/*     */           break;
/*     */         }
/*     */       } 
/*  81 */       if (j >= arrayOfXmlAnySimpleType.length) {
/*  82 */         context.invalid("cvc-enumeration-valid", new Object[] { "anyURI", v, QNameHelper.readable(sType) });
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  87 */     if (sType.hasPatternFacet())
/*     */     {
/*  89 */       if (!sType.matchPatternFacet(v))
/*     */       {
/*     */         
/*  92 */         context.invalid("cvc-datatype-valid.1.1", new Object[] { "anyURI", v, QNameHelper.readable(sType) });
/*     */       }
/*     */     }
/*     */     
/*     */     XmlAnySimpleType xmlAnySimpleType;
/*     */     
/*     */     int i;
/*     */     
/* 100 */     if ((xmlAnySimpleType = sType.getFacet(0)) != null && (
/* 101 */       i = ((SimpleValue)xmlAnySimpleType).getBigIntegerValue().intValue()) != v.length()) {
/* 102 */       context.invalid("cvc-length-valid.1.1", new Object[] { "anyURI", v, new Integer(i), QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 105 */     if ((xmlAnySimpleType = sType.getFacet(1)) != null && (
/* 106 */       i = ((SimpleValue)xmlAnySimpleType).getBigIntegerValue().intValue()) > v.length()) {
/* 107 */       context.invalid("cvc-minLength-valid.1.1", new Object[] { "anyURI", v, new Integer(i), QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 110 */     if ((xmlAnySimpleType = sType.getFacet(2)) != null && (
/* 111 */       i = ((SimpleValue)xmlAnySimpleType).getBigIntegerValue().intValue()) < v.length()) {
/* 112 */       context.invalid("cvc-maxLength-valid.1.1", new Object[] { "anyURI", v, new Integer(i), QNameHelper.readable(sType) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean check(String v, SchemaType sType) {
/* 118 */     int length = (v == null) ? 0 : v.length();
/*     */     
/* 120 */     XmlAnySimpleType xmlAnySimpleType1 = sType.getFacet(0);
/* 121 */     if (xmlAnySimpleType1 != null) {
/*     */       
/* 123 */       int m = ((SimpleValue)xmlAnySimpleType1).getBigIntegerValue().intValue();
/* 124 */       if (length == m) {
/* 125 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 129 */     XmlAnySimpleType xmlAnySimpleType2 = sType.getFacet(1);
/* 130 */     if (xmlAnySimpleType2 != null) {
/*     */       
/* 132 */       int m = ((SimpleValue)xmlAnySimpleType2).getBigIntegerValue().intValue();
/* 133 */       if (length < m) {
/* 134 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 138 */     XmlAnySimpleType xmlAnySimpleType3 = sType.getFacet(2);
/* 139 */     if (xmlAnySimpleType3 != null) {
/*     */       
/* 141 */       int m = ((SimpleValue)xmlAnySimpleType3).getBigIntegerValue().intValue();
/* 142 */       if (length > m) {
/* 143 */         return false;
/*     */       }
/*     */     } 
/* 146 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 151 */     validateLexical(stringValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaUriHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */