/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlValueDisconnectedException
/*    */   extends RuntimeException
/*    */ {
/*    */   XmlValueDisconnectedException() {}
/*    */   
/*    */   XmlValueDisconnectedException(String message) {
/* 26 */     super(message);
/*    */   }
/*    */ 
/*    */   
/*    */   XmlValueDisconnectedException(String message, Throwable cause) {
/* 31 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlValueDisconnectedException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */