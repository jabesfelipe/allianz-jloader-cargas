/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import org.apache.xmlbeans.GDuration;
/*     */ import org.apache.xmlbeans.GDurationSpecification;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaGDurationHolderEx
/*     */   extends XmlObjectBase
/*     */ {
/*     */   GDuration _value;
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public JavaGDurationHolderEx(SchemaType type, boolean complex) {
/*  29 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaType schemaType() {
/*  34 */     return this._schemaType;
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*     */     GDuration newVal;
/*  39 */     if (_validateOnSet()) {
/*  40 */       newVal = validateLexical(s, this._schemaType, _voorVc);
/*     */     } else {
/*  42 */       newVal = lex(s, _voorVc);
/*     */     } 
/*  44 */     if (_validateOnSet() && newVal != null) {
/*  45 */       validateValue((GDurationSpecification)newVal, this._schemaType, _voorVc);
/*     */     }
/*  47 */     this._value = newVal;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_GDuration(GDurationSpecification v) {
/*  52 */     if (_validateOnSet()) {
/*  53 */       validateValue(v, this._schemaType, _voorVc);
/*     */     }
/*  55 */     if (v.isImmutable() && v instanceof GDuration) {
/*  56 */       this._value = (GDuration)v;
/*     */     } else {
/*  58 */       this._value = new GDuration(v);
/*     */     } 
/*     */   }
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  62 */     return (this._value == null) ? "" : this._value.toString();
/*     */   }
/*     */   
/*     */   protected void set_nil() {
/*  66 */     this._value = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public GDuration getGDurationValue() {
/*  71 */     check_dated();
/*     */     
/*  73 */     return (this._value == null) ? null : this._value;
/*     */   }
/*     */ 
/*     */   
/*     */   public static GDuration lex(String v, ValidationContext context) {
/*  78 */     GDuration duration = null;
/*     */ 
/*     */     
/*     */     try {
/*  82 */       duration = new GDuration(v);
/*     */     }
/*  84 */     catch (Exception e) {
/*     */       
/*  86 */       context.invalid("duration", new Object[] { v });
/*     */     } 
/*     */     
/*  89 */     return duration;
/*     */   }
/*     */ 
/*     */   
/*     */   public static GDuration validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  94 */     GDuration duration = lex(v, context);
/*     */     
/*  96 */     if (duration != null && sType.hasPatternFacet() && 
/*  97 */       !sType.matchPatternFacet(v)) {
/*  98 */       context.invalid("cvc-datatype-valid.1.1", new Object[] { "duration", v, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 101 */     return duration;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateValue(GDurationSpecification v, SchemaType sType, ValidationContext context) {
/*     */     XmlAnySimpleType xmlAnySimpleType;
/*     */     GDuration g;
/* 109 */     if ((xmlAnySimpleType = sType.getFacet(3)) != null && 
/* 110 */       v.compareToGDuration((GDurationSpecification)(g = ((XmlObjectBase)xmlAnySimpleType).gDurationValue())) <= 0) {
/* 111 */       context.invalid("cvc-minExclusive-valid", new Object[] { "duration", v, g, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 114 */     if ((xmlAnySimpleType = sType.getFacet(4)) != null && 
/* 115 */       v.compareToGDuration((GDurationSpecification)(g = ((XmlObjectBase)xmlAnySimpleType).gDurationValue())) < 0) {
/* 116 */       context.invalid("cvc-minInclusive-valid", new Object[] { "duration", v, g, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 119 */     if ((xmlAnySimpleType = sType.getFacet(6)) != null && 
/* 120 */       v.compareToGDuration((GDurationSpecification)(g = ((XmlObjectBase)xmlAnySimpleType).gDurationValue())) >= 0) {
/* 121 */       context.invalid("cvc-maxExclusive-valid", new Object[] { "duration", v, g, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 124 */     if ((xmlAnySimpleType = sType.getFacet(5)) != null && 
/* 125 */       v.compareToGDuration((GDurationSpecification)(g = ((XmlObjectBase)xmlAnySimpleType).gDurationValue())) > 0) {
/* 126 */       context.invalid("cvc-maxInclusive-valid", new Object[] { "duration", v, g, QNameHelper.readable(sType) });
/*     */     }
/*     */     
/* 129 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 130 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 132 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/* 133 */         if (v.compareToGDuration((GDurationSpecification)((XmlObjectBase)arrayOfXmlAnySimpleType[i]).gDurationValue()) == 0)
/*     */           return; 
/* 135 */       }  context.invalid("cvc-enumeration-valid", new Object[] { "duration", v, QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compare_to(XmlObject d) {
/* 142 */     return this._value.compareToGDuration((GDurationSpecification)((XmlObjectBase)d).gDurationValue());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject d) {
/* 147 */     return this._value.equals(((XmlObjectBase)d).gDurationValue());
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 152 */     return this._value.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 157 */     validateLexical(lexical, schemaType(), ctx);
/* 158 */     validateValue((GDurationSpecification)gDurationValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaGDurationHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */