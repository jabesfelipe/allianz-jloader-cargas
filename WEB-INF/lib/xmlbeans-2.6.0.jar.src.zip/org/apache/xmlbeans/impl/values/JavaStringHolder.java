/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlObject;
/*    */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaStringHolder
/*    */   extends XmlObjectBase
/*    */ {
/*    */   private String _value;
/*    */   
/*    */   public SchemaType schemaType() {
/* 28 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_STRING;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int get_wscanon_rule() {
/* 33 */     return 1;
/*    */   }
/*    */   
/* 36 */   public String compute_text(NamespaceManager nsm) { return this._value; }
/* 37 */   protected void set_text(String s) { this._value = s; } protected void set_nil() {
/* 38 */     this._value = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean equal_to(XmlObject obj) {
/* 45 */     return this._value.equals(((XmlObjectBase)obj).stringValue());
/*    */   }
/*    */ 
/*    */   
/*    */   protected int value_hash_code() {
/* 50 */     return this._value.hashCode();
/*    */   }
/*    */   
/*    */   protected boolean is_defaultable_ws(String v) {
/* 54 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaStringHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */