/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.XmlName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlNameImpl
/*    */   extends JavaStringHolderEx
/*    */   implements XmlName
/*    */ {
/*    */   public XmlNameImpl() {
/* 25 */     super(XmlName.type, false);
/*    */   } public XmlNameImpl(SchemaType type, boolean complex) {
/* 27 */     super(type, complex);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\XmlNameImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */