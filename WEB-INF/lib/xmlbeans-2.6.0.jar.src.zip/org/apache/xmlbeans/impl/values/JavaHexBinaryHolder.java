/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlHexBinary;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*     */ import org.apache.xmlbeans.impl.util.HexBin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaHexBinaryHolder
/*     */   extends XmlObjectBase
/*     */ {
/*     */   protected byte[] _value;
/*     */   
/*     */   public SchemaType schemaType() {
/*  36 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_HEX_BINARY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String compute_text(NamespaceManager nsm) {
/*  45 */     return new String(HexBin.encode(this._value));
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*  49 */     this._hashcached = false;
/*  50 */     if (_validateOnSet()) {
/*  51 */       this._value = validateLexical(s, schemaType(), _voorVc);
/*     */     } else {
/*  53 */       this._value = lex(s, _voorVc);
/*     */     } 
/*     */   }
/*     */   protected void set_nil() {
/*  57 */     this._hashcached = false;
/*  58 */     this._value = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] lex(String v, ValidationContext context) {
/*  63 */     byte[] vBytes = null;
/*     */     
/*     */     try {
/*  66 */       vBytes = v.getBytes("UTF-8");
/*     */     }
/*  68 */     catch (UnsupportedEncodingException uee) {}
/*     */ 
/*     */ 
/*     */     
/*  72 */     byte[] bytes = HexBin.decode(vBytes);
/*     */     
/*  74 */     if (bytes == null)
/*     */     {
/*     */       
/*  77 */       context.invalid("hexBinary", new Object[] { "not encoded properly" });
/*     */     }
/*     */     
/*  80 */     return bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  85 */     byte[] bytes = lex(v, context);
/*     */     
/*  87 */     if (bytes == null) {
/*  88 */       return null;
/*     */     }
/*  90 */     if (!sType.matchPatternFacet(v)) {
/*     */       
/*  92 */       context.invalid("Hex encoded data does not match pattern for " + QNameHelper.readable(sType));
/*  93 */       return null;
/*     */     } 
/*     */     
/*  96 */     return bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getByteArrayValue() {
/* 101 */     check_dated();
/* 102 */     if (this._value == null) {
/* 103 */       return null;
/*     */     }
/* 105 */     byte[] result = new byte[this._value.length];
/* 106 */     System.arraycopy(this._value, 0, result, 0, this._value.length);
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_ByteArray(byte[] ba) {
/* 113 */     this._hashcached = false;
/* 114 */     this._value = new byte[ba.length];
/* 115 */     System.arraycopy(ba, 0, this._value, 0, ba.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject i) {
/* 121 */     byte[] ival = ((XmlHexBinary)i).getByteArrayValue();
/* 122 */     return Arrays.equals(this._value, ival);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _hashcached = false;
/* 127 */   protected int hashcode = 0;
/*     */   
/*     */   protected static MessageDigest md5;
/*     */   
/*     */   static {
/*     */     try {
/* 133 */       md5 = MessageDigest.getInstance("MD5");
/*     */     }
/* 135 */     catch (NoSuchAlgorithmException e) {
/*     */       
/* 137 */       throw new IllegalStateException("Cannot find MD5 hash Algorithm");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 143 */     if (this._hashcached) {
/* 144 */       return this.hashcode;
/*     */     }
/* 146 */     this._hashcached = true;
/*     */     
/* 148 */     if (this._value == null) {
/* 149 */       return this.hashcode = 0;
/*     */     }
/* 151 */     byte[] res = md5.digest(this._value);
/* 152 */     return this.hashcode = res[0] << 24 + res[1] << 16 + res[2] << 8 + res[3];
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaHexBinaryHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */