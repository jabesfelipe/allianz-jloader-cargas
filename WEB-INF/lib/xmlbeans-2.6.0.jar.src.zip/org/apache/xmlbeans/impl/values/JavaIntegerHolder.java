/*    */ package org.apache.xmlbeans.impl.values;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import org.apache.xmlbeans.SchemaType;
/*    */ import org.apache.xmlbeans.SimpleValue;
/*    */ import org.apache.xmlbeans.XmlObject;
/*    */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*    */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JavaIntegerHolder
/*    */   extends XmlObjectBase
/*    */ {
/*    */   private BigInteger _value;
/*    */   
/*    */   public SchemaType schemaType() {
/* 32 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_INTEGER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String compute_text(NamespaceManager nsm) {
/* 39 */     return this._value.toString();
/*    */   }
/*    */   protected void set_text(String s) {
/* 42 */     set_BigInteger(lex(s, _voorVc));
/*    */   }
/*    */   
/*    */   public static BigInteger lex(String s, ValidationContext vc) {
/* 46 */     if (s.length() > 0 && s.charAt(0) == '+')
/* 47 */       s = s.substring(1); 
/*    */     
/* 49 */     try { return new BigInteger(s); }
/* 50 */     catch (Exception e) { vc.invalid("integer", new Object[] { s }); return null; }
/*    */   
/*    */   }
/*    */   protected void set_nil() {
/* 54 */     this._value = null;
/*    */   }
/*    */   
/* 57 */   public BigDecimal getBigDecimalValue() { check_dated(); return (this._value == null) ? null : new BigDecimal(this._value); } public BigInteger getBigIntegerValue() {
/* 58 */     check_dated(); return this._value;
/*    */   }
/*    */   
/* 61 */   protected void set_BigDecimal(BigDecimal v) { this._value = v.toBigInteger(); } protected void set_BigInteger(BigInteger v) {
/* 62 */     this._value = v;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int compare_to(XmlObject i) {
/* 67 */     if (((SimpleValue)i).instanceType().getDecimalSize() > 1000000) {
/* 68 */       return -i.compareTo(this);
/*    */     }
/* 70 */     return this._value.compareTo(((XmlObjectBase)i).bigIntegerValue());
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean equal_to(XmlObject i) {
/* 75 */     if (((SimpleValue)i).instanceType().getDecimalSize() > 1000000) {
/* 76 */       return i.valueEquals(this);
/*    */     }
/* 78 */     return this._value.equals(((XmlObjectBase)i).bigIntegerValue());
/*    */   }
/*    */   
/* 81 */   private static BigInteger _maxlong = BigInteger.valueOf(Long.MAX_VALUE);
/* 82 */   private static BigInteger _minlong = BigInteger.valueOf(Long.MIN_VALUE);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int value_hash_code() {
/* 90 */     if (this._value.compareTo(_maxlong) > 0 || this._value.compareTo(_minlong) < 0)
/*    */     {
/* 92 */       return this._value.hashCode();
/*    */     }
/* 94 */     long longval = this._value.longValue();
/*    */     
/* 96 */     return (int)((longval >> 32L) * 19L + longval);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaIntegerHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */