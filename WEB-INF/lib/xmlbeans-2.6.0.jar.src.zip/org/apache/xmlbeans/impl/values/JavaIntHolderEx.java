/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaIntHolderEx
/*     */   extends JavaIntHolder
/*     */ {
/*     */   private SchemaType _schemaType;
/*     */   
/*     */   public JavaIntHolderEx(SchemaType type, boolean complex) {
/*  28 */     this._schemaType = type; initComplexType(complex, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SchemaType schemaType() {
/*  34 */     return this._schemaType;
/*     */   }
/*     */   
/*     */   protected void set_text(String s) {
/*     */     int v;
/*     */     
/*  40 */     try { v = XsTypeConverter.lexInt(s); }
/*  41 */     catch (Exception e) { throw new XmlValueOutOfRangeException(); }
/*     */     
/*  43 */     if (_validateOnSet()) {
/*     */       
/*  45 */       validateValue(v, this._schemaType, _voorVc);
/*  46 */       validateLexical(s, this._schemaType, _voorVc);
/*     */     } 
/*     */     
/*  49 */     super.set_int(v);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_int(int v) {
/*  54 */     if (_validateOnSet()) {
/*  55 */       validateValue(v, this._schemaType, _voorVc);
/*     */     }
/*  57 */     super.set_int(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void validateLexical(String v, SchemaType sType, ValidationContext context) {
/*  62 */     JavaDecimalHolder.validateLexical(v, context);
/*     */ 
/*     */     
/*  65 */     if (sType.hasPatternFacet())
/*     */     {
/*  67 */       if (!sType.matchPatternFacet(v))
/*     */       {
/*  69 */         context.invalid("cvc-datatype-valid.1.1", new Object[] { "int", v, QNameHelper.readable(sType) });
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void validateValue(int v, SchemaType sType, ValidationContext context) {
/*  78 */     XmlAnySimpleType xmlAnySimpleType1 = sType.getFacet(7);
/*  79 */     if (xmlAnySimpleType1 != null) {
/*     */       
/*  81 */       String temp = Integer.toString(v);
/*  82 */       int len = temp.length();
/*  83 */       if (len > 0 && temp.charAt(0) == '-')
/*  84 */         len--; 
/*  85 */       int m = getIntValue((XmlObject)xmlAnySimpleType1);
/*  86 */       if (len > m) {
/*     */         
/*  88 */         context.invalid("cvc-totalDigits-valid", new Object[] { new Integer(len), temp, new Integer(getIntValue((XmlObject)xmlAnySimpleType1)), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/*  95 */     XmlAnySimpleType xmlAnySimpleType2 = sType.getFacet(3);
/*  96 */     if (xmlAnySimpleType2 != null) {
/*     */       
/*  98 */       int m = getIntValue((XmlObject)xmlAnySimpleType2);
/*  99 */       if (v <= m) {
/*     */         
/* 101 */         context.invalid("cvc-minExclusive-valid", new Object[] { "int", new Integer(v), new Integer(m), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     XmlAnySimpleType xmlAnySimpleType3 = sType.getFacet(4);
/* 109 */     if (xmlAnySimpleType3 != null) {
/*     */       
/* 111 */       int m = getIntValue((XmlObject)xmlAnySimpleType3);
/* 112 */       if (v < m) {
/*     */         
/* 114 */         context.invalid("cvc-minInclusive-valid", new Object[] { "int", new Integer(v), new Integer(m), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     XmlAnySimpleType xmlAnySimpleType4 = sType.getFacet(5);
/* 122 */     if (xmlAnySimpleType4 != null) {
/*     */       
/* 124 */       int m = getIntValue((XmlObject)xmlAnySimpleType4);
/* 125 */       if (v > m) {
/*     */         
/* 127 */         context.invalid("cvc-maxExclusive-valid", new Object[] { "int", new Integer(v), new Integer(m), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 134 */     XmlAnySimpleType xmlAnySimpleType5 = sType.getFacet(6);
/* 135 */     if (xmlAnySimpleType5 != null) {
/*     */       
/* 137 */       int m = getIntValue((XmlObject)xmlAnySimpleType5);
/* 138 */       if (v >= m) {
/*     */         
/* 140 */         context.invalid("cvc-maxExclusive-valid", new Object[] { "int", new Integer(v), new Integer(m), QNameHelper.readable(sType) });
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 147 */     XmlAnySimpleType[] arrayOfXmlAnySimpleType = sType.getEnumerationValues();
/* 148 */     if (arrayOfXmlAnySimpleType != null) {
/*     */       
/* 150 */       for (int i = 0; i < arrayOfXmlAnySimpleType.length; i++) {
/*     */         
/* 152 */         if (v == getIntValue((XmlObject)arrayOfXmlAnySimpleType[i]))
/*     */           return; 
/*     */       } 
/* 155 */       context.invalid("cvc-enumeration-valid", new Object[] { "int", new Integer(v), QNameHelper.readable(sType) });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static int getIntValue(XmlObject o) {
/* 161 */     SchemaType s = o.schemaType();
/* 162 */     switch (s.getDecimalSize()) {
/*     */       
/*     */       case 1000001:
/* 165 */         return ((XmlObjectBase)o).getBigDecimalValue().intValue();
/*     */       case 1000000:
/* 167 */         return ((XmlObjectBase)o).getBigIntegerValue().intValue();
/*     */       case 64:
/* 169 */         return (int)((XmlObjectBase)o).getLongValue();
/*     */     } 
/* 171 */     return ((XmlObjectBase)o).getIntValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validate_simpleval(String lexical, ValidationContext ctx) {
/* 178 */     validateLexical(lexical, schemaType(), ctx);
/* 179 */     validateValue(getIntValue(), schemaType(), ctx);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaIntHolderEx.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */