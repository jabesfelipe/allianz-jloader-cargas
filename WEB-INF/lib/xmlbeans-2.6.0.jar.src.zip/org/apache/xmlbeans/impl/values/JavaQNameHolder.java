/*     */ package org.apache.xmlbeans.impl.values;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.SchemaType;
/*     */ import org.apache.xmlbeans.XmlAnySimpleType;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ import org.apache.xmlbeans.impl.common.PrefixResolver;
/*     */ import org.apache.xmlbeans.impl.common.QNameHelper;
/*     */ import org.apache.xmlbeans.impl.common.ValidationContext;
/*     */ import org.apache.xmlbeans.impl.common.XMLChar;
/*     */ import org.apache.xmlbeans.impl.schema.BuiltinSchemaTypeSystem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaQNameHolder
/*     */   extends XmlObjectBase
/*     */ {
/*     */   private QName _value;
/*     */   
/*     */   public SchemaType schemaType() {
/*  36 */     return (SchemaType)BuiltinSchemaTypeSystem.ST_QNAME;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int get_wscanon_rule() {
/*  41 */     return 1;
/*     */   }
/*     */   
/*  44 */   private static final NamespaceManager PRETTY_PREFIXER = new PrettyNamespaceManager();
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   private static class PrettyNamespaceManager
/*     */     implements NamespaceManager {
/*     */     public String find_prefix_for_nsuri(String nsuri, String suggested_prefix) {
/*  50 */       return QNameHelper.suggestPrefix(nsuri);
/*     */     }
/*     */     private PrettyNamespaceManager() {}
/*     */     public String getNamespaceForPrefix(String prefix) {
/*  54 */       throw new RuntimeException("Should not be called");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String compute_text(NamespaceManager nsm) {
/*  61 */     if (nsm == null)
/*     */     {
/*     */ 
/*     */       
/*  65 */       nsm = PRETTY_PREFIXER;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     String namespace = this._value.getNamespaceURI();
/*  74 */     String localPart = this._value.getLocalPart();
/*     */     
/*  76 */     if (namespace == null || namespace.length() == 0) {
/*  77 */       return localPart;
/*     */     }
/*  79 */     String prefix = nsm.find_prefix_for_nsuri(namespace, null);
/*     */     
/*  81 */     assert prefix != null;
/*     */     
/*  83 */     return "".equals(prefix) ? localPart : (prefix + ":" + localPart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName validateLexical(String v, ValidationContext context, PrefixResolver resolver) {
/*     */     QName qName;
/*     */     try {
/*  93 */       qName = parse(v, resolver);
/*     */     }
/*  95 */     catch (XmlValueOutOfRangeException e) {
/*     */       
/*  97 */       context.invalid(e.getMessage());
/*  98 */       qName = null;
/*     */     } 
/*     */     
/* 101 */     return qName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static QName parse(String v, PrefixResolver resolver) {
/*     */     String prefix, localname;
/*     */     int end;
/* 109 */     for (end = v.length(); end > 0 && 
/* 110 */       XMLChar.isSpace(v.charAt(end - 1)); end--);
/*     */     int start;
/* 112 */     for (start = 0; start < end && 
/* 113 */       XMLChar.isSpace(v.charAt(start)); start++);
/*     */ 
/*     */     
/* 116 */     int firstcolon = v.indexOf(':', start);
/* 117 */     if (firstcolon >= 0) {
/*     */       
/* 119 */       prefix = v.substring(start, firstcolon);
/* 120 */       localname = v.substring(firstcolon + 1, end);
/*     */     }
/*     */     else {
/*     */       
/* 124 */       prefix = "";
/* 125 */       localname = v.substring(start, end);
/*     */     } 
/*     */     
/* 128 */     if (prefix.length() > 0 && !XMLChar.isValidNCName(prefix)) {
/* 129 */       throw new XmlValueOutOfRangeException("QName", new Object[] { "Prefix not a valid NCName in '" + v + "'" });
/*     */     }
/* 131 */     if (!XMLChar.isValidNCName(localname)) {
/* 132 */       throw new XmlValueOutOfRangeException("QName", new Object[] { "Localname not a valid NCName in '" + v + "'" });
/*     */     }
/* 134 */     String uri = (resolver == null) ? null : resolver.getNamespaceForPrefix(prefix);
/*     */ 
/*     */     
/* 137 */     if (uri == null) {
/*     */       
/* 139 */       if (prefix.length() > 0) {
/* 140 */         throw new XmlValueOutOfRangeException("QName", new Object[] { "Can't resolve prefix '" + prefix + "'" });
/*     */       }
/* 142 */       uri = "";
/*     */     } 
/*     */     
/* 145 */     if (prefix != null && prefix.length() > 0) {
/* 146 */       return new QName(uri, localname, prefix);
/*     */     }
/* 148 */     return new QName(uri, localname);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_text(String s) {
/* 153 */     PrefixResolver resolver = NamespaceContext.getCurrent();
/*     */     
/* 155 */     if (resolver == null && has_store()) {
/* 156 */       resolver = get_store();
/*     */     }
/* 158 */     this._value = parse(s, resolver);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set_QName(QName name) {
/* 164 */     assert name != null;
/*     */ 
/*     */ 
/*     */     
/* 168 */     if (has_store()) {
/* 169 */       get_store().find_prefix_for_nsuri(name.getNamespaceURI(), null);
/*     */     }
/* 171 */     this._value = name;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void set_xmlanysimple(XmlAnySimpleType value) {
/* 176 */     this._value = parse(value.getStringValue(), NamespaceContext.getCurrent());
/*     */   }
/*     */   protected void set_nil() {
/* 179 */     this._value = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getQNameValue() {
/* 185 */     check_dated();
/* 186 */     return this._value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equal_to(XmlObject obj) {
/* 192 */     return this._value.equals(((XmlObjectBase)obj).qNameValue());
/*     */   }
/*     */ 
/*     */   
/*     */   protected int value_hash_code() {
/* 197 */     return this._value.hashCode();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\values\JavaQNameHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */