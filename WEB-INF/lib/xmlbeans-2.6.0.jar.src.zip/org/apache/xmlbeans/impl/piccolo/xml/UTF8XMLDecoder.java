/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.CharsetDecoder;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.IllegalCharException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UTF8XMLDecoder
/*     */   implements XMLDecoder
/*     */ {
/*     */   private boolean sawCR = false;
/*     */   
/*     */   public CharsetDecoder newCharsetDecoder() {
/*  39 */     return newXMLDecoder(); } public XMLDecoder newXMLDecoder() {
/*  40 */     return new UTF8XMLDecoder();
/*     */   }
/*     */   public int minBytesPerChar() {
/*  43 */     return 1;
/*     */   }
/*     */   
/*     */   public int maxBytesPerChar() {
/*  47 */     return 3;
/*     */   }
/*     */   public void reset() {
/*  50 */     this.sawCR = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decode(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*  56 */     int o = 0, i = o; while (true) { if (i < in_len && o < out_len) {
/*     */ 
/*     */ 
/*     */         
/*  60 */         int c = in_buf[in_off + i];
/*     */ 
/*     */         
/*  63 */         if ((c & 0x80) != 0) {
/*     */           int c2;
/*     */ 
/*     */ 
/*     */           
/*  68 */           if (++i < in_len) {
/*  69 */             c2 = in_buf[in_off + i];
/*     */           } else {
/*  71 */             result[0] = i - 1;
/*  72 */             result[1] = o;
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*  77 */           if ((c & 0xE0) == 192) {
/*     */             
/*  79 */             if ((c2 & 0x80) != 128) {
/*  80 */               throw new CharConversionException("Malformed UTF-8 character: 0x" + Integer.toHexString(c & 0xFF) + " 0x" + Integer.toHexString(c2 & 0xFF));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*  85 */             c = (c & 0x1F) << 6 | c2 & 0x3F;
/*     */ 
/*     */             
/*  88 */             if ((c & 0x780) == 0) {
/*  89 */               throw new CharConversionException("2-byte UTF-8 character is overlong: 0x" + Integer.toHexString(in_buf[in_off + i - 1] & 0xFF) + " 0x" + Integer.toHexString(c2 & 0xFF));
/*     */ 
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/*  96 */           else if ((c & 0xF0) == 224) {
/*  97 */             int c3; if (++i < in_len) {
/*  98 */               c3 = in_buf[in_off + i];
/*     */             } else {
/* 100 */               result[0] = i - 2;
/* 101 */               result[1] = o;
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/* 106 */             if ((c2 & 0x80) != 128 || (c3 & 0x80) != 128)
/*     */             {
/* 108 */               throw new CharConversionException("Malformed UTF-8 character: 0x" + Integer.toHexString(c & 0xFF) + " 0x" + Integer.toHexString(c2 & 0xFF) + " 0x" + Integer.toHexString(c3 & 0xFF));
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 115 */             c = (c & 0xF) << 12 | (c2 & 0x3F) << 6 | c3 & 0x3F;
/*     */ 
/*     */             
/* 118 */             if ((c & 0xF800) == 0) {
/* 119 */               throw new CharConversionException("3-byte UTF-8 character is overlong: 0x" + Integer.toHexString(in_buf[in_off + i - 2] & 0xFF) + " 0x" + Integer.toHexString(c2 & 0xFF) + " 0x" + Integer.toHexString(c3 & 0xFF));
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 126 */             if ((c & 0xF0) == 240) {
/* 127 */               int c3, c4; if (i + 2 < in_len) {
/* 128 */                 c3 = in_buf[in_off + ++i];
/* 129 */                 c4 = in_buf[in_off + ++i];
/*     */               } else {
/*     */                 
/* 132 */                 result[0] = i - 2;
/* 133 */                 result[1] = o;
/*     */                 
/*     */                 return;
/*     */               } 
/*     */               
/* 138 */               if ((c2 & 0x80) != 128 || (c3 & 0x80) != 128 || (c4 & 0x80) != 128)
/*     */               {
/*     */                 
/* 141 */                 throw new CharConversionException("Malformed UTF-8 character: 0x" + Integer.toHexString(c & 0xFF) + " 0x" + Integer.toHexString(c2 & 0xFF) + " 0x" + Integer.toHexString(c3 & 0xFF) + " 0x" + Integer.toHexString(c4 & 0xFF));
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 148 */               c = (c & 0x7) << 18 | (c2 & 0x3F) << 12 | (c3 & 0x3F) << 6 | c4 & 0x3F;
/*     */               
/* 150 */               if (c < 65536 || c > 1114111) {
/* 151 */                 throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */               }
/*     */ 
/*     */               
/* 155 */               c -= 65536;
/* 156 */               out_buf[out_off + o++] = (char)(c >> 10 | 0xD800);
/* 157 */               out_buf[out_off + o++] = (char)(c & 0x3FF | 0xDC00);
/* 158 */               this.sawCR = false;
/*     */             }
/*     */             else {
/*     */               
/* 162 */               throw new CharConversionException("Characters larger than 4 bytes are not supported: byte 0x" + Integer.toHexString(c & 0xFF) + " implies a length of more than 4 bytes");
/*     */             } 
/*     */             i++;
/*     */           } 
/* 166 */           if ((c >= 55296 && c < 57344) || c == 65534 || c == 65535)
/*     */           {
/* 168 */             throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */           }
/*     */         } 
/*     */         
/* 172 */         if (c >= 32) {
/* 173 */           this.sawCR = false;
/* 174 */           out_buf[out_off + o++] = (char)c;
/*     */         } else {
/*     */           
/* 177 */           switch (c) {
/*     */             case 10:
/* 179 */               if (this.sawCR) {
/* 180 */                 this.sawCR = false;
/*     */                 break;
/*     */               } 
/* 183 */               out_buf[out_off + o++] = '\n';
/*     */               break;
/*     */             
/*     */             case 13:
/* 187 */               this.sawCR = true;
/* 188 */               out_buf[out_off + o++] = '\n';
/*     */               break;
/*     */             
/*     */             case 9:
/* 192 */               out_buf[out_off + o++] = '\t';
/*     */               break;
/*     */             
/*     */             default:
/* 196 */               throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       }  i++; }
/* 202 */      result[0] = i;
/* 203 */     result[1] = o;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeXMLDecl(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*     */     int i;
/*     */     int o;
/* 211 */     for (i = o = 0; i < in_len && o < out_len; i++) {
/*     */ 
/*     */       
/* 214 */       int c = in_buf[in_off + i];
/*     */ 
/*     */ 
/*     */       
/* 218 */       if ((c & 0x80) != 0) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 224 */       if (c >= 32) {
/* 225 */         this.sawCR = false;
/* 226 */         out_buf[out_off + o++] = (char)c;
/*     */ 
/*     */ 
/*     */         
/* 230 */         if (c == 62) {
/* 231 */           i++;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } else {
/* 236 */         switch (c) {
/*     */           case 10:
/* 238 */             if (this.sawCR) {
/* 239 */               this.sawCR = false;
/*     */               break;
/*     */             } 
/* 242 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case 13:
/* 246 */             this.sawCR = true;
/* 247 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case 9:
/* 251 */             out_buf[out_off + o++] = '\t';
/*     */             break;
/*     */           
/*     */           default:
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 260 */     result[0] = i;
/* 261 */     result[1] = o;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\UTF8XMLDecoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */