/*    */ package org.apache.xmlbeans.impl.piccolo.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileFormatException
/*    */   extends IOException
/*    */ {
/*    */   protected int line;
/*    */   protected int column;
/*    */   
/*    */   public FileFormatException() {
/* 26 */     this(null);
/*    */   }
/*    */   
/*    */   public FileFormatException(String msg) {
/* 30 */     this(msg, -1, -1);
/*    */   }
/*    */   
/*    */   public FileFormatException(String msg, int line, int column) {
/* 34 */     super(msg);
/* 35 */     this.line = line;
/* 36 */     this.column = column;
/*    */   }
/*    */   
/*    */   public int getLine() {
/* 40 */     return this.line;
/*    */   }
/*    */   public int getColumn() {
/* 43 */     return this.column;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\io\FileFormatException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */