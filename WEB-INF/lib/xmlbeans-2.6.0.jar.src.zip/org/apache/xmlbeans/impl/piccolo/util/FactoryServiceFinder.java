/*    */ package org.apache.xmlbeans.impl.piccolo.util;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FactoryServiceFinder
/*    */ {
/*    */   static final String SERVICE = "META-INF/services/";
/*    */   
/*    */   public static String findService(String name) throws IOException {
/* 39 */     InputStream is = ClassLoader.getSystemClassLoader().getResourceAsStream("META-INF/services/" + name);
/*    */ 
/*    */     
/* 42 */     BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/*    */     
/* 44 */     return r.readLine();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Enumeration findServices(String name) throws IOException {
/* 52 */     return new FactoryEnumeration(ClassLoader.getSystemClassLoader().getResources(name));
/*    */   }
/*    */   
/*    */   private static class FactoryEnumeration
/*    */     implements Enumeration {
/*    */     Enumeration enumValue;
/* 58 */     Object next = null;
/*    */     
/*    */     FactoryEnumeration(Enumeration enumValue) {
/* 61 */       this.enumValue = enumValue;
/* 62 */       nextElement();
/*    */     }
/*    */     
/*    */     public boolean hasMoreElements() {
/* 66 */       return (this.next != null);
/*    */     }
/*    */     
/*    */     public Object nextElement() {
/* 70 */       Object current = this.next;
/*    */       
/*    */       while (true) {
/*    */         try {
/* 74 */           if (this.enumValue.hasMoreElements()) {
/* 75 */             BufferedReader r = new BufferedReader(new InputStreamReader(((URL)this.enumValue.nextElement()).openStream()));
/*    */ 
/*    */             
/* 78 */             this.next = r.readLine();
/*    */             break;
/*    */           } 
/* 81 */           this.next = null;
/*    */ 
/*    */           
/*    */           break;
/* 85 */         } catch (IOException e) {}
/*    */       } 
/*    */ 
/*    */ 
/*    */       
/* 90 */       return current;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccol\\util\FactoryServiceFinder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */