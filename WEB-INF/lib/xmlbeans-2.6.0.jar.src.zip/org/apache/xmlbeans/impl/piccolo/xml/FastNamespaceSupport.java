/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import org.apache.xmlbeans.impl.piccolo.util.IntStack;
/*     */ import org.apache.xmlbeans.impl.piccolo.util.StringStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastNamespaceSupport
/*     */ {
/*     */   public static final String XMLNS = "http://www.w3.org/XML/1998/namespace";
/*  43 */   private String[] prefixes = new String[20];
/*  44 */   private String[] uris = new String[20];
/*     */   
/*     */   private int prefixPos;
/*     */   
/*     */   private String defaultURI;
/*  49 */   private StringStack defaultURIs = new StringStack(20);
/*     */   
/*     */   private int prefixCount;
/*     */   
/*  53 */   private IntStack contextPrefixCounts = new IntStack(20);
/*     */ 
/*     */   
/*     */   private int defaultURIContexts;
/*     */   
/*  58 */   private IntStack defaultURIContextCounts = new IntStack(20);
/*     */   
/*     */   public FastNamespaceSupport() {
/*  61 */     reset();
/*     */   }
/*     */   
/*     */   public void reset() {
/*  65 */     this.defaultURIs.clear();
/*  66 */     this.contextPrefixCounts.clear();
/*  67 */     this.defaultURIContextCounts.clear();
/*     */     
/*  69 */     this.prefixPos = -1;
/*  70 */     this.defaultURI = "";
/*  71 */     this.prefixCount = 0;
/*  72 */     this.defaultURIContexts = 0;
/*     */   }
/*     */   
/*     */   public void pushContext() {
/*  76 */     this.defaultURIContexts++;
/*     */     
/*  78 */     this.contextPrefixCounts.push(this.prefixCount);
/*  79 */     this.prefixCount = 0;
/*     */   }
/*     */   
/*     */   public void popContext() {
/*  83 */     if (this.defaultURIContexts <= 0) {
/*  84 */       this.defaultURIContexts = this.defaultURIContextCounts.pop();
/*  85 */       this.defaultURI = this.defaultURIs.pop();
/*     */     } else {
/*  87 */       this.defaultURIContexts--;
/*     */     } 
/*  89 */     this.prefixPos -= this.prefixCount;
/*  90 */     this.prefixCount = this.contextPrefixCounts.pop();
/*     */   }
/*     */   
/*     */   public void declarePrefix(String prefix, String uri) {
/*  94 */     if (prefix.length() == 0) {
/*  95 */       this.defaultURIContexts--;
/*  96 */       this.defaultURIContextCounts.push(this.defaultURIContexts);
/*  97 */       this.defaultURIs.push(this.defaultURI);
/*  98 */       this.defaultURIContexts = 0;
/*  99 */       this.defaultURI = uri;
/*     */     } else {
/*     */       
/* 102 */       for (int i = 0; i < this.prefixCount; i++) {
/* 103 */         if (prefix == this.prefixes[this.prefixPos - i]) {
/* 104 */           this.uris[this.prefixPos - i] = uri;
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */       
/* 110 */       this.prefixPos++;
/* 111 */       this.prefixCount++;
/*     */ 
/*     */       
/* 114 */       if (this.prefixPos >= this.prefixes.length) {
/* 115 */         int oldLength = this.prefixes.length;
/* 116 */         int newLength = oldLength * 2;
/* 117 */         String[] newPrefixes = new String[newLength];
/* 118 */         String[] newURIs = new String[newLength];
/* 119 */         System.arraycopy(this.prefixes, 0, newPrefixes, 0, oldLength);
/* 120 */         System.arraycopy(this.uris, 0, newURIs, 0, oldLength);
/* 121 */         this.prefixes = newPrefixes;
/* 122 */         this.uris = newURIs;
/*     */       } 
/*     */       
/* 125 */       this.prefixes[this.prefixPos] = prefix;
/* 126 */       this.uris[this.prefixPos] = uri;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] processName(String qName, String[] parts, boolean isAttribute) {
/* 133 */     int colon = qName.indexOf(':');
/* 134 */     parts[2] = qName;
/* 135 */     if (colon < 0) {
/* 136 */       parts[1] = qName;
/*     */       
/* 138 */       if (isAttribute) {
/* 139 */         parts[0] = "";
/*     */       } else {
/* 141 */         parts[0] = this.defaultURI;
/* 142 */       }  return parts;
/*     */     } 
/* 144 */     String prefix = qName.substring(0, colon);
/* 145 */     parts[1] = qName.substring(colon + 1);
/* 146 */     parts[0] = getURI(prefix); if (getURI(prefix) == "") {
/* 147 */       return null;
/*     */     }
/* 149 */     return parts;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultURI() {
/* 155 */     return this.defaultURI;
/*     */   }
/*     */   
/*     */   public String getURI(String prefix) {
/* 159 */     if (prefix == null || prefix.length() == 0)
/* 160 */       return this.defaultURI; 
/* 161 */     if (prefix == "xml") {
/* 162 */       return "http://www.w3.org/XML/1998/namespace";
/*     */     }
/* 164 */     for (int i = this.prefixPos; i >= 0; i--) {
/* 165 */       if (prefix == this.prefixes[i])
/* 166 */         return this.uris[i]; 
/*     */     } 
/* 168 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public int getContextSize() {
/* 173 */     return this.prefixCount + ((this.defaultURIContexts == 0 && this.defaultURI != "") ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContextPrefix(int index) {
/* 179 */     if (index == this.prefixCount && this.defaultURIContexts == 0 && this.defaultURI != "")
/*     */     {
/* 181 */       return "";
/*     */     }
/* 183 */     return this.prefixes[this.prefixPos - index];
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContextURI(int index) {
/* 188 */     if (index == this.prefixCount && this.defaultURIContexts == 0 && this.defaultURI != "")
/*     */     {
/* 190 */       return this.defaultURI;
/*     */     }
/* 192 */     return this.uris[this.prefixPos - index];
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\FastNamespaceSupport.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */