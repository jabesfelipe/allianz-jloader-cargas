/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.CharsetDecoder;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.IllegalCharException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnicodeBigXMLDecoder
/*     */   implements XMLDecoder
/*     */ {
/*     */   private boolean sawCR = false;
/*     */   
/*     */   public CharsetDecoder newCharsetDecoder() {
/*  39 */     return newXMLDecoder(); } public XMLDecoder newXMLDecoder() {
/*  40 */     return new UnicodeBigXMLDecoder();
/*     */   }
/*     */   public int minBytesPerChar() {
/*  43 */     return 2;
/*     */   }
/*     */   
/*     */   public int maxBytesPerChar() {
/*  47 */     return 2;
/*     */   }
/*     */   public void reset() {
/*  50 */     this.sawCR = false;
/*     */   }
/*     */   public void decode(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*     */     int i;
/*     */     int o;
/*  55 */     for (i = o = 0; i + 1 < in_len && o < out_len; i += 2) {
/*  56 */       char c = (char)((0xFF & in_buf[in_off + i]) << 8 | 0xFF & in_buf[in_off + i + 1]);
/*     */       
/*  58 */       if (c >= ' ') {
/*  59 */         if (c <= '퟿' || (c >= '' && c <= '�') || (c >= 65536 && c <= 1114111)) {
/*     */ 
/*     */           
/*  62 */           this.sawCR = false;
/*  63 */           out_buf[out_off + o++] = c;
/*     */         } else {
/*     */           
/*  66 */           throw new IllegalCharException("Illegal XML Character: 0x" + Integer.toHexString(c));
/*     */         } 
/*     */       } else {
/*     */         
/*  70 */         switch (c) {
/*     */           case '\n':
/*  72 */             if (this.sawCR) {
/*  73 */               this.sawCR = false;
/*     */               break;
/*     */             } 
/*  76 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\r':
/*  80 */             this.sawCR = true;
/*  81 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\t':
/*  85 */             out_buf[out_off + o++] = '\t';
/*     */             break;
/*     */           
/*     */           default:
/*  89 */             throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/*  95 */     result[0] = i;
/*  96 */     result[1] = o;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeXMLDecl(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*     */     int i;
/*     */     int o;
/* 104 */     for (i = o = 0; i + 1 < in_len && o < out_len; i += 2) {
/* 105 */       char c = (char)((0xFF & in_buf[in_off + i]) << 8 | 0xFF & in_buf[in_off + i + 1]);
/*     */       
/* 107 */       if (c >= ' ') {
/* 108 */         if (c <= '퟿' || (c >= '' && c <= '�') || (c >= 65536 && c <= 1114111)) {
/*     */ 
/*     */           
/* 111 */           this.sawCR = false;
/* 112 */           out_buf[out_off + o++] = c;
/*     */ 
/*     */           
/* 115 */           if (c == '>') {
/* 116 */             i += 2;
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } else {
/*     */           break;
/*     */         } 
/*     */       } else {
/* 126 */         switch (c) {
/*     */           case '\n':
/* 128 */             if (this.sawCR) {
/* 129 */               this.sawCR = false;
/*     */               break;
/*     */             } 
/* 132 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\r':
/* 136 */             this.sawCR = true;
/* 137 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\t':
/* 141 */             out_buf[out_off + o++] = '\t';
/*     */             break;
/*     */           
/*     */           default:
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 150 */     result[0] = i;
/* 151 */     result[1] = o;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\UnicodeBigXMLDecoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */