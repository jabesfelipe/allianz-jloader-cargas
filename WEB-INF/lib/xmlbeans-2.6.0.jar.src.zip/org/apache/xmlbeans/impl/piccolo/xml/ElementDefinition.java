/*    */ package org.apache.xmlbeans.impl.piccolo.xml;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.xmlbeans.impl.piccolo.util.DuplicateKeyException;
/*    */ import org.apache.xmlbeans.impl.piccolo.util.IndexedObject;
/*    */ import org.apache.xmlbeans.impl.piccolo.util.IndexedObjectImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ElementDefinition
/*    */ {
/*    */   String name;
/*    */   AttributeDefinition[] attributes;
/*    */   Map attributeMap;
/* 37 */   int size = 0;
/*    */   
/*    */   public ElementDefinition() {
/* 40 */     this(null);
/*    */   }
/*    */   
/*    */   public ElementDefinition(String name) {
/* 44 */     this.name = name;
/* 45 */     this.attributes = new AttributeDefinition[4];
/* 46 */     this.attributeMap = new HashMap();
/* 47 */     this.size = 0;
/*    */   }
/*    */   
/*    */   public final String getName() {
/* 51 */     return this.name;
/*    */   }
/*    */   
/*    */   public final void setName(String name) {
/* 55 */     this.name = name;
/*    */   }
/*    */   
/*    */   public final AttributeDefinition[] getAttributes() {
/* 59 */     return this.attributes;
/*    */   }
/*    */   
/*    */   public final int getAttributeCount() {
/* 63 */     return this.size;
/*    */   }
/*    */   
/*    */   public final IndexedObject getIndexedAttribute(String name) {
/* 67 */     return (IndexedObject)this.attributeMap.get(name);
/*    */   }
/*    */   
/*    */   public final AttributeDefinition getAttribute(int index) {
/* 71 */     return this.attributes[index];
/*    */   }
/*    */   
/*    */   public final void addAttribute(AttributeDefinition attrib) throws DuplicateKeyException {
/* 75 */     Object newObj = new IndexedObjectImpl(this.size, attrib);
/* 76 */     Object oldObj = this.attributeMap.put(attrib.getQName(), newObj);
/*    */ 
/*    */     
/* 79 */     if (oldObj != null) {
/* 80 */       this.attributeMap.put(attrib.getQName(), oldObj);
/* 81 */       throw new DuplicateKeyException("attribute '" + attrib.getQName() + "' is already defined for element '" + this.name + "'.");
/*    */     } 
/*    */ 
/*    */     
/* 85 */     if (this.size >= this.attributes.length) {
/* 86 */       AttributeDefinition[] newAttributes = new AttributeDefinition[this.size * 2];
/* 87 */       System.arraycopy(this.attributes, 0, newAttributes, 0, this.size);
/* 88 */       this.attributes = newAttributes;
/*    */     } 
/* 90 */     this.attributes[this.size++] = attrib;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\ElementDefinition.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */