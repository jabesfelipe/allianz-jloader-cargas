/*    */ package org.apache.xmlbeans.impl.piccolo.io;
/*    */ 
/*    */ import java.io.CharConversionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalCharException
/*    */   extends CharConversionException
/*    */ {
/*    */   protected int line;
/*    */   protected int column;
/*    */   
/*    */   public IllegalCharException(String msg) {
/* 28 */     super(msg);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\io\IllegalCharException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */