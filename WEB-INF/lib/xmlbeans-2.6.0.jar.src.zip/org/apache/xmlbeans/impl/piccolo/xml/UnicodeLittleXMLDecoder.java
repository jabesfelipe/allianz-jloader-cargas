/*     */ package org.apache.xmlbeans.impl.piccolo.xml;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.CharsetDecoder;
/*     */ import org.apache.xmlbeans.impl.piccolo.io.IllegalCharException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnicodeLittleXMLDecoder
/*     */   implements XMLDecoder
/*     */ {
/*     */   private boolean sawCR = false;
/*     */   
/*     */   public CharsetDecoder newCharsetDecoder() {
/*  40 */     return newXMLDecoder(); } public XMLDecoder newXMLDecoder() {
/*  41 */     return new UnicodeLittleXMLDecoder();
/*     */   }
/*     */   public int minBytesPerChar() {
/*  44 */     return 2;
/*     */   }
/*     */   
/*     */   public int maxBytesPerChar() {
/*  48 */     return 2;
/*     */   }
/*     */   public void reset() {
/*  51 */     this.sawCR = false;
/*     */   }
/*     */   public void decode(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*     */     int i;
/*     */     int o;
/*  56 */     for (i = o = 0; i + 1 < in_len && o < out_len; i += 2) {
/*  57 */       char c = (char)((0xFF & in_buf[in_off + i + 1]) << 8 | 0xFF & in_buf[in_off + i]);
/*     */ 
/*     */       
/*  60 */       if (c >= ' ') {
/*  61 */         if (c <= '퟿' || (c >= '' && c <= '�') || (c >= 65536 && c <= 1114111)) {
/*     */ 
/*     */           
/*  64 */           this.sawCR = false;
/*  65 */           out_buf[out_off + o++] = c;
/*     */         } else {
/*     */           
/*  68 */           throw new IllegalCharException("Illegal XML Character: 0x" + Integer.toHexString(c));
/*     */         } 
/*     */       } else {
/*     */         
/*  72 */         switch (c) {
/*     */           case '\n':
/*  74 */             if (this.sawCR) {
/*  75 */               this.sawCR = false;
/*     */               break;
/*     */             } 
/*  78 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\r':
/*  82 */             this.sawCR = true;
/*  83 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\t':
/*  87 */             out_buf[out_off + o++] = '\t';
/*     */             break;
/*     */           
/*     */           default:
/*  91 */             throw new IllegalCharException("Illegal XML character: 0x" + Integer.toHexString(c));
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/*  97 */     result[0] = i;
/*  98 */     result[1] = o;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeXMLDecl(byte[] in_buf, int in_off, int in_len, char[] out_buf, int out_off, int out_len, int[] result) throws CharConversionException {
/*     */     int i;
/*     */     int o;
/* 106 */     for (i = o = 0; i + 1 < in_len && o < out_len; i += 2) {
/* 107 */       char c = (char)((0xFF & in_buf[in_off + i + 1]) << 8 | 0xFF & in_buf[in_off + i]);
/*     */ 
/*     */       
/* 110 */       if (c >= ' ') {
/* 111 */         if (c <= '퟿' || (c >= '' && c <= '�') || (c >= 65536 && c <= 1114111)) {
/*     */ 
/*     */           
/* 114 */           this.sawCR = false;
/* 115 */           out_buf[out_off + o++] = c;
/*     */ 
/*     */           
/* 118 */           if (c == '>') {
/* 119 */             i += 2;
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } else {
/*     */           break;
/*     */         } 
/*     */       } else {
/* 129 */         switch (c) {
/*     */           case '\n':
/* 131 */             if (this.sawCR) {
/* 132 */               this.sawCR = false;
/*     */               break;
/*     */             } 
/* 135 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\r':
/* 139 */             this.sawCR = true;
/* 140 */             out_buf[out_off + o++] = '\n';
/*     */             break;
/*     */           
/*     */           case '\t':
/* 144 */             out_buf[out_off + o++] = '\t';
/*     */             break;
/*     */           
/*     */           default:
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 153 */     result[0] = i;
/* 154 */     result[1] = o;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccolo\xml\UnicodeLittleXMLDecoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */