/*    */ package org.apache.xmlbeans.impl.piccolo.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringStack
/*    */ {
/*    */   private String[] stack;
/*    */   private int pos;
/*    */   
/*    */   public StringStack(int initialSize) {
/* 30 */     this.stack = new String[initialSize];
/* 31 */     this.pos = -1;
/*    */   }
/*    */   
/*    */   public String pop() {
/* 35 */     if (this.pos >= 0) {
/* 36 */       return this.stack[this.pos--];
/*    */     }
/*    */     
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void push(String s) {
/* 44 */     if (this.pos + 1 < this.stack.length) {
/* 45 */       this.stack[++this.pos] = s;
/*    */     } else {
/*    */       
/* 48 */       setSize(this.stack.length * 2);
/* 49 */       this.stack[++this.pos] = s;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setSize(int newSize) {
/* 54 */     if (newSize != this.stack.length) {
/* 55 */       String[] newStack = new String[newSize];
/* 56 */       System.arraycopy(this.stack, 0, newStack, 0, Math.min(this.stack.length, newSize));
/* 57 */       this.stack = newStack;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void clear() {
/* 62 */     this.pos = -1;
/*    */   }
/*    */   
/*    */   public int size() {
/* 66 */     return this.pos + 1;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\piccol\\util\StringStack.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */