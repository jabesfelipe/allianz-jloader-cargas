/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.xmlbeans.SystemProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XBeanDebug
/*     */ {
/*     */   public static final int TRACE_SCHEMA_LOADING = 1;
/*     */   public static final String traceProp = "org.apache.xmlbeans.impl.debug";
/*     */   public static final String defaultProp = "";
/*  31 */   private static int _enabled = initializeBitsFromProperty();
/*  32 */   private static int _indent = 0;
/*  33 */   private static String _indentspace = "                                                                                ";
/*     */   static PrintStream _err;
/*     */   
/*     */   private static int initializeBitsFromProperty() {
/*  37 */     int bits = 0;
/*  38 */     String prop = SystemProperties.getProperty("org.apache.xmlbeans.impl.debug", "");
/*  39 */     if (prop.indexOf("TRACE_SCHEMA_LOADING") >= 0)
/*  40 */       bits |= 0x1; 
/*  41 */     return bits;
/*     */   }
/*     */   
/*     */   public static void enable(int bits) {
/*  45 */     _enabled |= bits;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void disable(int bits) {
/*  50 */     _enabled &= bits ^ 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void trace(int bits, String message, int indent) {
/*  55 */     if (test(bits))
/*     */     {
/*  57 */       synchronized (XBeanDebug.class) {
/*     */         
/*  59 */         if (indent < 0) {
/*  60 */           _indent += indent;
/*     */         }
/*  62 */         String spaces = (_indent < 0) ? "" : ((_indent > _indentspace.length()) ? _indentspace : _indentspace.substring(0, _indent));
/*  63 */         String logmessage = Thread.currentThread().getName() + ": " + spaces + message + "\n";
/*  64 */         System.err.print(logmessage);
/*     */         
/*  66 */         if (indent > 0) {
/*  67 */           _indent += indent;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean test(int bits) {
/*  74 */     return ((_enabled & bits) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String log(String message) {
/*  81 */     log(message, null);
/*  82 */     return message;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String logStackTrace(String message) {
/*  87 */     log(message, new Throwable());
/*  88 */     return message;
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized String log(String message, Throwable stackTrace) {
/*  93 */     if (_err == null) {
/*     */       
/*     */       try {
/*     */         
/*  97 */         File diagnosticFile = File.createTempFile("xmlbeandebug", ".log");
/*  98 */         _err = new PrintStream(new FileOutputStream(diagnosticFile));
/*  99 */         System.err.println("Diagnostic XML Bean debug log file created: " + diagnosticFile);
/*     */       }
/* 101 */       catch (IOException e) {
/*     */         
/* 103 */         _err = System.err;
/*     */       } 
/*     */     }
/* 106 */     _err.println(message);
/* 107 */     if (stackTrace != null)
/*     */     {
/* 109 */       stackTrace.printStackTrace(_err);
/*     */     }
/* 111 */     return message;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Throwable logException(Throwable t) {
/* 116 */     log(t.getMessage(), t);
/* 117 */     return t;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XBeanDebug.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */