/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import org.apache.xmlbeans.xml.stream.XMLName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlNameImpl
/*     */   implements XMLName
/*     */ {
/*  22 */   private String namespaceUri = null;
/*  23 */   private String localName = null;
/*  24 */   private String prefix = null;
/*  25 */   private int hash = 0;
/*     */   public XmlNameImpl() {}
/*     */   
/*     */   public XmlNameImpl(String localName) {
/*  29 */     this.localName = localName;
/*     */   }
/*     */   public XmlNameImpl(String namespaceUri, String localName) {
/*  32 */     setNamespaceUri(namespaceUri);
/*  33 */     this.localName = localName;
/*     */   }
/*     */ 
/*     */   
/*     */   public XmlNameImpl(String namespaceUri, String localName, String prefix) {
/*  38 */     setNamespaceUri(namespaceUri);
/*  39 */     this.localName = localName;
/*  40 */     this.prefix = prefix;
/*     */   }
/*     */   
/*  43 */   public String getNamespaceUri() { return this.namespaceUri; }
/*  44 */   public String getLocalName() { return this.localName; } public String getPrefix() {
/*  45 */     return this.prefix;
/*     */   }
/*     */   public void setNamespaceUri(String namespaceUri) {
/*  48 */     this.hash = 0;
/*  49 */     if (namespaceUri != null && namespaceUri.equals(""))
/*  50 */       return;  this.namespaceUri = namespaceUri;
/*     */   }
/*     */   public void setLocalName(String localName) {
/*  53 */     this.localName = localName;
/*  54 */     this.hash = 0;
/*     */   } public void setPrefix(String prefix) {
/*  56 */     this.prefix = prefix;
/*     */   }
/*     */   public String getQualifiedName() {
/*  59 */     if (this.prefix != null && this.prefix.length() > 0) {
/*  60 */       return this.prefix + ":" + this.localName;
/*     */     }
/*  62 */     return this.localName;
/*     */   }
/*     */   public String toString() {
/*  65 */     if (getNamespaceUri() != null) {
/*  66 */       return "['" + getNamespaceUri() + "']:" + getQualifiedName();
/*     */     }
/*  68 */     return getQualifiedName();
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*  72 */     int tmp_hash = this.hash;
/*  73 */     if (tmp_hash == 0) {
/*  74 */       tmp_hash = 17;
/*  75 */       if (this.namespaceUri != null) {
/*  76 */         tmp_hash = 37 * tmp_hash + this.namespaceUri.hashCode();
/*     */       }
/*  78 */       if (this.localName != null) {
/*  79 */         tmp_hash = 37 * tmp_hash + this.localName.hashCode();
/*     */       }
/*  81 */       this.hash = tmp_hash;
/*     */     } 
/*  83 */     return tmp_hash;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object obj) {
/*  87 */     if (obj == this) return true;
/*     */     
/*  89 */     if (obj instanceof XMLName) {
/*  90 */       XMLName name = (XMLName)obj;
/*     */       
/*  92 */       String lname = this.localName;
/*  93 */       if ((lname == null) ? (name.getLocalName() == null) : lname.equals(name.getLocalName())) {
/*     */ 
/*     */ 
/*     */         
/*  97 */         String uri = this.namespaceUri;
/*  98 */         return (uri == null) ? ((name.getNamespaceUri() == null)) : uri.equals(name.getNamespaceUri());
/*     */       } 
/*     */       return false;
/*     */     } 
/* 102 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XmlNameImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */