/*      */ package org.apache.xmlbeans.impl.common;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.namespace.QName;
/*      */ import org.apache.xmlbeans.XmlError;
/*      */ import org.apache.xmlbeans.XmlException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XPath
/*      */ {
/*      */   public static final String _NS_BOUNDARY = "$xmlbeans!ns_boundary";
/*      */   public static final String _DEFAULT_ELT_NS = "$xmlbeans!default_uri";
/*      */   private final Selector _selector;
/*      */   private final boolean _sawDeepDot;
/*      */   static Class class$org$apache$xmlbeans$impl$common$XPath;
/*      */   
/*      */   public static class XPathCompileException
/*      */     extends XmlException
/*      */   {
/*      */     XPathCompileException(XmlError err) {
/*   35 */       super(err.toString(), null, err);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static Class class$(String x0) {
/*      */     
/*   43 */     try { return Class.forName(x0); } catch (ClassNotFoundException x1) { throw (new NoClassDefFoundError()).initCause(x1); }
/*      */   
/*      */   }
/*      */   public static class ExecutionContext { public static final int HIT = 1; public static final int DESCEND = 2;
/*   47 */     private ArrayList _stack = new ArrayList();
/*      */     
/*      */     public static final int ATTRS = 4;
/*      */     
/*      */     private XPath _xpath;
/*      */     private PathContext[] _paths;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     public final void init(XPath xpath) {
/*   56 */       if (this._xpath != xpath) {
/*      */         
/*   58 */         this._xpath = xpath;
/*      */         
/*   60 */         this._paths = new PathContext[xpath._selector._paths.length];
/*      */         
/*   62 */         for (int j = 0; j < this._paths.length; j++) {
/*   63 */           this._paths[j] = new PathContext();
/*      */         }
/*      */       } 
/*   66 */       this._stack.clear();
/*      */       
/*   68 */       for (int i = 0; i < this._paths.length; i++) {
/*   69 */         this._paths[i].init(xpath._selector._paths[i]);
/*      */       }
/*      */     }
/*      */     
/*      */     public final int start() {
/*   74 */       int result = 0;
/*      */       
/*   76 */       for (int i = 0; i < this._paths.length; i++) {
/*   77 */         result |= this._paths[i].start();
/*      */       }
/*   79 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     public final int element(QName name) {
/*   84 */       assert name != null;
/*      */       
/*   86 */       this._stack.add(name);
/*      */       
/*   88 */       int result = 0;
/*      */       
/*   90 */       for (int i = 0; i < this._paths.length; i++) {
/*   91 */         result |= this._paths[i].element(name);
/*      */       }
/*   93 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     public final boolean attr(QName name) {
/*   98 */       boolean hit = false;
/*      */       
/*  100 */       for (int i = 0; i < this._paths.length; i++) {
/*  101 */         hit |= this._paths[i].attr(name);
/*      */       }
/*  103 */       return hit;
/*      */     }
/*      */ 
/*      */     
/*      */     public final void end() {
/*  108 */       this._stack.remove(this._stack.size() - 1);
/*      */       
/*  110 */       for (int i = 0; i < this._paths.length; i++) {
/*  111 */         this._paths[i].end();
/*      */       }
/*      */     }
/*      */     
/*      */     private final class PathContext
/*      */     {
/*      */       private XPath.Step _curr;
/*  118 */       private List _prev = new ArrayList();
/*      */       static final boolean $assertionsDisabled;
/*      */       private final XPath.ExecutionContext this$0;
/*      */       
/*      */       void init(XPath.Step steps) {
/*  123 */         this._curr = steps;
/*  124 */         this._prev.clear();
/*      */       }
/*      */ 
/*      */       
/*      */       private QName top(int i) {
/*  129 */         return XPath.ExecutionContext.this._stack.get(XPath.ExecutionContext.this._stack.size() - 1 - i);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       private void backtrack() {
/*  135 */         assert this._curr != null;
/*      */         
/*  137 */         if (this._curr._hasBacktrack) {
/*      */ 
/*      */           
/*  140 */           this._curr = this._curr._backtrack;
/*      */           
/*      */           return;
/*      */         } 
/*  144 */         assert !this._curr._deep;
/*      */         
/*  146 */         this._curr = this._curr._prev;
/*      */         
/*  148 */         while (!this._curr._deep) {
/*      */           
/*  150 */           int t = 0;
/*      */           
/*  152 */           for (XPath.Step s = this._curr; !s._deep; s = s._prev) {
/*      */             
/*  154 */             if (!s.match(top(t++))) {
/*      */               this._curr = this._curr._prev;
/*      */               continue;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*      */       int start() {
/*  164 */         assert this._curr != null;
/*  165 */         assert this._curr._prev == null;
/*      */         
/*  167 */         if (this._curr._name != null) {
/*  168 */           return this._curr._flags;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  174 */         this._curr = null;
/*      */         
/*  176 */         return 1;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       int element(QName name) {
/*  182 */         this._prev.add(this._curr);
/*      */         
/*  184 */         if (this._curr == null) {
/*  185 */           return 0;
/*      */         }
/*  187 */         assert this._curr._name != null;
/*      */         
/*  189 */         if (!this._curr._attr && this._curr.match(name)) {
/*      */           
/*  191 */           if ((this._curr = this._curr._next)._name != null) {
/*  192 */             return this._curr._flags;
/*      */           }
/*  194 */           backtrack();
/*      */ 
/*      */           
/*  197 */           return (this._curr == null) ? 1 : (0x1 | this._curr._flags);
/*      */         } 
/*      */ 
/*      */         
/*      */         do {
/*  202 */           backtrack();
/*      */           
/*  204 */           if (this._curr == null) {
/*  205 */             return 0;
/*      */           }
/*  207 */           if (this._curr.match(name)) {
/*      */             
/*  209 */             this._curr = this._curr._next;
/*      */             
/*      */             break;
/*      */           } 
/*  213 */         } while (!this._curr._deep);
/*      */ 
/*      */ 
/*      */         
/*  217 */         return this._curr._flags;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean attr(QName name) {
/*  222 */         return (this._curr != null && this._curr._attr && this._curr.match(name));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       void end() {
/*  228 */         this._curr = this._prev.remove(this._prev.size() - 1);
/*      */       }
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static XPath compileXPath(String xpath) throws XPathCompileException {
/*  247 */     return compileXPath(xpath, "$this", null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static XPath compileXPath(String xpath, String currentNodeVar) throws XPathCompileException {
/*  253 */     return compileXPath(xpath, currentNodeVar, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static XPath compileXPath(String xpath, Map namespaces) throws XPathCompileException {
/*  259 */     return compileXPath(xpath, "$this", namespaces);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static XPath compileXPath(String xpath, String currentNodeVar, Map namespaces) throws XPathCompileException {
/*  266 */     return (new CompilationContext(namespaces, currentNodeVar)).compile(xpath);
/*      */   }
/*      */   private static class CompilationContext { private String _expr;
/*      */     private boolean _sawDeepDot;
/*      */     private boolean _lastDeepDot;
/*      */     private String _currentNodeVar;
/*      */     protected Map _namespaces;
/*      */     
/*      */     CompilationContext(Map namespaces, String currentNodeVar) {
/*  275 */       assert this._currentNodeVar == null || this._currentNodeVar.startsWith("$");
/*      */ 
/*      */ 
/*      */       
/*  279 */       if (currentNodeVar == null) {
/*  280 */         this._currentNodeVar = "$this";
/*      */       } else {
/*  282 */         this._currentNodeVar = currentNodeVar;
/*      */       } 
/*  284 */       this._namespaces = new HashMap();
/*      */       
/*  286 */       this._externalNamespaces = (namespaces == null) ? new HashMap() : namespaces;
/*      */     }
/*      */     private Map _externalNamespaces;
/*      */     private int _offset;
/*      */     
/*      */     XPath compile(String expr) throws XPath.XPathCompileException {
/*  292 */       this._offset = 0;
/*  293 */       this._line = 1;
/*  294 */       this._column = 1;
/*  295 */       this._expr = expr;
/*      */       
/*  297 */       return tokenizeXPath();
/*      */     }
/*      */     private int _line; private int _column; static final boolean $assertionsDisabled;
/*      */     
/*      */     int currChar() {
/*  302 */       return currChar(0);
/*      */     }
/*      */ 
/*      */     
/*      */     int currChar(int offset) {
/*  307 */       return (this._offset + offset >= this._expr.length()) ? -1 : this._expr.charAt(this._offset + offset);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void advance() {
/*  315 */       if (this._offset < this._expr.length()) {
/*      */         
/*  317 */         char ch = this._expr.charAt(this._offset);
/*      */         
/*  319 */         this._offset++;
/*  320 */         this._column++;
/*      */         
/*  322 */         if (ch == '\r' || ch == '\n') {
/*      */           
/*  324 */           this._line++;
/*  325 */           this._column = 1;
/*      */           
/*  327 */           if (this._offset + 1 < this._expr.length()) {
/*      */             
/*  329 */             char nextCh = this._expr.charAt(this._offset + 1);
/*      */             
/*  331 */             if ((nextCh == '\r' || nextCh == '\n') && ch != nextCh) {
/*  332 */               this._offset++;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     void advance(int count) {
/*  340 */       assert count >= 0;
/*      */       
/*  342 */       while (count-- > 0) {
/*  343 */         advance();
/*      */       }
/*      */     }
/*      */     
/*      */     boolean isWhitespace() {
/*  348 */       return isWhitespace(0);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isWhitespace(int offset) {
/*  353 */       int ch = currChar(offset);
/*  354 */       return (ch == 32 || ch == 9 || ch == 10 || ch == 13);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isNCNameStart() {
/*  359 */       return (currChar() == -1) ? false : XMLChar.isNCNameStart(currChar());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isNCName() {
/*  367 */       return (currChar() == -1) ? false : XMLChar.isNCName(currChar());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean startsWith(String s) {
/*  375 */       return startsWith(s, 0);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean startsWith(String s, int offset) {
/*  380 */       if (this._offset + offset >= this._expr.length()) {
/*  381 */         return false;
/*      */       }
/*  383 */       return this._expr.startsWith(s, this._offset + offset);
/*      */     }
/*      */ 
/*      */     
/*      */     private XPath.XPathCompileException newError(String msg) {
/*  388 */       XmlError err = XmlError.forLocation(msg, 0, null, this._line, this._column, this._offset);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  393 */       return new XPath.XPathCompileException(err);
/*      */     }
/*      */ 
/*      */     
/*      */     String lookupPrefix(String prefix) throws XPath.XPathCompileException {
/*  398 */       if (this._namespaces.containsKey(prefix)) {
/*  399 */         return (String)this._namespaces.get(prefix);
/*      */       }
/*  401 */       if (this._externalNamespaces.containsKey(prefix)) {
/*  402 */         return (String)this._externalNamespaces.get(prefix);
/*      */       }
/*  404 */       if (prefix.equals("xml")) {
/*  405 */         return "http://www.w3.org/XML/1998/namespace";
/*      */       }
/*  407 */       if (prefix.equals("xs")) {
/*  408 */         return "http://www.w3.org/2001/XMLSchema";
/*      */       }
/*  410 */       if (prefix.equals("xsi")) {
/*  411 */         return "http://www.w3.org/2001/XMLSchema-instance";
/*      */       }
/*  413 */       if (prefix.equals("fn")) {
/*  414 */         return "http://www.w3.org/2002/11/xquery-functions";
/*      */       }
/*  416 */       if (prefix.equals("xdt")) {
/*  417 */         return "http://www.w3.org/2003/11/xpath-datatypes";
/*      */       }
/*  419 */       if (prefix.equals("local")) {
/*  420 */         return "http://www.w3.org/2003/11/xquery-local-functions";
/*      */       }
/*  422 */       throw newError("Undefined prefix: " + prefix);
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean parseWhitespace() throws XPath.XPathCompileException {
/*  427 */       boolean sawSpace = false;
/*      */       
/*  429 */       while (isWhitespace()) {
/*      */         
/*  431 */         advance();
/*  432 */         sawSpace = true;
/*      */       } 
/*      */       
/*  435 */       return sawSpace;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean tokenize(String s) {
/*  446 */       assert s.length() > 0;
/*      */       
/*  448 */       int offset = 0;
/*      */       
/*  450 */       while (isWhitespace(offset)) {
/*  451 */         offset++;
/*      */       }
/*  453 */       if (!startsWith(s, offset)) {
/*  454 */         return false;
/*      */       }
/*  456 */       offset += s.length();
/*      */       
/*  458 */       advance(offset);
/*      */       
/*  460 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean tokenize(String s1, String s2) {
/*  465 */       assert s1.length() > 0;
/*  466 */       assert s2.length() > 0;
/*      */       
/*  468 */       int offset = 0;
/*      */       
/*  470 */       while (isWhitespace(offset)) {
/*  471 */         offset++;
/*      */       }
/*  473 */       if (!startsWith(s1, offset)) {
/*  474 */         return false;
/*      */       }
/*  476 */       offset += s1.length();
/*      */       
/*  478 */       while (isWhitespace(offset)) {
/*  479 */         offset++;
/*      */       }
/*  481 */       if (!startsWith(s2, offset)) {
/*  482 */         return false;
/*      */       }
/*  484 */       offset += s2.length();
/*      */       
/*  486 */       advance(offset);
/*      */       
/*  488 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean tokenize(String s1, String s2, String s3) {
/*  493 */       assert s1.length() > 0;
/*  494 */       assert s2.length() > 0;
/*  495 */       assert s3.length() > 0;
/*      */       
/*  497 */       int offset = 0;
/*      */       
/*  499 */       while (isWhitespace(offset)) {
/*  500 */         offset++;
/*      */       }
/*  502 */       if (!startsWith(s1, offset)) {
/*  503 */         return false;
/*      */       }
/*  505 */       offset += s1.length();
/*      */       
/*  507 */       while (isWhitespace(offset)) {
/*  508 */         offset++;
/*      */       }
/*  510 */       if (!startsWith(s2, offset)) {
/*  511 */         return false;
/*      */       }
/*  513 */       offset += s2.length();
/*      */       
/*  515 */       while (isWhitespace(offset)) {
/*  516 */         offset++;
/*      */       }
/*  518 */       if (!startsWith(s3, offset)) {
/*  519 */         return false;
/*      */       }
/*  521 */       offset += s3.length();
/*      */       
/*  523 */       while (isWhitespace(offset)) {
/*  524 */         offset++;
/*      */       }
/*  526 */       advance(offset);
/*      */       
/*  528 */       return true;
/*      */     }
/*      */     private boolean tokenize(String s1, String s2, String s3, String s4) {
/*  531 */       assert s1.length() > 0;
/*  532 */       assert s2.length() > 0;
/*  533 */       assert s3.length() > 0;
/*  534 */       assert s4.length() > 0;
/*      */       
/*  536 */       int offset = 0;
/*      */       
/*  538 */       while (isWhitespace(offset)) {
/*  539 */         offset++;
/*      */       }
/*  541 */       if (!startsWith(s1, offset)) {
/*  542 */         return false;
/*      */       }
/*  544 */       offset += s1.length();
/*      */       
/*  546 */       while (isWhitespace(offset)) {
/*  547 */         offset++;
/*      */       }
/*  549 */       if (!startsWith(s2, offset)) {
/*  550 */         return false;
/*      */       }
/*  552 */       offset += s2.length();
/*      */       
/*  554 */       while (isWhitespace(offset)) {
/*  555 */         offset++;
/*      */       }
/*  557 */       if (!startsWith(s3, offset)) {
/*  558 */         return false;
/*      */       }
/*  560 */       offset += s3.length();
/*      */       
/*  562 */       while (isWhitespace(offset)) {
/*  563 */         offset++;
/*      */       }
/*  565 */       if (!startsWith(s4, offset)) {
/*  566 */         return false;
/*      */       }
/*  568 */       offset += s4.length();
/*      */       
/*  570 */       advance(offset);
/*      */       
/*  572 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private String tokenizeNCName() throws XPath.XPathCompileException {
/*  578 */       parseWhitespace();
/*      */       
/*  580 */       if (!isNCNameStart()) {
/*  581 */         throw newError("Expected non-colonized name");
/*      */       }
/*  583 */       StringBuffer sb = new StringBuffer();
/*      */       
/*  585 */       sb.append((char)currChar());
/*      */       
/*  587 */       advance(); for (; isNCName(); advance()) {
/*  588 */         sb.append((char)currChar());
/*      */       }
/*  590 */       return sb.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     private QName getAnyQName() {
/*  595 */       return new QName("", "");
/*      */     }
/*      */ 
/*      */     
/*      */     private QName tokenizeQName() throws XPath.XPathCompileException {
/*  600 */       if (tokenize("*")) {
/*  601 */         return getAnyQName();
/*      */       }
/*  603 */       String ncName = tokenizeNCName();
/*      */       
/*  605 */       if (!tokenize(":")) {
/*  606 */         return new QName(lookupPrefix(""), ncName);
/*      */       }
/*  608 */       return new QName(lookupPrefix(ncName), tokenize("*") ? "" : tokenizeNCName());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String tokenizeQuotedUri() throws XPath.XPathCompileException {
/*      */       char quote;
/*  618 */       if (tokenize("\"")) {
/*  619 */         quote = '"';
/*  620 */       } else if (tokenize("'")) {
/*  621 */         quote = '\'';
/*      */       } else {
/*  623 */         throw newError("Expected quote (\" or ')");
/*      */       } 
/*  625 */       StringBuffer sb = new StringBuffer();
/*      */ 
/*      */       
/*      */       while (true) {
/*  629 */         if (currChar() == -1) {
/*  630 */           throw newError("Path terminated in URI literal");
/*      */         }
/*  632 */         if (currChar() == quote) {
/*      */           
/*  634 */           advance();
/*      */           
/*  636 */           if (currChar() != quote) {
/*      */             break;
/*      */           }
/*      */         } 
/*  640 */         sb.append((char)currChar());
/*      */         
/*  642 */         advance();
/*      */       } 
/*      */       
/*  645 */       return sb.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     private XPath.Step addStep(boolean deep, boolean attr, QName name, XPath.Step steps) {
/*  650 */       XPath.Step step = new XPath.Step(deep, attr, name);
/*      */       
/*  652 */       if (steps == null) {
/*  653 */         return step;
/*      */       }
/*  655 */       XPath.Step s = steps;
/*      */       
/*  657 */       while (steps._next != null) {
/*  658 */         steps = steps._next;
/*      */       }
/*  660 */       steps._next = step;
/*  661 */       step._prev = steps;
/*      */       
/*  663 */       return s;
/*      */     }
/*      */     
/*      */     private XPath.Step tokenizeSteps() throws XPath.XPathCompileException {
/*      */       boolean deep;
/*  668 */       if (tokenize("/")) {
/*  669 */         throw newError("Absolute paths unsupported");
/*      */       }
/*      */ 
/*      */       
/*  673 */       if (tokenize("$", this._currentNodeVar, "//") || tokenize(".", "//"))
/*  674 */       { deep = true; }
/*  675 */       else if (tokenize("$", this._currentNodeVar, "/") || tokenize(".", "/"))
/*  676 */       { deep = false; }
/*  677 */       else { if (tokenize("$", this._currentNodeVar) || tokenize(".")) {
/*  678 */           return addStep(false, false, null, null);
/*      */         }
/*  680 */         deep = false; }
/*      */       
/*  682 */       XPath.Step steps = null;
/*      */ 
/*      */ 
/*      */       
/*  686 */       boolean deepDot = false;
/*      */ 
/*      */       
/*      */       while (true) {
/*  690 */         if (tokenize("attribute", "::") || tokenize("@")) {
/*      */           
/*  692 */           steps = addStep(deep, true, tokenizeQName(), steps);
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  698 */         if (tokenize(".")) {
/*  699 */           deepDot = (deepDot || deep);
/*      */         } else {
/*      */           
/*  702 */           tokenize("child", "::"); QName name;
/*  703 */           if ((name = tokenizeQName()) != null) {
/*      */             
/*  705 */             steps = addStep(deep, false, name, steps);
/*  706 */             deep = false;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  711 */         if (tokenize("//")) {
/*      */           
/*  713 */           deep = true;
/*  714 */           deepDot = false; continue;
/*      */         } 
/*  716 */         if (tokenize("/")) {
/*      */           
/*  718 */           if (deepDot) {
/*  719 */             deep = true;
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/*  728 */       if (this._lastDeepDot = deepDot) {
/*      */         
/*  730 */         this._lastDeepDot = true;
/*  731 */         steps = addStep(true, false, getAnyQName(), steps);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  736 */       return addStep(false, false, null, steps);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void computeBacktrack(XPath.Step steps) throws XPath.XPathCompileException {
/*  751 */       for (XPath.Step s = steps; s != null; s = t) {
/*      */         XPath.Step t;
/*      */ 
/*      */         
/*  755 */         for (t = s._next; t != null && !t._deep;) {
/*  756 */           t = t._next;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  762 */         if (!s._deep) {
/*      */           
/*  764 */           for (XPath.Step u = s; u != t; u = u._next) {
/*  765 */             u._hasBacktrack = true;
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/*  773 */           int n = 0;
/*  774 */           XPath.Step u = s;
/*      */           
/*  776 */           while (u != t && u._name != null && !u.isWild() && !u._attr) {
/*      */             
/*  778 */             n++;
/*  779 */             u = u._next;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  784 */           QName[] pattern = new QName[n + 1];
/*  785 */           int[] kmp = new int[n + 1];
/*      */           
/*  787 */           XPath.Step v = s;
/*      */           int i;
/*  789 */           for (i = 0; i < n; i++) {
/*      */             
/*  791 */             pattern[i] = v._name;
/*  792 */             v = v._next;
/*      */           } 
/*      */           
/*  795 */           pattern[n] = getAnyQName();
/*      */           
/*  797 */           i = 0;
/*  798 */           int j = kmp[0] = -1;
/*      */           
/*  800 */           while (i < n) {
/*      */             
/*  802 */             while (j > -1 && !pattern[i].equals(pattern[j])) {
/*  803 */               j = kmp[j];
/*      */             }
/*  805 */             if (pattern[++i].equals(pattern[++j])) {
/*  806 */               kmp[i] = kmp[j]; continue;
/*      */             } 
/*  808 */             kmp[i] = j;
/*      */           } 
/*      */           
/*  811 */           i = 0;
/*      */           
/*  813 */           for (v = s; v != u; v = v._next) {
/*      */             
/*  815 */             v._hasBacktrack = true;
/*  816 */             v._backtrack = s;
/*      */             
/*  818 */             for (j = kmp[i]; j > 0; j--) {
/*  819 */               v._backtrack = v._backtrack._next;
/*      */             }
/*  821 */             i++;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  827 */           v = s;
/*      */           
/*  829 */           if (n > 1)
/*      */           {
/*  831 */             for (j = kmp[n - 1]; j > 0; j--) {
/*  832 */               v = v._next;
/*      */             }
/*      */           }
/*  835 */           if (u != t && u._attr) {
/*      */             
/*  837 */             u._hasBacktrack = true;
/*  838 */             u._backtrack = v;
/*  839 */             u = u._next;
/*      */           } 
/*      */           
/*  842 */           if (u != t && u._name == null) {
/*      */             
/*  844 */             u._hasBacktrack = true;
/*  845 */             u._backtrack = v;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  850 */           assert s._deep;
/*      */           
/*  852 */           s._hasBacktrack = true;
/*  853 */           s._backtrack = s;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void tokenizePath(ArrayList paths) throws XPath.XPathCompileException {
/*  860 */       this._lastDeepDot = false;
/*      */       
/*  862 */       XPath.Step steps = tokenizeSteps();
/*      */       
/*  864 */       computeBacktrack(steps);
/*      */       
/*  866 */       paths.add(steps);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  871 */       if (this._lastDeepDot) {
/*      */         
/*  873 */         this._sawDeepDot = true;
/*      */         
/*  875 */         XPath.Step s = null;
/*      */         
/*  877 */         for (XPath.Step t = steps; t != null; t = t._next) {
/*      */           
/*  879 */           if (t._next != null && t._next._next == null) {
/*  880 */             s = addStep(t._deep, true, t._name, s);
/*      */           } else {
/*  882 */             s = addStep(t._deep, t._attr, t._name, s);
/*      */           } 
/*      */         } 
/*  885 */         computeBacktrack(s);
/*      */         
/*  887 */         paths.add(s);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private XPath.Selector tokenizeSelector() throws XPath.XPathCompileException {
/*  893 */       ArrayList paths = new ArrayList();
/*      */       
/*  895 */       tokenizePath(paths);
/*      */       
/*  897 */       while (tokenize("|")) {
/*  898 */         tokenizePath(paths);
/*      */       }
/*  900 */       return new XPath.Selector((XPath.Step[])paths.toArray((Object[])new XPath.Step[0]));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private XPath tokenizeXPath() throws XPath.XPathCompileException {
/*      */       while (true) {
/*  907 */         while (tokenize("declare", "namespace")) {
/*      */           
/*  909 */           if (!parseWhitespace()) {
/*  910 */             throw newError("Expected prefix after 'declare namespace'");
/*      */           }
/*  912 */           String prefix = tokenizeNCName();
/*      */           
/*  914 */           if (!tokenize("=")) {
/*  915 */             throw newError("Expected '='");
/*      */           }
/*  917 */           String uri = tokenizeQuotedUri();
/*      */           
/*  919 */           if (this._namespaces.containsKey(prefix))
/*      */           {
/*  921 */             throw newError("Redefinition of namespace prefix: " + prefix);
/*      */           }
/*      */ 
/*      */           
/*  925 */           this._namespaces.put(prefix, uri);
/*      */ 
/*      */ 
/*      */           
/*  929 */           if (this._externalNamespaces.containsKey(prefix))
/*      */           {
/*  931 */             throw newError("Redefinition of namespace prefix: " + prefix);
/*      */           }
/*      */           
/*  934 */           this._externalNamespaces.put(prefix, uri);
/*      */           
/*  936 */           if (!tokenize(";"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  942 */           this._externalNamespaces.put("$xmlbeans!ns_boundary", new Integer(this._offset));
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  947 */         if (tokenize("declare", "default", "element", "namespace")) {
/*      */           
/*  949 */           String uri = tokenizeQuotedUri();
/*      */           
/*  951 */           if (this._namespaces.containsKey(""))
/*      */           {
/*  953 */             throw newError("Redefinition of default element namespace");
/*      */           }
/*      */ 
/*      */           
/*  957 */           this._namespaces.put("", uri);
/*      */ 
/*      */ 
/*      */           
/*  961 */           if (this._externalNamespaces.containsKey("$xmlbeans!default_uri"))
/*      */           {
/*  963 */             throw newError("Redefinition of default element namespace : ");
/*      */           }
/*  965 */           this._externalNamespaces.put("$xmlbeans!default_uri", uri);
/*      */           
/*  967 */           if (!tokenize(";")) {
/*  968 */             throw newError("Default Namespace declaration must end with ;");
/*      */           }
/*  970 */           this._externalNamespaces.put("$xmlbeans!ns_boundary", new Integer(this._offset));
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/*  980 */       if (!this._namespaces.containsKey("")) {
/*  981 */         this._namespaces.put("", "");
/*      */       }
/*  983 */       XPath.Selector selector = tokenizeSelector();
/*      */       
/*  985 */       parseWhitespace();
/*      */       
/*  987 */       if (currChar() != -1)
/*      */       {
/*  989 */         throw newError("Unexpected char '" + (char)currChar() + "'");
/*      */       }
/*      */ 
/*      */       
/*  993 */       return new XPath(selector, this._sawDeepDot);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void processNonXpathDecls() {} }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class Step
/*      */   {
/*      */     final boolean _attr;
/*      */     
/*      */     final boolean _deep;
/*      */     
/*      */     int _flags;
/*      */     
/*      */     final QName _name;
/*      */     
/*      */     Step _next;
/*      */     
/*      */     Step _prev;
/*      */     
/*      */     boolean _hasBacktrack;
/*      */     
/*      */     Step _backtrack;
/*      */ 
/*      */     
/*      */     Step(boolean deep, boolean attr, QName name) {
/* 1022 */       this._name = name;
/*      */       
/* 1024 */       this._deep = deep;
/* 1025 */       this._attr = attr;
/*      */       
/* 1027 */       int flags = 0;
/*      */       
/* 1029 */       if (this._deep || !this._attr) {
/* 1030 */         flags |= 0x2;
/*      */       }
/* 1032 */       if (this._attr) {
/* 1033 */         flags |= 0x4;
/*      */       }
/* 1035 */       this._flags = flags;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isWild() {
/* 1040 */       return (this._name.getLocalPart().length() == 0);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean match(QName name) {
/* 1045 */       String local = this._name.getLocalPart();
/* 1046 */       String nameLocal = name.getLocalPart();
/*      */ 
/*      */ 
/*      */       
/* 1050 */       int localLength = local.length();
/*      */ 
/*      */ 
/*      */       
/* 1054 */       if (localLength == 0) {
/*      */         
/* 1056 */         String str = this._name.getNamespaceURI();
/* 1057 */         int uriLength = str.length();
/*      */         
/* 1059 */         if (uriLength == 0) {
/* 1060 */           return true;
/*      */         }
/* 1062 */         return str.equals(name.getNamespaceURI());
/*      */       } 
/*      */       
/* 1065 */       if (localLength != nameLocal.length()) {
/* 1066 */         return false;
/*      */       }
/* 1068 */       String uri = this._name.getNamespaceURI();
/* 1069 */       String nameUri = name.getNamespaceURI();
/*      */       
/* 1071 */       if (uri.length() != nameUri.length()) {
/* 1072 */         return false;
/*      */       }
/* 1074 */       return (local.equals(nameLocal) && uri.equals(nameUri));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class Selector
/*      */   {
/*      */     final XPath.Step[] _paths;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Selector(XPath.Step[] paths) {
/* 1094 */       this._paths = paths;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XPath(Selector selector, boolean sawDeepDot) {
/* 1106 */     this._selector = selector;
/* 1107 */     this._sawDeepDot = sawDeepDot;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean sawDeepDot() {
/* 1112 */     return this._sawDeepDot;
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XPath.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */