/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import org.apache.xmlbeans.SimpleValue;
/*     */ import org.apache.xmlbeans.XmlObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlObjectList
/*     */ {
/*     */   private final XmlObject[] _objects;
/*     */   
/*     */   public XmlObjectList(int objectCount) {
/*  33 */     this._objects = new XmlObject[objectCount];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean set(XmlObject o, int index) {
/*  45 */     if (this._objects[index] != null) {
/*  46 */       return false;
/*     */     }
/*  48 */     this._objects[index] = o;
/*  49 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean filled() {
/*  56 */     for (int i = 0; i < this._objects.length; i++) {
/*  57 */       if (this._objects[i] == null) return false; 
/*     */     } 
/*  59 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int unfilled() {
/*  67 */     for (int i = 0; i < this._objects.length; i++) {
/*  68 */       if (this._objects[i] == null) return i; 
/*     */     } 
/*  70 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*  74 */     if (!(o instanceof XmlObjectList)) {
/*  75 */       return false;
/*     */     }
/*  77 */     XmlObjectList other = (XmlObjectList)o;
/*     */     
/*  79 */     if (other._objects.length != this._objects.length) {
/*  80 */       return false;
/*     */     }
/*  82 */     for (int i = 0; i < this._objects.length; i++) {
/*     */       
/*  84 */       if (this._objects[i] == null || other._objects[i] == null) {
/*  85 */         return false;
/*     */       }
/*  87 */       if (!this._objects[i].valueEquals(other._objects[i])) {
/*  88 */         return false;
/*     */       }
/*     */     } 
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  96 */     int h = 0;
/*     */     
/*  98 */     for (int i = 0; i < this._objects.length; i++) {
/*  99 */       if (this._objects[i] != null)
/* 100 */         h = 31 * h + this._objects[i].valueHashCode(); 
/*     */     } 
/* 102 */     return h;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String prettytrim(String s) {
/*     */     int end;
/* 108 */     for (end = s.length(); end > 0; end--) {
/*     */       
/* 110 */       if (!XMLChar.isSpace(s.charAt(end - 1)))
/*     */         break; 
/*     */     } 
/*     */     int start;
/* 114 */     for (start = 0; start < end; start++) {
/*     */       
/* 116 */       if (!XMLChar.isSpace(s.charAt(start)))
/*     */         break; 
/*     */     } 
/* 119 */     return s.substring(start, end);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 123 */     StringBuffer b = new StringBuffer();
/*     */     
/* 125 */     for (int i = 0; i < this._objects.length; i++) {
/*     */       
/* 127 */       if (i != 0) b.append(" "); 
/* 128 */       b.append(prettytrim(((SimpleValue)this._objects[i]).getStringValue()));
/*     */     } 
/*     */     
/* 131 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XmlObjectList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */