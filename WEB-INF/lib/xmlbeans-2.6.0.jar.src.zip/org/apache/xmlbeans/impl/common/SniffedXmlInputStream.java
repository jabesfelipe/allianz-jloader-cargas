/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SniffedXmlInputStream
/*     */   extends BufferedInputStream
/*     */ {
/*  29 */   public static int MAX_SNIFFED_BYTES = 192;
/*     */ 
/*     */   
/*     */   public SniffedXmlInputStream(InputStream stream) throws IOException {
/*  33 */     super(stream);
/*     */ 
/*     */     
/*  36 */     this._encoding = sniffFourBytes();
/*     */     
/*  38 */     if (this._encoding != null && this._encoding.equals("IBM037")) {
/*     */ 
/*     */       
/*  41 */       String encoding = sniffForXmlDecl(this._encoding);
/*  42 */       if (encoding != null) {
/*  43 */         this._encoding = encoding;
/*     */       }
/*     */     } 
/*  46 */     if (this._encoding == null)
/*     */     {
/*     */ 
/*     */       
/*  50 */       this._encoding = sniffForXmlDecl("UTF-8");
/*     */     }
/*     */     
/*  53 */     if (this._encoding == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  80 */       this._encoding = "UTF-8";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private int readAsMuchAsPossible(byte[] buf, int startAt, int len) throws IOException {
/*  86 */     int total = 0;
/*  87 */     while (total < len) {
/*     */       
/*  89 */       int count = read(buf, startAt + total, len - total);
/*  90 */       if (count < 0)
/*     */         break; 
/*  92 */       total += count;
/*     */     } 
/*  94 */     return total;
/*     */   }
/*     */ 
/*     */   
/*     */   private String sniffFourBytes() throws IOException {
/*  99 */     mark(4);
/* 100 */     int skip = 0;
/*     */     
/*     */     try {
/* 103 */       byte[] buf = new byte[4];
/* 104 */       if (readAsMuchAsPossible(buf, 0, 4) < 4)
/* 105 */         return null; 
/* 106 */       long result = (0xFF000000 & buf[0] << 24 | 0xFF0000 & buf[1] << 16 | 0xFF00 & buf[2] << 8 | 0xFF & buf[3]);
/*     */       
/* 108 */       if (result == 65279L)
/* 109 */         return "UCS-4"; 
/* 110 */       if (result == -131072L)
/* 111 */         return "UCS-4"; 
/* 112 */       if (result == 60L)
/* 113 */         return "UCS-4BE"; 
/* 114 */       if (result == 1006632960L)
/* 115 */         return "UCS-4LE"; 
/* 116 */       if (result == 3932223L)
/* 117 */         return "UTF-16BE"; 
/* 118 */       if (result == 1006649088L)
/* 119 */         return "UTF-16LE"; 
/* 120 */       if (result == 1010792557L)
/* 121 */         return null; 
/* 122 */       if (result == 1282385812L)
/* 123 */         return "IBM037"; 
/* 124 */       if ((result & 0xFFFFFFFFFFFF0000L) == -16842752L)
/* 125 */         return "UTF-16"; 
/* 126 */       if ((result & 0xFFFFFFFFFFFF0000L) == -131072L)
/* 127 */         return "UTF-16"; 
/* 128 */       if ((result & 0xFFFFFFFFFFFFFF00L) == -272908544L)
/* 129 */         return "UTF-8"; 
/* 130 */       return null;
/*     */     }
/*     */     finally {
/*     */       
/* 134 */       reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   private static Charset dummy1 = Charset.forName("UTF-8");
/* 142 */   private static Charset dummy2 = Charset.forName("UTF-16");
/* 143 */   private static Charset dummy3 = Charset.forName("UTF-16BE");
/* 144 */   private static Charset dummy4 = Charset.forName("UTF-16LE");
/* 145 */   private static Charset dummy5 = Charset.forName("ISO-8859-1");
/* 146 */   private static Charset dummy6 = Charset.forName("US-ASCII");
/* 147 */   private static Charset dummy7 = Charset.forName("Cp1252");
/*     */   
/*     */   private String _encoding;
/*     */   
/*     */   private String sniffForXmlDecl(String encoding) throws IOException {
/* 152 */     mark(MAX_SNIFFED_BYTES);
/*     */     
/*     */     try {
/* 155 */       byte[] bytebuf = new byte[MAX_SNIFFED_BYTES];
/* 156 */       int bytelimit = readAsMuchAsPossible(bytebuf, 0, MAX_SNIFFED_BYTES);
/*     */ 
/*     */       
/* 159 */       Charset charset = Charset.forName(encoding);
/* 160 */       Reader reader = new InputStreamReader(new ByteArrayInputStream(bytebuf, 0, bytelimit), charset);
/* 161 */       char[] buf = new char[bytelimit];
/* 162 */       int limit = 0;
/* 163 */       while (limit < bytelimit) {
/*     */         
/* 165 */         int count = reader.read(buf, limit, bytelimit - limit);
/* 166 */         if (count < 0)
/*     */           break; 
/* 168 */         limit += count;
/*     */       } 
/*     */       
/* 171 */       return extractXmlDeclEncoding(buf, 0, limit);
/*     */     }
/*     */     finally {
/*     */       
/* 175 */       reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getXmlEncoding() {
/* 183 */     return this._encoding;
/*     */   }
/*     */ 
/*     */   
/*     */   static String extractXmlDeclEncoding(char[] buf, int offset, int size) {
/* 188 */     int limit = offset + size;
/* 189 */     int xmlpi = firstIndexOf("<?xml", buf, offset, limit);
/* 190 */     if (xmlpi >= 0) {
/*     */       
/* 192 */       int i = xmlpi + 5;
/* 193 */       ScannedAttribute attr = new ScannedAttribute();
/* 194 */       while (i < limit) {
/*     */         
/* 196 */         i = scanAttribute(buf, i, limit, attr);
/* 197 */         if (i < 0)
/* 198 */           return null; 
/* 199 */         if (attr.name.equals("encoding"))
/* 200 */           return attr.value; 
/*     */       } 
/*     */     } 
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int firstIndexOf(String s, char[] buf, int startAt, int limit) {
/* 208 */     assert s.length() > 0;
/* 209 */     char[] lookFor = s.toCharArray();
/*     */     
/* 211 */     char firstchar = lookFor[0];
/* 212 */     for (limit -= lookFor.length; startAt < limit; startAt++) {
/*     */       
/* 214 */       if (buf[startAt] == firstchar) {
/*     */         
/* 216 */         int i = 1; while (true) { if (i < lookFor.length) {
/*     */             
/* 218 */             if (buf[startAt + i] != lookFor[i])
/*     */               break; 
/*     */             i++;
/*     */             continue;
/*     */           } 
/* 223 */           return startAt; }
/*     */       
/*     */       } 
/*     */     } 
/* 227 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int nextNonmatchingByte(char[] lookFor, char[] buf, int startAt, int limit) {
/* 232 */     for (; startAt < limit; startAt++) {
/*     */       
/* 234 */       int thischar = buf[startAt];
/* 235 */       int i = 0; while (true) { if (i < lookFor.length) {
/* 236 */           if (thischar == lookFor[i])
/*     */             break;  i++; continue;
/* 238 */         }  return startAt; }
/*     */     
/* 240 */     }  return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int nextMatchingByte(char[] lookFor, char[] buf, int startAt, int limit) {
/* 245 */     for (; startAt < limit; startAt++) {
/*     */       
/* 247 */       int thischar = buf[startAt];
/* 248 */       for (int i = 0; i < lookFor.length; i++) {
/* 249 */         if (thischar == lookFor[i])
/* 250 */           return startAt; 
/*     */       } 
/* 252 */     }  return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int nextMatchingByte(char lookFor, char[] buf, int startAt, int limit) {
/* 257 */     for (; startAt < limit; startAt++) {
/*     */       
/* 259 */       if (buf[startAt] == lookFor)
/* 260 */         return startAt; 
/*     */     } 
/* 262 */     return -1;
/*     */   }
/* 264 */   private static char[] WHITESPACE = new char[] { ' ', '\r', '\t', '\n' };
/* 265 */   private static char[] NOTNAME = new char[] { '=', ' ', '\r', '\t', '\n', '?', '>', '<', '\'', '"' };
/*     */   static final boolean $assertionsDisabled;
/*     */   
/*     */   private static class ScannedAttribute {
/*     */     public String name;
/*     */     public String value;
/*     */     
/*     */     private ScannedAttribute() {} }
/*     */   
/*     */   private static int scanAttribute(char[] buf, int startAt, int limit, ScannedAttribute attr) {
/* 275 */     int nameStart = nextNonmatchingByte(WHITESPACE, buf, startAt, limit);
/* 276 */     if (nameStart < 0)
/* 277 */       return -1; 
/* 278 */     int nameEnd = nextMatchingByte(NOTNAME, buf, nameStart, limit);
/* 279 */     if (nameEnd < 0)
/* 280 */       return -1; 
/* 281 */     int equals = nextNonmatchingByte(WHITESPACE, buf, nameEnd, limit);
/* 282 */     if (equals < 0)
/* 283 */       return -1; 
/* 284 */     if (buf[equals] != '=')
/* 285 */       return -1; 
/* 286 */     int valQuote = nextNonmatchingByte(WHITESPACE, buf, equals + 1, limit);
/* 287 */     if (buf[valQuote] != '\'' && buf[valQuote] != '"')
/* 288 */       return -1; 
/* 289 */     int valEndquote = nextMatchingByte(buf[valQuote], buf, valQuote + 1, limit);
/* 290 */     if (valEndquote < 0)
/* 291 */       return -1; 
/* 292 */     attr.name = new String(buf, nameStart, nameEnd - nameStart);
/* 293 */     attr.value = new String(buf, valQuote + 1, valEndquote - valQuote - 1);
/* 294 */     return valEndquote + 1;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\SniffedXmlInputStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */