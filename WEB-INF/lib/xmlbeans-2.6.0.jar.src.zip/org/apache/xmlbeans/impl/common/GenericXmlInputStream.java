/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import org.apache.xmlbeans.xml.stream.ReferenceResolver;
/*     */ import org.apache.xmlbeans.xml.stream.XMLEvent;
/*     */ import org.apache.xmlbeans.xml.stream.XMLInputStream;
/*     */ import org.apache.xmlbeans.xml.stream.XMLName;
/*     */ import org.apache.xmlbeans.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericXmlInputStream
/*     */   implements XMLInputStream
/*     */ {
/*     */   private boolean _initialized;
/*     */   private EventItem _nextEvent;
/*     */   private int _elementCount;
/*     */   private GenericXmlInputStream _master;
/*     */   
/*     */   public GenericXmlInputStream() {
/*  31 */     this._master = this;
/*  32 */     this._elementCount = 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private GenericXmlInputStream(GenericXmlInputStream master) {
/*  37 */     (this._master = master).ensureInit();
/*  38 */     this._nextEvent = master._nextEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLEvent nextEvent() throws XMLStreamException {
/*  47 */     throw new RuntimeException("nextEvent not overridden");
/*     */   }
/*     */ 
/*     */   
/*     */   private class EventItem
/*     */   {
/*     */     final XMLEvent _event;
/*     */     EventItem _next;
/*     */     private final GenericXmlInputStream this$0;
/*     */     
/*     */     EventItem(XMLEvent e) {
/*  58 */       this._event = e;
/*     */     }
/*     */     
/*  61 */     int getType() { return this._event.getType(); }
/*  62 */     boolean hasName() { return this._event.hasName(); } XMLName getName() {
/*  63 */       return this._event.getName();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureInit() {
/*  72 */     if (!this._master._initialized) {
/*     */ 
/*     */       
/*     */       try {
/*  76 */         this._master._nextEvent = getNextEvent();
/*     */       }
/*  78 */       catch (XMLStreamException e) {
/*     */         
/*  80 */         throw new RuntimeException(e);
/*     */       } 
/*     */       
/*  83 */       this._master._initialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private EventItem getNextEvent() throws XMLStreamException {
/*  89 */     XMLEvent e = nextEvent();
/*     */     
/*  91 */     return (e == null) ? null : new EventItem(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLEvent next() throws XMLStreamException {
/*  96 */     ensureInit();
/*     */     
/*  98 */     EventItem currentEvent = this._nextEvent;
/*     */     
/* 100 */     if (this._nextEvent != null) {
/*     */       
/* 102 */       if (this._nextEvent._next == null) {
/* 103 */         this._nextEvent._next = this._master.getNextEvent();
/*     */       }
/* 105 */       this._nextEvent = this._nextEvent._next;
/*     */     } 
/*     */     
/* 108 */     if (currentEvent == null) {
/* 109 */       return null;
/*     */     }
/* 111 */     if (currentEvent.getType() == 4) {
/*     */       
/* 113 */       if (--this._elementCount <= 0) {
/* 114 */         this._nextEvent = null;
/*     */       }
/* 116 */     } else if (currentEvent.getType() == 2) {
/* 117 */       this._elementCount++;
/*     */     } 
/* 119 */     return currentEvent._event;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() throws XMLStreamException {
/* 124 */     ensureInit();
/*     */     
/* 126 */     return (this._nextEvent != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void skip() throws XMLStreamException {
/* 131 */     next();
/*     */   }
/*     */ 
/*     */   
/*     */   public void skipElement() throws XMLStreamException {
/* 136 */     ensureInit();
/*     */     
/* 138 */     for (; this._nextEvent != null; next()) {
/*     */       
/* 140 */       if (this._nextEvent.getType() == 2) {
/*     */         break;
/*     */       }
/*     */     } 
/* 144 */     int count = 0;
/*     */     
/* 146 */     for (; this._nextEvent != null; next()) {
/*     */       
/* 148 */       int type = next().getType();
/*     */       
/* 150 */       if (type == 2) {
/* 151 */         count++;
/* 152 */       } else if (type == 4 && --count == 0) {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public XMLEvent peek() throws XMLStreamException {
/* 159 */     ensureInit();
/*     */     
/* 161 */     return this._nextEvent._event;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean skip(int eventType) throws XMLStreamException {
/* 166 */     ensureInit();
/*     */     
/* 168 */     for (; this._nextEvent != null; next()) {
/*     */       
/* 170 */       if (this._nextEvent.getType() == eventType) {
/* 171 */         return true;
/*     */       }
/*     */     } 
/* 174 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean skip(XMLName name) throws XMLStreamException {
/* 179 */     ensureInit();
/*     */     
/* 181 */     for (; this._nextEvent != null; next()) {
/*     */       
/* 183 */       if (this._nextEvent.hasName() && this._nextEvent.getName().equals(name)) {
/* 184 */         return true;
/*     */       }
/*     */     } 
/* 187 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean skip(XMLName name, int eventType) throws XMLStreamException {
/* 192 */     ensureInit();
/*     */     
/* 194 */     for (; this._nextEvent != null; next()) {
/*     */       
/* 196 */       if (this._nextEvent.getType() == eventType && this._nextEvent.hasName() && this._nextEvent.getName().equals(name))
/*     */       {
/*     */ 
/*     */         
/* 200 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 204 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLInputStream getSubStream() throws XMLStreamException {
/* 209 */     ensureInit();
/*     */     
/* 211 */     GenericXmlInputStream subStream = new GenericXmlInputStream(this);
/*     */     
/* 213 */     subStream.skip(2);
/*     */     
/* 215 */     return subStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws XMLStreamException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceResolver getReferenceResolver() {
/* 227 */     ensureInit();
/*     */     
/* 229 */     throw new RuntimeException("Not impl");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReferenceResolver(ReferenceResolver resolver) {
/* 234 */     ensureInit();
/*     */     
/* 236 */     throw new RuntimeException("Not impl");
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\GenericXmlInputStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */