/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadSaveUtils
/*     */ {
/*     */   public static Document xmlText2GenericDom(InputStream is, Document emptyDoc) throws SAXException, ParserConfigurationException, IOException {
/*  43 */     SAXParserFactory factory = SAXParserFactory.newInstance();
/*  44 */     factory.setNamespaceAware(true);
/*     */     
/*  46 */     SAXParser parser = factory.newSAXParser();
/*     */     
/*  48 */     Sax2Dom handler = new Sax2Dom(emptyDoc);
/*     */     
/*  50 */     parser.setProperty("http://xml.org/sax/properties/lexical-handler", handler);
/*  51 */     parser.parse(is, handler);
/*     */     
/*  53 */     return (Document)handler.getDOM();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void xmlStreamReader2XmlText(XMLStreamReader xsr, OutputStream os) throws XMLStreamException {
/*  60 */     XMLStreamWriter xsw = XMLOutputFactory.newInstance().createXMLStreamWriter(os);
/*     */     
/*  62 */     while (xsr.hasNext()) {
/*     */       int attrs, i, nses, j;
/*  64 */       switch (xsr.getEventType()) {
/*     */         
/*     */         case 10:
/*  67 */           xsw.writeAttribute(xsr.getPrefix(), xsr.getNamespaceURI(), xsr.getLocalName(), xsr.getText());
/*     */           break;
/*     */         
/*     */         case 12:
/*  71 */           xsw.writeCData(xsr.getText());
/*     */           break;
/*     */         
/*     */         case 4:
/*  75 */           xsw.writeCharacters(xsr.getText());
/*     */           break;
/*     */         
/*     */         case 5:
/*  79 */           xsw.writeComment(xsr.getText());
/*     */           break;
/*     */         
/*     */         case 11:
/*  83 */           xsw.writeDTD(xsr.getText());
/*     */           break;
/*     */         
/*     */         case 8:
/*  87 */           xsw.writeEndDocument();
/*     */           break;
/*     */         
/*     */         case 2:
/*  91 */           xsw.writeEndElement();
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 9:
/*  98 */           xsw.writeEntityRef(xsr.getText());
/*     */           break;
/*     */         
/*     */         case 13:
/* 102 */           xsw.writeNamespace(xsr.getPrefix(), xsr.getNamespaceURI());
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/* 109 */           xsw.writeProcessingInstruction(xsr.getPITarget(), xsr.getPIData());
/*     */           break;
/*     */         
/*     */         case 6:
/* 113 */           xsw.writeCharacters(xsr.getText());
/*     */           break;
/*     */         
/*     */         case 7:
/* 117 */           xsw.writeStartDocument();
/*     */           break;
/*     */         
/*     */         case 1:
/* 121 */           xsw.writeStartElement((xsr.getPrefix() == null) ? "" : xsr.getPrefix(), xsr.getLocalName(), xsr.getNamespaceURI());
/*     */           
/* 123 */           attrs = xsr.getAttributeCount();
/* 124 */           for (i = attrs - 1; i >= 0; i--)
/*     */           {
/* 126 */             xsw.writeAttribute((xsr.getAttributePrefix(i) == null) ? "" : xsr.getAttributePrefix(i), xsr.getAttributeNamespace(i), xsr.getAttributeLocalName(i), xsr.getAttributeValue(i));
/*     */           }
/*     */           
/* 129 */           nses = xsr.getNamespaceCount();
/* 130 */           for (j = 0; j < nses; j++)
/*     */           {
/* 132 */             xsw.writeNamespace(xsr.getNamespacePrefix(j), xsr.getNamespaceURI(j));
/*     */           }
/*     */           break;
/*     */       } 
/* 136 */       xsr.next();
/*     */     } 
/* 138 */     xsw.flush();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\LoadSaveUtils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */