/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import org.apache.xmlbeans.SchemaTypeLoader;
/*     */ import org.apache.xmlbeans.SystemProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SystemCache
/*     */ {
/*  37 */   private static SystemCache INSTANCE = new SystemCache();
/*     */ 
/*     */   
/*     */   static {
/*  41 */     String cacheClass = SystemProperties.getProperty("xmlbean.systemcacheimpl");
/*  42 */     Object impl = null;
/*  43 */     if (cacheClass != null) {
/*     */       
/*     */       try {
/*     */         
/*  47 */         impl = Class.forName(cacheClass).newInstance();
/*  48 */         if (!(impl instanceof SystemCache)) {
/*  49 */           throw new ClassCastException("Value for system property \"xmlbean.systemcacheimpl\" points to a class (" + cacheClass + ") which does not derive from SystemCache");
/*     */         
/*     */         }
/*     */       }
/*  53 */       catch (ClassNotFoundException cnfe) {
/*     */         
/*  55 */         throw new RuntimeException("Cache class " + cacheClass + " specified by \"xmlbean.systemcacheimpl\" was not found.", cnfe);
/*     */ 
/*     */       
/*     */       }
/*  59 */       catch (InstantiationException ie) {
/*     */         
/*  61 */         throw new RuntimeException("Could not instantiate class " + cacheClass + " as specified by \"xmlbean.systemcacheimpl\"." + " An empty constructor may be missing.", ie);
/*     */ 
/*     */       
/*     */       }
/*  65 */       catch (IllegalAccessException iae) {
/*     */         
/*  67 */         throw new RuntimeException("Could not instantiate class " + cacheClass + " as specified by \"xmlbean.systemcacheimpl\"." + " A public empty constructor may be missing.", iae);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  72 */     if (impl != null) {
/*  73 */       INSTANCE = (SystemCache)impl;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final synchronized void set(SystemCache instance) {
/*  78 */     INSTANCE = instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final SystemCache get() {
/*  83 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public SchemaTypeLoader getFromTypeLoaderCache(ClassLoader cl) {
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addToTypeLoaderCache(SchemaTypeLoader stl, ClassLoader cl) {}
/*     */ 
/*     */   
/*  96 */   private ThreadLocal tl_saxLoaders = new ThreadLocal();
/*     */ 
/*     */   
/*     */   public Object getSaxLoader() {
/* 100 */     SoftReference s = this.tl_saxLoaders.get();
/* 101 */     if (s == null) {
/* 102 */       return null;
/*     */     }
/* 104 */     return s.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSaxLoader(Object saxLoader) {
/* 109 */     this.tl_saxLoaders.set(new SoftReference(saxLoader));
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\SystemCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */