/*    */ package org.apache.xmlbeans.impl.common;
/*    */ 
/*    */ import javax.xml.stream.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidLexicalValueException
/*    */   extends RuntimeException
/*    */ {
/*    */   private Location _location;
/*    */   
/*    */   public InvalidLexicalValueException() {}
/*    */   
/*    */   public InvalidLexicalValueException(String msg) {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   
/*    */   public InvalidLexicalValueException(String msg, Throwable cause) {
/* 41 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public InvalidLexicalValueException(Throwable cause) {
/* 46 */     super(cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public InvalidLexicalValueException(String msg, Location location) {
/* 51 */     super(msg);
/* 52 */     setLocation(location);
/*    */   }
/*    */ 
/*    */   
/*    */   public InvalidLexicalValueException(String msg, Throwable cause, Location location) {
/* 57 */     super(msg, cause);
/* 58 */     setLocation(location);
/*    */   }
/*    */ 
/*    */   
/*    */   public InvalidLexicalValueException(Throwable cause, Location location) {
/* 63 */     super(cause);
/* 64 */     setLocation(location);
/*    */   }
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 69 */     return this._location;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLocation(Location location) {
/* 74 */     this._location = location;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\InvalidLexicalValueException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */