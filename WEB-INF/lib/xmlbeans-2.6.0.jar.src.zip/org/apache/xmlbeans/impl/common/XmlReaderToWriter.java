/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XmlReaderToWriter
/*     */ {
/*     */   public static void writeAll(XMLStreamReader xmlr, XMLStreamWriter writer) throws XMLStreamException {
/*  33 */     while (xmlr.hasNext()) {
/*  34 */       write(xmlr, writer);
/*  35 */       xmlr.next();
/*     */     } 
/*  37 */     write(xmlr, writer);
/*  38 */     writer.flush(); } public static void write(XMLStreamReader xmlr, XMLStreamWriter writer) throws XMLStreamException { String localName;
/*     */     String namespaceURI;
/*     */     int i;
/*     */     String encoding;
/*     */     int len;
/*     */     String version;
/*  44 */     switch (xmlr.getEventType()) {
/*     */       case 1:
/*  46 */         localName = xmlr.getLocalName();
/*  47 */         namespaceURI = xmlr.getNamespaceURI();
/*  48 */         if (namespaceURI != null && namespaceURI.length() > 0)
/*  49 */         { String prefix = xmlr.getPrefix();
/*  50 */           if (prefix != null) {
/*  51 */             writer.writeStartElement(prefix, localName, namespaceURI);
/*     */           } else {
/*     */             
/*  54 */             writer.writeStartElement(namespaceURI, localName);
/*     */           }  }
/*  56 */         else { writer.writeStartElement(localName); }
/*     */ 
/*     */         
/*  59 */         for (i = 0, len = xmlr.getNamespaceCount(); i < len; i++) {
/*  60 */           writer.writeNamespace(xmlr.getNamespacePrefix(i), xmlr.getNamespaceURI(i));
/*     */         }
/*     */ 
/*     */         
/*  64 */         for (i = 0, len = xmlr.getAttributeCount(); i < len; i++) {
/*  65 */           String attUri = xmlr.getAttributeNamespace(i);
/*  66 */           if (attUri != null) {
/*  67 */             writer.writeAttribute(attUri, xmlr.getAttributeLocalName(i), xmlr.getAttributeValue(i));
/*     */           }
/*     */           else {
/*     */             
/*  71 */             writer.writeAttribute(xmlr.getAttributeLocalName(i), xmlr.getAttributeValue(i));
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case 2:
/*  76 */         writer.writeEndElement();
/*     */         break;
/*     */       case 4:
/*     */       case 6:
/*  80 */         writer.writeCharacters(xmlr.getTextCharacters(), xmlr.getTextStart(), xmlr.getTextLength());
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/*  85 */         writer.writeProcessingInstruction(xmlr.getPITarget(), xmlr.getPIData());
/*     */         break;
/*     */       
/*     */       case 12:
/*  89 */         writer.writeCData(xmlr.getText());
/*     */         break;
/*     */       
/*     */       case 5:
/*  93 */         writer.writeComment(xmlr.getText());
/*     */         break;
/*     */       case 9:
/*  96 */         writer.writeEntityRef(xmlr.getLocalName());
/*     */         break;
/*     */       case 7:
/*  99 */         encoding = xmlr.getCharacterEncodingScheme();
/* 100 */         version = xmlr.getVersion();
/*     */         
/* 102 */         if (encoding != null && version != null) {
/* 103 */           writer.writeStartDocument(encoding, version); break;
/*     */         } 
/* 105 */         if (version != null)
/* 106 */           writer.writeStartDocument(xmlr.getVersion()); 
/*     */         break;
/*     */       case 8:
/* 109 */         writer.writeEndDocument();
/*     */         break;
/*     */       case 11:
/* 112 */         writer.writeDTD(xmlr.getText());
/*     */         break;
/*     */     }  }
/*     */ 
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XmlReaderToWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */