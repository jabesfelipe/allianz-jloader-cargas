/*    */ package org.apache.xmlbeans.impl.common;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReaderInputStream
/*    */   extends PushedInputStream
/*    */ {
/*    */   private Reader reader;
/*    */   private Writer writer;
/*    */   private char[] buf;
/* 29 */   public static int defaultBufferSize = 2048;
/*    */ 
/*    */   
/*    */   public ReaderInputStream(Reader reader, String encoding) throws UnsupportedEncodingException {
/* 33 */     this(reader, encoding, defaultBufferSize);
/*    */   }
/*    */ 
/*    */   
/*    */   public ReaderInputStream(Reader reader, String encoding, int bufferSize) throws UnsupportedEncodingException {
/* 38 */     if (bufferSize <= 0) {
/* 39 */       throw new IllegalArgumentException("Buffer size <= 0");
/*    */     }
/* 41 */     this.reader = reader;
/* 42 */     this.writer = new OutputStreamWriter(getOutputStream(), encoding);
/* 43 */     this.buf = new char[bufferSize];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void fill(int requestedBytes) throws IOException {
/*    */     do {
/* 50 */       int chars = this.reader.read(this.buf);
/* 51 */       if (chars < 0) {
/*    */         return;
/*    */       }
/* 54 */       this.writer.write(this.buf, 0, chars);
/* 55 */       this.writer.flush();
/*    */     }
/* 57 */     while (available() <= 0);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\ReaderInputStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */