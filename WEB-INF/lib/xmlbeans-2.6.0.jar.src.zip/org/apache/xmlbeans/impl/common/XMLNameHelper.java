/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.xmlbeans.xml.stream.XMLName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLNameHelper
/*     */ {
/*     */   public static QName getQName(XMLName xmlName) {
/*  26 */     if (xmlName == null) {
/*  27 */       return null;
/*     */     }
/*  29 */     return QNameHelper.forLNS(xmlName.getLocalName(), xmlName.getNamespaceUri());
/*     */   }
/*     */ 
/*     */   
/*     */   public static XMLName forLNS(String localname, String uri) {
/*  34 */     if (uri == null)
/*  35 */       uri = ""; 
/*  36 */     return new XmlNameImpl(uri, localname);
/*     */   }
/*     */ 
/*     */   
/*     */   public static XMLName forLN(String localname) {
/*  41 */     return new XmlNameImpl("", localname);
/*     */   }
/*     */ 
/*     */   
/*     */   public static XMLName forPretty(String pretty, int offset) {
/*  46 */     int at = pretty.indexOf('@', offset);
/*  47 */     if (at < 0)
/*  48 */       return new XmlNameImpl("", pretty.substring(offset)); 
/*  49 */     return new XmlNameImpl(pretty.substring(at + 1), pretty.substring(offset, at));
/*     */   }
/*     */ 
/*     */   
/*     */   public static String pretty(XMLName name) {
/*  54 */     if (name == null) {
/*  55 */       return "null";
/*     */     }
/*  57 */     if (name.getNamespaceUri() == null || name.getNamespaceUri().length() == 0) {
/*  58 */       return name.getLocalName();
/*     */     }
/*  60 */     return name.getLocalName() + "@" + name.getNamespaceUri();
/*     */   }
/*     */   
/*  63 */   private static final char[] hexdigits = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSafe(int c) {
/*  68 */     if (c >= 97 && c <= 122)
/*  69 */       return true; 
/*  70 */     if (c >= 65 && c <= 90)
/*  71 */       return true; 
/*  72 */     if (c >= 48 && c <= 57)
/*  73 */       return true; 
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String hexsafe(String s) {
/*  79 */     StringBuffer result = new StringBuffer();
/*  80 */     for (int i = 0; i < s.length(); i++) {
/*     */       
/*  82 */       char ch = s.charAt(i);
/*  83 */       if (isSafe(ch)) {
/*     */         
/*  85 */         result.append(ch);
/*     */       }
/*     */       else {
/*     */         
/*  89 */         byte[] utf8 = null;
/*     */         
/*     */         try {
/*  92 */           utf8 = s.substring(i, i + 1).getBytes("UTF-8");
/*  93 */           for (int j = 0; j < utf8.length; j++)
/*     */           {
/*  95 */             result.append('_');
/*  96 */             result.append(hexdigits[utf8[j] >> 4 & 0xF]);
/*  97 */             result.append(hexdigits[utf8[j] & 0xF]);
/*     */           }
/*     */         
/* 100 */         } catch (UnsupportedEncodingException uee) {
/*     */ 
/*     */           
/* 103 */           result.append("_BAD_UTF8_CHAR");
/*     */         } 
/*     */       } 
/*     */     } 
/* 107 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String hexsafedir(XMLName name) {
/* 112 */     if (name.getNamespaceUri() == null || name.getNamespaceUri().length() == 0)
/* 113 */       return "_nons/" + hexsafe(name.getLocalName()); 
/* 114 */     return hexsafe(name.getNamespaceUri()) + "/" + hexsafe(name.getLocalName());
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\XMLNameHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */