/*     */ package org.apache.xmlbeans.impl.common;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PushedInputStream
/*     */   extends InputStream
/*     */ {
/*  25 */   private static int defaultBufferSize = 2048;
/*     */   protected byte[] buf;
/*     */   protected int writepos;
/*     */   protected int readpos;
/*  29 */   protected int markpos = -1;
/*     */   protected int marklimit;
/*  31 */   protected OutputStream outputStream = new InternalOutputStream();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final OutputStream getOutputStream() {
/*  51 */     return this.outputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public PushedInputStream() {
/*  56 */     this(defaultBufferSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public PushedInputStream(int size) {
/*  61 */     if (size < 0)
/*     */     {
/*  63 */       throw new IllegalArgumentException("Negative initial buffer size");
/*     */     }
/*  65 */     this.buf = new byte[size];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void shift(int cb) {
/*  73 */     int savepos = this.readpos;
/*  74 */     if (this.markpos > 0)
/*     */     {
/*  76 */       if (this.readpos - this.markpos > this.marklimit) {
/*  77 */         this.markpos = -1;
/*     */       } else {
/*  79 */         savepos = this.markpos;
/*     */       } 
/*     */     }
/*  82 */     int size = this.writepos - savepos;
/*     */     
/*  84 */     if (savepos > 0 && this.buf.length - size >= cb && size <= cb) {
/*     */       
/*  86 */       System.arraycopy(this.buf, savepos, this.buf, 0, size);
/*     */     }
/*     */     else {
/*     */       
/*  90 */       int newcount = size + cb;
/*  91 */       byte[] newbuf = new byte[Math.max(this.buf.length << 1, newcount)];
/*  92 */       System.arraycopy(this.buf, savepos, newbuf, 0, size);
/*  93 */       this.buf = newbuf;
/*     */     } 
/*     */     
/*  96 */     if (savepos > 0) {
/*     */       
/*  98 */       this.readpos -= savepos;
/*  99 */       if (this.markpos > 0)
/* 100 */         this.markpos -= savepos; 
/* 101 */       this.writepos -= savepos;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized int read() throws IOException {
/* 107 */     if (this.readpos >= this.writepos) {
/*     */       
/* 109 */       fill(1);
/* 110 */       if (this.readpos >= this.writepos)
/* 111 */         return -1; 
/*     */     } 
/* 113 */     return this.buf[this.readpos++] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int read(byte[] b, int off, int len) throws IOException {
/* 122 */     int avail = this.writepos - this.readpos;
/* 123 */     if (avail < len) {
/*     */       
/* 125 */       fill(len - avail);
/* 126 */       avail = this.writepos - this.readpos;
/* 127 */       if (avail <= 0) return -1; 
/*     */     } 
/* 129 */     int cnt = (avail < len) ? avail : len;
/* 130 */     System.arraycopy(this.buf, this.readpos, b, off, cnt);
/* 131 */     this.readpos += cnt;
/* 132 */     return cnt;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized long skip(long n) throws IOException {
/* 137 */     if (n <= 0L) {
/* 138 */       return 0L;
/*     */     }
/* 140 */     long avail = (this.writepos - this.readpos);
/*     */     
/* 142 */     if (avail < n) {
/*     */ 
/*     */       
/* 145 */       long req = n - avail;
/* 146 */       if (req > 2147483647L)
/* 147 */         req = 2147483647L; 
/* 148 */       fill((int)req);
/* 149 */       avail = (this.writepos - this.readpos);
/* 150 */       if (avail <= 0L) {
/* 151 */         return 0L;
/*     */       }
/*     */     } 
/* 154 */     long skipped = (avail < n) ? avail : n;
/* 155 */     this.readpos = (int)(this.readpos + skipped);
/* 156 */     return skipped;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized int available() {
/* 161 */     return this.writepos - this.readpos;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void mark(int readlimit) {
/* 166 */     this.marklimit = readlimit;
/* 167 */     this.markpos = this.readpos;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void reset() throws IOException {
/* 172 */     if (this.markpos < 0)
/* 173 */       throw new IOException("Resetting to invalid mark"); 
/* 174 */     this.readpos = this.markpos;
/*     */   }
/*     */   protected abstract void fill(int paramInt) throws IOException;
/*     */   
/*     */   public boolean markSupported() {
/* 179 */     return true;
/*     */   }
/*     */   
/*     */   private class InternalOutputStream extends OutputStream {
/*     */     private final PushedInputStream this$0;
/*     */     
/*     */     public synchronized void write(int b) throws IOException {
/* 186 */       if (PushedInputStream.this.writepos + 1 > PushedInputStream.this.buf.length)
/*     */       {
/* 188 */         PushedInputStream.this.shift(1);
/*     */       }
/* 190 */       PushedInputStream.this.buf[PushedInputStream.this.writepos] = (byte)b;
/* 191 */       PushedInputStream.this.writepos++;
/*     */     }
/*     */     private InternalOutputStream() {}
/*     */     
/*     */     public synchronized void write(byte[] b, int off, int len) {
/* 196 */       if (off < 0 || off > b.length || len < 0 || off + len > b.length || off + len < 0)
/*     */       {
/* 198 */         throw new IndexOutOfBoundsException(); } 
/* 199 */       if (len == 0) {
/*     */         return;
/*     */       }
/* 202 */       if (PushedInputStream.this.writepos + len > PushedInputStream.this.buf.length) {
/* 203 */         PushedInputStream.this.shift(len);
/*     */       }
/* 205 */       System.arraycopy(b, off, PushedInputStream.this.buf, PushedInputStream.this.writepos, len);
/* 206 */       PushedInputStream.this.writepos += len;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\PushedInputStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */