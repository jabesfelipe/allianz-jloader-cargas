/*    */ package org.apache.xmlbeans.impl.common;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SniffedXmlReader
/*    */   extends BufferedReader
/*    */ {
/* 26 */   public static int MAX_SNIFFED_CHARS = 192;
/*    */ 
/*    */   
/*    */   public SniffedXmlReader(Reader reader) throws IOException {
/* 30 */     super(reader);
/* 31 */     this._encoding = sniffForXmlDecl();
/*    */   }
/*    */ 
/*    */   
/*    */   private int readAsMuchAsPossible(char[] buf, int startAt, int len) throws IOException {
/* 36 */     int total = 0;
/* 37 */     while (total < len) {
/*    */       
/* 39 */       int count = read(buf, startAt + total, len - total);
/* 40 */       if (count < 0)
/*    */         break; 
/* 42 */       total += count;
/*    */     } 
/* 44 */     return total;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   private static Charset dummy1 = Charset.forName("UTF-8");
/* 51 */   private static Charset dummy2 = Charset.forName("UTF-16");
/* 52 */   private static Charset dummy3 = Charset.forName("UTF-16BE");
/* 53 */   private static Charset dummy4 = Charset.forName("UTF-16LE");
/* 54 */   private static Charset dummy5 = Charset.forName("ISO-8859-1");
/* 55 */   private static Charset dummy6 = Charset.forName("US-ASCII");
/* 56 */   private static Charset dummy7 = Charset.forName("Cp1252");
/*    */   
/*    */   private String _encoding;
/*    */   
/*    */   private String sniffForXmlDecl() throws IOException {
/* 61 */     mark(MAX_SNIFFED_CHARS);
/*    */     
/*    */     try {
/* 64 */       char[] buf = new char[MAX_SNIFFED_CHARS];
/* 65 */       int limit = readAsMuchAsPossible(buf, 0, MAX_SNIFFED_CHARS);
/* 66 */       return SniffedXmlInputStream.extractXmlDeclEncoding(buf, 0, limit);
/*    */     }
/*    */     finally {
/*    */       
/* 70 */       reset();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getXmlEncoding() {
/* 78 */     return this._encoding;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\SniffedXmlReader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */