/*      */ package org.apache.xmlbeans.impl.common;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConcurrentReaderHashMap
/*      */   extends AbstractMap
/*      */   implements Map, Cloneable, Serializable
/*      */ {
/*      */   protected static class BarrierLock
/*      */     implements Serializable {}
/*      */   
/*  200 */   protected final BarrierLock barrierLock = new BarrierLock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient Object lastWrite;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void recordModification(Object x) {
/*  214 */     synchronized (this.barrierLock) {
/*  215 */       this.lastWrite = x;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Entry[] getTableForReading() {
/*  225 */     synchronized (this.barrierLock) {
/*  226 */       return this.table;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  235 */   public static int DEFAULT_INITIAL_CAPACITY = 32;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MINIMUM_CAPACITY = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MAXIMUM_CAPACITY = 1073741824;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient Entry[] table;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient int count;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int threshold;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected float loadFactor;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient Set keySet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient Set entrySet;
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient Collection values;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int p2capacity(int initialCapacity) {
/*  290 */     int result, cap = initialCapacity;
/*      */ 
/*      */ 
/*      */     
/*  294 */     if (cap > 1073741824 || cap < 0) {
/*  295 */       result = 1073741824;
/*      */     } else {
/*  297 */       result = 4;
/*  298 */       while (result < cap)
/*  299 */         result <<= 1; 
/*      */     } 
/*  301 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int hash(Object x) {
/*  310 */     int h = x.hashCode();
/*      */ 
/*      */ 
/*      */     
/*  314 */     return (h << 7) - h + (h >>> 9) + (h >>> 17);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean eq(Object x, Object y) {
/*  321 */     return (x == y || x.equals(y));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConcurrentReaderHashMap(int initialCapacity) {
/*  360 */     this(initialCapacity, 0.75F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConcurrentReaderHashMap() {
/*  369 */     this(DEFAULT_INITIAL_CAPACITY, 0.75F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConcurrentReaderHashMap(Map t) {
/*  379 */     this(Math.max((int)(t.size() / 0.75F) + 1, 16), 0.75F);
/*      */     
/*  381 */     putAll(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int size() {
/*  391 */     return this.count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isEmpty() {
/*  401 */     return (this.count == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(Object key) {
/*  422 */     int hash = hash(key);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  433 */     Entry[] tab = this.table;
/*  434 */     int index = hash & tab.length - 1;
/*  435 */     Entry first = tab[index];
/*  436 */     Entry e = first;
/*      */     
/*      */     while (true) {
/*  439 */       while (e == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  444 */         Entry[] reread = getTableForReading();
/*  445 */         if (tab == reread && first == tab[index]) {
/*  446 */           return null;
/*      */         }
/*      */         
/*  449 */         tab = reread;
/*  450 */         e = first = tab[index = hash & tab.length - 1];
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  455 */       if (e.hash == hash && eq(key, e.key)) {
/*  456 */         Object value = e.value;
/*  457 */         if (value != null) {
/*  458 */           return value;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  465 */         synchronized (this) {
/*  466 */           tab = this.table;
/*      */         } 
/*  468 */         e = first = tab[index = hash & tab.length - 1];
/*      */         
/*      */         continue;
/*      */       } 
/*  472 */       e = e.next;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsKey(Object key) {
/*  491 */     return (get(key) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object put(Object key, Object value) {
/*  513 */     if (value == null) {
/*  514 */       throw new NullPointerException();
/*      */     }
/*  516 */     int hash = hash(key);
/*  517 */     Entry[] tab = this.table;
/*  518 */     int index = hash & tab.length - 1;
/*  519 */     Entry first = tab[index];
/*      */     
/*      */     Entry e;
/*  522 */     for (e = first; e != null && (
/*  523 */       e.hash != hash || !eq(key, e.key)); e = e.next);
/*      */ 
/*      */     
/*  526 */     synchronized (this) {
/*  527 */       if (tab == this.table) {
/*  528 */         if (e == null) {
/*      */           
/*  530 */           if (first == tab[index]) {
/*      */             
/*  532 */             Entry newEntry = new Entry(hash, key, value, first);
/*  533 */             tab[index] = newEntry;
/*  534 */             if (++this.count >= this.threshold) { rehash(); }
/*  535 */             else { recordModification(newEntry); }
/*  536 */              return null;
/*      */           } 
/*      */         } else {
/*      */           
/*  540 */           Object oldValue = e.value;
/*  541 */           if (first == tab[index] && oldValue != null) {
/*  542 */             e.value = value;
/*  543 */             return oldValue;
/*      */           } 
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  549 */       return sput(key, value, hash);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object sput(Object key, Object value, int hash) {
/*  560 */     Entry[] tab = this.table;
/*  561 */     int index = hash & tab.length - 1;
/*  562 */     Entry first = tab[index];
/*  563 */     Entry e = first;
/*      */     
/*      */     while (true) {
/*  566 */       if (e == null) {
/*  567 */         Entry newEntry = new Entry(hash, key, value, first);
/*  568 */         tab[index] = newEntry;
/*  569 */         if (++this.count >= this.threshold) { rehash(); }
/*  570 */         else { recordModification(newEntry); }
/*  571 */          return null;
/*      */       } 
/*  573 */       if (e.hash == hash && eq(key, e.key)) {
/*  574 */         Object oldValue = e.value;
/*  575 */         e.value = value;
/*  576 */         return oldValue;
/*      */       } 
/*      */       
/*  579 */       e = e.next;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void rehash() {
/*  590 */     Entry[] oldTable = this.table;
/*  591 */     int oldCapacity = oldTable.length;
/*  592 */     if (oldCapacity >= 1073741824) {
/*  593 */       this.threshold = Integer.MAX_VALUE;
/*      */       
/*      */       return;
/*      */     } 
/*  597 */     int newCapacity = oldCapacity << 1;
/*  598 */     int mask = newCapacity - 1;
/*  599 */     this.threshold = (int)(newCapacity * this.loadFactor);
/*      */     
/*  601 */     Entry[] newTable = new Entry[newCapacity];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  616 */     for (int i = 0; i < oldCapacity; i++) {
/*      */ 
/*      */       
/*  619 */       Entry e = oldTable[i];
/*      */       
/*  621 */       if (e != null) {
/*  622 */         int idx = e.hash & mask;
/*  623 */         Entry next = e.next;
/*      */ 
/*      */         
/*  626 */         if (next == null) {
/*  627 */           newTable[idx] = e;
/*      */         }
/*      */         else {
/*      */           
/*  631 */           Entry lastRun = e;
/*  632 */           int lastIdx = idx;
/*  633 */           for (Entry last = next; last != null; last = last.next) {
/*  634 */             int k = last.hash & mask;
/*  635 */             if (k != lastIdx) {
/*  636 */               lastIdx = k;
/*  637 */               lastRun = last;
/*      */             } 
/*      */           } 
/*  640 */           newTable[lastIdx] = lastRun;
/*      */ 
/*      */           
/*  643 */           for (Entry p = e; p != lastRun; p = p.next) {
/*  644 */             int k = p.hash & mask;
/*  645 */             newTable[k] = new Entry(p.hash, p.key, p.value, newTable[k]);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  652 */     this.table = newTable;
/*  653 */     recordModification(newTable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object remove(Object key) {
/*  679 */     int hash = hash(key);
/*  680 */     Entry[] tab = this.table;
/*  681 */     int index = hash & tab.length - 1;
/*  682 */     Entry first = tab[index];
/*  683 */     Entry e = first;
/*      */     
/*  685 */     for (e = first; e != null && (
/*  686 */       e.hash != hash || !eq(key, e.key)); e = e.next);
/*      */ 
/*      */ 
/*      */     
/*  690 */     synchronized (this) {
/*  691 */       if (tab == this.table) {
/*  692 */         if (e == null) {
/*  693 */           if (first == tab[index]) {
/*  694 */             return null;
/*      */           }
/*      */         } else {
/*  697 */           Object oldValue = e.value;
/*  698 */           if (first == tab[index] && oldValue != null) {
/*  699 */             e.value = null;
/*  700 */             this.count--;
/*      */             
/*  702 */             Entry head = e.next;
/*  703 */             for (Entry p = first; p != e; p = p.next) {
/*  704 */               head = new Entry(p.hash, p.key, p.value, head);
/*      */             }
/*  706 */             tab[index] = head;
/*  707 */             recordModification(head);
/*  708 */             return oldValue;
/*      */           } 
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  714 */       return sremove(key, hash);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object sremove(Object key, int hash) {
/*  724 */     Entry[] tab = this.table;
/*  725 */     int index = hash & tab.length - 1;
/*  726 */     Entry first = tab[index];
/*      */     
/*  728 */     for (Entry e = first; e != null; e = e.next) {
/*  729 */       if (e.hash == hash && eq(key, e.key)) {
/*  730 */         Object oldValue = e.value;
/*  731 */         e.value = null;
/*  732 */         this.count--;
/*  733 */         Entry head = e.next;
/*  734 */         for (Entry p = first; p != e; p = p.next) {
/*  735 */           head = new Entry(p.hash, p.key, p.value, head);
/*      */         }
/*  737 */         tab[index] = head;
/*  738 */         recordModification(head);
/*  739 */         return oldValue;
/*      */       } 
/*      */     } 
/*  742 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsValue(Object value) {
/*  759 */     if (value == null) throw new NullPointerException();
/*      */     
/*  761 */     Entry[] tab = getTableForReading();
/*      */     
/*  763 */     for (int i = 0; i < tab.length; i++) {
/*  764 */       for (Entry e = tab[i]; e != null; e = e.next) {
/*  765 */         if (value.equals(e.value))
/*  766 */           return true; 
/*      */       } 
/*      */     } 
/*  769 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(Object value) {
/*  792 */     return containsValue(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void putAll(Map t) {
/*  806 */     int n = t.size();
/*  807 */     if (n == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  813 */     while (n >= this.threshold) {
/*  814 */       rehash();
/*      */     }
/*  816 */     for (Iterator it = t.entrySet().iterator(); it.hasNext(); ) {
/*  817 */       Map.Entry entry = it.next();
/*  818 */       Object key = entry.getKey();
/*  819 */       Object value = entry.getValue();
/*  820 */       put(key, value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clear() {
/*  829 */     Entry[] tab = this.table;
/*  830 */     for (int i = 0; i < tab.length; i++) {
/*      */ 
/*      */       
/*  833 */       for (Entry e = tab[i]; e != null; e = e.next) {
/*  834 */         e.value = null;
/*      */       }
/*  836 */       tab[i] = null;
/*      */     } 
/*  838 */     this.count = 0;
/*  839 */     recordModification(tab);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Object clone() {
/*      */     try {
/*  852 */       ConcurrentReaderHashMap t = (ConcurrentReaderHashMap)super.clone();
/*      */       
/*  854 */       t.keySet = null;
/*  855 */       t.entrySet = null;
/*  856 */       t.values = null;
/*      */       
/*  858 */       Entry[] tab = this.table;
/*  859 */       t.table = new Entry[tab.length];
/*  860 */       Entry[] ttab = t.table;
/*      */       
/*  862 */       for (int i = 0; i < tab.length; i++) {
/*  863 */         Entry first = null;
/*  864 */         for (Entry e = tab[i]; e != null; e = e.next)
/*  865 */           first = new Entry(e.hash, e.key, e.value, first); 
/*  866 */         ttab[i] = first;
/*      */       } 
/*      */       
/*  869 */       return t;
/*      */     }
/*  871 */     catch (CloneNotSupportedException e) {
/*      */       
/*  873 */       throw new InternalError();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ConcurrentReaderHashMap(int initialCapacity, float loadFactor) {
/*  879 */     this.keySet = null;
/*  880 */     this.entrySet = null;
/*  881 */     this.values = null;
/*      */     if (loadFactor <= 0.0F) {
/*      */       throw new IllegalArgumentException("Illegal Load factor: " + loadFactor);
/*      */     }
/*      */     this.loadFactor = loadFactor;
/*      */     int cap = p2capacity(initialCapacity);
/*      */     this.table = new Entry[cap];
/*      */     this.threshold = (int)(cap * loadFactor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set keySet() {
/*  896 */     Set ks = this.keySet;
/*  897 */     return (ks != null) ? ks : (this.keySet = new KeySet());
/*      */   }
/*      */   private class KeySet extends AbstractSet { private final ConcurrentReaderHashMap this$0;
/*      */     
/*      */     public Iterator iterator() {
/*  902 */       return new ConcurrentReaderHashMap.KeyIterator();
/*      */     } private KeySet() {}
/*      */     public int size() {
/*  905 */       return ConcurrentReaderHashMap.this.size();
/*      */     }
/*      */     public boolean contains(Object o) {
/*  908 */       return ConcurrentReaderHashMap.this.containsKey(o);
/*      */     }
/*      */     public boolean remove(Object o) {
/*  911 */       return (ConcurrentReaderHashMap.this.remove(o) != null);
/*      */     }
/*      */     public void clear() {
/*  914 */       ConcurrentReaderHashMap.this.clear();
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection values() {
/*  931 */     Collection vs = this.values;
/*  932 */     return (vs != null) ? vs : (this.values = new Values());
/*      */   }
/*      */   private class Values extends AbstractCollection { private final ConcurrentReaderHashMap this$0;
/*      */     private Values() {}
/*      */     public Iterator iterator() {
/*  937 */       return new ConcurrentReaderHashMap.ValueIterator();
/*      */     }
/*      */     public int size() {
/*  940 */       return ConcurrentReaderHashMap.this.size();
/*      */     }
/*      */     public boolean contains(Object o) {
/*  943 */       return ConcurrentReaderHashMap.this.containsValue(o);
/*      */     }
/*      */     public void clear() {
/*  946 */       ConcurrentReaderHashMap.this.clear();
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set entrySet() {
/*  964 */     Set es = this.entrySet;
/*  965 */     return (es != null) ? es : (this.entrySet = new EntrySet());
/*      */   }
/*      */   private class EntrySet extends AbstractSet { private final ConcurrentReaderHashMap this$0;
/*      */     private EntrySet() {}
/*      */     public Iterator iterator() {
/*  970 */       return new ConcurrentReaderHashMap.HashIterator();
/*      */     }
/*      */     public boolean contains(Object o) {
/*  973 */       if (!(o instanceof Map.Entry))
/*  974 */         return false; 
/*  975 */       Map.Entry entry = (Map.Entry)o;
/*  976 */       Object v = ConcurrentReaderHashMap.this.get(entry.getKey());
/*  977 */       return (v != null && v.equals(entry.getValue()));
/*      */     }
/*      */     public boolean remove(Object o) {
/*  980 */       if (!(o instanceof Map.Entry))
/*  981 */         return false; 
/*  982 */       return ConcurrentReaderHashMap.this.findAndRemoveEntry((Map.Entry)o);
/*      */     }
/*      */     public int size() {
/*  985 */       return ConcurrentReaderHashMap.this.size();
/*      */     }
/*      */     public void clear() {
/*  988 */       ConcurrentReaderHashMap.this.clear();
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized boolean findAndRemoveEntry(Map.Entry entry) {
/*  996 */     Object key = entry.getKey();
/*  997 */     Object v = get(key);
/*  998 */     if (v != null && v.equals(entry.getValue())) {
/*  999 */       remove(key);
/* 1000 */       return true;
/*      */     } 
/*      */     
/* 1003 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration keys() {
/* 1016 */     return new KeyIterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enumeration elements() {
/* 1032 */     return new ValueIterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class Entry
/*      */     implements Map.Entry
/*      */   {
/*      */     protected final int hash;
/*      */ 
/*      */     
/*      */     protected final Object key;
/*      */ 
/*      */     
/*      */     protected final Entry next;
/*      */ 
/*      */     
/*      */     protected volatile Object value;
/*      */ 
/*      */ 
/*      */     
/*      */     Entry(int hash, Object key, Object value, Entry next) {
/* 1055 */       this.hash = hash;
/* 1056 */       this.key = key;
/* 1057 */       this.next = next;
/* 1058 */       this.value = value;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Object getKey() {
/* 1064 */       return this.key;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object getValue() {
/* 1080 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object setValue(Object value) {
/* 1105 */       if (value == null)
/* 1106 */         throw new NullPointerException(); 
/* 1107 */       Object oldValue = this.value;
/* 1108 */       this.value = value;
/* 1109 */       return oldValue;
/*      */     }
/*      */     
/*      */     public boolean equals(Object o) {
/* 1113 */       if (!(o instanceof Map.Entry))
/* 1114 */         return false; 
/* 1115 */       Map.Entry e = (Map.Entry)o;
/* 1116 */       return (this.key.equals(e.getKey()) && this.value.equals(e.getValue()));
/*      */     }
/*      */     
/*      */     public int hashCode() {
/* 1120 */       return this.key.hashCode() ^ this.value.hashCode();
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1124 */       return this.key + "=" + this.value;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class HashIterator
/*      */     implements Iterator, Enumeration {
/*      */     protected final ConcurrentReaderHashMap.Entry[] tab;
/*      */     protected int index;
/* 1132 */     protected ConcurrentReaderHashMap.Entry entry = null;
/*      */     protected Object currentKey;
/*      */     protected Object currentValue;
/* 1135 */     protected ConcurrentReaderHashMap.Entry lastReturned = null; private final ConcurrentReaderHashMap this$0;
/*      */     
/*      */     protected HashIterator() {
/* 1138 */       this.tab = ConcurrentReaderHashMap.this.getTableForReading();
/* 1139 */       this.index = this.tab.length - 1;
/*      */     }
/*      */     
/* 1142 */     public boolean hasMoreElements() { return hasNext(); } public Object nextElement() {
/* 1143 */       return next();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/*      */       while (true) {
/* 1157 */         if (this.entry != null) {
/* 1158 */           Object v = this.entry.value;
/* 1159 */           if (v != null) {
/* 1160 */             this.currentKey = this.entry.key;
/* 1161 */             this.currentValue = v;
/* 1162 */             return true;
/*      */           } 
/*      */           
/* 1165 */           this.entry = this.entry.next;
/*      */         } 
/*      */         
/* 1168 */         while (this.entry == null && this.index >= 0) {
/* 1169 */           this.entry = this.tab[this.index--];
/*      */         }
/* 1171 */         if (this.entry == null) {
/* 1172 */           this.currentKey = this.currentValue = null;
/* 1173 */           return false;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     protected Object returnValueOfNext() {
/* 1178 */       return this.entry;
/*      */     }
/*      */     public Object next() {
/* 1181 */       if (this.currentKey == null && !hasNext()) {
/* 1182 */         throw new NoSuchElementException();
/*      */       }
/* 1184 */       Object result = returnValueOfNext();
/* 1185 */       this.lastReturned = this.entry;
/* 1186 */       this.currentKey = this.currentValue = null;
/* 1187 */       this.entry = this.entry.next;
/* 1188 */       return result;
/*      */     }
/*      */     
/*      */     public void remove() {
/* 1192 */       if (this.lastReturned == null)
/* 1193 */         throw new IllegalStateException(); 
/* 1194 */       ConcurrentReaderHashMap.this.remove(this.lastReturned.key);
/* 1195 */       this.lastReturned = null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class KeyIterator extends HashIterator { private final ConcurrentReaderHashMap this$0;
/*      */     
/*      */     protected Object returnValueOfNext() {
/* 1202 */       return this.currentKey;
/*      */     } }
/*      */   protected class ValueIterator extends HashIterator { private final ConcurrentReaderHashMap this$0;
/*      */     protected Object returnValueOfNext() {
/* 1206 */       return this.currentValue;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void writeObject(ObjectOutputStream s) throws IOException {
/* 1228 */     s.defaultWriteObject();
/*      */ 
/*      */     
/* 1231 */     s.writeInt(this.table.length);
/*      */ 
/*      */     
/* 1234 */     s.writeInt(this.count);
/*      */ 
/*      */     
/* 1237 */     for (int index = this.table.length - 1; index >= 0; index--) {
/* 1238 */       Entry entry = this.table[index];
/*      */       
/* 1240 */       while (entry != null) {
/* 1241 */         s.writeObject(entry.key);
/* 1242 */         s.writeObject(entry.value);
/* 1243 */         entry = entry.next;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 1256 */     s.defaultReadObject();
/*      */ 
/*      */     
/* 1259 */     int numBuckets = s.readInt();
/* 1260 */     this.table = new Entry[numBuckets];
/*      */ 
/*      */     
/* 1263 */     int size = s.readInt();
/*      */ 
/*      */     
/* 1266 */     for (int i = 0; i < size; i++) {
/* 1267 */       Object key = s.readObject();
/* 1268 */       Object value = s.readObject();
/* 1269 */       put(key, value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int capacity() {
/* 1278 */     return this.table.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float loadFactor() {
/* 1285 */     return this.loadFactor;
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\common\ConcurrentReaderHashMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */