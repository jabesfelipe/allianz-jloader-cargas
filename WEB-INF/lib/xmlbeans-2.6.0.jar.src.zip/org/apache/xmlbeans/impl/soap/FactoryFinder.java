/*     */ package org.apache.xmlbeans.impl.soap;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Properties;
/*     */ import org.apache.xmlbeans.SystemProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FactoryFinder
/*     */ {
/*     */   private static Object newInstance(String factoryClassName) throws SOAPException {
/*  41 */     ClassLoader classloader = null;
/*     */     try {
/*  43 */       classloader = Thread.currentThread().getContextClassLoader();
/*  44 */     } catch (Exception exception) {
/*  45 */       throw new SOAPException(exception.toString(), exception);
/*     */     } 
/*     */     
/*     */     try {
/*  49 */       Class factory = null;
/*  50 */       if (classloader == null) {
/*  51 */         factory = Class.forName(factoryClassName);
/*     */       } else {
/*     */         try {
/*  54 */           factory = classloader.loadClass(factoryClassName);
/*  55 */         } catch (ClassNotFoundException cnfe) {}
/*     */       } 
/*  57 */       if (factory == null) {
/*  58 */         classloader = FactoryFinder.class.getClassLoader();
/*  59 */         factory = classloader.loadClass(factoryClassName);
/*     */       } 
/*  61 */       return factory.newInstance();
/*  62 */     } catch (ClassNotFoundException classnotfoundexception) {
/*  63 */       throw new SOAPException("Provider " + factoryClassName + " not found", classnotfoundexception);
/*  64 */     } catch (Exception exception) {
/*  65 */       throw new SOAPException("Provider " + factoryClassName + " could not be instantiated: " + exception, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object find(String factoryPropertyName, String defaultFactoryClassName) throws SOAPException {
/*     */     try {
/*  80 */       String factoryClassName = SystemProperties.getProperty(factoryPropertyName);
/*  81 */       if (factoryClassName != null) {
/*  82 */         return newInstance(factoryClassName);
/*     */       }
/*  84 */     } catch (SecurityException securityexception) {}
/*     */     
/*     */     try {
/*  87 */       String propertiesFileName = SystemProperties.getProperty("java.home") + File.separator + "lib" + File.separator + "jaxm.properties";
/*     */ 
/*     */       
/*  90 */       File file = new File(propertiesFileName);
/*  91 */       if (file.exists()) {
/*  92 */         FileInputStream fileInput = new FileInputStream(file);
/*  93 */         Properties properties = new Properties();
/*  94 */         properties.load(fileInput);
/*  95 */         fileInput.close();
/*  96 */         String factoryClassName = properties.getProperty(factoryPropertyName);
/*  97 */         return newInstance(factoryClassName);
/*     */       } 
/*  99 */     } catch (Exception exception1) {}
/*     */     
/* 101 */     String factoryResource = "META-INF/services/" + factoryPropertyName;
/*     */     
/*     */     try {
/* 104 */       InputStream inputstream = getResource(factoryResource);
/* 105 */       if (inputstream != null) {
/* 106 */         BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputstream, "UTF-8"));
/* 107 */         String factoryClassName = bufferedreader.readLine();
/* 108 */         bufferedreader.close();
/* 109 */         if (factoryClassName != null && !"".equals(factoryClassName)) {
/* 110 */           return newInstance(factoryClassName);
/*     */         }
/*     */       } 
/* 113 */     } catch (Exception exception2) {}
/*     */     
/* 115 */     if (defaultFactoryClassName == null) {
/* 116 */       throw new SOAPException("Provider for " + factoryPropertyName + " cannot be found", null);
/*     */     }
/* 118 */     return newInstance(defaultFactoryClassName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static InputStream getResource(String factoryResource) {
/*     */     InputStream inputstream;
/* 137 */     ClassLoader classloader = null;
/*     */     try {
/* 139 */       classloader = Thread.currentThread().getContextClassLoader();
/* 140 */     } catch (SecurityException securityexception) {}
/*     */ 
/*     */     
/* 143 */     if (classloader == null) {
/* 144 */       inputstream = ClassLoader.getSystemResourceAsStream(factoryResource);
/*     */     } else {
/* 146 */       inputstream = classloader.getResourceAsStream(factoryResource);
/*     */     } 
/*     */     
/* 149 */     if (inputstream == null) {
/* 150 */       inputstream = FactoryFinder.class.getClassLoader().getResourceAsStream(factoryResource);
/*     */     }
/* 152 */     return inputstream;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\soap\FactoryFinder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */