package org.apache.xmlbeans.impl.soap;

public interface SOAPBodyElement extends SOAPElement {}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\soap\SOAPBodyElement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */