/*      */ package org.apache.xmlbeans.impl.richParser;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.InputStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Date;
/*      */ import javax.xml.namespace.NamespaceContext;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.stream.Location;
/*      */ import javax.xml.stream.XMLStreamException;
/*      */ import javax.xml.stream.XMLStreamReader;
/*      */ import org.apache.xmlbeans.GDate;
/*      */ import org.apache.xmlbeans.GDateBuilder;
/*      */ import org.apache.xmlbeans.GDuration;
/*      */ import org.apache.xmlbeans.XmlCalendar;
/*      */ import org.apache.xmlbeans.impl.common.InvalidLexicalValueException;
/*      */ import org.apache.xmlbeans.impl.common.XMLChar;
/*      */ import org.apache.xmlbeans.impl.common.XmlWhitespace;
/*      */ import org.apache.xmlbeans.impl.util.Base64;
/*      */ import org.apache.xmlbeans.impl.util.HexBin;
/*      */ import org.apache.xmlbeans.impl.util.XsTypeConverter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XMLStreamReaderExtImpl
/*      */   implements XMLStreamReaderExt
/*      */ {
/*      */   private final XMLStreamReader _xmlStream;
/*      */   private final CharSeqTrimWS _charSeq;
/*      */   private String _defaultValue;
/*      */   static Class class$org$apache$xmlbeans$impl$richParser$XMLStreamReaderExtImpl;
/*      */   
/*      */   public XMLStreamReaderExtImpl(XMLStreamReader xmlStream) {
/*   53 */     if (xmlStream == null) {
/*   54 */       throw new IllegalArgumentException();
/*      */     }
/*   56 */     this._xmlStream = xmlStream;
/*   57 */     this._charSeq = new CharSeqTrimWS(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public XMLStreamReader getUnderlyingXmlStream() {
/*   62 */     return this._xmlStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringValue() throws XMLStreamException {
/*   69 */     this._charSeq.reload(1);
/*   70 */     return this._charSeq.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringValue(int wsStyle) throws XMLStreamException {
/*   76 */     this._charSeq.reload(1);
/*      */ 
/*      */     
/*   79 */     return XmlWhitespace.collapse(this._charSeq.toString(), wsStyle);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBooleanValue() throws XMLStreamException, InvalidLexicalValueException {
/*   85 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*   88 */       return XsTypeConverter.lexBoolean(this._charSeq);
/*      */     }
/*   90 */     catch (InvalidLexicalValueException e) {
/*      */       
/*   92 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByteValue() throws XMLStreamException, InvalidLexicalValueException {
/*   99 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  102 */       return XsTypeConverter.lexByte(this._charSeq);
/*      */     }
/*  104 */     catch (NumberFormatException e) {
/*      */       
/*  106 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShortValue() throws XMLStreamException, InvalidLexicalValueException {
/*  113 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  116 */       return XsTypeConverter.lexShort(this._charSeq);
/*      */     }
/*  118 */     catch (NumberFormatException e) {
/*      */       
/*  120 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntValue() throws XMLStreamException, InvalidLexicalValueException {
/*  127 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  130 */       return XsTypeConverter.lexInt(this._charSeq);
/*      */     }
/*  132 */     catch (NumberFormatException e) {
/*      */       
/*  134 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLongValue() throws XMLStreamException, InvalidLexicalValueException {
/*  141 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  144 */       return XsTypeConverter.lexLong(this._charSeq);
/*      */     }
/*  146 */     catch (NumberFormatException e) {
/*      */       
/*  148 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getBigIntegerValue() throws XMLStreamException, InvalidLexicalValueException {
/*  155 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  158 */       return XsTypeConverter.lexInteger(this._charSeq);
/*      */     }
/*  160 */     catch (NumberFormatException e) {
/*      */       
/*  162 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimalValue() throws XMLStreamException, InvalidLexicalValueException {
/*  169 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  172 */       return XsTypeConverter.lexDecimal(this._charSeq);
/*      */     }
/*  174 */     catch (NumberFormatException e) {
/*      */       
/*  176 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloatValue() throws XMLStreamException, InvalidLexicalValueException {
/*  183 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  186 */       return XsTypeConverter.lexFloat(this._charSeq);
/*      */     }
/*  188 */     catch (NumberFormatException e) {
/*      */       
/*  190 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDoubleValue() throws XMLStreamException, InvalidLexicalValueException {
/*  197 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  200 */       return XsTypeConverter.lexDouble(this._charSeq);
/*      */     }
/*  202 */     catch (NumberFormatException e) {
/*      */       
/*  204 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getHexBinaryValue() throws XMLStreamException, InvalidLexicalValueException {
/*  211 */     this._charSeq.reload(2);
/*  212 */     String text = this._charSeq.toString();
/*  213 */     byte[] buf = HexBin.decode(text.getBytes());
/*  214 */     if (buf != null) {
/*  215 */       return new ByteArrayInputStream(buf);
/*      */     }
/*  217 */     throw new InvalidLexicalValueException("invalid hexBinary value", this._charSeq.getLocation());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBase64Value() throws XMLStreamException, InvalidLexicalValueException {
/*  223 */     this._charSeq.reload(2);
/*  224 */     String text = this._charSeq.toString();
/*  225 */     byte[] buf = Base64.decode(text.getBytes());
/*  226 */     if (buf != null) {
/*  227 */       return new ByteArrayInputStream(buf);
/*      */     }
/*  229 */     throw new InvalidLexicalValueException("invalid base64Binary value", this._charSeq.getLocation());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlCalendar getCalendarValue() throws XMLStreamException, InvalidLexicalValueException {
/*  235 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  238 */       return (new GDateBuilder(this._charSeq)).getCalendar();
/*      */     }
/*  240 */     catch (IllegalArgumentException e) {
/*      */       
/*  242 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDateValue() throws XMLStreamException, InvalidLexicalValueException {
/*  249 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  252 */       return (new GDateBuilder(this._charSeq)).getDate();
/*      */     }
/*  254 */     catch (IllegalArgumentException e) {
/*      */       
/*  256 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public GDate getGDateValue() throws XMLStreamException, InvalidLexicalValueException {
/*  263 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  266 */       return XsTypeConverter.lexGDate(this._charSeq);
/*      */     }
/*  268 */     catch (IllegalArgumentException e) {
/*      */       
/*  270 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public GDuration getGDurationValue() throws XMLStreamException, InvalidLexicalValueException {
/*  277 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  280 */       return new GDuration(this._charSeq);
/*      */     }
/*  282 */     catch (IllegalArgumentException e) {
/*      */       
/*  284 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QName getQNameValue() throws XMLStreamException, InvalidLexicalValueException {
/*  291 */     this._charSeq.reload(2);
/*      */     
/*      */     try {
/*  294 */       return XsTypeConverter.lexQName(this._charSeq, this._xmlStream.getNamespaceContext());
/*      */     }
/*  296 */     catch (InvalidLexicalValueException e) {
/*      */       
/*  298 */       throw new InvalidLexicalValueException(e.getMessage(), this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeStringValue(int index) throws XMLStreamException {
/*  304 */     return this._xmlStream.getAttributeValue(index);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeStringValue(int index, int wsStyle) throws XMLStreamException {
/*  309 */     return XmlWhitespace.collapse(this._xmlStream.getAttributeValue(index), wsStyle);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAttributeBooleanValue(int index) throws XMLStreamException {
/*      */     try {
/*  316 */       return XsTypeConverter.lexBoolean(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  318 */     catch (InvalidLexicalValueException e) {
/*      */       
/*  320 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getAttributeByteValue(int index) throws XMLStreamException {
/*      */     try {
/*  328 */       return XsTypeConverter.lexByte(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  330 */     catch (NumberFormatException e) {
/*      */       
/*  332 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getAttributeShortValue(int index) throws XMLStreamException {
/*      */     try {
/*  340 */       return XsTypeConverter.lexShort(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  342 */     catch (NumberFormatException e) {
/*      */       
/*  344 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAttributeIntValue(int index) throws XMLStreamException {
/*      */     try {
/*  352 */       return XsTypeConverter.lexInt(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  354 */     catch (NumberFormatException e) {
/*      */       
/*  356 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getAttributeLongValue(int index) throws XMLStreamException {
/*      */     try {
/*  364 */       return XsTypeConverter.lexLong(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  366 */     catch (NumberFormatException e) {
/*      */       
/*  368 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getAttributeBigIntegerValue(int index) throws XMLStreamException {
/*      */     try {
/*  376 */       return XsTypeConverter.lexInteger(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  378 */     catch (NumberFormatException e) {
/*      */       
/*  380 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getAttributeBigDecimalValue(int index) throws XMLStreamException {
/*      */     try {
/*  388 */       return XsTypeConverter.lexDecimal(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  390 */     catch (NumberFormatException e) {
/*      */       
/*  392 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getAttributeFloatValue(int index) throws XMLStreamException {
/*      */     try {
/*  400 */       return XsTypeConverter.lexFloat(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  402 */     catch (NumberFormatException e) {
/*      */       
/*  404 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getAttributeDoubleValue(int index) throws XMLStreamException {
/*      */     try {
/*  412 */       return XsTypeConverter.lexDouble(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  414 */     catch (NumberFormatException e) {
/*      */       
/*  416 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getAttributeHexBinaryValue(int index) throws XMLStreamException {
/*  422 */     String text = this._charSeq.reloadAtt(index, 2).toString();
/*  423 */     byte[] buf = HexBin.decode(text.getBytes());
/*  424 */     if (buf != null) {
/*  425 */       return new ByteArrayInputStream(buf);
/*      */     }
/*  427 */     throw new InvalidLexicalValueException("invalid hexBinary value", this._charSeq.getLocation());
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getAttributeBase64Value(int index) throws XMLStreamException {
/*  432 */     String text = this._charSeq.reloadAtt(index, 2).toString();
/*  433 */     byte[] buf = Base64.decode(text.getBytes());
/*  434 */     if (buf != null) {
/*  435 */       return new ByteArrayInputStream(buf);
/*      */     }
/*  437 */     throw new InvalidLexicalValueException("invalid base64Binary value", this._charSeq.getLocation());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public XmlCalendar getAttributeCalendarValue(int index) throws XMLStreamException {
/*      */     try {
/*  444 */       return (new GDateBuilder(this._charSeq.reloadAtt(index, 2))).getCalendar();
/*      */     
/*      */     }
/*  447 */     catch (IllegalArgumentException e) {
/*      */       
/*  449 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getAttributeDateValue(int index) throws XMLStreamException {
/*      */     try {
/*  457 */       return (new GDateBuilder(this._charSeq.reloadAtt(index, 2))).getDate();
/*      */     
/*      */     }
/*  460 */     catch (IllegalArgumentException e) {
/*      */       
/*  462 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public GDate getAttributeGDateValue(int index) throws XMLStreamException {
/*      */     try {
/*  470 */       return new GDate(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  472 */     catch (IllegalArgumentException e) {
/*      */       
/*  474 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public GDuration getAttributeGDurationValue(int index) throws XMLStreamException {
/*      */     try {
/*  482 */       return new GDuration(this._charSeq.reloadAtt(index, 2));
/*      */     }
/*  484 */     catch (IllegalArgumentException e) {
/*      */       
/*  486 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QName getAttributeQNameValue(int index) throws XMLStreamException {
/*      */     try {
/*  494 */       return XsTypeConverter.lexQName(this._charSeq.reloadAtt(index, 2), this._xmlStream.getNamespaceContext());
/*      */     
/*      */     }
/*  497 */     catch (InvalidLexicalValueException e) {
/*      */       
/*  499 */       throw new InvalidLexicalValueException(e.getMessage(), this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeStringValue(String uri, String local) throws XMLStreamException {
/*  505 */     return this._charSeq.reloadAtt(uri, local, 1).toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeStringValue(String uri, String local, int wsStyle) throws XMLStreamException {
/*  510 */     return XmlWhitespace.collapse(this._xmlStream.getAttributeValue(uri, local), wsStyle);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getAttributeBooleanValue(String uri, String local) throws XMLStreamException {
/*  515 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  518 */       return XsTypeConverter.lexBoolean(cs);
/*      */     }
/*  520 */     catch (InvalidLexicalValueException e) {
/*      */       
/*  522 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getAttributeByteValue(String uri, String local) throws XMLStreamException {
/*  528 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  531 */       return XsTypeConverter.lexByte(cs);
/*      */     }
/*  533 */     catch (NumberFormatException e) {
/*      */       
/*  535 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public short getAttributeShortValue(String uri, String local) throws XMLStreamException {
/*  541 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  544 */       return XsTypeConverter.lexShort(cs);
/*      */     }
/*  546 */     catch (NumberFormatException e) {
/*      */       
/*  548 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getAttributeIntValue(String uri, String local) throws XMLStreamException {
/*  554 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  557 */       return XsTypeConverter.lexInt(cs);
/*      */     }
/*  559 */     catch (NumberFormatException e) {
/*      */       
/*  561 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public long getAttributeLongValue(String uri, String local) throws XMLStreamException {
/*  567 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  570 */       return XsTypeConverter.lexLong(cs);
/*      */     }
/*  572 */     catch (NumberFormatException e) {
/*      */       
/*  574 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public BigInteger getAttributeBigIntegerValue(String uri, String local) throws XMLStreamException {
/*  580 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  583 */       return XsTypeConverter.lexInteger(cs);
/*      */     }
/*  585 */     catch (NumberFormatException e) {
/*      */       
/*  587 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getAttributeBigDecimalValue(String uri, String local) throws XMLStreamException {
/*  593 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  596 */       return XsTypeConverter.lexDecimal(cs);
/*      */     }
/*  598 */     catch (NumberFormatException e) {
/*      */       
/*  600 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public float getAttributeFloatValue(String uri, String local) throws XMLStreamException {
/*  606 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  609 */       return XsTypeConverter.lexFloat(cs);
/*      */     }
/*  611 */     catch (NumberFormatException e) {
/*      */       
/*  613 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public double getAttributeDoubleValue(String uri, String local) throws XMLStreamException {
/*  619 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  622 */       return XsTypeConverter.lexDouble(cs);
/*      */     }
/*  624 */     catch (NumberFormatException e) {
/*      */       
/*  626 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getAttributeHexBinaryValue(String uri, String local) throws XMLStreamException {
/*  632 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*  633 */     String text = cs.toString();
/*  634 */     byte[] buf = HexBin.decode(text.getBytes());
/*  635 */     if (buf != null) {
/*  636 */       return new ByteArrayInputStream(buf);
/*      */     }
/*  638 */     throw new InvalidLexicalValueException("invalid hexBinary value", this._charSeq.getLocation());
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getAttributeBase64Value(String uri, String local) throws XMLStreamException {
/*  643 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*  644 */     String text = cs.toString();
/*  645 */     byte[] buf = Base64.decode(text.getBytes());
/*  646 */     if (buf != null) {
/*  647 */       return new ByteArrayInputStream(buf);
/*      */     }
/*  649 */     throw new InvalidLexicalValueException("invalid base64Binary value", this._charSeq.getLocation());
/*      */   }
/*      */ 
/*      */   
/*      */   public XmlCalendar getAttributeCalendarValue(String uri, String local) throws XMLStreamException {
/*  654 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  657 */       return (new GDateBuilder(cs)).getCalendar();
/*      */     }
/*  659 */     catch (IllegalArgumentException e) {
/*      */       
/*  661 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getAttributeDateValue(String uri, String local) throws XMLStreamException {
/*      */     try {
/*  669 */       CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*  670 */       return (new GDateBuilder(cs)).getDate();
/*      */     }
/*  672 */     catch (IllegalArgumentException e) {
/*      */       
/*  674 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public GDate getAttributeGDateValue(String uri, String local) throws XMLStreamException {
/*      */     try {
/*  682 */       CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*  683 */       return new GDate(cs);
/*      */     }
/*  685 */     catch (IllegalArgumentException e) {
/*      */       
/*  687 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public GDuration getAttributeGDurationValue(String uri, String local) throws XMLStreamException {
/*      */     try {
/*  695 */       return new GDuration(this._charSeq.reloadAtt(uri, local, 2));
/*      */     }
/*  697 */     catch (IllegalArgumentException e) {
/*      */       
/*  699 */       throw new InvalidLexicalValueException(e, this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public QName getAttributeQNameValue(String uri, String local) throws XMLStreamException {
/*  705 */     CharSequence cs = this._charSeq.reloadAtt(uri, local, 2);
/*      */     
/*      */     try {
/*  708 */       return XsTypeConverter.lexQName(cs, this._xmlStream.getNamespaceContext());
/*      */     }
/*  710 */     catch (InvalidLexicalValueException e) {
/*      */       
/*  712 */       throw new InvalidLexicalValueException(e.getMessage(), this._charSeq.getLocation());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDefaultValue(String defaultValue) throws XMLStreamException {
/*  718 */     this._defaultValue = defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static Class class$(String x0) {
/*      */     
/*  725 */     try { return Class.forName(x0); } catch (ClassNotFoundException x1) { throw (new NoClassDefFoundError()).initCause(x1); }
/*      */   
/*      */   }
/*      */   
/*      */   private static class CharSeqTrimWS implements CharSequence { static final int XMLWHITESPACE_PRESERVE = 1;
/*      */     static final int XMLWHITESPACE_TRIM = 2;
/*  731 */     private static int INITIAL_SIZE = 100;
/*  732 */     private char[] _buf = new char[INITIAL_SIZE]; private int _start;
/*  733 */     private int _length = 0;
/*  734 */     private int _nonWSStart = 0;
/*  735 */     private int _nonWSEnd = 0;
/*      */     
/*      */     private String _toStringValue;
/*      */     private XMLStreamReaderExtImpl _xmlSteam;
/*      */     private final ExtLocation _location;
/*      */     private boolean _hasText;
/*      */     static final boolean $assertionsDisabled;
/*      */     
/*      */     CharSeqTrimWS(XMLStreamReaderExtImpl xmlSteam) {
/*  744 */       this._xmlSteam = xmlSteam;
/*  745 */       this._location = new ExtLocation();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void reload(int style) throws XMLStreamException {
/*  751 */       this._toStringValue = null;
/*  752 */       this._location.reset();
/*  753 */       this._hasText = false;
/*      */       
/*  755 */       fillBuffer();
/*      */       
/*  757 */       if (style == 1) {
/*      */         
/*  759 */         this._nonWSStart = 0;
/*  760 */         this._nonWSEnd = this._length;
/*      */ 
/*      */         
/*  763 */         if (!this._hasText && this._xmlSteam._defaultValue != null)
/*      */         {
/*  765 */           this._length = 0;
/*  766 */           fillBufferFromString(this._xmlSteam._defaultValue);
/*      */         }
/*      */       
/*  769 */       } else if (style == 2) {
/*      */         
/*  771 */         for (this._nonWSStart = 0; this._nonWSStart < this._length && 
/*  772 */           XMLChar.isSpace(this._buf[this._nonWSStart]); this._nonWSStart++);
/*      */         
/*  774 */         for (this._nonWSEnd = this._length; this._nonWSEnd > this._nonWSStart && 
/*  775 */           XMLChar.isSpace(this._buf[this._nonWSEnd - 1]); this._nonWSEnd--);
/*      */ 
/*      */ 
/*      */         
/*  779 */         if (length() == 0 && this._xmlSteam._defaultValue != null) {
/*      */           
/*  781 */           this._length = 0;
/*  782 */           fillBufferFromString(this._xmlSteam._defaultValue);
/*      */ 
/*      */           
/*  785 */           for (this._nonWSStart = 0; this._nonWSStart < this._length && 
/*  786 */             XMLChar.isSpace(this._buf[this._nonWSStart]); this._nonWSStart++);
/*      */           
/*  788 */           for (this._nonWSEnd = this._length; this._nonWSEnd > this._nonWSStart && 
/*  789 */             XMLChar.isSpace(this._buf[this._nonWSEnd - 1]); this._nonWSEnd--);
/*      */         } 
/*      */       } 
/*      */       
/*  793 */       this._xmlSteam._defaultValue = null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void fillBuffer() throws XMLStreamException {
/*  799 */       this._length = 0;
/*      */       
/*  801 */       if (this._xmlSteam.getEventType() == 7)
/*  802 */         this._xmlSteam.next(); 
/*  803 */       if (this._xmlSteam.isStartElement()) {
/*  804 */         this._xmlSteam.next();
/*      */       }
/*  806 */       int depth = 0;
/*  807 */       String error = null;
/*  808 */       int eventType = this._xmlSteam.getEventType();
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*  813 */         switch (eventType) {
/*      */           
/*      */           case 4:
/*      */           case 6:
/*      */           case 12:
/*  818 */             this._location.set(this._xmlSteam.getLocation());
/*      */             
/*  820 */             if (depth == 0) {
/*  821 */               addTextToBuffer();
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/*  837 */             this._location.set(this._xmlSteam.getLocation());
/*      */             break;
/*      */ 
/*      */           
/*      */           case 2:
/*  842 */             this._location.set(this._xmlSteam.getLocation());
/*  843 */             depth--;
/*  844 */             if (depth < 0) {
/*      */               break;
/*      */             }
/*      */             break;
/*      */           case 9:
/*  849 */             this._location.set(this._xmlSteam.getLocation());
/*      */             
/*  851 */             addEntityToBuffer();
/*      */             break;
/*      */           
/*      */           case 1:
/*  855 */             depth++;
/*  856 */             error = "Unexpected element '" + this._xmlSteam.getName() + "' in text content.";
/*  857 */             this._location.set(this._xmlSteam.getLocation());
/*      */             break;
/*      */         } 
/*      */         
/*  861 */         eventType = this._xmlSteam.next();
/*      */       } 
/*  863 */       if (error != null) {
/*  864 */         throw new XMLStreamException(error);
/*      */       }
/*      */     }
/*      */     
/*      */     private void ensureBufferLength(int lengthToAdd) {
/*  869 */       if (this._length + lengthToAdd > this._buf.length) {
/*      */         
/*  871 */         char[] newBuf = new char[this._length + lengthToAdd];
/*  872 */         if (this._length > 0)
/*  873 */           System.arraycopy(this._buf, 0, newBuf, 0, this._length); 
/*  874 */         this._buf = newBuf;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void fillBufferFromString(CharSequence value) {
/*  880 */       int textLength = value.length();
/*  881 */       ensureBufferLength(textLength);
/*      */       
/*  883 */       for (int i = 0; i < textLength; i++)
/*      */       {
/*  885 */         this._buf[i] = value.charAt(i);
/*      */       }
/*  887 */       this._length = textLength;
/*      */     }
/*      */ 
/*      */     
/*      */     private void addTextToBuffer() {
/*  892 */       this._hasText = true;
/*  893 */       int textLength = this._xmlSteam.getTextLength();
/*  894 */       ensureBufferLength(textLength);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  917 */       System.arraycopy(this._xmlSteam.getTextCharacters(), this._xmlSteam.getTextStart(), this._buf, this._length, textLength);
/*  918 */       this._length += textLength;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void addEntityToBuffer() {
/*  924 */       String text = this._xmlSteam.getText();
/*      */       
/*  926 */       int textLength = text.length();
/*  927 */       ensureBufferLength(textLength);
/*      */       
/*  929 */       text.getChars(0, text.length(), this._buf, this._length);
/*  930 */       this._length += text.length();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     CharSequence reloadAtt(int index, int style) throws XMLStreamException {
/*  936 */       this._location.reset();
/*  937 */       this._location.set(this._xmlSteam.getLocation());
/*  938 */       String value = this._xmlSteam.getAttributeValue(index);
/*      */       
/*  940 */       if (value == null && this._xmlSteam._defaultValue != null) {
/*  941 */         value = this._xmlSteam._defaultValue;
/*      */       }
/*  943 */       this._xmlSteam._defaultValue = null;
/*      */       
/*  945 */       int length = value.length();
/*      */       
/*  947 */       if (style == 1)
/*      */       {
/*  949 */         return value;
/*      */       }
/*  951 */       if (style == 2) {
/*      */         int nonWSStart;
/*      */         
/*  954 */         for (nonWSStart = 0; nonWSStart < length && 
/*  955 */           XMLChar.isSpace(value.charAt(nonWSStart)); nonWSStart++);
/*      */         int nonWSEnd;
/*  957 */         for (nonWSEnd = length; nonWSEnd > nonWSStart && 
/*  958 */           XMLChar.isSpace(value.charAt(nonWSEnd - 1)); nonWSEnd--);
/*      */         
/*  960 */         if (nonWSStart == 0 && nonWSEnd == length) {
/*  961 */           return value;
/*      */         }
/*  963 */         return value.subSequence(nonWSStart, nonWSEnd);
/*      */       } 
/*      */       
/*  966 */       throw new IllegalStateException("unknown style");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     CharSequence reloadAtt(String uri, String local, int style) throws XMLStreamException {
/*  972 */       this._location.reset();
/*  973 */       this._location.set(this._xmlSteam.getLocation());
/*  974 */       String value = this._xmlSteam.getAttributeValue(uri, local);
/*      */       
/*  976 */       if (value == null && this._xmlSteam._defaultValue != null) {
/*  977 */         value = this._xmlSteam._defaultValue;
/*      */       }
/*  979 */       this._xmlSteam._defaultValue = null;
/*      */       
/*  981 */       int length = value.length();
/*      */       
/*  983 */       if (style == 1)
/*      */       {
/*  985 */         return value;
/*      */       }
/*  987 */       if (style == 2) {
/*      */         
/*  989 */         for (this._nonWSStart = 0; this._nonWSStart < length && 
/*  990 */           XMLChar.isSpace(value.charAt(this._nonWSStart)); this._nonWSStart++);
/*      */         
/*  992 */         for (this._nonWSEnd = length; this._nonWSEnd > this._nonWSStart && 
/*  993 */           XMLChar.isSpace(value.charAt(this._nonWSEnd - 1)); this._nonWSEnd--);
/*      */         
/*  995 */         if (this._nonWSStart == 0 && this._nonWSEnd == length) {
/*  996 */           return value;
/*      */         }
/*  998 */         return value.subSequence(this._nonWSStart, this._nonWSEnd);
/*      */       } 
/* 1000 */       throw new IllegalStateException("unknown style");
/*      */     }
/*      */ 
/*      */     
/*      */     Location getLocation() {
/* 1005 */       ExtLocation loc = new ExtLocation();
/* 1006 */       loc.set(this._location);
/* 1007 */       return loc;
/*      */     }
/*      */ 
/*      */     
/*      */     public int length() {
/* 1012 */       return this._nonWSEnd - this._nonWSStart;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public char charAt(int index) {
/* 1019 */       assert index < this._nonWSEnd - this._nonWSStart && -1 < index : "Index " + index + " must be >-1 and <" + (this._nonWSEnd - this._nonWSStart);
/*      */       
/* 1021 */       return this._buf[this._nonWSStart + index];
/*      */     }
/*      */ 
/*      */     
/*      */     public CharSequence subSequence(int start, int end) {
/* 1026 */       return new String(this._buf, this._nonWSStart + start, end - start);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1031 */       if (this._toStringValue != null) {
/* 1032 */         return this._toStringValue;
/*      */       }
/* 1034 */       this._toStringValue = new String(this._buf, this._nonWSStart, this._nonWSEnd - this._nonWSStart);
/* 1035 */       return this._toStringValue;
/*      */     }
/*      */ 
/*      */     
/*      */     private static class ExtLocation
/*      */       implements Location
/*      */     {
/*      */       private int _line;
/*      */       
/*      */       private int _col;
/*      */       
/*      */       private int _off;
/*      */       
/*      */       private String _pid;
/*      */       
/*      */       private String _sid;
/*      */       private boolean _isSet = false;
/*      */       
/*      */       public int getLineNumber() {
/* 1054 */         if (this._isSet) {
/* 1055 */           return this._line;
/*      */         }
/* 1057 */         throw new IllegalStateException();
/*      */       }
/*      */ 
/*      */       
/*      */       public int getColumnNumber() {
/* 1062 */         if (this._isSet) {
/* 1063 */           return this._col;
/*      */         }
/* 1065 */         throw new IllegalStateException();
/*      */       }
/*      */ 
/*      */       
/*      */       public int getCharacterOffset() {
/* 1070 */         if (this._isSet) {
/* 1071 */           return this._off;
/*      */         }
/* 1073 */         throw new IllegalStateException();
/*      */       }
/*      */ 
/*      */       
/*      */       public String getPublicId() {
/* 1078 */         if (this._isSet) {
/* 1079 */           return this._pid;
/*      */         }
/* 1081 */         throw new IllegalStateException();
/*      */       }
/*      */ 
/*      */       
/*      */       public String getSystemId() {
/* 1086 */         if (this._isSet) {
/* 1087 */           return this._sid;
/*      */         }
/* 1089 */         throw new IllegalStateException();
/*      */       }
/*      */ 
/*      */       
/*      */       void set(Location loc) {
/* 1094 */         if (this._isSet) {
/*      */           return;
/*      */         }
/* 1097 */         this._isSet = true;
/* 1098 */         this._line = loc.getLineNumber();
/* 1099 */         this._col = loc.getColumnNumber();
/* 1100 */         this._off = loc.getCharacterOffset();
/* 1101 */         this._pid = loc.getPublicId();
/* 1102 */         this._sid = loc.getSystemId();
/*      */       }
/*      */ 
/*      */       
/*      */       void reset() {
/* 1107 */         this._isSet = false;
/*      */       }
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getProperty(String s) throws IllegalArgumentException {
/* 1116 */     return this._xmlStream.getProperty(s);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int next() throws XMLStreamException {
/* 1122 */     return this._xmlStream.next();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void require(int i, String s, String s1) throws XMLStreamException {
/* 1128 */     this._xmlStream.require(i, s, s1);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getElementText() throws XMLStreamException {
/* 1133 */     return this._xmlStream.getElementText();
/*      */   }
/*      */ 
/*      */   
/*      */   public int nextTag() throws XMLStreamException {
/* 1138 */     return this._xmlStream.nextTag();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasNext() throws XMLStreamException {
/* 1143 */     return this._xmlStream.hasNext();
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws XMLStreamException {
/* 1148 */     this._xmlStream.close();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNamespaceURI(String s) {
/* 1153 */     return this._xmlStream.getNamespaceURI(s);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isStartElement() {
/* 1158 */     return this._xmlStream.isStartElement();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEndElement() {
/* 1163 */     return this._xmlStream.isEndElement();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCharacters() {
/* 1168 */     return this._xmlStream.isCharacters();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWhiteSpace() {
/* 1173 */     return this._xmlStream.isWhiteSpace();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeValue(String s, String s1) {
/* 1178 */     return this._xmlStream.getAttributeValue(s, s1);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getAttributeCount() {
/* 1183 */     return this._xmlStream.getAttributeCount();
/*      */   }
/*      */ 
/*      */   
/*      */   public QName getAttributeName(int i) {
/* 1188 */     return this._xmlStream.getAttributeName(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeNamespace(int i) {
/* 1193 */     return this._xmlStream.getAttributeNamespace(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeLocalName(int i) {
/* 1198 */     return this._xmlStream.getAttributeLocalName(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributePrefix(int i) {
/* 1203 */     return this._xmlStream.getAttributePrefix(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeType(int i) {
/* 1208 */     return this._xmlStream.getAttributeType(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttributeValue(int i) {
/* 1213 */     return this._xmlStream.getAttributeValue(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAttributeSpecified(int i) {
/* 1218 */     return this._xmlStream.isAttributeSpecified(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNamespaceCount() {
/* 1223 */     return this._xmlStream.getNamespaceCount();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNamespacePrefix(int i) {
/* 1228 */     return this._xmlStream.getNamespacePrefix(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNamespaceURI(int i) {
/* 1233 */     return this._xmlStream.getNamespaceURI(i);
/*      */   }
/*      */ 
/*      */   
/*      */   public NamespaceContext getNamespaceContext() {
/* 1238 */     return this._xmlStream.getNamespaceContext();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getEventType() {
/* 1243 */     return this._xmlStream.getEventType();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getText() {
/* 1248 */     return this._xmlStream.getText();
/*      */   }
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() {
/* 1253 */     return this._xmlStream.getTextCharacters();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextCharacters(int i, char[] chars, int i1, int i2) throws XMLStreamException {
/* 1259 */     return this._xmlStream.getTextCharacters(i, chars, i1, i2);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getTextStart() {
/* 1264 */     return this._xmlStream.getTextStart();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getTextLength() {
/* 1269 */     return this._xmlStream.getTextLength();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getEncoding() {
/* 1274 */     return this._xmlStream.getEncoding();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasText() {
/* 1279 */     return this._xmlStream.hasText();
/*      */   }
/*      */ 
/*      */   
/*      */   public Location getLocation() {
/* 1284 */     return this._xmlStream.getLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public QName getName() {
/* 1289 */     return this._xmlStream.getName();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLocalName() {
/* 1294 */     return this._xmlStream.getLocalName();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasName() {
/* 1299 */     return this._xmlStream.hasName();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNamespaceURI() {
/* 1304 */     return this._xmlStream.getNamespaceURI();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getPrefix() {
/* 1309 */     return this._xmlStream.getPrefix();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getVersion() {
/* 1314 */     return this._xmlStream.getVersion();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isStandalone() {
/* 1319 */     return this._xmlStream.isStandalone();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean standaloneSet() {
/* 1324 */     return this._xmlStream.standaloneSet();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCharacterEncodingScheme() {
/* 1329 */     return this._xmlStream.getCharacterEncodingScheme();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getPITarget() {
/* 1334 */     return this._xmlStream.getPITarget();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getPIData() {
/* 1339 */     return this._xmlStream.getPIData();
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\richParser\XMLStreamReaderExtImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */