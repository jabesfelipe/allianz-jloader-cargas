/*     */ package org.apache.xmlbeans.impl.config;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameSet
/*     */ {
/*  34 */   public static NameSet EMPTY = new NameSet(true, Collections.EMPTY_SET);
/*     */ 
/*     */ 
/*     */   
/*  38 */   public static NameSet EVERYTHING = new NameSet(false, Collections.EMPTY_SET);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _isFinite;
/*     */ 
/*     */   
/*     */   private Set _finiteSet;
/*     */ 
/*     */ 
/*     */   
/*     */   private NameSet(boolean isFinite, Set finiteSet) {
/*  50 */     this._isFinite = isFinite;
/*  51 */     this._finiteSet = finiteSet;
/*     */   }
/*     */ 
/*     */   
/*     */   static NameSet newInstance(boolean isFinite, Set finiteSet) {
/*  56 */     if (finiteSet.size() == 0) {
/*  57 */       if (isFinite) {
/*  58 */         return EMPTY;
/*     */       }
/*  60 */       return EVERYTHING;
/*     */     } 
/*     */     
/*  63 */     Set fs = new HashSet();
/*  64 */     fs.addAll(finiteSet);
/*  65 */     return new NameSet(isFinite, fs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Set intersectFiniteSets(Set a, Set b) {
/*  71 */     Set intersection = new HashSet();
/*     */     
/*  73 */     while (a.iterator().hasNext()) {
/*     */       
/*  75 */       String name = a.iterator().next();
/*  76 */       if (b.contains(name))
/*  77 */         intersection.add(name); 
/*     */     } 
/*  79 */     return intersection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameSet union(NameSet with) {
/*  87 */     if (this._isFinite) {
/*     */       
/*  89 */       if (with._isFinite) {
/*     */         
/*  91 */         Set union = new HashSet();
/*  92 */         union.addAll(this._finiteSet);
/*  93 */         union.addAll(with._finiteSet);
/*  94 */         return newInstance(true, union);
/*     */       } 
/*     */ 
/*     */       
/*  98 */       Set subst = new HashSet();
/*  99 */       subst.addAll(with._finiteSet);
/* 100 */       subst.removeAll(this._finiteSet);
/* 101 */       return newInstance(false, subst);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 106 */     if (with._isFinite) {
/*     */       
/* 108 */       Set subst = new HashSet();
/* 109 */       subst.addAll(this._finiteSet);
/* 110 */       subst.removeAll(with._finiteSet);
/* 111 */       return newInstance(false, subst);
/*     */     } 
/*     */ 
/*     */     
/* 115 */     return newInstance(false, intersectFiniteSets(this._finiteSet, with._finiteSet));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameSet intersect(NameSet with) {
/* 125 */     if (this._isFinite) {
/*     */       
/* 127 */       if (with._isFinite)
/*     */       {
/* 129 */         return newInstance(true, intersectFiniteSets(this._finiteSet, with._finiteSet));
/*     */       }
/*     */ 
/*     */       
/* 133 */       Set subst = new HashSet();
/* 134 */       subst.addAll(this._finiteSet);
/* 135 */       subst.removeAll(with._finiteSet);
/* 136 */       return newInstance(false, subst);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 141 */     if (with._isFinite) {
/*     */       
/* 143 */       Set subst = new HashSet();
/* 144 */       subst.addAll(with._finiteSet);
/* 145 */       subst.removeAll(this._finiteSet);
/* 146 */       return newInstance(true, subst);
/*     */     } 
/*     */ 
/*     */     
/* 150 */     Set union = new HashSet();
/* 151 */     union.addAll(this._finiteSet);
/* 152 */     union.addAll(with._finiteSet);
/* 153 */     return newInstance(false, union);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameSet substractFrom(NameSet from) {
/* 164 */     return from.substract(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameSet substract(NameSet what) {
/* 173 */     if (this._isFinite) {
/*     */       
/* 175 */       if (what._isFinite) {
/*     */ 
/*     */         
/* 178 */         Set set = new HashSet();
/* 179 */         set.addAll(this._finiteSet);
/* 180 */         set.removeAll(what._finiteSet);
/* 181 */         return newInstance(true, set);
/*     */       } 
/*     */ 
/*     */       
/* 185 */       return newInstance(true, intersectFiniteSets(this._finiteSet, what._finiteSet));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 190 */     if (what._isFinite) {
/*     */ 
/*     */       
/* 193 */       Set union = new HashSet();
/* 194 */       union.addAll(this._finiteSet);
/* 195 */       union.addAll(what._finiteSet);
/* 196 */       return newInstance(false, union);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 201 */     Set subst = new HashSet();
/* 202 */     subst.addAll(what._finiteSet);
/* 203 */     subst.removeAll(this._finiteSet);
/* 204 */     return newInstance(true, subst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameSet invert() {
/* 214 */     return newInstance(!this._isFinite, this._finiteSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String name) {
/* 219 */     if (this._isFinite) {
/* 220 */       return this._finiteSet.contains(name);
/*     */     }
/* 222 */     return !this._finiteSet.contains(name);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\config\NameSet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */