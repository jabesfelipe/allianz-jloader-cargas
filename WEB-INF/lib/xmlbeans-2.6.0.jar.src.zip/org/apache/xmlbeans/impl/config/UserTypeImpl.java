/*    */ package org.apache.xmlbeans.impl.config;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.xmlbeans.UserType;
/*    */ import org.apache.xmlbeans.impl.jam.JamClassLoader;
/*    */ import org.apache.xmlbeans.impl.xb.xmlconfig.Usertypeconfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserTypeImpl
/*    */   implements UserType
/*    */ {
/*    */   private QName _name;
/*    */   private String _javaName;
/*    */   private String _staticHandler;
/*    */   
/*    */   static UserTypeImpl newInstance(JamClassLoader loader, Usertypeconfig cfgXO) {
/* 18 */     UserTypeImpl result = new UserTypeImpl();
/*    */     
/* 20 */     result._name = cfgXO.getName();
/* 21 */     result._javaName = cfgXO.getJavaname();
/* 22 */     result._staticHandler = cfgXO.getStaticHandler();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 28 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getJavaName() {
/* 34 */     return this._javaName;
/*    */   }
/*    */ 
/*    */   
/*    */   public QName getName() {
/* 39 */     return this._name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStaticHandler() {
/* 44 */     return this._staticHandler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\config\UserTypeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */