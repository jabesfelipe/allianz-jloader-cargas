/*    */ package org.apache.xmlbeans.impl.inst2xsd;
/*    */ 
/*    */ import org.apache.xmlbeans.impl.inst2xsd.util.Element;
/*    */ import org.apache.xmlbeans.impl.inst2xsd.util.TypeSystemHolder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SalamiSliceStrategy
/*    */   extends RussianDollStrategy
/*    */   implements XsdGenStrategy
/*    */ {
/*    */   protected void checkIfElementReferenceIsNeeded(Element child, String parentNamespace, TypeSystemHolder typeSystemHolder, Inst2XsdOptions options) {
/* 32 */     Element referencedElem = new Element();
/* 33 */     referencedElem.setGlobal(true);
/* 34 */     referencedElem.setName(child.getName());
/* 35 */     referencedElem.setType(child.getType());
/*    */     
/* 37 */     if (child.isNillable()) {
/*    */       
/* 39 */       referencedElem.setNillable(true);
/* 40 */       child.setNillable(false);
/*    */     } 
/*    */     
/* 43 */     referencedElem = addGlobalElement(referencedElem, typeSystemHolder, options);
/*    */     
/* 45 */     child.setRef(referencedElem);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\inst2xsd\SalamiSliceStrategy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */