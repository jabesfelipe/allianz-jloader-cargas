/*    */ package org.apache.xmlbeans.impl.inst2xsd;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.xmlbeans.impl.inst2xsd.util.Element;
/*    */ import org.apache.xmlbeans.impl.inst2xsd.util.Type;
/*    */ import org.apache.xmlbeans.impl.inst2xsd.util.TypeSystemHolder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VenetianBlindStrategy
/*    */   extends RussianDollStrategy
/*    */   implements XsdGenStrategy
/*    */ {
/*    */   protected void checkIfReferenceToGlobalTypeIsNeeded(Element elem, TypeSystemHolder typeSystemHolder, Inst2XsdOptions options) {
/* 35 */     Type elemType = elem.getType();
/* 36 */     QName elemName = elem.getName();
/*    */     
/* 38 */     if (elemType.isGlobal()) {
/*    */       return;
/*    */     }
/*    */     
/* 42 */     if (elemType.isComplexType())
/*    */     {
/* 44 */       for (int i = 0;; i++) {
/*    */         
/* 46 */         elemType.setName(new QName(elemName.getNamespaceURI(), elemName.getLocalPart() + "Type" + ((i == 0) ? "" : ("" + i))));
/*    */         
/* 48 */         Type candidate = typeSystemHolder.getGlobalType(elemType.getName());
/* 49 */         if (candidate == null) {
/*    */           
/* 51 */           elemType.setGlobal(true);
/* 52 */           typeSystemHolder.addGlobalType(elemType);
/*    */           
/*    */           break;
/*    */         } 
/*    */         
/* 57 */         if (compatibleTypes(candidate, elemType)) {
/*    */           
/* 59 */           combineTypes(candidate, elemType, options);
/* 60 */           elem.setType(candidate);
/*    */           break;
/*    */         } 
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean compatibleTypes(Type elemType, Type candidate) {
/* 72 */     if (elemType == candidate) {
/* 73 */       return true;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 90 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\xmlbeans-2.6.0.jar!\org\apache\xmlbeans\impl\inst2xsd\VenetianBlindStrategy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */