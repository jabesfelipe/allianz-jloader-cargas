/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.IntegerDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Header
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -6982184526372058126L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBcoHdrArq;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServicoHdrArq;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoRegHdrArq;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private Integer tpoIncsEmp;
/*     */   @LongPositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private Long nroInscEmp;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 52)
/*     */   private String codConvenio;
/*     */   @IntegerPositionalField(initialPosition = 53, finalPosition = 57)
/*     */   private Integer dscAgencia;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 58)
/*     */   private String dscAgenciaDV;
/*     */   @LongPositionalField(initialPosition = 59, finalPosition = 70)
/*     */   private Long dscConta;
/*     */   @PositionalField(initialPosition = 71, finalPosition = 71)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 72, finalPosition = 72)
/*     */   private String dscAgCtaDV;
/*     */   @PositionalField(initialPosition = 73, finalPosition = 102)
/*     */   private String nmeEmp;
/*     */   @PositionalField(initialPosition = 103, finalPosition = 132)
/*     */   private String nmeBco;
/*     */   @PositionalField(initialPosition = 133, finalPosition = 142)
/*     */   private String dscUsoFbrn2;
/*     */   @IntegerPositionalField(initialPosition = 143, finalPosition = 143)
/*     */   private Integer nroRmssRtrn;
/*     */   @PositionalField(initialPosition = 144, finalPosition = 151, decorator = DateDecorator240.class)
/*     */   private Date dtaGeracaoArq;
/*     */   @PositionalField(initialPosition = 152, finalPosition = 157, decorator = IntegerDecorator.class)
/*     */   private Integer hraGeracaoArq;
/*     */   @IntegerPositionalField(initialPosition = 158, finalPosition = 163)
/*     */   private Integer nroNsa;
/*     */   @IntegerPositionalField(initialPosition = 164, finalPosition = 166)
/*     */   private Integer nroLytArq;
/*     */   @PositionalField(initialPosition = 167, finalPosition = 171, decorator = IntegerDecorator.class)
/*     */   private Integer codDensidade;
/*     */   @PositionalField(initialPosition = 172, finalPosition = 191)
/*     */   private String dscResercadoBco;
/*     */   @PositionalField(initialPosition = 192, finalPosition = 211)
/*     */   private String dscResercadoEmp;
/*     */   @PositionalField(initialPosition = 212, finalPosition = 240)
/*     */   private String dscUsoFbrn3;
/*     */   
/*     */   public String getCodBcoHdrArq() {
/*  74 */     return this.codBcoHdrArq;
/*     */   }
/*     */   public void setCodBcoHdrArq(String codBcoHdrArq) {
/*  77 */     this.codBcoHdrArq = codBcoHdrArq;
/*     */   }
/*     */   public Integer getLteServicoHdrArq() {
/*  80 */     return this.lteServicoHdrArq;
/*     */   }
/*     */   public void setLteServicoHdrArq(Integer lteServicoHdrArq) {
/*  83 */     this.lteServicoHdrArq = lteServicoHdrArq;
/*     */   }
/*     */   public Integer getTpoRegHdrArq() {
/*  86 */     return this.tpoRegHdrArq;
/*     */   }
/*     */   public void setTpoRegHdrArq(Integer tpoRegHdrArq) {
/*  89 */     this.tpoRegHdrArq = tpoRegHdrArq;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  92 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  95 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getTpoIncsEmp() {
/*  98 */     return this.tpoIncsEmp;
/*     */   }
/*     */   public void setTpoIncsEmp(Integer tpoIncsEmp) {
/* 101 */     this.tpoIncsEmp = tpoIncsEmp;
/*     */   }
/*     */   public Long getNroInscEmp() {
/* 104 */     return this.nroInscEmp;
/*     */   }
/*     */   public void setNroInscEmp(Long nroInscEmp) {
/* 107 */     this.nroInscEmp = nroInscEmp;
/*     */   }
/*     */   public String getCodConvenio() {
/* 110 */     return this.codConvenio;
/*     */   }
/*     */   public void setCodConvenio(String codConvenio) {
/* 113 */     this.codConvenio = codConvenio;
/*     */   }
/*     */   public Integer getDscAgencia() {
/* 116 */     return this.dscAgencia;
/*     */   }
/*     */   public void setDscAgencia(Integer dscAgencia) {
/* 119 */     this.dscAgencia = dscAgencia;
/*     */   }
/*     */   public String getDscAgenciaDV() {
/* 122 */     return this.dscAgenciaDV;
/*     */   }
/*     */   public void setDscAgenciaDV(String dscAgenciaDV) {
/* 125 */     this.dscAgenciaDV = dscAgenciaDV;
/*     */   }
/*     */   public Long getDscConta() {
/* 128 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(Long dscConta) {
/* 131 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 134 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 137 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgCtaDV() {
/* 140 */     return this.dscAgCtaDV;
/*     */   }
/*     */   public void setDscAgCtaDV(String dscAgCtaDV) {
/* 143 */     this.dscAgCtaDV = dscAgCtaDV;
/*     */   }
/*     */   public String getNmeEmp() {
/* 146 */     return this.nmeEmp;
/*     */   }
/*     */   public void setNmeEmp(String nmeEmp) {
/* 149 */     this.nmeEmp = nmeEmp;
/*     */   }
/*     */   public String getNmeBco() {
/* 152 */     return this.nmeBco;
/*     */   }
/*     */   public void setNmeBco(String nmeBco) {
/* 155 */     this.nmeBco = nmeBco;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 158 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 161 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public Integer getNroRmssRtrn() {
/* 164 */     return this.nroRmssRtrn;
/*     */   }
/*     */   public void setNroRmssRtrn(Integer nroRmssRtrn) {
/* 167 */     this.nroRmssRtrn = nroRmssRtrn;
/*     */   }
/*     */   public Date getDtaGeracaoArq() {
/* 170 */     return this.dtaGeracaoArq;
/*     */   }
/*     */   public void setDtaGeracaoArq(Date dtaGeracaoArq) {
/* 173 */     this.dtaGeracaoArq = dtaGeracaoArq;
/*     */   }
/*     */   public Integer getHraGeracaoArq() {
/* 176 */     return this.hraGeracaoArq;
/*     */   }
/*     */   public void setHraGeracaoArq(Integer hraGeracaoArq) {
/* 179 */     this.hraGeracaoArq = hraGeracaoArq;
/*     */   }
/*     */   public Integer getNroNsa() {
/* 182 */     return this.nroNsa;
/*     */   }
/*     */   public void setNroNsa(Integer nroNsa) {
/* 185 */     this.nroNsa = nroNsa;
/*     */   }
/*     */   public Integer getNroLytArq() {
/* 188 */     return this.nroLytArq;
/*     */   }
/*     */   public void setNroLytArq(Integer nroLytArq) {
/* 191 */     this.nroLytArq = nroLytArq;
/*     */   }
/*     */   public Integer getCodDensidade() {
/* 194 */     return this.codDensidade;
/*     */   }
/*     */   public void setCodDensidade(Integer codDensidade) {
/* 197 */     this.codDensidade = codDensidade;
/*     */   }
/*     */   public String getDscResercadoBco() {
/* 200 */     return this.dscResercadoBco;
/*     */   }
/*     */   public void setDscResercadoBco(String dscResercadoBco) {
/* 203 */     this.dscResercadoBco = dscResercadoBco;
/*     */   }
/*     */   public String getDscResercadoEmp() {
/* 206 */     return this.dscResercadoEmp;
/*     */   }
/*     */   public void setDscResercadoEmp(String dscResercadoEmp) {
/* 209 */     this.dscResercadoEmp = dscResercadoEmp;
/*     */   }
/*     */   public String getDscUsoFbrn3() {
/* 212 */     return this.dscUsoFbrn3;
/*     */   }
/*     */   public void setDscUsoFbrn3(String dscUsoFbrn3) {
/* 215 */     this.dscUsoFbrn3 = dscUsoFbrn3;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */