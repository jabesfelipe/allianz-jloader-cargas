/*     */ package br.com.accesstage.loader.util.dao;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*     */ import org.springframework.stereotype.Repository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Repository
/*     */ public class BaseDAO
/*     */   extends JdbcDaoSupport
/*     */ {
/*  29 */   private static Logger logger = Logger.getLogger(BaseDAO.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private Connection conn;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   public BaseDAO(DataSource dataSource) {
/*  40 */     setDataSource(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeResultSet(ResultSet rs) {
/*     */     try {
/*  50 */       if (rs != null) {
/*  51 */         rs.close();
/*     */       }
/*  53 */     } catch (SQLException e) {
/*  54 */       logger.debug("Erro ao fechar ResultSet.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeStatement(Statement state) {
/*     */     try {
/*  65 */       if (state != null) {
/*  66 */         state.close();
/*     */       }
/*  68 */     } catch (SQLException e) {
/*  69 */       logger.debug("Erro ao fechar Statement.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreparedStatement preparedStatement(String sql) throws SQLException {
/*  81 */     return getConnection().prepareStatement(sql);
/*     */   }
/*     */   
/*     */   public void mergeString(String query, Object... param) throws SQLException {
/*  85 */     JdbcTemplate template = getJdbcTemplate();
/*  86 */     template.update(query, param);
/*     */   }
/*     */   
/*     */   public Object findCodigo(String sql, Class<?> clazz, Long... param) {
/*  90 */     JdbcTemplate template = getJdbcTemplate();
/*  91 */     Object codigo = template.queryForObject(sql, (Object[])param, clazz);
/*  92 */     if (codigo != null) {
/*  93 */       return codigo;
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(String sql, Object... param) throws SQLException {
/* 106 */     getJdbcTemplate().update(sql, param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getSequenceID(String sequence) throws SQLException {
/* 118 */     StringBuffer strQuery = new StringBuffer();
/* 119 */     strQuery.append("SELECT ");
/* 120 */     strQuery.append(sequence);
/* 121 */     strQuery.append(".NEXTVAL FROM DUAL");
/* 122 */     Long result = (Long)getJdbcTemplate().queryForObject(strQuery.toString(), Long.class);
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public List<?> query(String query, Class<?> clazz) {
/* 127 */     List<?> list = getJdbcTemplate().queryForList(query, clazz);
/* 128 */     return list;
/*     */   }
/*     */   
/*     */   public int[] updateBatch(List<Object[]> batch, String sql) {
/* 132 */     int[] updateCounts = getJdbcTemplate().batchUpdate(sql, batch);
/* 133 */     return updateCounts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close(Connection conn) throws SQLException {
/* 143 */     if (conn != null) {
/* 144 */       conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 150 */     close(this.conn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closedPreparedStement(PreparedStatement stmt) throws SQLException {
/* 160 */     if (stmt != null) {
/* 161 */       stmt.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollBack() throws SQLException {
/* 171 */     if (this.conn != null && !this.conn.isClosed()) {
/* 172 */       this.conn.rollback();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void commit() throws SQLException {
/* 182 */     if (this.conn != null && !this.conn.isClosed())
/* 183 */       this.conn.commit(); 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\dao\BaseDAO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */