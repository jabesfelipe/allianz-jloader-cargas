/*     */ package br.com.accesstage.loader.util.commom;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Stack;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ public class PositionalXMLReader
/*     */ {
/*     */   static final String LINE_NUMBER_KEY_NAME = "lineNumber";
/*     */   
/*     */   public static Document readXML(File file) throws IOException, SAXException {
/*  27 */     FileInputStream fis = null;
/*     */     try {
/*  29 */       fis = new FileInputStream(file);
/*  30 */       return readXML(fis);
/*     */     } finally {
/*  32 */       if (fis != null) {
/*  33 */         fis.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document readXML(InputStream is) throws IOException, SAXException {
/*     */     final Document doc;
/*     */     SAXParser parser;
/*     */     try {
/*  44 */       SAXParserFactory factory = SAXParserFactory.newInstance();
/*  45 */       parser = factory.newSAXParser();
/*  46 */       DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
/*  47 */       DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
/*  48 */       doc = docBuilder.newDocument();
/*  49 */     } catch (ParserConfigurationException e) {
/*  50 */       throw new RuntimeException("Can't create SAX parser / DOM builder.", e);
/*     */     } 
/*     */     
/*  53 */     final Stack<Element> elementStack = new Stack<Element>();
/*  54 */     final StringBuilder textBuffer = new StringBuilder();
/*  55 */     DefaultHandler handler = new DefaultHandler()
/*     */       {
/*     */         private Locator locator;
/*     */         
/*     */         public void setDocumentLocator(Locator locator) {
/*  60 */           this.locator = locator;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
/*  66 */           addTextIfNeeded();
/*  67 */           Element el = doc.createElement(qName);
/*  68 */           for (int i = 0; i < attributes.getLength(); i++) {
/*  69 */             el.setAttribute(attributes.getQName(i), attributes.getValue(i));
/*     */           }
/*  71 */           el.setUserData("lineNumber", String.valueOf(this.locator.getLineNumber()), null);
/*  72 */           elementStack.push(el);
/*     */         }
/*     */ 
/*     */         
/*     */         public void endElement(String uri, String localName, String qName) {
/*  77 */           addTextIfNeeded();
/*  78 */           Element closedEl = elementStack.pop();
/*  79 */           if (elementStack.isEmpty()) {
/*  80 */             doc.appendChild(closedEl);
/*     */           } else {
/*  82 */             Element parentEl = elementStack.peek();
/*  83 */             parentEl.appendChild(closedEl);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void characters(char[] ch, int start, int length) throws SAXException {
/*  89 */           textBuffer.append(ch, start, length);
/*     */         }
/*     */ 
/*     */         
/*     */         private void addTextIfNeeded() {
/*  94 */           if (textBuffer.length() > 0) {
/*  95 */             Element el = elementStack.peek();
/*  96 */             Node textNode = doc.createTextNode(textBuffer.toString());
/*  97 */             el.appendChild(textNode);
/*  98 */             textBuffer.delete(0, textBuffer.length());
/*     */           } 
/*     */         }
/*     */       };
/* 102 */     parser.parse(is, handler);
/*     */     
/* 104 */     return doc;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\commom\PositionalXMLReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */