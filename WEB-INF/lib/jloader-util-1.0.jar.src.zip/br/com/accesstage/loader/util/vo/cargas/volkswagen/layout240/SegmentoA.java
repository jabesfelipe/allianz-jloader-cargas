/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoA
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -489927538271121376L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBanco;
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private String loteServico;
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private String tpoRegistro;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private String nroSeqLote;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSeguimentoDetalhe;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String tpoMovimento;
/*     */   @PositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private String codInstMov;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 20)
/*     */   private String codCamaraCent;
/*     */   @PositionalField(initialPosition = 21, finalPosition = 23)
/*     */   private String codBancoFavorecido;
/*     */   @PositionalField(initialPosition = 24, finalPosition = 28)
/*     */   private String agMantenedora;
/*     */   @PositionalField(initialPosition = 29, finalPosition = 29)
/*     */   private String digAg;
/*     */   @PositionalField(initialPosition = 30, finalPosition = 41)
/*     */   private String nroCcStr;
/*     */   @PositionalField(initialPosition = 42, finalPosition = 42)
/*     */   private String nroDigCc;
/*     */   @PositionalField(initialPosition = 43, finalPosition = 43)
/*     */   private String nroDigAgCc;
/*     */   @PositionalField(initialPosition = 44, finalPosition = 73)
/*     */   private String nmeFavorecido;
/*     */   @PositionalField(initialPosition = 74, finalPosition = 93)
/*     */   private String nroDocEmpresa;
/*     */   @PositionalField(initialPosition = 94, finalPosition = 101)
/*     */   private String dtaPgtoStr;
/*     */   @PositionalField(initialPosition = 102, finalPosition = 104)
/*     */   private String tpoMoeda;
/*     */   @PositionalField(initialPosition = 105, finalPosition = 119)
/*     */   private String qtdMoeda;
/*     */   @PositionalField(initialPosition = 120, finalPosition = 134)
/*     */   private String vlrPgto;
/*     */   @PositionalField(initialPosition = 135, finalPosition = 154)
/*     */   private String nroDocBanco;
/*     */   @PositionalField(initialPosition = 155, finalPosition = 162)
/*     */   private String dtaEfetivacaoStr;
/*     */   @PositionalField(initialPosition = 163, finalPosition = 177)
/*     */   private String vlrEfetivacao;
/*     */   @PositionalField(initialPosition = 178, finalPosition = 217)
/*     */   private String dscInfo;
/*     */   @PositionalField(initialPosition = 218, finalPosition = 219)
/*     */   private String codFinalidadeDoc;
/*     */   @PositionalField(initialPosition = 220, finalPosition = 224)
/*     */   private String codFinalidadeTed;
/*     */   @PositionalField(initialPosition = 225, finalPosition = 226)
/*     */   private String codFinalidadePgto;
/*     */   @PositionalField(initialPosition = 227, finalPosition = 229)
/*     */   private String dscCnab;
/*     */   @PositionalField(initialPosition = 230, finalPosition = 230)
/*     */   private String dscAviso;
/*     */   @PositionalField(initialPosition = 231, finalPosition = 240)
/*     */   private String dscOcorrencia;
/*     */   
/*     */   public String getCodBanco() {
/*  79 */     return this.codBanco;
/*     */   }
/*     */   public void setCodBanco(String codBanco) {
/*  82 */     this.codBanco = codBanco;
/*     */   }
/*     */   public String getLoteServico() {
/*  85 */     return this.loteServico;
/*     */   }
/*     */   public void setLoteServico(String loteServico) {
/*  88 */     this.loteServico = loteServico;
/*     */   }
/*     */   public String getTpoRegistro() {
/*  91 */     return this.tpoRegistro;
/*     */   }
/*     */   public void setTpoRegistro(String tpoRegistro) {
/*  94 */     this.tpoRegistro = tpoRegistro;
/*     */   }
/*     */   public String getNroSeqLote() {
/*  97 */     return this.nroSeqLote;
/*     */   }
/*     */   public void setNroSeqLote(String nroSeqLote) {
/* 100 */     this.nroSeqLote = nroSeqLote;
/*     */   }
/*     */   public String getCodSeguimentoDetalhe() {
/* 103 */     return this.codSeguimentoDetalhe;
/*     */   }
/*     */   public void setCodSeguimentoDetalhe(String codSeguimentoDetalhe) {
/* 106 */     this.codSeguimentoDetalhe = codSeguimentoDetalhe;
/*     */   }
/*     */   public String getTpoMovimento() {
/* 109 */     return this.tpoMovimento;
/*     */   }
/*     */   public void setTpoMovimento(String tpoMovimento) {
/* 112 */     this.tpoMovimento = tpoMovimento;
/*     */   }
/*     */   public String getCodInstMov() {
/* 115 */     return this.codInstMov;
/*     */   }
/*     */   public void setCodInstMov(String codInstMov) {
/* 118 */     this.codInstMov = codInstMov;
/*     */   }
/*     */   public String getCodCamaraCent() {
/* 121 */     return this.codCamaraCent;
/*     */   }
/*     */   public void setCodCamaraCent(String codCamaraCent) {
/* 124 */     this.codCamaraCent = codCamaraCent;
/*     */   }
/*     */   public String getCodBancoFavorecido() {
/* 127 */     return this.codBancoFavorecido;
/*     */   }
/*     */   public void setCodBancoFavorecido(String codBancoFavorecido) {
/* 130 */     this.codBancoFavorecido = codBancoFavorecido;
/*     */   }
/*     */   public String getAgMantenedora() {
/* 133 */     return this.agMantenedora;
/*     */   }
/*     */   public void setAgMantenedora(String agMantenedora) {
/* 136 */     this.agMantenedora = agMantenedora;
/*     */   }
/*     */   public String getDigAg() {
/* 139 */     return this.digAg;
/*     */   }
/*     */   public void setDigAg(String digAg) {
/* 142 */     this.digAg = digAg;
/*     */   }
/*     */   public String getNroCcStr() {
/* 145 */     return this.nroCcStr;
/*     */   }
/*     */   public void setNroCcStr(String nroCcStr) {
/* 148 */     this.nroCcStr = nroCcStr;
/*     */   }
/*     */   public String getNroDigCc() {
/* 151 */     return this.nroDigCc;
/*     */   }
/*     */   public void setNroDigCc(String nroDigCc) {
/* 154 */     this.nroDigCc = nroDigCc;
/*     */   }
/*     */   public String getNroDigAgCc() {
/* 157 */     return this.nroDigAgCc;
/*     */   }
/*     */   public void setNroDigAgCc(String nroDigAgCc) {
/* 160 */     this.nroDigAgCc = nroDigAgCc;
/*     */   }
/*     */   public String getNmeFavorecido() {
/* 163 */     return this.nmeFavorecido;
/*     */   }
/*     */   public void setNmeFavorecido(String nmeFavorecido) {
/* 166 */     this.nmeFavorecido = nmeFavorecido;
/*     */   }
/*     */   public String getNroDocEmpresa() {
/* 169 */     return this.nroDocEmpresa;
/*     */   }
/*     */   public void setNroDocEmpresa(String nroDocEmpresa) {
/* 172 */     this.nroDocEmpresa = nroDocEmpresa;
/*     */   }
/*     */   public String getDtaPgtoStr() {
/* 175 */     return this.dtaPgtoStr;
/*     */   }
/*     */   public void setDtaPgtoStr(String dtaPgtoStr) {
/* 178 */     this.dtaPgtoStr = dtaPgtoStr;
/*     */   }
/*     */   public String getTpoMoeda() {
/* 181 */     return this.tpoMoeda;
/*     */   }
/*     */   public void setTpoMoeda(String tpoMoeda) {
/* 184 */     this.tpoMoeda = tpoMoeda;
/*     */   }
/*     */   public String getQtdMoeda() {
/* 187 */     return this.qtdMoeda;
/*     */   }
/*     */   public void setQtdMoeda(String qtdMoeda) {
/* 190 */     this.qtdMoeda = qtdMoeda;
/*     */   }
/*     */   public String getVlrPgto() {
/* 193 */     return this.vlrPgto;
/*     */   }
/*     */   public void setVlrPgto(String vlrPgto) {
/* 196 */     this.vlrPgto = vlrPgto;
/*     */   }
/*     */   public String getNroDocBanco() {
/* 199 */     return this.nroDocBanco;
/*     */   }
/*     */   public void setNroDocBanco(String nroDocBanco) {
/* 202 */     this.nroDocBanco = nroDocBanco;
/*     */   }
/*     */   public String getDtaEfetivacaoStr() {
/* 205 */     return this.dtaEfetivacaoStr;
/*     */   }
/*     */   public void setDtaEfetivacaoStr(String dtaEfetivacaoStr) {
/* 208 */     this.dtaEfetivacaoStr = dtaEfetivacaoStr;
/*     */   }
/*     */   public String getVlrEfetivacao() {
/* 211 */     return this.vlrEfetivacao;
/*     */   }
/*     */   public void setVlrEfetivacao(String vlrEfetivacao) {
/* 214 */     this.vlrEfetivacao = vlrEfetivacao;
/*     */   }
/*     */   public String getDscInfo() {
/* 217 */     return this.dscInfo;
/*     */   }
/*     */   public void setDscInfo(String dscInfo) {
/* 220 */     this.dscInfo = dscInfo;
/*     */   }
/*     */   public String getCodFinalidadeDoc() {
/* 223 */     return this.codFinalidadeDoc;
/*     */   }
/*     */   public void setCodFinalidadeDoc(String codFinalidadeDoc) {
/* 226 */     this.codFinalidadeDoc = codFinalidadeDoc;
/*     */   }
/*     */   public String getCodFinalidadeTed() {
/* 229 */     return this.codFinalidadeTed;
/*     */   }
/*     */   public void setCodFinalidadeTed(String codFinalidadeTed) {
/* 232 */     this.codFinalidadeTed = codFinalidadeTed;
/*     */   }
/*     */   public String getCodFinalidadePgto() {
/* 235 */     return this.codFinalidadePgto;
/*     */   }
/*     */   public void setCodFinalidadePgto(String codFinalidadePgto) {
/* 238 */     this.codFinalidadePgto = codFinalidadePgto;
/*     */   }
/*     */   public String getDscCnab() {
/* 241 */     return this.dscCnab;
/*     */   }
/*     */   public void setDscCnab(String dscCnab) {
/* 244 */     this.dscCnab = dscCnab;
/*     */   }
/*     */   public String getDscAviso() {
/* 247 */     return this.dscAviso;
/*     */   }
/*     */   public void setDscAviso(String dscAviso) {
/* 250 */     this.dscAviso = dscAviso;
/*     */   }
/*     */   public String getDscOcorrencia() {
/* 253 */     return this.dscOcorrencia;
/*     */   }
/*     */   public void setDscOcorrencia(String dscOcorrencia) {
/* 256 */     this.dscOcorrencia = dscOcorrencia;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\SegmentoA.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */