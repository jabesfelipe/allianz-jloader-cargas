package br.com.accesstage.loader.util.commom.ffpojo;

import com.github.ffpojo.exception.RecordParserException;

public interface RecordParser {
  <T> T parseFromText(Class<T> paramClass, String paramString) throws RecordParserException;
  
  <T> String parseToText(T paramT) throws RecordParserException;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\commom\ffpojo\RecordParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */