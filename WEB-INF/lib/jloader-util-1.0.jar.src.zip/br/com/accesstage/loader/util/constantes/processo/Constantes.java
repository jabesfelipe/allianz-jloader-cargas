package br.com.accesstage.loader.util.constantes.processo;

public class Constantes {
  public static final String JNDI_DATASOURCE_CARGA = "jdbc/ASCargasSchedulerDS-nonXA";
  
  public static final String JNDI_ROADCARD = "jdbc/ASRoadCard";
  
  public static final String SEQ_COD_CONTROLE_PROC_ERROR = "SEQ_COD_CONTROLE_PROC_ERROR";
  
  public static final String UPDATE_CONTROLE_PROCESSAMENTO_FIM_ERRO = "UPDATE CONTROLE_PROCESSAMENTO SET QTD_REGISTROS_PROCESSADOS = ?, COD_STATUS_PROCESSAMENTO = ?,  DTH_FIM = SYSDATE,DSC_OBSERVACAO = ? WHERE COD_STATUS_PROCESSAMENTO = 'PROCESSANDO' AND COD_CONTROLE_PROC = ? AND COD_ARQUIVO = ?";
  
  public static final String UPDATE_CONTROLE_PROCESSAMENTO_FIM_ERRO_2 = "UPDATE CONTROLE_PROCESSAMENTO SET QTD_REGISTROS_PROCESSADOS = ?, COD_STATUS_PROCESSAMENTO = ?,  DTH_FIM = SYSDATE,DSC_OBSERVACAO = ? WHERE COD_STATUS_PROCESSAMENTO = 'PROCESSANDO' AND COD_CONTROLE_PROC = ? AND COD_ARQUIVO = ?";
  
  public static final String UPDATE_CONTROLE_PROCESSAMENTO_INICIO = "UPDATE CONTROLE_PROCESSAMENTO SET DTH_INICIO = SYSDATE WHERE COD_STATUS_PROCESSAMENTO = 'PROCESSANDO' AND COD_CONTROLE_PROC = ?";
  
  public static final String UPDATE_CONTROLE_PROCESSAMENTO_FIM = "UPDATE CONTROLE_PROCESSAMENTO SET QTD_REGISTROS_PROCESSADOS = ?, COD_STATUS_PROCESSAMENTO = ?,  DTH_FIM = SYSDATE WHERE COD_STATUS_PROCESSAMENTO = 'PROCESSANDO' AND COD_CONTROLE_PROC = ?";
  
  public static final String UPDATE_CONTROLE_PROCESSAMENTO_FIM_NEW = "UPDATE CONTROLE_PROCESSAMENTO SET QTD_REGISTROS_PROCESSADOS = ?, COD_STATUS_PROCESSAMENTO = ?,  DTH_FIM = SYSDATE, DSC_OBSERVACAO = ? WHERE COD_STATUS_PROCESSAMENTO = 'PROCESSANDO' AND COD_CONTROLE_PROC = ? AND COD_ARQUIVO = ?";
  
  public static final String INSERT_CONTROLE_PROCESS_ERROR = "INSERT INTO CONTROLE_PROCESSAMENTO_ERRO (COD_CONTROLE_PROC_ERROR, COD_CONTROLE_PROC, COD_ARQUIVO, NRO_LINHA_ARQ, DSC_MSG_ERRO) VALUES (?, ?, ?, ?, ?)";
  
  public static final String SELECT_COD_FORNECEDOR = "SELECT F.COD_FORNECEDOR FROM EMPRESA E JOIN FORNECEDOR F ON F.COD_EMP_FORN = E.COD_EMPRESA WHERE E.NRO_INSCRICAO = ?";
  
  public static final String SELECT_COD_ANCORA = "SELECT COD_ANCORA FROM ANCORA WHERE COM_EMP_ANCORA IN (SELECT COD_EMPRESA FROM EMPRESA WHERE NRO_INSCRICAO = ?)";
  
  public static final String STA_PROCESSA_OK_CONTROLE = "OK";
  
  public static final String STA_PROCESSA_ERRO_CONTROLE = "ERRO";
  
  public static final String STA_PROCESSA_ERRO = "E";
  
  public static final String STA_PROCESSA_OK = "S";
  
  public static final String DSC_OBSERVACAO = "Alguns registros não foram processados. Ocorrência por ter sido por erro de sistema ou regra de negócio, favor verificar a tabela CONTROLE_PROCESSAMENTO_ERRO para maiores informações.";
  
  public static final String COD_RETORNO_NAO_ECONTRADO = "Código de retorno não encontrado";
  
  public static final String COD_RETORNO_NAO_ENCONTADO_BANCO = "Código de retorno não encontrado na base de dados da Roadcard (RCD_COD_OCORRENCIA).";
  
  public static final String SEQ_RCD_TRANSACAO_CONFIRMACAO = "SEQ_COD_TRANSACAO_CONFIR";
  
  public static final String TIPO_OPERACAO_DEBITO = "2";
  
  public static final String TIPO_OPERACAO_CREDITO = "1";
  
  public static final String SELECT_FB240_DTLH_A = "SELECT f.NRO_DOC_EMP AS NSU_PARCEIRO , TO_CHAR(h.DTA_GERACAO_ar,  'DD/MM/YYYY') AS DTA_ARQUIVO_RETORNO , TO_CHAR(TO_DATE(f.dta_pgto,  'DDMMYYYY'), 'DD/MM/YYYY') AS DTA_AUTORIZACAO , h.COD_BANCO_HDR_ARQ AS NRO_BANCO , f.cod_arquivo   AS COD_ARQUIVO , f.NRO_LINHA_ARQ AS NRO_LINHA_ARQ , f.DSC_OCORRENCIA AS DSC_OCORRENCIA FROM FB240_DTLH_A f, fb240_hdr_trllr_arq h WHERE 1 = 1 AND f.cod_arquivo = h.cod_arquivo AND f.STA_PROCESSAMENTO = 'N' AND f.cod_arquivo = ?";
  
  public static final String SELECT_FB150_DTHL_F = "SELECT      f.USO_EMP AS NSU_PARCEIRO    , TO_CHAR(h.DTA_GERACAO,  'DD/MM/YYYY') AS DTA_ARQUIVO_RETORNO    , TO_CHAR(f.dta_venc_deb, 'DD/MM/YYYY') AS DTA_AUTORIZACAO    , f.cod_ret       AS COD_RETORNO    , h.cod_banco     AS NRO_BANCO    , f.cod_arquivo   AS COD_ARQUIVO    , f.NRO_LINHA_ARQ AS NRO_LINHA_ARQ  FROM FB150_DTHL_F f      , FB150_HDR   h   WHERE 1 = 1     AND f.cod_arquivo = h.cod_arquivo     AND f.STA_PROCESSAMENTO = 'N'    AND f.cod_arquivo = ? ";
  
  public static final String SELECT_ROADCARD_RET_DTLH_A = "select * from ROADCARD_RET_DTLH_A where COD_ARQUIVO = ?";
  
  public static final String SELECT_ROADCARD_RET_DTLH_B = "select * from ROADCARD_RET_DTLH_B where COD_ARQUIVO = ?";
  
  public static final String SELECT_ROADCARD_RET_DTLH_C = "select * from ROADCARD_RET_DTLH_C where COD_ARQUIVO = ?";
  
  public static final String SELECT_ROADCARD500_RET_DTLH = "SELECT  rd.dsc_seu_numero AS NSU_PARCEIRO, r.hra_gravacao_arquivo_hdr HR_ARQUIVO_RETORNO,  TO_CHAR(TO_DATE(r.dta_gravacao_arquivo_hdr, 'YYYY/MM/DD'), 'DD/MM/YYYY') DTA_ARQUIVO_RETORNO,  TO_CHAR(rd.DTA_EFETIVACAO_PGTO, 'DD/MM/YYYY') DTA_AUTORIZACAO,  rd.DSC_INF_RETORNO1 COD_RETORNO,  rd.COD_ARQUIVO AS COD_ARQUIVO,  rd.NRO_LINHA_ARQ AS NRO_LINHA_ARQ  FROM ROADCARD500_RET_HDR_TRLLR r,ROADCARD500_RET_DTLH rd WHERE  rd.COD_ARQUIVO = r.COD_ARQUIVO AND rd.STA_PROCESSAMENTO = 'N' AND rd.COD_ARQUIVO = ?";
  
  public static final String SELECT_ARQUIVO_CARGA = "select * from ARQUIVO_CARGA where COD_ARQUIVO = ?";
  
  public static final String SELECT_COD_OCORRENCIA = "select * from RCD_COD_OCORRENCIA where COD_OCORRENCIA = ? and TPO_OPERACAO = ? AND NRO_BNC_RESP_TRANSACAO = ?";
  
  public static final String INSERT_ROADCARD_RCD_TRANSACAO_CONFIRMACAO = "INSERT INTO RCD_TRANSACAO_CONFIRMACAO(COD_TRANSACAO_CONFIRMACAO, COD_AUTORIZACAO, COD_RETORNO, DTA_ARQUIVO_RETORNO, DTA_AUTORIZACAO, DSC_IDENT_ARQ_RET, TIPO_OPERACAO, DSC_RETORNO, STA_CALLBACK, NSU_PARCEIRO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  
  public static final String INSERT_ROADCARD_RCD_MSG_RET_PROCESSAMENTO = "INSERT INTO RCD_MSG_RET_PROCESSAMENTO(COD_TRANSACAO_CONFIRMACAO, COD_OCORRENCIA, DSC_OCORRENCIA) VALUES (?, ?, ?)";
  
  public static final String SELECT_NRO_NSU_CRED_TRANSACAO = "SELECT NRO_NSU FROM rcd_cred_transacao WHERE NSU_PARCEIRO = ?";
  
  public static final String SELECT_NRO_NSU_DEB_TRANSACAO = "SELECT NRO_NSU FROM rcd_deb_transacao WHERE NSU_PARCEIRO = ?";
  
  public static final String SELECT_COUNT_NRO_SEQUENCIA_CONTROLE_PROC = "SELECT MAX(TO_NUMBER(nro_seq)) AS COUNT FROM rcd_controle_proc WHERE TO_DATE(dta_retorno, 'dd/MM/yy') = TO_DATE(?, 'dd/MM/yy')";
  
  public static final String INSERT_RCD_CONTROLE_PROC = "INSERT INTO rcd_controle_proc (COD_TRANSACAO_CONFIRMACAO, COD_ARQUIVO, DTA_RETORNO, NRO_SEQ) VALUES(?, ?, ?, ?)";
  
  public static final String UPDATE_FB150_DTHL_F_STA_PROCESSAMENTO = "UPDATE FB150_DTHL_F SET sta_processamento = ? WHERE cod_arquivo = ? AND nro_linha_arq = ?";
  
  public static final String UPDATE_FB240_DTLH_A_STA_PROCESSAMENTO = "UPDATE FB240_DTLH_A SET sta_processamento = ? WHERE cod_arquivo = ? AND nro_linha_arq = ?";
  
  public static final String UPDATE_500_RET_DTLH_STA_PROCESSAMENTO = "UPDATE ROADCARD500_RET_DTLH SET sta_processamento = ? WHERE cod_arquivo = ? AND nro_linha_arq = ?";
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\constantes\processo\Constantes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */