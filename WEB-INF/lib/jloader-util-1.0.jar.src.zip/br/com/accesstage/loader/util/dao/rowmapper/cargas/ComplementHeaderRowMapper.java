/*    */ package br.com.accesstage.loader.util.dao.rowmapper.cargas;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.allianz.debito.complementar.Header;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class ComplementHeaderRowMapper
/*    */   implements RowMapper<Header>
/*    */ {
/*    */   public Header mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 13 */     Header header = new Header();
/* 14 */     header.setCodArquivo(rs.getInt("COD_ARQUIVO"));
/* 15 */     header.setId(rs.getInt("COD_COMPL_HEADER"));
/* 16 */     header.setNroUnico(rs.getInt("NRO_UNICO"));
/* 17 */     header.setLinhaProcessada(rs.getInt("NRO_LINHA_ARQ"));
/* 18 */     header.setEmpid(rs.getInt("EMPID"));
/* 19 */     header.setCodRegistro(rs.getString("TPREGISTRO"));
/* 20 */     header.setEmpresaAllianz(rs.getString("EMPRESAALLIANZ"));
/* 21 */     header.setDataEnvio(rs.getString("DTENVIO"));
/* 22 */     header.setHoraEnvio(rs.getString("HRENVIO"));
/* 23 */     header.setNsa(rs.getString("NSA"));
/* 24 */     return header;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\dao\rowmapper\cargas\ComplementHeaderRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */