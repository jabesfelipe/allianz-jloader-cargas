/*     */ package br.com.accesstage.loader.util.commom;
/*     */ 
/*     */ import br.com.accesstage.loader.util.constantes.carga.Format;
/*     */ import br.com.accesstage.loader.util.exception.LayoutException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PciWs
/*     */ {
/*  17 */   private static Properties properties = new Properties();
/*  18 */   private static long lastModifiedDate = -1L;
/*     */   
/*  20 */   private static Logger logger = Logger.getLogger(PciWs.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PCI_TYPE_RECORD_MASK = "mascarar";
/*     */ 
/*     */   
/*     */   private static final String PCI_TYPE_RECORD_CRYPT = "criptografado";
/*     */ 
/*     */   
/*     */   private static final String PCI_TYPE_RECORD_PROP = "pci.creditcard.typerecord";
/*     */ 
/*     */   
/*     */   private static final String PCI_CARACTER_MASK = "*";
/*     */ 
/*     */   
/*     */   private static final int PCI_LENGTH_CARD = 20;
/*     */ 
/*     */   
/*     */   private static final String ASCARGAS_CONFIG = "/data/ascargas/config/config.properties";
/*     */ 
/*     */ 
/*     */   
/*     */   public static String tratar(String dados) throws LayoutException, IOException {
/*     */     String nroCartaoTratado;
/*  45 */     if (dados == null || "".equals(dados = dados.trim()))
/*  46 */       return dados; 
/*  47 */     if (dados.length() > 20) {
/*  48 */       throw new LayoutException("Tamanho do número do cartão não deve ultrapassar 20");
/*     */     }
/*     */ 
/*     */     
/*  52 */     String typeRecord = properties.getProperty("pci.creditcard.typerecord");
/*  53 */     if (typeRecord == null || "".equals(typeRecord.trim()) || "mascarar".equalsIgnoreCase(typeRecord)) {
/*  54 */       nroCartaoTratado = mascarar(dados);
/*     */     } else {
/*  56 */       nroCartaoTratado = criptografar(dados);
/*     */     } 
/*     */     
/*  59 */     return nroCartaoTratado;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String mascarar(String dados) throws LayoutException, IOException {
/*  72 */     if (dados.indexOf("*") >= 0) {
/*  73 */       return dados;
/*     */     }
/*     */ 
/*     */     
/*  77 */     String nroCartao = "";
/*     */     try {
/*  79 */       nroCartao = Format.removerZerosAEsquerda(dados);
/*  80 */     } catch (StringIndexOutOfBoundsException e) {
/*  81 */       logger.warn(e.getMessage(), e);
/*  82 */       nroCartao = dados;
/*     */     } 
/*     */ 
/*     */     
/*  86 */     if (nroCartao.length() < 11) {
/*  87 */       throw new LayoutException("Tamanho do número do cartão não deve ser menor que 11");
/*     */     }
/*     */ 
/*     */     
/*  91 */     String mascarado = nroCartao.substring(0, 6);
/*  92 */     mascarado = mascarado + Format.repeteString("*", nroCartao.length() - 10);
/*  93 */     mascarado = mascarado + nroCartao.substring(mascarado.length());
/*     */     
/*  95 */     return mascarado;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String criptografar(String dados) throws LayoutException, IOException {
/* 107 */     String encNroCartao = null;
/*     */ 
/*     */ 
/*     */     
/* 111 */     return encNroCartao;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getUrl() throws IOException {
/* 139 */     return getProperties().getProperty("url");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTypeNumberCard() throws IOException {
/* 148 */     return getProperties().getProperty("pci.creditcard.typerecord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties getProperties() throws IOException {
/* 157 */     File configFile = new File("/data/ascargas/config/config.properties");
/*     */     
/* 159 */     if (!configFile.exists()) {
/* 160 */       logger.error("Arquivo: " + configFile.getAbsolutePath() + "não existe!!");
/* 161 */     } else if (configFile.lastModified() > lastModifiedDate) {
/* 162 */       properties.clear();
/* 163 */       properties.load(new FileInputStream(configFile));
/* 164 */       lastModifiedDate = configFile.lastModified();
/* 165 */       logger.info("Path do properties: " + configFile);
/*     */     } 
/* 167 */     return properties;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\commom\PciWs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */