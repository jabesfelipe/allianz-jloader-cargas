/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout150;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.DateDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.DoubleDecorator;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "G")})
/*     */ public class DetalheG
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -869318727412504885L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private String codRegistro;
/*     */   @PositionalField(initialPosition = 2, finalPosition = 21)
/*     */   private String identClienteEmpresa;
/*     */   @PositionalField(initialPosition = 22, finalPosition = 29, decorator = DateDecorator.class)
/*     */   private Date dtaPagamento;
/*     */   @PositionalField(initialPosition = 30, finalPosition = 37, decorator = DateDecorator.class)
/*     */   private Date dtaCredito;
/*     */   @PositionalField(initialPosition = 38, finalPosition = 58)
/*     */   private String infoCodigoBarra;
/*     */   @PositionalField(initialPosition = 59, finalPosition = 60, decorator = DoubleDecorator.class)
/*     */   private Double valorRecebido;
/*     */   @PositionalField(initialPosition = 61, finalPosition = 66, decorator = DoubleDecorator.class)
/*     */   private Double valorTarifa;
/*     */   @PositionalField(initialPosition = 67, finalPosition = 74)
/*     */   private String nroSeqRegistro;
/*     */   @PositionalField(initialPosition = 75, finalPosition = 82)
/*     */   private String codAgArrecadadora;
/*     */   @PositionalField(initialPosition = 83, finalPosition = 83)
/*     */   private String formaArrecadacao;
/*     */   @PositionalField(initialPosition = 84, finalPosition = 106)
/*     */   private String nroAutenticacao;
/*     */   @PositionalField(initialPosition = 107, finalPosition = 107)
/*     */   private String formaPagamento;
/*     */   @PositionalField(initialPosition = 108, finalPosition = 116)
/*     */   private String usoFuturo;
/*     */   
/*     */   public String getCodRegistro() {
/*  49 */     return this.codRegistro;
/*     */   }
/*     */   public void setCodRegistro(String codRegistro) {
/*  52 */     this.codRegistro = codRegistro;
/*     */   }
/*     */   public String getIdentClienteEmpresa() {
/*  55 */     return this.identClienteEmpresa;
/*     */   }
/*     */   public void setIdentClienteEmpresa(String identClienteEmpresa) {
/*  58 */     this.identClienteEmpresa = identClienteEmpresa;
/*     */   }
/*     */   public Date getDtaPagamento() {
/*  61 */     return this.dtaPagamento;
/*     */   }
/*     */   public void setDtaPagamento(Date dtaPagamento) {
/*  64 */     this.dtaPagamento = dtaPagamento;
/*     */   }
/*     */   public Date getDtaCredito() {
/*  67 */     return this.dtaCredito;
/*     */   }
/*     */   public void setDtaCredito(Date dtaCredito) {
/*  70 */     this.dtaCredito = dtaCredito;
/*     */   }
/*     */   public String getInfoCodigoBarra() {
/*  73 */     return this.infoCodigoBarra;
/*     */   }
/*     */   public void setInfoCodigoBarra(String infoCodigoBarra) {
/*  76 */     this.infoCodigoBarra = infoCodigoBarra;
/*     */   }
/*     */   public Double getValorRecebido() {
/*  79 */     return this.valorRecebido;
/*     */   }
/*     */   public void setValorRecebido(Double valorRecebido) {
/*  82 */     this.valorRecebido = valorRecebido;
/*     */   }
/*     */   public Double getValorTarifa() {
/*  85 */     return this.valorTarifa;
/*     */   }
/*     */   public void setValorTarifa(Double valorTarifa) {
/*  88 */     this.valorTarifa = valorTarifa;
/*     */   }
/*     */   public String getNroSeqRegistro() {
/*  91 */     return this.nroSeqRegistro;
/*     */   }
/*     */   public void setNroSeqRegistro(String nroSeqRegistro) {
/*  94 */     this.nroSeqRegistro = nroSeqRegistro;
/*     */   }
/*     */   public String getCodAgArrecadadora() {
/*  97 */     return this.codAgArrecadadora;
/*     */   }
/*     */   public void setCodAgArrecadadora(String codAgArrecadadora) {
/* 100 */     this.codAgArrecadadora = codAgArrecadadora;
/*     */   }
/*     */   public String getFormaArrecadacao() {
/* 103 */     return this.formaArrecadacao;
/*     */   }
/*     */   public void setFormaArrecadacao(String formaArrecadacao) {
/* 106 */     this.formaArrecadacao = formaArrecadacao;
/*     */   }
/*     */   public String getNroAutenticacao() {
/* 109 */     return this.nroAutenticacao;
/*     */   }
/*     */   public void setNroAutenticacao(String nroAutenticacao) {
/* 112 */     this.nroAutenticacao = nroAutenticacao;
/*     */   }
/*     */   public String getFormaPagamento() {
/* 115 */     return this.formaPagamento;
/*     */   }
/*     */   public void setFormaPagamento(String formaPagamento) {
/* 118 */     this.formaPagamento = formaPagamento;
/*     */   }
/*     */   public String getUsoFuturo() {
/* 121 */     return this.usoFuturo;
/*     */   }
/*     */   public void setUsoFuturo(String usoFuturo) {
/* 124 */     this.usoFuturo = usoFuturo;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout150\DetalheG.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */