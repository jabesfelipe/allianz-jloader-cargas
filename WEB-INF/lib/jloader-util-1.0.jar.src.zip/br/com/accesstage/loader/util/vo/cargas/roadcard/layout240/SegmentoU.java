/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoU
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 5852846835830154519L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeqLte;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegRegDtlh;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Integer codMovRtrn;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 32, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrJurosMulta;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 47, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrDscConc;
/*     */   @PositionalField(initialPosition = 48, finalPosition = 62, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrAbatConc;
/*     */   @PositionalField(initialPosition = 63, finalPosition = 77, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrIof;
/*     */   @PositionalField(initialPosition = 78, finalPosition = 92, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrPgtSacado;
/*     */   @PositionalField(initialPosition = 93, finalPosition = 107, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrLiqCred;
/*     */   @PositionalField(initialPosition = 108, finalPosition = 122, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrOutrasDesp;
/*     */   @PositionalField(initialPosition = 123, finalPosition = 137, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrOutrasCred;
/*     */   @PositionalField(initialPosition = 138, finalPosition = 145, decorator = DateDecorator240.class)
/*  52 */   private Date dtaOcorrencia1 = null;
/*     */   @PositionalField(initialPosition = 146, finalPosition = 153, decorator = DateDecorator240.class)
/*     */   private Date dtaEfetCred;
/*     */   @PositionalField(initialPosition = 154, finalPosition = 157)
/*     */   private String codOcorrencia;
/*     */   @PositionalField(initialPosition = 158, finalPosition = 165, decorator = DateDecorator240.class)
/*  58 */   private Date dtaOcorrencia2 = null;
/*     */   
/*     */   @PositionalField(initialPosition = 166, finalPosition = 180, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrOcorrencia;
/*     */   @PositionalField(initialPosition = 181, finalPosition = 210)
/*     */   private String dscOCorrencia;
/*     */   @PositionalField(initialPosition = 211, finalPosition = 213)
/*     */   private String codBcoComp;
/*     */   @PositionalField(initialPosition = 214, finalPosition = 233)
/*     */   private Long nroBcoNosso;
/*     */   @PositionalField(initialPosition = 234, finalPosition = 240)
/*     */   private String dscUsoFbrn2;
/*     */   
/*     */   public String getCodBco() {
/*  72 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  75 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  78 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  81 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  84 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  87 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeqLte() {
/*  90 */     return this.nroSeqLte;
/*     */   }
/*     */   public void setNroSeqLte(Integer nroSeqLte) {
/*  93 */     this.nroSeqLte = nroSeqLte;
/*     */   }
/*     */   public String getCodSegRegDtlh() {
/*  96 */     return this.codSegRegDtlh;
/*     */   }
/*     */   public void setCodSegRegDtlh(String codSegRegDtlh) {
/*  99 */     this.codSegRegDtlh = codSegRegDtlh;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 102 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 105 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMovRtrn() {
/* 108 */     return this.codMovRtrn;
/*     */   }
/*     */   public void setCodMovRtrn(Integer codMovRtrn) {
/* 111 */     this.codMovRtrn = codMovRtrn;
/*     */   }
/*     */   public BigDecimal getVlrJurosMulta() {
/* 114 */     return this.vlrJurosMulta;
/*     */   }
/*     */   public void setVlrJurosMulta(BigDecimal vlrJurosMulta) {
/* 117 */     this.vlrJurosMulta = vlrJurosMulta;
/*     */   }
/*     */   public BigDecimal getVlrDscConc() {
/* 120 */     return this.vlrDscConc;
/*     */   }
/*     */   public void setVlrDscConc(BigDecimal vlrDscConc) {
/* 123 */     this.vlrDscConc = vlrDscConc;
/*     */   }
/*     */   public BigDecimal getVlrAbatConc() {
/* 126 */     return this.vlrAbatConc;
/*     */   }
/*     */   public void setVlrAbatConc(BigDecimal vlrAbatConc) {
/* 129 */     this.vlrAbatConc = vlrAbatConc;
/*     */   }
/*     */   public BigDecimal getVlrIof() {
/* 132 */     return this.vlrIof;
/*     */   }
/*     */   public void setVlrIof(BigDecimal vlrIof) {
/* 135 */     this.vlrIof = vlrIof;
/*     */   }
/*     */   public BigDecimal getVlrPgtSacado() {
/* 138 */     return this.vlrPgtSacado;
/*     */   }
/*     */   public void setVlrPgtSacado(BigDecimal vlrPgtSacado) {
/* 141 */     this.vlrPgtSacado = vlrPgtSacado;
/*     */   }
/*     */   public BigDecimal getVlrLiqCred() {
/* 144 */     return this.vlrLiqCred;
/*     */   }
/*     */   public void setVlrLiqCred(BigDecimal vlrLiqCred) {
/* 147 */     this.vlrLiqCred = vlrLiqCred;
/*     */   }
/*     */   public BigDecimal getVlrOutrasDesp() {
/* 150 */     return this.vlrOutrasDesp;
/*     */   }
/*     */   public void setVlrOutrasDesp(BigDecimal vlrOutrasDesp) {
/* 153 */     this.vlrOutrasDesp = vlrOutrasDesp;
/*     */   }
/*     */   public BigDecimal getVlrOutrasCred() {
/* 156 */     return this.vlrOutrasCred;
/*     */   }
/*     */   public void setVlrOutrasCred(BigDecimal vlrOutrasCred) {
/* 159 */     this.vlrOutrasCred = vlrOutrasCred;
/*     */   }
/*     */   public Date getDtaOcorrencia1() {
/* 162 */     return this.dtaOcorrencia1;
/*     */   }
/*     */   public void setDtaOcorrencia1(Date dtaOcorrencia1) {
/* 165 */     this.dtaOcorrencia1 = dtaOcorrencia1;
/*     */   }
/*     */   public Date getDtaEfetCred() {
/* 168 */     return this.dtaEfetCred;
/*     */   }
/*     */   public void setDtaEfetCred(Date dtaEfetCred) {
/* 171 */     this.dtaEfetCred = dtaEfetCred;
/*     */   }
/*     */   public String getCodOcorrencia() {
/* 174 */     return this.codOcorrencia;
/*     */   }
/*     */   public void setCodOcorrencia(String codOcorrencia) {
/* 177 */     this.codOcorrencia = codOcorrencia;
/*     */   }
/*     */   public Date getDtaOcorrencia2() {
/* 180 */     return this.dtaOcorrencia2;
/*     */   }
/*     */   public void setDtaOcorrencia2(Date dtaOcorrencia2) {
/* 183 */     this.dtaOcorrencia2 = dtaOcorrencia2;
/*     */   }
/*     */   public BigDecimal getVlrOcorrencia() {
/* 186 */     return this.vlrOcorrencia;
/*     */   }
/*     */   public void setVlrOcorrencia(BigDecimal vlrOcorrencia) {
/* 189 */     this.vlrOcorrencia = vlrOcorrencia;
/*     */   }
/*     */   public String getDscOCorrencia() {
/* 192 */     return this.dscOCorrencia;
/*     */   }
/*     */   public void setDscOCorrencia(String dscOCorrencia) {
/* 195 */     this.dscOCorrencia = dscOCorrencia;
/*     */   }
/*     */   public String getCodBcoComp() {
/* 198 */     return this.codBcoComp;
/*     */   }
/*     */   public void setCodBcoComp(String codBcoComp) {
/* 201 */     this.codBcoComp = codBcoComp;
/*     */   }
/*     */   public Long getNroBcoNosso() {
/* 204 */     return this.nroBcoNosso;
/*     */   }
/*     */   public void setNroBcoNosso(Long nroBcoNosso) {
/* 207 */     this.nroBcoNosso = nroBcoNosso;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 210 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 213 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoU.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */