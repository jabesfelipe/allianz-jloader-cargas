/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractVO
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 884526636877877257L;
/*    */   protected int id;
/*    */   protected int nroUnico;
/*    */   protected int codArquivo;
/*    */   protected int linhaProcessada;
/*    */   protected int empid;
/*    */   protected int headerLote;
/*    */   protected int traillerLote;
/*    */   
/*    */   public int getId() {
/* 21 */     return this.id;
/*    */   }
/*    */   public void setId(int id) {
/* 24 */     this.id = id;
/*    */   }
/*    */   public int getNroUnico() {
/* 27 */     return this.nroUnico;
/*    */   }
/*    */   public void setNroUnico(int nroUnico) {
/* 30 */     this.nroUnico = nroUnico;
/*    */   }
/*    */   public int getCodArquivo() {
/* 33 */     return this.codArquivo;
/*    */   }
/*    */   public void setCodArquivo(int codArquivo) {
/* 36 */     this.codArquivo = codArquivo;
/*    */   }
/*    */   public int getLinhaProcessada() {
/* 39 */     return this.linhaProcessada;
/*    */   }
/*    */   public void setLinhaProcessada(int linhaProcessada) {
/* 42 */     this.linhaProcessada = linhaProcessada;
/*    */   }
/*    */   public int getEmpid() {
/* 45 */     return this.empid;
/*    */   }
/*    */   public void setEmpid(int empid) {
/* 48 */     this.empid = empid;
/*    */   }
/*    */   public int getHeaderLote() {
/* 51 */     return this.headerLote;
/*    */   }
/*    */   public void setHeaderLote(int headerLote) {
/* 54 */     this.headerLote = headerLote;
/*    */   }
/*    */   public int getTraillerLote() {
/* 57 */     return this.traillerLote;
/*    */   }
/*    */   public void setTraillerLote(int traillerLote) {
/* 60 */     this.traillerLote = traillerLote;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\AbstractVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */