/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class HdrExtL033
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 2832560273842767421L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 9)
/*     */   private String codTpoOp;
/*     */   @IntegerPositionalField(initialPosition = 10, finalPosition = 11)
/*     */   private Integer codTpoServ;
/*     */   @IntegerPositionalField(initialPosition = 12, finalPosition = 13)
/*     */   private Integer dscFormaLan;
/*     */   @IntegerPositionalField(initialPosition = 14, finalPosition = 16)
/*     */   private Integer nroLytArq;
/*     */   @PositionalField(initialPosition = 17, finalPosition = 17)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private Integer tpoInscEmp;
/*     */   @LongPositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private Long nroInscEmp;
/*     */   @PositionalField(initialPosition = 32, finalPosition = 51)
/*     */   private String codConvenio;
/*     */   @IntegerPositionalField(initialPosition = 52, finalPosition = 56)
/*     */   private Integer dscAgencia;
/*     */   @PositionalField(initialPosition = 57, finalPosition = 57)
/*     */   private String dscAgenciaDV;
/*     */   @LongPositionalField(initialPosition = 58, finalPosition = 69)
/*     */   private Long dscConta;
/*     */   @PositionalField(initialPosition = 70, finalPosition = 70)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 71, finalPosition = 71)
/*     */   private String dscAgCtaDV;
/*     */   @PositionalField(initialPosition = 72, finalPosition = 101)
/*     */   private String nmeEmp;
/*     */   @PositionalField(initialPosition = 102, finalPosition = 141)
/*     */   private String dscUsoFbrn2;
/*     */   @PositionalField(initialPosition = 142, finalPosition = 149, decorator = DateDecorator240.class)
/*     */   private Date dtaSldInicial;
/*     */   @PositionalField(initialPosition = 150, finalPosition = 167, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrSldIncial;
/*     */   @PositionalField(initialPosition = 168, finalPosition = 168)
/*     */   private String dscSituacaoSldInicial;
/*     */   @PositionalField(initialPosition = 169, finalPosition = 169)
/*     */   private String dscStatusSldInicial;
/*     */   @PositionalField(initialPosition = 170, finalPosition = 172)
/*     */   private String codMoedaStr;
/*     */   @IntegerPositionalField(initialPosition = 173, finalPosition = 177)
/*     */   private Integer nroSeqHdr;
/*     */   @PositionalField(initialPosition = 178, finalPosition = 240)
/*     */   private String dscUsoFbrn3;
/*     */   
/*     */   public String getCodBco() {
/*  76 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  79 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  82 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  85 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  88 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  91 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public String getCodTpoOp() {
/*  94 */     return this.codTpoOp;
/*     */   }
/*     */   public void setCodTpoOp(String codTpoOp) {
/*  97 */     this.codTpoOp = codTpoOp;
/*     */   }
/*     */   public Integer getCodTpoServ() {
/* 100 */     return this.codTpoServ;
/*     */   }
/*     */   public void setCodTpoServ(Integer codTpoServ) {
/* 103 */     this.codTpoServ = codTpoServ;
/*     */   }
/*     */   public Integer getDscFormaLan() {
/* 106 */     return this.dscFormaLan;
/*     */   }
/*     */   public void setDscFormaLan(Integer dscFormaLan) {
/* 109 */     this.dscFormaLan = dscFormaLan;
/*     */   }
/*     */   public Integer getNroLytArq() {
/* 112 */     return this.nroLytArq;
/*     */   }
/*     */   public void setNroLytArq(Integer nroLytArq) {
/* 115 */     this.nroLytArq = nroLytArq;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 118 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 121 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getTpoInscEmp() {
/* 124 */     return this.tpoInscEmp;
/*     */   }
/*     */   public void setTpoInscEmp(Integer tpoInscEmp) {
/* 127 */     this.tpoInscEmp = tpoInscEmp;
/*     */   }
/*     */   public Long getNroInscEmp() {
/* 130 */     return this.nroInscEmp;
/*     */   }
/*     */   public void setNroInscEmp(Long nroInscEmp) {
/* 133 */     this.nroInscEmp = nroInscEmp;
/*     */   }
/*     */   public String getCodConvenio() {
/* 136 */     return this.codConvenio;
/*     */   }
/*     */   public void setCodConvenio(String codConvenio) {
/* 139 */     this.codConvenio = codConvenio;
/*     */   }
/*     */   public Integer getDscAgencia() {
/* 142 */     return this.dscAgencia;
/*     */   }
/*     */   public void setDscAgencia(Integer dscAgencia) {
/* 145 */     this.dscAgencia = dscAgencia;
/*     */   }
/*     */   public String getDscAgenciaDV() {
/* 148 */     return this.dscAgenciaDV;
/*     */   }
/*     */   public void setDscAgenciaDV(String dscAgenciaDV) {
/* 151 */     this.dscAgenciaDV = dscAgenciaDV;
/*     */   }
/*     */   public Long getDscConta() {
/* 154 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(Long dscConta) {
/* 157 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 160 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 163 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgCtaDV() {
/* 166 */     return this.dscAgCtaDV;
/*     */   }
/*     */   public void setDscAgCtaDV(String dscAgCtaDV) {
/* 169 */     this.dscAgCtaDV = dscAgCtaDV;
/*     */   }
/*     */   public String getNmeEmp() {
/* 172 */     return this.nmeEmp;
/*     */   }
/*     */   public void setNmeEmp(String nmeEmp) {
/* 175 */     this.nmeEmp = nmeEmp;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 178 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 181 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public Date getDtaSldInicial() {
/* 184 */     return this.dtaSldInicial;
/*     */   }
/*     */   public void setDtaSldInicial(Date dtaSldInicial) {
/* 187 */     this.dtaSldInicial = dtaSldInicial;
/*     */   }
/*     */   public BigDecimal getVlrSldIncial() {
/* 190 */     return this.vlrSldIncial;
/*     */   }
/*     */   public void setVlrSldIncial(BigDecimal vlrSldIncial) {
/* 193 */     this.vlrSldIncial = vlrSldIncial;
/*     */   }
/*     */   public String getDscSituacaoSldInicial() {
/* 196 */     return this.dscSituacaoSldInicial;
/*     */   }
/*     */   public void setDscSituacaoSldInicial(String dscSituacaoSldInicial) {
/* 199 */     this.dscSituacaoSldInicial = dscSituacaoSldInicial;
/*     */   }
/*     */   public String getDscStatusSldInicial() {
/* 202 */     return this.dscStatusSldInicial;
/*     */   }
/*     */   public void setDscStatusSldInicial(String dscStatusSldInicial) {
/* 205 */     this.dscStatusSldInicial = dscStatusSldInicial;
/*     */   }
/*     */   public String getCodMoedaStr() {
/* 208 */     return this.codMoedaStr;
/*     */   }
/*     */   public void setCodMoedaStr(String codMoedaStr) {
/* 211 */     this.codMoedaStr = codMoedaStr;
/*     */   }
/*     */   public Integer getNroSeqHdr() {
/* 214 */     return this.nroSeqHdr;
/*     */   }
/*     */   public void setNroSeqHdr(Integer nroSeqHdr) {
/* 217 */     this.nroSeqHdr = nroSeqHdr;
/*     */   }
/*     */   public String getDscUsoFbrn3() {
/* 220 */     return this.dscUsoFbrn3;
/*     */   }
/*     */   public void setDscUsoFbrn3(String dscUsoFbrn3) {
/* 223 */     this.dscUsoFbrn3 = dscUsoFbrn3;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\HdrExtL033.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */