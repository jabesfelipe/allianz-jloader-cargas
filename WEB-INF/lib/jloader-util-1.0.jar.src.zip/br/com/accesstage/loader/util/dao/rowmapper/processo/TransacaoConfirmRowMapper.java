/*    */ package br.com.accesstage.loader.util.dao.rowmapper.processo;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.processo.TransacaoConfirmVO;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransacaoConfirmRowMapper
/*    */   implements RowMapper<TransacaoConfirmVO>
/*    */ {
/*    */   public TransacaoConfirmVO mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 14 */     TransacaoConfirmVO transConfirm = new TransacaoConfirmVO();
/* 15 */     transConfirm.setNroNsu(rs.getString("NSU_PARCEIRO"));
/* 16 */     transConfirm.setDataArquivoRetorno(rs.getString("DTA_ARQUIVO_RETORNO"));
/* 17 */     transConfirm.setDataAutorizacao(rs.getString("DTA_AUTORIZACAO"));
/*    */     
/* 19 */     transConfirm.setDscOcorrencia(rs.getString("COD_RETORNO"));
/* 20 */     transConfirm.setCodArquivo(rs.getString("COD_ARQUIVO"));
/* 21 */     transConfirm.setNroBanco(rs.getString("NRO_BANCO"));
/* 22 */     transConfirm.setNroLinhaArq(Long.valueOf(rs.getLong("NRO_LINHA_ARQ")));
/* 23 */     transConfirm.setStaCallback(0);
/* 24 */     transConfirm.setTpoOperacao("2");
/* 25 */     return transConfirm;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\dao\rowmapper\processo\TransacaoConfirmRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */