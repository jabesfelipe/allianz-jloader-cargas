/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "A")})
/*     */ public class Header
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private String codRegistro;
/*     */   @PositionalField(initialPosition = 2, finalPosition = 2)
/*     */   private String codRemessa;
/*     */   @PositionalField(initialPosition = 3, finalPosition = 22)
/*     */   private String codConvenio;
/*     */   @PositionalField(initialPosition = 23, finalPosition = 42)
/*     */   private String nmeEmpresa;
/*     */   @PositionalField(initialPosition = 43, finalPosition = 45)
/*     */   private String nroBanco;
/*     */   @PositionalField(initialPosition = 46, finalPosition = 65)
/*     */   private String nmeBanco;
/*     */   @PositionalField(initialPosition = 66, finalPosition = 73)
/*     */   private String dtaGeracao;
/*     */   @PositionalField(initialPosition = 74, finalPosition = 79)
/*     */   private String nroNSA;
/*     */   @PositionalField(initialPosition = 80, finalPosition = 81)
/*     */   private String nroVersaoLayout;
/*     */   @PositionalField(initialPosition = 82, finalPosition = 98)
/*     */   private String identServico;
/*     */   @PositionalField(initialPosition = 99, finalPosition = 150)
/*     */   private String usoFuturo;
/*     */   
/*     */   public String getCodRegistro() {
/*  41 */     return this.codRegistro;
/*     */   }
/*     */   public void setCodRegistro(String codRegistro) {
/*  44 */     this.codRegistro = codRegistro;
/*     */   }
/*     */   public String getCodRemessa() {
/*  47 */     return this.codRemessa;
/*     */   }
/*     */   public void setCodRemessa(String codRemessa) {
/*  50 */     this.codRemessa = codRemessa;
/*     */   }
/*     */   public String getCodConvenio() {
/*  53 */     return this.codConvenio;
/*     */   }
/*     */   public void setCodConvenio(String codConvenio) {
/*  56 */     this.codConvenio = codConvenio;
/*     */   }
/*     */   public String getNmeEmpresa() {
/*  59 */     return this.nmeEmpresa;
/*     */   }
/*     */   public void setNmeEmpresa(String nmeEmpresa) {
/*  62 */     this.nmeEmpresa = nmeEmpresa;
/*     */   }
/*     */   public String getNroBanco() {
/*  65 */     return this.nroBanco;
/*     */   }
/*     */   public void setNroBanco(String nroBanco) {
/*  68 */     this.nroBanco = nroBanco;
/*     */   }
/*     */   public String getNmeBanco() {
/*  71 */     return this.nmeBanco;
/*     */   }
/*     */   public void setNmeBanco(String nmeBanco) {
/*  74 */     this.nmeBanco = nmeBanco;
/*     */   }
/*     */   public String getDtaGeracao() {
/*  77 */     return this.dtaGeracao;
/*     */   }
/*     */   public void setDtaGeracao(String dtaGeracao) {
/*  80 */     this.dtaGeracao = dtaGeracao;
/*     */   }
/*     */   public String getNroNSA() {
/*  83 */     return this.nroNSA;
/*     */   }
/*     */   public void setNroNSA(String nroNSA) {
/*  86 */     this.nroNSA = nroNSA;
/*     */   }
/*     */   public String getNroVersaoLayout() {
/*  89 */     return this.nroVersaoLayout;
/*     */   }
/*     */   public void setNroVersaoLayout(String nroVersaoLayout) {
/*  92 */     this.nroVersaoLayout = nroVersaoLayout;
/*     */   }
/*     */   public String getIdentServico() {
/*  95 */     return this.identServico;
/*     */   }
/*     */   public void setIdentServico(String identServico) {
/*  98 */     this.identServico = identServico;
/*     */   }
/*     */   public String getUsoFuturo() {
/* 101 */     return this.usoFuturo;
/*     */   }
/*     */   public void setUsoFuturo(String usoFuturo) {
/* 104 */     this.usoFuturo = usoFuturo;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */