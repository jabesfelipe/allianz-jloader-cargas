/*    */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord
/*    */ public class Trailler
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*    */   private String codBcoTrllrArq;
/*    */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*    */   private String nroLteServico;
/*    */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*    */   private String tpoRegTrllrArq;
/*    */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*    */   private String dscUsoFbrn1;
/*    */   @PositionalField(initialPosition = 18, finalPosition = 23)
/*    */   private String qtdLteArq;
/*    */   @PositionalField(initialPosition = 24, finalPosition = 29)
/*    */   private String qtdRegArq;
/*    */   @PositionalField(initialPosition = 30, finalPosition = 35)
/*    */   private String qtdContaConcArq;
/*    */   @PositionalField(initialPosition = 36, finalPosition = 240)
/*    */   private String dscUsoFbrn2;
/*    */   
/*    */   public String getCodBcoTrllrArq() {
/* 34 */     return this.codBcoTrllrArq;
/*    */   }
/*    */   public void setCodBcoTrllrArq(String codBcoTrllrArq) {
/* 37 */     this.codBcoTrllrArq = codBcoTrllrArq;
/*    */   }
/*    */   public String getNroLteServico() {
/* 40 */     return this.nroLteServico;
/*    */   }
/*    */   public void setNroLteServico(String nroLteServico) {
/* 43 */     this.nroLteServico = nroLteServico;
/*    */   }
/*    */   public String getTpoRegTrllrArq() {
/* 46 */     return this.tpoRegTrllrArq;
/*    */   }
/*    */   public void setTpoRegTrllrArq(String tpoRegTrllrArq) {
/* 49 */     this.tpoRegTrllrArq = tpoRegTrllrArq;
/*    */   }
/*    */   public String getDscUsoFbrn1() {
/* 52 */     return this.dscUsoFbrn1;
/*    */   }
/*    */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 55 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*    */   }
/*    */   public String getQtdLteArq() {
/* 58 */     return this.qtdLteArq;
/*    */   }
/*    */   public void setQtdLteArq(String qtdLteArq) {
/* 61 */     this.qtdLteArq = qtdLteArq;
/*    */   }
/*    */   public String getQtdRegArq() {
/* 64 */     return this.qtdRegArq;
/*    */   }
/*    */   public void setQtdRegArq(String qtdRegArq) {
/* 67 */     this.qtdRegArq = qtdRegArq;
/*    */   }
/*    */   public String getQtdContaConcArq() {
/* 70 */     return this.qtdContaConcArq;
/*    */   }
/*    */   public void setQtdContaConcArq(String qtdContaConcArq) {
/* 73 */     this.qtdContaConcArq = qtdContaConcArq;
/*    */   }
/*    */   public String getDscUsoFbrn2() {
/* 76 */     return this.dscUsoFbrn2;
/*    */   }
/*    */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 79 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\Trailler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */