/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "L")})
/*    */ public class DetalheL
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 9)
/*    */   private String dataFaturamentoContas;
/*    */   @PositionalField(initialPosition = 10, finalPosition = 17)
/*    */   private String dataVencimentoContas;
/*    */   @PositionalField(initialPosition = 18, finalPosition = 25)
/*    */   private String dataRemessaArquivoBanco;
/*    */   @PositionalField(initialPosition = 26, finalPosition = 33)
/*    */   private String dataRemessaContasFiscais;
/*    */   @PositionalField(initialPosition = 34, finalPosition = 150)
/*    */   private String usoFuturo;
/*    */   
/*    */   public String getCodRegistro() {
/* 31 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 34 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getDataFaturamentoContas() {
/* 37 */     return this.dataFaturamentoContas;
/*    */   }
/*    */   public void setDataFaturamentoContas(String dataFaturamentoContas) {
/* 40 */     this.dataFaturamentoContas = dataFaturamentoContas;
/*    */   }
/*    */   public String getDataVencimentoContas() {
/* 43 */     return this.dataVencimentoContas;
/*    */   }
/*    */   public void setDataVencimentoContas(String dataVencimentoContas) {
/* 46 */     this.dataVencimentoContas = dataVencimentoContas;
/*    */   }
/*    */   public String getDataRemessaArquivoBanco() {
/* 49 */     return this.dataRemessaArquivoBanco;
/*    */   }
/*    */   public void setDataRemessaArquivoBanco(String dataRemessaArquivoBanco) {
/* 52 */     this.dataRemessaArquivoBanco = dataRemessaArquivoBanco;
/*    */   }
/*    */   public String getDataRemessaContasFiscais() {
/* 55 */     return this.dataRemessaContasFiscais;
/*    */   }
/*    */   public void setDataRemessaContasFiscais(String dataRemessaContasFiscais) {
/* 58 */     this.dataRemessaContasFiscais = dataRemessaContasFiscais;
/*    */   }
/*    */   public String getUsoFuturo() {
/* 61 */     return this.usoFuturo;
/*    */   }
/*    */   public void setUsoFuturo(String usoFuturo) {
/* 64 */     this.usoFuturo = usoFuturo;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\DetalheL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */