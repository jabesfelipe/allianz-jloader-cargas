/*    */ package br.com.accesstage.loader.util.constantes.processo;
/*    */ 
/*    */ public enum StatusCarga
/*    */ {
/*  5 */   STATUS_OK(Integer.valueOf(1)),
/*  6 */   STATUS_ERRO_SISTEMA(Integer.valueOf(3)),
/*  7 */   STATUS_ERRO_LAYOUT(Integer.valueOf(4)),
/*  8 */   STATUS_PROCESSANDO(Integer.valueOf(6)),
/*  9 */   STATUS_OK_PROCESS(Integer.valueOf(7)),
/* 10 */   STATUS_PROCESSANDO_PROCESS(Integer.valueOf(8)),
/* 11 */   STATUS_ERRO_PROCESS(Integer.valueOf(9));
/*    */   
/*    */   private Integer codStatusCarga;
/*    */   
/*    */   StatusCarga(Integer codStatusCarga) {
/* 16 */     this.codStatusCarga = codStatusCarga;
/*    */   }
/*    */   
/*    */   public Integer getCodStatusCarga() {
/* 20 */     return this.codStatusCarga;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\constantes\processo\StatusCarga.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */