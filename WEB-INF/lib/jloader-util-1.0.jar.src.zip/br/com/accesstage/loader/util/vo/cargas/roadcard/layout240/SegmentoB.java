/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoB
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 7753388852092217693L;
/*     */   @LongPositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private Long codBanco;
/*     */   @LongPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Long loteServico;
/*     */   @LongPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Long tpoRegistro;
/*     */   @LongPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Long nroSeqLote;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSeguimentoDetalhe;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 17)
/*     */   private String usoCNAB;
/*     */   @LongPositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private Long tpoInsFavorecido;
/*     */   @LongPositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private Long nroInsFavorecido;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 62)
/*     */   private String dscLogradouro;
/*     */   @LongPositionalField(initialPosition = 63, finalPosition = 67)
/*     */   private Long nroLocal;
/*     */   @PositionalField(initialPosition = 68, finalPosition = 82)
/*     */   private String dscComplmento;
/*     */   @PositionalField(initialPosition = 83, finalPosition = 97)
/*     */   private String dscBairro;
/*     */   @PositionalField(initialPosition = 98, finalPosition = 117)
/*     */   private String nmeCidade;
/*     */   @LongPositionalField(initialPosition = 118, finalPosition = 122)
/*     */   private Long nroCep;
/*     */   @PositionalField(initialPosition = 123, finalPosition = 125)
/*     */   private String nroCepComplemento;
/*     */   @PositionalField(initialPosition = 126, finalPosition = 127)
/*     */   private String slgEstado;
/*     */   @LongPositionalField(initialPosition = 128, finalPosition = 135)
/*     */   private Long dtaVenc;
/*     */   @LongPositionalField(initialPosition = 136, finalPosition = 150)
/*     */   private Long vlrDoc;
/*     */   @LongPositionalField(initialPosition = 151, finalPosition = 165)
/*     */   private Long vlrAba;
/*     */   @LongPositionalField(initialPosition = 166, finalPosition = 180)
/*     */   private Long vlrDes;
/*     */   @LongPositionalField(initialPosition = 181, finalPosition = 195)
/*     */   private Long vlrMora;
/*     */   @LongPositionalField(initialPosition = 196, finalPosition = 210)
/*     */   private Long vlrMulta;
/*     */   @PositionalField(initialPosition = 211, finalPosition = 225)
/*     */   private String codDocFavorecido;
/*     */   @LongPositionalField(initialPosition = 226, finalPosition = 226)
/*     */   private Long dscAviso;
/*     */   @LongPositionalField(initialPosition = 227, finalPosition = 232)
/*     */   private Long usoSiape;
/*     */   @PositionalField(initialPosition = 233, finalPosition = 240)
/*     */   private String usoCNAB1;
/*     */   
/*     */   public Long getCodBanco() {
/*  72 */     return this.codBanco;
/*     */   }
/*     */   public void setCodBanco(Long codBanco) {
/*  75 */     this.codBanco = codBanco;
/*     */   }
/*     */   public Long getLoteServico() {
/*  78 */     return this.loteServico;
/*     */   }
/*     */   public void setLoteServico(Long loteServico) {
/*  81 */     this.loteServico = loteServico;
/*     */   }
/*     */   public Long getTpoRegistro() {
/*  84 */     return this.tpoRegistro;
/*     */   }
/*     */   public void setTpoRegistro(Long tpoRegistro) {
/*  87 */     this.tpoRegistro = tpoRegistro;
/*     */   }
/*     */   public Long getNroSeqLote() {
/*  90 */     return this.nroSeqLote;
/*     */   }
/*     */   public void setNroSeqLote(Long nroSeqLote) {
/*  93 */     this.nroSeqLote = nroSeqLote;
/*     */   }
/*     */   public String getCodSeguimentoDetalhe() {
/*  96 */     return this.codSeguimentoDetalhe;
/*     */   }
/*     */   public void setCodSeguimentoDetalhe(String codSeguimentoDetalhe) {
/*  99 */     this.codSeguimentoDetalhe = codSeguimentoDetalhe;
/*     */   }
/*     */   public String getUsoCNAB() {
/* 102 */     return this.usoCNAB;
/*     */   }
/*     */   public void setUsoCNAB(String usoCNAB) {
/* 105 */     this.usoCNAB = usoCNAB;
/*     */   }
/*     */   public Long getTpoInsFavorecido() {
/* 108 */     return this.tpoInsFavorecido;
/*     */   }
/*     */   public void setTpoInsFavorecido(Long tpoInsFavorecido) {
/* 111 */     this.tpoInsFavorecido = tpoInsFavorecido;
/*     */   }
/*     */   public Long getNroInsFavorecido() {
/* 114 */     return this.nroInsFavorecido;
/*     */   }
/*     */   public void setNroInsFavorecido(Long nroInsFavorecido) {
/* 117 */     this.nroInsFavorecido = nroInsFavorecido;
/*     */   }
/*     */   public String getDscLogradouro() {
/* 120 */     return this.dscLogradouro;
/*     */   }
/*     */   public void setDscLogradouro(String dscLogradouro) {
/* 123 */     this.dscLogradouro = dscLogradouro;
/*     */   }
/*     */   public Long getNroLocal() {
/* 126 */     return this.nroLocal;
/*     */   }
/*     */   public void setNroLocal(Long nroLocal) {
/* 129 */     this.nroLocal = nroLocal;
/*     */   }
/*     */   public String getDscComplmento() {
/* 132 */     return this.dscComplmento;
/*     */   }
/*     */   public void setDscComplmento(String dscComplmento) {
/* 135 */     this.dscComplmento = dscComplmento;
/*     */   }
/*     */   public String getDscBairro() {
/* 138 */     return this.dscBairro;
/*     */   }
/*     */   public void setDscBairro(String dscBairro) {
/* 141 */     this.dscBairro = dscBairro;
/*     */   }
/*     */   public String getNmeCidade() {
/* 144 */     return this.nmeCidade;
/*     */   }
/*     */   public void setNmeCidade(String nmeCidade) {
/* 147 */     this.nmeCidade = nmeCidade;
/*     */   }
/*     */   public Long getNroCep() {
/* 150 */     return this.nroCep;
/*     */   }
/*     */   public void setNroCep(Long nroCep) {
/* 153 */     this.nroCep = nroCep;
/*     */   }
/*     */   public String getNroCepComplemento() {
/* 156 */     return this.nroCepComplemento;
/*     */   }
/*     */   public void setNroCepComplemento(String nroCepComplemento) {
/* 159 */     this.nroCepComplemento = nroCepComplemento;
/*     */   }
/*     */   public String getSlgEstado() {
/* 162 */     return this.slgEstado;
/*     */   }
/*     */   public void setSlgEstado(String slgEstado) {
/* 165 */     this.slgEstado = slgEstado;
/*     */   }
/*     */   public Long getDtaVenc() {
/* 168 */     return this.dtaVenc;
/*     */   }
/*     */   public void setDtaVenc(Long dtaVenc) {
/* 171 */     this.dtaVenc = dtaVenc;
/*     */   }
/*     */   public Long getVlrDoc() {
/* 174 */     return this.vlrDoc;
/*     */   }
/*     */   public void setVlrDoc(Long vlrDoc) {
/* 177 */     this.vlrDoc = vlrDoc;
/*     */   }
/*     */   public Long getVlrAba() {
/* 180 */     return this.vlrAba;
/*     */   }
/*     */   public void setVlrAba(Long vlrAba) {
/* 183 */     this.vlrAba = vlrAba;
/*     */   }
/*     */   public Long getVlrDes() {
/* 186 */     return this.vlrDes;
/*     */   }
/*     */   public void setVlrDes(Long vlrDes) {
/* 189 */     this.vlrDes = vlrDes;
/*     */   }
/*     */   public Long getVlrMora() {
/* 192 */     return this.vlrMora;
/*     */   }
/*     */   public void setVlrMora(Long vlrMora) {
/* 195 */     this.vlrMora = vlrMora;
/*     */   }
/*     */   public Long getVlrMulta() {
/* 198 */     return this.vlrMulta;
/*     */   }
/*     */   public void setVlrMulta(Long vlrMulta) {
/* 201 */     this.vlrMulta = vlrMulta;
/*     */   }
/*     */   public String getCodDocFavorecido() {
/* 204 */     return this.codDocFavorecido;
/*     */   }
/*     */   public void setCodDocFavorecido(String codDocFavorecido) {
/* 207 */     this.codDocFavorecido = codDocFavorecido;
/*     */   }
/*     */   public Long getDscAviso() {
/* 210 */     return this.dscAviso;
/*     */   }
/*     */   public void setDscAviso(Long dscAviso) {
/* 213 */     this.dscAviso = dscAviso;
/*     */   }
/*     */   public Long getUsoSiape() {
/* 216 */     return this.usoSiape;
/*     */   }
/*     */   public void setUsoSiape(Long usoSiape) {
/* 219 */     this.usoSiape = usoSiape;
/*     */   }
/*     */   public String getUsoCNAB1() {
/* 222 */     return this.usoCNAB1;
/*     */   }
/*     */   public void setUsoCNAB1(String usoCNAB1) {
/* 225 */     this.usoCNAB1 = usoCNAB1;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoB.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */