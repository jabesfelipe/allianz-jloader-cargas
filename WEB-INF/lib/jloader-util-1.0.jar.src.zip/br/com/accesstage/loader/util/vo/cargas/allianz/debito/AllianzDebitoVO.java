/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AllianzDebitoVO
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Header header;
/*  33 */   private List<DetalheB> listDetalheB = new ArrayList<DetalheB>();
/*  34 */   private List<DetalheC> listDetalheC = new ArrayList<DetalheC>();
/*  35 */   private List<DetalheD> listDetalheD = new ArrayList<DetalheD>();
/*  36 */   private List<DetalheE> listDetalheE = new ArrayList<DetalheE>();
/*  37 */   private List<DetalheF> listDetalheF = new ArrayList<DetalheF>();
/*  38 */   private List<DetalheH> listDetalheH = new ArrayList<DetalheH>();
/*  39 */   private List<DetalheI> listDetalheI = new ArrayList<DetalheI>();
/*  40 */   private List<DetalheJ> listDetalheJ = new ArrayList<DetalheJ>();
/*  41 */   private List<DetalheK> listDetalheK = new ArrayList<DetalheK>();
/*  42 */   private List<DetalheL> listDetalheL = new ArrayList<DetalheL>();
/*  43 */   private List<DetalheT> listDetalheT = new ArrayList<DetalheT>();
/*  44 */   private List<DetalheX> listDetalheX = new ArrayList<DetalheX>();
/*  45 */   private List<DetalheZ> listDetalheZ = new ArrayList<DetalheZ>();
/*     */   private Trailler trailler;
/*     */   
/*     */   public Header getHeader() {
/*  49 */     return this.header;
/*     */   }
/*     */   
/*     */   public void setHeader(Header header) {
/*  53 */     this.header = header;
/*     */   }
/*     */   
/*     */   public List<DetalheB> getListDetalheB() {
/*  57 */     return this.listDetalheB;
/*     */   }
/*     */   
/*     */   public void setListDetalheB(List<DetalheB> listDetalheB) {
/*  61 */     this.listDetalheB = listDetalheB;
/*     */   }
/*     */   
/*     */   public List<DetalheC> getListDetalheC() {
/*  65 */     return this.listDetalheC;
/*     */   }
/*     */   
/*     */   public void setListDetalheC(List<DetalheC> listDetalheC) {
/*  69 */     this.listDetalheC = listDetalheC;
/*     */   }
/*     */   
/*     */   public List<DetalheD> getListDetalheD() {
/*  73 */     return this.listDetalheD;
/*     */   }
/*     */   
/*     */   public void setListDetalheD(List<DetalheD> listDetalheD) {
/*  77 */     this.listDetalheD = listDetalheD;
/*     */   }
/*     */   
/*     */   public List<DetalheE> getListDetalheE() {
/*  81 */     return this.listDetalheE;
/*     */   }
/*     */   
/*     */   public void setListDetalheE(List<DetalheE> listDetalheE) {
/*  85 */     this.listDetalheE = listDetalheE;
/*     */   }
/*     */   
/*     */   public List<DetalheF> getListDetalheF() {
/*  89 */     return this.listDetalheF;
/*     */   }
/*     */   
/*     */   public void setListDetalheF(List<DetalheF> listDetalheF) {
/*  93 */     this.listDetalheF = listDetalheF;
/*     */   }
/*     */   
/*     */   public List<DetalheH> getListDetalheH() {
/*  97 */     return this.listDetalheH;
/*     */   }
/*     */   
/*     */   public void setListDetalheH(List<DetalheH> listDetalheH) {
/* 101 */     this.listDetalheH = listDetalheH;
/*     */   }
/*     */   
/*     */   public List<DetalheI> getListDetalheI() {
/* 105 */     return this.listDetalheI;
/*     */   }
/*     */   
/*     */   public void setListDetalheI(List<DetalheI> listDetalheI) {
/* 109 */     this.listDetalheI = listDetalheI;
/*     */   }
/*     */   
/*     */   public List<DetalheJ> getListDetalheJ() {
/* 113 */     return this.listDetalheJ;
/*     */   }
/*     */   
/*     */   public void setListDetalheJ(List<DetalheJ> listDetalheJ) {
/* 117 */     this.listDetalheJ = listDetalheJ;
/*     */   }
/*     */   
/*     */   public List<DetalheK> getListDetalheK() {
/* 121 */     return this.listDetalheK;
/*     */   }
/*     */   
/*     */   public void setListDetalheK(List<DetalheK> listDetalheK) {
/* 125 */     this.listDetalheK = listDetalheK;
/*     */   }
/*     */   
/*     */   public List<DetalheL> getListDetalheL() {
/* 129 */     return this.listDetalheL;
/*     */   }
/*     */   
/*     */   public void setListDetalheL(List<DetalheL> listDetalheL) {
/* 133 */     this.listDetalheL = listDetalheL;
/*     */   }
/*     */   
/*     */   public List<DetalheT> getListDetalheT() {
/* 137 */     return this.listDetalheT;
/*     */   }
/*     */   
/*     */   public void setListDetalheT(List<DetalheT> listDetalheT) {
/* 141 */     this.listDetalheT = listDetalheT;
/*     */   }
/*     */   
/*     */   public List<DetalheX> getListDetalheX() {
/* 145 */     return this.listDetalheX;
/*     */   }
/*     */   
/*     */   public void setListDetalheX(List<DetalheX> listDetalheX) {
/* 149 */     this.listDetalheX = listDetalheX;
/*     */   }
/*     */   
/*     */   public List<DetalheZ> getListDetalheZ() {
/* 153 */     return this.listDetalheZ;
/*     */   }
/*     */   
/*     */   public void setListDetalheZ(List<DetalheZ> listDetalheZ) {
/* 157 */     this.listDetalheZ = listDetalheZ;
/*     */   }
/*     */   
/*     */   public Trailler getTrailler() {
/* 161 */     return this.trailler;
/*     */   }
/*     */   
/*     */   public void setTrailler(Trailler trailler) {
/* 165 */     this.trailler = trailler;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\AllianzDebitoVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */