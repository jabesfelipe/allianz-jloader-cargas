/*    */ package br.com.accesstage.loader.util.commom.ffpojo;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RecordDescriptor
/*    */ {
/*    */   private List<? extends FieldDescriptor> fieldDescriptors;
/*    */   private Class<?> recordClazz;
/*    */   
/*    */   public RecordDescriptor() {}
/*    */   
/*    */   public RecordDescriptor(Class<?> recordClazz, List<? extends FieldDescriptor> fieldDescriptors) {
/* 16 */     this.recordClazz = recordClazz;
/* 17 */     this.fieldDescriptors = fieldDescriptors;
/*    */   }
/*    */   
/*    */   public abstract void assertValid() throws Exception;
/*    */   
/*    */   public abstract void sortFieldDescriptors();
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\commom\ffpojo\RecordDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */