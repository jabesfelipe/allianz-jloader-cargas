/*    */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.decorator;
/*    */ 
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateDecorator_FULL
/*    */   extends DefaultFieldDecorator
/*    */ {
/*    */   public Object fromString(String str) {
/* 15 */     if (!isNullOrWhitespace(str.trim()) && StringUtils.isNotEmpty(str)) {
/*    */       try {
/* 17 */         if (Long.valueOf(str).longValue() != 0L) {
/* 18 */           return (new SimpleDateFormat("yyyyMMddHHmmss")).parse(str);
/*    */         }
/* 20 */         return null;
/*    */       }
/* 22 */       catch (ParseException e) {
/* 23 */         throw new FieldDecoratorException(e);
/*    */       } 
/*    */     }
/* 26 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isNullOrWhitespace(CharSequence value) {
/* 30 */     if (value == null) {
/* 31 */       return true;
/*    */     }
/* 33 */     for (int i = 0; i < value.length(); i++) {
/* 34 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 35 */         return false;
/*    */       }
/*    */     } 
/* 38 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.0.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\decorator\DateDecorator_FULL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */