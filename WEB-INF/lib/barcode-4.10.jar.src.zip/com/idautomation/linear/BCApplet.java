package com.idautomation.linear;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

public class BCApplet extends Applet {
  public BarCode BC = null;
  
  public boolean isStandalone = false;
  
  public BCApplet() {
    setLayout(new BorderLayout());
  }
  
  public void start() {
    this.BC.autoSize = false;
    this.BC.paint(getGraphics());
  }
  
  public void refresh() {
    this.BC.paint(this.BC.getGraphics());
    paintAll(getGraphics());
  }
  
  public void init() {
    if (this.BC == null)
      this.BC = new BarCode(); 
    add("Center", this.BC);
    À("CODE_TYPE");
    À("N");
    À("X");
    À("I");
    À("H");
    À("BAR_HEIGHT");
    À("CODABAR_START");
    À("CODABAR_STOP");
    À("BAR_COLOR");
    À("FONT_COLOR");
    À("TEXT_FONT");
    À("UPCE_SYSTEM");
    À("BACK_COLOR");
    À("CODE128_SET");
    À("LEFT_MARGIN");
    À("TOP_MARGIN");
    À("CHECK_CHAR");
    À("BARCODE");
    À("GUARDBARS");
    À("ROTATE");
    À("SUPPLEMENT");
    À("SUPPLEMENT_CODE");
    À("SUPPLEMENT_HEIGHT");
    À("SUPPLEMENT_SEPARATION");
    À("POSTNET_TALL");
    À("POSTNET_SHORT");
    À("CHECK_CHARINTEXT");
    À("ST");
  }
  
  private void À(String paramString) {
    String str = getStringParam(paramString, "");
    if (str.length() == 0)
      return; 
    setParameter(paramString, str);
  }
  
  public void setParameter(String paramString1, String paramString2) {
    if (paramString2 == null)
      return; 
    if (paramString1.compareTo("CODE_TYPE") == 0) {
      if (paramString2.compareTo("CODE39") == 0) {
        this;
        this.BC.barType = 0;
      } 
      if (paramString2.compareTo("CODE39EXT") == 0) {
        this;
        this.BC.barType = 1;
      } 
      if (paramString2.compareTo("CODE93") == 0) {
        this;
        this.BC.barType = 9;
      } 
      if (paramString2.compareTo("CODE11") == 0) {
        this;
        this.BC.barType = 3;
      } 
      if (paramString2.compareTo("CODABAR") == 0) {
        this;
        this.BC.barType = 4;
      } 
      if (paramString2.compareTo("CODE93EXT") == 0) {
        this;
        this.BC.barType = 14;
      } 
      if (paramString2.compareTo("CODE128") == 0) {
        this;
        this.BC.barType = 13;
      } 
      if (paramString2.compareTo("MSI") == 0) {
        this;
        this.BC.barType = 5;
      } 
      if (paramString2.compareTo("IND25") == 0) {
        this;
        this.BC.barType = 7;
      } 
      if (paramString2.compareTo("MAT25") == 0) {
        this;
        this.BC.barType = 8;
      } 
      if (paramString2.compareTo("INTERLEAVED25") == 0) {
        this;
        this.BC.barType = 2;
      } 
      if (paramString2.compareTo("EAN13") == 0) {
        this;
        this.BC.barType = 10;
      } 
      if (paramString2.compareTo("EAN8") == 0) {
        this;
        this.BC.barType = 11;
      } 
      if (paramString2.compareTo("UPCA") == 0) {
        this;
        this.BC.barType = 6;
      } 
      if (paramString2.compareTo("UPCE") == 0) {
        this;
        this.BC.barType = 12;
      } 
      if (paramString2.compareTo("POSTNET") == 0) {
        this;
        this.BC.barType = 15;
      } 
      if (paramString2.compareTo("PLANET") == 0) {
        this;
        this.BC.barType = 16;
      } 
      if (paramString2.compareTo("UCC128") == 0) {
        this;
        this.BC.barType = 17;
      } 
    } 
    if (paramString1.compareTo("N") == 0)
      this.BC.N = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("SUPPLEMENT_CODE") == 0)
      this.BC.supplement = paramString2; 
    if (paramString1.compareTo("SUPPLEMENT_SEPARATION") == 0)
      this.BC.supSeparationCM = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("SUPPLEMENT_HEIGHT") == 0)
      this.BC.supHeight = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("SUPPLEMENT") == 0) {
      this.BC.UPCEANSupplement2 = false;
      this.BC.UPCEANSupplement5 = false;
      if (paramString2.compareTo("2") == 0)
        this.BC.UPCEANSupplement2 = true; 
      if (paramString2.compareTo("5") == 0)
        this.BC.UPCEANSupplement5 = true; 
    } 
    if (paramString1.compareTo("ROTATE") == 0)
      this.BC.rotate = (int)(new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("POSTNET_TALL") == 0)
      this.BC.postnetHeightTallBar = (int)(new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("POSTNET_SHORT") == 0)
      this.BC.postnetHeightShortBar = (int)(new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("X") == 0)
      this.BC.X = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("I") == 0)
      this.BC.I = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("LEFT_MARGIN") == 0)
      this.BC.leftMarginCM = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("TOP_MARGIN") == 0)
      this.BC.topMarginCM = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("BAR_COLOR") == 0)
      this.BC.barColor = convertColor(paramString2); 
    if (paramString1.compareTo("FONT_COLOR") == 0)
      this.BC.fontColor = convertColor(paramString2); 
    if (paramString1.compareTo("BACK_COLOR") == 0)
      this.BC.backColor = convertColor(paramString2); 
    if (paramString1.compareTo("GUARDBARS") == 0)
      this.BC.guardBars = (paramString2.compareTo("Y") == 0); 
    if (paramString1.compareTo("UPCE_SYSTEM") == 0)
      this.BC.UPCESytem = (new String(paramString2 + "1")).charAt(0); 
    if (paramString1.compareTo("CODABAR_START") == 0)
      this.BC.CODABARStartChar = (new String(paramString2 + "A")).charAt(0); 
    if (paramString1.compareTo("CODABAR_STOP") == 0)
      this.BC.CODABARStopChar = (new String(paramString2 + "A")).charAt(0); 
    if (paramString1.compareTo("TEXT_FONT") == 0)
      this.BC.textFont = convertFont(paramString2); 
    if (paramString1.compareTo("H") == 0)
      this.BC.H = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("BARCODE") == 0)
      this.BC.setDataToEncode(paramString2); 
    if (paramString1.compareTo("CHECK_CHAR") == 0)
      this.BC.checkCharacter = (paramString2.compareTo("Y") == 0); 
    if (paramString1.compareTo("CHECK_CHARINTEXT") == 0)
      this.BC.checkCharacterInText = (paramString2.compareTo("Y") == 0); 
    if (paramString1.compareTo("CODE128_SET") == 0)
      this.BC.Code128Set = (new String(paramString2 + "B")).charAt(0); 
    if (paramString1.compareTo("BAR_HEIGHT") == 0)
      this.BC.barHeightCM = (new Double(paramString2)).doubleValue(); 
    if (paramString1.compareTo("ST") == 0)
      this.BC.showText = (paramString2.compareTo("Y") == 0); 
  }
  
  public Color convertColor(String paramString) {
    if (paramString.compareTo("NULL") == 0)
      return null; 
    if (paramString.compareTo("RED") == 0)
      return Color.red; 
    if (paramString.compareTo("BLACK") == 0)
      return Color.black; 
    if (paramString.compareTo("BLUE") == 0)
      return Color.blue; 
    if (paramString.compareTo("CYAN") == 0)
      return Color.cyan; 
    if (paramString.compareTo("DARKGRAY") == 0)
      return Color.darkGray; 
    if (paramString.compareTo("GRAY") == 0)
      return Color.gray; 
    if (paramString.compareTo("GREEN") == 0)
      return Color.green; 
    if (paramString.compareTo("LIGHTGRAY") == 0)
      return Color.lightGray; 
    if (paramString.compareTo("MAGENTA") == 0)
      return Color.magenta; 
    if (paramString.compareTo("ORANGE") == 0)
      return Color.orange; 
    if (paramString.compareTo("PINK") == 0)
      return Color.pink; 
    if (paramString.compareTo("WHITE") == 0)
      return Color.white; 
    if (paramString.compareTo("YELLOW") == 0)
      return Color.yellow; 
    try {
      return Color.decode(paramString);
    } catch (Exception exception) {
      return Color.black;
    } 
  }
  
  public Font convertFont(String paramString) {
    String[] arrayOfString = Â(paramString);
    if (arrayOfString == null)
      return null; 
    if (arrayOfString.length < 3)
      return null; 
    byte b = 0;
    if (arrayOfString[1].compareTo("BOLD") == 0)
      b = 1; 
    if (arrayOfString[1].compareTo("ITALIC") == 0)
      b = 2; 
    try {
      return new Font(arrayOfString[0], b, (new Integer(arrayOfString[2])).intValue());
    } catch (Exception exception) {
      return null;
    } 
  }
  
  protected String getStringParam(String paramString1, String paramString2) {
    return Á(paramString1, paramString2);
  }
  
  private String Á(String paramString1, String paramString2) {
    return this.isStandalone ? paramString2 : ((getParameter(paramString1) != null) ? getParameter(paramString1) : paramString2);
  }
  
  private String[] Â(String paramString) {
    String[] arrayOfString1 = new String[500];
    byte b1 = 0;
    for (int i = paramString.indexOf("|"); i >= 0; i = paramString.indexOf("|")) {
      arrayOfString1[b1++] = paramString.substring(0, i);
      paramString = paramString.substring(i + 1, paramString.length());
    } 
    if (paramString.compareTo("") != 0)
      arrayOfString1[b1++] = paramString; 
    if (b1 == 0)
      return null; 
    String[] arrayOfString2 = new String[b1];
    for (byte b2 = 0; b2 < b1; b2++)
      arrayOfString2[b2] = arrayOfString1[b2]; 
    return arrayOfString2;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\BCApplet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */