package com.idautomation.linear;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class IDAImageCreator {
  private Image im;
  
  public Graphics g;
  
  public Image getImage(int paramInt1, int paramInt2) {
    int i = paramInt1;
    if (paramInt2 > paramInt1)
      i = paramInt2; 
    this.im = new BufferedImage(i, i, 13);
    this.g = ((BufferedImage)this.im).createGraphics();
    return this.im;
  }
  
  public Graphics getGraphics() {
    return this.g;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\IDAImageCreator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */