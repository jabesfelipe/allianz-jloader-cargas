/*     */ package com.idautomation.linear;
/*     */ 
/*     */ import com.idautomation.linear.encoder.GifEncoder;
/*     */ import com.sun.image.codec.jpeg.JPEGCodec;
/*     */ import com.sun.image.codec.jpeg.JPEGEncodeParam;
/*     */ import com.sun.image.codec.jpeg.JPEGImageEncoder;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IDAutomationServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   private boolean debug = false;
/*     */   
/*     */   public void init() throws ServletException {}
/*     */   
/*     */   private BarCode getChart(HttpServletRequest paramHttpServletRequest) {
/*  35 */     BarCode barCode = new BarCode();
/*  36 */     if (paramHttpServletRequest != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  44 */       String str = null;
/*  45 */       if (paramHttpServletRequest.getParameter("CODE_TYPE") != null) {
/*     */         
/*  47 */         str = paramHttpServletRequest.getParameter("CODE_TYPE");
/*  48 */         if (str.compareTo("CODE39") == 0) barCode.barType = 0; 
/*  49 */         if (str.compareTo("CODE39EXT") == 0) barCode.barType = 1; 
/*  50 */         if (str.compareTo("INTERLEAVED25") == 0) barCode.barType = 2; 
/*  51 */         if (str.compareTo("CODE11") == 0) barCode.barType = 3; 
/*  52 */         if (str.compareTo("CODABAR") == 0) barCode.barType = 4; 
/*  53 */         if (str.compareTo("MSI") == 0) barCode.barType = 5; 
/*  54 */         if (str.compareTo("UPCA") == 0) barCode.barType = 6; 
/*  55 */         if (str.compareTo("IND25") == 0) barCode.barType = 7; 
/*  56 */         if (str.compareTo("MAT25") == 0) barCode.barType = 8; 
/*  57 */         if (str.compareTo("CODE93") == 0) barCode.barType = 9; 
/*  58 */         if (str.compareTo("EAN13") == 0) barCode.barType = 10; 
/*  59 */         if (str.compareTo("EAN8") == 0) barCode.barType = 11; 
/*  60 */         if (str.compareTo("UPCE") == 0) barCode.barType = 12; 
/*  61 */         if (str.compareTo("CODE128") == 0) barCode.barType = 13; 
/*  62 */         if (str.compareTo("CODE93EXT") == 0) barCode.barType = 14; 
/*  63 */         if (str.compareTo("POSTNET") == 0) barCode.barType = 15; 
/*  64 */         if (str.compareTo("PLANET") == 0) barCode.barType = 16; 
/*  65 */         if (str.compareTo("UCC128") == 0) barCode.barType = 17; 
/*     */       } 
/*  67 */       if (paramHttpServletRequest.getParameter("ROTATE") != null) barCode.rotate = (new Integer(paramHttpServletRequest.getParameter("ROTATE"))).intValue(); 
/*  68 */       if (paramHttpServletRequest.getParameter("BAR_HEIGHT") != null) barCode.barHeightCM = (new Double(paramHttpServletRequest.getParameter("BAR_HEIGHT"))).doubleValue(); 
/*  69 */       if (paramHttpServletRequest.getParameter("X") != null) barCode.X = (new Double(paramHttpServletRequest.getParameter("X"))).doubleValue(); 
/*  70 */       if (paramHttpServletRequest.getParameter("N") != null) barCode.N = (new Double(paramHttpServletRequest.getParameter("N"))).doubleValue(); 
/*  71 */       if (paramHttpServletRequest.getParameter("LEFT_MARGIN") != null) barCode.leftMarginCM = (new Double(paramHttpServletRequest.getParameter("LEFT_MARGIN"))).doubleValue(); 
/*  72 */       if (paramHttpServletRequest.getParameter("TOP_MARGIN") != null) barCode.topMarginCM = (new Double(paramHttpServletRequest.getParameter("TOP_MARGIN"))).doubleValue(); 
/*  73 */       if (paramHttpServletRequest.getParameter("CHECK_CHAR") != null) barCode.checkCharacter = (paramHttpServletRequest.getParameter("CHECK_CHAR").compareTo("Y") == 0); 
/*  74 */       if (paramHttpServletRequest.getParameter("CHECK_CHARINTEXT") != null) barCode.checkCharacterInText = (paramHttpServletRequest.getParameter("CHECK_CHARINTEXT").compareTo("Y") == 0); 
/*  75 */       if (paramHttpServletRequest.getParameter("ST") != null) barCode.showText = (paramHttpServletRequest.getParameter("ST").compareTo("Y") == 0); 
/*  76 */       if (paramHttpServletRequest.getParameter("CODE128_SET") != null) barCode.Code128Set = paramHttpServletRequest.getParameter("CODE128_SET").charAt(0); 
/*  77 */       if (paramHttpServletRequest.getParameter("UPCE_SYSTEM") != null) barCode.UPCESytem = paramHttpServletRequest.getParameter("UPCE_SYSTEM").charAt(0); 
/*  78 */       if (paramHttpServletRequest.getParameter("TEXT_FONT") != null) barCode.textFont = convertFont(paramHttpServletRequest.getParameter("TEXT_FONT")); 
/*  79 */       if (paramHttpServletRequest.getParameter("FONT_COLOR") != null) barCode.fontColor = convertColor(paramHttpServletRequest.getParameter("FONT_COLOR")); 
/*  80 */       if (paramHttpServletRequest.getParameter("BAR_COLOR") != null) barCode.barColor = convertColor(paramHttpServletRequest.getParameter("BAR_COLOR")); 
/*  81 */       if (paramHttpServletRequest.getParameter("BACK_COLOR") != null) barCode.backColor = convertColor(paramHttpServletRequest.getParameter("BACK_COLOR")); 
/*  82 */       if (paramHttpServletRequest.getParameter("BARCODE") != null) {
/*     */         
/*  84 */         barCode.code = paramHttpServletRequest.getParameter("BARCODE");
/*     */       }
/*     */       else {
/*     */         
/*  88 */         barCode.code = "000000000000";
/*     */       } 
/*     */     } else {
/*     */       
/*  92 */       barCode.code = "No Data";
/*     */     } 
/*  94 */     return barCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public Font convertFont(String paramString) {
/*  99 */     String[] arrayOfString = convertList(paramString);
/* 100 */     if (arrayOfString == null) return null; 
/* 101 */     if (arrayOfString.length < 3) return null; 
/* 102 */     byte b = 0;
/* 103 */     if (arrayOfString[1].compareTo("BOLD") == 0) b = 1; 
/* 104 */     if (arrayOfString[1].compareTo("ITALIC") == 0) b = 2;
/*     */     
/*     */     try {
/* 107 */       return new Font(arrayOfString[0], b, (new Integer(arrayOfString[2])).intValue());
/*     */     } catch (Exception exception) {
/* 109 */       return null;
/*     */     } 
/*     */   }
/*     */   private String[] convertList(String paramString) {
/* 113 */     String[] arrayOfString1 = new String[500];
/* 114 */     byte b1 = 0;
/*     */     
/* 116 */     int i = paramString.indexOf("|");
/* 117 */     while (i >= 0) {
/*     */       
/* 119 */       arrayOfString1[b1++] = paramString.substring(0, i);
/* 120 */       paramString = paramString.substring(i + 1, paramString.length());
/* 121 */       i = paramString.indexOf("|");
/*     */     } 
/* 123 */     if (paramString.compareTo("") != 0) arrayOfString1[b1++] = paramString; 
/* 124 */     if (b1 == 0) return null; 
/* 125 */     String[] arrayOfString2 = new String[b1];
/* 126 */     for (byte b2 = 0; b2 < b1; ) { arrayOfString2[b2] = arrayOfString1[b2]; b2++; }
/* 127 */      return arrayOfString2;
/*     */   }
/*     */   
/*     */   public Color convertColor(String paramString) {
/* 131 */     if (paramString.compareTo("NULL") == 0) return null; 
/* 132 */     if (paramString.compareTo("RED") == 0) return Color.red; 
/* 133 */     if (paramString.compareTo("BLACK") == 0) return Color.black; 
/* 134 */     if (paramString.compareTo("BLUE") == 0) return Color.blue; 
/* 135 */     if (paramString.compareTo("CYAN") == 0) return Color.cyan; 
/* 136 */     if (paramString.compareTo("DARKGRAY") == 0) return Color.darkGray; 
/* 137 */     if (paramString.compareTo("GRAY") == 0) return Color.gray; 
/* 138 */     if (paramString.compareTo("GREEN") == 0) return Color.green; 
/* 139 */     if (paramString.compareTo("LIGHTGRAY") == 0) return Color.lightGray; 
/* 140 */     if (paramString.compareTo("MAGENTA") == 0) return Color.magenta; 
/* 141 */     if (paramString.compareTo("ORANGE") == 0) return Color.orange; 
/* 142 */     if (paramString.compareTo("PINK") == 0) return Color.pink; 
/* 143 */     if (paramString.compareTo("WHITE") == 0) return Color.white; 
/* 144 */     if (paramString.compareTo("YELLOW") == 0) return Color.yellow;
/*     */     
/*     */     try {
/* 147 */       return Color.decode(paramString);
/*     */     } catch (Exception exception) {
/* 149 */       return Color.black;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/* 162 */     String str = "jpeg";
/* 163 */     if (paramHttpServletRequest != null) {
/*     */       
/* 165 */       if (paramHttpServletRequest.getParameter("FORMAT") != null) str = paramHttpServletRequest.getParameter("FORMAT").toLowerCase(); 
/* 166 */       if (str.compareTo("gif") != 0) str = "jpeg"; 
/*     */     } 
/* 168 */     paramHttpServletResponse.setContentType("image/" + str);
/* 169 */     ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
/*     */     
/* 171 */     paramHttpServletResponse.setHeader("Pragma", "no-cache");
/* 172 */     paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
/* 173 */     paramHttpServletResponse.setDateHeader("Expires", 0L);
/*     */ 
/*     */     
/*     */     try {
/* 177 */       int i = 10;
/* 178 */       int j = 10;
/*     */       
/* 180 */       BarCode barCode = getChart(paramHttpServletRequest);
/* 181 */       if (paramHttpServletRequest != null && paramHttpServletRequest.getParameter("WIDTH") != null && paramHttpServletRequest.getParameter("HEIGHT") != null) {
/*     */         
/* 183 */         i = (new Integer(paramHttpServletRequest.getParameter("WIDTH"))).intValue();
/* 184 */         j = (new Integer(paramHttpServletRequest.getParameter("HEIGHT"))).intValue();
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 189 */         barCode.autoSize = true;
/* 190 */         barCode.setSize(170, 90);
/* 191 */         BufferedImage bufferedImage1 = new BufferedImage((barCode.getSize()).width, (barCode.getSize()).height, 13);
/* 192 */         Graphics2D graphics2D1 = bufferedImage1.createGraphics();
/* 193 */         barCode.paint(graphics2D1);
/* 194 */         barCode.invalidate();
/* 195 */         i = (barCode.getSize()).width;
/* 196 */         j = (barCode.getSize()).height;
/* 197 */         graphics2D1.dispose();
/*     */       } 
/* 199 */       BufferedImage bufferedImage = new BufferedImage(i, j, 1);
/* 200 */       Graphics2D graphics2D = bufferedImage.createGraphics();
/* 201 */       if (this.debug) System.out.println("Size: " + i + " " + j); 
/* 202 */       barCode.setSize(i, j);
/* 203 */       barCode.paint(graphics2D);
/* 204 */       if (str.compareToIgnoreCase("gif") == 0) {
/*     */ 
/*     */         
/* 207 */         GifEncoder gifEncoder = new GifEncoder(bufferedImage, (OutputStream)servletOutputStream);
/* 208 */         gifEncoder.encode();
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 213 */         JPEGImageEncoder jPEGImageEncoder = JPEGCodec.createJPEGEncoder((OutputStream)servletOutputStream);
/*     */         
/* 215 */         JPEGEncodeParam jPEGEncodeParam = jPEGImageEncoder.getDefaultJPEGEncodeParam(bufferedImage);
/* 216 */         jPEGEncodeParam.setQuality(1.0F, true);
/* 217 */         jPEGImageEncoder.setJPEGEncodeParam(jPEGEncodeParam);
/* 218 */         jPEGImageEncoder.encode(bufferedImage, jPEGEncodeParam);
/*     */       } 
/*     */     } catch (Exception exception) {
/* 221 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException {
/*     */     try {
/* 229 */       doGet(paramHttpServletRequest, paramHttpServletResponse);
/*     */     } catch (Exception exception) {
/* 231 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\IDAutomationServlet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */