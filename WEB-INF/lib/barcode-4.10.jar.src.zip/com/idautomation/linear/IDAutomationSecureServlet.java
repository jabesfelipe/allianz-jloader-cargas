/*     */ package com.idautomation.linear;
/*     */ 
/*     */ import com.sun.image.codec.jpeg.JPEGCodec;
/*     */ import com.sun.image.codec.jpeg.JPEGEncodeParam;
/*     */ import com.sun.image.codec.jpeg.JPEGImageEncoder;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IDAutomationSecureServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   private boolean debug = false;
/*     */   
/*     */   public void init() throws ServletException {}
/*     */   
/*     */   private BarCode getChart(HttpServletRequest paramHttpServletRequest) {
/*  43 */     BarCode barCode = new BarCode();
/*     */     
/*  45 */     barCode.code = "SecureServlet";
/*     */     
/*  47 */     return barCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/*  61 */     String str = "jpeg";
/*  62 */     if (paramHttpServletRequest != null) {
/*  63 */       if (paramHttpServletRequest.getParameter("FORMAT") != null) str = paramHttpServletRequest.getParameter("FORMAT").toLowerCase(); 
/*  64 */       if (str.compareTo("gif") != 0) str = "jpeg";
/*     */     
/*     */     } 
/*  67 */     paramHttpServletResponse.setContentType("image/" + str);
/*  68 */     ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
/*     */     
/*  70 */     paramHttpServletResponse.setHeader("Pragma", "no-cache");
/*  71 */     paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
/*  72 */     paramHttpServletResponse.setDateHeader("Expires", 0L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  78 */       int i = 10;
/*  79 */       int j = 10;
/*     */       
/*  81 */       BarCode barCode = getChart(paramHttpServletRequest);
/*  82 */       if (paramHttpServletRequest != null && paramHttpServletRequest.getParameter("WIDTH") != null && paramHttpServletRequest.getParameter("HEIGHT") != null) {
/*  83 */         i = (new Integer(paramHttpServletRequest.getParameter("WIDTH"))).intValue();
/*  84 */         j = (new Integer(paramHttpServletRequest.getParameter("HEIGHT"))).intValue();
/*     */       }
/*     */       else {
/*     */         
/*  88 */         barCode.autoSize = true;
/*  89 */         barCode.setSize(170, 90);
/*  90 */         BufferedImage bufferedImage1 = new BufferedImage((barCode.getSize()).width, (barCode.getSize()).height, 13);
/*  91 */         Graphics2D graphics2D1 = bufferedImage1.createGraphics();
/*  92 */         barCode.paint(graphics2D1);
/*  93 */         barCode.invalidate();
/*  94 */         i = (barCode.getSize()).width;
/*  95 */         j = (barCode.getSize()).height;
/*  96 */         graphics2D1.dispose();
/*     */       } 
/*     */       
/*  99 */       BufferedImage bufferedImage = new BufferedImage(i, j, 1);
/* 100 */       Graphics2D graphics2D = bufferedImage.createGraphics();
/*     */       
/* 102 */       if (this.debug) System.out.println("Size: " + i + " " + j); 
/* 103 */       barCode.setSize(i, j);
/* 104 */       barCode.paint(graphics2D);
/*     */       
/* 106 */       if (str.compareToIgnoreCase("gif") == 0) {
/*     */ 
/*     */         
/* 109 */         barCode.setSize(i, j);
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 116 */         JPEGImageEncoder jPEGImageEncoder = JPEGCodec.createJPEGEncoder((OutputStream)servletOutputStream);
/*     */         
/* 118 */         JPEGEncodeParam jPEGEncodeParam = jPEGImageEncoder.getDefaultJPEGEncodeParam(bufferedImage);
/* 119 */         jPEGEncodeParam.setQuality(1.0F, true);
/* 120 */         jPEGImageEncoder.setJPEGEncodeParam(jPEGEncodeParam);
/* 121 */         jPEGImageEncoder.encode(bufferedImage, jPEGEncodeParam);
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       
/* 125 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException {
/*     */     
/* 136 */     try { doGet(paramHttpServletRequest, paramHttpServletResponse); }
/* 137 */     catch (Exception exception) { exception.printStackTrace(); }
/*     */   
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\IDAutomationSecureServlet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */