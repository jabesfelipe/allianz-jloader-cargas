/*     */ package com.idautomation.linear.encoder;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.awt.image.ImageConsumer;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ImageEncoder
/*     */   implements ImageConsumer
/*     */ {
/*     */   protected OutputStream out;
/*     */   private ImageProducer producer;
/*  59 */   private int width = -1;
/*  60 */   private int height = -1;
/*  61 */   private int hintflags = 0;
/*     */   private boolean started = false;
/*     */   private boolean encoding;
/*     */   private IOException iox;
/*  65 */   private static final ColorModel rgbModel = ColorModel.getRGBdefault();
/*  66 */   private Hashtable props = null;
/*     */   
/*     */   private boolean accumulate;
/*     */   
/*     */   private int[] accumulator;
/*     */   
/*     */   public ImageEncoder(Image paramImage, OutputStream paramOutputStream) throws IOException {
/*  73 */     this(paramImage.getSource(), paramOutputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void encode() throws IOException {
/* 108 */     this.encoding = true;
/* 109 */     this.iox = null;
/* 110 */     this.producer.startProduction(this);
/* 111 */     while (this.encoding) {
/*     */       
/*     */       try {
/* 114 */         wait();
/*     */       }
/* 116 */       catch (InterruptedException interruptedException) {}
/* 117 */     }  if (this.iox != null)
/* 118 */       throw this.iox; 
/*     */   }
/*     */   public ImageEncoder(ImageProducer paramImageProducer, OutputStream paramOutputStream) throws IOException {
/* 121 */     this.accumulate = false;
/*     */     this.producer = paramImageProducer;
/*     */     this.out = paramOutputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   private void encodePixelsWrapper(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5, int paramInt6) throws IOException {
/* 128 */     if (!this.started) {
/*     */       
/* 130 */       this.started = true;
/* 131 */       encodeStart(this.width, this.height);
/* 132 */       if ((this.hintflags & 0x2) == 0) {
/*     */         
/* 134 */         this.accumulate = true;
/* 135 */         this.accumulator = new int[this.width * this.height];
/*     */       } 
/*     */     } 
/* 138 */     if (this.accumulate) {
/* 139 */       for (byte b = 0; b < paramInt4; b++) {
/* 140 */         System.arraycopy(paramArrayOfint, b * paramInt6 + paramInt5, this.accumulator, (paramInt2 + b) * this.width + paramInt1, paramInt3);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 145 */       encodePixels(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void encodeFinish() throws IOException {
/* 150 */     if (this.accumulate) {
/*     */       
/* 152 */       encodePixels(0, 0, this.width, this.height, this.accumulator, 0, this.width);
/* 153 */       this.accumulator = null;
/* 154 */       this.accumulate = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void stop() {
/* 160 */     this.encoding = false;
/* 161 */     notifyAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDimensions(int paramInt1, int paramInt2) {
/* 169 */     this.width = paramInt1;
/* 170 */     this.height = paramInt2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperties(Hashtable paramHashtable) {
/* 175 */     this.props = paramHashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColorModel(ColorModel paramColorModel) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHints(int paramInt) {
/* 185 */     this.hintflags = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ColorModel paramColorModel, byte[] paramArrayOfbyte, int paramInt5, int paramInt6) {
/* 192 */     int[] arrayOfInt = new int[paramInt3];
/* 193 */     for (byte b = 0; b < paramInt4; b++) {
/*     */       
/* 195 */       int i = paramInt5 + b * paramInt6;
/* 196 */       for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 197 */         arrayOfInt[b1] = paramColorModel.getRGB(paramArrayOfbyte[i + b1] & 0xFF);
/*     */       }
/*     */       try {
/* 200 */         encodePixelsWrapper(paramInt1, paramInt2 + b, paramInt3, 1, arrayOfInt, 0, paramInt3);
/*     */       }
/*     */       catch (IOException iOException) {
/*     */         
/* 204 */         this.iox = iOException = null;
/* 205 */         stop();
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, ColorModel paramColorModel, int[] paramArrayOfint, int paramInt5, int paramInt6) {
/* 215 */     if (paramColorModel == rgbModel) {
/*     */ 
/*     */       
/*     */       try {
/* 219 */         encodePixelsWrapper(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramInt5, paramInt6);
/*     */       }
/*     */       catch (IOException iOException) {
/*     */         
/* 223 */         this.iox = iOException = null;
/* 224 */         stop();
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } else {
/* 230 */       int[] arrayOfInt = new int[paramInt3];
/* 231 */       for (byte b = 0; b < paramInt4; b++) {
/*     */         
/* 233 */         int i = paramInt5 + b * paramInt6;
/* 234 */         for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 235 */           arrayOfInt[b1] = paramColorModel.getRGB(paramArrayOfint[i + b1]);
/*     */         }
/*     */         try {
/* 238 */           encodePixelsWrapper(paramInt1, paramInt2 + b, paramInt3, 1, arrayOfInt, 0, paramInt3);
/*     */         }
/*     */         catch (IOException iOException) {
/*     */           
/* 242 */           this.iox = iOException = null;
/* 243 */           stop();
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void imageComplete(int paramInt) {
/* 252 */     this.producer.removeConsumer(this);
/* 253 */     if (paramInt == 4) {
/* 254 */       this.iox = new IOException("image aborted");
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 259 */         encodeFinish();
/* 260 */         encodeDone();
/*     */       }
/*     */       catch (IOException iOException) {
/*     */         
/* 264 */         this.iox = iOException = null;
/*     */       } 
/*     */     } 
/* 267 */     stop();
/*     */   }
/*     */   
/*     */   abstract void encodeStart(int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   abstract void encodePixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5, int paramInt6) throws IOException;
/*     */   
/*     */   abstract void encodeDone() throws IOException;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\encoder\ImageEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */