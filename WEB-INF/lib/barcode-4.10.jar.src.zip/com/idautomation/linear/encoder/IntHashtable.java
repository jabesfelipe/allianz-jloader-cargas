/*     */ package com.idautomation.linear.encoder;
/*     */ 
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntHashtable
/*     */   extends Dictionary
/*     */   implements Cloneable
/*     */ {
/*     */   private IntHashtableEntry[] table;
/*     */   private int count;
/*     */   private int threshold;
/*     */   private float loadFactor;
/*     */   
/*     */   public IntHashtable(int paramInt, float paramFloat) {
/*  48 */     if (paramInt <= 0 || paramFloat <= 0.0D)
/*  49 */       throw new IllegalArgumentException(); 
/*  50 */     this.loadFactor = paramFloat;
/*  51 */     this.table = new IntHashtableEntry[paramInt];
/*  52 */     this.threshold = (int)(paramInt * paramFloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntHashtable(int paramInt) {
/*  60 */     this(paramInt, 0.75F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntHashtable() {
/*  68 */     this(101, 0.75F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  74 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  80 */     return (this.count == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Enumeration keys() {
/*  87 */     return new IntHashtableEnumerator(this.table, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Enumeration elements() {
/*  95 */     return new IntHashtableEnumerator(this.table, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean contains(Object paramObject) {
/* 106 */     if (paramObject == null)
/* 107 */       throw new NullPointerException(); 
/* 108 */     IntHashtableEntry[] arrayOfIntHashtableEntry = this.table;
/* 109 */     for (int i = arrayOfIntHashtableEntry.length; i-- > 0;) {
/*     */       
/* 111 */       for (IntHashtableEntry intHashtableEntry = arrayOfIntHashtableEntry[i]; intHashtableEntry != null; intHashtableEntry = intHashtableEntry.next) {
/*     */         
/* 113 */         if (intHashtableEntry.value.equals(paramObject))
/* 114 */           return true; 
/*     */       } 
/*     */     } 
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean containsKey(int paramInt) {
/* 125 */     IntHashtableEntry[] arrayOfIntHashtableEntry = this.table;
/* 126 */     int i = paramInt;
/* 127 */     int j = (i & Integer.MAX_VALUE) % arrayOfIntHashtableEntry.length;
/* 128 */     for (IntHashtableEntry intHashtableEntry = arrayOfIntHashtableEntry[j]; intHashtableEntry != null; intHashtableEntry = intHashtableEntry.next) {
/*     */       
/* 130 */       if (intHashtableEntry.hash == i && intHashtableEntry.key == paramInt)
/* 131 */         return true; 
/*     */     } 
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object get(int paramInt) {
/* 144 */     IntHashtableEntry[] arrayOfIntHashtableEntry = this.table;
/* 145 */     int i = paramInt;
/* 146 */     int j = (i & Integer.MAX_VALUE) % arrayOfIntHashtableEntry.length;
/* 147 */     for (IntHashtableEntry intHashtableEntry = arrayOfIntHashtableEntry[j]; intHashtableEntry != null; intHashtableEntry = intHashtableEntry.next) {
/*     */       
/* 149 */       if (intHashtableEntry.hash == i && intHashtableEntry.key == paramInt)
/* 150 */         return intHashtableEntry.value; 
/*     */     } 
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object paramObject) {
/* 159 */     if (!(paramObject instanceof Integer))
/* 160 */       throw new InternalError("key is not an Integer"); 
/* 161 */     Integer integer = (Integer)paramObject;
/* 162 */     int i = integer.intValue();
/* 163 */     return get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rehash() {
/* 171 */     int i = this.table.length;
/* 172 */     IntHashtableEntry[] arrayOfIntHashtableEntry1 = this.table;
/*     */     
/* 174 */     int j = i * 2 + 1;
/* 175 */     IntHashtableEntry[] arrayOfIntHashtableEntry2 = new IntHashtableEntry[j];
/*     */     
/* 177 */     this.threshold = (int)(j * this.loadFactor);
/* 178 */     this.table = arrayOfIntHashtableEntry2;
/*     */     
/* 180 */     for (int k = i; k-- > 0;) {
/*     */       
/* 182 */       for (IntHashtableEntry intHashtableEntry = arrayOfIntHashtableEntry1[k]; intHashtableEntry != null; ) {
/*     */         
/* 184 */         IntHashtableEntry intHashtableEntry1 = intHashtableEntry;
/* 185 */         intHashtableEntry = intHashtableEntry.next;
/*     */         
/* 187 */         int m = (intHashtableEntry1.hash & Integer.MAX_VALUE) % j;
/* 188 */         intHashtableEntry1.next = arrayOfIntHashtableEntry2[m];
/* 189 */         arrayOfIntHashtableEntry2[m] = intHashtableEntry1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object put(int paramInt, Object paramObject) {
/* 206 */     if (paramObject == null) {
/* 207 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 210 */     IntHashtableEntry[] arrayOfIntHashtableEntry = this.table;
/* 211 */     int i = paramInt;
/* 212 */     int j = (i & Integer.MAX_VALUE) % arrayOfIntHashtableEntry.length;
/* 213 */     for (IntHashtableEntry intHashtableEntry1 = arrayOfIntHashtableEntry[j]; intHashtableEntry1 != null; intHashtableEntry1 = intHashtableEntry1.next) {
/*     */       
/* 215 */       if (intHashtableEntry1.hash == i && intHashtableEntry1.key == paramInt) {
/*     */         
/* 217 */         Object object = intHashtableEntry1.value;
/* 218 */         intHashtableEntry1.value = paramObject;
/* 219 */         return object;
/*     */       } 
/*     */     } 
/*     */     
/* 223 */     if (this.count >= this.threshold) {
/*     */ 
/*     */       
/* 226 */       rehash();
/* 227 */       return put(paramInt, paramObject);
/*     */     } 
/*     */ 
/*     */     
/* 231 */     IntHashtableEntry intHashtableEntry2 = new IntHashtableEntry();
/* 232 */     intHashtableEntry2.hash = i;
/* 233 */     intHashtableEntry2.key = paramInt;
/* 234 */     intHashtableEntry2.value = paramObject;
/* 235 */     intHashtableEntry2.next = arrayOfIntHashtableEntry[j];
/* 236 */     arrayOfIntHashtableEntry[j] = intHashtableEntry2;
/* 237 */     this.count++;
/* 238 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object paramObject1, Object paramObject2) {
/* 245 */     if (!(paramObject1 instanceof Integer))
/* 246 */       throw new InternalError("key is not an Integer"); 
/* 247 */     Integer integer = (Integer)paramObject1;
/* 248 */     int i = integer.intValue();
/* 249 */     return put(i, paramObject2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object remove(int paramInt) {
/* 258 */     IntHashtableEntry[] arrayOfIntHashtableEntry = this.table;
/* 259 */     int i = paramInt;
/* 260 */     int j = (i & Integer.MAX_VALUE) % arrayOfIntHashtableEntry.length;
/* 261 */     for (IntHashtableEntry intHashtableEntry1 = arrayOfIntHashtableEntry[j], intHashtableEntry2 = null; intHashtableEntry1 != null; intHashtableEntry2 = intHashtableEntry1, intHashtableEntry1 = intHashtableEntry1.next) {
/*     */       
/* 263 */       if (intHashtableEntry1.hash == i && intHashtableEntry1.key == paramInt) {
/*     */         
/* 265 */         if (intHashtableEntry2 != null) {
/* 266 */           intHashtableEntry2.next = intHashtableEntry1.next;
/*     */         } else {
/* 268 */           arrayOfIntHashtableEntry[j] = intHashtableEntry1.next;
/* 269 */         }  this.count--;
/* 270 */         return intHashtableEntry1.value;
/*     */       } 
/*     */     } 
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object paramObject) {
/* 280 */     if (!(paramObject instanceof Integer))
/* 281 */       throw new InternalError("key is not an Integer"); 
/* 282 */     Integer integer = (Integer)paramObject;
/* 283 */     int i = integer.intValue();
/* 284 */     return remove(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clear() {
/* 290 */     IntHashtableEntry[] arrayOfIntHashtableEntry = this.table;
/* 291 */     for (int i = arrayOfIntHashtableEntry.length; --i >= 0;)
/* 292 */       arrayOfIntHashtableEntry[i] = null; 
/* 293 */     this.count = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object clone() {
/*     */     try {
/* 303 */       IntHashtable intHashtable = (IntHashtable)super.clone();
/* 304 */       intHashtable.table = new IntHashtableEntry[this.table.length];
/* 305 */       for (int i = this.table.length; i-- > 0;) {
/* 306 */         intHashtable.table[i] = (this.table[i] != null) ? (IntHashtableEntry)this.table[i].clone() : null;
/*     */       }
/* 308 */       return intHashtable;
/*     */     
/*     */     }
/*     */     catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 313 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String toString() {
/* 320 */     int i = size() - 1;
/* 321 */     StringBuffer stringBuffer = new StringBuffer();
/* 322 */     Enumeration enumeration1 = keys();
/* 323 */     Enumeration enumeration2 = elements();
/* 324 */     stringBuffer.append("{");
/*     */     
/* 326 */     for (byte b = 0; b <= i; b++) {
/*     */       
/* 328 */       String str1 = enumeration1.nextElement().toString();
/* 329 */       String str2 = enumeration2.nextElement().toString();
/* 330 */       stringBuffer.append(str1 + "=" + str2);
/* 331 */       if (b < i)
/* 332 */         stringBuffer.append(", "); 
/*     */     } 
/* 334 */     stringBuffer.append("}");
/* 335 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\encoder\IntHashtable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */