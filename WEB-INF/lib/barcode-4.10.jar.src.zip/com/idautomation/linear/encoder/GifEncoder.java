/*     */ package com.idautomation.linear.encoder;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GifEncoder
/*     */   extends ImageEncoder
/*     */ {
/*     */   private boolean interlace = false;
/*     */   int width;
/*     */   int height;
/*     */   int[][] rgbPixels;
/*     */   IntHashtable colorHash;
/*     */   int Width;
/*     */   int Height;
/*     */   boolean Interlace;
/*     */   int curx;
/*     */   int cury;
/*     */   int CountDown;
/*     */   int Pass;
/*     */   static final int EOF = -1;
/*     */   static final int BITS = 12;
/*     */   static final int HSIZE = 5003;
/*     */   int n_bits;
/*     */   int maxbits;
/*     */   int maxcode;
/*     */   int maxmaxcode;
/*     */   int[] htab;
/*     */   int[] codetab;
/*     */   int hsize;
/*     */   int free_ent;
/*     */   boolean clear_flg;
/*     */   int g_init_bits;
/*     */   int ClearCode;
/*     */   int EOFCode;
/*     */   int cur_accum;
/*     */   int cur_bits;
/*     */   int[] masks;
/*     */   int a_count;
/*     */   byte[] accum;
/*     */   
/*     */   public GifEncoder(Image paramImage, OutputStream paramOutputStream) throws IOException {
/*  55 */     super(paramImage, paramOutputStream);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     this.Pass = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 429 */     this.maxbits = 12;
/*     */     
/* 431 */     this.maxmaxcode = 4096;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 438 */     this.htab = new int[5003];
/* 439 */     this.codetab = new int[5003];
/*     */     
/* 441 */     this.hsize = 5003;
/*     */     
/* 443 */     this.free_ent = 0;
/*     */ 
/*     */ 
/*     */     
/* 447 */     this.clear_flg = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 561 */     this.cur_accum = 0;
/* 562 */     this.cur_bits = 0;
/*     */     
/* 564 */     this.masks = new int[] { 0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 651 */     this.accum = new byte[256]; } public GifEncoder(Image paramImage, OutputStream paramOutputStream, boolean paramBoolean) throws IOException { super(paramImage, paramOutputStream); this.Pass = 0; this.maxbits = 12; this.maxmaxcode = 4096; this.htab = new int[5003]; this.codetab = new int[5003]; this.hsize = 5003; this.free_ent = 0; this.clear_flg = false; this.cur_accum = 0; this.cur_bits = 0; this.masks = new int[] { 0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535 }; this.accum = new byte[256]; this.interlace = paramBoolean; } public GifEncoder(ImageProducer paramImageProducer, OutputStream paramOutputStream) throws IOException { super(paramImageProducer, paramOutputStream); this.Pass = 0; this.maxbits = 12; this.maxmaxcode = 4096; this.htab = new int[5003]; this.codetab = new int[5003]; this.hsize = 5003; this.free_ent = 0; this.clear_flg = false; this.cur_accum = 0; this.cur_bits = 0; this.masks = new int[] { 0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535 }; this.accum = new byte[256]; } void encodeStart(int paramInt1, int paramInt2) throws IOException { this.width = paramInt1; this.height = paramInt2; this.rgbPixels = new int[paramInt2][paramInt1]; } void encodePixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5, int paramInt6) throws IOException { for (byte b = 0; b < paramInt4; b++) System.arraycopy(paramArrayOfint, b * paramInt6 + paramInt5, this.rgbPixels[paramInt2 + b], paramInt1, paramInt3);  } void encodeDone() throws IOException { byte b3; byte b = -1; int i = -1; this.colorHash = new IntHashtable(); byte b1 = 0; for (byte b2 = 0; b2 < this.height; b2++) { b3 = b2 * this.width; for (byte b4 = 0; b4 < this.width; b4++) { int k = this.rgbPixels[b2][b4]; boolean bool = (k >>> 24 < 128) ? true : false; if (bool) if (b < 0) { b = b1; i = k; } else if (k != i) { this.rgbPixels[b2][b4] = k = i; }   GifEncoderHashitem gifEncoderHashitem = (GifEncoderHashitem)this.colorHash.get(k); if (gifEncoderHashitem == null) { if (b1 >= 'Ā') throw new IOException("too many colors for a GIF");  gifEncoderHashitem = new GifEncoderHashitem(k, 1, b1, bool); b1++; this.colorHash.put(k, gifEncoderHashitem); } else { gifEncoderHashitem.count++; }  }  }  if (b1 <= 2) { b3 = 1; } else if (b1 <= 4) { b3 = 2; } else if (b1 <= 16) { b3 = 4; } else { b3 = 8; }  int j = 1 << b3; byte[] arrayOfByte1 = new byte[j]; byte[] arrayOfByte2 = new byte[j]; byte[] arrayOfByte3 = new byte[j]; for (Enumeration enumeration = this.colorHash.elements(); enumeration.hasMoreElements(); ) { GifEncoderHashitem gifEncoderHashitem = enumeration.nextElement(); arrayOfByte1[gifEncoderHashitem.index] = (byte)(gifEncoderHashitem.rgb >> 16 & 0xFF); arrayOfByte2[gifEncoderHashitem.index] = (byte)(gifEncoderHashitem.rgb >> 8 & 0xFF); arrayOfByte3[gifEncoderHashitem.index] = (byte)(gifEncoderHashitem.rgb & 0xFF); }  GIFEncode(this.out, this.width, this.height, this.interlace, (byte)0, b, b3, arrayOfByte1, arrayOfByte2, arrayOfByte3); } byte GetPixel(int paramInt1, int paramInt2) throws IOException { GifEncoderHashitem gifEncoderHashitem = (GifEncoderHashitem)this.colorHash.get(this.rgbPixels[paramInt2][paramInt1]); if (gifEncoderHashitem == null) throw new IOException("color not found");  return (byte)gifEncoderHashitem.index; } public GifEncoder(ImageProducer paramImageProducer, OutputStream paramOutputStream, boolean paramBoolean) throws IOException { super(paramImageProducer, paramOutputStream); this.Pass = 0; this.maxbits = 12; this.maxmaxcode = 4096; this.htab = new int[5003]; this.codetab = new int[5003]; this.hsize = 5003; this.free_ent = 0; this.clear_flg = false; this.cur_accum = 0; this.cur_bits = 0; this.masks = new int[] { 0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535 }; this.accum = new byte[256]; this.interlace = paramBoolean; }
/*     */   static void writeString(OutputStream paramOutputStream, String paramString) throws IOException { byte[] arrayOfByte = paramString.getBytes(); paramOutputStream.write(arrayOfByte); }
/*     */   void GIFEncode(OutputStream paramOutputStream, int paramInt1, int paramInt2, boolean paramBoolean, byte paramByte, int paramInt3, int paramInt4, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws IOException { int j; this.Width = paramInt1; this.Height = paramInt2; this.Interlace = paramBoolean; int i = 1 << paramInt4; boolean bool2 = false, bool1 = bool2; this.CountDown = paramInt1 * paramInt2; this.Pass = 0; if (paramInt4 <= 1) { j = 2; } else { j = paramInt4; }  this.curx = 0; this.cury = 0; writeString(paramOutputStream, "GIF89a"); Putword(paramInt1, paramOutputStream); Putword(paramInt2, paramOutputStream); byte b = -128; b = (byte)(b | 0x70); b = (byte)(b | (byte)(paramInt4 - 1)); Putbyte(b, paramOutputStream); Putbyte(paramByte, paramOutputStream); Putbyte((byte)0, paramOutputStream); for (byte b1 = 0; b1 < i; b1++) { Putbyte(paramArrayOfbyte1[b1], paramOutputStream); Putbyte(paramArrayOfbyte2[b1], paramOutputStream); Putbyte(paramArrayOfbyte3[b1], paramOutputStream); }  if (paramInt3 != -1) { Putbyte((byte)33, paramOutputStream); Putbyte((byte)-7, paramOutputStream); Putbyte((byte)4, paramOutputStream); Putbyte((byte)1, paramOutputStream); Putbyte((byte)0, paramOutputStream); Putbyte((byte)0, paramOutputStream); Putbyte((byte)paramInt3, paramOutputStream); Putbyte((byte)0, paramOutputStream); }  Putbyte((byte)44, paramOutputStream); Putword(bool1, paramOutputStream); Putword(bool2, paramOutputStream); Putword(paramInt1, paramOutputStream); Putword(paramInt2, paramOutputStream); if (paramBoolean) { Putbyte((byte)64, paramOutputStream); } else { Putbyte((byte)0, paramOutputStream); }  Putbyte((byte)j, paramOutputStream); compress(j + 1, paramOutputStream); Putbyte((byte)0, paramOutputStream); Putbyte((byte)59, paramOutputStream); }
/*     */   void BumpPixel() { this.curx++; if (this.curx == this.Width) { this.curx = 0; if (!this.Interlace) { this.cury++; } else { switch (this.Pass) { case 0: this.cury += 8; if (this.cury >= this.Height) { this.Pass++; this.cury = 4; }  break;case 1: this.cury += 8; if (this.cury >= this.Height) { this.Pass++; this.cury = 2; }  break;case 2: this.cury += 4; if (this.cury >= this.Height) { this.Pass++; this.cury = 1; }  break;
/*     */           case 3: this.cury += 2; break; }  }  }  }
/*     */   int GIFNextPixel() throws IOException { if (this.CountDown == 0)
/* 657 */       return -1;  this.CountDown--; byte b = GetPixel(this.curx, this.cury); BumpPixel(); return b & 0xFF; } void char_out(byte paramByte, OutputStream paramOutputStream) throws IOException { this.accum[this.a_count++] = paramByte;
/* 658 */     if (this.a_count >= 254)
/* 659 */       flush_char(paramOutputStream);  } void Putword(int paramInt, OutputStream paramOutputStream) throws IOException { Putbyte((byte)(paramInt & 0xFF), paramOutputStream); Putbyte((byte)(paramInt >> 8 & 0xFF), paramOutputStream); } void Putbyte(byte paramByte, OutputStream paramOutputStream) throws IOException { paramOutputStream.write(paramByte); } final int MAXCODE(int paramInt) { return (1 << paramInt) - 1; }
/*     */   void compress(int paramInt, OutputStream paramOutputStream) throws IOException { this.g_init_bits = paramInt; this.clear_flg = false; this.n_bits = this.g_init_bits; this.maxcode = MAXCODE(this.n_bits); this.ClearCode = 1 << paramInt - 1; this.EOFCode = this.ClearCode + 1; this.free_ent = this.ClearCode + 2; char_init(); int k = GIFNextPixel(); int n = 0; int i; for (i = this.hsize; i < 65536; i *= 2) n++;  n = 8 - n; int m = this.hsize; cl_hash(m); output(this.ClearCode, paramOutputStream); int j; while ((j = GIFNextPixel()) != -1) { i = (j << this.maxbits) + k; int i1 = j << n ^ k; if (this.htab[i1] == i) { k = this.codetab[i1]; continue; }  if (this.htab[i1] >= 0) { int i2 = m - i1; if (i1 == 0) i2 = 1;  label33: while (true) { if ((i1 -= i2) < 0) i1 += m;  if (this.htab[i1] == i) { k = this.codetab[i1]; break; }  if (this.htab[i1] < 0) break label33;  }  continue; }  output(k, paramOutputStream); k = j; if (this.free_ent < this.maxmaxcode) { this.codetab[i1] = this.free_ent++; this.htab[i1] = i; continue; }  cl_block(paramOutputStream); }  output(k, paramOutputStream); output(this.EOFCode, paramOutputStream); }
/*     */   void output(int paramInt, OutputStream paramOutputStream) throws IOException { this.cur_accum &= this.masks[this.cur_bits]; if (this.cur_bits > 0) { this.cur_accum |= paramInt << this.cur_bits; } else { this.cur_accum = paramInt; }  this.cur_bits += this.n_bits; while (this.cur_bits >= 8) { char_out((byte)(this.cur_accum & 0xFF), paramOutputStream); this.cur_accum >>= 8; this.cur_bits -= 8; }  if (this.free_ent > this.maxcode || this.clear_flg) if (this.clear_flg) { this.maxcode = MAXCODE(this.n_bits = this.g_init_bits); this.clear_flg = false; } else { this.n_bits++; if (this.n_bits == this.maxbits) { this.maxcode = this.maxmaxcode; } else { this.maxcode = MAXCODE(this.n_bits); }  }   if (paramInt == this.EOFCode) { while (this.cur_bits > 0) { char_out((byte)(this.cur_accum & 0xFF), paramOutputStream); this.cur_accum >>= 8; this.cur_bits -= 8; }  flush_char(paramOutputStream); }  }
/*     */   void cl_block(OutputStream paramOutputStream) throws IOException { cl_hash(this.hsize); this.free_ent = this.ClearCode + 2; this.clear_flg = true; output(this.ClearCode, paramOutputStream); }
/*     */   void cl_hash(int paramInt) { for (byte b = 0; b < paramInt; b++) this.htab[b] = -1;  }
/*     */   void char_init() { this.a_count = 0; }
/* 665 */   void flush_char(OutputStream paramOutputStream) throws IOException { if (this.a_count > 0) {
/*     */       
/* 667 */       paramOutputStream.write(this.a_count);
/* 668 */       paramOutputStream.write(this.accum, 0, this.a_count);
/* 669 */       this.a_count = 0;
/*     */     }  }
/*     */ 
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\encoder\GifEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */