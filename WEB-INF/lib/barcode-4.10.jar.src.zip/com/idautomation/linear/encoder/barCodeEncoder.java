/*     */ package com.idautomation.linear.encoder;
/*     */ 
/*     */ import com.idautomation.linear.BarCode;
/*     */ import com.sun.image.codec.jpeg.JPEGCodec;
/*     */ import com.sun.image.codec.jpeg.JPEGEncodeParam;
/*     */ import com.sun.image.codec.jpeg.JPEGImageEncoder;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class barCodeEncoder
/*     */ {
/*     */   String sFile;
/*     */   String sFormat;
/*     */   BarCode bc;
/*     */   public boolean result;
/*     */   
/*     */   public barCodeEncoder(BarCode paramBarCode, String paramString1, String paramString2) {
/*  29 */     this.sFormat = paramString1;
/*  30 */     this.sFile = paramString2;
/*  31 */     this.bc = paramBarCode;
/*  32 */     this.result = encode();
/*     */   }
/*     */   
/*     */   private boolean encode() {
/*  36 */     if (this.sFormat.toUpperCase().compareTo("GIF") == 0) return saveToGIF(); 
/*  37 */     if (this.sFormat.toUpperCase().compareTo("JPEG") == 0) return saveToJPEG(); 
/*  38 */     return false;
/*     */   }
/*     */   
/*     */   private boolean saveToGIF() {
/*  42 */     String str = System.getProperty("java.version");
/*  43 */     if (str.indexOf("1.1") == 0) return false;
/*     */ 
/*     */     
/*     */     try {
/*  47 */       if (this.bc.autoSize) {
/*  48 */         BufferedImage bufferedImage1 = new BufferedImage(100, 100, 13);
/*  49 */         Graphics2D graphics2D1 = bufferedImage1.createGraphics();
/*  50 */         this.bc.paint(graphics2D1);
/*  51 */         this.bc.invalidate();
/*  52 */         graphics2D1.dispose();
/*     */       } 
/*     */ 
/*     */       
/*  56 */       BufferedImage bufferedImage = new BufferedImage((this.bc.getSize()).width, (this.bc.getSize()).height, 13);
/*     */       
/*  58 */       Graphics2D graphics2D = bufferedImage.createGraphics();
/*     */       
/*  60 */       this.bc.paint(graphics2D);
/*     */ 
/*     */       
/*  63 */       File file = new File(this.sFile);
/*  64 */       file.delete();
/*  65 */       FileOutputStream fileOutputStream = new FileOutputStream(file);
/*     */ 
/*     */       
/*  68 */       GifEncoder gifEncoder = new GifEncoder(bufferedImage, fileOutputStream);
/*  69 */       gifEncoder.encode();
/*  70 */       fileOutputStream.close();
/*     */     }
/*     */     catch (Exception exception) {
/*     */       
/*  74 */       return false;
/*     */     } 
/*  76 */     return true;
/*     */   }
/*     */   
/*     */   private boolean saveToJPEG() {
/*  80 */     String str = System.getProperty("java.version");
/*  81 */     if (str.indexOf("1.1") == 0) return false;
/*     */ 
/*     */     
/*     */     try {
/*  85 */       if (this.bc.autoSize) {
/*  86 */         this.bc.setSize(170, 90);
/*  87 */         BufferedImage bufferedImage1 = new BufferedImage((this.bc.getSize()).width, (this.bc.getSize()).height, 13);
/*  88 */         Graphics2D graphics2D1 = bufferedImage1.createGraphics();
/*  89 */         this.bc.paint(graphics2D1);
/*  90 */         this.bc.invalidate();
/*  91 */         graphics2D1.dispose();
/*     */       } 
/*     */ 
/*     */       
/*  95 */       BufferedImage bufferedImage = new BufferedImage((this.bc.getSize()).width, (this.bc.getSize()).height, 1);
/*  96 */       Graphics2D graphics2D = bufferedImage.createGraphics();
/*  97 */       this.bc.paint(graphics2D);
/*     */ 
/*     */       
/* 100 */       File file = new File(this.sFile);
/* 101 */       file.delete();
/* 102 */       FileOutputStream fileOutputStream = new FileOutputStream(file);
/*     */ 
/*     */       
/* 105 */       JPEGImageEncoder jPEGImageEncoder = JPEGCodec.createJPEGEncoder(fileOutputStream);
/*     */ 
/*     */       
/* 108 */       JPEGEncodeParam jPEGEncodeParam = jPEGImageEncoder.getDefaultJPEGEncodeParam(bufferedImage);
/* 109 */       jPEGEncodeParam.setQuality(1.0F, true);
/* 110 */       jPEGImageEncoder.setJPEGEncodeParam(jPEGEncodeParam);
/* 111 */       jPEGImageEncoder.encode(bufferedImage, jPEGEncodeParam);
/* 112 */       fileOutputStream.close();
/*     */     } catch (Exception exception) {
/* 114 */       return false;
/* 115 */     }  return true;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\encoder\barCodeEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */