package com.idautomation.linear;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;
import java.io.Serializable;

public class BarCode extends Canvas implements Serializable {
  public static final int CODE39 = 0;
  
  public static final int CODE39EXT = 1;
  
  public static final int INTERLEAVED25 = 2;
  
  public static final int CODE11 = 3;
  
  public static final int CODABAR = 4;
  
  public static final int MSI = 5;
  
  public static final int UPCA = 6;
  
  public static final int IND25 = 7;
  
  public static final int MAT25 = 8;
  
  public static final int CODE93 = 9;
  
  public static final int EAN13 = 10;
  
  public static final int EAN8 = 11;
  
  public static final int UPCE = 12;
  
  public static final int CODE128 = 13;
  
  public static final int CODE93EXT = 14;
  
  public static final int POSTNET = 15;
  
  public static final int PLANET = 16;
  
  public static final int UCC128 = 17;
  
  public int barType = 13;
  
  public String code = "123456789012";
  
  private String codeSup = "";
  
  public boolean checkCharacter = true;
  
  public boolean checkCharacterInText = true;
  
  public double postnetHeightTallBar = 0.3D;
  
  public double postnetHeightShortBar = 0.125D;
  
  public double leftMarginCM = 0.3D;
  
  protected static final int d = 1;
  
  public double topMarginCM = 0.2D;
  
  protected int leftMarginPixels = 0;
  
  protected int topMarginPixels = 0;
  
  private int leftGuardBar = 0;
  
  private int centerGuardBarStart = 0;
  
  private int centerGuardBarEnd = 0;
  
  private int rightGuardBar = 0;
  
  private int endOfCode = 0;
  
  private int startSuplement;
  
  private int endSuplement;
  
  private int suplementTopMargin;
  
  public String supplement = "";
  
  public boolean guardBars = true;
  
  public Color backColor = Color.white;
  
  public String codeText = "";
  
  protected int narrowBarPixels = 0;
  
  protected int widthBarPixels = 0;
  
  protected double narrowBarCM = 0.0D;
  
  protected double widthBarCM = 0.0D;
  
  public int resolution = 38;
  
  protected int barHeightPixels = 0;
  
  public double barHeightCM = 1.0D;
  
  public int width = 170;
  
  public int height = 90;
  
  public int pWidth = this.width;
  
  public int pHeight = this.height;
  
  public boolean autoSize = true;
  
  public boolean showText = true;
  
  public Font textFont = new Font("Arial", 0, 11);
  
  public Color fontColor = Color.black;
  
  public Color barColor = Color.black;
  
  private int extraHeight = 0;
  
  public char UPCESytem = '0';
  
  public char CODABARStartChar = 'A';
  
  public char CODABARStopChar = 'B';
  
  public boolean UPCEANSupplement2 = false;
  
  public boolean UPCEANSupplement5 = false;
  
  public char Code128Set = '0';
  
  public double X = 0.03D;
  
  public double N = 2.0D;
  
  public double I = 1.0D;
  
  public double H = 0.45D;
  
  public double L = 0.0D;
  
  public int rotate = 0;
  
  public double supSeparationCM = 0.5D;
  
  public double supHeight = 0.8D;
  
  protected int currentX = 0;
  
  protected int currentY = 0;
  
  protected String[][] set39 = new String[][] { 
      { "0", "nnnwwnwnn" }, { "1", "wnnwnnnnw" }, { "2", "nnwwnnnnw" }, { "3", "wnwwnnnnn" }, { "4", "nnnwwnnnw" }, { "5", "wnnwwnnnn" }, { "6", "nnwwwnnnn" }, { "7", "nnnwnnwnw" }, { "8", "wnnwnnwnn" }, { "9", "nnwwnnwnn" }, 
      { "A", "wnnnnwnnw" }, { "B", "nnwnnwnnw" }, { "C", "wnwnnwnnn" }, { "D", "nnnnwwnnw" }, { "E", "wnnnwwnnn" }, { "F", "nnwnwwnnn" }, { "G", "nnnnnwwnw" }, { "H", "wnnnnwwnn" }, { "I", "nnwnnwwnn" }, { "J", "nnnnwwwnn" }, 
      { "K", "wnnnnnnww" }, { "L", "nnwnnnnww" }, { "M", "wnwnnnnwn" }, { "N", "nnnnwnnww" }, { "O", "wnnnwnnwn" }, { "P", "nnwnwnnwn" }, { "Q", "nnnnnnwww" }, { "R", "wnnnnnwwn" }, { "S", "nnwnnnwwn" }, { "T", "nnnnwnwwn" }, 
      { "U", "wwnnnnnnw" }, { "V", "nwwnnnnnw" }, { "W", "wwwnnnnnn" }, { "X", "nwnnwnnnw" }, { "Y", "wwnnwnnnn" }, { "Z", "nwwnwnnnn" }, { "-", "nwnnnnwnw" }, { ".", "wwnnnnwnn" }, { " ", "nwwnnnwnn" }, { "$", "nwnwnwnnn" }, 
      { "/", "nwnwnnnwn" }, { "+", "nwnnnwnwn" }, { "%", "nnnwnwnwn" }, { "*", "nwnnwnwnn" } };
  
  protected String[][] set25 = new String[][] { { "0", "nnwwn" }, { "1", "wnnnw" }, { "2", "nwnnw" }, { "3", "wwnnn" }, { "4", "nnwnw" }, { "5", "wnwnn" }, { "6", "nwwnn" }, { "7", "nnnww" }, { "8", "wnnwn" }, { "9", "nwnwn" } };
  
  protected String[][] setMSI = new String[][] { { "0", "nwnwnwnw" }, { "1", "nwnwnwwn" }, { "2", "nwnwwnnw" }, { "3", "nwnwwnwn" }, { "4", "nwwnnwnw" }, { "5", "nwwnnwwn" }, { "6", "nwwnwnnw" }, { "7", "nwwnwnwn" }, { "8", "wnnwnwnw" }, { "9", "wnnwnwwn" } };
  
  protected String[][] set11 = new String[][] { 
      { "0", "nnnnw" }, { "1", "wnnnw" }, { "2", "nwnnw" }, { "3", "wwnnn" }, { "4", "nnwnw" }, { "5", "wnwnn" }, { "6", "nwwnn" }, { "7", "nnnww" }, { "8", "wnnwn" }, { "9", "wnnnn" }, 
      { "-", "nnwnn" } };
  
  protected String[][] setCODABAR = new String[][] { 
      { "0", "nnnnnww" }, { "1", "nnnnwwn" }, { "2", "nnnwnnw" }, { "3", "wwnnnnn" }, { "4", "nnwnnwn" }, { "5", "wnnnnwn" }, { "6", "nwnnnnw" }, { "7", "nwnnwnn" }, { "8", "nwwnnnn" }, { "9", "wnnwnnn" }, 
      { "-", "nnnwwnn" }, { "$", "nnwwnnn" }, { ":", "wnnnwnw" }, { "/", "wnwnnnw" }, { ".", "wnwnwnn" }, { "+", "nnwnwnw" }, { "A", "nnwwnwn" }, { "B", "nwnwnnw" }, { "C", "nnnwnww" }, { "D", "nnnwwwn" } };
  
  protected String[][] set93 = new String[][] { 
      { "0", "131112" }, { "1", "111213" }, { "2", "111312" }, { "3", "111411" }, { "4", "121113" }, { "5", "121212" }, { "6", "121311" }, { "7", "111114" }, { "8", "131211" }, { "9", "141111" }, 
      { "A", "211113" }, { "B", "211212" }, { "C", "211311" }, { "D", "221112" }, { "E", "221211" }, { "F", "231111" }, { "G", "112113" }, { "H", "112212" }, { "I", "112311" }, { "J", "122112" }, 
      { "K", "132111" }, { "L", "111123" }, { "M", "111222" }, { "N", "111321" }, { "O", "121122" }, { "P", "131121" }, { "Q", "212112" }, { "R", "212211" }, { "S", "211122" }, { "T", "211221" }, 
      { "U", "221121" }, { "V", "222111" }, { "W", "112122" }, { "X", "112221" }, { "Y", "122121" }, { "Z", "123111" }, { "-", "121131" }, { ".", "311112" }, { " ", "311211" }, { "$", "321111" }, 
      { "/", "112131" }, { "+", "113121" }, { "%", "211131" }, { "_1", "121221" }, { "_2", "312111" }, { "_3", "311121" }, { "_4", "122211" } };
  
  protected String[][] setUPCALeft = new String[][] { { "0", "3211" }, { "1", "2221" }, { "2", "2122" }, { "3", "1411" }, { "4", "1132" }, { "5", "1231" }, { "6", "1114" }, { "7", "1312" }, { "8", "1213" }, { "9", "3112" } };
  
  protected String[][] setUPCARight = new String[][] { { "0", "3211" }, { "1", "2221" }, { "2", "2122" }, { "3", "1411" }, { "4", "1132" }, { "5", "1231" }, { "6", "1114" }, { "7", "1312" }, { "8", "1213" }, { "9", "3112" } };
  
  protected String[][] setUPCEOdd = new String[][] { { "0", "3211" }, { "1", "2221" }, { "2", "2122" }, { "3", "1411" }, { "4", "1132" }, { "5", "1231" }, { "6", "1114" }, { "7", "1312" }, { "8", "1213" }, { "9", "3112" } };
  
  protected String[][] setUPCEEven = new String[][] { { "0", "1123" }, { "1", "1222" }, { "2", "2212" }, { "3", "1141" }, { "4", "2311" }, { "5", "1321" }, { "6", "4111" }, { "7", "2131" }, { "8", "3121" }, { "9", "2113" } };
  
  protected String[] set39Ext = new String[] { 
      "%U", "$A", "$B", "$C", "$D", "$E", "$F", "$G", "$H", "$I", 
      "$J", "$K", "$L", "$M", "$N", "$O", "$P", "$Q", "$R", "$S", 
      "$T", "$U", "$V", "$W", "$X", "$Y", "$Z", "%A", "%B", "%C", 
      "%D", "%E", " ", "/A", "/B", "/C", "/D", "/E", "/F", "/G", 
      "/H", "/I", "/J", "/K", "/L", "-", ".", "/O", "0", "1", 
      "2", "3", "4", "5", "6", "7", "8", "9", "/Z", "%F", 
      "%G", "%H", "%I", "%J", "%V", "A", "B", "C", "D", "E", 
      "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", 
      "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", 
      "Z", "%K", "%L", "%M", "%N", "%O", "%W", "+A", "+B", "+C", 
      "+D", "+E", "+F", "+G", "+H", "+I", "+J", "+K", "+L", "+M", 
      "+N", "+O", "+P", "+Q", "+R", "+S", "+T", "+U", "+V", "+W", 
      "+X", "+Y", "+Z", "%P", "%Q", "%R", "%S", "%T" };
  
  protected String[] set93Ext = new String[] { 
      "_2U", "_1A", "_1B", "_1C", "_1D", "_1E", "_1F", "_1G", "_1H", "_1I", 
      "_1J", "_1K", "_1L", "_1M", "_1N", "_1O", "_1P", "_1Q", "_1R", "_1S", 
      "_1T", "_1U", "_1V", "_1W", "_1X", "_1Y", "_1Z", "_2A", "_2B", "_2C", 
      "_2D", "_2E", " ", "_3A", "_3B", "_3C", "_3D", "_3E", "_3F", "_3G", 
      "_3H", "_3I", "_3J", "_3K", "_3L", "-", ".", "_3O", "0", "1", 
      "2", "3", "4", "5", "6", "7", "8", "9", "_3Z", "_2F", 
      "_2G", "_2H", "_2I", "_2J", "_2V", "A", "B", "C", "D", "E", 
      "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", 
      "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", 
      "Z", "_2K", "_2L", "_2M", "_2N", "_2O", "_2W", "_4A", "_4B", "_4C", 
      "_4D", "_4E", "_4F", "_4G", "_4H", "_4I", "_4J", "_4K", "_4L", "_4M", 
      "_4N", "_4O", "_4P", "_4Q", "_4R", "_4S", "_4T", "_4U", "_4V", "_4W", 
      "_4X", "_4Y", "_4Z", "_2P", "_2Q", "_2R", "_2S", "_2T" };
  
  protected String[] UPCESystem0 = new String[] { "EEEOOO", "EEOEOO", "EEOOEO", "EEOOOE", "EOEEOO", "EOOEEO", "EOOOEE", "EOEOEO", "EOEOOE", "EOOEOE" };
  
  protected String[] UPCESystem1 = new String[] { "OOOEEE", "OOEOEE", "OOEEOE", "OOEEEO", "OEOOEE", "OEEOOE", "OEEEOO", "OEOEOE", "OEOEEO", "OEEOEO" };
  
  protected String[][] setEANLeftA = new String[][] { { "0", "3211" }, { "1", "2221" }, { "2", "2122" }, { "3", "1411" }, { "4", "1132" }, { "5", "1231" }, { "6", "1114" }, { "7", "1312" }, { "8", "1213" }, { "9", "3112" } };
  
  protected String[][] setEANLeftB = new String[][] { { "0", "1123" }, { "1", "1222" }, { "2", "2212" }, { "3", "1141" }, { "4", "2311" }, { "5", "1321" }, { "6", "4111" }, { "7", "2131" }, { "8", "3121" }, { "9", "2113" } };
  
  protected String[][] setEANRight = new String[][] { { "0", "3211" }, { "1", "2221" }, { "2", "2122" }, { "3", "1411" }, { "4", "1132" }, { "5", "1231" }, { "6", "1114" }, { "7", "1312" }, { "8", "1213" }, { "9", "3112" } };
  
  protected String[] setEANCode = new String[] { "AAAAA", "ABABB", "ABBAB", "ABBBA", "BAABB", "BBAAB", "BBBAA", "BABAB", "BABBA", "BBABA" };
  
  protected String[] fiveSuplement = new String[] { "EEOOO", "EOEOO", "EOOEO", "EOOOE", "OEEOO", "OOEEO", "OOOEE", "OEOEO", "OEOOE", "OOEOE" };
  
  protected String[] set128 = new String[] { 
      "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213", 
      "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132", 
      "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211", 
      "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313", 
      "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331", 
      "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111", 
      "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214", 
      "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111", 
      "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141", 
      "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141", 
      "114131", "311141", "411131" };
  
  protected String[] set128B = new String[] { 
      " ", "!", "\"", "#", "$", "%", "&", "'", "(", ")", 
      "*", "+", ",", "-", ".", "/", "0", "1", "2", "3", 
      "4", "5", "6", "7", "8", "9", ":", ";", "<", "=", 
      ">", "?", "@", "A", "B", "C", "D", "E", "F", "G", 
      "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", 
      "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "[", 
      "\\", "]", "^", "_", "`", "a", "b", "c", "d", "e", 
      "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", 
      "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", 
      "z", "{", "|", "}", "~", "Ã", "Ä", "Å", "Æ", "Ç", 
      "È", "É", "Ê" };
  
  protected String[] set128C = new String[] { 
      "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", 
      "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", 
      "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", 
      "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", 
      "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", 
      "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", 
      "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", 
      "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", 
      "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", 
      "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", 
      "ÈÈ", "ÉÉ", "ÊÊ" };
  
  protected String[][] setPOSTNET = new String[][] { { "0", "11000" }, { "1", "00011" }, { "2", "00101" }, { "3", "00110" }, { "4", "01001" }, { "5", "01010" }, { "6", "01100" }, { "7", "10001" }, { "8", "10010" }, { "9", "10100" } };
  
  protected String[][] setPLANET = new String[][] { { "0", "00111" }, { "1", "11100" }, { "2", "11010" }, { "3", "11001" }, { "4", "10110" }, { "5", "10101" }, { "6", "10011" }, { "7", "01110" }, { "8", "01101" }, { "9", "01011" } };
  
  public void setSymbologyID(int paramInt) {
    this.barType = paramInt;
    invalidate();
  }
  
  public int getSymbologyID() {
    return this.barType;
  }
  
  public void setDataToEncode(String paramString) {
    this.code = paramString;
    invalidate();
  }
  
  public String getDataToEncode() {
    return this.code;
  }
  
  public void setCheckCharacter(boolean paramBoolean) {
    this.checkCharacter = paramBoolean;
    invalidate();
  }
  
  public boolean getCheckCharacter() {
    return this.checkCharacter;
  }
  
  public void setCheckCharacterInText(boolean paramBoolean) {
    this.checkCharacterInText = paramBoolean;
    invalidate();
  }
  
  public boolean getCheckCharacterInText() {
    return this.checkCharacterInText;
  }
  
  public void setPostnetHeightTall(double paramDouble) {
    this.postnetHeightTallBar = paramDouble;
    invalidate();
  }
  
  public double getPostnetHeightTall() {
    return this.postnetHeightTallBar;
  }
  
  public void setPostnetHeightShort(double paramDouble) {
    this.postnetHeightShortBar = paramDouble;
    invalidate();
  }
  
  public double getPostnetHeightShort() {
    return this.postnetHeightShortBar;
  }
  
  public void setLeftMarginCM(double paramDouble) {
    this.leftMarginCM = paramDouble;
    invalidate();
  }
  
  public double getLeftMarginCM() {
    return this.leftMarginCM;
  }
  
  public void setTopMarginCM(double paramDouble) {
    this.topMarginCM = paramDouble;
    invalidate();
  }
  
  public double getTopMarginCM() {
    return this.topMarginCM;
  }
  
  public void setSupplementToEncode(String paramString) {
    this.supplement = paramString;
    invalidate();
  }
  
  public String getSupplementToEncode() {
    return this.supplement;
  }
  
  public void setBackground(Color paramColor) {
    this.backColor = paramColor;
    invalidate();
  }
  
  public Color getBackground() {
    return this.backColor;
  }
  
  public void setPixelsPerCM(int paramInt) {
    this.resolution = paramInt;
    invalidate();
  }
  
  public int getPixelsPerCM() {
    return this.resolution;
  }
  
  public void setBarHeightCM(double paramDouble) {
    this.barHeightCM = paramDouble;
    invalidate();
  }
  
  public double getBarHeightCM() {
    return this.barHeightCM;
  }
  
  public void setAutoSize(boolean paramBoolean) {
    this.autoSize = paramBoolean;
    invalidate();
  }
  
  public boolean getAutoSize() {
    return this.autoSize;
  }
  
  public Dimension getPreferredSize() {
    return new Dimension(this.pWidth, this.pHeight);
  }
  
  public Dimension getMinimumSize() {
    return new Dimension(10, 10);
  }
  
  public void setShowText(boolean paramBoolean) {
    this.showText = paramBoolean;
    invalidate();
  }
  
  public boolean getShowText() {
    return this.showText;
  }
  
  public void setFont(Font paramFont) {
    this.textFont = paramFont;
    invalidate();
  }
  
  public Font getFont() {
    return this.textFont;
  }
  
  public void setTextFontColor(Color paramColor) {
    this.fontColor = paramColor;
    invalidate();
  }
  
  public Color getTextFontColor() {
    return this.fontColor;
  }
  
  public void setForeground(Color paramColor) {
    this.barColor = paramColor;
    invalidate();
  }
  
  public Color getForeground() {
    return this.barColor;
  }
  
  public void setUPCESytem(String paramString) {
    if (paramString.equals("0"))
      this.UPCESytem = '0'; 
    if (paramString.equals("1"))
      this.UPCESytem = '1'; 
    invalidate();
  }
  
  public String getUPCESytem() {
    String str = "";
    if (this.UPCESytem == '0')
      str = "0"; 
    if (this.UPCESytem == '1')
      str = "1"; 
    return str;
  }
  
  public void setCODABARStartChar(String paramString) {
    if (paramString.equals("B"))
      this.CODABARStartChar = 'B'; 
    if (paramString.equals("A"))
      this.CODABARStartChar = 'A'; 
    if (paramString.equals("C"))
      this.CODABARStartChar = 'C'; 
    if (paramString.equals("D"))
      this.CODABARStartChar = 'D'; 
    invalidate();
  }
  
  public String getCODABARStartChar() {
    String str = "";
    if (this.CODABARStartChar == 'B')
      str = "B"; 
    if (this.CODABARStartChar == 'A')
      str = "A"; 
    if (this.CODABARStartChar == 'C')
      str = "C"; 
    if (this.CODABARStartChar == 'D')
      str = "D"; 
    return str;
  }
  
  public void setCODABARStopChar(String paramString) {
    if (paramString.equals("B"))
      this.CODABARStopChar = 'B'; 
    if (paramString.equals("A"))
      this.CODABARStopChar = 'A'; 
    if (paramString.equals("C"))
      this.CODABARStopChar = 'C'; 
    if (paramString.equals("D"))
      this.CODABARStopChar = 'D'; 
    invalidate();
  }
  
  public String getCODABARStopChar() {
    String str = "";
    if (this.CODABARStopChar == 'B')
      str = "B"; 
    if (this.CODABARStopChar == 'A')
      str = "A"; 
    if (this.CODABARStopChar == 'C')
      str = "C"; 
    if (this.CODABARStopChar == 'D')
      str = "D"; 
    return str;
  }
  
  public void setUPCEANSupplement2(boolean paramBoolean) {
    this.UPCEANSupplement2 = paramBoolean;
    invalidate();
  }
  
  public boolean getUPCEANSupplement2() {
    return this.UPCEANSupplement2;
  }
  
  public void setUPCEANSupplement5(boolean paramBoolean) {
    this.UPCEANSupplement5 = paramBoolean;
    invalidate();
  }
  
  public boolean getUPCEANSupplement5() {
    return this.UPCEANSupplement5;
  }
  
  public void setCode128Set(String paramString) {
    if (paramString.toUpperCase().equals("B"))
      this.Code128Set = 'B'; 
    if (paramString.toUpperCase().equals("A"))
      this.Code128Set = 'A'; 
    if (paramString.toUpperCase().equals("C"))
      this.Code128Set = 'C'; 
    if (paramString.toUpperCase().equals("AUTO"))
      this.Code128Set = '0'; 
    if (paramString.toUpperCase().equals("0"))
      this.Code128Set = '0'; 
    invalidate();
  }
  
  public String getCode128Set() {
    String str = "";
    if (this.Code128Set == 'B')
      str = "B"; 
    if (this.Code128Set == 'A')
      str = "A"; 
    if (this.Code128Set == 'C')
      str = "C"; 
    if (this.Code128Set == '0')
      str = "0"; 
    return str;
  }
  
  public void setXDimensionCM(double paramDouble) {
    this.X = paramDouble;
    invalidate();
  }
  
  public double getXDimensionCM() {
    return this.X;
  }
  
  public void setNarrowToWideRatio(double paramDouble) {
    this.N = paramDouble;
    invalidate();
  }
  
  public double getNarrowToWideRatio() {
    return this.N;
  }
  
  public void setRotationAngle(int paramInt) {
    this.rotate = paramInt;
    invalidate();
  }
  
  public int getRotationAngle() {
    return this.rotate;
  }
  
  protected void addBar(Graphics paramGraphics, int paramInt1, boolean paramBoolean, int paramInt2) {
    if (paramBoolean) {
      paramGraphics.setColor(this.barColor);
      paramGraphics.fillRect(this.currentX, this.topMarginPixels + paramInt2, paramInt1, this.barHeightPixels + this.extraHeight - paramInt2);
    } 
    this.currentX += paramInt1;
  }
  
  protected void paintPostNetChar(Graphics paramGraphics, String paramString) {
    int i = (int)(this.postnetHeightTallBar * this.resolution);
    int j = (int)(this.postnetHeightShortBar * this.resolution);
    paramGraphics.setColor(this.barColor);
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c == '0')
        paramGraphics.fillRect(this.currentX, this.topMarginPixels, this.narrowBarPixels, j + this.extraHeight); 
      if (c == '1')
        paramGraphics.fillRect(this.currentX, this.topMarginPixels + j - i, this.narrowBarPixels, i + this.extraHeight); 
      this.currentX += this.narrowBarPixels;
      this.currentX += this.widthBarPixels;
    } 
  }
  
  protected void paintPOSTNET(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    String str = this.code;
    paintPostNetChar(paramGraphics, "1");
    for (int k = this.code.length() - 1; k >= 0; k--) {
      String str1 = "" + this.code.charAt(k);
      j += findChar(this.setPOSTNET, str1);
    } 
    int m = (int)mod(j, 10.0D);
    if (m != 0)
      m = 10 - m; 
    if (this.checkCharacter)
      str = str + (new Integer(m)).toString(); 
    for (byte b = 0; b < str.length(); b++) {
      String str1 = "" + str.charAt(b);
      i = findChar(this.setPOSTNET, str1);
      paintPostNetChar(paramGraphics, this.setPOSTNET[i][1]);
    } 
    paintPostNetChar(paramGraphics, "1");
  }
  
  protected int findChar(String[][] paramArrayOfString, String paramString) {
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramString.compareTo(paramArrayOfString[b][0]) == 0)
        return b; 
    } 
    return -1;
  }
  
  protected void paintPLANET(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    String str = this.code;
    paintPostNetChar(paramGraphics, "1");
    for (int k = this.code.length() - 1; k >= 0; k--) {
      String str1 = "" + this.code.charAt(k);
      j += findChar(this.setPLANET, str1);
    } 
    int m = (int)mod(j, 10.0D);
    if (m != 0)
      m = 10 - m; 
    if (this.checkCharacter)
      str = str + (new Integer(m)).toString(); 
    for (byte b = 0; b < str.length(); b++) {
      String str1 = "" + str.charAt(b);
      i = findChar(this.setPLANET, str1);
      paintPostNetChar(paramGraphics, this.setPLANET[i][1]);
    } 
    paintPostNetChar(paramGraphics, "1");
  }
  
  protected void paintInterleaved25(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    boolean bool1 = false;
    String str1 = this.code;
    paintChar(paramGraphics, "bwbw", "nnnn");
    String str2 = "";
    if (mod(this.code.length(), 2.0D) == 0.0D && this.checkCharacter)
      str1 = "0" + this.code; 
    if (mod(this.code.length(), 2.0D) == 1.0D && !this.checkCharacter)
      str1 = "0" + this.code; 
    int k = 0;
    int m = 0;
    boolean bool2 = true;
    for (int n = str1.length() - 1; n >= 0; n--) {
      String str = "" + str1.charAt(n);
      if (bool2) {
        k += findChar(this.set25, str);
      } else {
        m += findChar(this.set25, str);
      } 
      bool2 = !bool2 ? true : false;
    } 
    int i1 = k * 3 + m;
    i1 = (int)mod(i1, 10.0D);
    if (i1 != 0)
      i1 = 10 - i1; 
    if (this.checkCharacter)
      str1 = str1 + (new Integer(i1)).toString(); 
    for (int i2 = 0; i2 < str1.length(); i2 += 2) {
      String str3 = "" + str1.charAt(i2);
      String str4 = "" + str1.charAt(i2 + 1);
      i = findChar(this.set25, str3);
      j = findChar(this.set25, str4);
      for (byte b = 0; b < 5; b++) {
        paintChar(paramGraphics, "b", "" + this.set25[i][1].charAt(b));
        paintChar(paramGraphics, "w", "" + this.set25[j][1].charAt(b));
      } 
    } 
    paintChar(paramGraphics, "bwb", "wnn");
    if (this.checkCharacterInText) {
      this.codeText = str1;
    } else {
      this.codeText = this.code;
    } 
  }
  
  protected void paintIND25(Graphics paramGraphics) {
    int i = 0;
    boolean bool1 = false;
    String str = this.code;
    paintChar(paramGraphics, "bwbwbw", "wwwwnw");
    int j = 0;
    int k = 0;
    boolean bool2 = true;
    for (int m = str.length() - 1; m >= 0; m--) {
      String str1 = "" + str.charAt(m);
      if (bool2) {
        j += findChar(this.set25, str1);
      } else {
        k += findChar(this.set25, str1);
      } 
      bool2 = !bool2 ? true : false;
    } 
    int n = j * 3 + k;
    n = (int)mod(n, 10.0D);
    if (n != 0)
      n = 10 - n; 
    if (this.checkCharacter)
      str = str + (new Integer(n)).toString(); 
    for (byte b = 0; b < str.length(); b++) {
      String str1 = "" + str.charAt(b);
      i = findChar(this.set25, str1);
      if (i >= 0)
        for (byte b1 = 0; b1 < this.set25[i][1].length(); b1++) {
          paintChar(paramGraphics, "b", "" + this.set25[i][1].charAt(b1));
          paintChar(paramGraphics, "w", "w");
        }  
    } 
    paintChar(paramGraphics, "bwbwb", "wwnww");
  }
  
  protected String UPCEANCheck(String paramString) {
    boolean bool = true;
    int i = 0;
    int j = 0;
    int k = 0;
    for (int m = paramString.length() - 1; m >= 0; m--) {
      if (bool) {
        i += (new Integer("" + paramString.charAt(m))).intValue();
      } else {
        j += (new Integer("" + paramString.charAt(m))).intValue();
      } 
      bool = !bool ? true : false;
    } 
    j = i * 3 + j;
    k = (int)mod(j, 10.0D);
    if (k != 0)
      k = 10 - k; 
    return "" + k;
  }
  
  protected void paintUPCA(Graphics paramGraphics) {
    int i = 0;
    boolean bool = false;
    if (this.code.length() < 11)
      return; 
    if (this.code.length() == 13) {
      this.supplement = this.code.substring(11, 13);
      this.UPCEANSupplement2 = true;
    } 
    if (this.code.length() == 14) {
      this.supplement = this.code.substring(12, 14);
      this.UPCEANSupplement2 = true;
    } 
    if (this.code.length() == 16) {
      this.supplement = this.code.substring(11, 16);
      this.UPCEANSupplement5 = true;
    } 
    if (this.code.length() == 17) {
      this.supplement = this.code.substring(12, 17);
      this.UPCEANSupplement5 = true;
    } 
    this.code = this.code.substring(0, 11);
    this.code += UPCEANCheck(this.code);
    paintGuardChar(paramGraphics, "bwb", "nnn", 0);
    this.leftGuardBar = this.currentX;
    for (byte b = 0; b < this.code.length(); b++) {
      String str = "" + this.code.charAt(b);
      i = -1;
      if (b <= 5) {
        i = findChar(this.setUPCALeft, str);
        paintChar(paramGraphics, "wbwb", this.setUPCALeft[i][1]);
      } else {
        i = findChar(this.setUPCARight, str);
        paintChar(paramGraphics, "bwbw", this.setUPCARight[i][1]);
      } 
      if (b == 5) {
        this.centerGuardBarStart = this.currentX;
        paintGuardChar(paramGraphics, "wbwbw", "nnnnn", 0);
        this.centerGuardBarEnd = this.currentX;
      } 
    } 
    this.rightGuardBar = this.currentX;
    paintGuardChar(paramGraphics, "bwb", "nnn", 0);
    this.endOfCode = this.currentX;
    if (this.UPCEANSupplement2) {
      paintSup2(paramGraphics, this.supplement);
    } else if (this.UPCEANSupplement5) {
      paintSup5(paramGraphics, this.supplement);
    } 
  }
  
  protected void paintEAN13(Graphics paramGraphics) {
    int i = 0;
    boolean bool = false;
    if (this.code.length() < 12)
      return; 
    if (this.code.length() == 14) {
      this.supplement = this.code.substring(12, 14);
      this.UPCEANSupplement2 = true;
    } 
    if (this.code.length() == 15) {
      this.supplement = this.code.substring(13, 15);
      this.UPCEANSupplement2 = true;
    } 
    if (this.code.length() == 17) {
      this.supplement = this.code.substring(12, 17);
      this.UPCEANSupplement5 = true;
    } 
    if (this.code.length() == 18) {
      this.supplement = this.code.substring(13, 18);
      this.UPCEANSupplement5 = true;
    } 
    this.code = this.code.substring(0, 12);
    this.code += UPCEANCheck(this.code);
    paintGuardChar(paramGraphics, "bwb", "nnn", 0);
    this.leftGuardBar = this.currentX;
    String str = this.setEANCode[(new Integer("" + this.code.charAt(0))).intValue()];
    i = findChar(this.setEANLeftA, "" + this.code.charAt(1));
    paintChar(paramGraphics, "wbwb", this.setEANLeftA[i][1]);
    for (byte b = 2; b < 12; b++) {
      String str1 = "" + this.code.charAt(b);
      i = -1;
      if (b <= 6) {
        String[][] arrayOfString = this.setEANLeftA;
        if (str.charAt(b - 2) == 'B')
          arrayOfString = this.setEANLeftB; 
        i = findChar(arrayOfString, str1);
        paintChar(paramGraphics, "wbwb", arrayOfString[i][1]);
      } else {
        i = findChar(this.setEANRight, str1);
        paintChar(paramGraphics, "bwbw", this.setEANRight[i][1]);
      } 
      if (b == 6) {
        this.centerGuardBarStart = this.currentX;
        paintGuardChar(paramGraphics, "wbwbw", "nnnnn", 0);
        this.centerGuardBarEnd = this.currentX;
      } 
    } 
    i = findChar(this.setEANRight, "" + this.code.charAt(12));
    paintChar(paramGraphics, "bwbw", this.setEANRight[i][1]);
    this.rightGuardBar = this.currentX;
    paintGuardChar(paramGraphics, "bwb", "nnn", 0);
    this.endOfCode = this.currentX;
    if (this.UPCEANSupplement2) {
      paintSup2(paramGraphics, this.supplement);
    } else if (this.UPCEANSupplement5) {
      paintSup5(paramGraphics, this.supplement);
    } 
  }
  
  private int À(String[] paramArrayOfString, String paramString) {
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramArrayOfString[b].compareTo(paramString) == 0)
        return b; 
    } 
    return -1;
  }
  
  protected void paintCode128(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    String str = this.code;
    this.codeText = this.code;
    char c = Character.MIN_VALUE;
    boolean bool = false;
    int k = 0;
    int m = this.code.length();
    String[] arrayOfString = this.set128B;
    int n = 103;
    if (this.Code128Set != '0') {
      str = "";
      this.codeText = "";
      for (byte b = 1; b <= m; b++) {
        c = this.code.charAt(b - 1);
        if (c < ' ' && c >= '\000') {
          if (this.Code128Set == 'A')
            str = str + (char)(c + 96); 
          if (this.Code128Set == 'B')
            if (this.code.charAt(b) < ' ') {
              str = str + 'É' + (char)(c + 96) + (char)(this.code.charAt(b) + 96) + 'È';
              b++;
            } else {
              str = str + 'É' + (char)(c + 96) + 'È';
            }  
          if (this.Code128Set == 'C')
            if (this.code.charAt(b) < ' ') {
              str = str + 'É' + 'É' + (c + 64) + (this.code.charAt(b) + 64) + "99";
              b++;
            } else {
              str = str + 'É' + 'É' + (c + 64) + "99";
            }  
          if (c == '\r' || c == '\t')
            this.codeText += "  "; 
        } else {
          this.codeText += (char)c;
          str = str + (char)c;
        } 
      } 
    } 
    if (this.Code128Set == '0') {
      arrayOfString = this.set128B;
      this.codeText = "";
      str = "";
      char c1 = 'Ì';
      byte b3 = 66;
      k = this.code.charAt(0);
      if (k < 32)
        c1 = 'Ë'; 
      if (k > 31 && k < 127)
        c1 = 'Ì'; 
      if (m > 3 && k > 47 && k < 58 && this.code.charAt(1) > '/' && this.code.charAt(1) < ':' && this.code.charAt(2) > '/' && this.code.charAt(2) < ':' && this.code.charAt(3) > '/' && this.code.charAt(3) < ':')
        c1 = 'Í'; 
      if (k == 202 || k > 211)
        c1 = 'Í'; 
      if (c1 == 'Ë') {
        b3 = 65;
        n = 103;
        paintChar(paramGraphics, "bwbwbw", "211412");
      } 
      if (c1 == 'Ì') {
        b3 = 66;
        n = 104;
        paintChar(paramGraphics, "bwbwbw", "211214");
      } 
      if (c1 == 'Í') {
        b3 = 67;
        n = 105;
        paintChar(paramGraphics, "bwbwbw", "211232");
      } 
      for (int i1 = 1; i1 <= m; i1++) {
        k = this.code.charAt(i1 - 1);
        if (i1 < m - 1 && (k == 202 || k > 211)) {
          str = str + 'Ê';
        } else if ((i1 <= m - 3 && k > 47 && k < 58 && this.code.charAt(i1) > '/' && this.code.charAt(i1) < ':' && this.code.charAt(i1 + 1) > '/' && this.code.charAt(i1 + 1) < ':' && this.code.charAt(i1 + 2) > '/' && this.code.charAt(i1 + 2) < ':') || (i1 <= m - 1 && k > 47 && k < 58 && this.code.charAt(i1) > '/' && this.code.charAt(i1) < ':' && b3 == 67)) {
          if (b3 != 67) {
            str = str + 'Ç';
            b3 = 67;
          } 
          k = (this.code.charAt(i1 - 1) - 48) * 10 + this.code.charAt(i1) - 48;
          if (k < 95 && k >= 0) {
            str = str + (char)(k + 32);
          } else if (k > 94) {
            str = str + (char)(k + 100);
          } 
          i1++;
        } else if (i1 <= m && (k < 32 || (b3 == 65 && k < 96))) {
          if (b3 != 65) {
            str = str + 'É';
            b3 = 65;
          } 
          if (k < 32) {
            str = str + (char)(k + 96);
          } else if (k > 31) {
            str = str + (char)k;
          } 
        } else if (i1 <= m && k > 31 && k < 127) {
          if (b3 != 66) {
            str = str + 'È';
            b3 = 66;
          } 
          str = str + (char)k;
        } 
      } 
      for (byte b4 = 1; b4 <= m; b4++) {
        k = this.code.charAt(b4 - 1);
        bool = false;
        if (b4 < m - 1 && (k == 202 || k > 211)) {
          k = (this.code.charAt(b4) - 48) * 10 + this.code.charAt(b4 + 1) - 48;
          if (this.code.charAt(b4 - 1) == 'Ô') {
            this.codeText += " (" + this.code.charAt(b4) + this.code.charAt(b4 + 1) + ") ";
            b4 += 2;
            bool = true;
          } else if (b4 < m - 2 && this.code.charAt(b4 - 1) == 'Õ') {
            this.codeText += " (" + this.code.charAt(b4) + this.code.charAt(b4 + 1) + this.code.charAt(b4 + 2) + ") ";
            b4 += 3;
            bool = true;
          } else if (b4 < m - 3 && this.code.charAt(b4 - 1) == 'Ö') {
            this.codeText += " (" + this.code.charAt(b4) + this.code.charAt(b4 + 1) + this.code.charAt(b4 + 2) + this.code.charAt(b4 + 3) + ") ";
            b4 += 4;
            bool = true;
          } else if (b4 < m - 4 && this.code.charAt(b4 - 1) == '×') {
            this.codeText += " (" + this.code.charAt(b4) + this.code.charAt(b4 + 1) + this.code.charAt(b4 + 2) + this.code.charAt(b4 + 3) + this.code.charAt(b4 + 4) + ") ";
            b4 += 5;
            bool = true;
          } else if ((k <= 30 && k >= 0) || (k <= 99 && k >= 90)) {
            this.codeText += " (" + this.code.charAt(b4) + this.code.charAt(b4 + 1) + ") ";
            b4 += 2;
            bool = true;
          } else if (b4 < m - 2 && ((k <= 49 && k >= 40) || (k <= 25 && k >= 23))) {
            this.codeText += " (" + this.code.charAt(b4) + this.code.charAt(b4 + 1) + this.code.charAt(b4 + 2) + ") ";
            b4 += 3;
            bool = true;
          } else if (b4 < m - 3 && ((k <= 81 && k >= 80) || (k <= 34 && k >= 31))) {
            this.codeText += " (" + this.code.charAt(b4) + this.code.charAt(b4 + 1) + this.code.charAt(b4 + 2) + this.code.charAt(b4 + 3) + ") ";
            b4 += 4;
            bool = true;
          } else if (b4 < m - 3 && !bool) {
            this.codeText += " (" + this.code.charAt(b4) + this.code.charAt(b4 + 1) + this.code.charAt(b4 + 2) + this.code.charAt(b4 + 3) + ") ";
            b4 += 4;
          } 
        } else if (this.code.charAt(b4 - 1) < ' ') {
          this.codeText += " ";
        } else if (this.code.charAt(b4 - 1) > '\037' && this.code.charAt(b4 - 1) < '') {
          this.codeText += this.code.charAt(b4 - 1);
        } 
      } 
    } 
    if (this.Code128Set == 'B') {
      arrayOfString = this.set128B;
      n = 104;
    } 
    if (this.Code128Set == 'C') {
      arrayOfString = this.set128C;
      n = 105;
      if (str.length() % 2 == 1) {
        str = "0" + str;
        this.codeText = str;
      } 
    } 
    if (this.Code128Set == 'B')
      paintChar(paramGraphics, "bwbwbw", "211214"); 
    if (this.Code128Set == 'C')
      paintChar(paramGraphics, "bwbwbw", "211232"); 
    if (this.Code128Set == 'A')
      paintChar(paramGraphics, "bwbwbw", "211412"); 
    byte b1 = 1;
    for (byte b2 = 0; b2 < str.length(); b2++) {
      String str1 = "" + str.charAt(b2);
      if (this.Code128Set == 'C') {
        String str2 = "" + str1;
        if (++b2 < str.length())
          str2 = str2 + str.charAt(b2); 
        i = À(this.set128C, str2);
        if (i >= 0) {
          paintChar(paramGraphics, "bwbwbw", this.set128[i]);
          n += i * b1;
        } 
      } else {
        i = À(arrayOfString, str1);
        if (i >= 0) {
          paintChar(paramGraphics, "bwbwbw", this.set128[i]);
          n += i * b1;
        } 
      } 
      b1++;
    } 
    if (this.checkCharacter) {
      j = (int)mod(n, 103.0D);
      paintChar(paramGraphics, "bwbwbw", this.set128[j]);
    } 
    paintChar(paramGraphics, "bwbwbwb", "2331112");
  }
  
  protected void paintUCC128(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    String str = this.code;
    this.codeText = this.code;
    boolean bool = false;
    String[] arrayOfString = this.set128C;
    this.Code128Set = 'C';
    int k = 105;
    if (str.length() % 2 == 1) {
      str = "0" + str;
      this.codeText = str;
    } 
    if (str.charAt(0) != 'Ê' && str.charAt(1) != 'Ê')
      str = "ÊÊ" + str; 
    int m = 0;
    int n = str.length();
    this.codeText = "";
    for (byte b1 = 0; b1 < n; b1++) {
      m = str.charAt(b1);
      if (b1 < n - 3 && str.charAt(b1) == 'Ê' && str.charAt(b1 + 1) == 'Ê') {
        m = (str.charAt(b1 + 2) - 48) * 10 + str.charAt(b1 + 3) - 48;
        if (b1 < n - 5 && ((m <= 81 && m >= 80) || (m <= 34 && m >= 31))) {
          this.codeText += " (" + str.charAt(b1 + 2) + str.charAt(b1 + 3) + str.charAt(b1 + 4) + str.charAt(b1 + 5) + ") ";
          b1 += 5;
        } else if (b1 < n - 4 && ((m <= 49 && m >= 40) || (m <= 25 && m >= 23))) {
          this.codeText += " (" + str.charAt(b1 + 2) + str.charAt(b1 + 3) + str.charAt(b1 + 4) + ") ";
          b1 += 4;
        } else if ((m <= 30 && m >= 0) || (m <= 99 && m >= 90)) {
          this.codeText += " (" + str.charAt(b1 + 2) + str.charAt(b1 + 3) + ") ";
          b1 += 3;
        } 
      } else {
        this.codeText += str.charAt(b1);
      } 
    } 
    paintChar(paramGraphics, "bwbwbw", "211232");
    byte b2 = 1;
    for (byte b3 = 0; b3 < str.length(); b3++) {
      String str1 = "" + str.charAt(b3);
      if (this.Code128Set == 'C') {
        String str2 = "" + str1;
        if (++b3 < str.length())
          str2 = str2 + str.charAt(b3); 
        i = À(this.set128C, str2);
        if (i >= 0) {
          paintChar(paramGraphics, "bwbwbw", this.set128[i]);
          k += i * b2;
        } 
      } else {
        i = À(arrayOfString, str1);
        if (i >= 0) {
          paintChar(paramGraphics, "bwbwbw", this.set128[i]);
          k += i * b2;
        } 
      } 
      b2++;
    } 
    if (this.checkCharacter) {
      j = (int)mod(k, 103.0D);
      paintChar(paramGraphics, "bwbwbw", this.set128[j]);
    } 
    paintChar(paramGraphics, "bwbwbwb", "2331112");
  }
  
  protected void paintEAN8(Graphics paramGraphics) {
    int i = 0;
    boolean bool = false;
    if (this.code.length() < 7)
      return; 
    if (this.code.length() == 7 && this.checkCharacter)
      this.code += UPCEANCheck(this.code); 
    paintGuardChar(paramGraphics, "bwb", "nnn", 0);
    this.leftGuardBar = this.currentX;
    for (byte b = 0; b < 8; b++) {
      String str = "" + this.code.charAt(b);
      i = -1;
      if (b <= 3) {
        i = findChar(this.setEANLeftA, str);
        paintChar(paramGraphics, "wbwb", this.setEANLeftA[i][1]);
      } else {
        i = findChar(this.setEANRight, str);
        paintChar(paramGraphics, "bwbw", this.setEANRight[i][1]);
      } 
      if (b == 3) {
        this.centerGuardBarStart = this.currentX;
        paintGuardChar(paramGraphics, "wbwbw", "nnnnn", 0);
        this.centerGuardBarEnd = this.currentX;
      } 
    } 
    this.rightGuardBar = this.currentX;
    paintGuardChar(paramGraphics, "bwb", "nnn", 0);
    this.endOfCode = this.currentX;
    if (this.UPCEANSupplement2) {
      paintSup2(paramGraphics, this.supplement);
    } else if (this.UPCEANSupplement5) {
      paintSup5(paramGraphics, this.supplement);
    } 
  }
  
  protected void paintUPCE(Graphics paramGraphics) {
    int i = 0;
    boolean bool = false;
    int j = 0;
    String str1 = "";
    if (this.code.length() == 13) {
      this.supplement = this.code.substring(11, 13);
      this.UPCEANSupplement2 = true;
    } 
    if (this.code.length() == 14) {
      this.supplement = this.code.substring(12, 14);
      this.UPCEANSupplement2 = true;
    } 
    if (this.code.length() == 16) {
      this.supplement = this.code.substring(11, 16);
      this.UPCEANSupplement5 = true;
    } 
    if (this.code.length() == 17) {
      this.supplement = this.code.substring(12, 17);
      this.UPCEANSupplement5 = true;
    } 
    if (this.code.length() < 11)
      return; 
    this.code = this.code.substring(0, 11);
    this.code += UPCEANCheck(this.code);
    j = (new Integer("" + this.code.charAt(11))).intValue();
    if (this.code.substring(3, 6).compareTo("000") == 0 || this.code.substring(3, 6).compareTo("100") == 0 || this.code.substring(3, 6).compareTo("200") == 0)
      str1 = this.code.substring(1, 3) + this.code.substring(8, 11) + this.code.charAt(3); 
    if (this.code.substring(3, 6).compareTo("300") == 0 || this.code.substring(3, 6).compareTo("400") == 0 || this.code.substring(3, 6).compareTo("500") == 0 || this.code.substring(3, 6).compareTo("600") == 0 || this.code.substring(3, 6).compareTo("700") == 0 || this.code.substring(3, 6).compareTo("800") == 0 || this.code.substring(3, 6).compareTo("900") == 0)
      str1 = this.code.substring(1, 4) + this.code.substring(9, 11) + "3"; 
    if (this.code.substring(4, 6).compareTo("10") == 0 || this.code.substring(4, 6).compareTo("20") == 0 || this.code.substring(4, 6).compareTo("30") == 0 || this.code.substring(4, 6).compareTo("40") == 0 || this.code.substring(4, 6).compareTo("50") == 0 || this.code.substring(4, 6).compareTo("60") == 0 || this.code.substring(4, 6).compareTo("70") == 0 || this.code.substring(4, 6).compareTo("80") == 0 || this.code.substring(4, 6).compareTo("90") == 0)
      str1 = this.code.substring(1, 5) + this.code.substring(10, 11) + "4"; 
    if (this.code.substring(5, 6).compareTo("0") != 0)
      str1 = this.code.substring(1, 6) + this.code.substring(10, 11); 
    this.codeText = "0" + str1 + j;
    paintGuardChar(paramGraphics, "bwb", "nnn", 0);
    this.leftGuardBar = this.currentX;
    String str2 = this.UPCESystem0[j];
    if (this.UPCESytem == '1')
      str2 = this.UPCESystem1[j]; 
    for (byte b = 0; b < str1.length(); b++) {
      String str = "" + str1.charAt(b);
      i = -1;
      String[][] arrayOfString = this.setUPCEOdd;
      if (str2.charAt(b) == 'E')
        arrayOfString = this.setUPCEEven; 
      i = findChar(arrayOfString, str);
      paintChar(paramGraphics, "wbwb", arrayOfString[i][1]);
    } 
    this.rightGuardBar = this.currentX;
    paintGuardChar(paramGraphics, "wbwbwb", "nnnnnn", 0);
    this.endOfCode = this.currentX;
    if (this.UPCEANSupplement2) {
      paintSup2(paramGraphics, this.supplement);
    } else if (this.UPCEANSupplement5) {
      paintSup5(paramGraphics, this.supplement);
    } 
  }
  
  protected void paintSup2(Graphics paramGraphics, String paramString) {
    boolean bool;
    if (this.supplement.length() > 0)
      paramString = this.supplement; 
    this.suplementTopMargin = (int)(this.barHeightPixels * (1.0D - this.supHeight));
    this.codeSup = paramString;
    if (paramString.length() != 2)
      return; 
    this.currentX = (int)(this.currentX + this.resolution * this.supSeparationCM);
    this.startSuplement = this.currentX;
    try {
      bool = Integer.valueOf(paramString).intValue();
    } catch (Exception exception) {
      bool = false;
    } 
    String str = "OO";
    if (mod(bool, 4.0D) == 1.0D)
      str = "OE"; 
    if (mod(bool, 4.0D) == 2.0D)
      str = "EO"; 
    if (mod(bool, 4.0D) == 3.0D)
      str = "EE"; 
    paintGuardChar(paramGraphics, "bwb", "112", this.suplementTopMargin);
    String[][] arrayOfString = this.setUPCEOdd;
    if (str.charAt(0) == 'E')
      arrayOfString = this.setUPCEEven; 
    int i = findChar(arrayOfString, "" + paramString.charAt(0));
    paintGuardChar(paramGraphics, "wbwb", arrayOfString[i][1], this.suplementTopMargin);
    paintGuardChar(paramGraphics, "wb", "11", this.suplementTopMargin);
    arrayOfString = this.setUPCEOdd;
    if (str.charAt(1) == 'E')
      arrayOfString = this.setUPCEEven; 
    i = findChar(arrayOfString, "" + paramString.charAt(1));
    paintGuardChar(paramGraphics, "wbwb", arrayOfString[i][1], this.suplementTopMargin);
    this.endSuplement = this.currentX;
  }
  
  protected void paintSup5(Graphics paramGraphics, String paramString) {
    if (this.supplement.length() > 0)
      paramString = this.supplement; 
    this.suplementTopMargin = (int)(this.barHeightPixels * (1.0D - this.supHeight));
    this.codeSup = paramString;
    if (paramString.length() != 5)
      return; 
    boolean bool = true;
    int i = 0;
    int j = 0;
    for (int m = paramString.length() - 1; m >= 0; m--) {
      if (bool) {
        i += (new Integer("" + paramString.charAt(m))).intValue();
      } else {
        j += (new Integer("" + paramString.charAt(m))).intValue();
      } 
      bool = !bool ? true : false;
    } 
    j = i * 3 + j * 9;
    String str1 = "" + j;
    int k = (new Integer("" + str1.charAt(str1.length() - 1))).intValue();
    String str2 = this.fiveSuplement[k];
    this.currentX = (int)(this.currentX + this.resolution * this.supSeparationCM);
    this.startSuplement = this.currentX;
    paintGuardChar(paramGraphics, "bwb", "112", this.suplementTopMargin);
    String[][] arrayOfString = null;
    for (byte b = 0; b < 5; b++) {
      arrayOfString = this.setUPCEOdd;
      if (str2.charAt(b) == 'E')
        arrayOfString = this.setUPCEEven; 
      int n = findChar(arrayOfString, "" + paramString.charAt(b));
      paintGuardChar(paramGraphics, "wbwb", arrayOfString[n][1], this.suplementTopMargin);
      if (b < 4)
        paintGuardChar(paramGraphics, "wb", "11", this.suplementTopMargin); 
    } 
    this.endSuplement = this.currentX;
  }
  
  protected void paintMAT25(Graphics paramGraphics) {
    int i = 0;
    boolean bool = false;
    String str = this.code;
    paintChar(paramGraphics, "bwbwbw", "wnnnnn");
    for (byte b = 0; b < str.length(); b++) {
      String str1 = "" + this.code.charAt(b);
      i = findChar(this.set25, str1);
      if (i >= 0)
        paintChar(paramGraphics, "bwbwbw", this.set25[i][1] + "n"); 
    } 
    paintChar(paramGraphics, "bwbwbw", "wnnnnn");
  }
  
  protected void paintCODE39(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    this.code = this.code.toUpperCase();
    paintChar(paramGraphics, "bwbwbwbwb", this.set39[findChar(this.set39, "*")][1]);
    this.currentX += this.narrowBarPixels;
    for (byte b = 0; b < this.code.length(); b++) {
      String str = "" + this.code.charAt(b);
      i = findChar(this.set39, str);
      if (i > -1) {
        j += i;
        paintChar(paramGraphics, "bwbwbwbwb", this.set39[i][1]);
        this.currentX += this.narrowBarPixels;
      } 
    } 
    if (this.checkCharacter) {
      i = (int)mod(j, 43.0D);
      paintChar(paramGraphics, "bwbwbwbwb", this.set39[i][1]);
      this.currentX += this.narrowBarPixels;
      if (this.checkCharacterInText) {
        this.codeText = this.code + "" + this.set39[i][0];
      } else {
        this.codeText = this.code;
      } 
    } 
    paintChar(paramGraphics, "bwbwbwbwb", this.set39[findChar(this.set39, "*")][1]);
  }
  
  protected void paintCODE11(Graphics paramGraphics) {
    int i = 0;
    int m = 0;
    paintChar(paramGraphics, "bwbwbw", "nnwwnn");
    byte b1 = 1;
    m = 0;
    for (int n = this.code.length() - 1; n >= 0; n--) {
      m += findChar(this.set11, "" + this.code.charAt(n)) * b1;
      if (++b1 == 11)
        b1 = 1; 
    } 
    int j = (int)mod(m, 11.0D);
    b1 = 2;
    m = j;
    for (int i1 = this.code.length() - 1; i1 >= 0; i1--) {
      m += findChar(this.set11, "" + this.code.charAt(i1)) * b1;
      if (++b1 == 10)
        b1 = 1; 
    } 
    int k = (int)mod(m, 11.0D);
    for (byte b2 = 0; b2 < this.code.length(); b2++) {
      String str = "" + this.code.charAt(b2);
      i = findChar(this.set11, str);
      if (i > -1)
        paintChar(paramGraphics, "bwbwbw", this.set11[i][1] + "n"); 
    } 
    if (this.checkCharacter) {
      paintChar(paramGraphics, "bwbwbw", this.set11[j][1] + "n");
      if (this.checkCharacterInText) {
        this.codeText = this.code + this.set11[j][0];
      } else {
        this.codeText = this.code;
      } 
      if (this.code.length() > 10) {
        paintChar(paramGraphics, "bwbwbw", this.set11[k][1] + "n");
        if (this.checkCharacterInText) {
          this.codeText += this.set11[k][0];
        } else {
          this.codeText = this.code;
        } 
      } 
    } 
    paintChar(paramGraphics, "bwbwbw", "nnwwnn");
  }
  
  protected void paintCODABAR(Graphics paramGraphics) {
    int i = 0;
    int k = 0;
    paintChar(paramGraphics, "bwbwbwbw", this.setCODABAR[findChar(this.setCODABAR, "" + this.CODABARStartChar)][1] + "n");
    k = findChar(this.setCODABAR, "" + this.CODABARStartChar) + findChar(this.setCODABAR, "" + this.CODABARStopChar);
    for (int m = this.code.length() - 1; m >= 0; m--)
      k += findChar(this.setCODABAR, "" + this.code.charAt(m)); 
    int j = (int)mod(k, 16.0D);
    if (j != 0)
      j = 16 - j; 
    for (byte b = 0; b < this.code.length(); b++) {
      String str = "" + this.code.charAt(b);
      i = findChar(this.setCODABAR, str);
      if (i > -1)
        paintChar(paramGraphics, "bwbwbwbw", this.setCODABAR[i][1] + "n"); 
    } 
    if (this.checkCharacter) {
      if (this.checkCharacterInText) {
        this.codeText = this.code + this.setCODABAR[j][0];
      } else {
        this.codeText = this.code;
      } 
      paintChar(paramGraphics, "bwbwbwbw", this.setCODABAR[j][1] + "n");
    } 
    paintChar(paramGraphics, "bwbwbwb", this.setCODABAR[findChar(this.setCODABAR, "" + this.CODABARStopChar)][1]);
  }
  
  protected void paintMSI(Graphics paramGraphics) {
    int i = 0;
    int k = 0;
    paintChar(paramGraphics, "bw", "wn");
    k = 0;
    String str = "";
    boolean bool = true;
    for (int m = this.code.length() - 1; m >= 0; m--) {
      if (!bool)
        k += findChar(this.setMSI, "" + this.code.charAt(m)); 
      if (bool)
        str = findChar(this.setMSI, "" + this.code.charAt(m)) + str; 
      bool = !bool ? true : false;
    } 
    str = "" + ((new Long(str)).longValue() * 2L);
    for (int n = str.length() - 1; n >= 0; n--)
      k += findChar(this.setMSI, "" + str.charAt(n)); 
    int j = (int)mod(k, 10.0D);
    if (j != 0)
      j = 10 - j; 
    for (byte b = 0; b < this.code.length(); b++) {
      String str1 = "" + this.code.charAt(b);
      i = findChar(this.setMSI, str1);
      if (i > -1)
        paintChar(paramGraphics, "bwbwbwbw", this.setMSI[i][1]); 
    } 
    if (this.checkCharacter) {
      paintChar(paramGraphics, "bwbwbwb", this.setMSI[j][1]);
      if (this.checkCharacterInText) {
        this.codeText = this.code + this.setMSI[j][0];
      } else {
        this.codeText = this.code;
      } 
    } 
    paintChar(paramGraphics, "wbwb", "nnwn");
  }
  
  protected static double mod(double paramDouble1, double paramDouble2) {
    double d1 = paramDouble1 / paramDouble2;
    double d2 = Math.round(d1);
    if (d2 > d1)
      d2--; 
    return paramDouble1 - paramDouble2 * d2;
  }
  
  protected void paintCODE39Ext(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    paintChar(paramGraphics, "bwbwbwbwb", this.set39[findChar(this.set39, "*")][1]);
    this.currentX += this.narrowBarPixels;
    for (byte b1 = 0; b1 < this.code.length(); b1++) {
      byte b = (byte)this.code.charAt(b1);
      if (b <= 128) {
        String str = this.set39Ext[b];
        for (byte b3 = 0; b3 < str.length(); b3++) {
          String str1 = "" + str.charAt(b3);
          i = findChar(this.set39, str1);
          if (i > -1) {
            j += i;
            paintChar(paramGraphics, "bwbwbwbwb", this.set39[i][1]);
            this.currentX += this.narrowBarPixels;
          } 
        } 
      } 
    } 
    this.codeText = "";
    char c = Character.MIN_VALUE;
    for (byte b2 = 1; b2 <= this.code.length(); b2++) {
      c = this.code.charAt(b2 - 1);
      if (c < ' ' && c >= '\000') {
        if (c == '\r' || c == '\t')
          this.codeText += "  "; 
      } else {
        this.codeText += (char)c;
      } 
    } 
    if (this.checkCharacter) {
      i = (int)mod(j, 43.0D);
      paintChar(paramGraphics, "bwbwbwbwb", this.set39[i][1]);
      this.currentX += this.narrowBarPixels;
      if (this.checkCharacterInText)
        this.codeText += "" + this.set39[i][0]; 
    } 
    paintChar(paramGraphics, "bwbwbwbwb", this.set39[findChar(this.set39, "*")][1]);
  }
  
  protected void paintBAR93(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    paintChar(paramGraphics, "bwbwbw", "111141");
    for (byte b1 = 0; b1 < this.code.length(); b1++) {
      String str = "" + this.code.charAt(b1);
      i = findChar(this.set93, str);
      if (i > -1) {
        j += i;
        paintChar(paramGraphics, "bwbwbw", this.set93[i][1]);
      } 
    } 
    byte b2 = 1;
    j = 0;
    for (int n = this.code.length() - 1; n >= 0; n--) {
      j += findChar(this.set93, "" + this.code.charAt(n)) * b2;
      if (++b2 == 21)
        b2 = 1; 
    } 
    m = (int)mod(j, 47.0D);
    b2 = 2;
    j = m;
    for (int i1 = this.code.length() - 1; i1 >= 0; i1--) {
      j += findChar(this.set93, "" + this.code.charAt(i1)) * b2;
      if (++b2 == 16)
        b2 = 1; 
    } 
    k = (int)mod(j, 47.0D);
    if (this.checkCharacter) {
      paintChar(paramGraphics, "bwbwbw", this.set93[m][1]);
      paintChar(paramGraphics, "bwbwbw", this.set93[k][1]);
      if (this.checkCharacterInText) {
        this.codeText = this.code + this.set93[m][0].charAt(0) + this.set93[k][0].charAt(0);
      } else {
        this.codeText = this.code;
      } 
    } 
    paintChar(paramGraphics, "bwbwbwb", "1111411");
  }
  
  protected void paintBAR93Ext(Graphics paramGraphics) {
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    paintChar(paramGraphics, "bwbwbw", "111141");
    for (byte b1 = 0; b1 < this.code.length(); b1++) {
      byte b = (byte)this.code.charAt(b1);
      if (b <= 128) {
        String str1;
        String str2 = this.set93Ext[b];
        if (str2.length() == 3) {
          str1 = "" + str2.charAt(0) + str2.charAt(1);
          i = findChar(this.set93, str1);
          paintChar(paramGraphics, "bwbwbw", this.set93[i][1]);
          str1 = "" + str2.charAt(2);
        } else {
          str1 = "" + str2.charAt(0);
        } 
        i = findChar(this.set93, str1);
        j += i;
        paintChar(paramGraphics, "bwbwbw", this.set93[i][1]);
      } 
    } 
    byte b2 = 1;
    j = 0;
    for (int n = this.code.length() - 1; n >= 0; n--) {
      byte b = (byte)this.code.charAt(n);
      if (b <= 128) {
        String str = this.set93Ext[b];
        if (str.length() == 3) {
          String str1 = "" + str.charAt(0) + str.charAt(1);
          i = findChar(this.set93, str1);
          j += i * (b2 + 1);
          str1 = "" + str.charAt(2);
          i = findChar(this.set93, str1);
          j += i * b2;
          if (++b2 == 21)
            b2 = 1; 
          if (++b2 == 21)
            b2 = 1; 
        } else {
          String str1 = "" + str.charAt(0);
          i = findChar(this.set93, str1);
          j += i * b2;
          if (++b2 == 21)
            b2 = 1; 
        } 
      } 
    } 
    m = (int)mod(j, 47.0D);
    b2 = 2;
    j = m;
    for (int i1 = this.code.length() - 1; i1 >= 0; i1--) {
      byte b = (byte)this.code.charAt(i1);
      if (b <= 128) {
        String str = this.set93Ext[b];
        if (str.length() == 3) {
          String str1 = "" + str.charAt(0) + str.charAt(1);
          i = findChar(this.set93, str1);
          j += i * (b2 + 1);
          str1 = "" + str.charAt(2);
          i = findChar(this.set93, str1);
          j += i * b2;
          if (++b2 == 16)
            b2 = 1; 
          if (++b2 == 16)
            b2 = 1; 
        } else {
          String str1 = "" + str.charAt(0);
          i = findChar(this.set93, str1);
          j += i * b2;
          if (++b2 == 16)
            b2 = 1; 
        } 
      } 
    } 
    k = (int)mod(j, 47.0D);
    if (this.checkCharacter) {
      paintChar(paramGraphics, "bwbwbw", this.set93[m][1]);
      paintChar(paramGraphics, "bwbwbw", this.set93[k][1]);
      if (this.checkCharacterInText) {
        this.codeText = this.code + this.set93[m][0].charAt(0) + this.set93[k][0].charAt(0);
      } else {
        this.codeText = this.code;
      } 
    } 
    paintChar(paramGraphics, "bwbwbwb", "1111411");
  }
  
  protected void paintChar(Graphics paramGraphics, String paramString1, String paramString2) {
    paintChar2(paramGraphics, paramString1, paramString2, 0);
  }
  
  protected void paintChar2(Graphics paramGraphics, String paramString1, String paramString2, int paramInt) {
    for (byte b = 0; b < paramString1.length(); b++) {
      char c1 = paramString1.charAt(b);
      char c2 = paramString2.charAt(b);
      if (c2 == 'n')
        addBar(paramGraphics, this.narrowBarPixels, (c1 == 'b'), paramInt); 
      if (c2 == 'w')
        addBar(paramGraphics, this.widthBarPixels, (c1 == 'b'), paramInt); 
      if (c2 == '1')
        addBar(paramGraphics, this.narrowBarPixels, (c1 == 'b'), paramInt); 
      if (c2 == '2')
        addBar(paramGraphics, this.narrowBarPixels * 2, (c1 == 'b'), paramInt); 
      if (c2 == '3')
        addBar(paramGraphics, this.narrowBarPixels * 3, (c1 == 'b'), paramInt); 
      if (c2 == '4')
        addBar(paramGraphics, this.narrowBarPixels * 4, (c1 == 'b'), paramInt); 
    } 
  }
  
  protected void paintGuardChar(Graphics paramGraphics, String paramString1, String paramString2, int paramInt) {
    if (this.textFont != null && this.guardBars) {
      paramGraphics.setFont(this.textFont);
      this.extraHeight = paramGraphics.getFontMetrics().getHeight();
    } 
    paintChar2(paramGraphics, paramString1, paramString2, paramInt);
    this.extraHeight = 0;
  }
  
  protected void calculateSizes() {
    int i = this.code.length();
    this.narrowBarCM = this.X;
    this.widthBarCM = this.X * this.N;
    if (this.barType == 2) {
      if (mod(i, 2.0D) == 0.0D && this.checkCharacter)
        i++; 
      if (mod(i, 2.0D) == 1.0D && !this.checkCharacter)
        i++; 
      if (this.checkCharacter)
        i++; 
      this.L = (i / 2) * (3.0D + 2.0D * this.N) * this.X + 7.0D * this.X;
    } 
    if (this.barType == 6)
      this.L = (i * 7) * this.X + 11.0D * this.X; 
    if (this.barType == 10)
      this.L = (i * 7) * this.X + 11.0D * this.X; 
    if (this.barType == 11)
      this.L = (i * 7) * this.X + 11.0D * this.X; 
    if (this.barType == 13) {
      if (this.checkCharacter)
        i++; 
      if (this.Code128Set == 'C') {
        this.L = (11 * i + 35) * this.X;
      } else {
        this.L = (5.5D * i + 35.0D) * this.X;
      } 
    } 
    if (this.barType == 12)
      this.L = 56.0D * this.X + 11.0D * this.X; 
    if (this.barType == 7) {
      if (this.checkCharacter)
        i++; 
      this.L = i * (3.0D + 2.0D * this.N) * this.X + 7.0D * this.X;
    } 
    if (this.barType == 8) {
      if (this.checkCharacter)
        i++; 
      this.L = i * (3.0D + 2.0D * this.N) * this.X + 7.0D * this.X;
    } 
    if (this.barType == 5) {
      if (this.checkCharacter)
        i++; 
      this.L = i * (4.0D + 4.0D * this.N) * this.X + (1.0D + this.N) * this.X + (2.0D + this.N) * this.X;
    } 
    if (this.barType == 4) {
      if (this.checkCharacter)
        i++; 
      this.L = (i + 2) * (4.0D + 3.0D * this.N) * this.X;
    } 
    if (this.barType == 3) {
      if (this.checkCharacter || this.code.length() > 10)
        i++; 
      this.L = (i + 2 + 1) * (3.0D + 2.0D * this.N) * this.X;
    } 
    if (this.barType == 15) {
      if (this.checkCharacter)
        i++; 
      this.L = this.X * 10.0D;
    } 
    if (this.barType == 0) {
      if (this.checkCharacter)
        i++; 
      this.L = (i + 2) * (3.0D * this.N + 6.0D) * this.X + (i + 1) * this.I * this.X;
    } 
    if (this.barType == 1) {
      i = 0;
      if (this.checkCharacter)
        i++; 
      for (byte b = 0; b < this.code.length(); b++) {
        byte b1 = (byte)this.code.charAt(b);
        if (b1 <= 128) {
          String str = this.set39Ext[b1];
          i += str.length();
        } 
      } 
      this.L = (i + 2) * (3.0D * this.N + 6.0D) * this.X + (i + 1) * this.I * this.X;
    } 
    if (this.barType == 9 || this.barType == 14) {
      i = 0;
      if (this.checkCharacter)
        i++; 
      for (byte b = 0; b < this.code.length(); b++) {
        byte b1 = (byte)this.code.charAt(b);
        if (b1 <= 128) {
          String str = this.set39Ext[b1];
          if (str.length() == 1) {
            i++;
          } else {
            i += 2;
          } 
        } 
      } 
      this.L = (i + 2) * 9.0D * this.X + (i + 1) * this.I * this.X;
    } 
    if (this.barHeightCM == 0.0D) {
      this.barHeightCM = this.L * this.H;
      if (this.barHeightCM < 0.625D)
        this.barHeightCM = 0.625D; 
    } 
    if (this.barHeightCM != 0.0D)
      this.barHeightPixels = (int)(this.barHeightCM * this.resolution); 
    if (this.narrowBarCM != 0.0D)
      this.narrowBarPixels = (int)(this.narrowBarCM * this.resolution); 
    if (this.widthBarCM != 0.0D)
      this.widthBarPixels = (int)(this.narrowBarPixels * this.N); 
    if (this.narrowBarPixels <= 0)
      this.narrowBarPixels = 1; 
    if (this.widthBarPixels <= 1)
      this.widthBarPixels = 2; 
  }
  
  public void paint(Graphics paramGraphics) {
    Graphics graphics = paramGraphics;
    Image image = null;
    if (this.rotate != 0) {
      String str = System.getProperty("java.version");
      if (str.indexOf("1.0") == 0 || str.indexOf("1.1") == 0) {
        image = createImage((getSize()).width, (getSize()).height);
        graphics = image.getGraphics();
      } else {
        IDAImageCreator iDAImageCreator = new IDAImageCreator();
        image = iDAImageCreator.getImage((getSize()).width, (getSize()).height);
        graphics = iDAImageCreator.getGraphics();
      } 
    } 
    paramGraphics.setColor(this.backColor);
    paramGraphics.fillRect(0, 0, (getSize()).width, (getSize()).height);
    paintBasis(graphics);
    if (this.rotate != 0) {
      int i = this.currentX + this.leftMarginPixels;
      int j = this.currentY + this.topMarginPixels;
      Image image1 = rotate(image, this.rotate, i, j);
      if (image1 == null) {
        paramGraphics.drawImage(image, 0, 0, null);
      } else {
        paramGraphics.drawImage(image1, 0, 0, null);
      } 
    } 
  }
  
  protected void paintBasis(Graphics paramGraphics) {
    this.codeText = "";
    calculateSizes();
    this.topMarginPixels = (int)(this.topMarginCM * this.resolution);
    this.leftMarginPixels = (int)(this.leftMarginCM * this.resolution);
    this.currentX = this.leftMarginPixels;
    paramGraphics.setColor(this.backColor);
    int i = (getSize()).width;
    int j = (getSize()).height;
    int k = i;
    if (j > k)
      k = j; 
    paramGraphics.fillRect(0, 0, k, k);
    this.endOfCode = 0;
    if (this.barType == 3)
      paintCODE11(paramGraphics); 
    if (this.barType == 5)
      paintMSI(paramGraphics); 
    if (this.barType == 4)
      paintCODABAR(paramGraphics); 
    if (this.barType == 0)
      paintCODE39(paramGraphics); 
    if (this.barType == 1)
      paintCODE39Ext(paramGraphics); 
    if (this.barType == 2)
      paintInterleaved25(paramGraphics); 
    if (this.barType == 9)
      paintBAR93(paramGraphics); 
    if (this.barType == 11)
      paintEAN8(paramGraphics); 
    if (this.barType == 10)
      paintEAN13(paramGraphics); 
    if (this.barType == 6)
      paintUPCA(paramGraphics); 
    if (this.barType == 12)
      paintUPCE(paramGraphics); 
    if (this.barType == 13)
      paintCode128(paramGraphics); 
    if (this.barType == 14)
      paintBAR93Ext(paramGraphics); 
    if (this.barType == 7)
      paintIND25(paramGraphics); 
    if (this.barType == 8)
      paintMAT25(paramGraphics); 
    if (this.barType == 15)
      paintPOSTNET(paramGraphics); 
    if (this.barType == 16)
      paintPLANET(paramGraphics); 
    if (this.barType == 17)
      paintUCC128(paramGraphics); 
    if (this.endOfCode == 0)
      this.endOfCode = this.currentX; 
    if (this.codeText.length() == 0)
      this.codeText = this.code; 
    if (this.showText && this.textFont != null) {
      paramGraphics.setFont(this.textFont);
      int m = paramGraphics.getFontMetrics().getHeight();
      if (this.rotate == 0 || this.rotate == 180) {
        this.pHeight = this.barHeightPixels + m + this.topMarginPixels * 2;
        this.pWidth = this.currentX + this.leftMarginPixels + 2;
        if (this.barType == 15 || this.barType == 16)
          this.pHeight = (int)(this.postnetHeightTallBar * this.resolution) + m + 11 + this.topMarginPixels; 
      } else {
        this.pWidth = this.barHeightPixels + m + this.topMarginPixels * 2;
        this.pHeight = this.currentX + this.leftMarginPixels + 2;
        if (this.barType == 15 || this.barType == 16)
          this.pWidth = (int)(this.postnetHeightTallBar * this.resolution) + m + 11 + this.topMarginPixels; 
      } 
    } else if (this.rotate == 0 || this.rotate == 180) {
      this.pHeight = this.barHeightPixels + this.topMarginPixels * 2;
      this.pWidth = this.currentX + this.leftMarginPixels + 2;
      if (this.barType == 15 || this.barType == 16)
        this.pHeight = (int)(this.postnetHeightTallBar * this.resolution) + 1 + this.topMarginPixels; 
    } else {
      this.pWidth = this.barHeightPixels + this.topMarginPixels * 2;
      this.pHeight = this.currentX + this.leftMarginPixels + 2;
      if (this.barType == 15 || this.barType == 16)
        this.pWidth = (int)(this.postnetHeightTallBar * this.resolution) + 1 + this.topMarginPixels; 
    } 
    if (this.autoSize)
      setSize(this.pWidth, this.pHeight); 
    this.currentY = this.barHeightPixels + this.topMarginPixels;
    if (this.showText && this.textFont != null) {
      paramGraphics.setColor(this.fontColor);
      paramGraphics.setFont(this.textFont);
      int m = paramGraphics.getFontMetrics().getHeight();
      int n = paramGraphics.getFontMetrics().stringWidth("X");
      if ((this.UPCEANSupplement2 || this.UPCEANSupplement5) && (this.barType == 11 || this.barType == 6 || this.barType == 12 || this.barType == 10)) {
        int i2 = (this.endSuplement - this.startSuplement - paramGraphics.getFontMetrics().stringWidth(this.codeSup)) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeSup, this.startSuplement + i2, this.topMarginPixels + this.suplementTopMargin - 2);
      } 
      if (this.barType == 15 || this.barType == 16) {
        int i2 = (this.endOfCode - this.leftMarginPixels - paramGraphics.getFontMetrics().stringWidth(this.codeText)) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeText, this.leftMarginPixels + i2, (int)(this.postnetHeightTallBar * this.resolution + m + 1.0D + this.topMarginPixels));
        this.currentY = (int)(this.postnetHeightTallBar * this.resolution) + m + 1 + this.topMarginPixels;
        return;
      } 
      if (this.barType == 10 && this.guardBars && this.codeText.length() >= 13) {
        int i2 = 0;
        paramGraphics.drawString(this.codeText.substring(0, 1), this.leftMarginPixels - n, this.barHeightPixels + m + 1 + this.topMarginPixels);
        i2 = (this.centerGuardBarStart - this.leftGuardBar - paramGraphics.getFontMetrics().stringWidth(this.codeText.substring(1, 7))) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeText.substring(1, 7), this.leftGuardBar + i2, this.barHeightPixels + m + 1 + this.topMarginPixels);
        i2 = (this.rightGuardBar - this.centerGuardBarEnd - paramGraphics.getFontMetrics().stringWidth(this.codeText.substring(7, 13))) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeText.substring(7, 13), this.centerGuardBarEnd + i2, this.barHeightPixels + m + 1 + this.topMarginPixels);
        this.currentY = this.barHeightPixels + m + 1 + this.topMarginPixels;
        return;
      } 
      if (this.barType == 6 && this.guardBars && this.codeText.length() >= 12) {
        int i2 = 0;
        paramGraphics.drawString(this.codeText.substring(0, 1), this.leftMarginPixels - n, this.barHeightPixels + m + 1 + this.topMarginPixels);
        i2 = (this.centerGuardBarStart - this.leftGuardBar - paramGraphics.getFontMetrics().stringWidth(this.codeText.substring(1, 6))) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeText.substring(1, 6), this.leftGuardBar + i2, this.barHeightPixels + m + 1 + this.topMarginPixels);
        i2 = (this.rightGuardBar - this.centerGuardBarEnd - paramGraphics.getFontMetrics().stringWidth(this.codeText.substring(6, 11))) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeText.substring(6, 11), this.centerGuardBarEnd + i2, this.barHeightPixels + m + 1 + this.topMarginPixels);
        paramGraphics.drawString(this.codeText.substring(11, 12), this.endOfCode + 3, this.barHeightPixels + m + 1 + this.topMarginPixels);
        this.currentY = this.barHeightPixels + m + 1 + this.topMarginPixels;
        return;
      } 
      if (this.barType == 11 && this.guardBars && this.codeText.length() >= 8) {
        int i2 = 0;
        i2 = (this.centerGuardBarStart - this.leftGuardBar - paramGraphics.getFontMetrics().stringWidth(this.codeText.substring(0, 4))) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeText.substring(0, 4), this.leftGuardBar + i2, this.barHeightPixels + m + 1 + this.topMarginPixels);
        i2 = (this.rightGuardBar - this.centerGuardBarEnd - paramGraphics.getFontMetrics().stringWidth(this.codeText.substring(4, 8))) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeText.substring(4, 8), this.centerGuardBarEnd + i2, this.barHeightPixels + m + 1 + this.topMarginPixels);
        this.currentY = this.barHeightPixels + m + 1 + this.topMarginPixels;
        return;
      } 
      if (this.barType == 12 && this.guardBars && this.codeText.length() >= 8) {
        int i2 = 0;
        paramGraphics.drawString(this.codeText.substring(0, 1), this.leftMarginPixels - n, this.barHeightPixels + m + 1 + this.topMarginPixels);
        i2 = (this.rightGuardBar + 2 - this.leftGuardBar - paramGraphics.getFontMetrics().stringWidth(this.codeText.substring(1, 7))) / 2;
        if (i2 < 0)
          i2 = 0; 
        paramGraphics.drawString(this.codeText.substring(1, 7), this.leftGuardBar + i2, this.barHeightPixels + m + 1 + this.topMarginPixels);
        paramGraphics.drawString(this.codeText.substring(7, 8), this.endOfCode + 2, this.barHeightPixels + m + 1 + this.topMarginPixels);
        this.currentY = this.barHeightPixels + m + 1 + this.topMarginPixels;
        return;
      } 
      int i1 = (this.endOfCode - this.leftMarginPixels - paramGraphics.getFontMetrics().stringWidth(this.codeText)) / 2;
      if (i1 < 0)
        i1 = 0; 
      paramGraphics.drawString(this.codeText, this.leftMarginPixels + i1, this.barHeightPixels + m + 1 + this.topMarginPixels);
      this.currentY = this.barHeightPixels + m + 1 + this.topMarginPixels;
    } 
  }
  
  protected Image rotate(Image paramImage, int paramInt1, int paramInt2, int paramInt3) {
    int i = paramImage.getWidth(null);
    int j = paramImage.getHeight(null);
    if (paramInt2 > i)
      paramInt2 = i; 
    if (paramInt3 > j)
      paramInt3 = j; 
    int[] arrayOfInt1 = new int[i * j];
    int[] arrayOfInt2 = new int[paramInt2 * paramInt3];
    PixelGrabber pixelGrabber = new PixelGrabber(paramImage, 0, 0, i, j, arrayOfInt1, 0, i);
    try {
      pixelGrabber.grabPixels();
    } catch (InterruptedException interruptedException) {
      System.err.println("interrupted waiting for pixels!");
      return null;
    } 
    if ((pixelGrabber.getStatus() & 0x80) != 0) {
      System.err.println("image fetch aborted or errored");
      return null;
    } 
    if (paramInt1 == 90) {
      for (byte b = 0; b < paramInt2; b++) {
        for (byte b1 = 0; b1 < paramInt3; b1++)
          arrayOfInt2[paramInt3 * (paramInt2 - b + 1) + b1] = arrayOfInt1[b1 * i + b]; 
      } 
      return Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(paramInt3, paramInt2, arrayOfInt2, 0, paramInt3));
    } 
    if (paramInt1 == 180) {
      for (byte b = 0; b < paramInt2; b++) {
        for (byte b1 = 0; b1 < paramInt3; b1++)
          arrayOfInt2[(paramInt3 - b1 + 1) * paramInt2 + paramInt2 - b + 1] = arrayOfInt1[b1 * i + b]; 
      } 
      return Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(paramInt2, paramInt3, arrayOfInt2, 0, paramInt2));
    } 
    if (paramInt1 == 270) {
      for (byte b = 0; b < paramInt2; b++) {
        for (byte b1 = 0; b1 < paramInt3; b1++)
          arrayOfInt2[paramInt3 * b + paramInt3 - b1 + 1] = arrayOfInt1[b1 * i + b]; 
      } 
      return Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(paramInt3, paramInt2, arrayOfInt2, 0, paramInt3));
    } 
    return null;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\barcode-4.10.jar!\com\idautomation\linear\BarCode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */