package javax.xml;

public class XMLConstants {
  public static final String DEFAULT_NS_PREFIX = "";
  
  public static final String XML_NS_PREFIX = "xml";
  
  public static final String XML_NS_URI = "http://www.w3.org/XML/1998/namespace";
  
  public static final String XMLNS_ATTRIBUTE = "xmlns";
  
  public static final String XMLNS_ATTRIBUTE_NS_URI = "http://www.w3.org/2000/xmlns/";
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\XMLConstants.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */