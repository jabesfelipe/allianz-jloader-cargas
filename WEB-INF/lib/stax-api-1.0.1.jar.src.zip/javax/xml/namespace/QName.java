/*     */ package javax.xml.namespace;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QName
/*     */   implements Serializable
/*     */ {
/*     */   private String namespaceURI;
/*     */   private String localPart;
/*     */   private String prefix;
/*     */   
/*     */   public QName(String localPart) {
/*  55 */     this("", localPart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName(String namespaceURI, String localPart) {
/*  70 */     this(namespaceURI, localPart, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName(String namespaceURI, String localPart, String prefix) {
/*  84 */     if (localPart == null) {
/*  85 */       throw new IllegalArgumentException("Local part not allowed to be null");
/*     */     }
/*     */     
/*  88 */     if (namespaceURI == null) {
/*  89 */       namespaceURI = "";
/*     */     }
/*     */     
/*  92 */     if (prefix == null) {
/*  93 */       prefix = "";
/*     */     }
/*     */     
/*  96 */     this.namespaceURI = namespaceURI;
/*  97 */     this.localPart = localPart;
/*  98 */     this.prefix = prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNamespaceURI() {
/* 109 */     return this.namespaceURI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalPart() {
/* 116 */     return this.localPart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/* 129 */     return this.prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     if (this.namespaceURI.equals("")) {
/* 138 */       return this.localPart;
/*     */     }
/*     */     
/* 141 */     return "{" + this.namespaceURI + "}" + this.localPart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName valueOf(String s) {
/* 162 */     if (s == null || s.equals("")) {
/* 163 */       throw new IllegalArgumentException("invalid QName literal");
/*     */     }
/*     */     
/* 166 */     if (s.charAt(0) == '{') {
/*     */       
/* 168 */       int i = s.indexOf('}');
/* 169 */       if (i == -1) {
/* 170 */         throw new IllegalArgumentException("invalid QName literal");
/*     */       }
/* 172 */       if (i == s.length() - 1) {
/* 173 */         throw new IllegalArgumentException("invalid QName literal");
/*     */       }
/* 175 */       return new QName(s.substring(1, i), s.substring(i + 1));
/*     */     } 
/*     */     
/* 178 */     return new QName(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 190 */     return this.namespaceURI.hashCode() ^ this.localPart.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean equals(Object obj) {
/* 212 */     if (obj == null) {
/* 213 */       return false;
/*     */     }
/*     */     
/* 216 */     if (!(obj instanceof QName)) {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     QName qname = (QName)obj;
/*     */     
/* 222 */     return (this.localPart.equals(qname.localPart) && this.namespaceURI.equals(qname.namespaceURI));
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\namespace\QName.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */