package javax.xml.namespace;

import java.util.Iterator;

public interface NamespaceContext {
  String getNamespaceURI(String paramString);
  
  String getPrefix(String paramString);
  
  Iterator getPrefixes(String paramString);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\namespace\NamespaceContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */