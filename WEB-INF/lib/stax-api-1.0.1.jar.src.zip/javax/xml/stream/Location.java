package javax.xml.stream;

public interface Location {
  int getLineNumber();
  
  int getColumnNumber();
  
  int getCharacterOffset();
  
  String getPublicId();
  
  String getSystemId();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\stream\Location.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */