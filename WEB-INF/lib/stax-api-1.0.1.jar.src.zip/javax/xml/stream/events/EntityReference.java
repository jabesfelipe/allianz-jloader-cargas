package javax.xml.stream.events;

public interface EntityReference extends XMLEvent {
  EntityDeclaration getDeclaration();
  
  String getName();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\stream\events\EntityReference.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */