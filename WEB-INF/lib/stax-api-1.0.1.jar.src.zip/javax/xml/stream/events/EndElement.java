package javax.xml.stream.events;

import java.util.Iterator;
import javax.xml.namespace.QName;

public interface EndElement extends XMLEvent {
  QName getName();
  
  Iterator getNamespaces();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\stream\events\EndElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */