package javax.xml.stream.events;

public interface Namespace extends Attribute {
  String getPrefix();
  
  String getNamespaceURI();
  
  boolean isDefaultNamespaceDeclaration();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\stream\events\Namespace.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */