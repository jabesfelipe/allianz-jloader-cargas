package javax.xml.stream.events;

public interface Characters extends XMLEvent {
  String getData();
  
  boolean isWhiteSpace();
  
  boolean isCData();
  
  boolean isIgnorableWhiteSpace();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\stream\events\Characters.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */