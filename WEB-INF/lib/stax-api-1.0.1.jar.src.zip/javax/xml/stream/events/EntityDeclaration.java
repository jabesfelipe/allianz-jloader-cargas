package javax.xml.stream.events;

public interface EntityDeclaration extends XMLEvent {
  String getPublicId();
  
  String getSystemId();
  
  String getName();
  
  String getNotationName();
  
  String getReplacementText();
  
  String getBaseURI();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\stream\events\EntityDeclaration.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */