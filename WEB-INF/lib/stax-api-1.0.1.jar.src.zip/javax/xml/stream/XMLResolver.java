package javax.xml.stream;

public interface XMLResolver {
  Object resolveEntity(String paramString1, String paramString2, String paramString3, String paramString4) throws XMLStreamException;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\stax-api-1.0.1.jar!\javax\xml\stream\XMLResolver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */