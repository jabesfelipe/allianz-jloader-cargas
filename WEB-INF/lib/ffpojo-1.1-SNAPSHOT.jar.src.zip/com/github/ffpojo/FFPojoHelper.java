/*    */ package com.github.ffpojo;
/*    */ 
/*    */ import com.github.ffpojo.container.HybridMetadataContainer;
/*    */ import com.github.ffpojo.container.MetadataContainer;
/*    */ import com.github.ffpojo.exception.FFPojoException;
/*    */ import com.github.ffpojo.exception.MetadataContainerException;
/*    */ import com.github.ffpojo.metadata.RecordDescriptor;
/*    */ import com.github.ffpojo.parser.RecordParser;
/*    */ import com.github.ffpojo.parser.RecordParserFactory;
/*    */ import java.io.File;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FFPojoHelper
/*    */ {
/*    */   private static FFPojoHelper singletonInstance;
/*    */   private MetadataContainer metadataContainer;
/*    */   
/*    */   private FFPojoHelper() throws FFPojoException {
/*    */     try {
/* 23 */       this.metadataContainer = (MetadataContainer)new HybridMetadataContainer();
/* 24 */     } catch (MetadataContainerException e) {
/* 25 */       throw new FFPojoException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static FFPojoHelper getInstance() throws FFPojoException {
/* 30 */     if (singletonInstance == null) {
/* 31 */       singletonInstance = new FFPojoHelper();
/*    */     }
/* 33 */     return singletonInstance;
/*    */   }
/*    */   
/*    */   public <T> List<T> getRecordsFromFile(String fileName, Class<T> recordClazz) throws FFPojoException {
/* 37 */     return getRecordsFromFile(new File(fileName), recordClazz);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> List<T> getRecordsFromFile(File file, Class<T> recordClazz) throws FFPojoException {
/* 42 */     return (new FFPojoFlatFileReaderBuilder()).withFile(file).withRecordClass(recordClazz).read();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> T createFromText(Class<T> recordClazz, String text) throws FFPojoException {
/*    */     try {
/* 50 */       RecordDescriptor recordDescriptor = this.metadataContainer.getRecordDescriptor(recordClazz);
/* 51 */       RecordParser recordParser = RecordParserFactory.createRecordParser(recordDescriptor);
/* 52 */       return (T)recordParser.parseFromText(recordClazz, text);
/* 53 */     } catch (Exception e) {
/* 54 */       throw new FFPojoException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> String parseToText(T record) throws FFPojoException {
/*    */     try {
/* 61 */       RecordDescriptor recordDescriptor = this.metadataContainer.getRecordDescriptor(record.getClass());
/* 62 */       RecordParser recordParser = RecordParserFactory.createRecordParser(recordDescriptor);
/* 63 */       return recordParser.parseToText(record);
/* 64 */     } catch (Exception e) {
/* 65 */       throw new FFPojoException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public RecordParser getRecordParser(Class<?> recordClazz) throws FFPojoException {
/*    */     try {
/* 71 */       RecordDescriptor recordDescriptor = this.metadataContainer.getRecordDescriptor(recordClazz);
/* 72 */       return RecordParserFactory.createRecordParser(recordDescriptor);
/* 73 */     } catch (Exception e) {
/* 74 */       throw new FFPojoException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\FFPojoHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */