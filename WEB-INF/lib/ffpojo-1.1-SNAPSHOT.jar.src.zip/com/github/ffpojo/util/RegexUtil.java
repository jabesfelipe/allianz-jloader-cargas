/*    */ package com.github.ffpojo.util;
/*    */ 
/*    */ public class RegexUtil
/*    */ {
/*    */   public static String escapeRegexMetacharacters(String s) {
/*  6 */     char[] charArray = s.toCharArray();
/*  7 */     StringBuffer sbuf = new StringBuffer();
/*  8 */     for (int i = 0; i < charArray.length; i++) {
/*  9 */       switch (charArray[i]) { case '$': case '(': case ')': case '*': case '+': case '.': case '<': case '>': case '?': case '[': case '\\':
/*    */         case '^':
/*    */         case '{':
/*    */         case '|':
/* 13 */           sbuf.append("\\");
/* 14 */           sbuf.append(charArray[i]);
/*    */           break;
/*    */         default:
/* 17 */           sbuf.append(charArray[i]); break; }
/*    */     
/*    */     } 
/* 20 */     return sbuf.toString();
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpoj\\util\RegexUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */