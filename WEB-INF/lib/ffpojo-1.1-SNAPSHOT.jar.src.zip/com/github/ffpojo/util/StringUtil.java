/*    */ package com.github.ffpojo.util;
/*    */ 
/*    */ public class StringUtil
/*    */ {
/*    */   public static final String EMPTY = "";
/*    */   
/*    */   public enum Direction {
/*  8 */     LEFT,
/*  9 */     RIGHT;
/*    */   }
/*    */   
/*    */   public static String fillToLength(String s, int length, char fillWith, Direction inDirection) {
/* 13 */     if (length < 0) {
/* 14 */       return s;
/*    */     }
/* 16 */     int actualLength = s.length();
/* 17 */     StringBuffer sbuf = new StringBuffer(s);
/* 18 */     if (actualLength < length) {
/* 19 */       StringBuffer sbufDifference = new StringBuffer();
/* 20 */       int difference = length - actualLength;
/* 21 */       for (int i = 0; i < difference; i++) {
/* 22 */         sbufDifference.append(String.valueOf(fillWith));
/*    */       }
/* 24 */       if (inDirection == Direction.LEFT) {
/* 25 */         sbuf = new StringBuffer(sbufDifference);
/* 26 */         sbuf.append(s);
/* 27 */       } else if (inDirection == Direction.RIGHT) {
/* 28 */         sbuf.append(sbufDifference);
/*    */       } 
/*    */     } else {
/* 31 */       sbuf.setLength(length);
/*    */     } 
/* 33 */     return sbuf.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean isNullOrEmpty(String s) {
/* 38 */     return (s == null || s.trim().equals(""));
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpoj\\util\StringUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */