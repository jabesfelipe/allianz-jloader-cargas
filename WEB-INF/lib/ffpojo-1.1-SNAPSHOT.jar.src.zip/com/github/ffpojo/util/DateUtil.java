/*    */ package com.github.ffpojo.util;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class DateUtil
/*    */ {
/*    */   public static Date convertToDate(Calendar dtCalendar) {
/*  9 */     return new Date(dtCalendar.getTimeInMillis());
/*    */   }
/*    */   
/*    */   public static Calendar convertToCalendar(Date date) {
/* 13 */     Calendar dtCalendar = Calendar.getInstance();
/* 14 */     dtCalendar.setTime(date);
/* 15 */     return dtCalendar;
/*    */   }
/*    */   
/*    */   public static Date floorDate(Date date) {
/* 19 */     Calendar dateAsCalendar = convertToCalendar(date);
/* 20 */     dateAsCalendar.set(11, 0);
/* 21 */     dateAsCalendar.set(12, 0);
/* 22 */     dateAsCalendar.set(13, 0);
/* 23 */     dateAsCalendar.set(14, 0);
/* 24 */     return convertToDate(dateAsCalendar);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpoj\\util\DateUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */