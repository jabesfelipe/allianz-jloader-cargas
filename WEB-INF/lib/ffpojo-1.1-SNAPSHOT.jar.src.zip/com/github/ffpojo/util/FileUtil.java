/*    */ package com.github.ffpojo.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.MappedByteBuffer;
/*    */ import java.nio.channels.FileChannel;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class FileUtil
/*    */ {
/*    */   public static List<MappedByteBuffer> mapFileUsingMappedByteBuffers(FileChannel channel, FileChannel.MapMode mode, int pageSize) throws IOException {
/* 13 */     List<MappedByteBuffer> buffers = new ArrayList<MappedByteBuffer>();
/* 14 */     long channelSize = channel.size();
/* 15 */     long mappingStart = 0L;
/* 16 */     int mappingSize = 0; long i;
/* 17 */     for (i = 0L; mappingStart + mappingSize < channelSize; i++) {
/* 18 */       if (channelSize / pageSize == i) {
/* 19 */         mappingSize = (int)(channelSize - i * pageSize);
/*    */       } else {
/* 21 */         mappingSize = pageSize;
/*    */       } 
/* 23 */       mappingStart = i * pageSize;
/* 24 */       MappedByteBuffer pagina = channel.map(mode, mappingStart, mappingSize);
/* 25 */       buffers.add(pagina);
/*    */     } 
/* 27 */     return buffers;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpoj\\util\FileUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */