/*     */ package com.github.ffpojo.util;
/*     */ import com.github.ffpojo.metadata.delimited.annotation.DelimitedRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ReflectUtil {
/*     */   public static boolean isGetter(Method method) {
/*  13 */     if (!method.getName().startsWith("get") && !method.getName().startsWith("is"))
/*  14 */       return false; 
/*  15 */     if (method.getName().equals("getClass"))
/*  16 */       return false; 
/*  17 */     if ((method.getParameterTypes()).length != 0)
/*  18 */       return false; 
/*  19 */     if (void.class.equals(method.getReturnType())) {
/*  20 */       return false;
/*     */     }
/*  22 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isSetter(Method method) {
/*  27 */     if (!method.getName().startsWith("set"))
/*  28 */       return false; 
/*  29 */     if ((method.getParameterTypes()).length != 1) {
/*  30 */       return false;
/*     */     }
/*  32 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getFieldNameFromGetterOrSetter(Method method) {
/*     */     String fieldNamePastelCase;
/*  38 */     if (isGetter(method) && method.getName().startsWith("is")) {
/*  39 */       fieldNamePastelCase = method.getName().substring(2);
/*     */     } else {
/*  41 */       fieldNamePastelCase = method.getName().substring(3);
/*     */     } 
/*  43 */     return pastelCaseToCamelCase(fieldNamePastelCase);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Method getSetterFromGetter(Method method, Class<?>[] parameterTypes, Class<?> clazz) throws SecurityException, NoSuchMethodException {
/*     */     String fieldNamePastelCase;
/*  49 */     if (method.getName().startsWith("is")) {
/*  50 */       fieldNamePastelCase = method.getName().substring(2);
/*     */     } else {
/*  52 */       fieldNamePastelCase = method.getName().substring(3);
/*     */     } 
/*  54 */     return clazz.getMethod("set" + fieldNamePastelCase, parameterTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Method getGetterFromFieldName(String fieldName, Class<?> clazz) throws SecurityException, NoSuchMethodException {
/*  59 */     String getterNameAsDefault = "get" + camelCaseToPastelCase(fieldName);
/*  60 */     String getterNameAsBoolean = "is" + camelCaseToPastelCase(fieldName);
/*  61 */     Method getter = null;
/*     */     try {
/*  63 */       getter = clazz.getMethod(getterNameAsDefault, (Class[])null);
/*  64 */     } catch (NoSuchMethodException e) {
/*  65 */       getter = clazz.getMethod(getterNameAsBoolean, (Class[])null);
/*     */     } 
/*  67 */     return getter;
/*     */   }
/*     */   
/*     */   public static List<Field> getRecursiveFields(Class<?> recordClazz) {
/*  71 */     Set<Field> listaFields = new TreeSet<Field>(new Comparator<Field>() {
/*     */           public int compare(Field o1, Field o2) {
/*  73 */             return o1.getName().compareToIgnoreCase(o2.getName());
/*     */           }
/*     */         });
/*  76 */     Class<?> clazz = recordClazz;
/*  77 */     while (clazz.isAnnotationPresent((Class)PositionalRecord.class) || clazz.isAnnotationPresent((Class)DelimitedRecord.class)) {
/*  78 */       listaFields.addAll(Arrays.asList(clazz.getDeclaredFields()));
/*  79 */       clazz = clazz.getSuperclass();
/*     */     } 
/*  81 */     return new ArrayList<Field>(listaFields);
/*     */   }
/*     */   
/*     */   public static List<Field> getAnnotadedFields(Class<?> recordClazz) {
/*  85 */     List<Field> listaFields = new ArrayList<Field>();
/*  86 */     if (recordClazz.isAnnotationPresent((Class)PositionalRecord.class) || recordClazz.isAnnotationPresent((Class)DelimitedRecord.class)) {
/*  87 */       listaFields.addAll(Arrays.asList(recordClazz.getDeclaredFields()));
/*     */     }
/*  89 */     return listaFields;
/*     */   }
/*     */   
/*     */   public static List<Class<?>> getSuperClassesOf(Class<?> clazz) {
/*  93 */     List<Class<?>> classes = new ArrayList<Class<?>>();
/*  94 */     Class<?> currentClazz = clazz;
/*  95 */     while (currentClazz.getSuperclass() != null) {
/*  96 */       currentClazz = currentClazz.getSuperclass();
/*  97 */       classes.add(currentClazz);
/*     */     } 
/*  99 */     return classes;
/*     */   }
/*     */   
/*     */   public static boolean existMethod(Class<?> clazz, String methodName, Class<?>... parameterTypes) {
/*     */     try {
/* 104 */       clazz.getDeclaredMethod(methodName, new Class[0]);
/* 105 */     } catch (Exception e) {
/* 106 */       return false;
/*     */     } 
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   private static String pastelCaseToCamelCase(String sPastel) {
/* 112 */     char firstChar = sPastel.charAt(0);
/* 113 */     return String.valueOf(Character.toLowerCase(firstChar)) + sPastel.substring(1);
/*     */   }
/*     */   
/*     */   private static String camelCaseToPastelCase(String sCamel) {
/* 117 */     char firstChar = sCamel.charAt(0);
/* 118 */     return String.valueOf(Character.toUpperCase(firstChar)) + sCamel.substring(1);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpoj\\util\ReflectUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */