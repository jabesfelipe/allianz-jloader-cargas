/*    */ package com.github.ffpojo.decorator;
/*    */ 
/*    */ import com.github.ffpojo.FFPojoHelper;
/*    */ import com.github.ffpojo.decorator.util.CollectionDecoratorUtil;
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.extra.ExtendedFieldDecorator;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ public class CollectionDecorator
/*    */   extends ExtendedFieldDecorator<Collection>
/*    */ {
/*    */   private final Class<?> itensCollectionType;
/*    */   private final Class<? extends Collection> collectionToReturn;
/*    */   
/*    */   public CollectionDecorator(Class<?> itensCollectionType, Class<? extends Collection> clazzCollection) {
/* 21 */     this.itensCollectionType = itensCollectionType;
/* 22 */     this.collectionToReturn = clazzCollection;
/*    */   }
/*    */   
/*    */   public String toString(Collection collection) throws FieldDecoratorException {
/* 26 */     StringBuilder sb = new StringBuilder();
/* 27 */     for (Iterator iterator = collection.iterator(); iterator.hasNext(); ) {
/* 28 */       Object object = iterator.next();
/* 29 */       String s = FFPojoHelper.getInstance().parseToText(object);
/* 30 */       sb.append(s);
/*    */     } 
/* 32 */     return sb.toString();
/*    */   }
/*    */   public Collection fromString(String field) throws FieldDecoratorException {
/*    */     Collection<Object> listObjects;
/* 36 */     if (field == null || field.isEmpty()) return null; 
/* 37 */     CollectionDecoratorUtil collectionDecoratorUtil = new CollectionDecoratorUtil(this.itensCollectionType);
/* 38 */     int objectLineSize = collectionDecoratorUtil.objectLineSize();
/* 39 */     int index = 0;
/*    */     
/* 41 */     if (Set.class.isAssignableFrom(this.collectionToReturn)) {
/* 42 */       listObjects = new HashSet();
/*    */     } else {
/* 44 */       listObjects = new ArrayList();
/*    */     } 
/* 46 */     while (index < field.length() - 1) {
/* 47 */       int finalPosition = index + objectLineSize;
/* 48 */       if (finalPosition > field.length() - 1) {
/* 49 */         finalPosition = field.length() - 1;
/*    */       }
/* 51 */       String item = field.substring(index, finalPosition);
/* 52 */       Object o = FFPojoHelper.getInstance().createFromText(this.itensCollectionType, item);
/* 53 */       listObjects.add(o);
/* 54 */       index = finalPosition;
/*    */     } 
/* 56 */     return listObjects;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Class<?>[] getTypesConstructorExtended() {
/* 65 */     return new Class[] { Class.class };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String[] getMethodContainsContstructorValues() {
/* 73 */     return new String[] { "itemType" };
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\CollectionDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */