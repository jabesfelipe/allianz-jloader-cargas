/*    */ package com.github.ffpojo.decorator;
/*    */ 
/*    */ import com.github.ffpojo.decorator.util.FloatPointDecoratorUtil;
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.extra.ExtendedFieldDecorator;
/*    */ 
/*    */ public class InternalDoubleDecorator extends ExtendedFieldDecorator<Double> {
/*    */   private static final int DEFAULT_PRECISION = 2;
/*    */   private final FloatPointDecoratorUtil floatPointDecoratorUtil;
/*    */   
/*    */   public InternalDoubleDecorator() {
/* 12 */     this(2);
/*    */   }
/*    */   
/*    */   public InternalDoubleDecorator(int precision) {
/* 16 */     this.floatPointDecoratorUtil = new FloatPointDecoratorUtil(precision);
/*    */   }
/*    */   
/*    */   public int getPrecision() {
/* 20 */     return this.floatPointDecoratorUtil.getPrecision();
/*    */   }
/*    */   
/*    */   public String toString(Double value) {
/* 24 */     return this.floatPointDecoratorUtil.toString(value.doubleValue());
/*    */   }
/*    */   
/*    */   public Double fromString(String value) {
/* 28 */     return Double.valueOf(this.floatPointDecoratorUtil.fromString(value).doubleValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Class<?>[] getTypesConstructorExtended() {
/* 36 */     return new Class[] { int.class };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String[] getMethodContainsContstructorValues() {
/* 44 */     return new String[] { "precision" };
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\InternalDoubleDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */