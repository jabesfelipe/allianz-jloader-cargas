/*    */ package com.github.ffpojo.decorator;
/*    */ 
/*    */ import com.github.ffpojo.decorator.util.IntegerDecoratorUtil;
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.extra.ExtendedFieldDecorator;
/*    */ 
/*    */ public class InternalLongDecorator
/*    */   extends ExtendedFieldDecorator<Long> {
/*  9 */   private final IntegerDecoratorUtil util = new IntegerDecoratorUtil();
/*    */   
/*    */   public String toString(Long field) throws FieldDecoratorException {
/* 12 */     return this.util.toStringFromLong(field);
/*    */   }
/*    */   
/*    */   public Long fromString(String field) throws FieldDecoratorException {
/* 16 */     return this.util.fromStringToLong(field);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\InternalLongDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */