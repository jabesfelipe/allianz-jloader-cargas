/*   */ package com.github.ffpojo.decorator;
/*   */ 
/*   */ import java.util.List;
/*   */ 
/*   */ public class InternalListDecorator
/*   */   extends CollectionDecorator {
/*   */   public InternalListDecorator(Class<?> itensCollectionType) {
/* 8 */     super(itensCollectionType, (Class)List.class);
/*   */   }
/*   */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\InternalListDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */