/*    */ package com.github.ffpojo.decorator;
/*    */ 
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.extra.ExtendedFieldDecorator;
/*    */ import java.lang.annotation.Annotation;
/*    */ 
/*    */ public class InternalBooleanDecorator
/*    */   extends ExtendedFieldDecorator<Boolean>
/*    */ {
/*    */   private String trueIdentifier;
/*    */   private String falseIdentifier;
/*    */   
/*    */   public InternalBooleanDecorator(String trueItendifier, String falseIdentifier) {
/* 14 */     this.trueIdentifier = trueItendifier;
/* 15 */     this.falseIdentifier = falseIdentifier;
/*    */   }
/*    */   
/*    */   public String toString(Boolean field) throws FieldDecoratorException {
/* 19 */     if (field == null) return null; 
/* 20 */     if (field.booleanValue()) {
/* 21 */       return this.trueIdentifier;
/*    */     }
/* 23 */     return this.falseIdentifier;
/*    */   }
/*    */   
/*    */   public Boolean fromString(String field) throws FieldDecoratorException {
/* 27 */     if (field == null) return null; 
/* 28 */     return Boolean.valueOf(field.trim().equalsIgnoreCase(this.trueIdentifier));
/*    */   }
/*    */   
/*    */   public static Class<?>[] getTypesConstructorExtended() {
/* 32 */     return new Class[] { String.class, String.class };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String[] getMethodContainsContstructorValues() {
/* 40 */     return new String[] { "trueIdentifier", "falseIdentifier" };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Class<? extends Annotation> annotationLinked() {
/* 48 */     return Annotation.class;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\InternalBooleanDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */