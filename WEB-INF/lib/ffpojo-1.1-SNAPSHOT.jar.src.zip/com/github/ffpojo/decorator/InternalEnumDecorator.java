/*    */ package com.github.ffpojo.decorator;
/*    */ 
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.extra.ExtendedFieldDecorator;
/*    */ import com.github.ffpojo.metadata.positional.annotation.EnumerationType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalEnumDecorator
/*    */   extends ExtendedFieldDecorator<Enum<?>>
/*    */ {
/*    */   private EnumerationType enumerationType;
/*    */   private Class<? extends Enum> clazzEnum;
/*    */   
/*    */   public InternalEnumDecorator(EnumerationType enumerationType, Class<? extends Enum> enumeration) {
/* 17 */     this.enumerationType = enumerationType;
/* 18 */     this.clazzEnum = enumeration;
/*    */   }
/*    */   
/*    */   public String toString(Enum field) throws FieldDecoratorException {
/* 22 */     if (field == null) {
/* 23 */       return "";
/*    */     }
/* 25 */     if (this.enumerationType.isString()) {
/* 26 */       return field.name();
/*    */     }
/* 28 */     return String.valueOf(field.ordinal());
/*    */   }
/*    */   
/*    */   public Enum fromString(String field) throws FieldDecoratorException {
/* 32 */     if (field == null || field.trim().isEmpty()) {
/* 33 */       return null;
/*    */     }
/* 35 */     if (this.enumerationType.isString()) {
/* 36 */       return Enum.valueOf((Class)this.clazzEnum, field);
/*    */     }
/* 38 */     return ((Enum[])this.clazzEnum.getEnumConstants())[Integer.valueOf(field).intValue()];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Class<?>[] getTypesConstructorExtended() {
/* 47 */     return new Class[] { EnumerationType.class, Class.class };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String[] getMethodContainsContstructorValues() {
/* 55 */     return new String[] { "enumType", "enumClass" };
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\InternalEnumDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */