/*    */ package com.github.ffpojo.decorator;
/*    */ 
/*    */ import com.github.ffpojo.decorator.util.IntegerDecoratorUtil;
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.extra.ExtendedFieldDecorator;
/*    */ 
/*    */ public class InternalIntegerDecorator
/*    */   extends ExtendedFieldDecorator<Integer> {
/*  9 */   private IntegerDecoratorUtil util = new IntegerDecoratorUtil();
/*    */   
/*    */   public String toString(Integer field) throws FieldDecoratorException {
/* 12 */     return this.util.toStringFromInteger(field);
/*    */   }
/*    */   
/*    */   public Integer fromString(String field) throws FieldDecoratorException {
/* 16 */     return this.util.fromStringToInteger(field);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\InternalIntegerDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */