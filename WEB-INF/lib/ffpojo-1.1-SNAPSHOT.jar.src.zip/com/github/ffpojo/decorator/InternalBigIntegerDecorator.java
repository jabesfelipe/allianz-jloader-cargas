/*    */ package com.github.ffpojo.decorator;
/*    */ 
/*    */ import com.github.ffpojo.decorator.util.IntegerDecoratorUtil;
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.extra.ExtendedFieldDecorator;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class InternalBigIntegerDecorator
/*    */   extends ExtendedFieldDecorator<BigInteger>
/*    */ {
/* 11 */   private final IntegerDecoratorUtil util = new IntegerDecoratorUtil();
/*    */   
/*    */   public String toString(BigInteger field) throws FieldDecoratorException {
/* 14 */     return this.util.toStringFromBigInteger(field);
/*    */   }
/*    */   
/*    */   public BigInteger fromString(String field) throws FieldDecoratorException {
/* 18 */     return this.util.fromStringToBigInteger(field);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\InternalBigIntegerDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */