/*    */ package com.github.ffpojo.decorator.util;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.RoundingMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FloatPointDecoratorUtil
/*    */ {
/*    */   private static final int DEFAULT_PRECISION = 2;
/*    */   private int precision;
/*    */   
/*    */   public FloatPointDecoratorUtil(int precision) {
/* 14 */     this.precision = precision;
/*    */   }
/*    */   
/*    */   public FloatPointDecoratorUtil() {
/* 18 */     this(2);
/*    */   }
/*    */   
/*    */   public String toString(BigDecimal value) {
/* 22 */     return toString(value, this.precision);
/*    */   }
/*    */   
/*    */   public String toString(double value) {
/* 26 */     return toString(value, this.precision);
/*    */   }
/*    */   
/*    */   public String toString(float value) {
/* 30 */     return toString(value, this.precision);
/*    */   }
/*    */   
/*    */   public BigDecimal fromString(String value) {
/* 34 */     return fromString(value, this.precision);
/*    */   }
/*    */   public double doubleFromString(String value) {
/* 37 */     return doubleFromString(value, this.precision);
/*    */   }
/*    */   public float floatFromString(String value) {
/* 40 */     return floatFromString(value, this.precision);
/*    */   }
/*    */   
/*    */   public static String toString(BigDecimal value, int precision) {
/* 44 */     if (value == null) return ""; 
/* 45 */     return value.multiply(getMultiplierFactor(precision)).toString().split("\\.")[0];
/*    */   }
/*    */   
/*    */   public static String toString(double value, int precision) {
/* 49 */     return toString(BigDecimal.valueOf(value), precision);
/*    */   }
/*    */ 
/*    */   
/*    */   public static String toString(float value, int precision) {
/* 54 */     return toString(new BigDecimal(String.valueOf(value)), precision);
/*    */   }
/*    */   
/*    */   public static BigDecimal fromString(String value, int precision) {
/* 58 */     return (new BigDecimal(value)).divide(getMultiplierFactor(precision)).setScale(precision, RoundingMode.CEILING);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static double doubleFromString(String value, int precision) {
/* 65 */     return fromString(value, precision).doubleValue();
/*    */   }
/*    */   
/*    */   public static float floatFromString(String value, int precision) {
/* 69 */     return fromString(value, precision).floatValue();
/*    */   }
/*    */   
/*    */   private static BigDecimal getMultiplierFactor(int precision) {
/* 73 */     return BigDecimal.valueOf(Math.round(Math.pow(10.0D, precision)));
/*    */   }
/*    */   
/*    */   public int getPrecision() {
/* 77 */     return this.precision;
/*    */   }
/*    */   
/*    */   public void setPrecicion(int precision) {
/* 81 */     this.precision = precision;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorato\\util\FloatPointDecoratorUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */