/*     */ package com.github.ffpojo.decorator.util;
/*     */ 
/*     */ import com.github.ffpojo.metadata.positional.annotation.AccessorType;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.BigDecimalPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.BooleanPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.DatePositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.DoublePositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.FloatPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionDecoratorUtil
/*     */ {
/*     */   private Class<?> clazz;
/*     */   private int clazzPositionSize;
/*     */   
/*     */   public CollectionDecoratorUtil(Class<?> clazzPositionalFieldAnnotaded) {
/*  25 */     this.clazz = clazzPositionalFieldAnnotaded;
/*  26 */     readAnnotations(this.clazz);
/*     */   }
/*     */   
/*     */   public int objectLineSize() {
/*  30 */     return this.clazzPositionSize;
/*     */   }
/*     */   
/*     */   private void readAnnotations(Class<?> clazz) {
/*  34 */     AccessorType accessorType = AccessorType.PROPERTY;
/*  35 */     if (clazz.isAnnotationPresent((Class)PositionalRecord.class)) {
/*  36 */       readObjectLineSizeFromField(clazz);
/*  37 */       readObjectLineSizeFromProperties(clazz);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObjectLineSizeFromField(Class<?> clazz) {
/*  43 */     Field[] fields = clazz.getDeclaredFields();
/*  44 */     for (int i = 0; i < fields.length; i++) {
/*  45 */       Field field = fields[i];
/*  46 */       field.setAccessible(true);
/*  47 */       Annotation[] annotations = field.getAnnotations();
/*  48 */       for (int j = 0; j < annotations.length; j++) {
/*  49 */         this.clazzPositionSize = getMoreThanPosition(getFinalPosition(annotations[j]));
/*     */       }
/*     */     } 
/*  52 */     readSuperClassRecursive(clazz);
/*     */   }
/*     */   
/*     */   private void readObjectLineSizeFromProperties(Class<?> clazz) {
/*  56 */     Method[] methods = clazz.getMethods();
/*  57 */     for (int i = 0; i < methods.length; i++) {
/*  58 */       if (methods[i].getName().startsWith("get")) {
/*  59 */         Method method = methods[i];
/*  60 */         getClassPositionSize(method);
/*     */       } 
/*     */     } 
/*  63 */     readSuperClassRecursive(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readSuperClassRecursive(Class<?> clazz) {
/*  68 */     Class<?> superClazz = clazz.getSuperclass();
/*  69 */     if (superClazz != null && superClazz.isAnnotationPresent((Class)PositionalRecord.class)) {
/*  70 */       readAnnotations(superClazz);
/*     */     }
/*     */   }
/*     */   
/*     */   private void getClassPositionSize(Method method) {
/*  75 */     Annotation[] annotations = method.getAnnotations();
/*  76 */     for (int j = 0; j < annotations.length; j++) {
/*  77 */       this.clazzPositionSize = getMoreThanPosition(getFinalPosition(annotations[j]));
/*     */     }
/*     */   }
/*     */   
/*     */   private int getMoreThanPosition(int actualValueAnnotationPosition) {
/*  82 */     return (this.clazzPositionSize < actualValueAnnotationPosition) ? actualValueAnnotationPosition : this.clazzPositionSize;
/*     */   }
/*     */   private int getFinalPosition(Annotation positionalField) {
/*  85 */     IntegerPositionalField.class.isAssignableFrom(positionalField.getClass());
/*  86 */     if (PositionalField.class.isAssignableFrom(positionalField.getClass()))
/*  87 */       return ((PositionalField)positionalField).finalPosition(); 
/*  88 */     if (BigDecimalPositionalField.class.isAssignableFrom(positionalField.getClass()))
/*  89 */       return ((BigDecimalPositionalField)positionalField).finalPosition(); 
/*  90 */     if (BooleanPositionalField.class.isAssignableFrom(positionalField.getClass()))
/*  91 */       return ((BooleanPositionalField)positionalField).finalPosition(); 
/*  92 */     if (DatePositionalField.class.isAssignableFrom(positionalField.getClass()))
/*  93 */       return ((DatePositionalField)positionalField).finalPosition(); 
/*  94 */     if (DoublePositionalField.class.isAssignableFrom(positionalField.getClass()))
/*  95 */       return ((DoublePositionalField)positionalField).finalPosition(); 
/*  96 */     if (FloatPositionalField.class.isAssignableFrom(positionalField.getClass()))
/*  97 */       return ((FloatPositionalField)positionalField).finalPosition(); 
/*  98 */     if (IntegerPositionalField.class.isAssignableFrom(positionalField.getClass()))
/*  99 */       return ((IntegerPositionalField)positionalField).finalPosition(); 
/* 100 */     if (LongPositionalField.class.isAssignableFrom(positionalField.getClass())) {
/* 101 */       return ((LongPositionalField)positionalField).finalPosition();
/*     */     }
/* 103 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorato\\util\CollectionDecoratorUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */