/*    */ package com.github.ffpojo.decorator.util;
/*    */ 
/*    */ import com.github.ffpojo.util.StringUtil;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ public class IntegerDecoratorUtil
/*    */ {
/*    */   private static final String EMPTY_STR = "";
/*    */   
/*    */   public BigInteger fromStringToBigInteger(String text) {
/* 12 */     if (StringUtil.isNullOrEmpty(text)) return null; 
/* 13 */     return new BigInteger(text);
/*    */   }
/*    */   
/*    */   public String toStringFromBigInteger(BigInteger number) {
/* 17 */     if (number == null) {
/* 18 */       return "";
/*    */     }
/* 20 */     return number.toString();
/*    */   }
/*    */   
/*    */   public String toStringFromLong(Long value) {
/* 24 */     if (value == null) return ""; 
/* 25 */     return value.toString();
/*    */   }
/*    */   
/*    */   public Long fromStringToLong(String text) {
/* 29 */     if (StringUtil.isNullOrEmpty(text)) return null; 
/* 30 */     return Long.valueOf(text);
/*    */   }
/*    */   
/*    */   public String toStringFromInteger(Integer value) {
/* 34 */     if (value == null) return ""; 
/* 35 */     return value.toString();
/*    */   }
/*    */   
/*    */   public Integer fromStringToInteger(String text) {
/* 39 */     if (StringUtil.isNullOrEmpty(text)) return null; 
/* 40 */     return Integer.valueOf(text);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorato\\util\IntegerDecoratorUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */