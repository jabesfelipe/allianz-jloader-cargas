/*    */ package com.github.ffpojo.decorator;
/*    */ 
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.extra.ExtendedFieldDecorator;
/*    */ import com.github.ffpojo.util.StringUtil;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class InternalDateDecorator
/*    */   extends ExtendedFieldDecorator<Date>
/*    */ {
/*    */   private static final String DEFAULT_FORMAT = "dd/MM/yyyy";
/*    */   private final SimpleDateFormat sdf;
/*    */   
/*    */   public InternalDateDecorator(String format) {
/* 17 */     this.sdf = new SimpleDateFormat(format);
/*    */   }
/*    */   public InternalDateDecorator() {
/* 20 */     this("dd/MM/yyyy");
/*    */   }
/*    */   
/*    */   public String toString(Date field) throws FieldDecoratorException {
/* 24 */     if (field == null) return null; 
/* 25 */     return this.sdf.format(field);
/*    */   }
/*    */   
/*    */   public Date fromString(String field) throws FieldDecoratorException {
/* 29 */     if (StringUtil.isNullOrEmpty(field)) return null; 
/*    */     try {
/* 31 */       return this.sdf.parse(field);
/* 32 */     } catch (ParseException e) {
/* 33 */       throw new FieldDecoratorException(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Class<?>[] getTypesConstructorExtended() {
/* 38 */     return new Class[] { String.class };
/*    */   }
/*    */   
/*    */   public static String[] getMethodContainsContstructorValues() {
/* 42 */     return new String[] { "dateFormat" };
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\decorator\InternalDateDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */