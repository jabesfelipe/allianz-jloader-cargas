package com.github.ffpojo.dsl;

import java.util.List;

public interface FFReaderBuilder<T> {
  List<T> read();
  
  void read(ReadProcessor paramReadProcessor);
  
  FFPojoRandomReaderBuilder<T> withThreads(int paramInt);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\dsl\FFReaderBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */