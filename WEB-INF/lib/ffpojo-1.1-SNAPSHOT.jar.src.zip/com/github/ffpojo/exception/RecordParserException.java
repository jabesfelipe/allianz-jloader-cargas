/*    */ package com.github.ffpojo.exception;
/*    */ 
/*    */ public class RecordParserException extends FFPojoException {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public RecordParserException(String message) {
/*  7 */     super(message);
/*    */   }
/*    */   
/*    */   public RecordParserException(Throwable cause) {
/* 11 */     super(cause);
/*    */   }
/*    */   
/*    */   public RecordParserException(String message, Throwable cause) {
/* 15 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\exception\RecordParserException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */