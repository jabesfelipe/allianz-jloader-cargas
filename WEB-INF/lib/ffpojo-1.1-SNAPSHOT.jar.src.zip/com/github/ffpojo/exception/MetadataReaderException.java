/*    */ package com.github.ffpojo.exception;
/*    */ 
/*    */ public class MetadataReaderException extends FFPojoException {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public MetadataReaderException(String message) {
/*  7 */     super(message);
/*    */   }
/*    */   
/*    */   public MetadataReaderException(Throwable cause) {
/* 11 */     super(cause);
/*    */   }
/*    */   
/*    */   public MetadataReaderException(String message, Throwable cause) {
/* 15 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\exception\MetadataReaderException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */