/*     */ package com.github.ffpojo.reader;
/*     */ 
/*     */ import com.github.ffpojo.exception.FFPojoException;
/*     */ import com.github.ffpojo.exception.MetadataReaderException;
/*     */ import com.github.ffpojo.metadata.RecordDescriptor;
/*     */ import com.github.ffpojo.metadata.delimited.DelimitedFieldDescriptor;
/*     */ import com.github.ffpojo.metadata.delimited.DelimitedRecordDescriptor;
/*     */ import com.github.ffpojo.metadata.delimited.annotation.DelimitedRecord;
/*     */ import com.github.ffpojo.metadata.extra.FFPojoAnnotationFieldManager;
/*     */ import com.github.ffpojo.metadata.positional.annotation.AccessorType;
/*     */ import com.github.ffpojo.util.ReflectUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DelimitedRecordAnnotationMetadataReader
/*     */   extends AnnotationMetadataReader
/*     */ {
/*  24 */   private final FFPojoAnnotationFieldManager annotationFieldManager = new FFPojoAnnotationFieldManager();
/*     */   
/*     */   public DelimitedRecordAnnotationMetadataReader(Class<?> clazz) {
/*  27 */     super(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public DelimitedRecordDescriptor readMetadata() throws MetadataReaderException {
/*  32 */     DelimitedRecordDescriptor recordDescriptor = getRecordDescriptor();
/*  33 */     recordDescriptor.sortFieldDescriptors();
/*  34 */     recordDescriptor.assertValid();
/*  35 */     return recordDescriptor;
/*     */   }
/*     */   
/*     */   private DelimitedRecordDescriptor getRecordDescriptor() throws MetadataReaderException {
/*  39 */     DelimitedRecord delimitedRecord = this.recordClazz.<DelimitedRecord>getAnnotation(DelimitedRecord.class);
/*  40 */     List<DelimitedFieldDescriptor> fieldDescriptors = readDelimitedFieldDescriptor();
/*  41 */     fieldDescriptors.addAll(readPositionalFieldDescriptorOnProperty());
/*  42 */     return new DelimitedRecordDescriptor(this.recordClazz, fieldDescriptors, delimitedRecord.delimiter());
/*     */   }
/*     */   
/*     */   private List<DelimitedFieldDescriptor> readDelimitedFieldDescriptor() throws MetadataReaderException {
/*  46 */     List<DelimitedFieldDescriptor> fieldDescriptors = new ArrayList<DelimitedFieldDescriptor>();
/*  47 */     List<Field> fields = ReflectUtil.getAnnotadedFields(this.recordClazz);
/*  48 */     for (Field field : fields) {
/*  49 */       readFieldDescriptor(fieldDescriptors, field);
/*     */     }
/*  51 */     return fieldDescriptors;
/*     */   }
/*     */   
/*     */   private void readFieldDescriptor(List<DelimitedFieldDescriptor> fieldDescriptors, Field field) {
/*  55 */     Annotation[] annotations = field.getAnnotations();
/*  56 */     for (Annotation annotation : annotations) {
/*  57 */       if (this.annotationFieldManager.isDelimitedField(annotation.annotationType())) {
/*  58 */         DelimitedFieldDescriptor fieldDescriptor = createDelimitedDescriptor(annotation);
/*  59 */         fieldDescriptor.setAccessorType(AccessorType.FIELD);
/*  60 */         fieldDescriptor.setField(field);
/*  61 */         fieldDescriptors.add(fieldDescriptor);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private DelimitedFieldDescriptor createDelimitedDescriptor(Annotation annotation) {
/*  67 */     DelimitedFieldDescriptor fieldDescriptor = new DelimitedFieldDescriptor();
/*  68 */     Class<?> clazz = annotation.annotationType();
/*     */     try {
/*  70 */       fieldDescriptor.setPositionIndex(((Integer)clazz.getMethod("positionIndex", new Class[0]).invoke(annotation, new Object[0])).intValue());
/*  71 */       fieldDescriptor.setDecorator(this.annotationFieldManager.createNewInstanceDecorator(annotation));
/*  72 */     } catch (Exception e) {
/*  73 */       throw new FFPojoException(e);
/*     */     } 
/*  75 */     return fieldDescriptor;
/*     */   }
/*     */   
/*     */   private List<DelimitedFieldDescriptor> readPositionalFieldDescriptorOnProperty() throws MetadataReaderException {
/*  79 */     List<DelimitedFieldDescriptor> fieldDescriptors = new ArrayList<DelimitedFieldDescriptor>();
/*  80 */     Method[] methods = this.recordClazz.getMethods();
/*  81 */     for (Method method : methods) {
/*  82 */       if (ReflectUtil.isGetter(method)) {
/*  83 */         Annotation[] annotations = method.getAnnotations();
/*  84 */         for (Annotation annotation : annotations) {
/*  85 */           if (this.annotationFieldManager.isDelimitedField(annotation.annotationType())) {
/*     */             try {
/*  87 */               String fieldName = ReflectUtil.getFieldNameFromGetterOrSetter(method);
/*  88 */               Field field = this.recordClazz.getDeclaredField(fieldName);
/*  89 */               if (!this.annotationFieldManager.isFieldAlreadyFFPojoAnnotation(field)) {
/*  90 */                 DelimitedFieldDescriptor fieldDescriptor = createDelimitedDescriptor(annotation);
/*  91 */                 fieldDescriptor.setAccessorType(AccessorType.PROPERTY);
/*  92 */                 fieldDescriptor.setGetter(method);
/*  93 */                 fieldDescriptors.add(fieldDescriptor);
/*     */               } 
/*  95 */             } catch (NoSuchFieldException e) {
/*  96 */               e.printStackTrace();
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 103 */     return fieldDescriptors;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\reader\DelimitedRecordAnnotationMetadataReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */