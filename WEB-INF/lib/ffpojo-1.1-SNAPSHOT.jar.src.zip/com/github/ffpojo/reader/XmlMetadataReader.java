/*     */ package com.github.ffpojo.reader;
/*     */ 
/*     */ import com.github.ffpojo.exception.MetadataReaderException;
/*     */ import com.github.ffpojo.metadata.FieldDecorator;
/*     */ import com.github.ffpojo.metadata.RecordDescriptor;
/*     */ import com.github.ffpojo.metadata.delimited.DelimitedFieldDescriptor;
/*     */ import com.github.ffpojo.metadata.delimited.DelimitedRecordDescriptor;
/*     */ import com.github.ffpojo.metadata.positional.PaddingAlign;
/*     */ import com.github.ffpojo.metadata.positional.PositionalFieldDescriptor;
/*     */ import com.github.ffpojo.metadata.positional.PositionalRecordDescriptor;
/*     */ import com.github.ffpojo.util.ReflectUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ public class XmlMetadataReader
/*     */ {
/*     */   private static final String SCHEMA_CLASSPATH = "ffpojo-ofm.xsd";
/*     */   private static final String ATTRIBUTE_JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
/*     */   private static final String ATTRIBUTE_JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
/*     */   private InputStream xmlMetadataInputStream;
/*     */   
/*     */   private static final class XmlValidationErrorHandler
/*     */     implements ErrorHandler {
/*     */     private XmlValidationErrorHandler() {}
/*     */     
/*     */     public void error(SAXParseException exception) throws SAXException {
/*  40 */       throw exception;
/*     */     }
/*     */     public void fatalError(SAXParseException exception) throws SAXException {
/*  43 */       throw exception;
/*     */     }
/*     */     public void warning(SAXParseException exception) throws SAXException {
/*  46 */       throw exception;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlMetadataReader(InputStream xmlMetadataInputStream) {
/*  53 */     this.xmlMetadataInputStream = xmlMetadataInputStream;
/*     */   }
/*     */   public Map<Class<?>, RecordDescriptor> readMetadata() throws MetadataReaderException {
/*     */     Document doc;
/*  57 */     InputStream schemaFileInputStream = getClass().getClassLoader().getResourceAsStream("ffpojo-ofm.xsd");
/*     */     
/*  59 */     DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
/*  60 */     docBuilderFactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
/*  61 */     docBuilderFactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaSource", schemaFileInputStream);
/*  62 */     docBuilderFactory.setValidating(true);
/*  63 */     docBuilderFactory.setNamespaceAware(true);
/*  64 */     docBuilderFactory.setIgnoringComments(true);
/*  65 */     docBuilderFactory.setCoalescing(true);
/*  66 */     docBuilderFactory.setIgnoringElementContentWhitespace(true);
/*     */ 
/*     */     
/*     */     try {
/*  70 */       DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
/*  71 */       docBuilder.setErrorHandler(new XmlValidationErrorHandler());
/*  72 */       doc = docBuilder.parse(this.xmlMetadataInputStream);
/*  73 */     } catch (ParserConfigurationException e) {
/*  74 */       throw new MetadataReaderException(e);
/*  75 */     } catch (IOException e) {
/*  76 */       throw new MetadataReaderException(e);
/*  77 */     } catch (SAXException e) {
/*  78 */       throw new MetadataReaderException(e);
/*     */     } 
/*     */     
/*  81 */     Node rootNode = doc.getFirstChild();
/*     */     
/*  83 */     return readFFPojoMappingsNode(rootNode);
/*     */   }
/*     */   
/*     */   private Map<Class<?>, RecordDescriptor> readFFPojoMappingsNode(Node node) throws MetadataReaderException {
/*  87 */     Map<Class<?>, RecordDescriptor> recordDescriptorByClazzMap = new HashMap<Class<?>, RecordDescriptor>();
/*  88 */     if (node.hasChildNodes()) {
/*  89 */       NodeList childNodes = node.getChildNodes();
/*  90 */       for (int i = 0; i < childNodes.getLength(); i++) {
/*  91 */         Node childNode = childNodes.item(i);
/*  92 */         if (childNode.getNodeType() == 1) {
/*  93 */           RecordDescriptor recordDescriptor = readFFPojoNode(childNode);
/*  94 */           if (recordDescriptor != null) {
/*  95 */             recordDescriptor.sortFieldDescriptors();
/*  96 */             recordDescriptor.assertValid();
/*  97 */             recordDescriptorByClazzMap.put(recordDescriptor.getRecordClazz(), recordDescriptor);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 102 */     return recordDescriptorByClazzMap;
/*     */   }
/*     */   private RecordDescriptor readFFPojoNode(Node node) throws MetadataReaderException {
/*     */     DelimitedRecordDescriptor delimitedRecordDescriptor;
/* 106 */     RecordDescriptor recordDescriptor = null;
/* 107 */     Class<?> recordClazz = null;
/* 108 */     if (node.hasAttributes()) {
/* 109 */       NamedNodeMap attributes = node.getAttributes();
/* 110 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 111 */         Node attr = attributes.item(i);
/* 112 */         if (attr.getNodeName().equals("class")) {
/* 113 */           String recordClazzName = attr.getNodeValue();
/*     */           try {
/* 115 */             recordClazz = Class.forName(recordClazzName);
/* 116 */           } catch (ClassNotFoundException e) {
/* 117 */             throw new MetadataReaderException("Record class not found on classpath: " + recordClazzName, e);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 122 */     if (node.hasChildNodes()) {
/* 123 */       NodeList childNodes = node.getChildNodes();
/* 124 */       for (int i = 0; i < childNodes.getLength(); i++) {
/* 125 */         Node childNode = childNodes.item(i);
/* 126 */         if (childNode.getNodeType() == 1) {
/* 127 */           if (childNode.getNodeName().equals("positional")) {
/* 128 */             PositionalRecordDescriptor positionalRecordDescriptor = new PositionalRecordDescriptor();
/* 129 */             positionalRecordDescriptor.setRecordClazz(recordClazz);
/* 130 */             readPositionalNode(childNode, positionalRecordDescriptor);
/* 131 */             PositionalRecordDescriptor positionalRecordDescriptor1 = positionalRecordDescriptor;
/* 132 */           } else if (childNode.getNodeName().equals("delimited")) {
/* 133 */             DelimitedRecordDescriptor delimitedRecordDescriptor1 = new DelimitedRecordDescriptor();
/* 134 */             delimitedRecordDescriptor1.setRecordClazz(recordClazz);
/* 135 */             readDelimitedNode(childNode, delimitedRecordDescriptor1);
/* 136 */             delimitedRecordDescriptor = delimitedRecordDescriptor1;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 141 */     return (RecordDescriptor)delimitedRecordDescriptor;
/*     */   }
/*     */   
/*     */   private void readPositionalNode(Node node, PositionalRecordDescriptor recordDescriptorIn) throws MetadataReaderException {
/* 145 */     if (node.hasChildNodes()) {
/* 146 */       NodeList childNodes = node.getChildNodes();
/* 147 */       for (int i = 0; i < childNodes.getLength(); i++) {
/* 148 */         Node childNode = childNodes.item(i);
/* 149 */         if (childNode.getNodeType() == 1) {
/* 150 */           readPositionalFieldNode(childNode, recordDescriptorIn);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readPositionalFieldNode(Node node, PositionalRecordDescriptor recordDescriptorIn) throws MetadataReaderException {
/* 157 */     PositionalFieldDescriptor positionalFieldDescriptor = new PositionalFieldDescriptor();
/* 158 */     if (node.hasAttributes()) {
/* 159 */       NamedNodeMap attributes = node.getAttributes();
/* 160 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 161 */         Node attr = attributes.item(i);
/* 162 */         if (attr.getNodeName().equals("name")) {
/* 163 */           Method getter; String fieldName = attr.getNodeValue();
/*     */           
/*     */           try {
/* 166 */             getter = ReflectUtil.getGetterFromFieldName(fieldName, recordDescriptorIn.getRecordClazz());
/* 167 */           } catch (SecurityException e) {
/* 168 */             throw new MetadataReaderException(e);
/* 169 */           } catch (NoSuchMethodException e) {
/* 170 */             throw new MetadataReaderException("Getter method not found for field name: " + fieldName, e);
/*     */           } 
/* 172 */           positionalFieldDescriptor.setGetter(getter);
/* 173 */         } else if (attr.getNodeName().equals("decorator-class")) {
/* 174 */           FieldDecorator<?> decorator; String decoratorClazzName = attr.getNodeValue();
/*     */           
/*     */           try {
/* 177 */             Object decoratorObj = Class.forName(decoratorClazzName).newInstance();
/* 178 */             if (FieldDecorator.class.isInstance(decoratorObj)) {
/* 179 */               decorator = (FieldDecorator)decoratorObj;
/*     */             } else {
/* 181 */               throw new MetadataReaderException("Decorator class must be a subtype of " + FieldDecorator.class);
/*     */             } 
/* 183 */           } catch (ClassNotFoundException e) {
/* 184 */             throw new MetadataReaderException("Decorator class not found on classpath: " + decoratorClazzName, e);
/* 185 */           } catch (Exception e) {
/* 186 */             throw new MetadataReaderException("Error while instantiating decorator class: " + decoratorClazzName, e);
/*     */           } 
/* 188 */           positionalFieldDescriptor.setDecorator(decorator);
/* 189 */         } else if (attr.getNodeName().equals("initial-position")) {
/* 190 */           int initialPosition = Integer.parseInt(attr.getNodeValue());
/* 191 */           positionalFieldDescriptor.setInitialPosition(initialPosition);
/* 192 */         } else if (attr.getNodeName().equals("final-position")) {
/* 193 */           int finalPosition = Integer.parseInt(attr.getNodeValue());
/* 194 */           positionalFieldDescriptor.setFinalPosition(finalPosition);
/* 195 */         } else if (attr.getNodeName().equals("padding-align")) {
/* 196 */           PaddingAlign paddingAlign = PaddingAlign.valueOf(attr.getNodeValue());
/* 197 */           positionalFieldDescriptor.setPaddingAlign(paddingAlign);
/* 198 */         } else if (attr.getNodeName().equals("padding-character")) {
/* 199 */           String paddingCharacter = attr.getNodeValue();
/* 200 */           positionalFieldDescriptor.setPaddingCharacter(paddingCharacter.charAt(0));
/* 201 */         } else if (attr.getNodeName().equals("trim-on-read")) {
/* 202 */           boolean trimOnRead = Boolean.valueOf(attr.getNodeValue()).booleanValue();
/* 203 */           positionalFieldDescriptor.setTrimOnRead(trimOnRead);
/*     */         } 
/*     */       } 
/*     */     } 
/* 207 */     recordDescriptorIn.getFieldDescriptors().add(positionalFieldDescriptor);
/*     */   }
/*     */   
/*     */   private void readDelimitedNode(Node node, DelimitedRecordDescriptor recordDescriptorIn) throws MetadataReaderException {
/* 211 */     if (node.hasAttributes()) {
/* 212 */       NamedNodeMap attributes = node.getAttributes();
/* 213 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 214 */         Node attr = attributes.item(i);
/* 215 */         if (attr.getNodeName().equals("delimiter")) {
/* 216 */           String delimiter = attr.getNodeValue();
/* 217 */           recordDescriptorIn.setDelimiter(delimiter);
/*     */         } 
/*     */       } 
/*     */     } 
/* 221 */     if (node.hasChildNodes()) {
/* 222 */       NodeList childNodes = node.getChildNodes();
/* 223 */       for (int i = 0; i < childNodes.getLength(); i++) {
/* 224 */         Node childNode = childNodes.item(i);
/* 225 */         if (childNode.getNodeType() == 1) {
/* 226 */           readDelimitedFieldNode(childNode, recordDescriptorIn);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readDelimitedFieldNode(Node node, DelimitedRecordDescriptor recordDescriptorIn) throws MetadataReaderException {
/* 233 */     DelimitedFieldDescriptor delimitedFieldDescriptor = new DelimitedFieldDescriptor();
/* 234 */     if (node.hasAttributes()) {
/* 235 */       NamedNodeMap attributes = node.getAttributes();
/* 236 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 237 */         Node attr = attributes.item(i);
/* 238 */         if (attr.getNodeName().equals("name")) {
/* 239 */           Method getter; String fieldName = attr.getNodeValue();
/*     */           
/*     */           try {
/* 242 */             getter = ReflectUtil.getGetterFromFieldName(fieldName, recordDescriptorIn.getRecordClazz());
/* 243 */           } catch (SecurityException e) {
/* 244 */             throw new MetadataReaderException(e);
/* 245 */           } catch (NoSuchMethodException e) {
/* 246 */             throw new MetadataReaderException("Getter method not found for field name: " + fieldName, e);
/*     */           } 
/* 248 */           delimitedFieldDescriptor.setGetter(getter);
/* 249 */         } else if (attr.getNodeName().equals("decorator-class")) {
/* 250 */           FieldDecorator<?> decorator; String decoratorClazzName = attr.getNodeValue();
/*     */           
/*     */           try {
/* 253 */             Object decoratorObj = Class.forName(decoratorClazzName).newInstance();
/* 254 */             if (FieldDecorator.class.isInstance(decoratorObj)) {
/* 255 */               decorator = (FieldDecorator)decoratorObj;
/*     */             } else {
/* 257 */               throw new MetadataReaderException("Decorator class must be a subtype of " + FieldDecorator.class);
/*     */             } 
/* 259 */           } catch (ClassNotFoundException e) {
/* 260 */             throw new MetadataReaderException("Decorator class not found on classpath: " + decoratorClazzName, e);
/* 261 */           } catch (Exception e) {
/* 262 */             throw new MetadataReaderException("Error while instantiating decorator class: " + decoratorClazzName, e);
/*     */           } 
/* 264 */           delimitedFieldDescriptor.setDecorator(decorator);
/* 265 */         } else if (attr.getNodeName().equals("position-index")) {
/* 266 */           int positionIndex = Integer.parseInt(attr.getNodeValue());
/* 267 */           delimitedFieldDescriptor.setPositionIndex(positionIndex);
/*     */         } 
/*     */       } 
/*     */     } 
/* 271 */     recordDescriptorIn.getFieldDescriptors().add(delimitedFieldDescriptor);
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\reader\XmlMetadataReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */