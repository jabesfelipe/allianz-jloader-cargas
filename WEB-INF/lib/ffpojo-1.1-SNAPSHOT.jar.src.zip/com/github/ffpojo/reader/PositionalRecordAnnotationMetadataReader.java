/*     */ package com.github.ffpojo.reader;
/*     */ 
/*     */ import com.github.ffpojo.exception.FFPojoException;
/*     */ import com.github.ffpojo.exception.MetadataReaderException;
/*     */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*     */ import com.github.ffpojo.metadata.FieldDecorator;
/*     */ import com.github.ffpojo.metadata.RecordDescriptor;
/*     */ import com.github.ffpojo.metadata.extra.FFPojoAnnotationFieldManager;
/*     */ import com.github.ffpojo.metadata.positional.PaddingAlign;
/*     */ import com.github.ffpojo.metadata.positional.PositionalFieldDescriptor;
/*     */ import com.github.ffpojo.metadata.positional.PositionalRecordDescriptor;
/*     */ import com.github.ffpojo.metadata.positional.annotation.AccessorType;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.util.ReflectUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ class PositionalRecordAnnotationMetadataReader
/*     */   extends AnnotationMetadataReader
/*     */ {
/*  28 */   private FFPojoAnnotationFieldManager annotationFieldManager = new FFPojoAnnotationFieldManager();
/*     */   public PositionalRecordAnnotationMetadataReader(Class<?> clazz) {
/*  30 */     super(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PositionalRecordDescriptor readMetadata() throws MetadataReaderException {
/*  36 */     PositionalRecordDescriptor recordDescriptor = getRecordDescriptor();
/*  37 */     recordDescriptor.assertValid();
/*  38 */     recordDescriptor.setIgnorePositionNotFound(((PositionalRecord)this.recordClazz.<PositionalRecord>getAnnotation(PositionalRecord.class)).ignorePositionNotFound());
/*  39 */     recordDescriptor.sortFieldDescriptors();
/*  40 */     return recordDescriptor;
/*     */   }
/*     */   
/*     */   private PositionalRecordDescriptor getRecordDescriptor() throws MetadataReaderException {
/*  44 */     Set<PositionalFieldDescriptor> fieldDescriptors = readPositionalFieldDescriptor();
/*  45 */     fieldDescriptors.addAll(readPositionalFieldDescriptorOnProperty());
/*  46 */     return new PositionalRecordDescriptor(this.recordClazz, new ArrayList<PositionalFieldDescriptor>(fieldDescriptors));
/*     */   }
/*     */   
/*     */   private Set<PositionalFieldDescriptor> readPositionalFieldDescriptor() throws MetadataReaderException {
/*  50 */     Set<PositionalFieldDescriptor> fieldDescriptors = new HashSet<PositionalFieldDescriptor>();
/*  51 */     List<Field> fields = ReflectUtil.getRecursiveFields(this.recordClazz);
/*  52 */     for (Field field : fields) {
/*  53 */       readFieldDescriptor(fieldDescriptors, field);
/*     */     }
/*  55 */     return fieldDescriptors;
/*     */   }
/*     */   
/*     */   private void readFieldDescriptor(Set<PositionalFieldDescriptor> fieldDescriptors, Field field) {
/*  59 */     Annotation[] annotations = field.getAnnotations();
/*  60 */     for (Annotation annotation : annotations) {
/*  61 */       if (this.annotationFieldManager.isPositionalField(annotation.annotationType())) {
/*  62 */         PositionalFieldDescriptor fieldDescriptor = createPositionalDescriptor(annotation);
/*  63 */         fieldDescriptor.setAccessorType(AccessorType.FIELD);
/*  64 */         fieldDescriptor.setField(field);
/*  65 */         fieldDescriptors.add(fieldDescriptor);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<PositionalFieldDescriptor> readPositionalFieldDescriptorOnProperty() throws MetadataReaderException {
/*  71 */     List<PositionalFieldDescriptor> fieldDescriptors = new ArrayList<PositionalFieldDescriptor>();
/*  72 */     Method[] methods = this.recordClazz.getMethods();
/*  73 */     for (Method method : methods) {
/*  74 */       if (ReflectUtil.isGetter(method)) {
/*  75 */         Annotation[] annotations = method.getAnnotations();
/*  76 */         for (Annotation annotation : annotations) {
/*  77 */           if (this.annotationFieldManager.isPositionalField(annotation.annotationType())) {
/*     */             try {
/*  79 */               String fieldName = ReflectUtil.getFieldNameFromGetterOrSetter(method);
/*  80 */               Field field = this.recordClazz.getDeclaredField(fieldName);
/*  81 */               if (!this.annotationFieldManager.isFieldAlreadyFFPojoAnnotation(field)) {
/*  82 */                 PositionalFieldDescriptor fieldDescriptor = createPositionalDescriptor(annotation);
/*  83 */                 fieldDescriptor.setAccessorType(AccessorType.PROPERTY);
/*  84 */                 fieldDescriptor.setGetter(method);
/*  85 */                 fieldDescriptors.add(fieldDescriptor);
/*     */               } 
/*  87 */             } catch (NoSuchFieldException e) {
/*  88 */               e.printStackTrace();
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  95 */     return fieldDescriptors;
/*     */   }
/*     */   
/*     */   private PositionalFieldDescriptor createPositionalDescriptor(Annotation positionalFieldAnnotation) {
/*  99 */     PositionalFieldDescriptor fieldDescriptor = new PositionalFieldDescriptor();
/* 100 */     Class<? extends Annotation> clazz = positionalFieldAnnotation.annotationType();
/*     */     try {
/* 102 */       fieldDescriptor.setPaddingAlign((PaddingAlign)clazz.getMethod("paddingAlign", new Class[0]).invoke(positionalFieldAnnotation, new Object[0]));
/* 103 */       fieldDescriptor.setPaddingCharacter(((Character)clazz.getMethod("paddingCharacter", new Class[0]).invoke(positionalFieldAnnotation, new Object[0])).charValue());
/* 104 */       fieldDescriptor.setTrimOnRead(((Boolean)clazz.getMethod("trimOnRead", new Class[0]).invoke(positionalFieldAnnotation, new Object[0])).booleanValue());
/* 105 */       if (this.annotationFieldManager.isRemainPositionalField(clazz)) {
/* 106 */         fieldDescriptor.setRemainPosition(true);
/* 107 */         fieldDescriptor.setDecorator((FieldDecorator)new DefaultFieldDecorator());
/*     */       } else {
/* 109 */         fieldDescriptor.setDecorator(this.annotationFieldManager.createNewInstanceDecorator(positionalFieldAnnotation));
/* 110 */         fieldDescriptor.setFinalPosition(((Integer)clazz.getMethod("finalPosition", new Class[0]).invoke(positionalFieldAnnotation, new Object[0])).intValue());
/* 111 */         fieldDescriptor.setInitialPosition(((Integer)clazz.getMethod("initialPosition", new Class[0]).invoke(positionalFieldAnnotation, new Object[0])).intValue());
/*     */       } 
/* 113 */       return fieldDescriptor;
/* 114 */     } catch (Exception e) {
/* 115 */       throw new FFPojoException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\reader\PositionalRecordAnnotationMetadataReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */