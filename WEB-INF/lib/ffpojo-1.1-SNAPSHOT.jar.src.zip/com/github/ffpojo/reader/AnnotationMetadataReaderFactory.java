/*    */ package com.github.ffpojo.reader;
/*    */ 
/*    */ import com.github.ffpojo.exception.MetadataNotFoundException;
/*    */ import com.github.ffpojo.metadata.delimited.annotation.DelimitedRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ 
/*    */ public class AnnotationMetadataReaderFactory
/*    */ {
/*    */   public static AnnotationMetadataReader createAnnotationMetadataReader(Class<?> recordClazz) throws MetadataNotFoundException {
/* 10 */     PositionalRecord positionalRecordAnnotation = recordClazz.<PositionalRecord>getAnnotation(PositionalRecord.class);
/* 11 */     if (positionalRecordAnnotation != null) {
/* 12 */       return new PositionalRecordAnnotationMetadataReader(recordClazz);
/*    */     }
/* 14 */     DelimitedRecord delimitedRecordAnnotation = recordClazz.<DelimitedRecord>getAnnotation(DelimitedRecord.class);
/* 15 */     if (delimitedRecordAnnotation != null) {
/* 16 */       return new DelimitedRecordAnnotationMetadataReader(recordClazz);
/*    */     }
/* 18 */     throw new MetadataNotFoundException("Annotation metadata not found for class " + recordClazz);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\reader\AnnotationMetadataReaderFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */