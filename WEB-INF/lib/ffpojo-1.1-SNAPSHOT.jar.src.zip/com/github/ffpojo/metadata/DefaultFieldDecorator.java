/*    */ package com.github.ffpojo.metadata;
/*    */ 
/*    */ 
/*    */ public class DefaultFieldDecorator
/*    */   implements FieldDecorator<Object>
/*    */ {
/*    */   public String toString(Object field) {
/*  8 */     return field.toString();
/*    */   }
/*    */   
/*    */   public Object fromString(String field) {
/* 12 */     return field;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\DefaultFieldDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */