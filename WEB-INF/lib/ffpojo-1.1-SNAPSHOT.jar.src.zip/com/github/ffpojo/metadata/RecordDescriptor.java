/*    */ package com.github.ffpojo.metadata;
/*    */ 
/*    */ import com.github.ffpojo.exception.InvalidMetadataException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RecordDescriptor
/*    */ {
/*    */   private List<? extends FieldDescriptor> fieldDescriptors;
/*    */   private Class<?> recordClazz;
/*    */   
/*    */   public RecordDescriptor() {}
/*    */   
/*    */   public RecordDescriptor(Class<?> recordClazz, List<? extends FieldDescriptor> fieldDescriptors) {
/* 17 */     this.recordClazz = recordClazz;
/* 18 */     this.fieldDescriptors = fieldDescriptors;
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract void assertValid() throws InvalidMetadataException;
/*    */ 
/*    */   
/*    */   public abstract void sortFieldDescriptors();
/*    */   
/*    */   public List<? extends FieldDescriptor> getFieldDescriptors() {
/* 28 */     return this.fieldDescriptors;
/*    */   }
/*    */   public void setFieldDescriptors(List<? extends FieldDescriptor> fieldDescriptors) {
/* 31 */     this.fieldDescriptors = fieldDescriptors;
/*    */   }
/*    */   public Class<?> getRecordClazz() {
/* 34 */     return this.recordClazz;
/*    */   }
/*    */   public void setRecordClazz(Class<?> recordClazz) {
/* 37 */     this.recordClazz = recordClazz;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\RecordDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */