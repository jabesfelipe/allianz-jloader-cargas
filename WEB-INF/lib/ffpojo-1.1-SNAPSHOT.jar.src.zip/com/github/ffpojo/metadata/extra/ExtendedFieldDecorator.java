/*    */ package com.github.ffpojo.metadata.extra;
/*    */ 
/*    */ import com.github.ffpojo.metadata.FieldDecorator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ExtendedFieldDecorator<T>
/*    */   implements FieldDecorator<T>
/*    */ {
/*    */   public static Class<?>[] getTypesConstructorExtended() {
/* 13 */     return new Class[0];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String[] getMethodContainsContstructorValues() {
/* 21 */     return new String[0];
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\extra\ExtendedFieldDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */