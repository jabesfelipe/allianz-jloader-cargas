/*     */ package com.github.ffpojo.metadata.extra;
/*     */ import com.github.ffpojo.decorator.InternalBigDecimalDecorator;
/*     */ import com.github.ffpojo.decorator.InternalDoubleDecorator;
/*     */ import com.github.ffpojo.decorator.InternalEnumDecorator;
/*     */ import com.github.ffpojo.decorator.InternalFloatDecorator;
/*     */ import com.github.ffpojo.decorator.InternalLongDecorator;
/*     */ import com.github.ffpojo.exception.FFPojoException;
/*     */ import com.github.ffpojo.exception.MetadataReaderException;
/*     */ import com.github.ffpojo.metadata.FieldDecorator;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.RemainPositionalField;
/*     */ import com.github.ffpojo.util.ReflectUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class FFPojoAnnotationFieldManager {
/*  19 */   private static final Map<String, Class<? extends FieldDecorator<?>>> mapAnnotationDecoratorClass = new HashMap<String, Class<? extends FieldDecorator<?>>>();
/*     */   
/*     */   static {
/*  22 */     mapAnnotationDecoratorClass.put("date", InternalDateDecorator.class);
/*  23 */     mapAnnotationDecoratorClass.put("long", InternalLongDecorator.class);
/*  24 */     mapAnnotationDecoratorClass.put("integer", InternalIntegerDecorator.class);
/*  25 */     mapAnnotationDecoratorClass.put("boolean", InternalBooleanDecorator.class);
/*  26 */     mapAnnotationDecoratorClass.put("list", InternalListDecorator.class);
/*  27 */     mapAnnotationDecoratorClass.put("set", InternalSetDecorator.class);
/*  28 */     mapAnnotationDecoratorClass.put("double", InternalDoubleDecorator.class);
/*  29 */     mapAnnotationDecoratorClass.put("float", InternalFloatDecorator.class);
/*  30 */     mapAnnotationDecoratorClass.put("bigdecimal", InternalBigDecimalDecorator.class);
/*  31 */     mapAnnotationDecoratorClass.put("biginteger", InternalBigIntegerDecorator.class);
/*  32 */     mapAnnotationDecoratorClass.put("enum", InternalEnumDecorator.class);
/*     */   }
/*     */   
/*     */   public Class<?> getClassDecorator(Class<? extends Annotation> clazzPositionalFieldAnnotation) {
/*  36 */     if (!isFFPojoAnnotationField(clazzPositionalFieldAnnotation)) {
/*  37 */       throw new FFPojoException(String.format("The class %s not seem a DelimitedField or PositionalField annotation.", new Object[] { clazzPositionalFieldAnnotation }));
/*     */     }
/*  39 */     String dataType = clazzPositionalFieldAnnotation.getSimpleName().replaceAll("DelimitedField", "").replaceAll("PositionalField", "").toLowerCase();
/*     */ 
/*     */ 
/*     */     
/*  43 */     return mapAnnotationDecoratorClass.get(dataType);
/*     */   }
/*     */   
/*     */   public boolean isFFPojoAnnotationField(Class<? extends Annotation> annotation) {
/*  47 */     return (isDelimitedField(annotation) || isPositionalField(annotation));
/*     */   }
/*     */   
/*     */   public boolean isRemainPositionalField(Class<? extends Annotation> annotation) {
/*  51 */     return annotation.isAssignableFrom(RemainPositionalField.class);
/*     */   }
/*     */   
/*     */   public boolean isPositionalField(Class<? extends Annotation> annotation) {
/*     */     try {
/*  56 */       annotation.getMethod("initialPosition", new Class[0]);
/*  57 */       annotation.getMethod("finalPosition", new Class[0]);
/*  58 */     } catch (Exception e) {
/*  59 */       return isRemainPositionalField(annotation);
/*     */     } 
/*  61 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isDelimitedField(Class<? extends Annotation> annotation) {
/*     */     try {
/*  66 */       annotation.getMethod("positionIndex", new Class[0]);
/*  67 */     } catch (Exception e) {
/*  68 */       return false;
/*     */     } 
/*  70 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFieldAlreadyFFPojoAnnotation(Field field) {
/*  75 */     Annotation[] annotationsField = field.getAnnotations();
/*  76 */     boolean hasFieldAnnotaded = false;
/*  77 */     for (int i = 0; i < annotationsField.length; i++) {
/*  78 */       hasFieldAnnotaded = isFFPojoAnnotationField(annotationsField[i].annotationType());
/*  79 */       if (hasFieldAnnotaded) {
/*  80 */         return hasFieldAnnotaded;
/*     */       }
/*     */     } 
/*  83 */     return hasFieldAnnotaded;
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldDecorator<?> createNewInstanceDecorator(Annotation fieldAnnotation) throws MetadataReaderException {
/*  88 */     Class<? extends Annotation> clazzPositionalFieldAnnotation = fieldAnnotation.annotationType();
/*  89 */     Class<?> clazzFieldDecorator = getClassDecorator(clazzPositionalFieldAnnotation);
/*  90 */     if (clazzFieldDecorator != null && ReflectUtil.getSuperClassesOf(clazzFieldDecorator).contains(ExtendedFieldDecorator.class)) {
/*     */       try {
/*  92 */         Method getTypesConstructorExtended = clazzFieldDecorator.getMethod("getTypesConstructorExtended", new Class[0]);
/*  93 */         Method getMethodContainsContstructorValues = clazzFieldDecorator.getMethod("getMethodContainsContstructorValues", new Class[0]);
/*     */         
/*  95 */         Class<?>[] typesToConstructor = (Class[])getTypesConstructorExtended.invoke(null, new Object[0]);
/*  96 */         String[] methodsName = (String[])getMethodContainsContstructorValues.invoke(null, new Object[0]);
/*  97 */         Object[] parameters = new Object[methodsName.length];
/*  98 */         for (int i = 0; i < methodsName.length; i++) {
/*  99 */           Method method = clazzPositionalFieldAnnotation.getMethod(methodsName[i], new Class[0]);
/* 100 */           parameters[i] = method.invoke(fieldAnnotation, new Object[0]);
/*     */         } 
/* 102 */         clazzFieldDecorator.getConstructors();
/* 103 */         FieldDecorator<?> filedDecorator = clazzFieldDecorator.getConstructor(typesToConstructor).newInstance(parameters);
/* 104 */         return filedDecorator;
/* 105 */       } catch (Exception e) {
/* 106 */         throw new FFPojoException(e);
/*     */       } 
/*     */     }
/* 109 */     return getDecoratorInstance(fieldAnnotation);
/*     */   }
/*     */ 
/*     */   
/*     */   private FieldDecorator<?> getDecoratorInstance(Annotation annotation) {
/* 114 */     Class<? extends FieldDecorator> decorator = null;
/*     */     try {
/* 116 */       decorator = (Class<? extends FieldDecorator>)annotation.getClass().getMethod("decorator", new Class[0]).invoke(annotation, new Object[0]);
/* 117 */       return decorator.newInstance();
/* 118 */     } catch (Exception e) {
/* 119 */       throw new MetadataReaderException("Error while instantiating decorator class, make sure that is provided a default constructor for class " + decorator, e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\extra\FFPojoAnnotationFieldManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */