/*    */ package com.github.ffpojo.metadata;
/*    */ 
/*    */ import com.github.ffpojo.metadata.positional.annotation.AccessorType;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FieldDescriptor
/*    */ {
/*    */   private Method getter;
/*    */   private Field field;
/* 13 */   private AccessorType accessorType = AccessorType.PROPERTY;
/*    */ 
/*    */ 
/*    */   
/*    */   public Method getGetter() {
/* 18 */     return this.getter;
/*    */   }
/*    */   public void setGetter(Method getter) {
/* 21 */     this.getter = getter;
/*    */   }
/*    */   public Field getField() {
/* 24 */     return this.field;
/*    */   }
/*    */   public void setField(Field field) {
/* 27 */     this.field = field;
/*    */   }
/*    */   public AccessorType getAccessorType() {
/* 30 */     return this.accessorType;
/*    */   }
/*    */   public void setAccessorType(AccessorType accessorType) {
/* 33 */     this.accessorType = accessorType;
/*    */   }
/*    */   
/*    */   public boolean isByField() {
/* 37 */     return this.accessorType.isByField();
/*    */   }
/*    */   
/*    */   public boolean isByProperty() {
/* 41 */     return this.accessorType.isByProperty();
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\FieldDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */