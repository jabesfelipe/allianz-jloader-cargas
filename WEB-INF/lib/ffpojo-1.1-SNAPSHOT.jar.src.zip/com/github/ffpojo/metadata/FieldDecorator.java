package com.github.ffpojo.metadata;

import com.github.ffpojo.exception.FieldDecoratorException;

public interface FieldDecorator<T> {
  String toString(T paramT) throws FieldDecoratorException;
  
  T fromString(String paramString) throws FieldDecoratorException;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\FieldDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */