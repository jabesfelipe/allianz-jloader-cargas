/*    */ package com.github.ffpojo.metadata.positional.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AccessorType
/*    */ {
/*  9 */   PROPERTY, FIELD;
/*    */   
/*    */   public boolean isByField() {
/* 12 */     return FIELD.equals(this);
/*    */   }
/*    */   
/*    */   public boolean isByProperty() {
/* 16 */     return PROPERTY.equals(this);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\positional\annotation\AccessorType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */