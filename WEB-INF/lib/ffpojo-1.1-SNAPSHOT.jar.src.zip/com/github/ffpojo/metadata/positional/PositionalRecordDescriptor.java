/*     */ package com.github.ffpojo.metadata.positional;
/*     */ 
/*     */ import com.github.ffpojo.exception.InvalidMetadataException;
/*     */ import com.github.ffpojo.metadata.RecordDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PositionalRecordDescriptor
/*     */   extends RecordDescriptor
/*     */ {
/*     */   private boolean ignorePositionNotFound = false;
/*     */   
/*     */   public PositionalRecordDescriptor() {
/*  20 */     setFieldDescriptors(new ArrayList());
/*     */   }
/*     */   
/*     */   public PositionalRecordDescriptor(Class<?> recordClazz, List<PositionalFieldDescriptor> fieldDescriptors) {
/*  24 */     super(recordClazz, fieldDescriptors);
/*     */   }
/*     */ 
/*     */   
/*     */   public void assertValid() throws InvalidMetadataException {
/*  29 */     List<PositionalFieldDescriptor> positionalFieldDescriptors = getFieldDescriptors();
/*  30 */     if (null != positionalFieldDescriptors) {
/*  31 */       sortAndRemoveRepeated(positionalFieldDescriptors);
/*     */     }
/*  33 */     if (positionalFieldDescriptors != null && !positionalFieldDescriptors.isEmpty())
/*  34 */       for (int i = 0; i < positionalFieldDescriptors.size(); i++) {
/*  35 */         PositionalFieldDescriptor actualFieldDescriptor = positionalFieldDescriptors.get(i);
/*  36 */         if (!actualFieldDescriptor.isRemainPosition()) {
/*     */ 
/*     */           
/*  39 */           boolean isFirstFieldDescriptor = (i == 0);
/*  40 */           PositionalFieldDescriptor previousFieldDescriptor = null;
/*  41 */           if (!isFirstFieldDescriptor) {
/*  42 */             previousFieldDescriptor = positionalFieldDescriptors.get(i - 1);
/*     */           }
/*     */           
/*  45 */           if (actualFieldDescriptor.getInitialPosition() <= 0 || actualFieldDescriptor.getFinalPosition() <= 0) {
/*  46 */             throw new InvalidMetadataException("Initial position and final position must be positive integers (greater than zero): " + actualFieldDescriptor.getGetter());
/*     */           }
/*  48 */           if (actualFieldDescriptor.getFinalPosition() < actualFieldDescriptor.getInitialPosition()) {
/*  49 */             throw new InvalidMetadataException("Invalid interval of positions: " + actualFieldDescriptor.getGetter());
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  62 */           if (!isFirstFieldDescriptor && actualFieldDescriptor.getInitialPosition() <= previousFieldDescriptor.getFinalPosition()) {
/*  63 */             String filedName = getFieldName(actualFieldDescriptor);
/*  64 */             String previousName = getFieldName(previousFieldDescriptor);
/*     */             
/*  66 */             throw new InvalidMetadataException(String.format("Position interval of field %s overlaps the previous field %s ", new Object[] { filedName, previousName }));
/*     */           } 
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   private String getFieldName(PositionalFieldDescriptor fieldDescriptor) {
/*  73 */     String previousName = "";
/*  74 */     if (fieldDescriptor.isByProperty()) {
/*  75 */       previousName = fieldDescriptor.getGetter().getName();
/*     */     } else {
/*  77 */       previousName = fieldDescriptor.getField().getName();
/*     */     } 
/*  79 */     return previousName;
/*     */   }
/*     */   
/*     */   private void sortAndRemoveRepeated(List<PositionalFieldDescriptor> positionalFieldDescriptors) {
/*  83 */     TreeSet<PositionalFieldDescriptor> fieldDescriptors = new TreeSet<PositionalFieldDescriptor>(positionalFieldDescriptors);
/*  84 */     positionalFieldDescriptors.clear();
/*  85 */     positionalFieldDescriptors.addAll(fieldDescriptors);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PositionalFieldDescriptor> getFieldDescriptors() {
/*  91 */     return super.getFieldDescriptors();
/*     */   }
/*     */ 
/*     */   
/*     */   public void sortFieldDescriptors() {
/*  96 */     List<PositionalFieldDescriptor> fieldDescriptors = getFieldDescriptors();
/*  97 */     if (fieldDescriptors != null && !fieldDescriptors.isEmpty()) {
/*  98 */       Collections.sort(fieldDescriptors);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isIgnorePositionNotFound() {
/* 103 */     return this.ignorePositionNotFound;
/*     */   }
/*     */   
/*     */   public void setIgnorePositionNotFound(boolean ignorePositionNotFound) {
/* 107 */     this.ignorePositionNotFound = ignorePositionNotFound;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\positional\PositionalRecordDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */