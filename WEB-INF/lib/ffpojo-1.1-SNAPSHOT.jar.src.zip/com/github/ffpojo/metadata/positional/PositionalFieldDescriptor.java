/*    */ package com.github.ffpojo.metadata.positional;
/*    */ 
/*    */ import com.github.ffpojo.metadata.FieldDecorator;
/*    */ import com.github.ffpojo.metadata.FieldDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PositionalFieldDescriptor
/*    */   extends FieldDescriptor
/*    */   implements Comparable<PositionalFieldDescriptor>
/*    */ {
/*    */   private int initialPosition;
/*    */   private int finalPosition;
/*    */   private PaddingAlign paddingAlign;
/*    */   private char paddingCharacter;
/*    */   private boolean trimOnRead;
/*    */   private FieldDecorator<?> decorator;
/*    */   private boolean ignorePositionNotFound;
/*    */   private boolean remainPosition;
/*    */   
/*    */   public int compareTo(PositionalFieldDescriptor other) {
/* 22 */     if (isRemainPosition()) {
/* 23 */       return 1;
/*    */     }
/* 25 */     if (other.isRemainPosition()) {
/* 26 */       return -1;
/*    */     }
/* 28 */     if (this.initialPosition - other.initialPosition == 0) {
/*    */       
/* 30 */       if (this.finalPosition - other.finalPosition == 0) {
/* 31 */         if (isByProperty()) {
/* 32 */           return getGetter().getName().compareTo(other.getGetter().getName());
/*    */         }
/* 34 */         return (getField() == null) ? -1 : ((other.getField() == null) ? 1 : getField().getName().compareTo(other.getField().getName()));
/*    */       } 
/*    */ 
/*    */       
/* 38 */       return this.finalPosition - other.finalPosition;
/*    */     } 
/*    */     
/* 41 */     return this.initialPosition - other.initialPosition;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getInitialPosition() {
/* 48 */     return this.initialPosition;
/*    */   }
/*    */   public void setInitialPosition(int initialPosition) {
/* 51 */     this.initialPosition = initialPosition;
/*    */   }
/*    */   public int getFinalPosition() {
/* 54 */     return this.finalPosition;
/*    */   }
/*    */   public void setFinalPosition(int finalPosition) {
/* 57 */     this.finalPosition = finalPosition;
/*    */   }
/*    */   public FieldDecorator<?> getDecorator() {
/* 60 */     return this.decorator;
/*    */   }
/*    */   public void setDecorator(FieldDecorator<?> decorator) {
/* 63 */     this.decorator = decorator;
/*    */   }
/*    */   public PaddingAlign getPaddingAlign() {
/* 66 */     return this.paddingAlign;
/*    */   }
/*    */   public void setPaddingAlign(PaddingAlign paddingAlign) {
/* 69 */     this.paddingAlign = paddingAlign;
/*    */   }
/*    */   public char getPaddingCharacter() {
/* 72 */     return this.paddingCharacter;
/*    */   }
/*    */   public void setPaddingCharacter(char paddingCharacter) {
/* 75 */     this.paddingCharacter = paddingCharacter;
/*    */   }
/*    */   public boolean isTrimOnRead() {
/* 78 */     return this.trimOnRead;
/*    */   }
/*    */   public void setTrimOnRead(boolean trimOnRead) {
/* 81 */     this.trimOnRead = trimOnRead;
/*    */   }
/*    */   
/*    */   public boolean isIgnorePositionNotFound() {
/* 85 */     return this.ignorePositionNotFound;
/*    */   }
/*    */   
/*    */   public void setIgnorePositionNotFound(boolean ignorePositionNotFound) {
/* 89 */     this.ignorePositionNotFound = ignorePositionNotFound;
/*    */   }
/*    */   
/*    */   public boolean isRemainPosition() {
/* 93 */     return this.remainPosition;
/*    */   }
/*    */   
/*    */   public void setRemainPosition(boolean remainPosition) {
/* 97 */     this.remainPosition = remainPosition;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\positional\PositionalFieldDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */