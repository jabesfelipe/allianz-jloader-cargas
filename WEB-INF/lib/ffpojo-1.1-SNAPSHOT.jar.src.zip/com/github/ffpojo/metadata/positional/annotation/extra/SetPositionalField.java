package com.github.ffpojo.metadata.positional.annotation.extra;

import com.github.ffpojo.metadata.positional.PaddingAlign;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface SetPositionalField {
  int initialPosition();
  
  int finalPosition();
  
  Class<?> itemType();
  
  PaddingAlign paddingAlign() default PaddingAlign.RIGHT;
  
  char paddingCharacter() default ' ';
  
  boolean trimOnRead() default true;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\positional\annotation\extra\SetPositionalField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */