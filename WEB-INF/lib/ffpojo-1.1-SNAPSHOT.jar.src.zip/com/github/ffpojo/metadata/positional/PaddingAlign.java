/*   */ package com.github.ffpojo.metadata.positional;
/*   */ 
/*   */ public enum PaddingAlign {
/* 4 */   LEFT,
/* 5 */   RIGHT;
/*   */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\positional\PaddingAlign.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */