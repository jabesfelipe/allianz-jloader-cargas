package com.github.ffpojo.metadata.delimited.annotation.extra;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface IntegerDelimitedField {
  int positionIndex();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\delimited\annotation\extra\IntegerDelimitedField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */