/*    */ package com.github.ffpojo.metadata.delimited;
/*    */ 
/*    */ import com.github.ffpojo.exception.InvalidMetadataException;
/*    */ import com.github.ffpojo.metadata.RecordDescriptor;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class DelimitedRecordDescriptor
/*    */   extends RecordDescriptor
/*    */ {
/*    */   private String delimiter;
/*    */   
/*    */   public DelimitedRecordDescriptor() {
/* 16 */     setFieldDescriptors(new ArrayList());
/*    */   }
/*    */   
/*    */   public DelimitedRecordDescriptor(Class<?> recordClazz, List<DelimitedFieldDescriptor> fieldDescriptors, String delimiter) {
/* 20 */     super(recordClazz, fieldDescriptors);
/* 21 */     this.delimiter = delimiter;
/*    */   }
/*    */ 
/*    */   
/*    */   public void assertValid() throws InvalidMetadataException {
/* 26 */     if (getDelimiter() == null || getDelimiter().equals("")) {
/* 27 */       throw new InvalidMetadataException("Delimiter is required and cannot be an empty string");
/*    */     }
/* 29 */     List<DelimitedFieldDescriptor> delimitedFieldDescriptors = getFieldDescriptors();
/* 30 */     if (delimitedFieldDescriptors != null && !delimitedFieldDescriptors.isEmpty()) {
/* 31 */       for (int i = 0; i < delimitedFieldDescriptors.size(); i++) {
/* 32 */         DelimitedFieldDescriptor actualFieldDescriptor = delimitedFieldDescriptors.get(i);
/*    */         
/* 34 */         boolean isFirstFieldDescriptor = (i == 0);
/* 35 */         DelimitedFieldDescriptor previousFieldDescriptor = null;
/* 36 */         if (!isFirstFieldDescriptor) {
/* 37 */           previousFieldDescriptor = delimitedFieldDescriptors.get(i - 1);
/*    */         }
/*    */         
/* 40 */         if (actualFieldDescriptor.getPositionIndex() <= 0) {
/* 41 */           throw new InvalidMetadataException("Position index must be an positive integer (greater than zero): " + actualFieldDescriptor.getGetter());
/*    */         }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 54 */         if (!isFirstFieldDescriptor && actualFieldDescriptor.getPositionIndex() == previousFieldDescriptor.getPositionIndex()) {
/* 55 */           throw new InvalidMetadataException("Position index overlaps the previous field: " + actualFieldDescriptor.getGetter());
/*    */         }
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List<DelimitedFieldDescriptor> getFieldDescriptors() {
/* 64 */     return super.getFieldDescriptors();
/*    */   }
/*    */ 
/*    */   
/*    */   public void sortFieldDescriptors() {
/* 69 */     List<DelimitedFieldDescriptor> fieldDescriptors = getFieldDescriptors();
/* 70 */     if (fieldDescriptors != null && !fieldDescriptors.isEmpty()) {
/* 71 */       Collections.sort(fieldDescriptors);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDelimiter() {
/* 78 */     return this.delimiter;
/*    */   }
/*    */   public void setDelimiter(String delimiter) {
/* 81 */     this.delimiter = delimiter;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\delimited\DelimitedRecordDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */