/*    */ package com.github.ffpojo.metadata.delimited;
/*    */ 
/*    */ import com.github.ffpojo.metadata.FieldDecorator;
/*    */ import com.github.ffpojo.metadata.FieldDescriptor;
/*    */ 
/*    */ public class DelimitedFieldDescriptor
/*    */   extends FieldDescriptor
/*    */   implements Comparable<DelimitedFieldDescriptor> {
/*    */   private int positionIndex;
/*    */   private FieldDecorator<?> decorator;
/*    */   
/*    */   public int compareTo(DelimitedFieldDescriptor other) {
/* 13 */     if (this.positionIndex - other.positionIndex == 0) {
/* 14 */       return getGetter().getName().compareTo(other.getGetter().getName());
/*    */     }
/* 16 */     return this.positionIndex - other.positionIndex;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPositionIndex() {
/* 23 */     return this.positionIndex;
/*    */   }
/*    */   public void setPositionIndex(int positionIndex) {
/* 26 */     this.positionIndex = positionIndex;
/*    */   }
/*    */   public FieldDecorator<?> getDecorator() {
/* 29 */     return this.decorator;
/*    */   }
/*    */   public void setDecorator(FieldDecorator<?> decorator) {
/* 32 */     this.decorator = decorator;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\delimited\DelimitedFieldDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */