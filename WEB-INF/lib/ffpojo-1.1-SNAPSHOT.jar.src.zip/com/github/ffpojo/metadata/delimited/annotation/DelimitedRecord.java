package com.github.ffpojo.metadata.delimited.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface DelimitedRecord {
  String delimiter() default ",";
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\delimited\annotation\DelimitedRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */