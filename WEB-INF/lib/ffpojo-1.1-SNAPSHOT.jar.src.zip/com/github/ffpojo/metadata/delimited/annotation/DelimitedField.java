package com.github.ffpojo.metadata.delimited.annotation;

import com.github.ffpojo.metadata.FieldDecorator;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.FIELD})
public @interface DelimitedField {
  int positionIndex();
  
  Class<? extends FieldDecorator<?>> decorator() default com.github.ffpojo.metadata.DefaultFieldDecorator.class;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\metadata\delimited\annotation\DelimitedField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */