package com.github.ffpojo.file.writer;

import com.github.ffpojo.exception.FFPojoException;
import com.github.ffpojo.file.reader.FlatFileReader;
import java.io.IOException;
import java.util.Collection;

public interface FlatFileWriter {
  void close() throws IOException;
  
  boolean isClosed();
  
  void writeRecord(Object paramObject) throws IOException, FFPojoException;
  
  void writeRecordArray(Object[] paramArrayOfObject) throws IOException, FFPojoException;
  
  void writeRecordList(Collection<?> paramCollection) throws IOException, FFPojoException;
  
  void writeFromFlatFileReader(FlatFileReader paramFlatFileReader) throws IOException, FFPojoException;
  
  long getRecordsWritten();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\writer\FlatFileWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */