/*    */ package com.github.ffpojo.file.writer;
/*    */ 
/*    */ import com.github.ffpojo.FFPojoHelper;
/*    */ import com.github.ffpojo.exception.FFPojoException;
/*    */ import com.github.ffpojo.file.reader.FlatFileReader;
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ 
/*    */ public class FileSystemFlatFileWriter
/*    */   extends BaseFlatFileWriter
/*    */   implements FlatFileWriter {
/*    */   private FFPojoHelper ffpojoHelper;
/*    */   private BufferedWriter writer;
/*    */   
/*    */   public FileSystemFlatFileWriter(File file, boolean createIfNotExists) throws IOException, FFPojoException {
/* 19 */     if (file == null) {
/* 20 */       throw new IllegalArgumentException("File object is null");
/*    */     }
/* 22 */     if (!file.exists()) {
/* 23 */       if (createIfNotExists) {
/* 24 */         file.createNewFile();
/*    */       } else {
/* 26 */         throw new IllegalArgumentException("Specified file does not exists: " + file.getName());
/*    */       } 
/*    */     }
/* 29 */     if (!file.isFile())
/* 30 */       throw new IllegalArgumentException("Specified file does not represent a file: " + file.getName()); 
/* 31 */     if (!file.canWrite()) {
/* 32 */       throw new IllegalArgumentException("Specified file cannot be written, please check the SO permissions: " + file.getName());
/*    */     }
/*    */     
/* 35 */     this.ffpojoHelper = FFPojoHelper.getInstance();
/* 36 */     this.writer = new BufferedWriter(new FileWriter(file));
/*    */   }
/*    */   
/*    */   public void writeRecord(Object record) throws IOException, FFPojoException {
/* 40 */     if (record == null) {
/* 41 */       throw new IllegalArgumentException("Record object is null");
/*    */     }
/* 43 */     String recordText = this.ffpojoHelper.parseToText(record);
/* 44 */     if (this.recordsWritten > 0L) {
/* 45 */       this.writer.newLine();
/*    */     }
/* 47 */     this.writer.write(recordText);
/* 48 */     this.recordsWritten++;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeRecordArray(Object[] recordArray) throws IOException, FFPojoException {
/* 53 */     if (recordArray != null && recordArray.length > 0) {
/* 54 */       for (Object rec : recordArray) {
/* 55 */         writeRecord(rec);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeRecordList(Collection<?> recordCollection) throws IOException, FFPojoException {
/* 61 */     if (recordCollection != null && !recordCollection.isEmpty()) {
/* 62 */       for (Object rec : recordCollection) {
/* 63 */         writeRecord(rec);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeFromFlatFileReader(FlatFileReader flatFileReader) throws IOException, FFPojoException {
/* 69 */     if (flatFileReader == null || flatFileReader.isClosed()) {
/* 70 */       throw new IllegalArgumentException("FlatFileReader object is null or closed");
/*    */     }
/* 72 */     flatFileReader.reset();
/* 73 */     for (Object record : flatFileReader) {
/* 74 */       writeRecord(record);
/*    */     }
/* 76 */     flatFileReader.close();
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 80 */     if (this.writer != null) {
/* 81 */       this.writer.close();
/* 82 */       this.writer = null;
/*    */     } 
/* 84 */     this.closed = true;
/* 85 */     System.gc();
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\writer\FileSystemFlatFileWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */