/*   */ package com.github.ffpojo.file.reader;
/*   */ 
/*   */ public enum RecordType {
/* 4 */   HEADER,
/* 5 */   BODY,
/* 6 */   TRAILER;
/*   */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\reader\RecordType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */