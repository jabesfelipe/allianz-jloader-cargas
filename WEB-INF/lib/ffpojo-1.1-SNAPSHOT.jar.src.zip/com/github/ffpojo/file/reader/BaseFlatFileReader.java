/*    */ package com.github.ffpojo.file.reader;
/*    */ 
/*    */ import com.github.ffpojo.FFPojoHelper;
/*    */ import com.github.ffpojo.exception.RecordParserException;
/*    */ import com.github.ffpojo.parser.RecordParser;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ abstract class BaseFlatFileReader
/*    */   implements FlatFileReader
/*    */ {
/*    */   protected FlatFileReaderDefinition flatFileDefinition;
/*    */   protected RecordType recordType;
/*    */   protected String recordText;
/*    */   protected long recordIndex;
/*    */   protected boolean closed;
/* 17 */   private final FFPojoHelper ffpojoHelper = FFPojoHelper.getInstance();
/*    */ 
/*    */   
/*    */   protected Object parseRecordFromText(String text) throws RecordParserException {
/*    */     Class<?> recordClazz;
/* 22 */     if (this.recordIndex == 0L && this.flatFileDefinition.getHeader() != null) {
/* 23 */       this.recordType = RecordType.HEADER;
/* 24 */       recordClazz = this.flatFileDefinition.getHeader();
/* 25 */     } else if (!hasNext() && this.flatFileDefinition.getTrailer() != null) {
/* 26 */       this.recordType = RecordType.TRAILER;
/* 27 */       recordClazz = this.flatFileDefinition.getTrailer();
/*    */     } else {
/* 29 */       this.recordType = RecordType.BODY;
/* 30 */       recordClazz = this.flatFileDefinition.getBody(text);
/*    */     } 
/* 32 */     RecordParser parser = this.ffpojoHelper.getRecordParser(recordClazz);
/* 33 */     return parser.parseFromText(recordClazz, text);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void remove() {
/* 38 */     throw new UnsupportedOperationException("Remove method not supported");
/*    */   }
/*    */   
/*    */   public Iterator<Object> iterator() {
/* 42 */     return this;
/*    */   }
/*    */   
/*    */   public RecordType getRecordType() {
/* 46 */     return this.recordType;
/*    */   }
/*    */   public String getRecordText() {
/* 49 */     return this.recordText;
/*    */   }
/*    */   public long getRecordIndex() {
/* 52 */     return this.recordIndex;
/*    */   }
/*    */   public boolean isClosed() {
/* 55 */     return this.closed;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\reader\BaseFlatFileReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */