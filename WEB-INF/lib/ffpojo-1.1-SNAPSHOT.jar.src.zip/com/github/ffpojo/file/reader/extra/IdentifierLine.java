/*    */ package com.github.ffpojo.file.reader.extra;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdentifierLine
/*    */ {
/* 12 */   private Map<Integer, String> mapIds = new HashMap<Integer, String>();
/*    */   
/*    */   public Map<Integer, String> getMapIds() {
/* 15 */     return this.mapIds;
/*    */   }
/*    */   
/*    */   public void setMapIds(Map<Integer, String> mapIds) {
/* 19 */     this.mapIds = mapIds;
/*    */   }
/*    */   
/*    */   public void putId(Integer startPosition, String text) {
/* 23 */     this.mapIds.put(startPosition, text);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 28 */     if (this == o) return true; 
/* 29 */     if (o == null || getClass() != o.getClass()) return false;
/*    */     
/* 31 */     IdentifierLine that = (IdentifierLine)o;
/*    */     
/* 33 */     return this.mapIds.equals(that.mapIds);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 39 */     return this.mapIds.hashCode();
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\reader\extra\IdentifierLine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */