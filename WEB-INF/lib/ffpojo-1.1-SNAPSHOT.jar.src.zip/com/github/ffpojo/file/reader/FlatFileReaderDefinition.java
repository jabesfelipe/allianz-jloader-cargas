/*     */ package com.github.ffpojo.file.reader;
/*     */ import com.github.ffpojo.FFPojoHelper;
/*     */ import com.github.ffpojo.exception.FFPojoException;
/*     */ import com.github.ffpojo.file.reader.extra.IdentifierLine;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*     */ import com.github.ffpojo.parser.RecordParser;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class FlatFileReaderDefinition {
/*  15 */   private final FFPojoHelper ffpojoHelper = FFPojoHelper.getInstance();
/*     */   
/*     */   private Class<?> body;
/*     */   
/*     */   private Class<?> header;
/*     */   
/*     */   private Class<?> trailer;
/*     */   @Deprecated
/*     */   private RecordParser bodyParser;
/*     */   @Deprecated
/*     */   private RecordParser headerParser;
/*     */   @Deprecated
/*     */   private RecordParser trailerParser;
/*  28 */   private Map<IdentifierLine, Class<?>> definitions = new HashMap<IdentifierLine, Class<?>>();
/*     */   
/*     */   private IdentifierLine idLine;
/*     */   
/*     */   public FlatFileReaderDefinition(Class bodyClass) {
/*  33 */     this((Collection)Arrays.asList(new Class[] { bodyClass }));
/*     */   }
/*     */ 
/*     */   
/*     */   public FlatFileReaderDefinition(Collection<Class<?>> bodyClasses) {
/*  38 */     if (bodyClasses == null || bodyClasses.isEmpty()) {
/*  39 */       throw new IllegalArgumentException("Class<?> object is null");
/*     */     }
/*  41 */     createMapDefinitions(bodyClasses);
/*     */   }
/*     */ 
/*     */   
/*     */   private void createMapDefinitions(Collection<Class<?>> bodyClasses) {
/*  46 */     for (Class<?> bodyClass : bodyClasses) {
/*  47 */       if (bodyClass.isAnnotationPresent((Class)PositionalRecord.class)) {
/*  48 */         PositionalRecord pr = bodyClass.<PositionalRecord>getAnnotation(PositionalRecord.class);
/*  49 */         PositionalRecordLineIdentifier[] identifiers = pr.lineIdentifiers();
/*  50 */         IdentifierLine identifierLine = new IdentifierLine();
/*  51 */         for (int i = 0; i < identifiers.length; i++) {
/*  52 */           identifierLine.putId(Integer.valueOf(identifiers[i].startPosition()), identifiers[i].textIdentifier());
/*     */         }
/*  54 */         this.definitions.put(identifierLine, bodyClass);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setHeader(Class<?> header) throws FFPojoException {
/*  60 */     this.header = header;
/*  61 */     if (header == null) {
/*  62 */       this.headerParser = null;
/*     */     } else {
/*  64 */       this.headerParser = this.ffpojoHelper.getRecordParser(header);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setTrailer(Class<?> trailer) throws FFPojoException {
/*  69 */     this.trailer = trailer;
/*  70 */     if (trailer == null) {
/*  71 */       this.trailerParser = null;
/*     */     } else {
/*  73 */       this.trailerParser = this.ffpojoHelper.getRecordParser(trailer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getBody(String message) {
/*  80 */     Set<IdentifierLine> identifierLines = this.definitions.keySet();
/*  81 */     IdentifierLine messageId = new IdentifierLine();
/*  82 */     for (IdentifierLine id : identifierLines) {
/*  83 */       Map<Integer, String> mapIds = id.getMapIds();
/*  84 */       Set<Integer> keys = mapIds.keySet();
/*  85 */       for (Integer startPosition : keys) {
/*  86 */         String textId = mapIds.get(startPosition);
/*  87 */         int sizeText = textId.length();
/*  88 */         int finalPosition = startPosition.intValue() + sizeText;
/*  89 */         if (finalPosition > message.length()) {
/*     */           break;
/*     */         }
/*  92 */         messageId.putId(startPosition, message.substring(startPosition.intValue(), finalPosition));
/*     */       } 
/*  94 */       if (id.equals(messageId)) {
/*  95 */         this.body = this.definitions.get(messageId);
/*     */         break;
/*     */       } 
/*  98 */       messageId.getMapIds().clear();
/*     */     } 
/*     */     
/* 101 */     if (this.body == null) {
/* 102 */       throw new FFPojoException(String.format("No class matches with the line starting with:  %s ", new Object[] { getStartWithText(message) }));
/*     */     }
/*     */     
/* 105 */     return this.body;
/*     */   }
/*     */   
/*     */   private String getStartWithText(String message) {
/* 109 */     String startWith = "";
/* 110 */     if (message.length() > 20) {
/* 111 */       startWith = message.substring(0, 20);
/*     */     } else {
/* 113 */       startWith = message;
/*     */     } 
/* 115 */     return startWith;
/*     */   }
/*     */   
/*     */   public Class<?> getBody() {
/* 119 */     return this.body;
/*     */   }
/*     */   public Class<?> getHeader() {
/* 122 */     return this.header;
/*     */   }
/*     */   public Class<?> getTrailer() {
/* 125 */     return this.trailer;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public RecordParser getBodyParser() {
/* 130 */     return this.bodyParser;
/*     */   }
/*     */   @Deprecated
/*     */   public RecordParser getHeaderParser() {
/* 134 */     return this.headerParser;
/*     */   }
/*     */   @Deprecated
/*     */   public RecordParser getTrailerParser() {
/* 138 */     return this.trailerParser;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\reader\FlatFileReaderDefinition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */