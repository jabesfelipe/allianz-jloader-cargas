/*    */ package com.github.ffpojo.file.reader;
/*    */ 
/*    */ import com.github.ffpojo.exception.RecordParserException;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ public class InputStreamFlatFileReader
/*    */   extends BaseFlatFileReader
/*    */   implements FlatFileReader {
/*    */   private static final boolean IS_RESET_SUPPORTED = false;
/*    */   private BufferedReader inputStreamReader;
/*    */   private String nextLine;
/*    */   
/*    */   public InputStreamFlatFileReader(InputStream inputStream, FlatFileReaderDefinition flatFile) throws IOException {
/* 19 */     if (inputStream == null) {
/* 20 */       throw new IllegalArgumentException("InputStream object is null");
/*    */     }
/*    */     
/* 23 */     this.inputStreamReader = new BufferedReader(new InputStreamReader(inputStream));
/* 24 */     this.flatFileDefinition = flatFile;
/* 25 */     this.nextLine = this.inputStreamReader.readLine();
/*    */   }
/*    */   
/*    */   public boolean isResetSupported() {
/* 29 */     return false;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void reset() throws IOException {
/* 34 */     throw new UnsupportedOperationException("Reset method not supported by " + getClass());
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 38 */     if (this.inputStreamReader != null) {
/* 39 */       this.inputStreamReader.close();
/*    */     }
/* 41 */     this.closed = true;
/* 42 */     System.gc();
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 46 */     if (this.nextLine == null) {
/* 47 */       return false;
/*    */     }
/* 49 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object next() {
/* 54 */     if (!hasNext()) {
/* 55 */       throw new NoSuchElementException("There are no more records to read");
/*    */     }
/*    */     try {
/* 58 */       String currLine = this.nextLine;
/* 59 */       this.nextLine = this.inputStreamReader.readLine();
/* 60 */       Object record = parseRecordFromText(currLine);
/* 61 */       this.recordText = this.nextLine;
/* 62 */       this.recordIndex++;
/* 63 */       return record;
/* 64 */     } catch (IOException e) {
/* 65 */       throw new RuntimeException("Error while decoding the line number " + (this.recordIndex + 1L), e);
/* 66 */     } catch (RecordParserException e) {
/* 67 */       throw new RuntimeException("Error while parsing from text the line number " + (this.recordIndex + 1L), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\reader\InputStreamFlatFileReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */