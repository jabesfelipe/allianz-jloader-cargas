package com.github.ffpojo.file.reader;

import java.io.IOException;
import java.util.Iterator;

public interface FlatFileReader extends Iterator<Object>, Iterable<Object> {
  void reset() throws IOException;
  
  void close() throws IOException;
  
  boolean isResetSupported();
  
  boolean isClosed();
  
  RecordType getRecordType();
  
  String getRecordText();
  
  long getRecordIndex();
  
  boolean hasNext();
  
  Object next();
  
  @Deprecated
  void remove();
  
  Iterator<Object> iterator();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\reader\FlatFileReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */