/*     */ package com.github.ffpojo.file.reader;
/*     */ 
/*     */ import com.github.ffpojo.exception.FFPojoException;
/*     */ import com.github.ffpojo.exception.RecordParserException;
/*     */ import com.github.ffpojo.util.FileUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.MappedByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class FileSystemFlatFileReader
/*     */   extends BaseFlatFileReader implements FlatFileReader {
/*     */   private static final int DEFAULT_LINE_BYTE_BUFFER_SIZE = 2048;
/*  22 */   private static final Charset DEFAULT_CHARSET = Charset.defaultCharset();
/*     */   
/*     */   private static final int PAGE_SIZE = 2147483647;
/*     */   
/*     */   private static final boolean IS_RESET_SUPPORTED = true;
/*     */   private List<MappedByteBuffer> buffers;
/*     */   private MappedByteBuffer singleBuffer;
/*     */   private boolean isSingleBuffer;
/*     */   private FileChannel channel;
/*     */   private ByteBuffer byteBuffer;
/*     */   private CharsetDecoder decoder;
/*     */   private long fileSize;
/*     */   private long position;
/*     */   
/*     */   public FileSystemFlatFileReader(File file, FlatFileReaderDefinition flatFileDefinition) throws IOException {
/*  37 */     this(file, flatFileDefinition, DEFAULT_CHARSET, 2048);
/*     */   }
/*     */   
/*     */   public FileSystemFlatFileReader(File file, FlatFileReaderDefinition flatFileDefinition, int lineByteBufferSize) throws IOException {
/*  41 */     this(file, flatFileDefinition, DEFAULT_CHARSET, lineByteBufferSize);
/*     */   }
/*     */   
/*     */   public FileSystemFlatFileReader(File file, FlatFileReaderDefinition flatFileDefinition, Charset charset) throws IOException {
/*  45 */     this(file, flatFileDefinition, charset, 2048);
/*     */   }
/*     */ 
/*     */   
/*     */   public FileSystemFlatFileReader(File file, FlatFileReaderDefinition flatFile, Charset charset, int lineByteBufferSize) throws IOException {
/*  50 */     if (file == null)
/*  51 */       throw new IllegalArgumentException("File object is null"); 
/*  52 */     if (!file.exists())
/*  53 */       throw new IllegalArgumentException("Specified file does not exists: " + file.getName()); 
/*  54 */     if (!file.isFile())
/*  55 */       throw new IllegalArgumentException("Specified file does not represent a file: " + file.getName()); 
/*  56 */     if (!file.canRead()) {
/*  57 */       throw new IllegalArgumentException("Specified file cannot be read, please check the SO permissions: " + file.getName());
/*     */     }
/*  59 */     this.flatFileDefinition = flatFile;
/*  60 */     this.fileSize = file.length();
/*  61 */     this.decoder = charset.newDecoder();
/*     */     
/*  63 */     this.byteBuffer = ByteBuffer.allocateDirect(lineByteBufferSize);
/*  64 */     this.channel = (new RandomAccessFile(file, "r")).getChannel();
/*     */     
/*  66 */     this.buffers = FileUtil.mapFileUsingMappedByteBuffers(this.channel, FileChannel.MapMode.READ_ONLY, 2147483647);
/*  67 */     if (this.buffers.size() == 1) {
/*  68 */       this.singleBuffer = this.buffers.get(0);
/*  69 */       this.isSingleBuffer = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private byte getByteByPosition(long position) {
/*  74 */     if (this.isSingleBuffer) {
/*  75 */       return this.singleBuffer.get((int)position);
/*     */     }
/*  77 */     int bufferIndex = (int)(position / 2147483647L);
/*  78 */     int bufferPosition = (int)(position % 2147483647L);
/*  79 */     return ((MappedByteBuffer)this.buffers.get(bufferIndex)).get(bufferPosition);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isResetSupported() {
/*  84 */     return true;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  88 */     this.position = 0L;
/*  89 */     this.recordIndex = 0L;
/*  90 */     this.recordType = null;
/*  91 */     this.recordText = null;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  95 */     if (this.channel != null && this.channel.isOpen()) {
/*  96 */       this.channel.close();
/*     */     }
/*  98 */     if (this.buffers != null && !this.buffers.isEmpty()) {
/*  99 */       this.buffers.clear();
/*     */     }
/* 101 */     this.singleBuffer = null;
/* 102 */     this.byteBuffer = null;
/* 103 */     this.fileSize = 0L;
/* 104 */     this.closed = true;
/* 105 */     System.gc();
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/* 109 */     if (this.position < this.fileSize) {
/* 110 */       return true;
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */   
/*     */   public Object next() {
/*     */     Object record;
/* 117 */     if (!hasNext()) {
/* 118 */       throw new NoSuchElementException("There are no more records to read");
/*     */     }
/*     */     
/* 121 */     this.byteBuffer.clear();
/* 122 */     boolean foundLineBreak = false;
/* 123 */     boolean foundEndOfFile = false;
/* 124 */     while (!foundLineBreak && !foundEndOfFile) {
/*     */       
/* 126 */       byte actualByte = getByteByPosition(this.position);
/* 127 */       if ((char)actualByte == '\r' || (char)actualByte == '\n') {
/* 128 */         foundLineBreak = true;
/* 129 */         if (this.position == this.fileSize - 1L) {
/* 130 */           foundEndOfFile = true;
/*     */         } else {
/* 132 */           byte nextByte = getByteByPosition(this.position + 1L);
/* 133 */           if ((char)nextByte == '\n') {
/* 134 */             this.position++;
/*     */           }
/*     */         } 
/*     */       } else {
/* 138 */         this.byteBuffer.put(actualByte);
/*     */       } 
/*     */       
/* 141 */       if (this.position == this.fileSize - 1L) {
/* 142 */         foundEndOfFile = true;
/*     */       }
/*     */       
/* 145 */       this.position++;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 150 */       this.byteBuffer.flip();
/* 151 */       CharBuffer charBuffer = this.decoder.decode(this.byteBuffer);
/* 152 */       record = parseRecordFromText(charBuffer.toString());
/* 153 */       this.recordText = charBuffer.toString();
/* 154 */       this.recordIndex++;
/* 155 */     } catch (IOException e) {
/* 156 */       throw new FFPojoException("Error while decoding the line number " + (this.recordIndex + 1L), e);
/* 157 */     } catch (RecordParserException e) {
/* 158 */       throw new FFPojoException("Error while parsing from text the line number " + (this.recordIndex + 1L), e);
/*     */     } 
/*     */     
/* 161 */     return record;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\reader\FileSystemFlatFileReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */