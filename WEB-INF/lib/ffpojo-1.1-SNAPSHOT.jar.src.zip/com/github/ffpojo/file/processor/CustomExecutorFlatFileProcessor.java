/*    */ package com.github.ffpojo.file.processor;
/*    */ 
/*    */ import com.github.ffpojo.exception.RecordProcessorException;
/*    */ import com.github.ffpojo.file.processor.record.RecordProcessor;
/*    */ import com.github.ffpojo.file.processor.record.event.DefaultRecordEvent;
/*    */ import com.github.ffpojo.file.processor.record.event.RecordEvent;
/*    */ import com.github.ffpojo.file.processor.record.handler.ErrorHandler;
/*    */ import com.github.ffpojo.file.reader.FlatFileReader;
/*    */ import com.github.ffpojo.file.reader.RecordType;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ 
/*    */ public class CustomExecutorFlatFileProcessor
/*    */   extends BaseFlatFileProcessor
/*    */   implements FlatFileProcessor {
/*    */   private ExecutorService executor;
/*    */   
/*    */   public CustomExecutorFlatFileProcessor(FlatFileReader flatFileReader, ExecutorService executor) {
/* 18 */     super(flatFileReader);
/* 19 */     if (executor == null || executor.isShutdown()) {
/* 20 */       throw new IllegalArgumentException("ExecutorService is null or shutdown");
/*    */     }
/* 22 */     this.executor = executor;
/*    */   }
/*    */   
/*    */   public void processFlatFile(final RecordProcessor processor) {
/* 26 */     for (Object record : this.flatFileReader) {
/* 27 */       final RecordType recordType = this.flatFileReader.getRecordType();
/* 28 */       final DefaultRecordEvent event = new DefaultRecordEvent(record, this.flatFileReader.getRecordText(), this.flatFileReader.getRecordIndex());
/* 29 */       this.executor.execute(new Runnable() {
/*    */             public void run() {
/*    */               try {
/* 32 */                 if (recordType == RecordType.HEADER) {
/* 33 */                   processor.processHeader(event);
/* 34 */                 } else if (recordType == RecordType.BODY) {
/* 35 */                   processor.processBody(event);
/* 36 */                 } else if (recordType == RecordType.TRAILER) {
/* 37 */                   processor.processTrailer(event);
/*    */                 } 
/* 39 */               } catch (RecordProcessorException e) {
/*    */                 try {
/* 41 */                   CustomExecutorFlatFileProcessor.this.errorHandler.error(e);
/* 42 */                 } catch (RecordProcessorException exThrownByErrorHandler) {
/* 43 */                   exThrownByErrorHandler.printStackTrace();
/*    */                 } 
/*    */               } 
/*    */             }
/*    */           });
/*    */     } 
/* 49 */     this.executor.shutdown();
/* 50 */     while (!this.executor.isTerminated())
/* 51 */       Thread.yield(); 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\processor\CustomExecutorFlatFileProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */