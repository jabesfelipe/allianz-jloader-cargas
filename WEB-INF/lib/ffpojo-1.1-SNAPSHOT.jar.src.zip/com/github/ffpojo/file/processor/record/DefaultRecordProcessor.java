package com.github.ffpojo.file.processor.record;

import com.github.ffpojo.exception.RecordProcessorException;
import com.github.ffpojo.file.processor.record.event.RecordEvent;

public class DefaultRecordProcessor implements RecordProcessor {
  public void processBody(RecordEvent event) throws RecordProcessorException {}
  
  public void processHeader(RecordEvent event) throws RecordProcessorException {}
  
  public void processTrailer(RecordEvent event) throws RecordProcessorException {}
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\processor\record\DefaultRecordProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */