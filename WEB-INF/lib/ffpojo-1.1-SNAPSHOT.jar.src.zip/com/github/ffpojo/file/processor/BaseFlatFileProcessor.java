/*    */ package com.github.ffpojo.file.processor;
/*    */ 
/*    */ import com.github.ffpojo.file.processor.record.handler.DefaultErrorHandler;
/*    */ import com.github.ffpojo.file.processor.record.handler.ErrorHandler;
/*    */ import com.github.ffpojo.file.reader.FlatFileReader;
/*    */ 
/*    */ abstract class BaseFlatFileProcessor
/*    */   implements FlatFileProcessor
/*    */ {
/*    */   protected FlatFileReader flatFileReader;
/*    */   protected ErrorHandler errorHandler;
/*    */   
/*    */   protected BaseFlatFileProcessor(FlatFileReader flatFileReader) {
/* 14 */     if (flatFileReader == null || flatFileReader.isClosed()) {
/* 15 */       throw new IllegalArgumentException("FlatFileReader object is null or closed");
/*    */     }
/* 17 */     this.errorHandler = (ErrorHandler)new DefaultErrorHandler();
/* 18 */     this.flatFileReader = flatFileReader;
/*    */   }
/*    */   
/*    */   public void setErrorHandler(ErrorHandler errorHandler) {
/* 22 */     this.errorHandler = errorHandler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\processor\BaseFlatFileProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */