package com.github.ffpojo.file.processor;

import com.github.ffpojo.file.processor.record.RecordProcessor;
import com.github.ffpojo.file.processor.record.handler.ErrorHandler;

public interface FlatFileProcessor {
  void processFlatFile(RecordProcessor paramRecordProcessor);
  
  void setErrorHandler(ErrorHandler paramErrorHandler);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\processor\FlatFileProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */