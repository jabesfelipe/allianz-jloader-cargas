/*    */ package com.github.ffpojo.file.processor;
/*    */ 
/*    */ import com.github.ffpojo.exception.RecordProcessorException;
/*    */ import com.github.ffpojo.file.processor.record.RecordProcessor;
/*    */ import com.github.ffpojo.file.processor.record.event.DefaultRecordEvent;
/*    */ import com.github.ffpojo.file.processor.record.event.RecordEvent;
/*    */ import com.github.ffpojo.file.processor.record.handler.ErrorHandler;
/*    */ import com.github.ffpojo.file.reader.FlatFileReader;
/*    */ import com.github.ffpojo.file.reader.RecordType;
/*    */ 
/*    */ public class DefaultFlatFileProcessor
/*    */   extends BaseFlatFileProcessor implements FlatFileProcessor {
/*    */   public DefaultFlatFileProcessor(FlatFileReader flatFileReader) {
/* 14 */     super(flatFileReader);
/*    */   }
/*    */   
/*    */   public void processFlatFile(RecordProcessor processor) {
/* 18 */     for (Object record : this.flatFileReader) {
/* 19 */       RecordType recordType = this.flatFileReader.getRecordType();
/* 20 */       DefaultRecordEvent defaultRecordEvent = new DefaultRecordEvent(record, this.flatFileReader.getRecordText(), this.flatFileReader.getRecordIndex());
/*    */       try {
/* 22 */         if (recordType == RecordType.HEADER) {
/* 23 */           processor.processHeader((RecordEvent)defaultRecordEvent); continue;
/* 24 */         }  if (recordType == RecordType.BODY) {
/* 25 */           processor.processBody((RecordEvent)defaultRecordEvent); continue;
/* 26 */         }  if (recordType == RecordType.TRAILER) {
/* 27 */           processor.processTrailer((RecordEvent)defaultRecordEvent);
/*    */         }
/* 29 */       } catch (RecordProcessorException e) {
/*    */         try {
/* 31 */           this.errorHandler.error(e);
/* 32 */         } catch (RecordProcessorException exThrownByErrorHandler) {
/* 33 */           exThrownByErrorHandler.printStackTrace();
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\processor\DefaultFlatFileProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */