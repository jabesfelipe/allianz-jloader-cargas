/*    */ package com.github.ffpojo.file.processor;
/*    */ 
/*    */ import com.github.ffpojo.exception.RecordProcessorException;
/*    */ import com.github.ffpojo.file.processor.record.RecordProcessor;
/*    */ import com.github.ffpojo.file.processor.record.event.DefaultRecordEvent;
/*    */ import com.github.ffpojo.file.processor.record.event.RecordEvent;
/*    */ import com.github.ffpojo.file.processor.record.handler.ErrorHandler;
/*    */ import com.github.ffpojo.file.reader.FlatFileReader;
/*    */ import com.github.ffpojo.file.reader.RecordType;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ 
/*    */ public class ThreadPoolFlatFileProcessor
/*    */   extends BaseFlatFileProcessor
/*    */   implements FlatFileProcessor {
/*    */   private ExecutorService executor;
/*    */   
/*    */   public ThreadPoolFlatFileProcessor(FlatFileReader flatFileReader, int threadPoolSize) {
/* 19 */     super(flatFileReader);
/* 20 */     this.executor = Executors.newFixedThreadPool(threadPoolSize);
/*    */   }
/*    */   
/*    */   public void processFlatFile(final RecordProcessor processor) {
/* 24 */     for (Object record : this.flatFileReader) {
/* 25 */       final RecordType recordType = this.flatFileReader.getRecordType();
/* 26 */       final DefaultRecordEvent event = new DefaultRecordEvent(record, this.flatFileReader.getRecordText(), this.flatFileReader.getRecordIndex());
/* 27 */       this.executor.execute(new Runnable() {
/*    */             public void run() {
/*    */               try {
/* 30 */                 if (recordType == RecordType.HEADER) {
/* 31 */                   processor.processHeader(event);
/* 32 */                 } else if (recordType == RecordType.BODY) {
/* 33 */                   processor.processBody(event);
/* 34 */                 } else if (recordType == RecordType.TRAILER) {
/* 35 */                   processor.processTrailer(event);
/*    */                 } 
/* 37 */               } catch (RecordProcessorException e) {
/*    */                 try {
/* 39 */                   ThreadPoolFlatFileProcessor.this.errorHandler.error(e);
/* 40 */                 } catch (RecordProcessorException exThrownByErrorHandler) {
/* 41 */                   exThrownByErrorHandler.printStackTrace();
/*    */                 } 
/*    */               } 
/*    */             }
/*    */           });
/*    */     } 
/* 47 */     this.executor.shutdown();
/* 48 */     while (!this.executor.isTerminated())
/* 49 */       Thread.yield(); 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\processor\ThreadPoolFlatFileProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */