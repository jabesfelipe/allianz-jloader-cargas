/*    */ package com.github.ffpojo.file.processor.record.event;
/*    */ 
/*    */ public class DefaultRecordEvent
/*    */   implements RecordEvent {
/*    */   private Object record;
/*    */   private String recordText;
/*    */   private long recordIndex;
/*    */   
/*    */   public DefaultRecordEvent(Object record, String recordText, long recordIndex) {
/* 10 */     this.record = record;
/* 11 */     this.recordText = recordText;
/* 12 */     this.recordIndex = recordIndex;
/*    */   }
/*    */   
/*    */   public Object getRecord() {
/* 16 */     return this.record;
/*    */   }
/*    */   
/*    */   public String getRecordText() {
/* 20 */     return this.recordText;
/*    */   }
/*    */   
/*    */   public long getRecordIndex() {
/* 24 */     return this.recordIndex;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\processor\record\event\DefaultRecordEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */