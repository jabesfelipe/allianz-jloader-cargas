package com.github.ffpojo.file.processor.record.event;

public interface RecordEvent {
  Object getRecord();
  
  String getRecordText();
  
  long getRecordIndex();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\file\processor\record\event\RecordEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */