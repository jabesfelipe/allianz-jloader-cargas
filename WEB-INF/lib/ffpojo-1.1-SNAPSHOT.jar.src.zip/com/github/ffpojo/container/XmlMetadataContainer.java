/*    */ package com.github.ffpojo.container;
/*    */ 
/*    */ import com.github.ffpojo.exception.MetadataContainerException;
/*    */ import com.github.ffpojo.exception.MetadataReaderException;
/*    */ import com.github.ffpojo.metadata.RecordDescriptor;
/*    */ import com.github.ffpojo.reader.XmlMetadataReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ class XmlMetadataContainer
/*    */   extends BaseMetadataContainer
/*    */   implements MetadataContainer
/*    */ {
/*    */   public XmlMetadataContainer(InputStream xmlMetadataInputStream) throws MetadataContainerException {
/* 15 */     XmlMetadataReader xmlMetadataReader = new XmlMetadataReader(xmlMetadataInputStream);
/*    */     try {
/* 17 */       this.recordDescriptorByClazzMap = xmlMetadataReader.readMetadata();
/* 18 */       xmlMetadataInputStream.close();
/* 19 */     } catch (MetadataReaderException e) {
/* 20 */       throw new MetadataContainerException("Error while reading ffpojo-ofm xml metadata", e);
/* 21 */     } catch (IOException e) {
/* 22 */       throw new MetadataContainerException("Error while reading ffpojo-ofm xml metadata", e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public RecordDescriptor getRecordDescriptor(Class<?> recordClazz) {
/* 27 */     return this.recordDescriptorByClazzMap.get(recordClazz);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\container\XmlMetadataContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */