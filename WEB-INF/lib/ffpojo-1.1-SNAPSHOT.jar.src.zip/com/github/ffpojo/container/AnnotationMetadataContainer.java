/*    */ package com.github.ffpojo.container;
/*    */ 
/*    */ import com.github.ffpojo.exception.MetadataContainerException;
/*    */ import com.github.ffpojo.exception.MetadataNotFoundException;
/*    */ import com.github.ffpojo.exception.MetadataReaderException;
/*    */ import com.github.ffpojo.metadata.RecordDescriptor;
/*    */ import com.github.ffpojo.reader.AnnotationMetadataReader;
/*    */ import com.github.ffpojo.reader.AnnotationMetadataReaderFactory;
/*    */ 
/*    */ class AnnotationMetadataContainer
/*    */   extends BaseMetadataContainer
/*    */   implements MetadataContainer {
/*    */   public RecordDescriptor getRecordDescriptor(Class<?> recordClazz) throws MetadataContainerException {
/* 14 */     RecordDescriptor recordDescriptor = this.recordDescriptorByClazzMap.get(recordClazz);
/* 15 */     if (recordDescriptor == null) {
/*    */       
/*    */       try {
/* 18 */         AnnotationMetadataReader annotationMetadataReader = AnnotationMetadataReaderFactory.createAnnotationMetadataReader(recordClazz);
/* 19 */         recordDescriptor = annotationMetadataReader.readMetadata();
/* 20 */         this.recordDescriptorByClazzMap.put(recordClazz, recordDescriptor);
/* 21 */       } catch (MetadataNotFoundException e) {
/* 22 */         recordDescriptor = null;
/* 23 */       } catch (MetadataReaderException e) {
/* 24 */         throw new MetadataContainerException("Error while reading annotation metadata for class " + recordClazz, e);
/*    */       } 
/*    */     }
/* 27 */     return recordDescriptor;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\container\AnnotationMetadataContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */