/*    */ package com.github.ffpojo.container;
/*    */ 
/*    */ import com.github.ffpojo.exception.MetadataContainerException;
/*    */ import com.github.ffpojo.metadata.RecordDescriptor;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HybridMetadataContainer
/*    */   extends BaseMetadataContainer
/*    */   implements MetadataContainer
/*    */ {
/*    */   private static final String XML_OFM_CLASSPATH = "ffpojo-ofm.xml";
/* 17 */   private MetadataContainer annotationMetadataContainer = new AnnotationMetadataContainer(); public HybridMetadataContainer() throws MetadataContainerException {
/* 18 */     InputStream xmlFileInputStream = getClass().getClassLoader().getResourceAsStream("ffpojo-ofm.xml");
/* 19 */     if (xmlFileInputStream != null)
/* 20 */       this.xmlMetadataContainer = new XmlMetadataContainer(xmlFileInputStream); 
/*    */   }
/*    */   private MetadataContainer xmlMetadataContainer;
/*    */   
/*    */   public RecordDescriptor getRecordDescriptor(Class<?> recordClazz) throws MetadataContainerException {
/* 25 */     RecordDescriptor recordDescriptor = this.recordDescriptorByClazzMap.get(recordClazz);
/* 26 */     if (recordDescriptor == null) {
/* 27 */       if (this.xmlMetadataContainer != null) {
/* 28 */         recordDescriptor = this.xmlMetadataContainer.getRecordDescriptor(recordClazz);
/*    */       }
/* 30 */       if (recordDescriptor == null) {
/* 31 */         recordDescriptor = this.annotationMetadataContainer.getRecordDescriptor(recordClazz);
/*    */       }
/* 33 */       if (recordDescriptor == null) {
/* 34 */         throw new MetadataContainerException("Object-Flat-Mapping metadata not found for class " + recordClazz);
/*    */       }
/* 36 */       this.recordDescriptorByClazzMap.put(recordClazz, recordDescriptor);
/*    */     } 
/*    */     
/* 39 */     return recordDescriptor;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\container\HybridMetadataContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */