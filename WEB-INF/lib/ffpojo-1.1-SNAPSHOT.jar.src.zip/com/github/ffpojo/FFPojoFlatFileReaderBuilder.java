/*     */ package com.github.ffpojo;
/*     */ 
/*     */ import com.github.ffpojo.dsl.AddClassBuilder;
/*     */ import com.github.ffpojo.dsl.FFPojoRandomReaderBuilder;
/*     */ import com.github.ffpojo.dsl.FFReaderBuilder;
/*     */ import com.github.ffpojo.dsl.ReadProcessor;
/*     */ import com.github.ffpojo.exception.FFPojoException;
/*     */ import com.github.ffpojo.exception.RecordProcessorException;
/*     */ import com.github.ffpojo.file.processor.ThreadPoolFlatFileProcessor;
/*     */ import com.github.ffpojo.file.processor.record.DefaultRecordProcessor;
/*     */ import com.github.ffpojo.file.processor.record.RecordProcessor;
/*     */ import com.github.ffpojo.file.processor.record.event.RecordEvent;
/*     */ import com.github.ffpojo.file.reader.FlatFileReader;
/*     */ import com.github.ffpojo.file.reader.FlatFileReaderDefinition;
/*     */ import com.github.ffpojo.file.reader.InputStreamFlatFileReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FFPojoFlatFileReaderBuilder
/*     */ {
/*  29 */   private final Set<Class> classes = (Set)new HashSet<Class<?>>();
/*     */   
/*     */   public AddClassBuilder withFile(final File file) {
/*  32 */     return new AddClassBuilder()
/*     */       {
/*     */         public FFReaderBuilder withRecordClasses(List<Class<?>> clazz) {
/*  35 */           FFPojoFlatFileReaderBuilder.this.classes.addAll(clazz);
/*  36 */           return FFPojoFlatFileReaderBuilder.this.read(file);
/*     */         }
/*     */         
/*     */         public FFReaderBuilder withRecordClass(Class<?> clazz) {
/*  40 */           FFPojoFlatFileReaderBuilder.this.classes.add(clazz);
/*  41 */           return FFPojoFlatFileReaderBuilder.this.read(file);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public AddClassBuilder withInputStream(final InputStream inputStream) {
/*  47 */     return new AddClassBuilder() {
/*     */         public FFReaderBuilder withRecordClasses(List<Class<?>> clazz) {
/*  49 */           FFPojoFlatFileReaderBuilder.this.classes.addAll(clazz);
/*  50 */           return FFPojoFlatFileReaderBuilder.this.read(inputStream);
/*     */         }
/*     */         
/*     */         public FFReaderBuilder withRecordClass(Class<?> clazz) {
/*  54 */           FFPojoFlatFileReaderBuilder.this.classes.add(clazz);
/*  55 */           return FFPojoFlatFileReaderBuilder.this.read(inputStream);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private FFReaderBuilder read(File file) {
/*     */     try {
/*  62 */       return read(new FileInputStream(file));
/*  63 */     } catch (Exception e) {
/*  64 */       throw new FFPojoException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private FFReaderBuilder read(final InputStream inputStream) throws FFPojoException {
/*  69 */     return new FFReaderBuilder() {
/*     */         public List<?> read() {
/*  71 */           final List<?> itens = new ArrayList();
/*  72 */           read(new ReadProcessor() {
/*     */                 public void process(Object item) {
/*  74 */                   itens.add(item);
/*     */                 }
/*     */               });
/*  77 */           return itens;
/*     */         }
/*     */         public void read(ReadProcessor processor) {
/*     */           InputStreamFlatFileReader inputStreamFlatFileReader;
/*  81 */           FlatFileReader reader = null;
/*     */           try {
/*  83 */             inputStreamFlatFileReader = new InputStreamFlatFileReader(inputStream, new FlatFileReaderDefinition(FFPojoFlatFileReaderBuilder.this.classes));
/*  84 */             while (inputStreamFlatFileReader.hasNext()) {
/*  85 */               processor.process(inputStreamFlatFileReader.next());
/*     */             }
/*  87 */           } catch (Exception e) {
/*  88 */             throw new FFPojoException(e);
/*     */           } finally {
/*     */             try {
/*  91 */               if (inputStreamFlatFileReader != null) {
/*  92 */                 inputStreamFlatFileReader.close();
/*     */               }
/*  94 */             } catch (IOException e) {
/*  95 */               throw new FFPojoException(e);
/*     */             } 
/*     */           } 
/*     */         }
/*     */         
/*     */         public FFPojoRandomReaderBuilder withThreads(final int qtdeThreads) {
/* 101 */           return new FFPojoRandomReaderBuilder() {
/*     */               public List<?> randomRead() {
/* 103 */                 final List<?> itens = new ArrayList();
/* 104 */                 randomRead(new ReadProcessor() {
/*     */                       public void process(Object item) {
/* 106 */                         itens.add(item);
/*     */                       }
/*     */                     });
/* 109 */                 return itens;
/*     */               }
/*     */               public void randomRead(final ReadProcessor processor) {
/*     */                 InputStreamFlatFileReader inputStreamFlatFileReader;
/* 113 */                 FlatFileReader reader = null;
/*     */                 try {
/* 115 */                   inputStream.available();
/* 116 */                   if (isClosed(inputStream) && inputStream.markSupported()) {
/* 117 */                     inputStream.reset();
/*     */                   }
/* 119 */                   inputStreamFlatFileReader = inputStreamFlatFileReader = new InputStreamFlatFileReader(inputStream, new FlatFileReaderDefinition(FFPojoFlatFileReaderBuilder.this.classes));
/* 120 */                   ThreadPoolFlatFileProcessor threadPoolFlatFileProcessor = new ThreadPoolFlatFileProcessor((FlatFileReader)inputStreamFlatFileReader, qtdeThreads);
/* 121 */                   synchronized (this) {
/* 122 */                     threadPoolFlatFileProcessor.processFlatFile((RecordProcessor)new DefaultRecordProcessor()
/*     */                         {
/*     */                           public void processBody(RecordEvent event) throws RecordProcessorException {
/* 125 */                             processor.process(event.getRecord());
/*     */                           }
/*     */                         });
/*     */                   } 
/* 129 */                 } catch (Exception e) {
/* 130 */                   throw new FFPojoException(e);
/*     */                 } finally {
/*     */                   try {
/* 133 */                     if (inputStreamFlatFileReader != null) {
/* 134 */                       inputStreamFlatFileReader.close();
/*     */                     }
/* 136 */                   } catch (IOException e) {
/* 137 */                     throw new FFPojoException(e);
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */ 
/*     */               
/*     */               private boolean isClosed(InputStream inputStream) {
/*     */                 try {
/* 145 */                   return (inputStream.available() == 0);
/* 146 */                 } catch (IOException e) {
/* 147 */                   return true;
/*     */                 } 
/*     */               }
/*     */             };
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\FFPojoFlatFileReaderBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */