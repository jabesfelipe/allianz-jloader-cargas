/*     */ package com.github.ffpojo.parser;
/*     */ 
/*     */ import com.github.ffpojo.exception.FFPojoException;
/*     */ import com.github.ffpojo.exception.FieldDecoratorException;
/*     */ import com.github.ffpojo.exception.RecordParserException;
/*     */ import com.github.ffpojo.metadata.FieldDecorator;
/*     */ import com.github.ffpojo.metadata.RecordDescriptor;
/*     */ import com.github.ffpojo.metadata.positional.PositionalFieldDescriptor;
/*     */ import com.github.ffpojo.metadata.positional.PositionalRecordDescriptor;
/*     */ import com.github.ffpojo.util.ReflectUtil;
/*     */ import com.github.ffpojo.util.StringUtil;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PositionalRecordParser
/*     */   extends BaseRecordParser
/*     */   implements RecordParser
/*     */ {
/*     */   public PositionalRecordParser(PositionalRecordDescriptor recordDescriptor) {
/*  24 */     super((RecordDescriptor)recordDescriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PositionalRecordParser() {}
/*     */ 
/*     */   
/*     */   public <T> T parseFromText(Class<T> recordClazz, String text) throws RecordParserException {
/*  33 */     T record = createRecordInstance(recordClazz);
/*  34 */     List<PositionalFieldDescriptor> positionalFieldDescriptors = getRecordDescriptor().getFieldDescriptors();
/*     */     
/*  36 */     for (int i = 0; i < positionalFieldDescriptors.size(); i++) {
/*  37 */       PositionalFieldDescriptor actualFieldDescriptor = positionalFieldDescriptors.get(i);
/*  38 */       PositionalFieldDescriptor previousFieldDescriptor = readPreviousFieldDescriptors(positionalFieldDescriptors, i);
/*  39 */       String fieldValue = readFieldValue(text, actualFieldDescriptor, previousFieldDescriptor);
/*     */       
/*  41 */       if (actualFieldDescriptor.isByField()) {
/*  42 */         setValueByFieldFromText(record, actualFieldDescriptor, fieldValue);
/*     */       } else {
/*  44 */         setValueByPropertyFromText(recordClazz, record, actualFieldDescriptor, fieldValue);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  49 */     return record;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> String parseToText(T record) throws RecordParserException {
/*  54 */     StringBuffer sbufRecordLine = new StringBuffer();
/*  55 */     List<PositionalFieldDescriptor> positionalFieldDescriptors = getRecordDescriptor().getFieldDescriptors();
/*     */     
/*  57 */     for (int i = 0; i < positionalFieldDescriptors.size(); i++) {
/*  58 */       PositionalFieldDescriptor actualFieldDescriptor = positionalFieldDescriptors.get(i);
/*     */       
/*  60 */       PositionalFieldDescriptor previousFieldDescriptor = readPreviousFieldDescriptors(positionalFieldDescriptors, i);
/*  61 */       boolean isFirstFieldDescriptor = (previousFieldDescriptor == null);
/*     */       
/*  63 */       String fieldValue = readFieldValueFromRecord(record, actualFieldDescriptor);
/*  64 */       int fieldLength = actualFieldDescriptor.getFinalPosition() - actualFieldDescriptor.getInitialPosition() + 1;
/*  65 */       String sizedFieldValue = StringUtil.fillToLength(fieldValue, fieldLength, actualFieldDescriptor.getPaddingCharacter(), StringUtil.Direction.valueOf(actualFieldDescriptor.getPaddingAlign().toString()));
/*  66 */       if (actualFieldDescriptor.isRemainPosition()) {
/*  67 */         sizedFieldValue = fieldValue;
/*     */       }
/*     */ 
/*     */       
/*  71 */       if (isFirstFieldDescriptor && actualFieldDescriptor.getInitialPosition() > 1) {
/*  72 */         int blankSpaces = actualFieldDescriptor.getInitialPosition() - 1;
/*  73 */         sizedFieldValue = StringUtil.fillToLength(sizedFieldValue, blankSpaces + fieldLength, ' ', StringUtil.Direction.LEFT);
/*  74 */       } else if (!isFirstFieldDescriptor && previousFieldDescriptor.getFinalPosition() < actualFieldDescriptor.getInitialPosition() - 1) {
/*  75 */         int blankSpaces = actualFieldDescriptor.getInitialPosition() - previousFieldDescriptor.getFinalPosition() - 1;
/*  76 */         sizedFieldValue = StringUtil.fillToLength(sizedFieldValue, blankSpaces + fieldLength, ' ', StringUtil.Direction.LEFT);
/*     */       } 
/*  78 */       sbufRecordLine.append(sizedFieldValue);
/*     */     } 
/*     */     
/*  81 */     return sbufRecordLine.toString();
/*     */   }
/*     */   
/*     */   private PositionalFieldDescriptor readPreviousFieldDescriptors(List<PositionalFieldDescriptor> positionalFieldDescriptors, int indexActualFieldDescriptor) {
/*  85 */     boolean isFirstFieldDescriptor = (indexActualFieldDescriptor == 0);
/*  86 */     PositionalFieldDescriptor previousFieldDescriptor = null;
/*  87 */     if (!isFirstFieldDescriptor) {
/*  88 */       previousFieldDescriptor = positionalFieldDescriptors.get(indexActualFieldDescriptor - 1);
/*     */     }
/*  90 */     return previousFieldDescriptor;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T createRecordInstance(Class<T> recordClazz) {
/*     */     T record;
/*     */     try {
/*  97 */       record = recordClazz.newInstance();
/*  98 */     } catch (Exception e) {
/*  99 */       throw new RecordParserException("Error while instantiating record class, make sure that is provided a default constructor for class " + recordClazz, e);
/*     */     } 
/* 101 */     return record;
/*     */   }
/*     */   
/*     */   private String readFieldValueFromRecord(Object record, PositionalFieldDescriptor actualFieldDescriptor) {
/* 105 */     Object fieldValueObj = readFieldValueObject(record, actualFieldDescriptor);
/* 106 */     return applyDecorator(actualFieldDescriptor, fieldValueObj);
/*     */   }
/*     */   
/*     */   private String applyDecorator(PositionalFieldDescriptor actualFieldDescriptor, Object fieldValueObj) {
/*     */     String fieldValue;
/* 111 */     if (fieldValueObj == null) {
/* 112 */       fieldValue = "";
/*     */     } else {
/*     */       try {
/* 115 */         FieldDecorator<Object> decorator = actualFieldDescriptor.getDecorator();
/* 116 */         fieldValue = decorator.toString(fieldValueObj);
/* 117 */       } catch (FieldDecoratorException e) {
/* 118 */         throw new RecordParserException(e);
/*     */       } 
/*     */     } 
/* 121 */     return fieldValue;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> Object readFieldValueObject(T record, PositionalFieldDescriptor actualFieldDescriptor) {
/*     */     Object fieldValueObj;
/* 127 */     if (actualFieldDescriptor.isByField()) {
/* 128 */       fieldValueObj = readValueObjectByField(record, actualFieldDescriptor);
/*     */     } else {
/* 130 */       fieldValueObj = readFieldValueObjectByProperty(record, actualFieldDescriptor);
/*     */     } 
/* 132 */     return fieldValueObj;
/*     */   }
/*     */   
/*     */   private <T> Object readFieldValueObjectByProperty(T record, PositionalFieldDescriptor actualFieldDescriptor) {
/*     */     Object fieldValueObj;
/* 137 */     Method getter = actualFieldDescriptor.getGetter();
/*     */     try {
/* 139 */       fieldValueObj = getter.invoke(record, new Object[0]);
/* 140 */     } catch (Exception e) {
/* 141 */       throw new RecordParserException("Error while invoking getter method: " + getter, e);
/*     */     } 
/* 143 */     return fieldValueObj;
/*     */   }
/*     */   
/*     */   private <T> Object readValueObjectByField(T record, PositionalFieldDescriptor actualFieldDescriptor) {
/*     */     Object fieldValueObj;
/* 148 */     Field field = actualFieldDescriptor.getField();
/* 149 */     field.setAccessible(true);
/*     */     try {
/* 151 */       fieldValueObj = field.get(record);
/* 152 */     } catch (Exception e) {
/* 153 */       throw new RecordParserException("Error while reading value on field: " + field.getName());
/*     */     } 
/* 155 */     return fieldValueObj;
/*     */   }
/*     */ 
/*     */   
/*     */   private String applyTrimOnRead(String fieldValue, PositionalFieldDescriptor actualFieldDescriptor) {
/* 160 */     if (actualFieldDescriptor.isTrimOnRead()) {
/* 161 */       fieldValue = fieldValue.trim();
/*     */     }
/* 163 */     return fieldValue;
/*     */   }
/*     */   
/*     */   private <T> void setValueByPropertyFromText(Class<T> recordClazz, T record, PositionalFieldDescriptor actualFieldDescriptor, String fieldValue) {
/*     */     Method setter;
/* 168 */     Class<?> getterReturnType = actualFieldDescriptor.getGetter().getReturnType();
/*     */     try {
/* 170 */       setter = ReflectUtil.getSetterFromGetter(actualFieldDescriptor.getGetter(), new Class[] { String.class }, recordClazz);
/* 171 */     } catch (NoSuchMethodException e1) {
/*     */       try {
/* 173 */         setter = ReflectUtil.getSetterFromGetter(actualFieldDescriptor.getGetter(), new Class[] { getterReturnType }, recordClazz);
/* 174 */       } catch (NoSuchMethodException e2) {
/* 175 */         throw new RecordParserException("Compatible setter not found for getter " + actualFieldDescriptor.getGetter(), e2);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 180 */       FieldDecorator<?> decorator = actualFieldDescriptor.getDecorator();
/* 181 */       Object parameter = decorator.fromString(fieldValue);
/* 182 */       setter.invoke(record, new Object[] { parameter });
/* 183 */     } catch (FieldDecoratorException e) {
/* 184 */       throw new RecordParserException(e);
/* 185 */     } catch (Exception e) {
/* 186 */       throw new RecordParserException("Error while invoking setter method, make sure that is provided a compatible fromString decorator method: " + setter, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private <T> void setValueByFieldFromText(T record, PositionalFieldDescriptor actualFieldDescriptor, String fieldValue) {
/* 191 */     Field field = actualFieldDescriptor.getField();
/* 192 */     field.setAccessible(true);
/*     */     try {
/* 194 */       Object value = actualFieldDescriptor.getDecorator().fromString(fieldValue);
/* 195 */       field.set(record, value);
/* 196 */     } catch (Exception e) {
/* 197 */       throw new FFPojoException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String readFieldValue(String text, PositionalFieldDescriptor actualFieldDescriptor, PositionalFieldDescriptor previousFieldDescriptor) {
/* 202 */     String fieldValue = "";
/* 203 */     int initialIndex = 0;
/* 204 */     int finalIndex = 0; actualFieldDescriptor.getFinalPosition();
/* 205 */     if (actualFieldDescriptor.isRemainPosition()) {
/* 206 */       if (previousFieldDescriptor != null && 
/* 207 */         text.length() > previousFieldDescriptor.getFinalPosition()) {
/* 208 */         initialIndex = previousFieldDescriptor.getFinalPosition();
/*     */       }
/*     */       
/* 211 */       finalIndex = text.length();
/* 212 */       fieldValue = text.substring(initialIndex, finalIndex);
/*     */     } else {
/* 214 */       initialIndex = actualFieldDescriptor.getInitialPosition() - 1;
/* 215 */       finalIndex = actualFieldDescriptor.getFinalPosition();
/* 216 */       if (text.length() < finalIndex) {
/* 217 */         if (!((PositionalRecordDescriptor)this.recordDescriptor).isIgnorePositionNotFound()) {
/* 218 */           throw new RecordParserException("The text length is less than the declared length in field mapping: " + actualFieldDescriptor.getGetter());
/*     */         }
/* 220 */         if (text.length() > initialIndex && initialIndex >= 0) {
/* 221 */           fieldValue = text.substring(initialIndex);
/*     */         }
/*     */       } else {
/* 224 */         fieldValue = text.substring(initialIndex, finalIndex);
/*     */       } 
/*     */     } 
/*     */     
/* 228 */     return applyTrimOnRead(fieldValue, actualFieldDescriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected PositionalRecordDescriptor getRecordDescriptor() {
/* 233 */     return (PositionalRecordDescriptor)this.recordDescriptor;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\parser\PositionalRecordParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */