/*    */ package com.github.ffpojo.parser;
/*    */ 
/*    */ import com.github.ffpojo.metadata.RecordDescriptor;
/*    */ import com.github.ffpojo.metadata.delimited.DelimitedRecordDescriptor;
/*    */ import com.github.ffpojo.metadata.positional.PositionalRecordDescriptor;
/*    */ 
/*    */ public class RecordParserFactory
/*    */ {
/*    */   public static RecordParser createRecordParser(RecordDescriptor recordDescriptor) {
/* 10 */     if (recordDescriptor instanceof PositionalRecordDescriptor)
/* 11 */       return new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor); 
/* 12 */     if (recordDescriptor instanceof DelimitedRecordDescriptor) {
/* 13 */       return new DelimitedRecordParser((DelimitedRecordDescriptor)recordDescriptor);
/*    */     }
/* 15 */     throw new IllegalArgumentException("RecordParser not found for class " + recordDescriptor.getClass());
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\parser\RecordParserFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */