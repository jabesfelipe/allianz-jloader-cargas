/*     */ package com.github.ffpojo.parser;
/*     */ 
/*     */ import com.github.ffpojo.exception.FFPojoException;
/*     */ import com.github.ffpojo.exception.FieldDecoratorException;
/*     */ import com.github.ffpojo.exception.RecordParserException;
/*     */ import com.github.ffpojo.metadata.FieldDecorator;
/*     */ import com.github.ffpojo.metadata.RecordDescriptor;
/*     */ import com.github.ffpojo.metadata.delimited.DelimitedFieldDescriptor;
/*     */ import com.github.ffpojo.metadata.delimited.DelimitedRecordDescriptor;
/*     */ import com.github.ffpojo.metadata.positional.annotation.AccessorType;
/*     */ import com.github.ffpojo.util.ReflectUtil;
/*     */ import com.github.ffpojo.util.RegexUtil;
/*     */ import com.github.ffpojo.util.StringUtil;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ 
/*     */ class DelimitedRecordParser
/*     */   extends BaseRecordParser
/*     */   implements RecordParser
/*     */ {
/*     */   public DelimitedRecordParser(DelimitedRecordDescriptor recordDescriptor) {
/*  23 */     super((RecordDescriptor)recordDescriptor);
/*     */   }
/*     */   
/*     */   public <T> T parseFromText(Class<T> recordClazz, String text) throws RecordParserException {
/*     */     T record;
/*     */     try {
/*  29 */       record = recordClazz.newInstance();
/*  30 */     } catch (Exception e) {
/*  31 */       throw new RecordParserException("Error while instantiating record class, make sure that is provided a default constructor for class " + recordClazz, e);
/*     */     } 
/*     */     
/*  34 */     List<DelimitedFieldDescriptor> delimitedFieldDescriptors = getRecordDescriptor().getFieldDescriptors();
/*  35 */     String[] textTokens = text.split(RegexUtil.escapeRegexMetacharacters(getRecordDescriptor().getDelimiter()));
/*  36 */     int tokensQtt = textTokens.length;
/*  37 */     for (int i = 0; i < delimitedFieldDescriptors.size(); i++) {
/*  38 */       String fieldValue; DelimitedFieldDescriptor actualFieldDescriptor = delimitedFieldDescriptors.get(i);
/*     */ 
/*     */       
/*  41 */       if (actualFieldDescriptor.getPositionIndex() <= tokensQtt) {
/*  42 */         fieldValue = textTokens[actualFieldDescriptor.getPositionIndex() - 1];
/*     */       } else {
/*  44 */         throw new RecordParserException("The position declared in field-mapping is greater than the text tokens amount: " + actualFieldDescriptor.getGetter());
/*     */       } 
/*     */       
/*  47 */       if (actualFieldDescriptor.getAccessorType().equals(AccessorType.FIELD)) {
/*  48 */         Field field = actualFieldDescriptor.getField();
/*  49 */         field.setAccessible(true);
/*     */         try {
/*  51 */           Object value = actualFieldDescriptor.getDecorator().fromString(fieldValue);
/*  52 */           field.set(record, value);
/*  53 */         } catch (Exception e) {
/*  54 */           throw new FFPojoException(e);
/*     */         } 
/*     */       } else {
/*     */         Method setter;
/*  58 */         Class<?> getterReturnType = actualFieldDescriptor.getGetter().getReturnType();
/*     */         try {
/*  60 */           setter = ReflectUtil.getSetterFromGetter(actualFieldDescriptor.getGetter(), new Class[] { String.class }, recordClazz);
/*  61 */         } catch (NoSuchMethodException e1) {
/*     */           try {
/*  63 */             setter = ReflectUtil.getSetterFromGetter(actualFieldDescriptor.getGetter(), new Class[] { getterReturnType }, recordClazz);
/*  64 */           } catch (NoSuchMethodException e2) {
/*  65 */             throw new RecordParserException("Compatible setter not found for getter " + actualFieldDescriptor.getGetter(), e2);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/*  71 */           FieldDecorator<?> decorator = actualFieldDescriptor.getDecorator();
/*  72 */           Object parameter = decorator.fromString(fieldValue);
/*  73 */           if (setter != null)
/*  74 */             setter.invoke(record, new Object[] { parameter }); 
/*  75 */         } catch (FieldDecoratorException e) {
/*  76 */           throw new RecordParserException(e);
/*  77 */         } catch (Exception e) {
/*  78 */           throw new RecordParserException("Error while invoking setter method, make sure that is provided a compatible fromString decorator method: " + setter, e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     return record;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> String parseToText(T record) throws RecordParserException {
/*  91 */     StringBuffer sbufRecordLine = new StringBuffer();
/*     */     
/*  93 */     List<DelimitedFieldDescriptor> delimitedFieldDescriptors = getRecordDescriptor().getFieldDescriptors();
/*  94 */     for (int i = 0; i < delimitedFieldDescriptors.size(); i++) {
/*  95 */       Object fieldValueObj; String fieldValue; DelimitedFieldDescriptor actualFieldDescriptor = delimitedFieldDescriptors.get(i);
/*     */       
/*  97 */       boolean isFirstFieldDescriptor = (i == 0);
/*  98 */       DelimitedFieldDescriptor previousFieldDescriptor = null;
/*  99 */       if (!isFirstFieldDescriptor) {
/* 100 */         previousFieldDescriptor = delimitedFieldDescriptors.get(i - 1);
/*     */       }
/*     */       
/* 103 */       Method getter = actualFieldDescriptor.getGetter();
/*     */       
/*     */       try {
/* 106 */         fieldValueObj = getter.invoke(record, new Object[0]);
/* 107 */       } catch (Exception e) {
/* 108 */         throw new RecordParserException("Error while invoking getter method: " + getter, e);
/*     */       } 
/*     */ 
/*     */       
/* 112 */       if (fieldValueObj == null) {
/* 113 */         fieldValue = "";
/*     */       } else {
/*     */         try {
/* 116 */           FieldDecorator<Object> decorator = actualFieldDescriptor.getDecorator();
/* 117 */           fieldValue = decorator.toString(fieldValueObj);
/* 118 */         } catch (FieldDecoratorException e) {
/* 119 */           throw new RecordParserException(e);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 124 */       if (isFirstFieldDescriptor && actualFieldDescriptor.getPositionIndex() > 1) {
/* 125 */         int missingFields = actualFieldDescriptor.getPositionIndex() - 1;
/* 126 */         sbufRecordLine.append(StringUtil.fillToLength("", missingFields, ',', StringUtil.Direction.RIGHT));
/* 127 */       } else if (!isFirstFieldDescriptor && previousFieldDescriptor.getPositionIndex() < actualFieldDescriptor.getPositionIndex() - 1) {
/* 128 */         int missingFields = actualFieldDescriptor.getPositionIndex() - previousFieldDescriptor.getPositionIndex() - 1;
/* 129 */         sbufRecordLine.append(StringUtil.fillToLength("", missingFields, ',', StringUtil.Direction.RIGHT));
/*     */       } 
/*     */       
/* 132 */       sbufRecordLine.append(fieldValue);
/* 133 */       if (i < delimitedFieldDescriptors.size() - 1) {
/* 134 */         sbufRecordLine.append(getRecordDescriptor().getDelimiter());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 139 */     return sbufRecordLine.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected DelimitedRecordDescriptor getRecordDescriptor() {
/* 144 */     return (DelimitedRecordDescriptor)this.recordDescriptor;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ffpojo-1.1-SNAPSHOT.jar!\com\github\ffpojo\parser\DelimitedRecordParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */