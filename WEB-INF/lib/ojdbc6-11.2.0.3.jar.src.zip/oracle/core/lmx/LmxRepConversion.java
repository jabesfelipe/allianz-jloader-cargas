/*     */ package oracle.core.lmx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LmxRepConversion
/*     */ {
/*     */   public static void printInHex(byte paramByte) {
/*  28 */     System.out.print((char)nibbleToHex((byte)((paramByte & 0xF0) >> 4)));
/*  29 */     System.out.print((char)nibbleToHex((byte)(paramByte & 0xF)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte nibbleToHex(byte paramByte) {
/*  43 */     paramByte = (byte)(paramByte & 0xF);
/*  44 */     return (byte)((paramByte < 10) ? (paramByte + 48) : (paramByte - 10 + 65));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte asciiHexToNibble(byte paramByte) {
/*     */     byte b;
/*  64 */     if (paramByte >= 97 && paramByte <= 102) {
/*  65 */       b = (byte)(paramByte - 97 + 10);
/*     */     }
/*  67 */     else if (paramByte >= 65 && paramByte <= 70) {
/*  68 */       b = (byte)(paramByte - 65 + 10);
/*     */     }
/*  70 */     else if (paramByte >= 48 && paramByte <= 57) {
/*  71 */       b = (byte)(paramByte - 48);
/*     */     } else {
/*     */       
/*  74 */       b = paramByte;
/*     */     } 
/*  76 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void bArray2nibbles(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/*  88 */     for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/*     */       
/*  90 */       paramArrayOfbyte2[b * 2] = nibbleToHex((byte)((paramArrayOfbyte1[b] & 0xF0) >> 4));
/*  91 */       paramArrayOfbyte2[b * 2 + 1] = nibbleToHex((byte)(paramArrayOfbyte1[b] & 0xF));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bArray2String(byte[] paramArrayOfbyte) {
/* 104 */     StringBuffer stringBuffer = new StringBuffer(paramArrayOfbyte.length * 2);
/* 105 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/*     */       
/* 107 */       stringBuffer.append((char)nibbleToHex((byte)((paramArrayOfbyte[b] & 0xF0) >> 4)));
/* 108 */       stringBuffer.append((char)nibbleToHex((byte)(paramArrayOfbyte[b] & 0xF)));
/*     */     } 
/* 110 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] nibbles2bArray(byte[] paramArrayOfbyte) {
/* 124 */     byte[] arrayOfByte = new byte[paramArrayOfbyte.length / 2];
/*     */ 
/*     */     
/* 127 */     for (byte b = 0; b < arrayOfByte.length; b++) {
/*     */       
/* 129 */       arrayOfByte[b] = (byte)(asciiHexToNibble(paramArrayOfbyte[b * 2]) << 4);
/* 130 */       arrayOfByte[b] = (byte)(arrayOfByte[b] | asciiHexToNibble(paramArrayOfbyte[b * 2 + 1]));
/*     */     } 
/* 132 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void printInHex(long paramLong) {
/* 137 */     byte[] arrayOfByte = toHex(paramLong);
/* 138 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void printInHex(int paramInt) {
/* 143 */     byte[] arrayOfByte = toHex(paramInt);
/* 144 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void printInHex(short paramShort) {
/* 149 */     byte[] arrayOfByte = toHex(paramShort);
/* 150 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] toHex(long paramLong) {
/* 155 */     byte b = 16;
/* 156 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 158 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 160 */       arrayOfByte[i] = nibbleToHex((byte)(int)(paramLong & 0xFL));
/* 161 */       paramLong >>= 4L;
/*     */     } 
/* 163 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] toHex(int paramInt) {
/* 168 */     byte b = 8;
/* 169 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 171 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 173 */       arrayOfByte[i] = nibbleToHex((byte)(paramInt & 0xF));
/* 174 */       paramInt >>= 4;
/*     */     } 
/* 176 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] toHex(short paramShort) {
/* 181 */     byte b = 4;
/* 182 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 184 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 186 */       arrayOfByte[i] = nibbleToHex((byte)(paramShort & 0xF));
/* 187 */       paramShort = (short)(paramShort >> 4);
/*     */     } 
/* 189 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\core\lmx\LmxRepConversion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */