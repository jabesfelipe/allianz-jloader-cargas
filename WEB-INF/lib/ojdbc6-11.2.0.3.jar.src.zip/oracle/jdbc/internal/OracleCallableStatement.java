package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.SQLException;
import oracle.jdbc.OracleCallableStatement;

public interface OracleCallableStatement extends OracleCallableStatement, OraclePreparedStatement {
  byte[] privateGetBytes(int paramInt) throws SQLException;
  
  BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException;
  
  InputStream getAsciiStream(String paramString) throws SQLException;
  
  Reader getCharacterStream(String paramString) throws SQLException;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\OracleCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */