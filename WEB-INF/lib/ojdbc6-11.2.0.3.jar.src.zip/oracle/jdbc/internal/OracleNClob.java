package oracle.jdbc.internal;

import oracle.jdbc.OracleNClob;

public interface OracleNClob extends OracleDatumWithConnection, OracleNClob, OracleClob {}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\OracleNClob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */