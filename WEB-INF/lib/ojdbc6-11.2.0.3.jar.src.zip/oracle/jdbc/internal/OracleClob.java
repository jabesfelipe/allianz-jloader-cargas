package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleClob;
import oracle.sql.ClobDBAccess;

public interface OracleClob extends OracleDatumWithConnection, OracleClob {
  InputStream getAsciiStream(long paramLong) throws SQLException;
  
  Reader getCharacterStream(long paramLong) throws SQLException;
  
  boolean isNCLOB();
  
  int getChars(long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException;
  
  int putChars(long paramLong, char[] paramArrayOfchar) throws SQLException;
  
  int putChars(long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException;
  
  int putString(long paramLong, String paramString) throws SQLException;
  
  int getChunkSize() throws SQLException;
  
  int getBufferSize() throws SQLException;
  
  Object toJdbc() throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Reader characterStreamValue() throws SQLException;
  
  InputStream asciiStreamValue() throws SQLException;
  
  InputStream binaryStreamValue() throws SQLException;
  
  String stringValue() throws SQLException;
  
  void trim(long paramLong) throws SQLException;
  
  OutputStream getAsciiOutputStream(long paramLong) throws SQLException;
  
  Writer getCharacterOutputStream(long paramLong) throws SQLException;
  
  Writer getCharacterOutputStream() throws SQLException;
  
  OutputStream getAsciiOutputStream() throws SQLException;
  
  byte[] getLocator();
  
  void setLocator(byte[] paramArrayOfbyte);
  
  Object makeJdbcArray(int paramInt);
  
  ClobDBAccess getDBAccess() throws SQLException;
  
  Connection getJavaSqlConnection() throws SQLException;
  
  void setLength(long paramLong);
  
  void setChunkSize(int paramInt);
  
  void setPrefetchedData(char[] paramArrayOfchar);
  
  void setPrefetchedData(char[] paramArrayOfchar, int paramInt);
  
  char[] getPrefetchedData();
  
  int getPrefetchedDataSize();
  
  void setActivePrefetch(boolean paramBoolean);
  
  void clearCachedData();
  
  boolean isActivePrefetch();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\OracleClob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */