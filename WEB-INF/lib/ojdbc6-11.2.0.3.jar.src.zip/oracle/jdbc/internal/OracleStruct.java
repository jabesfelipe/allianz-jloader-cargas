package oracle.jdbc.internal;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Map;
import oracle.jdbc.OracleStruct;
import oracle.sql.Datum;
import oracle.sql.ORADataFactory;
import oracle.sql.StructDescriptor;

public interface OracleStruct extends OracleDatumWithConnection, OracleStruct {
  StructDescriptor getDescriptor() throws SQLException;
  
  void setDescriptor(StructDescriptor paramStructDescriptor);
  
  Datum[] getOracleAttributes() throws SQLException;
  
  Map getMap();
  
  byte[] toBytes() throws SQLException;
  
  void setDatumArray(Datum[] paramArrayOfDatum);
  
  void setObjArray(Object[] paramArrayOfObject) throws SQLException;
  
  Object toJdbc() throws SQLException;
  
  Object toJdbc(Map paramMap) throws SQLException;
  
  Object toClass(Class paramClass) throws SQLException;
  
  Object toClass(Class paramClass, Map paramMap) throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Object makeJdbcArray(int paramInt);
  
  void setAutoBuffering(boolean paramBoolean) throws SQLException;
  
  boolean getAutoBuffering() throws SQLException;
  
  void setImage(byte[] paramArrayOfbyte, long paramLong1, long paramLong2) throws SQLException;
  
  void setImageLength(long paramLong) throws SQLException;
  
  long getImageOffset();
  
  long getImageLength();
  
  ORADataFactory getORADataFactory(Hashtable paramHashtable, String paramString) throws SQLException;
  
  boolean isInHierarchyOf(String paramString) throws SQLException;
  
  Connection getJavaSqlConnection() throws SQLException;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\OracleStruct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */