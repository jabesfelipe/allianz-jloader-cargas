/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class KeywordValueLong
/*    */ {
/*    */   public abstract int getKeyword() throws SQLException;
/*    */   
/*    */   public abstract byte[] getBinaryValue() throws SQLException;
/*    */   
/*    */   public abstract String getTextValue() throws SQLException;
/*    */   
/*    */   public static final KeywordValueLong constructKeywordValue(int paramInt, String paramString) throws SQLException {
/* 58 */     return (KeywordValueLong)InternalFactory.createKeywordValueLong(paramInt, paramString, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final KeywordValueLong constructKeywordValue(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 70 */     return (KeywordValueLong)InternalFactory.createKeywordValueLong(paramInt, null, paramArrayOfbyte);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\KeywordValueLong.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */