package oracle.jdbc.internal;

import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleArray;
import oracle.sql.ArrayDescriptor;
import oracle.sql.Datum;

public interface OracleArray extends OracleDatumWithConnection, OracleArray {
  public static final int ACCESS_FORWARD = 1;
  
  public static final int ACCESS_REVERSE = 2;
  
  public static final int ACCESS_UNKNOWN = 3;
  
  Datum[] getOracleArray() throws SQLException;
  
  Datum[] getOracleArray(long paramLong, int paramInt) throws SQLException;
  
  void setAutoBuffering(boolean paramBoolean) throws SQLException;
  
  boolean getAutoBuffering() throws SQLException;
  
  void setAutoIndexing(boolean paramBoolean, int paramInt) throws SQLException;
  
  void setAutoIndexing(boolean paramBoolean) throws SQLException;
  
  boolean getAutoIndexing() throws SQLException;
  
  int getAccessDirection() throws SQLException;
  
  ArrayDescriptor getDescriptor() throws SQLException;
  
  Map getMap() throws SQLException;
  
  byte[] toBytes() throws SQLException;
  
  void setDatumArray(Datum[] paramArrayOfDatum);
  
  void setObjArray(Object paramObject) throws SQLException;
  
  void setLocator(byte[] paramArrayOfbyte);
  
  void setPrefixSegment(byte[] paramArrayOfbyte);
  
  void setPrefixFlag(byte paramByte);
  
  byte[] getLocator();
  
  void setLength(int paramInt);
  
  boolean hasDataSeg();
  
  boolean isInline();
  
  boolean isConvertibleTo(Class paramClass);
  
  Object makeJdbcArray(int paramInt);
  
  void setLastIndexOffset(long paramLong1, long paramLong2) throws SQLException;
  
  void setIndexOffset(long paramLong1, long paramLong2) throws SQLException;
  
  long getLastIndex() throws SQLException;
  
  long getLastOffset() throws SQLException;
  
  long getOffset(long paramLong) throws SQLException;
  
  void setImage(byte[] paramArrayOfbyte, long paramLong1, long paramLong2) throws SQLException;
  
  void setImageLength(long paramLong) throws SQLException;
  
  long getImageOffset();
  
  long getImageLength();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\OracleArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */