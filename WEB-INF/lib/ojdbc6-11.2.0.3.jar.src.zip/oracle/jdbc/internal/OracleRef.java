package oracle.jdbc.internal;

import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleRef;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public interface OracleRef extends OracleDatumWithConnection, OracleRef {
  Object getValue(Map paramMap) throws SQLException;
  
  Object getValue() throws SQLException;
  
  STRUCT getSTRUCT() throws SQLException;
  
  void setValue(Object paramObject) throws SQLException;
  
  StructDescriptor getDescriptor() throws SQLException;
  
  String getSQLTypeName() throws SQLException;
  
  Object toJdbc() throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Object makeJdbcArray(int paramInt);
  
  Object clone() throws CloneNotSupportedException;
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\OracleRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */