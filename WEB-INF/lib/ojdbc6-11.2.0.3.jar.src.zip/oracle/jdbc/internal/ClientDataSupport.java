package oracle.jdbc.internal;

public interface ClientDataSupport {
  Object getClientData(Object paramObject);
  
  Object setClientData(Object paramObject1, Object paramObject2);
  
  Object removeClientData(Object paramObject);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\ClientDataSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */