/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class KeywordValue
/*    */ {
/*    */   public abstract int getKeyword() throws SQLException;
/*    */   
/*    */   public abstract byte[] getBinaryValue() throws SQLException;
/*    */   
/*    */   public abstract String getTextValue() throws SQLException;
/*    */   
/*    */   public static final KeywordValue constructKeywordValue(int paramInt, String paramString) throws SQLException {
/* 52 */     return (KeywordValue)InternalFactory.createKeywordValue(paramInt, paramString, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final KeywordValue constructKeywordValue(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 64 */     return (KeywordValue)InternalFactory.createKeywordValue(paramInt, null, paramArrayOfbyte);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\internal\KeywordValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */