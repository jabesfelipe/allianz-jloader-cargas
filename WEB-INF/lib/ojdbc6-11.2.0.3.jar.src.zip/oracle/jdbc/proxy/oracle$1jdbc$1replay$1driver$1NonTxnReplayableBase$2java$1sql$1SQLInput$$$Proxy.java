package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLInput$$$Proxy extends NonTxnReplayableBase implements SQLInput, _Proxy_ {
  private SQLInput delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject24971;
  
  private static Method methodObject24952;
  
  private static Method methodObject24951;
  
  private static Method methodObject24950;
  
  private static Method methodObject24957;
  
  private static Method methodObject24972;
  
  private static Method methodObject24959;
  
  private static Method methodObject24961;
  
  private static Method methodObject24946;
  
  private static Method methodObject24965;
  
  private static Method methodObject24954;
  
  private static Method methodObject24948;
  
  private static Method methodObject24956;
  
  private static Method methodObject24968;
  
  private static Method methodObject24960;
  
  private static Method methodObject24953;
  
  private static Method methodObject24966;
  
  private static Method methodObject24947;
  
  private static Method methodObject24958;
  
  private static Method methodObject24955;
  
  private static Method methodObject24949;
  
  private static Method methodObject24963;
  
  private static Method methodObject24962;
  
  private static Method methodObject24967;
  
  private static Method methodObject24964;
  
  private static Method methodObject24969;
  
  private static Method methodObject24970;
  
  public URL readURL() throws SQLException {
    try {
      preForAll(methodObject24971, this, new Object[0]);
      return (URL)postForAll(methodObject24971, this.proxyFactory.proxyFor(this.delegate.readURL(), this, (Map)this.proxyCache, methodObject24971));
    } catch (SQLException e) {
      return (URL)postForAll(methodObject24971, onErrorForAll(methodObject24971, e));
    } 
  }
  
  public float readFloat() throws SQLException {
    try {
      preForAll(methodObject24952, this, new Object[0]);
      return ((Float)postForAll(methodObject24952, this.proxyFactory.proxyFor(Float.valueOf(this.delegate.readFloat()), this, (Map)this.proxyCache, methodObject24952))).floatValue();
    } catch (SQLException e) {
      return ((Float)postForAll(methodObject24952, onErrorForAll(methodObject24952, e))).floatValue();
    } 
  }
  
  public short readShort() throws SQLException {
    try {
      preForAll(methodObject24951, this, new Object[0]);
      return ((Short)postForAll(methodObject24951, this.proxyFactory.proxyFor(Short.valueOf(this.delegate.readShort()), this, (Map)this.proxyCache, methodObject24951))).shortValue();
    } catch (SQLException e) {
      return ((Short)postForAll(methodObject24951, onErrorForAll(methodObject24951, e))).shortValue();
    } 
  }
  
  public long readLong() throws SQLException {
    try {
      preForAll(methodObject24950, this, new Object[0]);
      return ((Long)postForAll(methodObject24950, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.readLong()), this, (Map)this.proxyCache, methodObject24950))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject24950, onErrorForAll(methodObject24950, e))).longValue();
    } 
  }
  
  public Blob readBlob() throws SQLException {
    try {
      preForAll(methodObject24957, this, new Object[0]);
      return (Blob)postForAll(methodObject24957, this.proxyFactory.proxyFor(this.delegate.readBlob(), this, (Map)this.proxyCache, methodObject24957));
    } catch (SQLException e) {
      return (Blob)postForAll(methodObject24957, onErrorForAll(methodObject24957, e));
    } 
  }
  
  public boolean wasNull() throws SQLException {
    try {
      preForAll(methodObject24972, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24972, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.wasNull()), this, (Map)this.proxyCache, methodObject24972))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24972, onErrorForAll(methodObject24972, e))).booleanValue();
    } 
  }
  
  public Reader readCharacterStream() throws SQLException {
    try {
      preForAll(methodObject24959, this, new Object[0]);
      return (Reader)postForAll(methodObject24959, this.proxyFactory.proxyFor(this.delegate.readCharacterStream(), this, (Map)this.proxyCache, methodObject24959));
    } catch (SQLException e) {
      return (Reader)postForAll(methodObject24959, onErrorForAll(methodObject24959, e));
    } 
  }
  
  public Date readDate() throws SQLException {
    try {
      preForAll(methodObject24961, this, new Object[0]);
      return (Date)postForAll(methodObject24961, this.proxyFactory.proxyFor(this.delegate.readDate(), this, (Map)this.proxyCache, methodObject24961));
    } catch (SQLException e) {
      return (Date)postForAll(methodObject24961, onErrorForAll(methodObject24961, e));
    } 
  }
  
  public int readInt() throws SQLException {
    try {
      preForAll(methodObject24946, this, new Object[0]);
      return ((Integer)postForAll(methodObject24946, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.readInt()), this, (Map)this.proxyCache, methodObject24946))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24946, onErrorForAll(methodObject24946, e))).intValue();
    } 
  }
  
  public Ref readRef() throws SQLException {
    try {
      preForAll(methodObject24965, this, new Object[0]);
      return (Ref)postForAll(methodObject24965, this.proxyFactory.proxyFor(this.delegate.readRef(), this, (Map)this.proxyCache, methodObject24965));
    } catch (SQLException e) {
      return (Ref)postForAll(methodObject24965, onErrorForAll(methodObject24965, e));
    } 
  }
  
  public InputStream readAsciiStream() throws SQLException {
    try {
      preForAll(methodObject24954, this, new Object[0]);
      return (InputStream)postForAll(methodObject24954, this.proxyFactory.proxyFor(this.delegate.readAsciiStream(), this, (Map)this.proxyCache, methodObject24954));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject24954, onErrorForAll(methodObject24954, e));
    } 
  }
  
  public byte[] readBytes() throws SQLException {
    try {
      preForAll(methodObject24948, this, new Object[0]);
      return (byte[])postForAll(methodObject24948, this.proxyFactory.proxyFor(this.delegate.readBytes(), this, (Map)this.proxyCache, methodObject24948));
    } catch (SQLException e) {
      return (byte[])postForAll(methodObject24948, onErrorForAll(methodObject24948, e));
    } 
  }
  
  public InputStream readBinaryStream() throws SQLException {
    try {
      preForAll(methodObject24956, this, new Object[0]);
      return (InputStream)postForAll(methodObject24956, this.proxyFactory.proxyFor(this.delegate.readBinaryStream(), this, (Map)this.proxyCache, methodObject24956));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject24956, onErrorForAll(methodObject24956, e));
    } 
  }
  
  public String readString() throws SQLException {
    try {
      preForAll(methodObject24968, this, new Object[0]);
      return (String)postForAll(methodObject24968, this.proxyFactory.proxyFor(this.delegate.readString(), this, (Map)this.proxyCache, methodObject24968));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24968, onErrorForAll(methodObject24968, e));
    } 
  }
  
  public Clob readClob() throws SQLException {
    try {
      preForAll(methodObject24960, this, new Object[0]);
      return (Clob)postForAll(methodObject24960, this.proxyFactory.proxyFor(this.delegate.readClob(), this, (Map)this.proxyCache, methodObject24960));
    } catch (SQLException e) {
      return (Clob)postForAll(methodObject24960, onErrorForAll(methodObject24960, e));
    } 
  }
  
  public Array readArray() throws SQLException {
    try {
      preForAll(methodObject24953, this, new Object[0]);
      return (Array)postForAll(methodObject24953, this.proxyFactory.proxyFor(this.delegate.readArray(), this, (Map)this.proxyCache, methodObject24953));
    } catch (SQLException e) {
      return (Array)postForAll(methodObject24953, onErrorForAll(methodObject24953, e));
    } 
  }
  
  public RowId readRowId() throws SQLException {
    try {
      preForAll(methodObject24966, this, new Object[0]);
      return (RowId)postForAll(methodObject24966, this.proxyFactory.proxyFor(this.delegate.readRowId(), this, (Map)this.proxyCache, methodObject24966));
    } catch (SQLException e) {
      return (RowId)postForAll(methodObject24966, onErrorForAll(methodObject24966, e));
    } 
  }
  
  public Object readObject() throws SQLException {
    try {
      preForAll(methodObject24947, this, new Object[0]);
      return postForAll(methodObject24947, this.proxyFactory.proxyFor(this.delegate.readObject(), this, (Map)this.proxyCache, methodObject24947));
    } catch (SQLException e) {
      return postForAll(methodObject24947, onErrorForAll(methodObject24947, e));
    } 
  }
  
  public boolean readBoolean() throws SQLException {
    try {
      preForAll(methodObject24958, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24958, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.readBoolean()), this, (Map)this.proxyCache, methodObject24958))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24958, onErrorForAll(methodObject24958, e))).booleanValue();
    } 
  }
  
  public BigDecimal readBigDecimal() throws SQLException {
    try {
      preForAll(methodObject24955, this, new Object[0]);
      return (BigDecimal)postForAll(methodObject24955, this.proxyFactory.proxyFor(this.delegate.readBigDecimal(), this, (Map)this.proxyCache, methodObject24955));
    } catch (SQLException e) {
      return (BigDecimal)postForAll(methodObject24955, onErrorForAll(methodObject24955, e));
    } 
  }
  
  public byte readByte() throws SQLException {
    try {
      preForAll(methodObject24949, this, new Object[0]);
      return ((Byte)postForAll(methodObject24949, this.proxyFactory.proxyFor(Byte.valueOf(this.delegate.readByte()), this, (Map)this.proxyCache, methodObject24949))).byteValue();
    } catch (SQLException e) {
      return ((Byte)postForAll(methodObject24949, onErrorForAll(methodObject24949, e))).byteValue();
    } 
  }
  
  public NClob readNClob() throws SQLException {
    try {
      preForAll(methodObject24963, this, new Object[0]);
      return (NClob)postForAll(methodObject24963, this.proxyFactory.proxyFor(this.delegate.readNClob(), this, (Map)this.proxyCache, methodObject24963));
    } catch (SQLException e) {
      return (NClob)postForAll(methodObject24963, onErrorForAll(methodObject24963, e));
    } 
  }
  
  public double readDouble() throws SQLException {
    try {
      preForAll(methodObject24962, this, new Object[0]);
      return ((Double)postForAll(methodObject24962, this.proxyFactory.proxyFor(Double.valueOf(this.delegate.readDouble()), this, (Map)this.proxyCache, methodObject24962))).doubleValue();
    } catch (SQLException e) {
      return ((Double)postForAll(methodObject24962, onErrorForAll(methodObject24962, e))).doubleValue();
    } 
  }
  
  public SQLXML readSQLXML() throws SQLException {
    try {
      preForAll(methodObject24967, this, new Object[0]);
      return (SQLXML)postForAll(methodObject24967, this.proxyFactory.proxyFor(this.delegate.readSQLXML(), this, (Map)this.proxyCache, methodObject24967));
    } catch (SQLException e) {
      return (SQLXML)postForAll(methodObject24967, onErrorForAll(methodObject24967, e));
    } 
  }
  
  public String readNString() throws SQLException {
    try {
      preForAll(methodObject24964, this, new Object[0]);
      return (String)postForAll(methodObject24964, this.proxyFactory.proxyFor(this.delegate.readNString(), this, (Map)this.proxyCache, methodObject24964));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24964, onErrorForAll(methodObject24964, e));
    } 
  }
  
  public Time readTime() throws SQLException {
    try {
      preForAll(methodObject24969, this, new Object[0]);
      return (Time)postForAll(methodObject24969, this.proxyFactory.proxyFor(this.delegate.readTime(), this, (Map)this.proxyCache, methodObject24969));
    } catch (SQLException e) {
      return (Time)postForAll(methodObject24969, onErrorForAll(methodObject24969, e));
    } 
  }
  
  public Timestamp readTimestamp() throws SQLException {
    try {
      preForAll(methodObject24970, this, new Object[0]);
      return (Timestamp)postForAll(methodObject24970, this.proxyFactory.proxyFor(this.delegate.readTimestamp(), this, (Map)this.proxyCache, methodObject24970));
    } catch (SQLException e) {
      return (Timestamp)postForAll(methodObject24970, onErrorForAll(methodObject24970, e));
    } 
  }
  
  public SQLInput _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(SQLInput delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject24971 = SQLInput.class.getDeclaredMethod("readURL", new Class[0]);
      methodObject24952 = SQLInput.class.getDeclaredMethod("readFloat", new Class[0]);
      methodObject24951 = SQLInput.class.getDeclaredMethod("readShort", new Class[0]);
      methodObject24950 = SQLInput.class.getDeclaredMethod("readLong", new Class[0]);
      methodObject24957 = SQLInput.class.getDeclaredMethod("readBlob", new Class[0]);
      methodObject24972 = SQLInput.class.getDeclaredMethod("wasNull", new Class[0]);
      methodObject24959 = SQLInput.class.getDeclaredMethod("readCharacterStream", new Class[0]);
      methodObject24961 = SQLInput.class.getDeclaredMethod("readDate", new Class[0]);
      methodObject24946 = SQLInput.class.getDeclaredMethod("readInt", new Class[0]);
      methodObject24965 = SQLInput.class.getDeclaredMethod("readRef", new Class[0]);
      methodObject24954 = SQLInput.class.getDeclaredMethod("readAsciiStream", new Class[0]);
      methodObject24948 = SQLInput.class.getDeclaredMethod("readBytes", new Class[0]);
      methodObject24956 = SQLInput.class.getDeclaredMethod("readBinaryStream", new Class[0]);
      methodObject24968 = SQLInput.class.getDeclaredMethod("readString", new Class[0]);
      methodObject24960 = SQLInput.class.getDeclaredMethod("readClob", new Class[0]);
      methodObject24953 = SQLInput.class.getDeclaredMethod("readArray", new Class[0]);
      methodObject24966 = SQLInput.class.getDeclaredMethod("readRowId", new Class[0]);
      methodObject24947 = SQLInput.class.getDeclaredMethod("readObject", new Class[0]);
      methodObject24958 = SQLInput.class.getDeclaredMethod("readBoolean", new Class[0]);
      methodObject24955 = SQLInput.class.getDeclaredMethod("readBigDecimal", new Class[0]);
      methodObject24949 = SQLInput.class.getDeclaredMethod("readByte", new Class[0]);
      methodObject24963 = SQLInput.class.getDeclaredMethod("readNClob", new Class[0]);
      methodObject24962 = SQLInput.class.getDeclaredMethod("readDouble", new Class[0]);
      methodObject24967 = SQLInput.class.getDeclaredMethod("readSQLXML", new Class[0]);
      methodObject24964 = SQLInput.class.getDeclaredMethod("readNString", new Class[0]);
      methodObject24969 = SQLInput.class.getDeclaredMethod("readTime", new Class[0]);
      methodObject24970 = SQLInput.class.getDeclaredMethod("readTimestamp", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLInput$$$Proxy(SQLInput paramSQLInput, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramSQLInput;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLInput$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */