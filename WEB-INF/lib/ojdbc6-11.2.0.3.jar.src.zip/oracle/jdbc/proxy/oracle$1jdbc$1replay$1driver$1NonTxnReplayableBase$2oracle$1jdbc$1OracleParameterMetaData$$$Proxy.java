package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ParameterMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.OracleParameterMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleParameterMetaData$$$Proxy extends NonTxnReplayableBase implements OracleParameterMetaData, _Proxy_ {
  private OracleParameterMetaData delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject24988;
  
  private static Method methodObject24983;
  
  private static Method methodObject24985;
  
  private static Method methodObject24982;
  
  private static Method methodObject24990;
  
  private static Method methodObject24984;
  
  private static Method methodObject24992;
  
  private static Method methodObject24989;
  
  private static Method methodObject24987;
  
  private static Method methodObject24986;
  
  private static Method methodObject24991;
  
  public int getScale(int arg0) throws SQLException {
    try {
      preForAll(methodObject24988, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24988, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, (Map)this.proxyCache, methodObject24988))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24988, onErrorForAll(methodObject24988, e))).intValue();
    } 
  }
  
  public int getParameterCount() throws SQLException {
    try {
      preForAll(methodObject24983, this, new Object[0]);
      return ((Integer)postForAll(methodObject24983, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterCount()), this, (Map)this.proxyCache, methodObject24983))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24983, onErrorForAll(methodObject24983, e))).intValue();
    } 
  }
  
  public int getParameterType(int arg0) throws SQLException {
    try {
      preForAll(methodObject24985, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24985, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterType(arg0)), this, (Map)this.proxyCache, methodObject24985))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24985, onErrorForAll(methodObject24985, e))).intValue();
    } 
  }
  
  public String getParameterClassName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24982, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24982, this.proxyFactory.proxyFor(this.delegate.getParameterClassName(arg0), this, (Map)this.proxyCache, methodObject24982));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24982, onErrorForAll(methodObject24982, e));
    } 
  }
  
  public boolean isSigned(int arg0) throws SQLException {
    try {
      preForAll(methodObject24990, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24990, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, (Map)this.proxyCache, methodObject24990))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24990, onErrorForAll(methodObject24990, e))).booleanValue();
    } 
  }
  
  public int getParameterMode(int arg0) throws SQLException {
    try {
      preForAll(methodObject24984, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24984, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterMode(arg0)), this, (Map)this.proxyCache, methodObject24984))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24984, onErrorForAll(methodObject24984, e))).intValue();
    } 
  }
  
  public Object unwrap(Class arg0) throws SQLException {
    return this.delegate.unwrap(arg0);
  }
  
  public int isNullable(int arg0) throws SQLException {
    try {
      preForAll(methodObject24989, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24989, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, (Map)this.proxyCache, methodObject24989))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24989, onErrorForAll(methodObject24989, e))).intValue();
    } 
  }
  
  public int getPrecision(int arg0) throws SQLException {
    try {
      preForAll(methodObject24987, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24987, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, (Map)this.proxyCache, methodObject24987))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24987, onErrorForAll(methodObject24987, e))).intValue();
    } 
  }
  
  public String getParameterTypeName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24986, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24986, this.proxyFactory.proxyFor(this.delegate.getParameterTypeName(arg0), this, (Map)this.proxyCache, methodObject24986));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24986, onErrorForAll(methodObject24986, e));
    } 
  }
  
  public boolean isWrapperFor(Class arg0) throws SQLException {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public OracleParameterMetaData _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleParameterMetaData delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject24988 = ParameterMetaData.class.getDeclaredMethod("getScale", new Class[] { int.class });
      methodObject24983 = ParameterMetaData.class.getDeclaredMethod("getParameterCount", new Class[0]);
      methodObject24985 = ParameterMetaData.class.getDeclaredMethod("getParameterType", new Class[] { int.class });
      methodObject24982 = ParameterMetaData.class.getDeclaredMethod("getParameterClassName", new Class[] { int.class });
      methodObject24990 = ParameterMetaData.class.getDeclaredMethod("isSigned", new Class[] { int.class });
      methodObject24984 = ParameterMetaData.class.getDeclaredMethod("getParameterMode", new Class[] { int.class });
      methodObject24992 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject24989 = ParameterMetaData.class.getDeclaredMethod("isNullable", new Class[] { int.class });
      methodObject24987 = ParameterMetaData.class.getDeclaredMethod("getPrecision", new Class[] { int.class });
      methodObject24986 = ParameterMetaData.class.getDeclaredMethod("getParameterTypeName", new Class[] { int.class });
      methodObject24991 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleParameterMetaData$$$Proxy(OracleParameterMetaData paramOracleParameterMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleParameterMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleParameterMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */