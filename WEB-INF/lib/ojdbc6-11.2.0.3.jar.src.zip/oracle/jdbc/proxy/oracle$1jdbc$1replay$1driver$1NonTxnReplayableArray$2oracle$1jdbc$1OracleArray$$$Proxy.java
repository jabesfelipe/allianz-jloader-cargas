package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleArray;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy extends NonTxnReplayableArray implements OracleArray, _Proxy_ {
  private OracleArray delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25200;
  
  private static Method methodObject25193;
  
  private static Method methodObject25208;
  
  private static Method methodObject25207;
  
  private static Method methodObject25204;
  
  private static Method methodObject25217;
  
  private static Method methodObject25215;
  
  private static Method methodObject25205;
  
  private static Method methodObject25216;
  
  private static Method methodObject25194;
  
  private static Method methodObject25198;
  
  private static Method methodObject25197;
  
  private static Method methodObject25202;
  
  private static Method methodObject25212;
  
  private static Method methodObject25199;
  
  private static Method methodObject25195;
  
  private static Method methodObject25206;
  
  private static Method methodObject25213;
  
  private static Method methodObject25211;
  
  private static Method methodObject25210;
  
  private static Method methodObject25203;
  
  private static Method methodObject25201;
  
  private static Method methodObject25196;
  
  private static Method methodObject25209;
  
  private static Method methodObject25214;
  
  public double[] getDoubleArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25200, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (double[])postForAll(methodObject25200, this.proxyFactory.proxyFor(this.delegate.getDoubleArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25200));
    } catch (SQLException e) {
      return (double[])postForAll(methodObject25200, onErrorForAll(methodObject25200, e));
    } 
  }
  
  public int length() throws SQLException {
    try {
      preForAll(methodObject25193, this, new Object[0]);
      return ((Integer)postForAll(methodObject25193, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.length()), this, (Map)this.proxyCache, methodObject25193))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25193, onErrorForAll(methodObject25193, e))).intValue();
    } 
  }
  
  public Object getArray(Map arg0) throws SQLException {
    try {
      preForAll(methodObject25208, this, new Object[] { arg0 });
      return postForAll(methodObject25208, this.proxyFactory.proxyFor(this.delegate.getArray(arg0), this, (Map)this.proxyCache, methodObject25208));
    } catch (SQLException e) {
      return postForAll(methodObject25208, onErrorForAll(methodObject25208, e));
    } 
  }
  
  public Object getArray() throws SQLException {
    try {
      preForAll(methodObject25207, this, new Object[0]);
      return postForAll(methodObject25207, this.proxyFactory.proxyFor(this.delegate.getArray(), this, (Map)this.proxyCache, methodObject25207));
    } catch (SQLException e) {
      return postForAll(methodObject25207, onErrorForAll(methodObject25207, e));
    } 
  }
  
  public long[] getLongArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25204, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (long[])postForAll(methodObject25204, this.proxyFactory.proxyFor(this.delegate.getLongArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25204));
    } catch (SQLException e) {
      return (long[])postForAll(methodObject25204, onErrorForAll(methodObject25204, e));
    } 
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map arg2) throws SQLException {
    try {
      preForAll(methodObject25217, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject25217, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject25217));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25217, onErrorForAll(methodObject25217, e));
    } 
  }
  
  public ResultSet getResultSet(Map arg0) throws SQLException {
    try {
      preForAll(methodObject25215, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject25215, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0), this, (Map)this.proxyCache, methodObject25215));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25215, onErrorForAll(methodObject25215, e));
    } 
  }
  
  public float[] getFloatArray() throws SQLException {
    try {
      preForAll(methodObject25205, this, new Object[0]);
      return (float[])postForAll(methodObject25205, this.proxyFactory.proxyFor(this.delegate.getFloatArray(), this, (Map)this.proxyCache, methodObject25205));
    } catch (SQLException e) {
      return (float[])postForAll(methodObject25205, onErrorForAll(methodObject25205, e));
    } 
  }
  
  public ResultSet getResultSet(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25216, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject25216, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0, arg1), this, (Map)this.proxyCache, methodObject25216));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25216, onErrorForAll(methodObject25216, e));
    } 
  }
  
  public String getSQLTypeName() throws SQLException {
    try {
      preForAll(methodObject25194, this, new Object[0]);
      return (String)postForAll(methodObject25194, this.proxyFactory.proxyFor(this.delegate.getSQLTypeName(), this, (Map)this.proxyCache, methodObject25194));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25194, onErrorForAll(methodObject25194, e));
    } 
  }
  
  public int[] getIntArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25198, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (int[])postForAll(methodObject25198, this.proxyFactory.proxyFor(this.delegate.getIntArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25198));
    } catch (SQLException e) {
      return (int[])postForAll(methodObject25198, onErrorForAll(methodObject25198, e));
    } 
  }
  
  public int[] getIntArray() throws SQLException {
    try {
      preForAll(methodObject25197, this, new Object[0]);
      return (int[])postForAll(methodObject25197, this.proxyFactory.proxyFor(this.delegate.getIntArray(), this, (Map)this.proxyCache, methodObject25197));
    } catch (SQLException e) {
      return (int[])postForAll(methodObject25197, onErrorForAll(methodObject25197, e));
    } 
  }
  
  public short[] getShortArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25202, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (short[])postForAll(methodObject25202, this.proxyFactory.proxyFor(this.delegate.getShortArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25202));
    } catch (SQLException e) {
      return (short[])postForAll(methodObject25202, onErrorForAll(methodObject25202, e));
    } 
  }
  
  public int getBaseType() throws SQLException {
    try {
      preForAll(methodObject25212, this, new Object[0]);
      return ((Integer)postForAll(methodObject25212, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBaseType()), this, (Map)this.proxyCache, methodObject25212))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25212, onErrorForAll(methodObject25212, e))).intValue();
    } 
  }
  
  public double[] getDoubleArray() throws SQLException {
    try {
      preForAll(methodObject25199, this, new Object[0]);
      return (double[])postForAll(methodObject25199, this.proxyFactory.proxyFor(this.delegate.getDoubleArray(), this, (Map)this.proxyCache, methodObject25199));
    } catch (SQLException e) {
      return (double[])postForAll(methodObject25199, onErrorForAll(methodObject25199, e));
    } 
  }
  
  public Object toJdbc() throws SQLException {
    try {
      preForAll(methodObject25195, this, new Object[0]);
      return postForAll(methodObject25195, this.proxyFactory.proxyFor(this.delegate.toJdbc(), this, (Map)this.proxyCache, methodObject25195));
    } catch (SQLException e) {
      return postForAll(methodObject25195, onErrorForAll(methodObject25195, e));
    } 
  }
  
  public float[] getFloatArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25206, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (float[])postForAll(methodObject25206, this.proxyFactory.proxyFor(this.delegate.getFloatArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25206));
    } catch (SQLException e) {
      return (float[])postForAll(methodObject25206, onErrorForAll(methodObject25206, e));
    } 
  }
  
  public String getBaseTypeName() throws SQLException {
    try {
      preForAll(methodObject25213, this, new Object[0]);
      return (String)postForAll(methodObject25213, this.proxyFactory.proxyFor(this.delegate.getBaseTypeName(), this, (Map)this.proxyCache, methodObject25213));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25213, onErrorForAll(methodObject25213, e));
    } 
  }
  
  public void free() throws SQLException {
    try {
      preForAll(methodObject25211, this, new Object[0]);
      this.delegate.free();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25211, e);
      return;
    } 
  }
  
  public Object getArray(long arg0, int arg1, Map arg2) throws SQLException {
    try {
      preForAll(methodObject25210, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject25210, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject25210));
    } catch (SQLException e) {
      return postForAll(methodObject25210, onErrorForAll(methodObject25210, e));
    } 
  }
  
  public long[] getLongArray() throws SQLException {
    try {
      preForAll(methodObject25203, this, new Object[0]);
      return (long[])postForAll(methodObject25203, this.proxyFactory.proxyFor(this.delegate.getLongArray(), this, (Map)this.proxyCache, methodObject25203));
    } catch (SQLException e) {
      return (long[])postForAll(methodObject25203, onErrorForAll(methodObject25203, e));
    } 
  }
  
  public short[] getShortArray() throws SQLException {
    try {
      preForAll(methodObject25201, this, new Object[0]);
      return (short[])postForAll(methodObject25201, this.proxyFactory.proxyFor(this.delegate.getShortArray(), this, (Map)this.proxyCache, methodObject25201));
    } catch (SQLException e) {
      return (short[])postForAll(methodObject25201, onErrorForAll(methodObject25201, e));
    } 
  }
  
  public OracleTypeMetaData getOracleMetaData() throws SQLException {
    try {
      preForAll(methodObject25196, this, new Object[0]);
      return (OracleTypeMetaData)postForAll(methodObject25196, this.proxyFactory.proxyFor(this.delegate.getOracleMetaData(), this, (Map)this.proxyCache, methodObject25196));
    } catch (SQLException e) {
      return (OracleTypeMetaData)postForAll(methodObject25196, onErrorForAll(methodObject25196, e));
    } 
  }
  
  public Object getArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25209, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject25209, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25209));
    } catch (SQLException e) {
      return postForAll(methodObject25209, onErrorForAll(methodObject25209, e));
    } 
  }
  
  public ResultSet getResultSet() throws SQLException {
    try {
      preForAll(methodObject25214, this, new Object[0]);
      return (ResultSet)postForAll(methodObject25214, this.proxyFactory.proxyFor(this.delegate.getResultSet(), this, (Map)this.proxyCache, methodObject25214));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25214, onErrorForAll(methodObject25214, e));
    } 
  }
  
  public OracleArray _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleArray delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25200 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[] { long.class, int.class });
      methodObject25193 = OracleArray.class.getDeclaredMethod("length", new Class[0]);
      methodObject25208 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject25207 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject25204 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[] { long.class, int.class });
      methodObject25217 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class, Map.class });
      methodObject25215 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject25205 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[0]);
      methodObject25216 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class });
      methodObject25194 = OracleArray.class.getDeclaredMethod("getSQLTypeName", new Class[0]);
      methodObject25198 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[] { long.class, int.class });
      methodObject25197 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[0]);
      methodObject25202 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[] { long.class, int.class });
      methodObject25212 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject25199 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[0]);
      methodObject25195 = OracleArray.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject25206 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[] { long.class, int.class });
      methodObject25213 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject25211 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject25210 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class, Map.class });
      methodObject25203 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[0]);
      methodObject25201 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[0]);
      methodObject25196 = OracleArray.class.getDeclaredMethod("getOracleMetaData", new Class[0]);
      methodObject25209 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class });
      methodObject25214 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy(OracleArray paramOracleArray, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1OracleArray$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */