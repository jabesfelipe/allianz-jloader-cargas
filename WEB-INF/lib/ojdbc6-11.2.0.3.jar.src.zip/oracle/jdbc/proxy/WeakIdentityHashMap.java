/*      */ package oracle.jdbc.proxy;
/*      */ 
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.ReferenceQueue;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WeakIdentityHashMap<K, V>
/*      */   implements Map<K, V>
/*      */ {
/*      */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*      */   private static final int MAXIMUM_CAPACITY = 1073741824;
/*      */   private static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*      */   Entry<K, V>[] table;
/*      */   private int size;
/*      */   private int threshold;
/*      */   private final float loadFactor;
/*  171 */   private final ReferenceQueue<Object> queue = new ReferenceQueue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   volatile int modCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Entry<K, V>[] newTable(int paramInt) {
/*  186 */     return (Entry<K, V>[])new Entry[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WeakIdentityHashMap(int paramInt) {
/*  224 */     this(paramInt, 0.75F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WeakIdentityHashMap(Map<? extends K, ? extends V> paramMap) {
/*  248 */     this(Math.max((int)(paramMap.size() / 0.75F) + 1, 16), 0.75F);
/*      */     
/*  250 */     putAll(paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  258 */   private static final Object NULL_KEY = new Object();
/*      */   private transient Set<Map.Entry<K, V>> entrySet;
/*      */   volatile transient Set<K> keySet;
/*      */   volatile transient Collection<V> values;
/*      */   
/*      */   private static Object maskNull(Object paramObject) {
/*  264 */     return (paramObject == null) ? NULL_KEY : paramObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Object unmaskNull(Object paramObject) {
/*  271 */     return (paramObject == NULL_KEY) ? null : paramObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean eq(Object paramObject1, Object paramObject2) {
/*  278 */     return (paramObject1 == paramObject2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int indexFor(int paramInt1, int paramInt2) {
/*  285 */     return paramInt1 & paramInt2 - 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void expungeStaleEntries() {
/*      */     Reference<?> reference;
/*  292 */     while ((reference = this.queue.poll()) != null) {
/*  293 */       synchronized (this.queue) {
/*      */         
/*  295 */         Entry<K, V> entry1 = (Entry)reference;
/*  296 */         int i = indexFor(entry1.hash, this.table.length);
/*      */         
/*  298 */         Entry<K, V> entry2 = this.table[i];
/*  299 */         Entry<K, V> entry3 = entry2;
/*  300 */         while (entry3 != null) {
/*  301 */           Entry<K, V> entry = entry3.next;
/*  302 */           if (entry3 == entry1) {
/*  303 */             if (entry2 == entry1) {
/*  304 */               this.table[i] = entry;
/*      */             } else {
/*  306 */               entry2.next = entry;
/*      */             } 
/*      */             
/*  309 */             entry1.value = null;
/*  310 */             this.size--;
/*      */             break;
/*      */           } 
/*  313 */           entry2 = entry3;
/*  314 */           entry3 = entry;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Entry<K, V>[] getTable() {
/*  324 */     expungeStaleEntries();
/*  325 */     return this.table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  335 */     if (this.size == 0)
/*  336 */       return 0; 
/*  337 */     expungeStaleEntries();
/*  338 */     return this.size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  348 */     return (size() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V get(Object paramObject) {
/*  369 */     Object object = maskNull(paramObject);
/*  370 */     int i = System.identityHashCode(object);
/*  371 */     Entry[] arrayOfEntry = (Entry[])getTable();
/*  372 */     int j = indexFor(i, arrayOfEntry.length);
/*  373 */     Entry entry = arrayOfEntry[j];
/*  374 */     while (entry != null) {
/*  375 */       if (entry.hash == i && eq(object, entry.get()))
/*  376 */         return entry.value; 
/*  377 */       entry = entry.next;
/*      */     } 
/*  379 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsKey(Object paramObject) {
/*  391 */     return (getEntry(paramObject) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Entry<K, V> getEntry(Object paramObject) {
/*  399 */     Object object = maskNull(paramObject);
/*  400 */     int i = System.identityHashCode(object);
/*  401 */     Entry[] arrayOfEntry = (Entry[])getTable();
/*  402 */     int j = indexFor(i, arrayOfEntry.length);
/*  403 */     Entry<K, V> entry = arrayOfEntry[j];
/*  404 */     while (entry != null && (entry.hash != i || !eq(object, entry.get())))
/*  405 */       entry = entry.next; 
/*  406 */     return entry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V put(K paramK, V paramV) {
/*  422 */     Object object = maskNull(paramK);
/*  423 */     int i = System.identityHashCode(object);
/*  424 */     Entry[] arrayOfEntry = (Entry[])getTable();
/*  425 */     int j = indexFor(i, arrayOfEntry.length);
/*      */     Entry<?, V> entry;
/*  427 */     for (entry = arrayOfEntry[j]; entry != null; entry = entry.next) {
/*  428 */       if (i == entry.hash && eq(object, entry.get())) {
/*  429 */         V v = entry.value;
/*  430 */         if (paramV != v)
/*  431 */           entry.value = paramV; 
/*  432 */         return v;
/*      */       } 
/*      */     } 
/*      */     
/*  436 */     this.modCount++;
/*  437 */     entry = arrayOfEntry[j];
/*  438 */     arrayOfEntry[j] = new Entry<Object, V>(object, paramV, this.queue, i, entry);
/*  439 */     if (++this.size >= this.threshold)
/*  440 */       resize(arrayOfEntry.length * 2); 
/*  441 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resize(int paramInt) {
/*  459 */     Entry[] arrayOfEntry1 = (Entry[])getTable();
/*  460 */     int i = arrayOfEntry1.length;
/*  461 */     if (i == 1073741824) {
/*  462 */       this.threshold = Integer.MAX_VALUE;
/*      */       
/*      */       return;
/*      */     } 
/*  466 */     Entry[] arrayOfEntry2 = (Entry[])newTable(paramInt);
/*  467 */     transfer((Entry<K, V>[])arrayOfEntry1, (Entry<K, V>[])arrayOfEntry2);
/*  468 */     this.table = (Entry<K, V>[])arrayOfEntry2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  475 */     if (this.size >= this.threshold / 2) {
/*  476 */       this.threshold = (int)(paramInt * this.loadFactor);
/*      */     } else {
/*  478 */       expungeStaleEntries();
/*  479 */       transfer((Entry<K, V>[])arrayOfEntry2, (Entry<K, V>[])arrayOfEntry1);
/*  480 */       this.table = (Entry<K, V>[])arrayOfEntry1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void transfer(Entry<K, V>[] paramArrayOfEntry1, Entry<K, V>[] paramArrayOfEntry2) {
/*  486 */     for (byte b = 0; b < paramArrayOfEntry1.length; b++) {
/*  487 */       Entry<K, V> entry = paramArrayOfEntry1[b];
/*  488 */       paramArrayOfEntry1[b] = null;
/*  489 */       while (entry != null) {
/*  490 */         Entry<K, V> entry1 = entry.next;
/*  491 */         Object object = entry.get();
/*  492 */         if (object == null) {
/*  493 */           entry.next = null;
/*  494 */           entry.value = null;
/*  495 */           this.size--;
/*      */         } else {
/*  497 */           int i = indexFor(entry.hash, paramArrayOfEntry2.length);
/*  498 */           entry.next = paramArrayOfEntry2[i];
/*  499 */           paramArrayOfEntry2[i] = entry;
/*      */         } 
/*  501 */         entry = entry1;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void putAll(Map<? extends K, ? extends V> paramMap) {
/*  515 */     int i = paramMap.size();
/*  516 */     if (i == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  528 */     if (i > this.threshold) {
/*  529 */       int j = (int)(i / this.loadFactor + 1.0F);
/*  530 */       if (j > 1073741824)
/*  531 */         j = 1073741824; 
/*  532 */       int k = this.table.length;
/*  533 */       while (k < j)
/*  534 */         k <<= 1; 
/*  535 */       if (k > this.table.length) {
/*  536 */         resize(k);
/*      */       }
/*      */     } 
/*  539 */     for (Map.Entry<? extends K, ? extends V> entry : paramMap.entrySet()) {
/*  540 */       put((K)entry.getKey(), (V)entry.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V remove(Object paramObject) {
/*  564 */     Object object = maskNull(paramObject);
/*  565 */     int i = System.identityHashCode(object);
/*  566 */     Entry[] arrayOfEntry = (Entry[])getTable();
/*  567 */     int j = indexFor(i, arrayOfEntry.length);
/*  568 */     Entry entry1 = arrayOfEntry[j];
/*  569 */     Entry entry2 = entry1;
/*      */     
/*  571 */     while (entry2 != null) {
/*  572 */       Entry entry = entry2.next;
/*  573 */       if (i == entry2.hash && eq(object, entry2.get())) {
/*  574 */         this.modCount++;
/*  575 */         this.size--;
/*  576 */         if (entry1 == entry2) {
/*  577 */           arrayOfEntry[j] = entry;
/*      */         } else {
/*  579 */           entry1.next = entry;
/*  580 */         }  return entry2.value;
/*      */       } 
/*  582 */       entry1 = entry2;
/*  583 */       entry2 = entry;
/*      */     } 
/*      */     
/*  586 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean removeMapping(Object paramObject) {
/*  591 */     if (!(paramObject instanceof Map.Entry))
/*  592 */       return false; 
/*  593 */     Entry[] arrayOfEntry = (Entry[])getTable();
/*  594 */     Map.Entry entry = (Map.Entry)paramObject;
/*  595 */     Object object = maskNull(entry.getKey());
/*  596 */     int i = System.identityHashCode(object);
/*  597 */     int j = indexFor(i, arrayOfEntry.length);
/*  598 */     Entry entry1 = arrayOfEntry[j];
/*  599 */     Entry entry2 = entry1;
/*      */     
/*  601 */     while (entry2 != null) {
/*  602 */       Entry entry3 = entry2.next;
/*  603 */       if (i == entry2.hash && entry2.equals(entry)) {
/*  604 */         this.modCount++;
/*  605 */         this.size--;
/*  606 */         if (entry1 == entry2) {
/*  607 */           arrayOfEntry[j] = entry3;
/*      */         } else {
/*  609 */           entry1.next = entry3;
/*  610 */         }  return true;
/*      */       } 
/*  612 */       entry1 = entry2;
/*  613 */       entry2 = entry3;
/*      */     } 
/*      */     
/*  616 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/*  626 */     while (this.queue.poll() != null);
/*      */ 
/*      */     
/*  629 */     this.modCount++;
/*  630 */     Arrays.fill((Object[])this.table, (Object)null);
/*  631 */     this.size = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  636 */     while (this.queue.poll() != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsValue(Object paramObject) {
/*  649 */     if (paramObject == null) {
/*  650 */       return containsNullValue();
/*      */     }
/*  652 */     Entry[] arrayOfEntry = (Entry[])getTable();
/*  653 */     for (int i = arrayOfEntry.length; i-- > 0;) {
/*  654 */       for (Entry entry = arrayOfEntry[i]; entry != null; entry = entry.next)
/*  655 */       { if (paramObject.equals(entry.value))
/*  656 */           return true;  } 
/*  657 */     }  return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean containsNullValue() {
/*  664 */     Entry[] arrayOfEntry = (Entry[])getTable();
/*  665 */     for (int i = arrayOfEntry.length; i-- > 0;) {
/*  666 */       for (Entry entry = arrayOfEntry[i]; entry != null; entry = entry.next)
/*  667 */       { if (entry.value == null)
/*  668 */           return true;  } 
/*  669 */     }  return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class Entry<K, V>
/*      */     extends WeakReference<Object>
/*      */     implements Map.Entry<K, V>
/*      */   {
/*      */     V value;
/*      */ 
/*      */     
/*      */     final int hash;
/*      */     
/*      */     Entry<K, V> next;
/*      */ 
/*      */     
/*      */     Entry(Object param1Object, V param1V, ReferenceQueue<Object> param1ReferenceQueue, int param1Int, Entry<K, V> param1Entry) {
/*  687 */       super(param1Object, param1ReferenceQueue);
/*  688 */       this.value = param1V;
/*  689 */       this.hash = param1Int;
/*  690 */       this.next = param1Entry;
/*      */     }
/*      */ 
/*      */     
/*      */     public K getKey() {
/*  695 */       return (K)WeakIdentityHashMap.unmaskNull(get());
/*      */     }
/*      */     
/*      */     public V getValue() {
/*  699 */       return this.value;
/*      */     }
/*      */     
/*      */     public V setValue(V param1V) {
/*  703 */       V v = this.value;
/*  704 */       this.value = param1V;
/*  705 */       return v;
/*      */     }
/*      */     
/*      */     public boolean equals(Object param1Object) {
/*  709 */       if (!(param1Object instanceof Map.Entry))
/*  710 */         return false; 
/*  711 */       Map.Entry entry = (Map.Entry)param1Object;
/*  712 */       K k = getKey();
/*  713 */       Object object = entry.getKey();
/*  714 */       if (k == object) {
/*  715 */         V v = getValue();
/*  716 */         Object object1 = entry.getValue();
/*  717 */         if (v == object1 || (v != null && v.equals(object1)))
/*  718 */           return true; 
/*      */       } 
/*  720 */       return false;
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*  724 */       K k = getKey();
/*  725 */       V v = getValue();
/*  726 */       return ((k == null) ? 0 : System.identityHashCode(k)) ^ ((v == null) ? 0 : v.hashCode());
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  731 */       return (new StringBuilder()).append(getKey()).append("=").append(getValue()).toString();
/*      */     }
/*      */   }
/*      */   
/*      */   private abstract class HashIterator<T> implements Iterator<T> {
/*      */     private int index;
/*  737 */     private WeakIdentityHashMap.Entry<K, V> entry = null;
/*  738 */     private WeakIdentityHashMap.Entry<K, V> lastReturned = null;
/*  739 */     private int expectedModCount = WeakIdentityHashMap.this.modCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  745 */     private Object nextKey = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  751 */     private Object currentKey = null;
/*      */     
/*      */     HashIterator() {
/*  754 */       this.index = WeakIdentityHashMap.this.isEmpty() ? 0 : WeakIdentityHashMap.this.table.length;
/*      */     }
/*      */     
/*      */     public boolean hasNext() {
/*  758 */       WeakIdentityHashMap.Entry[] arrayOfEntry = WeakIdentityHashMap.this.table;
/*      */       
/*  760 */       while (this.nextKey == null) {
/*  761 */         WeakIdentityHashMap.Entry<K, V> entry = this.entry;
/*  762 */         int i = this.index;
/*  763 */         while (entry == null && i > 0)
/*  764 */           entry = arrayOfEntry[--i]; 
/*  765 */         this.entry = entry;
/*  766 */         this.index = i;
/*  767 */         if (entry == null) {
/*  768 */           this.currentKey = null;
/*  769 */           return false;
/*      */         } 
/*  771 */         this.nextKey = entry.get();
/*  772 */         if (this.nextKey == null)
/*  773 */           this.entry = this.entry.next; 
/*      */       } 
/*  775 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     protected WeakIdentityHashMap.Entry<K, V> nextEntry() {
/*  780 */       if (WeakIdentityHashMap.this.modCount != this.expectedModCount)
/*  781 */         throw new ConcurrentModificationException(); 
/*  782 */       if (this.nextKey == null && !hasNext()) {
/*  783 */         throw new NoSuchElementException();
/*      */       }
/*  785 */       this.lastReturned = this.entry;
/*  786 */       this.entry = this.entry.next;
/*  787 */       this.currentKey = this.nextKey;
/*  788 */       this.nextKey = null;
/*  789 */       return this.lastReturned;
/*      */     }
/*      */     
/*      */     public void remove() {
/*  793 */       if (this.lastReturned == null)
/*  794 */         throw new IllegalStateException(); 
/*  795 */       if (WeakIdentityHashMap.this.modCount != this.expectedModCount) {
/*  796 */         throw new ConcurrentModificationException();
/*      */       }
/*  798 */       WeakIdentityHashMap.this.remove(this.currentKey);
/*  799 */       this.expectedModCount = WeakIdentityHashMap.this.modCount;
/*  800 */       this.lastReturned = null;
/*  801 */       this.currentKey = null;
/*      */     }
/*      */   }
/*      */   
/*      */   private class ValueIterator extends HashIterator<V> { private ValueIterator() {}
/*      */     
/*      */     public V next() {
/*  808 */       return (nextEntry()).value;
/*      */     } }
/*      */   
/*      */   private class KeyIterator extends HashIterator<K> { private KeyIterator() {}
/*      */     
/*      */     public K next() {
/*  814 */       return (K)nextEntry().getKey();
/*      */     } }
/*      */   
/*      */   private class EntryIterator extends HashIterator<Map.Entry<K, V>> { private EntryIterator() {}
/*      */     
/*      */     public Map.Entry<K, V> next() {
/*  820 */       return nextEntry();
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   public WeakIdentityHashMap(int paramInt, float paramFloat) {
/*  826 */     this.entrySet = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  833 */     this.keySet = null;
/*  834 */     this.values = null; if (paramInt < 0) throw new IllegalArgumentException("Illegal Initial Capacity: " + paramInt);  if (paramInt > 1073741824) paramInt = 1073741824;  if (paramFloat <= 0.0F || Float.isNaN(paramFloat)) throw new IllegalArgumentException("Illegal Load factor: " + paramFloat);  int i = 1; while (i < paramInt) i <<= 1;  this.table = newTable(i); this.loadFactor = paramFloat; this.threshold = (int)(i * paramFloat); } public WeakIdentityHashMap() { this.entrySet = null; this.keySet = null; this.values = null;
/*      */     this.loadFactor = 0.75F;
/*      */     this.threshold = 16;
/*      */     this.table = newTable(16); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<K> keySet() {
/*  850 */     Set<K> set = this.keySet;
/*  851 */     return (set != null) ? set : (this.keySet = new KeySet());
/*      */   }
/*      */   private class KeySet extends AbstractSet<K> { private KeySet() {}
/*      */     
/*      */     public Iterator<K> iterator() {
/*  856 */       return new WeakIdentityHashMap.KeyIterator();
/*      */     }
/*      */     
/*      */     public int size() {
/*  860 */       return WeakIdentityHashMap.this.size();
/*      */     }
/*      */     
/*      */     public boolean contains(Object param1Object) {
/*  864 */       return WeakIdentityHashMap.this.containsKey(param1Object);
/*      */     }
/*      */     
/*      */     public boolean remove(Object param1Object) {
/*  868 */       if (WeakIdentityHashMap.this.containsKey(param1Object)) {
/*  869 */         WeakIdentityHashMap.this.remove(param1Object);
/*  870 */         return true;
/*      */       } 
/*      */       
/*  873 */       return false;
/*      */     }
/*      */     
/*      */     public void clear() {
/*  877 */       WeakIdentityHashMap.this.clear();
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<V> values() {
/*  895 */     Collection<V> collection = this.values;
/*  896 */     return (collection != null) ? collection : (this.values = new Values());
/*      */   }
/*      */   private class Values extends AbstractCollection<V> { private Values() {}
/*      */     
/*      */     public Iterator<V> iterator() {
/*  901 */       return new WeakIdentityHashMap.ValueIterator();
/*      */     }
/*      */     
/*      */     public int size() {
/*  905 */       return WeakIdentityHashMap.this.size();
/*      */     }
/*      */     
/*      */     public boolean contains(Object param1Object) {
/*  909 */       return WeakIdentityHashMap.this.containsValue(param1Object);
/*      */     }
/*      */     
/*      */     public void clear() {
/*  913 */       WeakIdentityHashMap.this.clear();
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Map.Entry<K, V>> entrySet() {
/*  932 */     Set<Map.Entry<K, V>> set = this.entrySet;
/*  933 */     return (set != null) ? set : (this.entrySet = new EntrySet());
/*      */   }
/*      */   private class EntrySet extends AbstractSet<Map.Entry<K, V>> { private EntrySet() {}
/*      */     
/*      */     public Iterator<Map.Entry<K, V>> iterator() {
/*  938 */       return new WeakIdentityHashMap.EntryIterator();
/*      */     }
/*      */     
/*      */     public boolean contains(Object param1Object) {
/*  942 */       if (!(param1Object instanceof Map.Entry))
/*  943 */         return false; 
/*  944 */       Map.Entry entry = (Map.Entry)param1Object;
/*  945 */       WeakIdentityHashMap.Entry entry1 = WeakIdentityHashMap.this.getEntry(entry.getKey());
/*  946 */       return (entry1 != null && entry1.equals(entry));
/*      */     }
/*      */     
/*      */     public boolean remove(Object param1Object) {
/*  950 */       return WeakIdentityHashMap.this.removeMapping(param1Object);
/*      */     }
/*      */     
/*      */     public int size() {
/*  954 */       return WeakIdentityHashMap.this.size();
/*      */     }
/*      */     
/*      */     public void clear() {
/*  958 */       WeakIdentityHashMap.this.clear();
/*      */     }
/*      */     
/*      */     private List<Map.Entry<K, V>> deepCopy() {
/*  962 */       ArrayList<Map.Entry<K, V>> arrayList = new ArrayList(size());
/*      */       
/*  964 */       for (Map.Entry<?, ?> entry : (Iterable<Map.Entry<?, ?>>)this)
/*  965 */         arrayList.add(new AbstractMap.SimpleEntry<Object, Object>(entry)); 
/*  966 */       return arrayList;
/*      */     }
/*      */     
/*      */     public Object[] toArray() {
/*  970 */       return deepCopy().toArray();
/*      */     }
/*      */     
/*      */     public <T> T[] toArray(T[] param1ArrayOfT) {
/*  974 */       return deepCopy().toArray(param1ArrayOfT);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object paramObject) {
/* 1002 */     if (paramObject == this) {
/* 1003 */       return true;
/*      */     }
/* 1005 */     if (!(paramObject instanceof Map))
/* 1006 */       return false; 
/* 1007 */     Map map = (Map)paramObject;
/* 1008 */     if (map.size() != size()) {
/* 1009 */       return false;
/*      */     }
/*      */     try {
/* 1012 */       Iterator<Map.Entry<K, V>> iterator = entrySet().iterator();
/* 1013 */       while (iterator.hasNext()) {
/* 1014 */         Map.Entry entry = iterator.next();
/* 1015 */         Object object1 = entry.getKey();
/* 1016 */         Object object2 = entry.getValue();
/* 1017 */         if (object2 == null) {
/* 1018 */           if (map.get(object1) != null || !map.containsKey(object1))
/* 1019 */             return false;  continue;
/*      */         } 
/* 1021 */         if (!object2.equals(map.get(object1))) {
/* 1022 */           return false;
/*      */         }
/*      */       } 
/* 1025 */     } catch (ClassCastException classCastException) {
/* 1026 */       return false;
/* 1027 */     } catch (NullPointerException nullPointerException) {
/* 1028 */       return false;
/*      */     } 
/*      */     
/* 1031 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1052 */     int i = 0;
/* 1053 */     Iterator<Map.Entry<K, V>> iterator = entrySet().iterator();
/* 1054 */     while (iterator.hasNext())
/* 1055 */       i += ((Map.Entry)iterator.next()).hashCode(); 
/* 1056 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1072 */     Iterator<Map.Entry<K, V>> iterator = entrySet().iterator();
/* 1073 */     if (!iterator.hasNext()) {
/* 1074 */       return "{}";
/*      */     }
/* 1076 */     StringBuilder stringBuilder = new StringBuilder();
/* 1077 */     stringBuilder.append('{');
/*      */     while (true) {
/* 1079 */       Map.Entry entry = iterator.next();
/* 1080 */       Object object1 = entry.getKey();
/* 1081 */       Object object2 = entry.getValue();
/* 1082 */       stringBuilder.append((object1 == this) ? "(this Map)" : object1);
/* 1083 */       stringBuilder.append('=');
/* 1084 */       stringBuilder.append((object2 == this) ? "(this Map)" : object2);
/* 1085 */       if (!iterator.hasNext())
/* 1086 */         return stringBuilder.append('}').toString(); 
/* 1087 */       stringBuilder.append(", ");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object clone() throws CloneNotSupportedException {
/* 1098 */     WeakIdentityHashMap weakIdentityHashMap = (WeakIdentityHashMap)super.clone();
/* 1099 */     weakIdentityHashMap.keySet = null;
/* 1100 */     weakIdentityHashMap.values = null;
/* 1101 */     return weakIdentityHashMap;
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\WeakIdentityHashMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */