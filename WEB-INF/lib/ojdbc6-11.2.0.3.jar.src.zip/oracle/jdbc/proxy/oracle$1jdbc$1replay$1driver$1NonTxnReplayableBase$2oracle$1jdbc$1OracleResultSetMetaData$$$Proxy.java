package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetMetaData$$$Proxy extends NonTxnReplayableBase implements OracleResultSetMetaData, _Proxy_ {
  private OracleResultSetMetaData delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25020;
  
  private static Method methodObject25009;
  
  private static Method methodObject25012;
  
  private static Method methodObject25019;
  
  private static Method methodObject25002;
  
  private static Method methodObject24999;
  
  private static Method methodObject25021;
  
  private static Method methodObject25022;
  
  private static Method methodObject25006;
  
  private static Method methodObject25005;
  
  private static Method methodObject25007;
  
  private static Method methodObject25014;
  
  private static Method methodObject25008;
  
  private static Method methodObject25013;
  
  private static Method methodObject25017;
  
  private static Method methodObject25010;
  
  private static Method methodObject25023;
  
  private static Method methodObject25015;
  
  private static Method methodObject25003;
  
  private static Method methodObject25001;
  
  private static Method methodObject25018;
  
  private static Method methodObject25016;
  
  private static Method methodObject25004;
  
  private static Method methodObject25011;
  
  private static Method methodObject25000;
  
  public boolean isSearchable(int arg0) throws SQLException {
    try {
      preForAll(methodObject25020, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25020, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSearchable(arg0)), this, (Map)this.proxyCache, methodObject25020))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25020, onErrorForAll(methodObject25020, e))).booleanValue();
    } 
  }
  
  public int getColumnDisplaySize(int arg0) throws SQLException {
    try {
      preForAll(methodObject25009, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25009, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnDisplaySize(arg0)), this, (Map)this.proxyCache, methodObject25009))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25009, onErrorForAll(methodObject25009, e))).intValue();
    } 
  }
  
  public int getColumnType(int arg0) throws SQLException {
    try {
      preForAll(methodObject25012, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25012, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnType(arg0)), this, (Map)this.proxyCache, methodObject25012))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25012, onErrorForAll(methodObject25012, e))).intValue();
    } 
  }
  
  public boolean isDefinitelyWritable(int arg0) throws SQLException {
    try {
      preForAll(methodObject25019, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25019, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isDefinitelyWritable(arg0)), this, (Map)this.proxyCache, methodObject25019))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25019, onErrorForAll(methodObject25019, e))).booleanValue();
    } 
  }
  
  public int getPrecision(int arg0) throws SQLException {
    try {
      preForAll(methodObject25002, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25002, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, (Map)this.proxyCache, methodObject25002))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25002, onErrorForAll(methodObject25002, e))).intValue();
    } 
  }
  
  public boolean isNCHAR(int arg0) throws SQLException {
    try {
      preForAll(methodObject24999, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24999, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isNCHAR(arg0)), this, (Map)this.proxyCache, methodObject24999))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24999, onErrorForAll(methodObject24999, e))).booleanValue();
    } 
  }
  
  public boolean isWritable(int arg0) throws SQLException {
    try {
      preForAll(methodObject25021, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25021, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isWritable(arg0)), this, (Map)this.proxyCache, methodObject25021))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25021, onErrorForAll(methodObject25021, e))).booleanValue();
    } 
  }
  
  public boolean isWrapperFor(Class arg0) throws SQLException {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public String getCatalogName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25006, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25006, this.proxyFactory.proxyFor(this.delegate.getCatalogName(arg0), this, (Map)this.proxyCache, methodObject25006));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25006, onErrorForAll(methodObject25006, e));
    } 
  }
  
  public boolean isSigned(int arg0) throws SQLException {
    try {
      preForAll(methodObject25005, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25005, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, (Map)this.proxyCache, methodObject25005))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25005, onErrorForAll(methodObject25005, e))).booleanValue();
    } 
  }
  
  public String getColumnClassName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25007, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25007, this.proxyFactory.proxyFor(this.delegate.getColumnClassName(arg0), this, (Map)this.proxyCache, methodObject25007));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25007, onErrorForAll(methodObject25007, e));
    } 
  }
  
  public String getSchemaName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25014, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25014, this.proxyFactory.proxyFor(this.delegate.getSchemaName(arg0), this, (Map)this.proxyCache, methodObject25014));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25014, onErrorForAll(methodObject25014, e));
    } 
  }
  
  public int getColumnCount() throws SQLException {
    try {
      preForAll(methodObject25008, this, new Object[0]);
      return ((Integer)postForAll(methodObject25008, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnCount()), this, (Map)this.proxyCache, methodObject25008))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25008, onErrorForAll(methodObject25008, e))).intValue();
    } 
  }
  
  public String getColumnTypeName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25013, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25013, this.proxyFactory.proxyFor(this.delegate.getColumnTypeName(arg0), this, (Map)this.proxyCache, methodObject25013));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25013, onErrorForAll(methodObject25013, e));
    } 
  }
  
  public boolean isCaseSensitive(int arg0) throws SQLException {
    try {
      preForAll(methodObject25017, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25017, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCaseSensitive(arg0)), this, (Map)this.proxyCache, methodObject25017))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25017, onErrorForAll(methodObject25017, e))).booleanValue();
    } 
  }
  
  public String getColumnLabel(int arg0) throws SQLException {
    try {
      preForAll(methodObject25010, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25010, this.proxyFactory.proxyFor(this.delegate.getColumnLabel(arg0), this, (Map)this.proxyCache, methodObject25010));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25010, onErrorForAll(methodObject25010, e));
    } 
  }
  
  public Object unwrap(Class arg0) throws SQLException {
    return this.delegate.unwrap(arg0);
  }
  
  public String getTableName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25015, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25015, this.proxyFactory.proxyFor(this.delegate.getTableName(arg0), this, (Map)this.proxyCache, methodObject25015));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25015, onErrorForAll(methodObject25015, e));
    } 
  }
  
  public int getScale(int arg0) throws SQLException {
    try {
      preForAll(methodObject25003, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25003, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, (Map)this.proxyCache, methodObject25003))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25003, onErrorForAll(methodObject25003, e))).intValue();
    } 
  }
  
  public boolean isReadOnly(int arg0) throws SQLException {
    try {
      preForAll(methodObject25001, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25001, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isReadOnly(arg0)), this, (Map)this.proxyCache, methodObject25001))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25001, onErrorForAll(methodObject25001, e))).booleanValue();
    } 
  }
  
  public boolean isCurrency(int arg0) throws SQLException {
    try {
      preForAll(methodObject25018, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25018, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCurrency(arg0)), this, (Map)this.proxyCache, methodObject25018))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25018, onErrorForAll(methodObject25018, e))).booleanValue();
    } 
  }
  
  public boolean isAutoIncrement(int arg0) throws SQLException {
    try {
      preForAll(methodObject25016, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25016, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isAutoIncrement(arg0)), this, (Map)this.proxyCache, methodObject25016))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25016, onErrorForAll(methodObject25016, e))).booleanValue();
    } 
  }
  
  public int isNullable(int arg0) throws SQLException {
    try {
      preForAll(methodObject25004, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25004, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, (Map)this.proxyCache, methodObject25004))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25004, onErrorForAll(methodObject25004, e))).intValue();
    } 
  }
  
  public String getColumnName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25011, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25011, this.proxyFactory.proxyFor(this.delegate.getColumnName(arg0), this, (Map)this.proxyCache, methodObject25011));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25011, onErrorForAll(methodObject25011, e));
    } 
  }
  
  public OracleResultSetMetaData.SecurityAttribute getSecurityAttribute(int arg0) throws SQLException {
    try {
      preForAll(methodObject25000, this, new Object[] { Integer.valueOf(arg0) });
      return (OracleResultSetMetaData.SecurityAttribute)postForAll(methodObject25000, this.proxyFactory.proxyFor(this.delegate.getSecurityAttribute(arg0), this, (Map)this.proxyCache, methodObject25000));
    } catch (SQLException e) {
      return (OracleResultSetMetaData.SecurityAttribute)postForAll(methodObject25000, onErrorForAll(methodObject25000, e));
    } 
  }
  
  public OracleResultSetMetaData _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleResultSetMetaData delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25020 = ResultSetMetaData.class.getDeclaredMethod("isSearchable", new Class[] { int.class });
      methodObject25009 = ResultSetMetaData.class.getDeclaredMethod("getColumnDisplaySize", new Class[] { int.class });
      methodObject25012 = ResultSetMetaData.class.getDeclaredMethod("getColumnType", new Class[] { int.class });
      methodObject25019 = ResultSetMetaData.class.getDeclaredMethod("isDefinitelyWritable", new Class[] { int.class });
      methodObject25002 = ResultSetMetaData.class.getDeclaredMethod("getPrecision", new Class[] { int.class });
      methodObject24999 = OracleResultSetMetaData.class.getDeclaredMethod("isNCHAR", new Class[] { int.class });
      methodObject25021 = ResultSetMetaData.class.getDeclaredMethod("isWritable", new Class[] { int.class });
      methodObject25022 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject25006 = ResultSetMetaData.class.getDeclaredMethod("getCatalogName", new Class[] { int.class });
      methodObject25005 = ResultSetMetaData.class.getDeclaredMethod("isSigned", new Class[] { int.class });
      methodObject25007 = ResultSetMetaData.class.getDeclaredMethod("getColumnClassName", new Class[] { int.class });
      methodObject25014 = ResultSetMetaData.class.getDeclaredMethod("getSchemaName", new Class[] { int.class });
      methodObject25008 = ResultSetMetaData.class.getDeclaredMethod("getColumnCount", new Class[0]);
      methodObject25013 = ResultSetMetaData.class.getDeclaredMethod("getColumnTypeName", new Class[] { int.class });
      methodObject25017 = ResultSetMetaData.class.getDeclaredMethod("isCaseSensitive", new Class[] { int.class });
      methodObject25010 = ResultSetMetaData.class.getDeclaredMethod("getColumnLabel", new Class[] { int.class });
      methodObject25023 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject25015 = ResultSetMetaData.class.getDeclaredMethod("getTableName", new Class[] { int.class });
      methodObject25003 = ResultSetMetaData.class.getDeclaredMethod("getScale", new Class[] { int.class });
      methodObject25001 = ResultSetMetaData.class.getDeclaredMethod("isReadOnly", new Class[] { int.class });
      methodObject25018 = ResultSetMetaData.class.getDeclaredMethod("isCurrency", new Class[] { int.class });
      methodObject25016 = ResultSetMetaData.class.getDeclaredMethod("isAutoIncrement", new Class[] { int.class });
      methodObject25004 = ResultSetMetaData.class.getDeclaredMethod("isNullable", new Class[] { int.class });
      methodObject25011 = ResultSetMetaData.class.getDeclaredMethod("getColumnName", new Class[] { int.class });
      methodObject25000 = OracleResultSetMetaData.class.getDeclaredMethod("getSecurityAttribute", new Class[] { int.class });
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetMetaData$$$Proxy(OracleResultSetMetaData paramOracleResultSetMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleResultSetMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleResultSetMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */