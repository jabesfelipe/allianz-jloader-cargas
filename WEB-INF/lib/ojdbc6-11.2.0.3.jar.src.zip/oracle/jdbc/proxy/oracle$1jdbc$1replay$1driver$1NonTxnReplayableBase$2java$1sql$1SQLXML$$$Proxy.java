package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.util.Map;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLXML$$$Proxy extends NonTxnReplayableBase implements SQLXML, _Proxy_ {
  private SQLXML delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject24975;
  
  private static Method methodObject24978;
  
  private static Method methodObject24974;
  
  private static Method methodObject24979;
  
  private static Method methodObject24980;
  
  private static Method methodObject24976;
  
  private static Method methodObject24977;
  
  private static Method methodObject24973;
  
  private static Method methodObject24981;
  
  public OutputStream setBinaryStream() throws SQLException {
    try {
      preForAll(methodObject24975, this, new Object[0]);
      return (OutputStream)postForAll(methodObject24975, this.proxyFactory.proxyFor(this.delegate.setBinaryStream(), this, (Map)this.proxyCache, methodObject24975));
    } catch (SQLException e) {
      return (OutputStream)postForAll(methodObject24975, onErrorForAll(methodObject24975, e));
    } 
  }
  
  public void free() throws SQLException {
    try {
      preForAll(methodObject24978, this, new Object[0]);
      this.delegate.free();
      postForAll(methodObject24978);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject24978, e);
      return;
    } 
  }
  
  public Source getSource(Class<Source> arg0) throws SQLException {
    try {
      preForAll(methodObject24974, this, new Object[] { arg0 });
      return (Source)postForAll(methodObject24974, this.proxyFactory.proxyFor(this.delegate.<Source>getSource(arg0), this, (Map)this.proxyCache, methodObject24974));
    } catch (SQLException e) {
      return (Source)postForAll(methodObject24974, onErrorForAll(methodObject24974, e));
    } 
  }
  
  public InputStream getBinaryStream() throws SQLException {
    try {
      preForAll(methodObject24979, this, new Object[0]);
      return (InputStream)postForAll(methodObject24979, this.proxyFactory.proxyFor(this.delegate.getBinaryStream(), this, (Map)this.proxyCache, methodObject24979));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject24979, onErrorForAll(methodObject24979, e));
    } 
  }
  
  public Reader getCharacterStream() throws SQLException {
    try {
      preForAll(methodObject24980, this, new Object[0]);
      return (Reader)postForAll(methodObject24980, this.proxyFactory.proxyFor(this.delegate.getCharacterStream(), this, (Map)this.proxyCache, methodObject24980));
    } catch (SQLException e) {
      return (Reader)postForAll(methodObject24980, onErrorForAll(methodObject24980, e));
    } 
  }
  
  public Writer setCharacterStream() throws SQLException {
    try {
      preForAll(methodObject24976, this, new Object[0]);
      return (Writer)postForAll(methodObject24976, this.proxyFactory.proxyFor(this.delegate.setCharacterStream(), this, (Map)this.proxyCache, methodObject24976));
    } catch (SQLException e) {
      return (Writer)postForAll(methodObject24976, onErrorForAll(methodObject24976, e));
    } 
  }
  
  public void setString(String arg0) throws SQLException {
    try {
      preForAll(methodObject24977, this, new Object[] { arg0 });
      this.delegate.setString(arg0);
      postForAll(methodObject24977);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject24977, e);
      return;
    } 
  }
  
  public String getString() throws SQLException {
    try {
      preForAll(methodObject24973, this, new Object[0]);
      return (String)postForAll(methodObject24973, this.proxyFactory.proxyFor(this.delegate.getString(), this, (Map)this.proxyCache, methodObject24973));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24973, onErrorForAll(methodObject24973, e));
    } 
  }
  
  public Result setResult(Class<Result> arg0) throws SQLException {
    try {
      preForAll(methodObject24981, this, new Object[] { arg0 });
      return (Result)postForAll(methodObject24981, this.proxyFactory.proxyFor(this.delegate.<Result>setResult(arg0), this, (Map)this.proxyCache, methodObject24981));
    } catch (SQLException e) {
      return (Result)postForAll(methodObject24981, onErrorForAll(methodObject24981, e));
    } 
  }
  
  public SQLXML _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(SQLXML delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject24975 = SQLXML.class.getDeclaredMethod("setBinaryStream", new Class[0]);
      methodObject24978 = SQLXML.class.getDeclaredMethod("free", new Class[0]);
      methodObject24974 = SQLXML.class.getDeclaredMethod("getSource", new Class[] { Class.class });
      methodObject24979 = SQLXML.class.getDeclaredMethod("getBinaryStream", new Class[0]);
      methodObject24980 = SQLXML.class.getDeclaredMethod("getCharacterStream", new Class[0]);
      methodObject24976 = SQLXML.class.getDeclaredMethod("setCharacterStream", new Class[0]);
      methodObject24977 = SQLXML.class.getDeclaredMethod("setString", new Class[] { String.class });
      methodObject24973 = SQLXML.class.getDeclaredMethod("getString", new Class[0]);
      methodObject24981 = SQLXML.class.getDeclaredMethod("setResult", new Class[] { Class.class });
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLXML$$$Proxy(SQLXML paramSQLXML, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramSQLXML;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLXML$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */