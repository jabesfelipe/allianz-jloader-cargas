/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.objectweb.asm.ClassReader;
/*     */ import org.objectweb.asm.ClassWriter;
/*     */ import org.objectweb.asm.Label;
/*     */ import org.objectweb.asm.MethodVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClassGenerator
/*     */ {
/*     */   private final AnnotationsForIface annotationsForIface;
/*     */   private final String proxyName;
/*     */   private final String superclassName;
/*     */   private final String ifaceName;
/*     */   private final String proxyType;
/*     */   private final String ifaceType;
/*     */   final Map<MethodSignature, MethodGenerator> members;
/*     */   
/*     */   static class AnnotationsForIface
/*     */   {
/*     */     private final AnnotationsRegistry registry;
/*     */     private final Class iface;
/*     */     private final AnnotationsRegistry.Value value;
/*     */     
/*     */     AnnotationsForIface(AnnotationsRegistry param1AnnotationsRegistry, Class param1Class, AnnotationsRegistry.Value param1Value) {
/*  74 */       this.registry = param1AnnotationsRegistry;
/*  75 */       this.iface = param1Class;
/*  76 */       this.value = param1Value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AnnotationsRegistry getRegistry() {
/*  84 */       return this.registry;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Class getIface() {
/*  92 */       return this.iface;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AnnotationsRegistry.Value getValue() {
/* 100 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassGenerator(AnnotationsForIface paramAnnotationsForIface, String paramString1, String paramString2, String paramString3, Map<MethodSignature, MethodGenerator> paramMap) {
/* 116 */     this.annotationsForIface = paramAnnotationsForIface;
/* 117 */     this.proxyName = Utils.makeSlashed(paramString1);
/* 118 */     this.proxyType = Utils.makeType(paramString1);
/* 119 */     this.superclassName = Utils.makeSlashed(paramString2);
/* 120 */     this.ifaceName = Utils.makeSlashed(paramString3);
/* 121 */     this.ifaceType = Utils.makeType(paramString3);
/* 122 */     this.members = paramMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getProxyName() {
/* 130 */     return this.proxyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getSuperclassName() {
/* 138 */     return this.superclassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getIfaceName() {
/* 146 */     return this.ifaceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getProxyType() {
/* 154 */     return this.proxyType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getIfaceType() {
/* 162 */     return this.ifaceType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> byte[] generateBytecode(GeneratedProxiesRegistry.Key paramKey, AnnotationsRegistry paramAnnotationsRegistry) {
/* 169 */     Class clazz1 = paramKey.getIface();
/* 170 */     final Class superclass = paramKey.getSuperclass();
/*     */     
/* 172 */     if (!clazz1.isInterface()) {
/* 173 */       new RuntimeException("iface must be interface");
/*     */     }
/* 175 */     if (clazz2.isInterface()) {
/* 176 */       new RuntimeException("sclass must not be interface");
/*     */     }
/* 178 */     HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
/*     */ 
/*     */     
/* 181 */     final HashMap<Object, Object> superclassMethods = new HashMap<Object, Object>();
/*     */ 
/*     */     
/* 184 */     AnnotationsForIface annotationsForIface = new AnnotationsForIface(paramAnnotationsRegistry, clazz1, paramAnnotationsRegistry.get(clazz1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     ClassGenerator classGenerator = new ClassGenerator(annotationsForIface, paramKey.toString(), clazz2.getName(), clazz1.getName(), (Map)hashMap1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     (new Runnable() {
/*     */         public void run() {
/* 200 */           traverse(superclass);
/*     */         }
/*     */         void traverse(Class param1Class) {
/* 203 */           if (null == param1Class) {
/*     */             return;
/*     */           }
/* 206 */           for (Method method : param1Class.getDeclaredMethods()) {
/* 207 */             superclassMethods.put(new MethodSignature(method), method);
/*     */           }
/* 209 */           traverse(param1Class.getSuperclass());
/*     */         }
/*     */       }).run();
/*     */ 
/*     */     
/* 214 */     for (Method method1 : clazz1.getMethods()) {
/*     */       
/* 216 */       MethodSignature methodSignature = new MethodSignature(method1);
/*     */ 
/*     */       
/* 219 */       Method method2 = (Method)hashMap2.get(methodSignature);
/*     */ 
/*     */       
/* 222 */       hashMap1.put(methodSignature, new MethodGenerator(classGenerator, method1, (null == method2 || Modifier.isAbstract(method2.getModifiers()))));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     ClassWriter classWriter = new ClassWriter(3);
/*     */ 
/*     */     
/* 233 */     classGenerator.generate(classWriter);
/* 234 */     return classWriter.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Class generate(Class<T> paramClass, Class paramClass1, AnnotationsRegistry paramAnnotationsRegistry) {
/* 242 */     GeneratedProxiesRegistry.Key key = new GeneratedProxiesRegistry.Key(paramClass, paramClass1);
/*     */ 
/*     */     
/* 245 */     final byte[] bytecode = generateBytecode(key, paramAnnotationsRegistry);
/*     */ 
/*     */ 
/*     */     
/* 249 */     String str = System.getProperty("oracle.jdbc.proxy.asm.verify");
/* 250 */     if (null != str && 0 == "true".compareToIgnoreCase(str)) {
/*     */ 
/*     */       
/* 253 */       try { Class<?> clazz = Class.forName("org.objectweb.asm.util.CheckClassAdapter");
/*     */ 
/*     */         
/* 256 */         Method method = clazz.getMethod("verify", new Class[] { ClassReader.class, boolean.class, PrintWriter.class });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 263 */         method.invoke(null, new Object[] { new ClassReader(arrayOfByte), Boolean.valueOf(true), new PrintWriter(new OutputStreamWriter(System.out)) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */          }
/*     */       
/* 272 */       catch (ClassNotFoundException classNotFoundException) {  }
/* 273 */       catch (NoSuchMethodException noSuchMethodException) {  }
/* 274 */       catch (IllegalAccessException illegalAccessException) {  }
/* 275 */       catch (InvocationTargetException invocationTargetException) {}
/*     */     }
/*     */     
/*     */     try {
/* 279 */       return Class.forName(key.toString(), false, new ClassLoader()
/*     */           {
/*     */ 
/*     */ 
/*     */             
/*     */             protected Class findClass(String param1String)
/*     */             {
/* 286 */               return defineClass(param1String, bytecode, 0, bytecode.length);
/*     */             }
/*     */           });
/*     */     }
/* 290 */     catch (ClassNotFoundException classNotFoundException) {
/*     */       
/* 292 */       throw new RuntimeException(classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void generate(ClassWriter paramClassWriter) {
/* 298 */     paramClassWriter.visit(50, 33, this.proxyName, null, this.superclassName, new String[] { this.ifaceName, Utils.makeSlashed(_Proxy_.class.getName()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 307 */     for (MethodGenerator methodGenerator : this.members.values()) {
/* 308 */       if (null != methodGenerator) {
/* 309 */         methodGenerator.generate(paramClassWriter);
/*     */       }
/*     */     } 
/*     */     
/* 313 */     MethodVisitor methodVisitor1 = paramClassWriter.visitMethod(1, "_getDelegate_", "()" + this.ifaceType, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 321 */     methodVisitor1.visitCode();
/* 322 */     methodVisitor1.visitVarInsn(25, 0);
/* 323 */     methodVisitor1.visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     methodVisitor1.visitInsn(176);
/* 330 */     methodVisitor1.visitMaxs(0, 0);
/* 331 */     methodVisitor1.visitEnd();
/*     */ 
/*     */     
/* 334 */     methodVisitor1 = paramClassWriter.visitMethod(4161, "_getDelegate_", "()Ljava/lang/Object;", null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 342 */     methodVisitor1.visitCode();
/* 343 */     methodVisitor1.visitVarInsn(25, 0);
/* 344 */     methodVisitor1.visitMethodInsn(182, this.proxyName, "_getDelegate_", "()" + this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 350 */     methodVisitor1.visitInsn(176);
/* 351 */     methodVisitor1.visitMaxs(0, 0);
/* 352 */     methodVisitor1.visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     AnnotationsRegistry.Value value = this.annotationsForIface.getValue();
/*     */ 
/*     */     
/* 360 */     if (null != value) {
/*     */ 
/*     */       
/* 363 */       Method method1 = value.getMethodGetDelegate();
/*     */ 
/*     */       
/* 366 */       if (null != method1) {
/*     */         
/* 368 */         MethodVisitor methodVisitor = paramClassWriter.visitMethod(1, method1.getName(), "()" + Utils.makeType(method1.getReturnType()), null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 375 */         methodVisitor.visitCode();
/* 376 */         Label label1 = new Label();
/* 377 */         methodVisitor.visitLabel(label1);
/* 378 */         methodVisitor.visitVarInsn(25, 0);
/* 379 */         methodVisitor.visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/* 380 */         methodVisitor.visitInsn(176);
/* 381 */         Label label2 = new Label();
/* 382 */         methodVisitor.visitLabel(label2);
/* 383 */         methodVisitor.visitLocalVariable("this", this.proxyType, null, label1, label2, 0);
/* 384 */         methodVisitor.visitMaxs(0, 0);
/* 385 */         methodVisitor.visitEnd();
/*     */       } 
/*     */ 
/*     */       
/* 389 */       Method method2 = value.getMethodSetDelegate();
/*     */ 
/*     */       
/* 392 */       if (null != method2) {
/*     */         
/* 394 */         Class[] arrayOfClass = method2.getParameterTypes();
/*     */         
/* 396 */         if (1 != arrayOfClass.length) {
/* 397 */           throw new RuntimeException("wrong delegate setter signature");
/*     */         }
/* 399 */         MethodVisitor methodVisitor = paramClassWriter.visitMethod(1, method2.getName(), "(" + Utils.makeType(arrayOfClass[0]) + ")V", null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 407 */         methodVisitor.visitCode();
/*     */         Label label1;
/* 409 */         methodVisitor.visitLabel(label1 = new Label());
/*     */         
/* 411 */         methodVisitor.visitVarInsn(25, 0);
/*     */         
/* 413 */         methodVisitor.visitFieldInsn(180, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 419 */         methodVisitor.visitVarInsn(25, 0);
/* 420 */         methodVisitor.visitVarInsn(25, 0);
/*     */         
/* 422 */         methodVisitor.visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 428 */         methodVisitor.visitVarInsn(25, 1);
/*     */         
/* 430 */         methodVisitor.visitMethodInsn(182, Utils.makeSlashed(ProxyFactory.class), "updateDelegate", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 436 */         methodVisitor.visitVarInsn(25, 0);
/* 437 */         methodVisitor.visitVarInsn(25, 1);
/*     */         
/* 439 */         methodVisitor.visitFieldInsn(181, this.proxyName, "delegate", this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 445 */         methodVisitor.visitInsn(177);
/*     */         Label label2;
/* 447 */         methodVisitor.visitLabel(label2 = new Label());
/*     */         
/* 449 */         methodVisitor.visitLocalVariable("this", this.proxyType, null, label1, label2, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 457 */         methodVisitor.visitLocalVariable("delegate", this.ifaceType, null, label1, label2, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 465 */         methodVisitor.visitMaxs(0, 0);
/* 466 */         methodVisitor.visitEnd();
/*     */       } 
/*     */ 
/*     */       
/* 470 */       Method method3 = value.getMethodGetCreator();
/*     */ 
/*     */       
/* 473 */       if (null != method3) {
/*     */         
/* 475 */         MethodVisitor methodVisitor = paramClassWriter.visitMethod(1, method3.getName(), "()" + Utils.makeType(method3.getReturnType()), null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 483 */         methodVisitor.visitCode();
/* 484 */         Label label1 = new Label();
/* 485 */         methodVisitor.visitLabel(label1);
/* 486 */         methodVisitor.visitVarInsn(25, 0);
/* 487 */         methodVisitor.visitFieldInsn(180, this.proxyName, "creator", "Ljava/lang/Object;");
/* 488 */         methodVisitor.visitInsn(176);
/* 489 */         Label label2 = new Label();
/* 490 */         methodVisitor.visitLabel(label2);
/* 491 */         methodVisitor.visitLocalVariable("this", this.proxyType, null, label1, label2, 0);
/* 492 */         methodVisitor.visitMaxs(1, 1);
/* 493 */         methodVisitor.visitEnd();
/*     */       } 
/*     */ 
/*     */       
/* 497 */       Method method4 = value.getMethodGetProxy();
/*     */ 
/*     */       
/* 500 */       if (null != method4) {
/*     */         
/* 502 */         Class[] arrayOfClass = method4.getParameterTypes();
/*     */ 
/*     */         
/* 505 */         Class<?> clazz = method4.getReturnType();
/*     */ 
/*     */         
/* 508 */         if (!Arrays.deepEquals((Object[])new Class[] { Object.class, Object.class }, (Object[])arrayOfClass) || !Object.class.equals(clazz))
/*     */         {
/* 510 */           throw new RuntimeException("internal error: wrong @GetProxy method");
/*     */         }
/* 512 */         MethodVisitor methodVisitor = paramClassWriter.visitMethod(1, method4.getName(), "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "<T:Ljava/lang/Object;>(TT;Ljava/lang/Object;)TT;", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 520 */         methodVisitor.visitCode();
/* 521 */         methodVisitor.visitVarInsn(25, 0);
/*     */         
/* 523 */         methodVisitor.visitFieldInsn(180, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 529 */         methodVisitor.visitVarInsn(25, 1);
/* 530 */         methodVisitor.visitVarInsn(25, 2);
/*     */         
/* 532 */         methodVisitor.visitMethodInsn(182, Utils.makeSlashed(ProxyFactory.class), "proxyFor", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 538 */         methodVisitor.visitInsn(176);
/* 539 */         methodVisitor.visitMaxs(3, 3);
/* 540 */         methodVisitor.visitEnd();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 546 */     paramClassWriter.visitField(2, "delegate", this.ifaceType, null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 554 */     paramClassWriter.visitField(18, "creator", "Ljava/lang/Object;", null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 562 */     paramClassWriter.visitField(18, "proxyFactory", Utils.makeType(ProxyFactory.class.getName()), null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 570 */     paramClassWriter.visitField(18, "proxyCache", "Ljava/util/Map;", "Ljava/util/Map<Ljava/lang/Object;Ljava/lang/Object;>;", null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 578 */     boolean bool = false;
/* 579 */     for (MethodGenerator methodGenerator : this.members.values()) {
/*     */       
/* 581 */       paramClassWriter.visitField(10, methodGenerator.getMethodObject(), "Ljava/lang/reflect/Method;", null, null).visitEnd();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 588 */       bool = true;
/*     */     } 
/*     */ 
/*     */     
/* 592 */     if (bool) {
/*     */       
/* 594 */       MethodVisitor methodVisitor = paramClassWriter.visitMethod(8, "<clinit>", "()V", null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 602 */       methodVisitor.visitCode();
/*     */ 
/*     */ 
/*     */       
/*     */       Label label1, label2, label3;
/*     */ 
/*     */       
/* 609 */       methodVisitor.visitTryCatchBlock(label1 = new Label(), label2 = new Label(), label3 = new Label(), "java/lang/Throwable");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 615 */       methodVisitor.visitLabel(label1);
/*     */       
/* 617 */       for (MethodGenerator methodGenerator : this.members.values()) {
/* 618 */         methodGenerator.initializeMethodObject(methodVisitor);
/*     */       }
/* 620 */       methodVisitor.visitLabel(label2); Label label4;
/* 621 */       methodVisitor.visitJumpInsn(167, label4 = new Label());
/* 622 */       methodVisitor.visitLabel(label3);
/*     */       
/* 624 */       methodVisitor.visitFrame(4, 0, null, 1, new Object[] { "java/lang/Throwable" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 631 */       methodVisitor.visitVarInsn(58, 0);
/*     */       
/* 633 */       methodVisitor.visitTypeInsn(187, "java/lang/RuntimeException");
/* 634 */       methodVisitor.visitInsn(89);
/* 635 */       methodVisitor.visitVarInsn(25, 0);
/*     */       
/* 637 */       methodVisitor.visitMethodInsn(183, "java/lang/RuntimeException", "<init>", "(Ljava/lang/Throwable;)V");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 643 */       methodVisitor.visitInsn(191);
/*     */       
/* 645 */       methodVisitor.visitLabel(label4);
/* 646 */       methodVisitor.visitFrame(3, 0, null, 0, null);
/* 647 */       methodVisitor.visitInsn(177);
/* 648 */       methodVisitor.visitMaxs(0, 0);
/* 649 */       methodVisitor.visitEnd();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 654 */     String str = "(" + this.ifaceType + "Ljava/lang/Object;" + Utils.makeType(ProxyFactory.class.getName()) + "Ljava/util/Map;" + ")V";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 662 */     MethodVisitor methodVisitor2 = paramClassWriter.visitMethod(1, "<init>", str, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 670 */     methodVisitor2.visitCode();
/* 671 */     methodVisitor2.visitVarInsn(25, 0);
/*     */     
/* 673 */     methodVisitor2.visitMethodInsn(183, this.superclassName, "<init>", "()V");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 679 */     methodVisitor2.visitVarInsn(25, 0);
/* 680 */     methodVisitor2.visitVarInsn(25, 1);
/*     */     
/* 682 */     methodVisitor2.visitFieldInsn(181, this.proxyName, "delegate", this.ifaceType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 688 */     methodVisitor2.visitVarInsn(25, 0);
/* 689 */     methodVisitor2.visitVarInsn(25, 2);
/*     */     
/* 691 */     methodVisitor2.visitFieldInsn(181, this.proxyName, "creator", "Ljava/lang/Object;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 697 */     methodVisitor2.visitVarInsn(25, 0);
/* 698 */     methodVisitor2.visitVarInsn(25, 3);
/*     */     
/* 700 */     methodVisitor2.visitFieldInsn(181, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class.getName()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 706 */     methodVisitor2.visitVarInsn(25, 0);
/* 707 */     methodVisitor2.visitVarInsn(25, 4);
/*     */     
/* 709 */     methodVisitor2.visitFieldInsn(181, this.proxyName, "proxyCache", "Ljava/util/Map;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 715 */     methodVisitor2.visitInsn(177);
/* 716 */     methodVisitor2.visitMaxs(0, 0);
/* 717 */     methodVisitor2.visitEnd();
/*     */ 
/*     */     
/* 720 */     paramClassWriter.visitEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationsForIface getAnnotationsForIface() {
/* 728 */     return this.annotationsForIface;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\ClassGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */