package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.sql.SQLName;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Array$$$Proxy extends NonTxnReplayableBase implements OracleTypeMetaData.Array, _Proxy_ {
  private OracleTypeMetaData.Array delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25037;
  
  private static Method methodObject25035;
  
  private static Method methodObject25032;
  
  private static Method methodObject25033;
  
  private static Method methodObject25038;
  
  private static Method methodObject25036;
  
  private static Method methodObject25039;
  
  private static Method methodObject25031;
  
  private static Method methodObject25034;
  
  private static Method methodObject25030;
  
  public OracleTypeMetaData.Kind getKind() {
    preForAll(methodObject25037, this, new Object[0]);
    return (OracleTypeMetaData.Kind)postForAll(methodObject25037, this.proxyFactory.proxyFor(this.delegate.getKind(), this, (Map)this.proxyCache, methodObject25037));
  }
  
  public int getTypeCode() throws SQLException {
    try {
      preForAll(methodObject25035, this, new Object[0]);
      return ((Integer)postForAll(methodObject25035, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeCode()), this, (Map)this.proxyCache, methodObject25035))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25035, onErrorForAll(methodObject25035, e))).intValue();
    } 
  }
  
  public OracleTypeMetaData.ArrayStorage getArrayStorage() throws SQLException {
    try {
      preForAll(methodObject25032, this, new Object[0]);
      return (OracleTypeMetaData.ArrayStorage)postForAll(methodObject25032, this.proxyFactory.proxyFor(this.delegate.getArrayStorage(), this, (Map)this.proxyCache, methodObject25032));
    } catch (SQLException e) {
      return (OracleTypeMetaData.ArrayStorage)postForAll(methodObject25032, onErrorForAll(methodObject25032, e));
    } 
  }
  
  public long getMaxLength() throws SQLException {
    try {
      preForAll(methodObject25033, this, new Object[0]);
      return ((Long)postForAll(methodObject25033, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getMaxLength()), this, (Map)this.proxyCache, methodObject25033))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject25033, onErrorForAll(methodObject25033, e))).longValue();
    } 
  }
  
  public SQLName getSQLName() throws SQLException {
    try {
      preForAll(methodObject25038, this, new Object[0]);
      return (SQLName)postForAll(methodObject25038, this.proxyFactory.proxyFor(this.delegate.getSQLName(), this, (Map)this.proxyCache, methodObject25038));
    } catch (SQLException e) {
      return (SQLName)postForAll(methodObject25038, onErrorForAll(methodObject25038, e));
    } 
  }
  
  public String getSchemaName() throws SQLException {
    try {
      preForAll(methodObject25036, this, new Object[0]);
      return (String)postForAll(methodObject25036, this.proxyFactory.proxyFor(this.delegate.getSchemaName(), this, (Map)this.proxyCache, methodObject25036));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25036, onErrorForAll(methodObject25036, e));
    } 
  }
  
  public String getTypeCodeName() throws SQLException {
    try {
      preForAll(methodObject25039, this, new Object[0]);
      return (String)postForAll(methodObject25039, this.proxyFactory.proxyFor(this.delegate.getTypeCodeName(), this, (Map)this.proxyCache, methodObject25039));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25039, onErrorForAll(methodObject25039, e));
    } 
  }
  
  public String getBaseName() throws SQLException {
    try {
      preForAll(methodObject25031, this, new Object[0]);
      return (String)postForAll(methodObject25031, this.proxyFactory.proxyFor(this.delegate.getBaseName(), this, (Map)this.proxyCache, methodObject25031));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25031, onErrorForAll(methodObject25031, e));
    } 
  }
  
  public String getName() throws SQLException {
    try {
      preForAll(methodObject25034, this, new Object[0]);
      return (String)postForAll(methodObject25034, this.proxyFactory.proxyFor(this.delegate.getName(), this, (Map)this.proxyCache, methodObject25034));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25034, onErrorForAll(methodObject25034, e));
    } 
  }
  
  public int getBaseType() throws SQLException {
    try {
      preForAll(methodObject25030, this, new Object[0]);
      return ((Integer)postForAll(methodObject25030, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBaseType()), this, (Map)this.proxyCache, methodObject25030))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25030, onErrorForAll(methodObject25030, e))).intValue();
    } 
  }
  
  public OracleTypeMetaData.Array _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleTypeMetaData.Array delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25037 = OracleTypeMetaData.class.getDeclaredMethod("getKind", new Class[0]);
      methodObject25035 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCode", new Class[0]);
      methodObject25032 = OracleTypeMetaData.Array.class.getDeclaredMethod("getArrayStorage", new Class[0]);
      methodObject25033 = OracleTypeMetaData.Array.class.getDeclaredMethod("getMaxLength", new Class[0]);
      methodObject25038 = OracleTypeMetaData.class.getDeclaredMethod("getSQLName", new Class[0]);
      methodObject25036 = OracleTypeMetaData.class.getDeclaredMethod("getSchemaName", new Class[0]);
      methodObject25039 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCodeName", new Class[0]);
      methodObject25031 = OracleTypeMetaData.Array.class.getDeclaredMethod("getBaseName", new Class[0]);
      methodObject25034 = OracleTypeMetaData.class.getDeclaredMethod("getName", new Class[0]);
      methodObject25030 = OracleTypeMetaData.Array.class.getDeclaredMethod("getBaseType", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Array$$$Proxy(OracleTypeMetaData.Array paramArray, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Array$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */