package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.LargeObjectAccessMode;
import oracle.jdbc.OracleBfile;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.internal.OracleBfile;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleDatumWithConnection;
import oracle.jdbc.replay.driver.NonTxnReplayableBfile;
import oracle.sql.BFILE;
import oracle.sql.BfileDBAccess;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1internal$1OracleBfile$$$Proxy extends NonTxnReplayableBfile implements OracleBfile, _Proxy_ {
  private OracleBfile delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject9575;
  
  private static Method methodObject9577;
  
  private static Method methodObject9569;
  
  private static Method methodObject9535;
  
  private static Method methodObject9557;
  
  private static Method methodObject9540;
  
  private static Method methodObject9565;
  
  private static Method methodObject9559;
  
  private static Method methodObject9553;
  
  private static Method methodObject9564;
  
  private static Method methodObject9568;
  
  private static Method methodObject9558;
  
  private static Method methodObject9544;
  
  private static Method methodObject9573;
  
  private static Method methodObject9550;
  
  private static Method methodObject9552;
  
  private static Method methodObject9574;
  
  private static Method methodObject9530;
  
  private static Method methodObject9549;
  
  private static Method methodObject9542;
  
  private static Method methodObject9576;
  
  private static Method methodObject9538;
  
  private static Method methodObject9537;
  
  private static Method methodObject9545;
  
  private static Method methodObject9528;
  
  private static Method methodObject9570;
  
  private static Method methodObject9567;
  
  private static Method methodObject9566;
  
  private static Method methodObject9561;
  
  private static Method methodObject9572;
  
  private static Method methodObject9548;
  
  private static Method methodObject9539;
  
  private static Method methodObject9531;
  
  private static Method methodObject9527;
  
  private static Method methodObject9560;
  
  private static Method methodObject9533;
  
  private static Method methodObject9562;
  
  private static Method methodObject9571;
  
  private static Method methodObject9532;
  
  private static Method methodObject9555;
  
  private static Method methodObject9554;
  
  private static Method methodObject9534;
  
  private static Method methodObject9578;
  
  private static Method methodObject9541;
  
  private static Method methodObject9536;
  
  private static Method methodObject9543;
  
  private static Method methodObject9529;
  
  private static Method methodObject9551;
  
  private static Method methodObject9546;
  
  private static Method methodObject9556;
  
  private static Method methodObject9563;
  
  private static Method methodObject9547;
  
  public void openFile() throws SQLException {
    try {
      preForAll(methodObject9575, this, new Object[0]);
      this.delegate.openFile();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject9575, e);
      return;
    } 
  }
  
  public boolean fileExists() throws SQLException {
    try {
      preForAll(methodObject9577, this, new Object[0]);
      return ((Boolean)postForAll(methodObject9577, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.fileExists()), this, (Map)this.proxyCache, methodObject9577))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject9577, onErrorForAll(methodObject9577, e))).booleanValue();
    } 
  }
  
  public void close() throws SQLException {
    try {
      preForAll(methodObject9569, this, new Object[0]);
      this.delegate.close();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject9569, e);
      return;
    } 
  }
  
  public Connection getJavaSqlConnection() throws SQLException {
    try {
      preForAll(methodObject9535, this, new Object[0]);
      return (Connection)postForAll(methodObject9535, this.proxyFactory.proxyFor(this.delegate.getJavaSqlConnection(), this, (Map)this.proxyCache, methodObject9535));
    } catch (SQLException e) {
      return (Connection)postForAll(methodObject9535, onErrorForAll(methodObject9535, e));
    } 
  }
  
  public Time timeValue(Calendar arg0) throws SQLException {
    return this.delegate.timeValue(arg0);
  }
  
  public boolean booleanValue() throws SQLException {
    return this.delegate.booleanValue();
  }
  
  public int getBytes(long arg0, int arg1, byte[] arg2) throws SQLException {
    try {
      preForAll(methodObject9565, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return ((Integer)postForAll(methodObject9565, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBytes(arg0, arg1, arg2)), this, (Map)this.proxyCache, methodObject9565))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject9565, onErrorForAll(methodObject9565, e))).intValue();
    } 
  }
  
  public Timestamp timestampValue(Calendar arg0) throws SQLException {
    return this.delegate.timestampValue(arg0);
  }
  
  public String stringValue(Connection arg0) throws SQLException {
    return this.delegate.stringValue((arg0 instanceof _Proxy_) ? ((_Proxy_<Connection>)arg0)._getDelegate_() : arg0);
  }
  
  public byte[] getBytes(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject9564, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (byte[])postForAll(methodObject9564, this.proxyFactory.proxyFor(this.delegate.getBytes(arg0, arg1), this, (Map)this.proxyCache, methodObject9564));
    } catch (SQLException e) {
      return (byte[])postForAll(methodObject9564, onErrorForAll(methodObject9564, e));
    } 
  }
  
  public long position(OracleBfile arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject9568, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject9568, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position((arg0 instanceof _Proxy_) ? ((_Proxy_<OracleBfile>)arg0)._getDelegate_() : arg0, arg1)), this, (Map)this.proxyCache, methodObject9568))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject9568, onErrorForAll(methodObject9568, e))).longValue();
    } 
  }
  
  public Timestamp timestampValue() throws SQLException {
    return this.delegate.timestampValue();
  }
  
  public int intValue() throws SQLException {
    return this.delegate.intValue();
  }
  
  public InputStream getBinaryStream(long arg0) throws SQLException {
    try {
      preForAll(methodObject9573, this, new Object[] { Long.valueOf(arg0) });
      return (InputStream)postForAll(methodObject9573, this.proxyFactory.proxyFor(this.delegate.getBinaryStream(arg0), this, (Map)this.proxyCache, methodObject9573));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject9573, onErrorForAll(methodObject9573, e));
    } 
  }
  
  public void setShareBytes(byte[] arg0) {
    this.delegate.setShareBytes(arg0);
  }
  
  public String stringValue() throws SQLException {
    return this.delegate.stringValue();
  }
  
  public String getDirAlias() throws SQLException {
    try {
      preForAll(methodObject9574, this, new Object[0]);
      return (String)postForAll(methodObject9574, this.proxyFactory.proxyFor(this.delegate.getDirAlias(), this, (Map)this.proxyCache, methodObject9574));
    } catch (SQLException e) {
      return (String)postForAll(methodObject9574, onErrorForAll(methodObject9574, e));
    } 
  }
  
  public InputStream asciiStreamValue() throws SQLException {
    try {
      preForAll(methodObject9530, this, new Object[0]);
      return (InputStream)postForAll(methodObject9530, this.proxyFactory.proxyFor(this.delegate.asciiStreamValue(), this, (Map)this.proxyCache, methodObject9530));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject9530, onErrorForAll(methodObject9530, e));
    } 
  }
  
  public byte[] shareBytes() {
    return this.delegate.shareBytes();
  }
  
  public double doubleValue() throws SQLException {
    return this.delegate.doubleValue();
  }
  
  public boolean isFileOpen() throws SQLException {
    try {
      preForAll(methodObject9576, this, new Object[0]);
      return ((Boolean)postForAll(methodObject9576, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isFileOpen()), this, (Map)this.proxyCache, methodObject9576))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject9576, onErrorForAll(methodObject9576, e))).booleanValue();
    } 
  }
  
  public BfileDBAccess getDBAccess() throws SQLException {
    try {
      preForAll(methodObject9538, this, new Object[0]);
      return (BfileDBAccess)postForAll(methodObject9538, this.proxyFactory.proxyFor(this.delegate.getDBAccess(), this, (Map)this.proxyCache, methodObject9538));
    } catch (SQLException e) {
      return (BfileDBAccess)postForAll(methodObject9538, onErrorForAll(methodObject9538, e));
    } 
  }
  
  public byte[] getLocator() {
    preForAll(methodObject9537, this, new Object[0]);
    return (byte[])postForAll(methodObject9537, this.proxyFactory.proxyFor(this.delegate.getLocator(), this, (Map)this.proxyCache, methodObject9537));
  }
  
  public long longValue() throws SQLException {
    return this.delegate.longValue();
  }
  
  public void setLength(long arg0) {
    preForAll(methodObject9528, this, new Object[] { Long.valueOf(arg0) });
    this.delegate.setLength(arg0);
  }
  
  public void open(LargeObjectAccessMode arg0) throws SQLException {
    try {
      preForAll(methodObject9570, this, new Object[] { arg0 });
      this.delegate.open(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject9570, e);
      return;
    } 
  }
  
  public long position(byte[] arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject9567, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject9567, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position(arg0, arg1)), this, (Map)this.proxyCache, methodObject9567))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject9567, onErrorForAll(methodObject9567, e))).longValue();
    } 
  }
  
  public long length() throws SQLException {
    try {
      preForAll(methodObject9566, this, new Object[0]);
      return ((Long)postForAll(methodObject9566, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.length()), this, (Map)this.proxyCache, methodObject9566))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject9566, onErrorForAll(methodObject9566, e))).longValue();
    } 
  }
  
  public OracleConnection getInternalConnection() throws SQLException {
    return this.delegate.getInternalConnection();
  }
  
  public InputStream getBinaryStream() throws SQLException {
    try {
      preForAll(methodObject9572, this, new Object[0]);
      return (InputStream)postForAll(methodObject9572, this.proxyFactory.proxyFor(this.delegate.getBinaryStream(), this, (Map)this.proxyCache, methodObject9572));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject9572, onErrorForAll(methodObject9572, e));
    } 
  }
  
  public void setBytes(byte[] arg0) {
    this.delegate.setBytes(arg0);
  }
  
  public byte[] getBytes() {
    return this.delegate.getBytes();
  }
  
  public InputStream binaryStreamValue() throws SQLException {
    try {
      preForAll(methodObject9531, this, new Object[0]);
      return (InputStream)postForAll(methodObject9531, this.proxyFactory.proxyFor(this.delegate.binaryStreamValue(), this, (Map)this.proxyCache, methodObject9531));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject9531, onErrorForAll(methodObject9531, e));
    } 
  }
  
  public long position(BFILE arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject9527, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject9527, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position(arg0, arg1)), this, (Map)this.proxyCache, methodObject9527))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject9527, onErrorForAll(methodObject9527, e))).longValue();
    } 
  }
  
  public OracleConnection getOracleConnection() throws SQLException {
    return this.delegate.getOracleConnection();
  }
  
  public Object toJdbc() throws SQLException {
    try {
      preForAll(methodObject9533, this, new Object[0]);
      return postForAll(methodObject9533, this.proxyFactory.proxyFor(this.delegate.toJdbc(), this, (Map)this.proxyCache, methodObject9533));
    } catch (SQLException e) {
      return postForAll(methodObject9533, onErrorForAll(methodObject9533, e));
    } 
  }
  
  public void setPhysicalConnectionOf(Connection arg0) {
    this.delegate.setPhysicalConnectionOf((arg0 instanceof _Proxy_) ? ((_Proxy_<Connection>)arg0)._getDelegate_() : arg0);
  }
  
  public boolean isOpen() throws SQLException {
    try {
      preForAll(methodObject9571, this, new Object[0]);
      return ((Boolean)postForAll(methodObject9571, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isOpen()), this, (Map)this.proxyCache, methodObject9571))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject9571, onErrorForAll(methodObject9571, e))).booleanValue();
    } 
  }
  
  public boolean isConvertibleTo(Class arg0) {
    preForAll(methodObject9532, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject9532, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isConvertibleTo(arg0)), this, (Map)this.proxyCache, methodObject9532))).booleanValue();
  }
  
  public Date dateValue() throws SQLException {
    return this.delegate.dateValue();
  }
  
  public BigDecimal bigDecimalValue() throws SQLException {
    return this.delegate.bigDecimalValue();
  }
  
  public Object makeJdbcArray(int arg0) {
    preForAll(methodObject9534, this, new Object[] { Integer.valueOf(arg0) });
    return postForAll(methodObject9534, this.proxyFactory.proxyFor(this.delegate.makeJdbcArray(arg0), this, (Map)this.proxyCache, methodObject9534));
  }
  
  public void closeFile() throws SQLException {
    try {
      preForAll(methodObject9578, this, new Object[0]);
      this.delegate.closeFile();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject9578, e);
      return;
    } 
  }
  
  public byte byteValue() throws SQLException {
    return this.delegate.byteValue();
  }
  
  public void setLocator(byte[] arg0) {
    preForAll(methodObject9536, this, new Object[] { arg0 });
    this.delegate.setLocator(arg0);
  }
  
  public float floatValue() throws SQLException {
    return this.delegate.floatValue();
  }
  
  public Reader characterStreamValue() throws SQLException {
    try {
      preForAll(methodObject9529, this, new Object[0]);
      return (Reader)postForAll(methodObject9529, this.proxyFactory.proxyFor(this.delegate.characterStreamValue(), this, (Map)this.proxyCache, methodObject9529));
    } catch (SQLException e) {
      return (Reader)postForAll(methodObject9529, onErrorForAll(methodObject9529, e));
    } 
  }
  
  public InputStream getStream() throws SQLException {
    return this.delegate.getStream();
  }
  
  public long getLength() {
    return this.delegate.getLength();
  }
  
  public Time timeValue() throws SQLException {
    return this.delegate.timeValue();
  }
  
  public String getName() throws SQLException {
    try {
      preForAll(methodObject9563, this, new Object[0]);
      return (String)postForAll(methodObject9563, this.proxyFactory.proxyFor(this.delegate.getName(), this, (Map)this.proxyCache, methodObject9563));
    } catch (SQLException e) {
      return (String)postForAll(methodObject9563, onErrorForAll(methodObject9563, e));
    } 
  }
  
  public OracleConnection getConnection() throws SQLException {
    return this.delegate.getConnection();
  }
  
  public OracleBfile _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleBfile delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject9575 = OracleBfile.class.getDeclaredMethod("openFile", new Class[0]);
      methodObject9577 = OracleBfile.class.getDeclaredMethod("fileExists", new Class[0]);
      methodObject9569 = OracleBfile.class.getDeclaredMethod("close", new Class[0]);
      methodObject9535 = OracleBfile.class.getDeclaredMethod("getJavaSqlConnection", new Class[0]);
      methodObject9557 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[] { Calendar.class });
      methodObject9540 = OracleDatumWithConnection.class.getDeclaredMethod("booleanValue", new Class[0]);
      methodObject9565 = OracleBfile.class.getDeclaredMethod("getBytes", new Class[] { long.class, int.class, byte[].class });
      methodObject9559 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[] { Calendar.class });
      methodObject9553 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[] { Connection.class });
      methodObject9564 = OracleBfile.class.getDeclaredMethod("getBytes", new Class[] { long.class, int.class });
      methodObject9568 = OracleBfile.class.getDeclaredMethod("position", new Class[] { OracleBfile.class, long.class });
      methodObject9558 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[0]);
      methodObject9544 = OracleDatumWithConnection.class.getDeclaredMethod("intValue", new Class[0]);
      methodObject9573 = OracleBfile.class.getDeclaredMethod("getBinaryStream", new Class[] { long.class });
      methodObject9550 = OracleDatumWithConnection.class.getDeclaredMethod("setShareBytes", new Class[] { byte[].class });
      methodObject9552 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[0]);
      methodObject9574 = OracleBfile.class.getDeclaredMethod("getDirAlias", new Class[0]);
      methodObject9530 = OracleBfile.class.getDeclaredMethod("asciiStreamValue", new Class[0]);
      methodObject9549 = OracleDatumWithConnection.class.getDeclaredMethod("shareBytes", new Class[0]);
      methodObject9542 = OracleDatumWithConnection.class.getDeclaredMethod("doubleValue", new Class[0]);
      methodObject9576 = OracleBfile.class.getDeclaredMethod("isFileOpen", new Class[0]);
      methodObject9538 = OracleBfile.class.getDeclaredMethod("getDBAccess", new Class[0]);
      methodObject9537 = OracleBfile.class.getDeclaredMethod("getLocator", new Class[0]);
      methodObject9545 = OracleDatumWithConnection.class.getDeclaredMethod("longValue", new Class[0]);
      methodObject9528 = OracleBfile.class.getDeclaredMethod("setLength", new Class[] { long.class });
      methodObject9570 = OracleBfile.class.getDeclaredMethod("open", new Class[] { LargeObjectAccessMode.class });
      methodObject9567 = OracleBfile.class.getDeclaredMethod("position", new Class[] { byte[].class, long.class });
      methodObject9566 = OracleBfile.class.getDeclaredMethod("length", new Class[0]);
      methodObject9561 = OracleDatumWithConnection.class.getDeclaredMethod("getInternalConnection", new Class[0]);
      methodObject9572 = OracleBfile.class.getDeclaredMethod("getBinaryStream", new Class[0]);
      methodObject9548 = OracleDatumWithConnection.class.getDeclaredMethod("setBytes", new Class[] { byte[].class });
      methodObject9539 = OracleDatumWithConnection.class.getDeclaredMethod("getBytes", new Class[0]);
      methodObject9531 = OracleBfile.class.getDeclaredMethod("binaryStreamValue", new Class[0]);
      methodObject9527 = OracleBfile.class.getDeclaredMethod("position", new Class[] { BFILE.class, long.class });
      methodObject9560 = OracleDatumWithConnection.class.getDeclaredMethod("getOracleConnection", new Class[0]);
      methodObject9533 = OracleBfile.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject9562 = OracleDatumWithConnection.class.getDeclaredMethod("setPhysicalConnectionOf", new Class[] { Connection.class });
      methodObject9571 = OracleBfile.class.getDeclaredMethod("isOpen", new Class[0]);
      methodObject9532 = OracleBfile.class.getDeclaredMethod("isConvertibleTo", new Class[] { Class.class });
      methodObject9555 = OracleDatumWithConnection.class.getDeclaredMethod("dateValue", new Class[0]);
      methodObject9554 = OracleDatumWithConnection.class.getDeclaredMethod("bigDecimalValue", new Class[0]);
      methodObject9534 = OracleBfile.class.getDeclaredMethod("makeJdbcArray", new Class[] { int.class });
      methodObject9578 = OracleBfile.class.getDeclaredMethod("closeFile", new Class[0]);
      methodObject9541 = OracleDatumWithConnection.class.getDeclaredMethod("byteValue", new Class[0]);
      methodObject9536 = OracleBfile.class.getDeclaredMethod("setLocator", new Class[] { byte[].class });
      methodObject9543 = OracleDatumWithConnection.class.getDeclaredMethod("floatValue", new Class[0]);
      methodObject9529 = OracleBfile.class.getDeclaredMethod("characterStreamValue", new Class[0]);
      methodObject9551 = OracleDatumWithConnection.class.getDeclaredMethod("getStream", new Class[0]);
      methodObject9546 = OracleDatumWithConnection.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject9556 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[0]);
      methodObject9563 = OracleBfile.class.getDeclaredMethod("getName", new Class[0]);
      methodObject9547 = OracleDatumWithConnection.class.getDeclaredMethod("getConnection", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1internal$1OracleBfile$$$Proxy(OracleBfile paramOracleBfile, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleBfile;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1internal$1OracleBfile$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */