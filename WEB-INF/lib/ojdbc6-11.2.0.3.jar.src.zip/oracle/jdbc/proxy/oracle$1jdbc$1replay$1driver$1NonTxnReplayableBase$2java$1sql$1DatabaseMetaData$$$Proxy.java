package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.RowIdLifetime;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1DatabaseMetaData$$$Proxy extends NonTxnReplayableBase implements DatabaseMetaData, _Proxy_ {
  private DatabaseMetaData delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject24896;
  
  private static Method methodObject24766;
  
  private static Method methodObject24870;
  
  private static Method methodObject24840;
  
  private static Method methodObject24756;
  
  private static Method methodObject24744;
  
  private static Method methodObject24761;
  
  private static Method methodObject24792;
  
  private static Method methodObject24861;
  
  private static Method methodObject24825;
  
  private static Method methodObject24798;
  
  private static Method methodObject24763;
  
  private static Method methodObject24850;
  
  private static Method methodObject24800;
  
  private static Method methodObject24884;
  
  private static Method methodObject24749;
  
  private static Method methodObject24782;
  
  private static Method methodObject24854;
  
  private static Method methodObject24759;
  
  private static Method methodObject24815;
  
  private static Method methodObject24804;
  
  private static Method methodObject24901;
  
  private static Method methodObject24795;
  
  private static Method methodObject24811;
  
  private static Method methodObject24787;
  
  private static Method methodObject24758;
  
  private static Method methodObject24773;
  
  private static Method methodObject24747;
  
  private static Method methodObject24797;
  
  private static Method methodObject24893;
  
  private static Method methodObject24885;
  
  private static Method methodObject24873;
  
  private static Method methodObject24757;
  
  private static Method methodObject24737;
  
  private static Method methodObject24746;
  
  private static Method methodObject24752;
  
  private static Method methodObject24895;
  
  private static Method methodObject24802;
  
  private static Method methodObject24807;
  
  private static Method methodObject24879;
  
  private static Method methodObject24750;
  
  private static Method methodObject24846;
  
  private static Method methodObject24775;
  
  private static Method methodObject24890;
  
  private static Method methodObject24883;
  
  private static Method methodObject24754;
  
  private static Method methodObject24801;
  
  private static Method methodObject24741;
  
  private static Method methodObject24886;
  
  private static Method methodObject24859;
  
  private static Method methodObject24738;
  
  private static Method methodObject24817;
  
  private static Method methodObject24745;
  
  private static Method methodObject24813;
  
  private static Method methodObject24755;
  
  private static Method methodObject24789;
  
  private static Method methodObject24841;
  
  private static Method methodObject24814;
  
  private static Method methodObject24733;
  
  private static Method methodObject24805;
  
  private static Method methodObject24823;
  
  private static Method methodObject24768;
  
  private static Method methodObject24793;
  
  private static Method methodObject24831;
  
  private static Method methodObject24732;
  
  private static Method methodObject24851;
  
  private static Method methodObject24855;
  
  private static Method methodObject24764;
  
  private static Method methodObject24785;
  
  private static Method methodObject24809;
  
  private static Method methodObject24786;
  
  private static Method methodObject24898;
  
  private static Method methodObject24892;
  
  private static Method methodObject24874;
  
  private static Method methodObject24902;
  
  private static Method methodObject24835;
  
  private static Method methodObject24788;
  
  private static Method methodObject24796;
  
  private static Method methodObject24783;
  
  private static Method methodObject24808;
  
  private static Method methodObject24882;
  
  private static Method methodObject24877;
  
  private static Method methodObject24830;
  
  private static Method methodObject24863;
  
  private static Method methodObject24832;
  
  private static Method methodObject24847;
  
  private static Method methodObject24751;
  
  private static Method methodObject24781;
  
  private static Method methodObject24820;
  
  private static Method methodObject24868;
  
  private static Method methodObject24765;
  
  private static Method methodObject24731;
  
  private static Method methodObject24897;
  
  private static Method methodObject24734;
  
  private static Method methodObject24760;
  
  private static Method methodObject24864;
  
  private static Method methodObject24828;
  
  private static Method methodObject24853;
  
  private static Method methodObject24845;
  
  private static Method methodObject24834;
  
  private static Method methodObject24889;
  
  private static Method methodObject24778;
  
  private static Method methodObject24767;
  
  private static Method methodObject24869;
  
  private static Method methodObject24903;
  
  private static Method methodObject24810;
  
  private static Method methodObject24860;
  
  private static Method methodObject24848;
  
  private static Method methodObject24791;
  
  private static Method methodObject24819;
  
  private static Method methodObject24881;
  
  private static Method methodObject24769;
  
  private static Method methodObject24838;
  
  private static Method methodObject24812;
  
  private static Method methodObject24852;
  
  private static Method methodObject24880;
  
  private static Method methodObject24748;
  
  private static Method methodObject24739;
  
  private static Method methodObject24875;
  
  private static Method methodObject24818;
  
  private static Method methodObject24899;
  
  private static Method methodObject24735;
  
  private static Method methodObject24826;
  
  private static Method methodObject24878;
  
  private static Method methodObject24904;
  
  private static Method methodObject24839;
  
  private static Method methodObject24794;
  
  private static Method methodObject24753;
  
  private static Method methodObject24780;
  
  private static Method methodObject24803;
  
  private static Method methodObject24790;
  
  private static Method methodObject24829;
  
  private static Method methodObject24822;
  
  private static Method methodObject24844;
  
  private static Method methodObject24837;
  
  private static Method methodObject24867;
  
  private static Method methodObject24824;
  
  private static Method methodObject24856;
  
  private static Method methodObject24776;
  
  private static Method methodObject24799;
  
  private static Method methodObject24774;
  
  private static Method methodObject24777;
  
  private static Method methodObject24736;
  
  private static Method methodObject24806;
  
  private static Method methodObject24816;
  
  private static Method methodObject24891;
  
  private static Method methodObject24779;
  
  private static Method methodObject24894;
  
  private static Method methodObject24872;
  
  private static Method methodObject24843;
  
  private static Method methodObject24821;
  
  private static Method methodObject24857;
  
  private static Method methodObject24888;
  
  private static Method methodObject24849;
  
  private static Method methodObject24865;
  
  private static Method methodObject24772;
  
  private static Method methodObject24771;
  
  private static Method methodObject24784;
  
  private static Method methodObject24836;
  
  private static Method methodObject24858;
  
  private static Method methodObject24833;
  
  private static Method methodObject24862;
  
  private static Method methodObject24770;
  
  private static Method methodObject24827;
  
  private static Method methodObject24866;
  
  private static Method methodObject24871;
  
  private static Method methodObject24900;
  
  private static Method methodObject24740;
  
  private static Method methodObject24887;
  
  private static Method methodObject24876;
  
  private static Method methodObject24842;
  
  private static Method methodObject24762;
  
  private static Method methodObject24742;
  
  private static Method methodObject24743;
  
  public boolean supportsTransactionIsolationLevel(int arg0) throws SQLException {
    try {
      preForAll(methodObject24896, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24896, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsTransactionIsolationLevel(arg0)), this, (Map)this.proxyCache, methodObject24896))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24896, onErrorForAll(methodObject24896, e))).booleanValue();
    } 
  }
  
  public int getJDBCMajorVersion() throws SQLException {
    try {
      preForAll(methodObject24766, this, new Object[0]);
      return ((Integer)postForAll(methodObject24766, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getJDBCMajorVersion()), this, (Map)this.proxyCache, methodObject24766))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24766, onErrorForAll(methodObject24766, e))).intValue();
    } 
  }
  
  public boolean supportsOpenCursorsAcrossCommit() throws SQLException {
    try {
      preForAll(methodObject24870, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24870, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOpenCursorsAcrossCommit()), this, (Map)this.proxyCache, methodObject24870))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24870, onErrorForAll(methodObject24870, e))).booleanValue();
    } 
  }
  
  public boolean supportsCatalogsInIndexDefinitions() throws SQLException {
    try {
      preForAll(methodObject24840, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24840, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInIndexDefinitions()), this, (Map)this.proxyCache, methodObject24840))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24840, onErrorForAll(methodObject24840, e))).booleanValue();
    } 
  }
  
  public int getDriverMinorVersion() {
    preForAll(methodObject24756, this, new Object[0]);
    return ((Integer)postForAll(methodObject24756, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDriverMinorVersion()), this, (Map)this.proxyCache, methodObject24756))).intValue();
  }
  
  public String getCatalogTerm() throws SQLException {
    try {
      preForAll(methodObject24744, this, new Object[0]);
      return (String)postForAll(methodObject24744, this.proxyFactory.proxyFor(this.delegate.getCatalogTerm(), this, (Map)this.proxyCache, methodObject24744));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24744, onErrorForAll(methodObject24744, e));
    } 
  }
  
  public ResultSet getFunctionColumns(String arg0, String arg1, String arg2, String arg3) throws SQLException {
    try {
      preForAll(methodObject24761, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject24761, this.proxyFactory.proxyFor(this.delegate.getFunctionColumns(arg0, arg1, arg2, arg3), this, (Map)this.proxyCache, methodObject24761));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24761, onErrorForAll(methodObject24761, e));
    } 
  }
  
  public ResultSet getProcedures(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24792, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24792, this.proxyFactory.proxyFor(this.delegate.getProcedures(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24792));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24792, onErrorForAll(methodObject24792, e));
    } 
  }
  
  public boolean supportsLimitedOuterJoins() throws SQLException {
    try {
      preForAll(methodObject24861, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24861, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsLimitedOuterJoins()), this, (Map)this.proxyCache, methodObject24861))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24861, onErrorForAll(methodObject24861, e))).booleanValue();
    } 
  }
  
  public boolean ownInsertsAreVisible(int arg0) throws SQLException {
    try {
      preForAll(methodObject24825, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24825, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.ownInsertsAreVisible(arg0)), this, (Map)this.proxyCache, methodObject24825))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24825, onErrorForAll(methodObject24825, e))).booleanValue();
    } 
  }
  
  public ResultSet getSchemas() throws SQLException {
    try {
      preForAll(methodObject24798, this, new Object[0]);
      return (ResultSet)postForAll(methodObject24798, this.proxyFactory.proxyFor(this.delegate.getSchemas(), this, (Map)this.proxyCache, methodObject24798));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24798, onErrorForAll(methodObject24798, e));
    } 
  }
  
  public String getIdentifierQuoteString() throws SQLException {
    try {
      preForAll(methodObject24763, this, new Object[0]);
      return (String)postForAll(methodObject24763, this.proxyFactory.proxyFor(this.delegate.getIdentifierQuoteString(), this, (Map)this.proxyCache, methodObject24763));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24763, onErrorForAll(methodObject24763, e));
    } 
  }
  
  public boolean supportsDataManipulationTransactionsOnly() throws SQLException {
    try {
      preForAll(methodObject24850, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24850, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsDataManipulationTransactionsOnly()), this, (Map)this.proxyCache, methodObject24850))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24850, onErrorForAll(methodObject24850, e))).booleanValue();
    } 
  }
  
  public String getSearchStringEscape() throws SQLException {
    try {
      preForAll(methodObject24800, this, new Object[0]);
      return (String)postForAll(methodObject24800, this.proxyFactory.proxyFor(this.delegate.getSearchStringEscape(), this, (Map)this.proxyCache, methodObject24800));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24800, onErrorForAll(methodObject24800, e));
    } 
  }
  
  public boolean supportsSchemasInPrivilegeDefinitions() throws SQLException {
    try {
      preForAll(methodObject24884, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24884, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInPrivilegeDefinitions()), this, (Map)this.proxyCache, methodObject24884))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24884, onErrorForAll(methodObject24884, e))).booleanValue();
    } 
  }
  
  public ResultSet getCrossReference(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5) throws SQLException {
    try {
      preForAll(methodObject24749, this, new Object[] { arg0, arg1, arg2, arg3, arg4, arg5 });
      return (ResultSet)postForAll(methodObject24749, this.proxyFactory.proxyFor(this.delegate.getCrossReference(arg0, arg1, arg2, arg3, arg4, arg5), this, (Map)this.proxyCache, methodObject24749));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24749, onErrorForAll(methodObject24749, e));
    } 
  }
  
  public int getMaxSchemaNameLength() throws SQLException {
    try {
      preForAll(methodObject24782, this, new Object[0]);
      return ((Integer)postForAll(methodObject24782, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxSchemaNameLength()), this, (Map)this.proxyCache, methodObject24782))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24782, onErrorForAll(methodObject24782, e))).intValue();
    } 
  }
  
  public boolean supportsFullOuterJoins() throws SQLException {
    try {
      preForAll(methodObject24854, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24854, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsFullOuterJoins()), this, (Map)this.proxyCache, methodObject24854))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24854, onErrorForAll(methodObject24854, e))).booleanValue();
    } 
  }
  
  public ResultSet getExportedKeys(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24759, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24759, this.proxyFactory.proxyFor(this.delegate.getExportedKeys(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24759));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24759, onErrorForAll(methodObject24759, e));
    } 
  }
  
  public boolean locatorsUpdateCopy() throws SQLException {
    try {
      preForAll(methodObject24815, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24815, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.locatorsUpdateCopy()), this, (Map)this.proxyCache, methodObject24815))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24815, onErrorForAll(methodObject24815, e))).booleanValue();
    } 
  }
  
  public String getSystemFunctions() throws SQLException {
    try {
      preForAll(methodObject24804, this, new Object[0]);
      return (String)postForAll(methodObject24804, this.proxyFactory.proxyFor(this.delegate.getSystemFunctions(), this, (Map)this.proxyCache, methodObject24804));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24804, onErrorForAll(methodObject24804, e));
    } 
  }
  
  public boolean usesLocalFilePerTable() throws SQLException {
    try {
      preForAll(methodObject24901, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24901, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.usesLocalFilePerTable()), this, (Map)this.proxyCache, methodObject24901))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24901, onErrorForAll(methodObject24901, e))).booleanValue();
    } 
  }
  
  public String getSQLKeywords() throws SQLException {
    try {
      preForAll(methodObject24795, this, new Object[0]);
      return (String)postForAll(methodObject24795, this.proxyFactory.proxyFor(this.delegate.getSQLKeywords(), this, (Map)this.proxyCache, methodObject24795));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24795, onErrorForAll(methodObject24795, e));
    } 
  }
  
  public String getUserName() throws SQLException {
    try {
      preForAll(methodObject24811, this, new Object[0]);
      return (String)postForAll(methodObject24811, this.proxyFactory.proxyFor(this.delegate.getUserName(), this, (Map)this.proxyCache, methodObject24811));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24811, onErrorForAll(methodObject24811, e));
    } 
  }
  
  public int getMaxUserNameLength() throws SQLException {
    try {
      preForAll(methodObject24787, this, new Object[0]);
      return ((Integer)postForAll(methodObject24787, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxUserNameLength()), this, (Map)this.proxyCache, methodObject24787))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24787, onErrorForAll(methodObject24787, e))).intValue();
    } 
  }
  
  public String getDriverVersion() throws SQLException {
    try {
      preForAll(methodObject24758, this, new Object[0]);
      return (String)postForAll(methodObject24758, this.proxyFactory.proxyFor(this.delegate.getDriverVersion(), this, (Map)this.proxyCache, methodObject24758));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24758, onErrorForAll(methodObject24758, e));
    } 
  }
  
  public int getMaxColumnsInIndex() throws SQLException {
    try {
      preForAll(methodObject24773, this, new Object[0]);
      return ((Integer)postForAll(methodObject24773, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInIndex()), this, (Map)this.proxyCache, methodObject24773))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24773, onErrorForAll(methodObject24773, e))).intValue();
    } 
  }
  
  public ResultSet getColumnPrivileges(String arg0, String arg1, String arg2, String arg3) throws SQLException {
    try {
      preForAll(methodObject24747, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject24747, this.proxyFactory.proxyFor(this.delegate.getColumnPrivileges(arg0, arg1, arg2, arg3), this, (Map)this.proxyCache, methodObject24747));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24747, onErrorForAll(methodObject24747, e));
    } 
  }
  
  public String getSchemaTerm() throws SQLException {
    try {
      preForAll(methodObject24797, this, new Object[0]);
      return (String)postForAll(methodObject24797, this.proxyFactory.proxyFor(this.delegate.getSchemaTerm(), this, (Map)this.proxyCache, methodObject24797));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24797, onErrorForAll(methodObject24797, e));
    } 
  }
  
  public boolean supportsSubqueriesInIns() throws SQLException {
    try {
      preForAll(methodObject24893, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24893, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSubqueriesInIns()), this, (Map)this.proxyCache, methodObject24893))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24893, onErrorForAll(methodObject24893, e))).booleanValue();
    } 
  }
  
  public boolean supportsSchemasInProcedureCalls() throws SQLException {
    try {
      preForAll(methodObject24885, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24885, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInProcedureCalls()), this, (Map)this.proxyCache, methodObject24885))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24885, onErrorForAll(methodObject24885, e))).booleanValue();
    } 
  }
  
  public boolean supportsOpenStatementsAcrossRollback() throws SQLException {
    try {
      preForAll(methodObject24873, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24873, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOpenStatementsAcrossRollback()), this, (Map)this.proxyCache, methodObject24873))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24873, onErrorForAll(methodObject24873, e))).booleanValue();
    } 
  }
  
  public String getDriverName() throws SQLException {
    try {
      preForAll(methodObject24757, this, new Object[0]);
      return (String)postForAll(methodObject24757, this.proxyFactory.proxyFor(this.delegate.getDriverName(), this, (Map)this.proxyCache, methodObject24757));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24757, onErrorForAll(methodObject24757, e));
    } 
  }
  
  public boolean autoCommitFailureClosesAllResultSets() throws SQLException {
    try {
      preForAll(methodObject24737, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24737, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.autoCommitFailureClosesAllResultSets()), this, (Map)this.proxyCache, methodObject24737))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24737, onErrorForAll(methodObject24737, e))).booleanValue();
    } 
  }
  
  public ResultSet getClientInfoProperties() throws SQLException {
    try {
      preForAll(methodObject24746, this, new Object[0]);
      return (ResultSet)postForAll(methodObject24746, this.proxyFactory.proxyFor(this.delegate.getClientInfoProperties(), this, (Map)this.proxyCache, methodObject24746));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24746, onErrorForAll(methodObject24746, e));
    } 
  }
  
  public String getDatabaseProductName() throws SQLException {
    try {
      preForAll(methodObject24752, this, new Object[0]);
      return (String)postForAll(methodObject24752, this.proxyFactory.proxyFor(this.delegate.getDatabaseProductName(), this, (Map)this.proxyCache, methodObject24752));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24752, onErrorForAll(methodObject24752, e));
    } 
  }
  
  public boolean supportsTableCorrelationNames() throws SQLException {
    try {
      preForAll(methodObject24895, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24895, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsTableCorrelationNames()), this, (Map)this.proxyCache, methodObject24895))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24895, onErrorForAll(methodObject24895, e))).booleanValue();
    } 
  }
  
  public ResultSet getSuperTables(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24802, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24802, this.proxyFactory.proxyFor(this.delegate.getSuperTables(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24802));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24802, onErrorForAll(methodObject24802, e));
    } 
  }
  
  public ResultSet getTables(String arg0, String arg1, String arg2, String[] arg3) throws SQLException {
    try {
      preForAll(methodObject24807, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject24807, this.proxyFactory.proxyFor(this.delegate.getTables(arg0, arg1, arg2, arg3), this, (Map)this.proxyCache, methodObject24807));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24807, onErrorForAll(methodObject24807, e));
    } 
  }
  
  public boolean supportsResultSetHoldability(int arg0) throws SQLException {
    try {
      preForAll(methodObject24879, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24879, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsResultSetHoldability(arg0)), this, (Map)this.proxyCache, methodObject24879))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24879, onErrorForAll(methodObject24879, e))).booleanValue();
    } 
  }
  
  public int getDatabaseMajorVersion() throws SQLException {
    try {
      preForAll(methodObject24750, this, new Object[0]);
      return ((Integer)postForAll(methodObject24750, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDatabaseMajorVersion()), this, (Map)this.proxyCache, methodObject24750))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24750, onErrorForAll(methodObject24750, e))).intValue();
    } 
  }
  
  public boolean supportsConvert(int arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject24846, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
      return ((Boolean)postForAll(methodObject24846, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsConvert(arg0, arg1)), this, (Map)this.proxyCache, methodObject24846))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24846, onErrorForAll(methodObject24846, e))).booleanValue();
    } 
  }
  
  public int getMaxColumnsInSelect() throws SQLException {
    try {
      preForAll(methodObject24775, this, new Object[0]);
      return ((Integer)postForAll(methodObject24775, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInSelect()), this, (Map)this.proxyCache, methodObject24775))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24775, onErrorForAll(methodObject24775, e))).intValue();
    } 
  }
  
  public boolean supportsStoredProcedures() throws SQLException {
    try {
      preForAll(methodObject24890, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24890, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsStoredProcedures()), this, (Map)this.proxyCache, methodObject24890))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24890, onErrorForAll(methodObject24890, e))).booleanValue();
    } 
  }
  
  public boolean supportsSchemasInIndexDefinitions() throws SQLException {
    try {
      preForAll(methodObject24883, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24883, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInIndexDefinitions()), this, (Map)this.proxyCache, methodObject24883))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24883, onErrorForAll(methodObject24883, e))).booleanValue();
    } 
  }
  
  public int getDefaultTransactionIsolation() throws SQLException {
    try {
      preForAll(methodObject24754, this, new Object[0]);
      return ((Integer)postForAll(methodObject24754, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDefaultTransactionIsolation()), this, (Map)this.proxyCache, methodObject24754))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24754, onErrorForAll(methodObject24754, e))).intValue();
    } 
  }
  
  public String getStringFunctions() throws SQLException {
    try {
      preForAll(methodObject24801, this, new Object[0]);
      return (String)postForAll(methodObject24801, this.proxyFactory.proxyFor(this.delegate.getStringFunctions(), this, (Map)this.proxyCache, methodObject24801));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24801, onErrorForAll(methodObject24801, e));
    } 
  }
  
  public boolean doesMaxRowSizeIncludeBlobs() throws SQLException {
    try {
      preForAll(methodObject24741, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24741, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.doesMaxRowSizeIncludeBlobs()), this, (Map)this.proxyCache, methodObject24741))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24741, onErrorForAll(methodObject24741, e))).booleanValue();
    } 
  }
  
  public boolean supportsSchemasInTableDefinitions() throws SQLException {
    try {
      preForAll(methodObject24886, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24886, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInTableDefinitions()), this, (Map)this.proxyCache, methodObject24886))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24886, onErrorForAll(methodObject24886, e))).booleanValue();
    } 
  }
  
  public boolean supportsIntegrityEnhancementFacility() throws SQLException {
    try {
      preForAll(methodObject24859, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24859, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsIntegrityEnhancementFacility()), this, (Map)this.proxyCache, methodObject24859))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24859, onErrorForAll(methodObject24859, e))).booleanValue();
    } 
  }
  
  public boolean dataDefinitionCausesTransactionCommit() throws SQLException {
    try {
      preForAll(methodObject24738, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24738, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.dataDefinitionCausesTransactionCommit()), this, (Map)this.proxyCache, methodObject24738))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24738, onErrorForAll(methodObject24738, e))).booleanValue();
    } 
  }
  
  public boolean nullsAreSortedAtEnd() throws SQLException {
    try {
      preForAll(methodObject24817, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24817, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullsAreSortedAtEnd()), this, (Map)this.proxyCache, methodObject24817))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24817, onErrorForAll(methodObject24817, e))).booleanValue();
    } 
  }
  
  public ResultSet getCatalogs() throws SQLException {
    try {
      preForAll(methodObject24745, this, new Object[0]);
      return (ResultSet)postForAll(methodObject24745, this.proxyFactory.proxyFor(this.delegate.getCatalogs(), this, (Map)this.proxyCache, methodObject24745));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24745, onErrorForAll(methodObject24745, e));
    } 
  }
  
  public boolean insertsAreDetected(int arg0) throws SQLException {
    try {
      preForAll(methodObject24813, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24813, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.insertsAreDetected(arg0)), this, (Map)this.proxyCache, methodObject24813))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24813, onErrorForAll(methodObject24813, e))).booleanValue();
    } 
  }
  
  public int getDriverMajorVersion() {
    preForAll(methodObject24755, this, new Object[0]);
    return ((Integer)postForAll(methodObject24755, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDriverMajorVersion()), this, (Map)this.proxyCache, methodObject24755))).intValue();
  }
  
  public ResultSet getPrimaryKeys(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24789, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24789, this.proxyFactory.proxyFor(this.delegate.getPrimaryKeys(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24789));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24789, onErrorForAll(methodObject24789, e));
    } 
  }
  
  public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLException {
    try {
      preForAll(methodObject24841, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24841, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInPrivilegeDefinitions()), this, (Map)this.proxyCache, methodObject24841))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24841, onErrorForAll(methodObject24841, e))).booleanValue();
    } 
  }
  
  public boolean isCatalogAtStart() throws SQLException {
    try {
      preForAll(methodObject24814, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24814, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCatalogAtStart()), this, (Map)this.proxyCache, methodObject24814))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24814, onErrorForAll(methodObject24814, e))).booleanValue();
    } 
  }
  
  public ResultSet getAttributes(String arg0, String arg1, String arg2, String arg3) throws SQLException {
    try {
      preForAll(methodObject24733, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject24733, this.proxyFactory.proxyFor(this.delegate.getAttributes(arg0, arg1, arg2, arg3), this, (Map)this.proxyCache, methodObject24733));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24733, onErrorForAll(methodObject24733, e));
    } 
  }
  
  public ResultSet getTablePrivileges(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24805, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24805, this.proxyFactory.proxyFor(this.delegate.getTablePrivileges(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24805));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24805, onErrorForAll(methodObject24805, e));
    } 
  }
  
  public boolean othersUpdatesAreVisible(int arg0) throws SQLException {
    try {
      preForAll(methodObject24823, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24823, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.othersUpdatesAreVisible(arg0)), this, (Map)this.proxyCache, methodObject24823))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24823, onErrorForAll(methodObject24823, e))).booleanValue();
    } 
  }
  
  public int getMaxBinaryLiteralLength() throws SQLException {
    try {
      preForAll(methodObject24768, this, new Object[0]);
      return ((Integer)postForAll(methodObject24768, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxBinaryLiteralLength()), this, (Map)this.proxyCache, methodObject24768))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24768, onErrorForAll(methodObject24768, e))).intValue();
    } 
  }
  
  public int getResultSetHoldability() throws SQLException {
    try {
      preForAll(methodObject24793, this, new Object[0]);
      return ((Integer)postForAll(methodObject24793, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getResultSetHoldability()), this, (Map)this.proxyCache, methodObject24793))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24793, onErrorForAll(methodObject24793, e))).intValue();
    } 
  }
  
  public boolean storesUpperCaseIdentifiers() throws SQLException {
    try {
      preForAll(methodObject24831, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24831, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesUpperCaseIdentifiers()), this, (Map)this.proxyCache, methodObject24831))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24831, onErrorForAll(methodObject24831, e))).booleanValue();
    } 
  }
  
  public boolean isReadOnly() throws SQLException {
    try {
      preForAll(methodObject24732, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24732, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isReadOnly()), this, (Map)this.proxyCache, methodObject24732))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24732, onErrorForAll(methodObject24732, e))).booleanValue();
    } 
  }
  
  public boolean supportsDifferentTableCorrelationNames() throws SQLException {
    try {
      preForAll(methodObject24851, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24851, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsDifferentTableCorrelationNames()), this, (Map)this.proxyCache, methodObject24851))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24851, onErrorForAll(methodObject24851, e))).booleanValue();
    } 
  }
  
  public boolean supportsGetGeneratedKeys() throws SQLException {
    try {
      preForAll(methodObject24855, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24855, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsGetGeneratedKeys()), this, (Map)this.proxyCache, methodObject24855))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24855, onErrorForAll(methodObject24855, e))).booleanValue();
    } 
  }
  
  public ResultSet getImportedKeys(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24764, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24764, this.proxyFactory.proxyFor(this.delegate.getImportedKeys(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24764));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24764, onErrorForAll(methodObject24764, e));
    } 
  }
  
  public int getMaxTableNameLength() throws SQLException {
    try {
      preForAll(methodObject24785, this, new Object[0]);
      return ((Integer)postForAll(methodObject24785, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxTableNameLength()), this, (Map)this.proxyCache, methodObject24785))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24785, onErrorForAll(methodObject24785, e))).intValue();
    } 
  }
  
  public ResultSet getTypeInfo() throws SQLException {
    try {
      preForAll(methodObject24809, this, new Object[0]);
      return (ResultSet)postForAll(methodObject24809, this.proxyFactory.proxyFor(this.delegate.getTypeInfo(), this, (Map)this.proxyCache, methodObject24809));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24809, onErrorForAll(methodObject24809, e));
    } 
  }
  
  public int getMaxTablesInSelect() throws SQLException {
    try {
      preForAll(methodObject24786, this, new Object[0]);
      return ((Integer)postForAll(methodObject24786, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxTablesInSelect()), this, (Map)this.proxyCache, methodObject24786))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24786, onErrorForAll(methodObject24786, e))).intValue();
    } 
  }
  
  public boolean supportsUnion() throws SQLException {
    try {
      preForAll(methodObject24898, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24898, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsUnion()), this, (Map)this.proxyCache, methodObject24898))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24898, onErrorForAll(methodObject24898, e))).booleanValue();
    } 
  }
  
  public boolean supportsSubqueriesInExists() throws SQLException {
    try {
      preForAll(methodObject24892, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24892, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSubqueriesInExists()), this, (Map)this.proxyCache, methodObject24892))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24892, onErrorForAll(methodObject24892, e))).booleanValue();
    } 
  }
  
  public boolean supportsOrderByUnrelated() throws SQLException {
    try {
      preForAll(methodObject24874, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24874, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOrderByUnrelated()), this, (Map)this.proxyCache, methodObject24874))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24874, onErrorForAll(methodObject24874, e))).booleanValue();
    } 
  }
  
  public boolean usesLocalFiles() throws SQLException {
    try {
      preForAll(methodObject24902, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24902, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.usesLocalFiles()), this, (Map)this.proxyCache, methodObject24902))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24902, onErrorForAll(methodObject24902, e))).booleanValue();
    } 
  }
  
  public boolean supportsANSI92IntermediateSQL() throws SQLException {
    try {
      preForAll(methodObject24835, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24835, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsANSI92IntermediateSQL()), this, (Map)this.proxyCache, methodObject24835))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24835, onErrorForAll(methodObject24835, e))).booleanValue();
    } 
  }
  
  public String getNumericFunctions() throws SQLException {
    try {
      preForAll(methodObject24788, this, new Object[0]);
      return (String)postForAll(methodObject24788, this.proxyFactory.proxyFor(this.delegate.getNumericFunctions(), this, (Map)this.proxyCache, methodObject24788));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24788, onErrorForAll(methodObject24788, e));
    } 
  }
  
  public int getSQLStateType() throws SQLException {
    try {
      preForAll(methodObject24796, this, new Object[0]);
      return ((Integer)postForAll(methodObject24796, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getSQLStateType()), this, (Map)this.proxyCache, methodObject24796))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24796, onErrorForAll(methodObject24796, e))).intValue();
    } 
  }
  
  public int getMaxStatementLength() throws SQLException {
    try {
      preForAll(methodObject24783, this, new Object[0]);
      return ((Integer)postForAll(methodObject24783, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxStatementLength()), this, (Map)this.proxyCache, methodObject24783))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24783, onErrorForAll(methodObject24783, e))).intValue();
    } 
  }
  
  public String getTimeDateFunctions() throws SQLException {
    try {
      preForAll(methodObject24808, this, new Object[0]);
      return (String)postForAll(methodObject24808, this.proxyFactory.proxyFor(this.delegate.getTimeDateFunctions(), this, (Map)this.proxyCache, methodObject24808));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24808, onErrorForAll(methodObject24808, e));
    } 
  }
  
  public boolean supportsSchemasInDataManipulation() throws SQLException {
    try {
      preForAll(methodObject24882, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24882, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSchemasInDataManipulation()), this, (Map)this.proxyCache, methodObject24882))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24882, onErrorForAll(methodObject24882, e))).booleanValue();
    } 
  }
  
  public boolean supportsPositionedUpdate() throws SQLException {
    try {
      preForAll(methodObject24877, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24877, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsPositionedUpdate()), this, (Map)this.proxyCache, methodObject24877))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24877, onErrorForAll(methodObject24877, e))).booleanValue();
    } 
  }
  
  public boolean storesMixedCaseQuotedIdentifiers() throws SQLException {
    try {
      preForAll(methodObject24830, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24830, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesMixedCaseQuotedIdentifiers()), this, (Map)this.proxyCache, methodObject24830))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24830, onErrorForAll(methodObject24830, e))).booleanValue();
    } 
  }
  
  public boolean supportsMixedCaseIdentifiers() throws SQLException {
    try {
      preForAll(methodObject24863, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24863, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMixedCaseIdentifiers()), this, (Map)this.proxyCache, methodObject24863))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24863, onErrorForAll(methodObject24863, e))).booleanValue();
    } 
  }
  
  public boolean storesUpperCaseQuotedIdentifiers() throws SQLException {
    try {
      preForAll(methodObject24832, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24832, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesUpperCaseQuotedIdentifiers()), this, (Map)this.proxyCache, methodObject24832))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24832, onErrorForAll(methodObject24832, e))).booleanValue();
    } 
  }
  
  public boolean supportsCoreSQLGrammar() throws SQLException {
    try {
      preForAll(methodObject24847, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24847, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCoreSQLGrammar()), this, (Map)this.proxyCache, methodObject24847))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24847, onErrorForAll(methodObject24847, e))).booleanValue();
    } 
  }
  
  public int getDatabaseMinorVersion() throws SQLException {
    try {
      preForAll(methodObject24751, this, new Object[0]);
      return ((Integer)postForAll(methodObject24751, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getDatabaseMinorVersion()), this, (Map)this.proxyCache, methodObject24751))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24751, onErrorForAll(methodObject24751, e))).intValue();
    } 
  }
  
  public int getMaxRowSize() throws SQLException {
    try {
      preForAll(methodObject24781, this, new Object[0]);
      return ((Integer)postForAll(methodObject24781, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxRowSize()), this, (Map)this.proxyCache, methodObject24781))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24781, onErrorForAll(methodObject24781, e))).intValue();
    } 
  }
  
  public boolean nullsAreSortedLow() throws SQLException {
    try {
      preForAll(methodObject24820, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24820, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullsAreSortedLow()), this, (Map)this.proxyCache, methodObject24820))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24820, onErrorForAll(methodObject24820, e))).booleanValue();
    } 
  }
  
  public boolean supportsNamedParameters() throws SQLException {
    try {
      preForAll(methodObject24868, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24868, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsNamedParameters()), this, (Map)this.proxyCache, methodObject24868))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24868, onErrorForAll(methodObject24868, e))).booleanValue();
    } 
  }
  
  public ResultSet getIndexInfo(String arg0, String arg1, String arg2, boolean arg3, boolean arg4) throws SQLException {
    try {
      preForAll(methodObject24765, this, new Object[] { arg0, arg1, arg2, Boolean.valueOf(arg3), Boolean.valueOf(arg4) });
      return (ResultSet)postForAll(methodObject24765, this.proxyFactory.proxyFor(this.delegate.getIndexInfo(arg0, arg1, arg2, arg3, arg4), this, (Map)this.proxyCache, methodObject24765));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24765, onErrorForAll(methodObject24765, e));
    } 
  }
  
  public String getURL() throws SQLException {
    try {
      preForAll(methodObject24731, this, new Object[0]);
      return (String)postForAll(methodObject24731, this.proxyFactory.proxyFor(this.delegate.getURL(), this, (Map)this.proxyCache, methodObject24731));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24731, onErrorForAll(methodObject24731, e));
    } 
  }
  
  public boolean supportsTransactions() throws SQLException {
    try {
      preForAll(methodObject24897, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24897, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsTransactions()), this, (Map)this.proxyCache, methodObject24897))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24897, onErrorForAll(methodObject24897, e))).booleanValue();
    } 
  }
  
  public Connection getConnection() throws SQLException {
    try {
      preForAll(methodObject24734, this, new Object[0]);
      return (Connection)postForAll(methodObject24734, this.proxyFactory.proxyFor(this.delegate.getConnection(), this, (Map)this.proxyCache, methodObject24734));
    } catch (SQLException e) {
      return (Connection)postForAll(methodObject24734, onErrorForAll(methodObject24734, e));
    } 
  }
  
  public String getExtraNameCharacters() throws SQLException {
    try {
      preForAll(methodObject24760, this, new Object[0]);
      return (String)postForAll(methodObject24760, this.proxyFactory.proxyFor(this.delegate.getExtraNameCharacters(), this, (Map)this.proxyCache, methodObject24760));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24760, onErrorForAll(methodObject24760, e));
    } 
  }
  
  public boolean supportsMixedCaseQuotedIdentifiers() throws SQLException {
    try {
      preForAll(methodObject24864, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24864, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMixedCaseQuotedIdentifiers()), this, (Map)this.proxyCache, methodObject24864))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24864, onErrorForAll(methodObject24864, e))).booleanValue();
    } 
  }
  
  public boolean storesLowerCaseQuotedIdentifiers() throws SQLException {
    try {
      preForAll(methodObject24828, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24828, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesLowerCaseQuotedIdentifiers()), this, (Map)this.proxyCache, methodObject24828))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24828, onErrorForAll(methodObject24828, e))).booleanValue();
    } 
  }
  
  public boolean supportsExtendedSQLGrammar() throws SQLException {
    try {
      preForAll(methodObject24853, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24853, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsExtendedSQLGrammar()), this, (Map)this.proxyCache, methodObject24853))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24853, onErrorForAll(methodObject24853, e))).booleanValue();
    } 
  }
  
  public boolean supportsConvert() throws SQLException {
    try {
      preForAll(methodObject24845, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24845, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsConvert()), this, (Map)this.proxyCache, methodObject24845))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24845, onErrorForAll(methodObject24845, e))).booleanValue();
    } 
  }
  
  public boolean supportsANSI92FullSQL() throws SQLException {
    try {
      preForAll(methodObject24834, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24834, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsANSI92FullSQL()), this, (Map)this.proxyCache, methodObject24834))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24834, onErrorForAll(methodObject24834, e))).booleanValue();
    } 
  }
  
  public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException {
    try {
      preForAll(methodObject24889, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24889, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsStoredFunctionsUsingCallSyntax()), this, (Map)this.proxyCache, methodObject24889))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24889, onErrorForAll(methodObject24889, e))).booleanValue();
    } 
  }
  
  public int getMaxCursorNameLength() throws SQLException {
    try {
      preForAll(methodObject24778, this, new Object[0]);
      return ((Integer)postForAll(methodObject24778, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxCursorNameLength()), this, (Map)this.proxyCache, methodObject24778))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24778, onErrorForAll(methodObject24778, e))).intValue();
    } 
  }
  
  public int getJDBCMinorVersion() throws SQLException {
    try {
      preForAll(methodObject24767, this, new Object[0]);
      return ((Integer)postForAll(methodObject24767, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getJDBCMinorVersion()), this, (Map)this.proxyCache, methodObject24767))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24767, onErrorForAll(methodObject24767, e))).intValue();
    } 
  }
  
  public boolean supportsNonNullableColumns() throws SQLException {
    try {
      preForAll(methodObject24869, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24869, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsNonNullableColumns()), this, (Map)this.proxyCache, methodObject24869))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24869, onErrorForAll(methodObject24869, e))).booleanValue();
    } 
  }
  
  public boolean isWrapperFor(Class<?> arg0) throws SQLException {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public ResultSet getUDTs(String arg0, String arg1, String arg2, int[] arg3) throws SQLException {
    try {
      preForAll(methodObject24810, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject24810, this.proxyFactory.proxyFor(this.delegate.getUDTs(arg0, arg1, arg2, arg3), this, (Map)this.proxyCache, methodObject24810));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24810, onErrorForAll(methodObject24810, e));
    } 
  }
  
  public boolean supportsLikeEscapeClause() throws SQLException {
    try {
      preForAll(methodObject24860, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24860, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsLikeEscapeClause()), this, (Map)this.proxyCache, methodObject24860))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24860, onErrorForAll(methodObject24860, e))).booleanValue();
    } 
  }
  
  public boolean supportsCorrelatedSubqueries() throws SQLException {
    try {
      preForAll(methodObject24848, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24848, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCorrelatedSubqueries()), this, (Map)this.proxyCache, methodObject24848))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24848, onErrorForAll(methodObject24848, e))).booleanValue();
    } 
  }
  
  public String getProcedureTerm() throws SQLException {
    try {
      preForAll(methodObject24791, this, new Object[0]);
      return (String)postForAll(methodObject24791, this.proxyFactory.proxyFor(this.delegate.getProcedureTerm(), this, (Map)this.proxyCache, methodObject24791));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24791, onErrorForAll(methodObject24791, e));
    } 
  }
  
  public boolean nullsAreSortedHigh() throws SQLException {
    try {
      preForAll(methodObject24819, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24819, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullsAreSortedHigh()), this, (Map)this.proxyCache, methodObject24819))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24819, onErrorForAll(methodObject24819, e))).booleanValue();
    } 
  }
  
  public boolean supportsSavepoints() throws SQLException {
    try {
      preForAll(methodObject24881, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24881, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSavepoints()), this, (Map)this.proxyCache, methodObject24881))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24881, onErrorForAll(methodObject24881, e))).booleanValue();
    } 
  }
  
  public int getMaxCatalogNameLength() throws SQLException {
    try {
      preForAll(methodObject24769, this, new Object[0]);
      return ((Integer)postForAll(methodObject24769, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxCatalogNameLength()), this, (Map)this.proxyCache, methodObject24769))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24769, onErrorForAll(methodObject24769, e))).intValue();
    } 
  }
  
  public boolean supportsBatchUpdates() throws SQLException {
    try {
      preForAll(methodObject24838, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24838, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsBatchUpdates()), this, (Map)this.proxyCache, methodObject24838))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24838, onErrorForAll(methodObject24838, e))).booleanValue();
    } 
  }
  
  public ResultSet getVersionColumns(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24812, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24812, this.proxyFactory.proxyFor(this.delegate.getVersionColumns(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24812));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24812, onErrorForAll(methodObject24812, e));
    } 
  }
  
  public boolean supportsExpressionsInOrderBy() throws SQLException {
    try {
      preForAll(methodObject24852, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24852, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsExpressionsInOrderBy()), this, (Map)this.proxyCache, methodObject24852))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24852, onErrorForAll(methodObject24852, e))).booleanValue();
    } 
  }
  
  public boolean supportsResultSetType(int arg0) throws SQLException {
    try {
      preForAll(methodObject24880, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24880, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsResultSetType(arg0)), this, (Map)this.proxyCache, methodObject24880))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24880, onErrorForAll(methodObject24880, e))).booleanValue();
    } 
  }
  
  public ResultSet getColumns(String arg0, String arg1, String arg2, String arg3) throws SQLException {
    try {
      preForAll(methodObject24748, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject24748, this.proxyFactory.proxyFor(this.delegate.getColumns(arg0, arg1, arg2, arg3), this, (Map)this.proxyCache, methodObject24748));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24748, onErrorForAll(methodObject24748, e));
    } 
  }
  
  public boolean dataDefinitionIgnoredInTransactions() throws SQLException {
    try {
      preForAll(methodObject24739, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24739, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.dataDefinitionIgnoredInTransactions()), this, (Map)this.proxyCache, methodObject24739))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24739, onErrorForAll(methodObject24739, e))).booleanValue();
    } 
  }
  
  public boolean supportsOuterJoins() throws SQLException {
    try {
      preForAll(methodObject24875, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24875, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOuterJoins()), this, (Map)this.proxyCache, methodObject24875))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24875, onErrorForAll(methodObject24875, e))).booleanValue();
    } 
  }
  
  public boolean nullsAreSortedAtStart() throws SQLException {
    try {
      preForAll(methodObject24818, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24818, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullsAreSortedAtStart()), this, (Map)this.proxyCache, methodObject24818))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24818, onErrorForAll(methodObject24818, e))).booleanValue();
    } 
  }
  
  public boolean supportsUnionAll() throws SQLException {
    try {
      preForAll(methodObject24899, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24899, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsUnionAll()), this, (Map)this.proxyCache, methodObject24899))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24899, onErrorForAll(methodObject24899, e))).booleanValue();
    } 
  }
  
  public boolean allProceduresAreCallable() throws SQLException {
    try {
      preForAll(methodObject24735, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24735, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.allProceduresAreCallable()), this, (Map)this.proxyCache, methodObject24735))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24735, onErrorForAll(methodObject24735, e))).booleanValue();
    } 
  }
  
  public boolean ownUpdatesAreVisible(int arg0) throws SQLException {
    try {
      preForAll(methodObject24826, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24826, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.ownUpdatesAreVisible(arg0)), this, (Map)this.proxyCache, methodObject24826))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24826, onErrorForAll(methodObject24826, e))).booleanValue();
    } 
  }
  
  public boolean supportsResultSetConcurrency(int arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject24878, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
      return ((Boolean)postForAll(methodObject24878, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsResultSetConcurrency(arg0, arg1)), this, (Map)this.proxyCache, methodObject24878))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24878, onErrorForAll(methodObject24878, e))).booleanValue();
    } 
  }
  
  public Object unwrap(Class<?> arg0) throws SQLException {
    return this.delegate.unwrap(arg0);
  }
  
  public boolean supportsCatalogsInDataManipulation() throws SQLException {
    try {
      preForAll(methodObject24839, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24839, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInDataManipulation()), this, (Map)this.proxyCache, methodObject24839))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24839, onErrorForAll(methodObject24839, e))).booleanValue();
    } 
  }
  
  public RowIdLifetime getRowIdLifetime() throws SQLException {
    try {
      preForAll(methodObject24794, this, new Object[0]);
      return (RowIdLifetime)postForAll(methodObject24794, this.proxyFactory.proxyFor(this.delegate.getRowIdLifetime(), this, (Map)this.proxyCache, methodObject24794));
    } catch (SQLException e) {
      return (RowIdLifetime)postForAll(methodObject24794, onErrorForAll(methodObject24794, e));
    } 
  }
  
  public String getDatabaseProductVersion() throws SQLException {
    try {
      preForAll(methodObject24753, this, new Object[0]);
      return (String)postForAll(methodObject24753, this.proxyFactory.proxyFor(this.delegate.getDatabaseProductVersion(), this, (Map)this.proxyCache, methodObject24753));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24753, onErrorForAll(methodObject24753, e));
    } 
  }
  
  public int getMaxProcedureNameLength() throws SQLException {
    try {
      preForAll(methodObject24780, this, new Object[0]);
      return ((Integer)postForAll(methodObject24780, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxProcedureNameLength()), this, (Map)this.proxyCache, methodObject24780))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24780, onErrorForAll(methodObject24780, e))).intValue();
    } 
  }
  
  public ResultSet getSuperTypes(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24803, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24803, this.proxyFactory.proxyFor(this.delegate.getSuperTypes(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24803));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24803, onErrorForAll(methodObject24803, e));
    } 
  }
  
  public ResultSet getProcedureColumns(String arg0, String arg1, String arg2, String arg3) throws SQLException {
    try {
      preForAll(methodObject24790, this, new Object[] { arg0, arg1, arg2, arg3 });
      return (ResultSet)postForAll(methodObject24790, this.proxyFactory.proxyFor(this.delegate.getProcedureColumns(arg0, arg1, arg2, arg3), this, (Map)this.proxyCache, methodObject24790));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24790, onErrorForAll(methodObject24790, e));
    } 
  }
  
  public boolean storesMixedCaseIdentifiers() throws SQLException {
    try {
      preForAll(methodObject24829, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24829, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesMixedCaseIdentifiers()), this, (Map)this.proxyCache, methodObject24829))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24829, onErrorForAll(methodObject24829, e))).booleanValue();
    } 
  }
  
  public boolean othersInsertsAreVisible(int arg0) throws SQLException {
    try {
      preForAll(methodObject24822, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24822, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.othersInsertsAreVisible(arg0)), this, (Map)this.proxyCache, methodObject24822))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24822, onErrorForAll(methodObject24822, e))).booleanValue();
    } 
  }
  
  public boolean supportsColumnAliasing() throws SQLException {
    try {
      preForAll(methodObject24844, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24844, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsColumnAliasing()), this, (Map)this.proxyCache, methodObject24844))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24844, onErrorForAll(methodObject24844, e))).booleanValue();
    } 
  }
  
  public boolean supportsAlterTableWithDropColumn() throws SQLException {
    try {
      preForAll(methodObject24837, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24837, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsAlterTableWithDropColumn()), this, (Map)this.proxyCache, methodObject24837))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24837, onErrorForAll(methodObject24837, e))).booleanValue();
    } 
  }
  
  public boolean supportsMultipleTransactions() throws SQLException {
    try {
      preForAll(methodObject24867, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24867, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMultipleTransactions()), this, (Map)this.proxyCache, methodObject24867))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24867, onErrorForAll(methodObject24867, e))).booleanValue();
    } 
  }
  
  public boolean ownDeletesAreVisible(int arg0) throws SQLException {
    try {
      preForAll(methodObject24824, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24824, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.ownDeletesAreVisible(arg0)), this, (Map)this.proxyCache, methodObject24824))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24824, onErrorForAll(methodObject24824, e))).booleanValue();
    } 
  }
  
  public boolean supportsGroupBy() throws SQLException {
    try {
      preForAll(methodObject24856, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24856, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsGroupBy()), this, (Map)this.proxyCache, methodObject24856))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24856, onErrorForAll(methodObject24856, e))).booleanValue();
    } 
  }
  
  public int getMaxColumnsInTable() throws SQLException {
    try {
      preForAll(methodObject24776, this, new Object[0]);
      return ((Integer)postForAll(methodObject24776, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInTable()), this, (Map)this.proxyCache, methodObject24776))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24776, onErrorForAll(methodObject24776, e))).intValue();
    } 
  }
  
  public ResultSet getSchemas(String arg0, String arg1) throws SQLException {
    try {
      preForAll(methodObject24799, this, new Object[] { arg0, arg1 });
      return (ResultSet)postForAll(methodObject24799, this.proxyFactory.proxyFor(this.delegate.getSchemas(arg0, arg1), this, (Map)this.proxyCache, methodObject24799));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24799, onErrorForAll(methodObject24799, e));
    } 
  }
  
  public int getMaxColumnsInOrderBy() throws SQLException {
    try {
      preForAll(methodObject24774, this, new Object[0]);
      return ((Integer)postForAll(methodObject24774, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInOrderBy()), this, (Map)this.proxyCache, methodObject24774))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24774, onErrorForAll(methodObject24774, e))).intValue();
    } 
  }
  
  public int getMaxConnections() throws SQLException {
    try {
      preForAll(methodObject24777, this, new Object[0]);
      return ((Integer)postForAll(methodObject24777, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxConnections()), this, (Map)this.proxyCache, methodObject24777))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24777, onErrorForAll(methodObject24777, e))).intValue();
    } 
  }
  
  public boolean allTablesAreSelectable() throws SQLException {
    try {
      preForAll(methodObject24736, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24736, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.allTablesAreSelectable()), this, (Map)this.proxyCache, methodObject24736))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24736, onErrorForAll(methodObject24736, e))).booleanValue();
    } 
  }
  
  public ResultSet getTableTypes() throws SQLException {
    try {
      preForAll(methodObject24806, this, new Object[0]);
      return (ResultSet)postForAll(methodObject24806, this.proxyFactory.proxyFor(this.delegate.getTableTypes(), this, (Map)this.proxyCache, methodObject24806));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24806, onErrorForAll(methodObject24806, e));
    } 
  }
  
  public boolean nullPlusNonNullIsNull() throws SQLException {
    try {
      preForAll(methodObject24816, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24816, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.nullPlusNonNullIsNull()), this, (Map)this.proxyCache, methodObject24816))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24816, onErrorForAll(methodObject24816, e))).booleanValue();
    } 
  }
  
  public boolean supportsSubqueriesInComparisons() throws SQLException {
    try {
      preForAll(methodObject24891, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24891, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSubqueriesInComparisons()), this, (Map)this.proxyCache, methodObject24891))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24891, onErrorForAll(methodObject24891, e))).booleanValue();
    } 
  }
  
  public int getMaxIndexLength() throws SQLException {
    try {
      preForAll(methodObject24779, this, new Object[0]);
      return ((Integer)postForAll(methodObject24779, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxIndexLength()), this, (Map)this.proxyCache, methodObject24779))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24779, onErrorForAll(methodObject24779, e))).intValue();
    } 
  }
  
  public boolean supportsSubqueriesInQuantifieds() throws SQLException {
    try {
      preForAll(methodObject24894, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24894, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSubqueriesInQuantifieds()), this, (Map)this.proxyCache, methodObject24894))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24894, onErrorForAll(methodObject24894, e))).booleanValue();
    } 
  }
  
  public boolean supportsOpenStatementsAcrossCommit() throws SQLException {
    try {
      preForAll(methodObject24872, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24872, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOpenStatementsAcrossCommit()), this, (Map)this.proxyCache, methodObject24872))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24872, onErrorForAll(methodObject24872, e))).booleanValue();
    } 
  }
  
  public boolean supportsCatalogsInTableDefinitions() throws SQLException {
    try {
      preForAll(methodObject24843, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24843, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInTableDefinitions()), this, (Map)this.proxyCache, methodObject24843))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24843, onErrorForAll(methodObject24843, e))).booleanValue();
    } 
  }
  
  public boolean othersDeletesAreVisible(int arg0) throws SQLException {
    try {
      preForAll(methodObject24821, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24821, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.othersDeletesAreVisible(arg0)), this, (Map)this.proxyCache, methodObject24821))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24821, onErrorForAll(methodObject24821, e))).booleanValue();
    } 
  }
  
  public boolean supportsGroupByBeyondSelect() throws SQLException {
    try {
      preForAll(methodObject24857, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24857, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsGroupByBeyondSelect()), this, (Map)this.proxyCache, methodObject24857))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24857, onErrorForAll(methodObject24857, e))).booleanValue();
    } 
  }
  
  public boolean supportsStatementPooling() throws SQLException {
    try {
      preForAll(methodObject24888, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24888, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsStatementPooling()), this, (Map)this.proxyCache, methodObject24888))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24888, onErrorForAll(methodObject24888, e))).booleanValue();
    } 
  }
  
  public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLException {
    try {
      preForAll(methodObject24849, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24849, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsDataDefinitionAndDataManipulationTransactions()), this, (Map)this.proxyCache, methodObject24849))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24849, onErrorForAll(methodObject24849, e))).booleanValue();
    } 
  }
  
  public boolean supportsMultipleOpenResults() throws SQLException {
    try {
      preForAll(methodObject24865, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24865, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMultipleOpenResults()), this, (Map)this.proxyCache, methodObject24865))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24865, onErrorForAll(methodObject24865, e))).booleanValue();
    } 
  }
  
  public int getMaxColumnsInGroupBy() throws SQLException {
    try {
      preForAll(methodObject24772, this, new Object[0]);
      return ((Integer)postForAll(methodObject24772, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnsInGroupBy()), this, (Map)this.proxyCache, methodObject24772))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24772, onErrorForAll(methodObject24772, e))).intValue();
    } 
  }
  
  public int getMaxColumnNameLength() throws SQLException {
    try {
      preForAll(methodObject24771, this, new Object[0]);
      return ((Integer)postForAll(methodObject24771, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxColumnNameLength()), this, (Map)this.proxyCache, methodObject24771))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24771, onErrorForAll(methodObject24771, e))).intValue();
    } 
  }
  
  public int getMaxStatements() throws SQLException {
    try {
      preForAll(methodObject24784, this, new Object[0]);
      return ((Integer)postForAll(methodObject24784, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxStatements()), this, (Map)this.proxyCache, methodObject24784))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24784, onErrorForAll(methodObject24784, e))).intValue();
    } 
  }
  
  public boolean supportsAlterTableWithAddColumn() throws SQLException {
    try {
      preForAll(methodObject24836, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24836, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsAlterTableWithAddColumn()), this, (Map)this.proxyCache, methodObject24836))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24836, onErrorForAll(methodObject24836, e))).booleanValue();
    } 
  }
  
  public boolean supportsGroupByUnrelated() throws SQLException {
    try {
      preForAll(methodObject24858, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24858, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsGroupByUnrelated()), this, (Map)this.proxyCache, methodObject24858))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24858, onErrorForAll(methodObject24858, e))).booleanValue();
    } 
  }
  
  public boolean supportsANSI92EntryLevelSQL() throws SQLException {
    try {
      preForAll(methodObject24833, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24833, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsANSI92EntryLevelSQL()), this, (Map)this.proxyCache, methodObject24833))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24833, onErrorForAll(methodObject24833, e))).booleanValue();
    } 
  }
  
  public boolean supportsMinimumSQLGrammar() throws SQLException {
    try {
      preForAll(methodObject24862, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24862, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMinimumSQLGrammar()), this, (Map)this.proxyCache, methodObject24862))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24862, onErrorForAll(methodObject24862, e))).booleanValue();
    } 
  }
  
  public int getMaxCharLiteralLength() throws SQLException {
    try {
      preForAll(methodObject24770, this, new Object[0]);
      return ((Integer)postForAll(methodObject24770, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getMaxCharLiteralLength()), this, (Map)this.proxyCache, methodObject24770))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24770, onErrorForAll(methodObject24770, e))).intValue();
    } 
  }
  
  public boolean storesLowerCaseIdentifiers() throws SQLException {
    try {
      preForAll(methodObject24827, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24827, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.storesLowerCaseIdentifiers()), this, (Map)this.proxyCache, methodObject24827))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24827, onErrorForAll(methodObject24827, e))).booleanValue();
    } 
  }
  
  public boolean supportsMultipleResultSets() throws SQLException {
    try {
      preForAll(methodObject24866, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24866, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsMultipleResultSets()), this, (Map)this.proxyCache, methodObject24866))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24866, onErrorForAll(methodObject24866, e))).booleanValue();
    } 
  }
  
  public boolean supportsOpenCursorsAcrossRollback() throws SQLException {
    try {
      preForAll(methodObject24871, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24871, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsOpenCursorsAcrossRollback()), this, (Map)this.proxyCache, methodObject24871))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24871, onErrorForAll(methodObject24871, e))).booleanValue();
    } 
  }
  
  public boolean updatesAreDetected(int arg0) throws SQLException {
    try {
      preForAll(methodObject24900, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24900, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.updatesAreDetected(arg0)), this, (Map)this.proxyCache, methodObject24900))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24900, onErrorForAll(methodObject24900, e))).booleanValue();
    } 
  }
  
  public boolean deletesAreDetected(int arg0) throws SQLException {
    try {
      preForAll(methodObject24740, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24740, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.deletesAreDetected(arg0)), this, (Map)this.proxyCache, methodObject24740))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24740, onErrorForAll(methodObject24740, e))).booleanValue();
    } 
  }
  
  public boolean supportsSelectForUpdate() throws SQLException {
    try {
      preForAll(methodObject24887, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24887, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsSelectForUpdate()), this, (Map)this.proxyCache, methodObject24887))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24887, onErrorForAll(methodObject24887, e))).booleanValue();
    } 
  }
  
  public boolean supportsPositionedDelete() throws SQLException {
    try {
      preForAll(methodObject24876, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24876, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsPositionedDelete()), this, (Map)this.proxyCache, methodObject24876))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24876, onErrorForAll(methodObject24876, e))).booleanValue();
    } 
  }
  
  public boolean supportsCatalogsInProcedureCalls() throws SQLException {
    try {
      preForAll(methodObject24842, this, new Object[0]);
      return ((Boolean)postForAll(methodObject24842, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.supportsCatalogsInProcedureCalls()), this, (Map)this.proxyCache, methodObject24842))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24842, onErrorForAll(methodObject24842, e))).booleanValue();
    } 
  }
  
  public ResultSet getFunctions(String arg0, String arg1, String arg2) throws SQLException {
    try {
      preForAll(methodObject24762, this, new Object[] { arg0, arg1, arg2 });
      return (ResultSet)postForAll(methodObject24762, this.proxyFactory.proxyFor(this.delegate.getFunctions(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject24762));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24762, onErrorForAll(methodObject24762, e));
    } 
  }
  
  public ResultSet getBestRowIdentifier(String arg0, String arg1, String arg2, int arg3, boolean arg4) throws SQLException {
    try {
      preForAll(methodObject24742, this, new Object[] { arg0, arg1, arg2, Integer.valueOf(arg3), Boolean.valueOf(arg4) });
      return (ResultSet)postForAll(methodObject24742, this.proxyFactory.proxyFor(this.delegate.getBestRowIdentifier(arg0, arg1, arg2, arg3, arg4), this, (Map)this.proxyCache, methodObject24742));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject24742, onErrorForAll(methodObject24742, e));
    } 
  }
  
  public String getCatalogSeparator() throws SQLException {
    try {
      preForAll(methodObject24743, this, new Object[0]);
      return (String)postForAll(methodObject24743, this.proxyFactory.proxyFor(this.delegate.getCatalogSeparator(), this, (Map)this.proxyCache, methodObject24743));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24743, onErrorForAll(methodObject24743, e));
    } 
  }
  
  public DatabaseMetaData _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(DatabaseMetaData delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject24896 = DatabaseMetaData.class.getDeclaredMethod("supportsTransactionIsolationLevel", new Class[] { int.class });
      methodObject24766 = DatabaseMetaData.class.getDeclaredMethod("getJDBCMajorVersion", new Class[0]);
      methodObject24870 = DatabaseMetaData.class.getDeclaredMethod("supportsOpenCursorsAcrossCommit", new Class[0]);
      methodObject24840 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInIndexDefinitions", new Class[0]);
      methodObject24756 = DatabaseMetaData.class.getDeclaredMethod("getDriverMinorVersion", new Class[0]);
      methodObject24744 = DatabaseMetaData.class.getDeclaredMethod("getCatalogTerm", new Class[0]);
      methodObject24761 = DatabaseMetaData.class.getDeclaredMethod("getFunctionColumns", new Class[] { String.class, String.class, String.class, String.class });
      methodObject24792 = DatabaseMetaData.class.getDeclaredMethod("getProcedures", new Class[] { String.class, String.class, String.class });
      methodObject24861 = DatabaseMetaData.class.getDeclaredMethod("supportsLimitedOuterJoins", new Class[0]);
      methodObject24825 = DatabaseMetaData.class.getDeclaredMethod("ownInsertsAreVisible", new Class[] { int.class });
      methodObject24798 = DatabaseMetaData.class.getDeclaredMethod("getSchemas", new Class[0]);
      methodObject24763 = DatabaseMetaData.class.getDeclaredMethod("getIdentifierQuoteString", new Class[0]);
      methodObject24850 = DatabaseMetaData.class.getDeclaredMethod("supportsDataManipulationTransactionsOnly", new Class[0]);
      methodObject24800 = DatabaseMetaData.class.getDeclaredMethod("getSearchStringEscape", new Class[0]);
      methodObject24884 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInPrivilegeDefinitions", new Class[0]);
      methodObject24749 = DatabaseMetaData.class.getDeclaredMethod("getCrossReference", new Class[] { String.class, String.class, String.class, String.class, String.class, String.class });
      methodObject24782 = DatabaseMetaData.class.getDeclaredMethod("getMaxSchemaNameLength", new Class[0]);
      methodObject24854 = DatabaseMetaData.class.getDeclaredMethod("supportsFullOuterJoins", new Class[0]);
      methodObject24759 = DatabaseMetaData.class.getDeclaredMethod("getExportedKeys", new Class[] { String.class, String.class, String.class });
      methodObject24815 = DatabaseMetaData.class.getDeclaredMethod("locatorsUpdateCopy", new Class[0]);
      methodObject24804 = DatabaseMetaData.class.getDeclaredMethod("getSystemFunctions", new Class[0]);
      methodObject24901 = DatabaseMetaData.class.getDeclaredMethod("usesLocalFilePerTable", new Class[0]);
      methodObject24795 = DatabaseMetaData.class.getDeclaredMethod("getSQLKeywords", new Class[0]);
      methodObject24811 = DatabaseMetaData.class.getDeclaredMethod("getUserName", new Class[0]);
      methodObject24787 = DatabaseMetaData.class.getDeclaredMethod("getMaxUserNameLength", new Class[0]);
      methodObject24758 = DatabaseMetaData.class.getDeclaredMethod("getDriverVersion", new Class[0]);
      methodObject24773 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInIndex", new Class[0]);
      methodObject24747 = DatabaseMetaData.class.getDeclaredMethod("getColumnPrivileges", new Class[] { String.class, String.class, String.class, String.class });
      methodObject24797 = DatabaseMetaData.class.getDeclaredMethod("getSchemaTerm", new Class[0]);
      methodObject24893 = DatabaseMetaData.class.getDeclaredMethod("supportsSubqueriesInIns", new Class[0]);
      methodObject24885 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInProcedureCalls", new Class[0]);
      methodObject24873 = DatabaseMetaData.class.getDeclaredMethod("supportsOpenStatementsAcrossRollback", new Class[0]);
      methodObject24757 = DatabaseMetaData.class.getDeclaredMethod("getDriverName", new Class[0]);
      methodObject24737 = DatabaseMetaData.class.getDeclaredMethod("autoCommitFailureClosesAllResultSets", new Class[0]);
      methodObject24746 = DatabaseMetaData.class.getDeclaredMethod("getClientInfoProperties", new Class[0]);
      methodObject24752 = DatabaseMetaData.class.getDeclaredMethod("getDatabaseProductName", new Class[0]);
      methodObject24895 = DatabaseMetaData.class.getDeclaredMethod("supportsTableCorrelationNames", new Class[0]);
      methodObject24802 = DatabaseMetaData.class.getDeclaredMethod("getSuperTables", new Class[] { String.class, String.class, String.class });
      methodObject24807 = DatabaseMetaData.class.getDeclaredMethod("getTables", new Class[] { String.class, String.class, String.class, String[].class });
      methodObject24879 = DatabaseMetaData.class.getDeclaredMethod("supportsResultSetHoldability", new Class[] { int.class });
      methodObject24750 = DatabaseMetaData.class.getDeclaredMethod("getDatabaseMajorVersion", new Class[0]);
      methodObject24846 = DatabaseMetaData.class.getDeclaredMethod("supportsConvert", new Class[] { int.class, int.class });
      methodObject24775 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInSelect", new Class[0]);
      methodObject24890 = DatabaseMetaData.class.getDeclaredMethod("supportsStoredProcedures", new Class[0]);
      methodObject24883 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInIndexDefinitions", new Class[0]);
      methodObject24754 = DatabaseMetaData.class.getDeclaredMethod("getDefaultTransactionIsolation", new Class[0]);
      methodObject24801 = DatabaseMetaData.class.getDeclaredMethod("getStringFunctions", new Class[0]);
      methodObject24741 = DatabaseMetaData.class.getDeclaredMethod("doesMaxRowSizeIncludeBlobs", new Class[0]);
      methodObject24886 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInTableDefinitions", new Class[0]);
      methodObject24859 = DatabaseMetaData.class.getDeclaredMethod("supportsIntegrityEnhancementFacility", new Class[0]);
      methodObject24738 = DatabaseMetaData.class.getDeclaredMethod("dataDefinitionCausesTransactionCommit", new Class[0]);
      methodObject24817 = DatabaseMetaData.class.getDeclaredMethod("nullsAreSortedAtEnd", new Class[0]);
      methodObject24745 = DatabaseMetaData.class.getDeclaredMethod("getCatalogs", new Class[0]);
      methodObject24813 = DatabaseMetaData.class.getDeclaredMethod("insertsAreDetected", new Class[] { int.class });
      methodObject24755 = DatabaseMetaData.class.getDeclaredMethod("getDriverMajorVersion", new Class[0]);
      methodObject24789 = DatabaseMetaData.class.getDeclaredMethod("getPrimaryKeys", new Class[] { String.class, String.class, String.class });
      methodObject24841 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInPrivilegeDefinitions", new Class[0]);
      methodObject24814 = DatabaseMetaData.class.getDeclaredMethod("isCatalogAtStart", new Class[0]);
      methodObject24733 = DatabaseMetaData.class.getDeclaredMethod("getAttributes", new Class[] { String.class, String.class, String.class, String.class });
      methodObject24805 = DatabaseMetaData.class.getDeclaredMethod("getTablePrivileges", new Class[] { String.class, String.class, String.class });
      methodObject24823 = DatabaseMetaData.class.getDeclaredMethod("othersUpdatesAreVisible", new Class[] { int.class });
      methodObject24768 = DatabaseMetaData.class.getDeclaredMethod("getMaxBinaryLiteralLength", new Class[0]);
      methodObject24793 = DatabaseMetaData.class.getDeclaredMethod("getResultSetHoldability", new Class[0]);
      methodObject24831 = DatabaseMetaData.class.getDeclaredMethod("storesUpperCaseIdentifiers", new Class[0]);
      methodObject24732 = DatabaseMetaData.class.getDeclaredMethod("isReadOnly", new Class[0]);
      methodObject24851 = DatabaseMetaData.class.getDeclaredMethod("supportsDifferentTableCorrelationNames", new Class[0]);
      methodObject24855 = DatabaseMetaData.class.getDeclaredMethod("supportsGetGeneratedKeys", new Class[0]);
      methodObject24764 = DatabaseMetaData.class.getDeclaredMethod("getImportedKeys", new Class[] { String.class, String.class, String.class });
      methodObject24785 = DatabaseMetaData.class.getDeclaredMethod("getMaxTableNameLength", new Class[0]);
      methodObject24809 = DatabaseMetaData.class.getDeclaredMethod("getTypeInfo", new Class[0]);
      methodObject24786 = DatabaseMetaData.class.getDeclaredMethod("getMaxTablesInSelect", new Class[0]);
      methodObject24898 = DatabaseMetaData.class.getDeclaredMethod("supportsUnion", new Class[0]);
      methodObject24892 = DatabaseMetaData.class.getDeclaredMethod("supportsSubqueriesInExists", new Class[0]);
      methodObject24874 = DatabaseMetaData.class.getDeclaredMethod("supportsOrderByUnrelated", new Class[0]);
      methodObject24902 = DatabaseMetaData.class.getDeclaredMethod("usesLocalFiles", new Class[0]);
      methodObject24835 = DatabaseMetaData.class.getDeclaredMethod("supportsANSI92IntermediateSQL", new Class[0]);
      methodObject24788 = DatabaseMetaData.class.getDeclaredMethod("getNumericFunctions", new Class[0]);
      methodObject24796 = DatabaseMetaData.class.getDeclaredMethod("getSQLStateType", new Class[0]);
      methodObject24783 = DatabaseMetaData.class.getDeclaredMethod("getMaxStatementLength", new Class[0]);
      methodObject24808 = DatabaseMetaData.class.getDeclaredMethod("getTimeDateFunctions", new Class[0]);
      methodObject24882 = DatabaseMetaData.class.getDeclaredMethod("supportsSchemasInDataManipulation", new Class[0]);
      methodObject24877 = DatabaseMetaData.class.getDeclaredMethod("supportsPositionedUpdate", new Class[0]);
      methodObject24830 = DatabaseMetaData.class.getDeclaredMethod("storesMixedCaseQuotedIdentifiers", new Class[0]);
      methodObject24863 = DatabaseMetaData.class.getDeclaredMethod("supportsMixedCaseIdentifiers", new Class[0]);
      methodObject24832 = DatabaseMetaData.class.getDeclaredMethod("storesUpperCaseQuotedIdentifiers", new Class[0]);
      methodObject24847 = DatabaseMetaData.class.getDeclaredMethod("supportsCoreSQLGrammar", new Class[0]);
      methodObject24751 = DatabaseMetaData.class.getDeclaredMethod("getDatabaseMinorVersion", new Class[0]);
      methodObject24781 = DatabaseMetaData.class.getDeclaredMethod("getMaxRowSize", new Class[0]);
      methodObject24820 = DatabaseMetaData.class.getDeclaredMethod("nullsAreSortedLow", new Class[0]);
      methodObject24868 = DatabaseMetaData.class.getDeclaredMethod("supportsNamedParameters", new Class[0]);
      methodObject24765 = DatabaseMetaData.class.getDeclaredMethod("getIndexInfo", new Class[] { String.class, String.class, String.class, boolean.class, boolean.class });
      methodObject24731 = DatabaseMetaData.class.getDeclaredMethod("getURL", new Class[0]);
      methodObject24897 = DatabaseMetaData.class.getDeclaredMethod("supportsTransactions", new Class[0]);
      methodObject24734 = DatabaseMetaData.class.getDeclaredMethod("getConnection", new Class[0]);
      methodObject24760 = DatabaseMetaData.class.getDeclaredMethod("getExtraNameCharacters", new Class[0]);
      methodObject24864 = DatabaseMetaData.class.getDeclaredMethod("supportsMixedCaseQuotedIdentifiers", new Class[0]);
      methodObject24828 = DatabaseMetaData.class.getDeclaredMethod("storesLowerCaseQuotedIdentifiers", new Class[0]);
      methodObject24853 = DatabaseMetaData.class.getDeclaredMethod("supportsExtendedSQLGrammar", new Class[0]);
      methodObject24845 = DatabaseMetaData.class.getDeclaredMethod("supportsConvert", new Class[0]);
      methodObject24834 = DatabaseMetaData.class.getDeclaredMethod("supportsANSI92FullSQL", new Class[0]);
      methodObject24889 = DatabaseMetaData.class.getDeclaredMethod("supportsStoredFunctionsUsingCallSyntax", new Class[0]);
      methodObject24778 = DatabaseMetaData.class.getDeclaredMethod("getMaxCursorNameLength", new Class[0]);
      methodObject24767 = DatabaseMetaData.class.getDeclaredMethod("getJDBCMinorVersion", new Class[0]);
      methodObject24869 = DatabaseMetaData.class.getDeclaredMethod("supportsNonNullableColumns", new Class[0]);
      methodObject24903 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject24810 = DatabaseMetaData.class.getDeclaredMethod("getUDTs", new Class[] { String.class, String.class, String.class, int[].class });
      methodObject24860 = DatabaseMetaData.class.getDeclaredMethod("supportsLikeEscapeClause", new Class[0]);
      methodObject24848 = DatabaseMetaData.class.getDeclaredMethod("supportsCorrelatedSubqueries", new Class[0]);
      methodObject24791 = DatabaseMetaData.class.getDeclaredMethod("getProcedureTerm", new Class[0]);
      methodObject24819 = DatabaseMetaData.class.getDeclaredMethod("nullsAreSortedHigh", new Class[0]);
      methodObject24881 = DatabaseMetaData.class.getDeclaredMethod("supportsSavepoints", new Class[0]);
      methodObject24769 = DatabaseMetaData.class.getDeclaredMethod("getMaxCatalogNameLength", new Class[0]);
      methodObject24838 = DatabaseMetaData.class.getDeclaredMethod("supportsBatchUpdates", new Class[0]);
      methodObject24812 = DatabaseMetaData.class.getDeclaredMethod("getVersionColumns", new Class[] { String.class, String.class, String.class });
      methodObject24852 = DatabaseMetaData.class.getDeclaredMethod("supportsExpressionsInOrderBy", new Class[0]);
      methodObject24880 = DatabaseMetaData.class.getDeclaredMethod("supportsResultSetType", new Class[] { int.class });
      methodObject24748 = DatabaseMetaData.class.getDeclaredMethod("getColumns", new Class[] { String.class, String.class, String.class, String.class });
      methodObject24739 = DatabaseMetaData.class.getDeclaredMethod("dataDefinitionIgnoredInTransactions", new Class[0]);
      methodObject24875 = DatabaseMetaData.class.getDeclaredMethod("supportsOuterJoins", new Class[0]);
      methodObject24818 = DatabaseMetaData.class.getDeclaredMethod("nullsAreSortedAtStart", new Class[0]);
      methodObject24899 = DatabaseMetaData.class.getDeclaredMethod("supportsUnionAll", new Class[0]);
      methodObject24735 = DatabaseMetaData.class.getDeclaredMethod("allProceduresAreCallable", new Class[0]);
      methodObject24826 = DatabaseMetaData.class.getDeclaredMethod("ownUpdatesAreVisible", new Class[] { int.class });
      methodObject24878 = DatabaseMetaData.class.getDeclaredMethod("supportsResultSetConcurrency", new Class[] { int.class, int.class });
      methodObject24904 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject24839 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInDataManipulation", new Class[0]);
      methodObject24794 = DatabaseMetaData.class.getDeclaredMethod("getRowIdLifetime", new Class[0]);
      methodObject24753 = DatabaseMetaData.class.getDeclaredMethod("getDatabaseProductVersion", new Class[0]);
      methodObject24780 = DatabaseMetaData.class.getDeclaredMethod("getMaxProcedureNameLength", new Class[0]);
      methodObject24803 = DatabaseMetaData.class.getDeclaredMethod("getSuperTypes", new Class[] { String.class, String.class, String.class });
      methodObject24790 = DatabaseMetaData.class.getDeclaredMethod("getProcedureColumns", new Class[] { String.class, String.class, String.class, String.class });
      methodObject24829 = DatabaseMetaData.class.getDeclaredMethod("storesMixedCaseIdentifiers", new Class[0]);
      methodObject24822 = DatabaseMetaData.class.getDeclaredMethod("othersInsertsAreVisible", new Class[] { int.class });
      methodObject24844 = DatabaseMetaData.class.getDeclaredMethod("supportsColumnAliasing", new Class[0]);
      methodObject24837 = DatabaseMetaData.class.getDeclaredMethod("supportsAlterTableWithDropColumn", new Class[0]);
      methodObject24867 = DatabaseMetaData.class.getDeclaredMethod("supportsMultipleTransactions", new Class[0]);
      methodObject24824 = DatabaseMetaData.class.getDeclaredMethod("ownDeletesAreVisible", new Class[] { int.class });
      methodObject24856 = DatabaseMetaData.class.getDeclaredMethod("supportsGroupBy", new Class[0]);
      methodObject24776 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInTable", new Class[0]);
      methodObject24799 = DatabaseMetaData.class.getDeclaredMethod("getSchemas", new Class[] { String.class, String.class });
      methodObject24774 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInOrderBy", new Class[0]);
      methodObject24777 = DatabaseMetaData.class.getDeclaredMethod("getMaxConnections", new Class[0]);
      methodObject24736 = DatabaseMetaData.class.getDeclaredMethod("allTablesAreSelectable", new Class[0]);
      methodObject24806 = DatabaseMetaData.class.getDeclaredMethod("getTableTypes", new Class[0]);
      methodObject24816 = DatabaseMetaData.class.getDeclaredMethod("nullPlusNonNullIsNull", new Class[0]);
      methodObject24891 = DatabaseMetaData.class.getDeclaredMethod("supportsSubqueriesInComparisons", new Class[0]);
      methodObject24779 = DatabaseMetaData.class.getDeclaredMethod("getMaxIndexLength", new Class[0]);
      methodObject24894 = DatabaseMetaData.class.getDeclaredMethod("supportsSubqueriesInQuantifieds", new Class[0]);
      methodObject24872 = DatabaseMetaData.class.getDeclaredMethod("supportsOpenStatementsAcrossCommit", new Class[0]);
      methodObject24843 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInTableDefinitions", new Class[0]);
      methodObject24821 = DatabaseMetaData.class.getDeclaredMethod("othersDeletesAreVisible", new Class[] { int.class });
      methodObject24857 = DatabaseMetaData.class.getDeclaredMethod("supportsGroupByBeyondSelect", new Class[0]);
      methodObject24888 = DatabaseMetaData.class.getDeclaredMethod("supportsStatementPooling", new Class[0]);
      methodObject24849 = DatabaseMetaData.class.getDeclaredMethod("supportsDataDefinitionAndDataManipulationTransactions", new Class[0]);
      methodObject24865 = DatabaseMetaData.class.getDeclaredMethod("supportsMultipleOpenResults", new Class[0]);
      methodObject24772 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnsInGroupBy", new Class[0]);
      methodObject24771 = DatabaseMetaData.class.getDeclaredMethod("getMaxColumnNameLength", new Class[0]);
      methodObject24784 = DatabaseMetaData.class.getDeclaredMethod("getMaxStatements", new Class[0]);
      methodObject24836 = DatabaseMetaData.class.getDeclaredMethod("supportsAlterTableWithAddColumn", new Class[0]);
      methodObject24858 = DatabaseMetaData.class.getDeclaredMethod("supportsGroupByUnrelated", new Class[0]);
      methodObject24833 = DatabaseMetaData.class.getDeclaredMethod("supportsANSI92EntryLevelSQL", new Class[0]);
      methodObject24862 = DatabaseMetaData.class.getDeclaredMethod("supportsMinimumSQLGrammar", new Class[0]);
      methodObject24770 = DatabaseMetaData.class.getDeclaredMethod("getMaxCharLiteralLength", new Class[0]);
      methodObject24827 = DatabaseMetaData.class.getDeclaredMethod("storesLowerCaseIdentifiers", new Class[0]);
      methodObject24866 = DatabaseMetaData.class.getDeclaredMethod("supportsMultipleResultSets", new Class[0]);
      methodObject24871 = DatabaseMetaData.class.getDeclaredMethod("supportsOpenCursorsAcrossRollback", new Class[0]);
      methodObject24900 = DatabaseMetaData.class.getDeclaredMethod("updatesAreDetected", new Class[] { int.class });
      methodObject24740 = DatabaseMetaData.class.getDeclaredMethod("deletesAreDetected", new Class[] { int.class });
      methodObject24887 = DatabaseMetaData.class.getDeclaredMethod("supportsSelectForUpdate", new Class[0]);
      methodObject24876 = DatabaseMetaData.class.getDeclaredMethod("supportsPositionedDelete", new Class[0]);
      methodObject24842 = DatabaseMetaData.class.getDeclaredMethod("supportsCatalogsInProcedureCalls", new Class[0]);
      methodObject24762 = DatabaseMetaData.class.getDeclaredMethod("getFunctions", new Class[] { String.class, String.class, String.class });
      methodObject24742 = DatabaseMetaData.class.getDeclaredMethod("getBestRowIdentifier", new Class[] { String.class, String.class, String.class, int.class, boolean.class });
      methodObject24743 = DatabaseMetaData.class.getDeclaredMethod("getCatalogSeparator", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1DatabaseMetaData$$$Proxy(DatabaseMetaData paramDatabaseMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramDatabaseMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1DatabaseMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */