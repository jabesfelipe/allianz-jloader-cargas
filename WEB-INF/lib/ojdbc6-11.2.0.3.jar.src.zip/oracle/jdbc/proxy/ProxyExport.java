/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyExport
/*     */ {
/*     */   public static void main(String[] paramArrayOfString) throws ClassNotFoundException, IOException {
/*  42 */     if (0 == paramArrayOfString.length) {
/*     */       
/*  44 */       System.out.println("Usage:");
/*  45 */       System.out.println("java -classpath ojdbc6.jar oracle.jdbc.proxy.ProxyExport [-d dir] class1 class2 class3 ...");
/*  46 */       System.out.println("  dir - directory to store exported proxy classes");
/*  47 */       System.out.println("  class1 class2 class3 ... - superclasses equipped with @ProxyFor annotation");
/*     */       
/*     */       return;
/*     */     } 
/*  51 */     byte b = 0;
/*  52 */     String str = "";
/*     */     
/*  54 */     if ("-d".equals(paramArrayOfString[0])) {
/*     */       
/*  56 */       if (paramArrayOfString.length < 2) {
/*     */         
/*  58 */         System.out.println("wrong directory");
/*     */         
/*     */         return;
/*     */       } 
/*  62 */       str = paramArrayOfString[1];
/*  63 */       b = 2;
/*     */       
/*  65 */       if (!(new File(str)).exists()) {
/*     */         
/*  67 */         System.out.println("target directory does not exist");
/*     */         
/*     */         return;
/*     */       } 
/*  71 */       if (0 != str.length() && !str.endsWith(File.separator)) {
/*  72 */         str = str + File.separator;
/*     */       }
/*     */     } 
/*  75 */     ArrayList<Class<?>> arrayList = new ArrayList();
/*  76 */     for (; b < paramArrayOfString.length; b++) {
/*  77 */       arrayList.add(Class.forName(paramArrayOfString[b]));
/*     */     }
/*  79 */     ProxyFactory proxyFactory = ProxyFactory.createProxyFactory((Class[])arrayList.<Class<?>[]>toArray((Class<?>[][])new Class[0]));
/*     */ 
/*     */     
/*  82 */     AnnotationsRegistry annotationsRegistry = proxyFactory.annotationsRegistry;
/*     */ 
/*     */     
/*  85 */     for (AnnotationsRegistry.Value value : annotationsRegistry.values()) {
/*     */       
/*  87 */       Class clazz = value.getSuperclass();
/*  88 */       for (Class clazz1 : value.getIfacesToProxy()) {
/*     */         
/*  90 */         GeneratedProxiesRegistry.Key key = new GeneratedProxiesRegistry.Key(clazz1, clazz);
/*     */ 
/*     */         
/*  93 */         byte[] arrayOfByte = ClassGenerator.generateBytecode(key, proxyFactory.annotationsRegistry);
/*     */ 
/*     */ 
/*     */         
/*  97 */         String str1 = key.makePathname();
/*     */         
/*  99 */         int i = str1.lastIndexOf(File.separator);
/* 100 */         if (-1 != i) {
/*     */           
/* 102 */           String str2 = str1.substring(0, i);
/* 103 */           (new File(str + str2)).mkdirs();
/*     */         } 
/*     */         
/* 106 */         BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(str + str1));
/*     */ 
/*     */ 
/*     */         
/* 110 */         bufferedOutputStream.write(arrayOfByte);
/* 111 */         bufferedOutputStream.close();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\ProxyExport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */