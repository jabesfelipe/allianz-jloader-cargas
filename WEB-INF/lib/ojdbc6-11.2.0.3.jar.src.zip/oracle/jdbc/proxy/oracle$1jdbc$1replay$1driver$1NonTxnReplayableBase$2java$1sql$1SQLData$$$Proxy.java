package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLData$$$Proxy extends NonTxnReplayableBase implements SQLData, _Proxy_ {
  private SQLData delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject24943;
  
  private static Method methodObject24945;
  
  private static Method methodObject24944;
  
  public String getSQLTypeName() throws SQLException {
    try {
      preForAll(methodObject24943, this, new Object[0]);
      return (String)postForAll(methodObject24943, this.proxyFactory.proxyFor(this.delegate.getSQLTypeName(), this, (Map)this.proxyCache, methodObject24943));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24943, onErrorForAll(methodObject24943, e));
    } 
  }
  
  public void writeSQL(SQLOutput arg0) throws SQLException {
    try {
      preForAll(methodObject24945, this, new Object[] { arg0 });
      this.delegate.writeSQL((arg0 instanceof _Proxy_) ? ((_Proxy_<SQLOutput>)arg0)._getDelegate_() : arg0);
      postForAll(methodObject24945);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject24945, e);
      return;
    } 
  }
  
  public void readSQL(SQLInput arg0, String arg1) throws SQLException {
    try {
      preForAll(methodObject24944, this, new Object[] { arg0, arg1 });
      this.delegate.readSQL((arg0 instanceof _Proxy_) ? ((_Proxy_<SQLInput>)arg0)._getDelegate_() : arg0, arg1);
      postForAll(methodObject24944);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject24944, e);
      return;
    } 
  }
  
  public SQLData _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(SQLData delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject24943 = SQLData.class.getDeclaredMethod("getSQLTypeName", new Class[0]);
      methodObject24945 = SQLData.class.getDeclaredMethod("writeSQL", new Class[] { SQLOutput.class });
      methodObject24944 = SQLData.class.getDeclaredMethod("readSQL", new Class[] { SQLInput.class, String.class });
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLData$$$Proxy(SQLData paramSQLData, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramSQLData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1SQLData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */