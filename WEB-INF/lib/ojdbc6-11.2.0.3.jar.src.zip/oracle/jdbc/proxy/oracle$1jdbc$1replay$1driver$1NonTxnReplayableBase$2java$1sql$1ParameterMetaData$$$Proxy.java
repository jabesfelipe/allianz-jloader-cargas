package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ParameterMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ParameterMetaData$$$Proxy extends NonTxnReplayableBase implements ParameterMetaData, _Proxy_ {
  private ParameterMetaData delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject24911;
  
  private static Method methodObject24906;
  
  private static Method methodObject24908;
  
  private static Method methodObject24905;
  
  private static Method methodObject24913;
  
  private static Method methodObject24907;
  
  private static Method methodObject24915;
  
  private static Method methodObject24912;
  
  private static Method methodObject24910;
  
  private static Method methodObject24909;
  
  private static Method methodObject24914;
  
  public int getScale(int arg0) throws SQLException {
    try {
      preForAll(methodObject24911, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24911, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, (Map)this.proxyCache, methodObject24911))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24911, onErrorForAll(methodObject24911, e))).intValue();
    } 
  }
  
  public int getParameterCount() throws SQLException {
    try {
      preForAll(methodObject24906, this, new Object[0]);
      return ((Integer)postForAll(methodObject24906, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterCount()), this, (Map)this.proxyCache, methodObject24906))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24906, onErrorForAll(methodObject24906, e))).intValue();
    } 
  }
  
  public int getParameterType(int arg0) throws SQLException {
    try {
      preForAll(methodObject24908, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24908, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterType(arg0)), this, (Map)this.proxyCache, methodObject24908))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24908, onErrorForAll(methodObject24908, e))).intValue();
    } 
  }
  
  public String getParameterClassName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24905, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24905, this.proxyFactory.proxyFor(this.delegate.getParameterClassName(arg0), this, (Map)this.proxyCache, methodObject24905));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24905, onErrorForAll(methodObject24905, e));
    } 
  }
  
  public boolean isSigned(int arg0) throws SQLException {
    try {
      preForAll(methodObject24913, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24913, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, (Map)this.proxyCache, methodObject24913))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24913, onErrorForAll(methodObject24913, e))).booleanValue();
    } 
  }
  
  public int getParameterMode(int arg0) throws SQLException {
    try {
      preForAll(methodObject24907, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24907, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getParameterMode(arg0)), this, (Map)this.proxyCache, methodObject24907))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24907, onErrorForAll(methodObject24907, e))).intValue();
    } 
  }
  
  public Object unwrap(Class<?> arg0) throws SQLException {
    return this.delegate.unwrap(arg0);
  }
  
  public int isNullable(int arg0) throws SQLException {
    try {
      preForAll(methodObject24912, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24912, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, (Map)this.proxyCache, methodObject24912))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24912, onErrorForAll(methodObject24912, e))).intValue();
    } 
  }
  
  public int getPrecision(int arg0) throws SQLException {
    try {
      preForAll(methodObject24910, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24910, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, (Map)this.proxyCache, methodObject24910))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24910, onErrorForAll(methodObject24910, e))).intValue();
    } 
  }
  
  public String getParameterTypeName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24909, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24909, this.proxyFactory.proxyFor(this.delegate.getParameterTypeName(arg0), this, (Map)this.proxyCache, methodObject24909));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24909, onErrorForAll(methodObject24909, e));
    } 
  }
  
  public boolean isWrapperFor(Class<?> arg0) throws SQLException {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public ParameterMetaData _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(ParameterMetaData delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject24911 = ParameterMetaData.class.getDeclaredMethod("getScale", new Class[] { int.class });
      methodObject24906 = ParameterMetaData.class.getDeclaredMethod("getParameterCount", new Class[0]);
      methodObject24908 = ParameterMetaData.class.getDeclaredMethod("getParameterType", new Class[] { int.class });
      methodObject24905 = ParameterMetaData.class.getDeclaredMethod("getParameterClassName", new Class[] { int.class });
      methodObject24913 = ParameterMetaData.class.getDeclaredMethod("isSigned", new Class[] { int.class });
      methodObject24907 = ParameterMetaData.class.getDeclaredMethod("getParameterMode", new Class[] { int.class });
      methodObject24915 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject24912 = ParameterMetaData.class.getDeclaredMethod("isNullable", new Class[] { int.class });
      methodObject24910 = ParameterMetaData.class.getDeclaredMethod("getPrecision", new Class[] { int.class });
      methodObject24909 = ParameterMetaData.class.getDeclaredMethod("getParameterTypeName", new Class[] { int.class });
      methodObject24914 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ParameterMetaData$$$Proxy(ParameterMetaData paramParameterMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramParameterMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ParameterMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */