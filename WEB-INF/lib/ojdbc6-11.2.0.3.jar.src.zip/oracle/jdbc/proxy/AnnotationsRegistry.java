/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import oracle.jdbc.proxy.annotation.GetCreator;
/*     */ import oracle.jdbc.proxy.annotation.GetDelegate;
/*     */ import oracle.jdbc.proxy.annotation.GetProxy;
/*     */ import oracle.jdbc.proxy.annotation.Methods;
/*     */ import oracle.jdbc.proxy.annotation.OnError;
/*     */ import oracle.jdbc.proxy.annotation.Post;
/*     */ import oracle.jdbc.proxy.annotation.Pre;
/*     */ import oracle.jdbc.proxy.annotation.ProxyFor;
/*     */ import oracle.jdbc.proxy.annotation.ProxyLocale;
/*     */ import oracle.jdbc.proxy.annotation.SetDelegate;
/*     */ import oracle.jdbc.proxy.annotation.Signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationsRegistry
/*     */ {
/*     */   private static class SyntaxError
/*     */     extends RuntimeException
/*     */   {
/*     */     SyntaxError(String param1String) {
/*  48 */       super(param1String);
/*     */     }
/*     */     
/*  51 */     private static final SyntaxError onlyOneAllowed = new SyntaxError("only one @Pre/@Post/@OnError/@GetDelegate/@SetDelegate/@GetCreator/@GetProxy allowed");
/*     */ 
/*     */     
/*  54 */     private static final SyntaxError onlyOneMethodslessAllowed = new SyntaxError("only one @Methods-less @Pre/@Post/@OnError allowed");
/*     */ 
/*     */     
/*  57 */     private static final SyntaxError wrongMethodsContext = new SyntaxError("wrong context for @Methods");
/*     */ 
/*     */     
/*  60 */     private static final SyntaxError wrongPre = new SyntaxError("wrong @Pre");
/*     */ 
/*     */     
/*  63 */     private static final SyntaxError wrongPost = new SyntaxError("wrong @Post");
/*     */ 
/*     */     
/*  66 */     private static final SyntaxError wrongOnError = new SyntaxError("wrong @OnError");
/*     */ 
/*     */     
/*  69 */     private static final SyntaxError onlyOneOnErrorExceptionTypeAllowed = new SyntaxError("only one @OnError Exception type allowed for a given method");
/*     */ 
/*     */     
/*  72 */     private static final SyntaxError wrongGetCreator = new SyntaxError("wrong @GetCreator");
/*     */ 
/*     */     
/*  75 */     private static final SyntaxError wrongGetCreatorMustBeProtected = new SyntaxError("wrong @GetCreator: must be protected");
/*     */ 
/*     */     
/*  78 */     private static final SyntaxError wrongGetCreatorMustBeAbstract = new SyntaxError("wrong @GetCreator: must be abstract");
/*     */ 
/*     */     
/*  81 */     private static final SyntaxError wrongGetDelegate = new SyntaxError("wrong @GetDelegate");
/*     */ 
/*     */     
/*  84 */     private static final SyntaxError wrongGetDelegateMustBeProtected = new SyntaxError("wrong @GetDelegate: must be protected");
/*     */ 
/*     */     
/*  87 */     private static final SyntaxError wrongGetDelegateMustBeAbstract = new SyntaxError("wrong @GetDelegate: must be abstract");
/*     */ 
/*     */     
/*  90 */     private static final SyntaxError wrongGetProxy = new SyntaxError("wrong @GetProxy");
/*     */ 
/*     */     
/*  93 */     private static final SyntaxError wrongGetProxyMustBeProtected = new SyntaxError("wrong @GetProxy: must be protected");
/*     */ 
/*     */     
/*  96 */     private static final SyntaxError wrongGetProxyMustBeAbstract = new SyntaxError("wrong @GetProxy: must be abstract");
/*     */ 
/*     */     
/*  99 */     private static final SyntaxError wrongSetDelegate = new SyntaxError("wrong @SetDelegate");
/*     */ 
/*     */     
/* 102 */     private static final SyntaxError wrongSetDelegateMustBeProtected = new SyntaxError("wrong @SetDelegate: must be protected");
/*     */ 
/*     */     
/* 105 */     private static final SyntaxError wrongSetDelegateMustBeAbstract = new SyntaxError("wrong @SetDelegate: must be abstract");
/*     */ 
/*     */     
/* 108 */     private static final SyntaxError emptyProxyForList = new SyntaxError("empty @ProxyFor list");
/*     */ 
/*     */ 
/*     */     
/*     */     private static SyntaxError mustBeClass(Class param1Class) {
/* 113 */       return new SyntaxError(param1Class.getName() + " must be an abstract or concrete class");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static SyntaxError mustBeIface(Class param1Class) {
/* 119 */       return new SyntaxError(param1Class.getName() + " must be an interface");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static SyntaxError annotationDefinedMoreThanOnce(String param1String) {
/* 125 */       return new SyntaxError(param1String + " is defined more than once for the same method");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static SyntaxError noProxyForClass(Class param1Class) {
/* 131 */       return new SyntaxError("no @ProxyFor for class " + param1Class.getName());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static SyntaxError returnTypeMismatch(Method param1Method1, Method param1Method2) {
/* 138 */       return new SyntaxError("interceptor " + param1Method1.getName() + " and interceptee " + param1Method2.getName() + ": have different return types (" + param1Method1.getReturnType().getName() + " and " + param1Method2.getReturnType().getName() + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   private Map<Class, Value> ifacesToAnnotatedSuperclasses = (Map)new HashMap<Class<?>, Value>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void register(Class... paramVarArgs) {
/* 155 */     for (Class clazz : paramVarArgs) {
/*     */       
/* 157 */       if (clazz.isInterface()) {
/* 158 */         throw SyntaxError.mustBeClass(clazz);
/*     */       }
/* 160 */       Value value = new Value(clazz);
/*     */       
/* 162 */       for (Class clazz1 : value.getIfacesToProxy()) {
/* 163 */         this.ifacesToAnnotatedSuperclasses.put(clazz1, value);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   Value get(Class paramClass) {
/* 169 */     return this.ifacesToAnnotatedSuperclasses.get(paramClass);
/*     */   }
/*     */ 
/*     */   
/*     */   Set<Class> keySet() {
/* 174 */     return this.ifacesToAnnotatedSuperclasses.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   Collection<Value> values() {
/* 179 */     return this.ifacesToAnnotatedSuperclasses.values();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean containsKey(Object paramObject) {
/* 184 */     return this.ifacesToAnnotatedSuperclasses.containsKey(paramObject);
/*     */   }
/*     */   
/*     */   static class Value {
/*     */     private final Class superclass;
/*     */     
/*     */     static final class Pres extends MethodSpecific<Method> {
/* 191 */       Pres() { super("@Pre"); }
/* 192 */     } static final class VoidPosts extends MethodSpecific<Method> { VoidPosts() { super("Void @Post"); } } static final class ReturningPosts extends MethodSpecific<Method> {
/* 193 */       ReturningPosts() { super("Returning @Post"); }
/* 194 */     } static final class VoidOnErrors extends MethodSpecific<Map<Class, Method>> { VoidOnErrors() { super("Void @OnError"); } } private static class MethodSpecific<T> { static final class Pres extends MethodSpecific<Method> { Pres() { super("@Pre"); } } static final class VoidPosts extends MethodSpecific<Method> { VoidPosts() { super("Void @Post"); } } static final class ReturningPosts extends MethodSpecific<Method> { ReturningPosts() { super("Returning @Post"); } } static final class VoidOnErrors extends MethodSpecific<Map<Class, Method>> { VoidOnErrors() { super("Void @OnError"); } } static final class ReturningOnErrors extends MethodSpecific<Map<Class, Method>> { ReturningOnErrors() {
/* 195 */           super("Returning @OnError");
/*     */         } }
/* 197 */       private final Map<MethodSignature, T> ref = new HashMap<MethodSignature, T>();
/*     */ 
/*     */       
/*     */       private final String annotationType;
/*     */ 
/*     */       
/*     */       private MethodSpecific(String param2String) {
/* 204 */         this.annotationType = param2String;
/*     */       }
/*     */ 
/*     */       
/*     */       void put(MethodSignature param2MethodSignature, T param2T) {
/* 209 */         if (null != this.ref.put(param2MethodSignature, param2T)) {
/* 210 */           throw AnnotationsRegistry.SyntaxError.annotationDefinedMoreThanOnce(this.annotationType);
/*     */         }
/*     */       }
/*     */       
/*     */       T get(MethodSignature param2MethodSignature) {
/* 215 */         return this.ref.get(param2MethodSignature);
/*     */       } }
/*     */ 
/*     */ 
/*     */     
/*     */     static final class ReturningOnErrors
/*     */       extends MethodSpecific<Map<Class, Method>>
/*     */     {
/*     */       ReturningOnErrors() {
/*     */         super("Returning @OnError");
/*     */       }
/*     */     }
/*     */     
/*     */     private static class Rest
/*     */     {
/*     */       private final Method pre;
/*     */       private final Method voidPost;
/*     */       private final Method returningPost;
/*     */       private final Map<Class, Method> voidOnErrorsMap;
/*     */       private final Map<Class, Method> returningOnErrorsMap;
/*     */       
/*     */       Rest(Method param2Method1, Method param2Method2, Method param2Method3, Map<Class, Method> param2Map1, Map<Class, Method> param2Map2) {
/* 237 */         this.pre = param2Method1;
/* 238 */         this.voidPost = param2Method2;
/* 239 */         this.returningPost = param2Method3;
/* 240 */         this.voidOnErrorsMap = param2Map1;
/* 241 */         this.returningOnErrorsMap = param2Map2;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       Method getPre() {
/* 249 */         return this.pre;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       Map<Class, Method> getReturningOnError() {
/* 257 */         return this.returningOnErrorsMap;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       Method getReturningPost() {
/* 265 */         return this.returningPost;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       Map<Class, Method> getVoidOnError() {
/* 273 */         return this.voidOnErrorsMap;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       Method getVoidPost() {
/* 281 */         return this.voidPost;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 286 */     private final List<Class> ifacesToProxy = (List)new ArrayList<Class<?>>();
/*     */     
/* 288 */     private final MethodSpecific.Pres pres = new MethodSpecific.Pres();
/* 289 */     private final MethodSpecific.VoidPosts voidPosts = new MethodSpecific.VoidPosts();
/* 290 */     private final MethodSpecific.ReturningPosts returningPosts = new MethodSpecific.ReturningPosts();
/* 291 */     private final MethodSpecific.VoidOnErrors voidOnErrors = new MethodSpecific.VoidOnErrors();
/* 292 */     private final MethodSpecific.ReturningOnErrors returningOnErrors = new MethodSpecific.ReturningOnErrors();
/*     */     
/*     */     private final Rest rest;
/*     */     
/* 296 */     private Method methodGetCreator = null;
/* 297 */     private Method methodGetDelegate = null;
/* 298 */     private Method methodGetProxy = null;
/* 299 */     private Method methodSetDelegate = null;
/*     */     private boolean isProxyLocale = false;
/*     */     private Method pre;
/*     */     private Method voidPost;
/*     */     private Method returningPost;
/*     */     private Map<Class, Method> voidOnErrorsMap;
/*     */     private Map<Class, Method> returningOnErrorsMap;
/*     */     
/*     */     Value(Class param1Class) {
/* 308 */       this.pre = null; this.voidPost = null; this.returningPost = null;
/* 309 */       this.voidOnErrorsMap = (Map)new HashMap<Class<?>, Method>(); this.returningOnErrorsMap = (Map)new HashMap<Class<?>, Method>();
/*     */       this.superclass = param1Class;
/*     */       this.rest = parseAnnotations();
/*     */     }
/*     */     
/*     */     private void parseAnnotationProxyLocale() {
/* 315 */       if (this.superclass.isAnnotationPresent((Class)ProxyLocale.class)) {
/* 316 */         this.isProxyLocale = true;
/*     */       }
/*     */     }
/*     */     
/*     */     private void parseAnnotationProxyFor() {
/* 321 */       if (this.superclass.isAnnotationPresent((Class)ProxyFor.class)) {
/*     */         
/* 323 */         ProxyFor proxyFor = (ProxyFor)this.superclass.getAnnotation(ProxyFor.class);
/* 324 */         boolean bool = true;
/*     */         
/* 326 */         for (Class clazz : proxyFor.value()) {
/*     */           
/* 328 */           if (!clazz.isInterface()) {
/* 329 */             throw AnnotationsRegistry.SyntaxError.mustBeIface(clazz);
/*     */           }
/* 331 */           this.ifacesToProxy.add(clazz);
/* 332 */           bool = false;
/*     */         } 
/*     */         
/* 335 */         if (bool) throw AnnotationsRegistry.SyntaxError.emptyProxyForList;
/*     */       
/*     */       } else {
/* 338 */         throw AnnotationsRegistry.SyntaxError.noProxyForClass(this.superclass);
/*     */       } 
/*     */     }
/* 341 */     private static final Class[] listOfMethodOperators = new Class[] { Pre.class, Post.class, OnError.class, GetCreator.class, GetDelegate.class, GetProxy.class, SetDelegate.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void checkIsSingle(Method param1Method, Class param1Class) {
/* 349 */       for (Class<? extends Annotation> clazz : listOfMethodOperators) {
/* 350 */         if (!clazz.equals(param1Class) && 
/* 351 */           param1Method.isAnnotationPresent(clazz))
/* 352 */           throw AnnotationsRegistry.SyntaxError.onlyOneAllowed; 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void parseAnnotationPre(Method param1Method) {
/* 357 */       if (param1Method.isAnnotationPresent((Class)Pre.class)) {
/*     */         
/* 359 */         checkIsSingle(param1Method, Pre.class);
/*     */         
/* 361 */         if (!Arrays.deepEquals((Object[])new Class[0], (Object[])param1Method.getExceptionTypes()))
/*     */         {
/*     */           
/* 364 */           throw AnnotationsRegistry.SyntaxError.wrongPre;
/*     */         }
/* 366 */         if (!Arrays.deepEquals((Object[])new Class[] { Method.class, Object.class, Object[].class }, (Object[])param1Method.getParameterTypes()))
/*     */         {
/*     */           
/* 369 */           throw AnnotationsRegistry.SyntaxError.wrongPre;
/*     */         }
/* 371 */         if (!void.class.equals(param1Method.getReturnType())) {
/* 372 */           throw AnnotationsRegistry.SyntaxError.wrongPre;
/*     */         }
/* 374 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 375 */           for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/* 376 */             this.pres.put(new MethodSignature(signature.name(), signature.args(), null), param1Method);
/*     */           }
/*     */         } else {
/* 379 */           if (null != this.pre) throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed; 
/* 380 */           this.pre = param1Method;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private Class doAutoBoxing(Class param1Class) {
/* 387 */       if (boolean.class.equals(param1Class)) {
/* 388 */         return Boolean.class;
/*     */       }
/* 390 */       if (char.class.equals(param1Class)) {
/* 391 */         return Character.class;
/*     */       }
/* 393 */       if (byte.class.equals(param1Class)) {
/* 394 */         return Byte.class;
/*     */       }
/* 396 */       if (short.class.equals(param1Class)) {
/* 397 */         return Short.class;
/*     */       }
/* 399 */       if (int.class.equals(param1Class)) {
/* 400 */         return Integer.class;
/*     */       }
/* 402 */       if (long.class.equals(param1Class)) {
/* 403 */         return Long.class;
/*     */       }
/* 405 */       if (float.class.equals(param1Class)) {
/* 406 */         return Float.class;
/*     */       }
/* 408 */       if (double.class.equals(param1Class)) {
/* 409 */         return Double.class;
/*     */       }
/* 411 */       return param1Class;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void checkReturnTypesMismatch(MethodSignature param1MethodSignature, Method param1Method) {
/* 424 */       Method method = null;
/*     */       
/* 426 */       Class clazz = doAutoBoxing(param1Method.getReturnType());
/*     */ 
/*     */       
/* 429 */       for (Class clazz1 : getIfacesToProxy()) {
/*     */         
/*     */         try {
/* 432 */           method = clazz1.getDeclaredMethod(param1MethodSignature.getName(), param1MethodSignature.getParameterTypes());
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 437 */           Class clazz2 = doAutoBoxing(method.getReturnType());
/*     */ 
/*     */           
/* 440 */           if (void.class.equals(clazz2)) {
/*     */             continue;
/*     */           }
/* 443 */           clazz.asSubclass(clazz2);
/*     */         }
/* 445 */         catch (NoSuchMethodException noSuchMethodException) {
/*     */ 
/*     */         
/*     */         }
/* 449 */         catch (ClassCastException classCastException) {
/*     */           
/* 451 */           throw AnnotationsRegistry.SyntaxError.returnTypeMismatch(param1Method, method);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void checkReturnTypesMismatch(Method param1Method) {
/* 466 */       Class clazz = doAutoBoxing(param1Method.getReturnType());
/*     */ 
/*     */       
/* 469 */       for (Class clazz1 : getIfacesToProxy()) {
/* 470 */         for (Method method : clazz1.getDeclaredMethods()) {
/*     */           
/* 472 */           Class clazz2 = doAutoBoxing(method.getReturnType());
/*     */ 
/*     */           
/* 475 */           if (!void.class.equals(clazz2)) {
/*     */             
/*     */             try {
/*     */ 
/*     */               
/* 480 */               clazz2.asSubclass(clazz);
/*     */             }
/* 482 */             catch (ClassCastException classCastException) {
/*     */               
/* 484 */               throw AnnotationsRegistry.SyntaxError.returnTypeMismatch(param1Method, method);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void parseAnnotationPost(Method param1Method) {
/* 493 */       if (param1Method.isAnnotationPresent((Class)Post.class)) {
/*     */         
/* 495 */         checkIsSingle(param1Method, Post.class);
/*     */         
/* 497 */         Class<?> clazz = param1Method.getReturnType();
/* 498 */         Class[] arrayOfClass1 = param1Method.getParameterTypes();
/* 499 */         Class[] arrayOfClass2 = param1Method.getExceptionTypes();
/*     */         
/* 501 */         if (!Arrays.deepEquals((Object[])new Class[0], (Object[])arrayOfClass2)) {
/* 502 */           throw AnnotationsRegistry.SyntaxError.wrongPost;
/*     */         }
/* 504 */         if (void.class.equals(clazz) && Arrays.deepEquals((Object[])new Class[] { Method.class }, (Object[])arrayOfClass1)) {
/*     */ 
/*     */           
/* 507 */           if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 508 */             for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/* 509 */               this.voidPosts.put(new MethodSignature(signature.name(), signature.args(), null), param1Method);
/*     */             }
/*     */           } else {
/* 512 */             if (null != this.voidPost) throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed; 
/* 513 */             this.voidPost = param1Method;
/*     */           }
/*     */         
/* 516 */         } else if (!void.class.equals(clazz) && Arrays.deepEquals((Object[])new Class[] { Method.class, clazz }, (Object[])arrayOfClass1)) {
/*     */ 
/*     */           
/* 519 */           if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 520 */             for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/*     */               
/* 522 */               MethodSignature methodSignature = new MethodSignature(signature.name(), signature.args(), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 528 */               checkReturnTypesMismatch(methodSignature, param1Method);
/* 529 */               this.returningPosts.put(methodSignature, param1Method);
/*     */             } 
/*     */           } else {
/*     */             
/* 533 */             checkReturnTypesMismatch(param1Method);
/*     */             
/* 535 */             if (null != this.returningPost) throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed; 
/* 536 */             this.returningPost = param1Method;
/*     */           } 
/*     */         } else {
/*     */           
/* 540 */           throw AnnotationsRegistry.SyntaxError.wrongPost;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void parseAnnotationOnError(Method param1Method) {
/* 546 */       if (param1Method.isAnnotationPresent((Class)OnError.class)) {
/*     */         
/* 548 */         checkIsSingle(param1Method, OnError.class);
/*     */         
/* 550 */         Class<?> clazz = param1Method.getReturnType();
/* 551 */         Class[] arrayOfClass1 = param1Method.getParameterTypes();
/* 552 */         Class[] arrayOfClass2 = param1Method.getExceptionTypes();
/*     */         
/* 554 */         OnError onError = param1Method.<OnError>getAnnotation(OnError.class);
/* 555 */         Class clazz1 = onError.value();
/*     */         
/* 557 */         if (Arrays.deepEquals((Object[])new Class[] { Method.class, clazz1 }, (Object[])arrayOfClass1) && Arrays.deepEquals((Object[])new Class[] { clazz1 }, (Object[])arrayOfClass2) && void.class.equals(clazz)) {
/*     */ 
/*     */ 
/*     */           
/* 561 */           if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 562 */             for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/*     */               
/* 564 */               MethodSignature methodSignature = new MethodSignature(signature.name(), signature.args(), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 570 */               Map<Class, Method> map = this.voidOnErrors.get(methodSignature);
/* 571 */               if (null == map) {
/* 572 */                 this.voidOnErrors.put(methodSignature, map = (Map)new HashMap<Class<?>, Method>());
/*     */               }
/* 574 */               if (null != map.put(clazz1, param1Method)) {
/* 575 */                 throw AnnotationsRegistry.SyntaxError.onlyOneOnErrorExceptionTypeAllowed;
/*     */               }
/*     */             } 
/* 578 */           } else if (null != this.voidOnErrorsMap.put(clazz1, param1Method)) {
/* 579 */             throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed;
/*     */           } 
/* 581 */         } else if (Arrays.deepEquals((Object[])new Class[] { Method.class, clazz1 }, (Object[])arrayOfClass1) && Arrays.deepEquals((Object[])new Class[] { clazz1 }, (Object[])arrayOfClass2) && !void.class.equals(clazz)) {
/*     */ 
/*     */ 
/*     */           
/* 585 */           if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 586 */             for (Signature signature : ((Methods)param1Method.<Methods>getAnnotation(Methods.class)).signatures()) {
/*     */               
/* 588 */               MethodSignature methodSignature = new MethodSignature(signature.name(), signature.args(), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 594 */               checkReturnTypesMismatch(methodSignature, param1Method);
/*     */               
/* 596 */               Map<Class, Method> map = this.returningOnErrors.get(methodSignature);
/* 597 */               if (null == map) {
/* 598 */                 this.returningOnErrors.put(methodSignature, map = (Map)new HashMap<Class<?>, Method>());
/*     */               }
/* 600 */               if (null != map.put(clazz1, param1Method)) {
/* 601 */                 throw AnnotationsRegistry.SyntaxError.onlyOneOnErrorExceptionTypeAllowed;
/*     */               }
/*     */             } 
/*     */           } else {
/* 605 */             checkReturnTypesMismatch(param1Method);
/*     */             
/* 607 */             if (null != this.returningOnErrorsMap.put(clazz1, param1Method)) {
/* 608 */               throw AnnotationsRegistry.SyntaxError.onlyOneMethodslessAllowed;
/*     */             }
/*     */           } 
/*     */         } else {
/* 612 */           throw AnnotationsRegistry.SyntaxError.wrongOnError;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void parseAnnotationGetCreator(Method param1Method) {
/* 618 */       if (param1Method.isAnnotationPresent((Class)GetCreator.class)) {
/*     */         
/* 620 */         checkIsSingle(param1Method, GetCreator.class);
/*     */         
/* 622 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 623 */           throw AnnotationsRegistry.SyntaxError.wrongMethodsContext;
/*     */         }
/* 625 */         int i = param1Method.getModifiers();
/*     */         
/* 627 */         if (!Modifier.isProtected(i)) {
/* 628 */           throw AnnotationsRegistry.SyntaxError.wrongGetCreatorMustBeProtected;
/*     */         }
/* 630 */         if (!Modifier.isAbstract(i)) {
/* 631 */           throw AnnotationsRegistry.SyntaxError.wrongGetCreatorMustBeAbstract;
/*     */         }
/* 633 */         if (!Arrays.deepEquals((Object[])new Class[0], (Object[])param1Method.getParameterTypes())) {
/* 634 */           throw AnnotationsRegistry.SyntaxError.wrongGetCreator;
/*     */         }
/* 636 */         if (!Object.class.equals(param1Method.getReturnType())) {
/* 637 */           throw AnnotationsRegistry.SyntaxError.wrongGetCreator;
/*     */         }
/* 639 */         this.methodGetCreator = param1Method;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void parseAnnotationGetProxy(Method param1Method) {
/* 645 */       if (param1Method.isAnnotationPresent((Class)GetProxy.class)) {
/*     */         
/* 647 */         checkIsSingle(param1Method, GetProxy.class);
/*     */         
/* 649 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 650 */           throw AnnotationsRegistry.SyntaxError.wrongMethodsContext;
/*     */         }
/* 652 */         int i = param1Method.getModifiers();
/*     */         
/* 654 */         if (!Modifier.isProtected(i)) {
/* 655 */           throw AnnotationsRegistry.SyntaxError.wrongGetProxyMustBeProtected;
/*     */         }
/* 657 */         if (!Modifier.isAbstract(i)) {
/* 658 */           throw AnnotationsRegistry.SyntaxError.wrongGetProxyMustBeAbstract;
/*     */         }
/* 660 */         if (!Arrays.deepEquals((Object[])new Class[] { Object.class, Object.class }, (Object[])param1Method.getParameterTypes()))
/*     */         {
/*     */           
/* 663 */           throw AnnotationsRegistry.SyntaxError.wrongGetProxy;
/*     */         }
/* 665 */         if (!Object.class.equals(param1Method.getReturnType())) {
/* 666 */           throw AnnotationsRegistry.SyntaxError.wrongGetProxy;
/*     */         }
/* 668 */         this.methodGetProxy = param1Method;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void parseAnnotationGetDelegate(Method param1Method) {
/* 674 */       if (param1Method.isAnnotationPresent((Class)GetDelegate.class)) {
/*     */         
/* 676 */         checkIsSingle(param1Method, GetDelegate.class);
/*     */         
/* 678 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 679 */           throw AnnotationsRegistry.SyntaxError.wrongMethodsContext;
/*     */         }
/* 681 */         int i = param1Method.getModifiers();
/*     */         
/* 683 */         if (!Modifier.isProtected(i)) {
/* 684 */           throw AnnotationsRegistry.SyntaxError.wrongGetDelegateMustBeProtected;
/*     */         }
/* 686 */         if (!Modifier.isAbstract(i)) {
/* 687 */           throw AnnotationsRegistry.SyntaxError.wrongGetDelegateMustBeAbstract;
/*     */         }
/* 689 */         if (!Arrays.deepEquals((Object[])new Class[0], (Object[])param1Method.getParameterTypes())) {
/* 690 */           throw AnnotationsRegistry.SyntaxError.wrongGetDelegate;
/*     */         }
/* 692 */         if (void.class.equals(param1Method.getReturnType())) {
/* 693 */           throw AnnotationsRegistry.SyntaxError.wrongGetDelegate;
/*     */         }
/* 695 */         this.methodGetDelegate = param1Method;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void parseAnnotationSetDelegate(Method param1Method) {
/* 701 */       if (param1Method.isAnnotationPresent((Class)SetDelegate.class)) {
/*     */         
/* 703 */         checkIsSingle(param1Method, SetDelegate.class);
/*     */         
/* 705 */         if (param1Method.isAnnotationPresent((Class)Methods.class)) {
/* 706 */           throw AnnotationsRegistry.SyntaxError.wrongMethodsContext;
/*     */         }
/* 708 */         int i = param1Method.getModifiers();
/*     */         
/* 710 */         if (!Modifier.isProtected(i)) {
/* 711 */           throw AnnotationsRegistry.SyntaxError.wrongSetDelegateMustBeProtected;
/*     */         }
/* 713 */         if (!Modifier.isAbstract(i)) {
/* 714 */           throw AnnotationsRegistry.SyntaxError.wrongSetDelegateMustBeAbstract;
/*     */         }
/* 716 */         if (1 != (param1Method.getParameterTypes()).length) {
/* 717 */           throw AnnotationsRegistry.SyntaxError.wrongSetDelegate;
/*     */         }
/* 719 */         if (!void.class.equals(param1Method.getReturnType())) {
/* 720 */           throw AnnotationsRegistry.SyntaxError.wrongSetDelegate;
/*     */         }
/* 722 */         this.methodSetDelegate = param1Method;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private Rest parseAnnotations() {
/* 728 */       parseAnnotationProxyFor();
/* 729 */       parseAnnotationProxyLocale();
/*     */       
/* 731 */       for (Method method : this.superclass.getDeclaredMethods()) {
/*     */         
/* 733 */         parseAnnotationPre(method);
/* 734 */         parseAnnotationPost(method);
/* 735 */         parseAnnotationOnError(method);
/* 736 */         parseAnnotationGetCreator(method);
/* 737 */         parseAnnotationGetProxy(method);
/* 738 */         parseAnnotationGetDelegate(method);
/* 739 */         parseAnnotationSetDelegate(method);
/*     */       } 
/*     */       
/* 742 */       return new Rest(this.pre, this.voidPost, this.returningPost, this.voidOnErrorsMap, this.returningOnErrorsMap);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean belongsToIfaceToProxy(Class param1Class, MethodSignature param1MethodSignature) {
/* 757 */       for (Class clazz : this.ifacesToProxy) {
/*     */ 
/*     */         
/* 760 */         try { param1Class.asSubclass(clazz);
/*     */           
/* 762 */           if (null != clazz.getDeclaredMethod(param1MethodSignature.getName(), param1MethodSignature.getParameterTypes()))
/*     */           {
/*     */             
/* 765 */             return true;
/*     */           } }
/* 767 */         catch (NoSuchMethodException noSuchMethodException) {  }
/* 768 */         catch (ClassCastException classCastException) {}
/*     */       } 
/* 770 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getMethodPre(Class param1Class, MethodSignature param1MethodSignature) {
/* 786 */       Method method = this.pres.get(param1MethodSignature);
/*     */ 
/*     */       
/* 789 */       if (null != method) {
/* 790 */         return method;
/*     */       }
/* 792 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getPre() : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getMethodVoidPost(Class param1Class, MethodSignature param1MethodSignature) {
/* 810 */       Method method = this.voidPosts.get(param1MethodSignature);
/*     */ 
/*     */       
/* 813 */       if (null != method) {
/* 814 */         return method;
/*     */       }
/* 816 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getVoidPost() : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getMethodReturningPost(Class param1Class, MethodSignature param1MethodSignature) {
/* 834 */       Method method = this.returningPosts.get(param1MethodSignature);
/*     */ 
/*     */       
/* 837 */       if (null != method) {
/* 838 */         return method;
/*     */       }
/* 840 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getReturningPost() : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Map<Class, Method> getMapVoidOnError(Class param1Class, MethodSignature param1MethodSignature) {
/* 858 */       Map<Class, Method> map = this.voidOnErrors.get(param1MethodSignature);
/*     */ 
/*     */       
/* 861 */       if (null != map) {
/* 862 */         return map;
/*     */       }
/* 864 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getVoidOnError() : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Map<Class, Method> getMapReturningOnError(Class param1Class, MethodSignature param1MethodSignature) {
/* 882 */       Map<Class, Method> map = this.returningOnErrors.get(param1MethodSignature);
/*     */ 
/*     */       
/* 885 */       if (null != map) {
/* 886 */         return map;
/*     */       }
/* 888 */       return belongsToIfaceToProxy(param1Class, param1MethodSignature) ? this.rest.getReturningOnError() : null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getMethodGetCreator() {
/* 898 */       return this.methodGetCreator;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getMethodGetDelegate() {
/* 906 */       return this.methodGetDelegate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getMethodGetProxy() {
/* 914 */       return this.methodGetProxy;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method getMethodSetDelegate() {
/* 922 */       return this.methodSetDelegate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     List<Class> getIfacesToProxy() {
/* 930 */       return this.ifacesToProxy;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Class getSuperclass() {
/* 938 */       return this.superclass;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isProxyLocale() {
/* 946 */       return this.isProxyLocale;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\AnnotationsRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */