package oracle.jdbc.proxy;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;
import oracle.jdbc.OracleResultSetCache;
import oracle.jdbc.internal.OracleResultSetCache;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetCache$$$Proxy extends NonTxnReplayableBase implements OracleResultSetCache, _Proxy_ {
  private OracleResultSetCache delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25100;
  
  private static Method methodObject25099;
  
  private static Method methodObject25101;
  
  private static Method methodObject25097;
  
  private static Method methodObject25098;
  
  private static Method methodObject25102;
  
  public void remove(int arg0) throws IOException {
    preForAll(methodObject25100, this, new Object[] { Integer.valueOf(arg0) });
    this.delegate.remove(arg0);
    postForAll(methodObject25100);
  }
  
  public Object get(int arg0, int arg1) throws IOException {
    preForAll(methodObject25099, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
    return postForAll(methodObject25099, this.proxyFactory.proxyFor(this.delegate.get(arg0, arg1), this, (Map)this.proxyCache, methodObject25099));
  }
  
  public void remove(int arg0, int arg1) throws IOException {
    preForAll(methodObject25101, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1) });
    this.delegate.remove(arg0, arg1);
    postForAll(methodObject25101);
  }
  
  public void put(int arg0, int arg1, Object arg2) throws IOException {
    preForAll(methodObject25097, this, new Object[] { Integer.valueOf(arg0), Integer.valueOf(arg1), arg2 });
    this.delegate.put(arg0, arg1, (arg2 instanceof _Proxy_) ? ((_Proxy_)arg2)._getDelegate_() : arg2);
    postForAll(methodObject25097);
  }
  
  public void clear() throws IOException {
    preForAll(methodObject25098, this, new Object[0]);
    this.delegate.clear();
    postForAll(methodObject25098);
  }
  
  public void close() throws IOException {
    preForAll(methodObject25102, this, new Object[0]);
    this.delegate.close();
    postForAll(methodObject25102);
  }
  
  public OracleResultSetCache _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleResultSetCache delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25100 = OracleResultSetCache.class.getDeclaredMethod("remove", new Class[] { int.class });
      methodObject25099 = OracleResultSetCache.class.getDeclaredMethod("get", new Class[] { int.class, int.class });
      methodObject25101 = OracleResultSetCache.class.getDeclaredMethod("remove", new Class[] { int.class, int.class });
      methodObject25097 = OracleResultSetCache.class.getDeclaredMethod("put", new Class[] { int.class, int.class, Object.class });
      methodObject25098 = OracleResultSetCache.class.getDeclaredMethod("clear", new Class[0]);
      methodObject25102 = OracleResultSetCache.class.getDeclaredMethod("close", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetCache$$$Proxy(OracleResultSetCache paramOracleResultSetCache, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleResultSetCache;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetCache$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */