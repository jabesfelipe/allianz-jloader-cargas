/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.objectweb.asm.ClassWriter;
/*     */ import org.objectweb.asm.Label;
/*     */ import org.objectweb.asm.MethodVisitor;
/*     */ import org.objectweb.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MethodGenerator
/*     */ {
/*  64 */   private static long ids = 0L;
/*  65 */   private final String methodObject = "methodObject" + ids++;
/*     */ 
/*     */   
/*     */   private final String proxyName;
/*     */ 
/*     */   
/*     */   private final String ifaceName;
/*     */ 
/*     */   
/*     */   private final String superclassName;
/*     */ 
/*     */   
/*     */   private final String proxyType;
/*     */   
/*     */   private final String ifaceType;
/*     */   
/*     */   private final Method method;
/*     */   
/*     */   private final ClassGenerator.AnnotationsForIface annotationsForIface;
/*     */   
/*     */   private final boolean callDelegate;
/*     */   
/*     */   private final boolean returns;
/*     */   
/*     */   private final Class[] parameterTypes;
/*     */   
/*     */   private final Class[] exceptionTypes;
/*     */   
/*     */   private final Class returnType;
/*     */   
/*     */   private final String methodName;
/*     */   
/*     */   private final String signature;
/*     */   
/*     */   private final String[] throwables;
/*     */   
/*     */   private final List<Class> exceptionsToCatch;
/*     */ 
/*     */   
/*     */   String getMethodObject() {
/* 105 */     return this.methodObject;
/*     */   }
/*     */   
/* 108 */   MethodGenerator(ClassGenerator paramClassGenerator, Method paramMethod, boolean paramBoolean) { this.exceptionsToCatch = new ReadOnlyList<Class>()
/*     */       {
/*     */         
/*     */         public Class get(int param1Int)
/*     */         {
/* 113 */           return (0 == param1Int) ? RuntimeException.class : MethodGenerator.this.exceptionTypes[param1Int - 1];
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int size() {
/* 120 */           return MethodGenerator.this.exceptionTypes.length + 1; } }; this.proxyName = paramClassGenerator.getProxyName(); this.ifaceName = paramClassGenerator.getIfaceName(); this.superclassName = paramClassGenerator.getSuperclassName(); this.ifaceType = paramClassGenerator.getIfaceType(); this.proxyType = paramClassGenerator.getProxyType(); this.method = paramMethod; this.annotationsForIface = paramClassGenerator.getAnnotationsForIface(); this.callDelegate = paramBoolean; this.parameterTypes = paramMethod.getParameterTypes();
/*     */     this.exceptionTypes = paramMethod.getExceptionTypes();
/*     */     this.returnType = paramMethod.getReturnType();
/*     */     this.returns = !"void".equals(this.returnType.getName());
/*     */     this.methodName = paramMethod.getName();
/*     */     this.signature = Utils.makeSignature(this.parameterTypes, this.returnType);
/* 126 */     this.throwables = Utils.makeThrowables(this.exceptionTypes); } private Method getMethodPre() { AnnotationsRegistry.Value value = this.annotationsForIface.getValue();
/*     */ 
/*     */     
/* 129 */     if (null == value) {
/* 130 */       return null;
/*     */     }
/* 132 */     return value.getMethodPre(this.annotationsForIface.getIface(), new MethodSignature(this.method)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMethodToProxy() {
/* 139 */     AnnotationsRegistry.Value value = this.annotationsForIface.getValue();
/*     */ 
/*     */     
/* 142 */     if (null == value) {
/* 143 */       return false;
/*     */     }
/* 145 */     return value.belongsToIfaceToProxy(this.annotationsForIface.getIface(), new MethodSignature(this.method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMethodPreDefined() {
/* 152 */     return (null != getMethodPre());
/*     */   }
/*     */ 
/*     */   
/*     */   private Method getMethodVoidPost() {
/* 157 */     AnnotationsRegistry.Value value = this.annotationsForIface.getValue();
/*     */ 
/*     */     
/* 160 */     if (null == value) {
/* 161 */       return null;
/*     */     }
/* 163 */     return value.getMethodVoidPost(this.annotationsForIface.getIface(), new MethodSignature(this.method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMethodVoidPostDefined() {
/* 170 */     return (null != getMethodVoidPost());
/*     */   }
/*     */ 
/*     */   
/*     */   private Method getMethodReturningPost() {
/* 175 */     AnnotationsRegistry.Value value = this.annotationsForIface.getValue();
/*     */ 
/*     */     
/* 178 */     if (null == value) {
/* 179 */       return null;
/*     */     }
/* 181 */     return value.getMethodReturningPost(this.annotationsForIface.getIface(), new MethodSignature(this.method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMethodReturningPostDefined() {
/* 188 */     return (null != getMethodReturningPost());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getMethodVoidOnError(Class paramClass) {
/* 194 */     AnnotationsRegistry.Value value = this.annotationsForIface.getValue();
/*     */ 
/*     */     
/* 197 */     if (null == value) {
/* 198 */       return null;
/*     */     }
/* 200 */     Map<Class, Method> map = value.getMapVoidOnError(this.annotationsForIface.getIface(), new MethodSignature(this.method));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     if (null == map) {
/* 206 */       return null;
/*     */     }
/* 208 */     return map.get(paramClass);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isMethodVoidOnErrorDefined() {
/* 213 */     boolean bool = false;
/*     */     
/* 215 */     for (Class clazz : this.exceptionsToCatch) {
/* 216 */       if (null != getMethodVoidOnError(clazz))
/* 217 */         bool = true; 
/*     */     } 
/* 219 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getMethodReturningOnError(Class paramClass) {
/* 225 */     AnnotationsRegistry.Value value = this.annotationsForIface.getValue();
/*     */ 
/*     */     
/* 228 */     if (null == value) {
/* 229 */       return null;
/*     */     }
/* 231 */     Map<Class, Method> map = value.getMapReturningOnError(this.annotationsForIface.getIface(), new MethodSignature(this.method));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     if (null == map) {
/* 237 */       return null;
/*     */     }
/* 239 */     return map.get(paramClass);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isMethodReturningOnErrorDefined() {
/* 244 */     boolean bool = false;
/*     */     
/* 246 */     for (Class clazz : this.exceptionsToCatch) {
/* 247 */       if (null != getMethodReturningOnError(clazz))
/* 248 */         bool = true; 
/*     */     } 
/* 250 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isMethodOnErrorDefined() {
/* 255 */     return this.returns ? isMethodReturningOnErrorDefined() : isMethodVoidOnErrorDefined();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMethodPostDefined() {
/* 262 */     return this.returns ? isMethodReturningPostDefined() : isMethodVoidPostDefined();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final Method getMethodPost() {
/* 268 */     return this.returns ? getMethodReturningPost() : getMethodVoidPost();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isAnyInterceptorDefined() {
/* 275 */     return (isMethodPreDefined() || isMethodVoidPostDefined() || isMethodReturningPostDefined() || isMethodVoidOnErrorDefined() || isMethodReturningOnErrorDefined());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void generate(ClassWriter paramClassWriter) {
/*     */     Object object1, object2, object3;
/* 318 */     MethodVisitor methodVisitor = paramClassWriter.visitMethod(this.method.isVarArgs() ? 129 : 1, this.methodName, this.signature, null, this.throwables);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 325 */     methodVisitor.visitCode();
/*     */     
/* 327 */     Label label1 = new Label();
/* 328 */     Label label2 = new Label();
/* 329 */     Label label3 = new Label();
/* 330 */     Label label4 = new Label();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 338 */     int j = 1;
/*     */     
/* 340 */     for (Class clazz : this.parameterTypes) {
/* 341 */       j += Utils.varSize(clazz);
/*     */     }
/* 343 */     int i = j;
/*     */ 
/*     */ 
/*     */     
/* 347 */     if (isMethodOnErrorDefined()) {
/*     */       
/* 349 */       j = this.exceptionsToCatch.size();
/* 350 */       object1 = new Label[j];
/*     */       
/* 352 */       for (byte b = 0; b < j; b++)
/*     */       {
/* 354 */         Class clazz = this.exceptionsToCatch.get(b);
/*     */         
/* 356 */         Method method = this.returns ? getMethodReturningOnError(clazz) : getMethodVoidOnError(clazz);
/*     */ 
/*     */ 
/*     */         
/* 360 */         if (null != method)
/*     */         {
/*     */           
/* 363 */           methodVisitor.visitTryCatchBlock(label3, label4, object1[b] = new Label(), Utils.makeSlashed(this.exceptionsToCatch.get(b)));
/*     */         
/*     */         }
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 371 */       object1 = null;
/*     */     } 
/* 373 */     methodVisitor.visitLabel(label1);
/* 374 */     methodVisitor.visitLabel(label3);
/*     */ 
/*     */     
/* 377 */     if (isMethodPreDefined()) {
/*     */       
/* 379 */       methodVisitor.visitVarInsn(25, 0);
/*     */       
/* 381 */       methodVisitor.visitFieldInsn(178, this.proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 387 */       methodVisitor.visitVarInsn(25, 0);
/*     */ 
/*     */       
/* 390 */       j = this.parameterTypes.length;
/*     */       
/* 392 */       if (this.method.isVarArgs() && 1 == j) {
/* 393 */         methodVisitor.visitVarInsn(25, 1);
/*     */       } else {
/*     */         
/* 396 */         Utils.loadConst(methodVisitor, j);
/* 397 */         methodVisitor.visitTypeInsn(189, "java/lang/Object"); int n;
/*     */         byte b;
/* 399 */         for (n = 1, b = 0; b < j; b++) {
/*     */           
/* 401 */           Class clazz = this.parameterTypes[b];
/*     */           
/* 403 */           methodVisitor.visitInsn(89);
/* 404 */           Utils.loadConst(methodVisitor, b);
/* 405 */           methodVisitor.visitVarInsn(Utils.loadOpcode(clazz), n);
/* 406 */           Utils.autoBox(methodVisitor, clazz);
/* 407 */           methodVisitor.visitInsn(83);
/* 408 */           n += Utils.varSize(clazz);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 413 */       methodVisitor.visitMethodInsn(183, this.superclassName, getMethodPre().getName(), "(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)V");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 430 */     if (isMethodPostDefined()) {
/*     */       
/* 432 */       methodVisitor.visitVarInsn(25, 0);
/*     */       
/* 434 */       methodVisitor.visitFieldInsn(178, this.proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 441 */     if (this.returns) {
/*     */       
/* 443 */       methodVisitor.visitVarInsn(25, 0);
/* 444 */       methodVisitor.visitFieldInsn(180, this.proxyName, "proxyFactory", Utils.makeType(ProxyFactory.class.getName()));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 451 */     methodVisitor.visitVarInsn(25, 0);
/*     */     
/* 453 */     if (this.callDelegate) {
/* 454 */       methodVisitor.visitFieldInsn(180, this.proxyName, "delegate", this.ifaceType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 460 */     loadDelegateParams(methodVisitor);
/*     */     
/* 462 */     methodVisitor.visitMethodInsn(this.callDelegate ? 185 : 183, this.callDelegate ? this.ifaceName : this.superclassName, this.methodName, this.signature);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 468 */     boolean bool = isMethodToProxy();
/*     */     
/* 470 */     if (this.returns && bool) {
/*     */       
/* 472 */       Utils.cast(methodVisitor, this.returnType, Object.class);
/*     */       
/* 474 */       methodVisitor.visitVarInsn(25, 0);
/*     */       
/* 476 */       methodVisitor.visitVarInsn(25, 0);
/* 477 */       methodVisitor.visitFieldInsn(180, this.proxyName, "proxyCache", "Ljava/util/Map;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 483 */       methodVisitor.visitFieldInsn(178, this.proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 489 */       methodVisitor.visitMethodInsn(182, Utils.makeSlashed(ProxyFactory.class.getName()), "proxyFor", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Map;Ljava/lang/reflect/Method;)Ljava/lang/Object;");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 496 */     if (isMethodPostDefined()) {
/*     */       
/* 498 */       if (this.returns) {
/* 499 */         Utils.cast(methodVisitor, bool ? Object.class : this.returnType, getMethodPost().getParameterTypes()[1]);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 504 */       methodVisitor.visitMethodInsn(182, this.superclassName, getMethodPost().getName(), "(Ljava/lang/reflect/Method;" + (this.returns ? Utils.makeType(getMethodPost().getParameterTypes()[1]) : "") + ")" + Utils.makeType(getMethodPost().getReturnType()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 512 */       if (this.returns) {
/* 513 */         Utils.cast(methodVisitor, getMethodPost().getReturnType(), this.returnType);
/*     */       }
/* 515 */     } else if (this.returns) {
/* 516 */       Utils.cast(methodVisitor, bool ? Object.class : this.returnType, this.returnType);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 521 */     methodVisitor.visitLabel(label4);
/* 522 */     methodVisitor.visitInsn(Utils.returnOpcode(this.returnType));
/*     */ 
/*     */     
/* 525 */     if (isMethodOnErrorDefined()) {
/*     */       
/* 527 */       int n = this.exceptionsToCatch.size();
/* 528 */       object2 = new Label[n];
/* 529 */       object3 = new Label[n];
/*     */       
/* 531 */       for (byte b = 0; b < n; b++) {
/*     */         
/* 533 */         Class clazz = this.exceptionsToCatch.get(b);
/*     */         
/* 535 */         Method method = this.returns ? getMethodReturningOnError(clazz) : getMethodVoidOnError(clazz);
/*     */ 
/*     */ 
/*     */         
/* 539 */         if (null != method) {
/*     */ 
/*     */           
/* 542 */           methodVisitor.visitLabel((Label)object1[b]);
/*     */           
/* 544 */           methodVisitor.visitFrame(4, 0, null, 1, new Object[] { Utils.makeSlashed(clazz) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 551 */           methodVisitor.visitVarInsn(58, i);
/*     */           
/* 553 */           methodVisitor.visitLabel(object2[b] = new Label());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 562 */           methodVisitor.visitVarInsn(25, 0);
/*     */           
/* 564 */           methodVisitor.visitFieldInsn(178, this.proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 570 */           if (this.returns && isMethodPostDefined()) {
/*     */             
/* 572 */             methodVisitor.visitVarInsn(25, 0);
/*     */             
/* 574 */             methodVisitor.visitFieldInsn(178, this.proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 581 */           methodVisitor.visitVarInsn(25, i);
/*     */           
/* 583 */           methodVisitor.visitMethodInsn(182, this.superclassName, method.getName(), "(Ljava/lang/reflect/Method;" + Utils.makeType(method.getParameterTypes()[1].getName()) + ")" + Utils.makeType(method.getReturnType().getName()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 591 */           if (this.returns && isMethodPostDefined()) {
/*     */             
/* 593 */             Utils.cast(methodVisitor, method.getReturnType(), getMethodPost().getParameterTypes()[1]);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 598 */             methodVisitor.visitMethodInsn(182, this.superclassName, getMethodPost().getName(), "(Ljava/lang/reflect/Method;" + Utils.makeType(getMethodPost().getParameterTypes()[1].getName()) + ")" + Utils.makeType(getMethodPost().getReturnType().getName()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 606 */             Utils.cast(methodVisitor, getMethodPost().getReturnType(), this.returnType);
/*     */           } else {
/*     */             
/* 609 */             Utils.cast(methodVisitor, method.getReturnType(), this.returnType);
/*     */           } 
/* 611 */           methodVisitor.visitInsn(Utils.returnOpcode(this.returnType));
/*     */           
/* 613 */           methodVisitor.visitLabel(object3[b] = new Label());
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 618 */       object2 = object3 = null;
/*     */     } 
/* 620 */     methodVisitor.visitLabel(label2);
/*     */ 
/*     */     
/* 623 */     int k = 0;
/*     */     
/* 625 */     methodVisitor.visitLocalVariable("this", this.proxyType, null, label1, label2, k++);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 633 */     int m = 0;
/* 634 */     for (; m < this.parameterTypes.length; 
/* 635 */       k += Utils.varSize(this.parameterTypes[m]), m++) {
/* 636 */       methodVisitor.visitLocalVariable("arg" + m, Utils.makeType(this.parameterTypes[m]), null, label1, label2, k);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 644 */     if (isMethodOnErrorDefined()) {
/*     */       
/* 646 */       if (i != k) {
/* 647 */         throw new RuntimeException("wrong exception index");
/*     */       }
/* 649 */       m = this.exceptionsToCatch.size();
/* 650 */       for (byte b = 0; b < m; b++) {
/*     */         
/* 652 */         Class clazz = this.exceptionsToCatch.get(b);
/*     */         
/* 654 */         Method method = this.returns ? getMethodReturningOnError(clazz) : getMethodVoidOnError(clazz);
/*     */ 
/*     */ 
/*     */         
/* 658 */         if (null != method)
/*     */         {
/*     */           
/* 661 */           methodVisitor.visitLocalVariable("e", Utils.makeType(this.exceptionsToCatch.get(b)), null, (Label)object2[b], (Label)object3[b], i);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 671 */     methodVisitor.visitMaxs(0, 0);
/* 672 */     methodVisitor.visitEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadDelegateParams(MethodVisitor paramMethodVisitor) {
/* 677 */     String str = Utils.makeSlashed(_Proxy_.class.getName());
/*     */     
/* 679 */     int i = 1; byte b = 0;
/* 680 */     for (; b < this.parameterTypes.length; 
/* 681 */       i += Utils.varSize(this.parameterTypes[b]), b++) {
/*     */       
/* 683 */       Class clazz = this.parameterTypes[b];
/* 684 */       String str1 = Utils.makeSlashed(clazz.getName());
/* 685 */       boolean bool = false;
/*     */       
/* 687 */       for (AnnotationsRegistry.Value value : this.annotationsForIface.getRegistry().values()) {
/* 688 */         for (Class<?> clazz1 : value.getIfacesToProxy()) {
/* 689 */           if (clazz.isAssignableFrom(clazz1))
/*     */           {
/* 691 */             bool = true;
/*     */           }
/*     */         } 
/*     */       } 
/* 695 */       if (bool) {
/*     */         
/* 697 */         paramMethodVisitor.visitVarInsn(Utils.loadOpcode(clazz), i);
/* 698 */         paramMethodVisitor.visitTypeInsn(193, str);
/* 699 */         Label label1 = new Label();
/* 700 */         paramMethodVisitor.visitJumpInsn(153, label1);
/* 701 */         paramMethodVisitor.visitVarInsn(Utils.loadOpcode(clazz), i);
/* 702 */         paramMethodVisitor.visitTypeInsn(192, str);
/* 703 */         paramMethodVisitor.visitMethodInsn(185, str, "_getDelegate_", "()Ljava/lang/Object;");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 708 */         paramMethodVisitor.visitTypeInsn(192, str1);
/* 709 */         Label label2 = new Label();
/* 710 */         paramMethodVisitor.visitJumpInsn(167, label2);
/* 711 */         paramMethodVisitor.visitLabel(label1);
/* 712 */         paramMethodVisitor.visitFrame(3, 0, null, 0, null);
/* 713 */         paramMethodVisitor.visitVarInsn(Utils.loadOpcode(clazz), i);
/* 714 */         paramMethodVisitor.visitLabel(label2);
/* 715 */         paramMethodVisitor.visitFrame(4, 0, null, 1, new Object[] { str1 });
/*     */       } else {
/*     */         
/* 718 */         paramMethodVisitor.visitVarInsn(Utils.loadOpcode(clazz), i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void initializeMethodObject(MethodVisitor paramMethodVisitor) {
/* 724 */     int i = this.parameterTypes.length;
/* 725 */     paramMethodVisitor.visitLdcInsn(Type.getType(Utils.makeType(this.method.getDeclaringClass().getName())));
/* 726 */     paramMethodVisitor.visitLdcInsn(this.methodName);
/* 727 */     Utils.loadConst(paramMethodVisitor, i);
/* 728 */     paramMethodVisitor.visitTypeInsn(189, "java/lang/Class");
/*     */     
/* 730 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 732 */       paramMethodVisitor.visitInsn(89);
/* 733 */       Utils.loadConst(paramMethodVisitor, b);
/* 734 */       Utils.loadClass(paramMethodVisitor, this.parameterTypes[b]);
/* 735 */       paramMethodVisitor.visitInsn(83);
/*     */     } 
/*     */     
/* 738 */     paramMethodVisitor.visitMethodInsn(182, "java/lang/Class", "getDeclaredMethod", "(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 744 */     paramMethodVisitor.visitFieldInsn(179, this.proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\MethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */