package oracle.jdbc.proxy;

public interface _Proxy_<T> {
  T _getDelegate_();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\_Proxy_.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */