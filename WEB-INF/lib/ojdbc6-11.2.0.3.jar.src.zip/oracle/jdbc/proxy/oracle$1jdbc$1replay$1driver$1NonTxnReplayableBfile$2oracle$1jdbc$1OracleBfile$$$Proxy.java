package oracle.jdbc.proxy;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.LargeObjectAccessMode;
import oracle.jdbc.OracleBfile;
import oracle.jdbc.replay.driver.NonTxnReplayableBfile;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1OracleBfile$$$Proxy extends NonTxnReplayableBfile implements OracleBfile, _Proxy_ {
  private OracleBfile delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject9515;
  
  private static Method methodObject9514;
  
  private static Method methodObject9519;
  
  private static Method methodObject9520;
  
  private static Method methodObject9523;
  
  private static Method methodObject9524;
  
  private static Method methodObject9525;
  
  private static Method methodObject9517;
  
  private static Method methodObject9526;
  
  private static Method methodObject9513;
  
  private static Method methodObject9512;
  
  private static Method methodObject9516;
  
  private static Method methodObject9511;
  
  private static Method methodObject9521;
  
  private static Method methodObject9518;
  
  private static Method methodObject9522;
  
  public long position(byte[] arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject9515, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject9515, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position(arg0, arg1)), this, (Map)this.proxyCache, methodObject9515))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject9515, onErrorForAll(methodObject9515, e))).longValue();
    } 
  }
  
  public long length() throws SQLException {
    try {
      preForAll(methodObject9514, this, new Object[0]);
      return ((Long)postForAll(methodObject9514, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.length()), this, (Map)this.proxyCache, methodObject9514))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject9514, onErrorForAll(methodObject9514, e))).longValue();
    } 
  }
  
  public boolean isOpen() throws SQLException {
    try {
      preForAll(methodObject9519, this, new Object[0]);
      return ((Boolean)postForAll(methodObject9519, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isOpen()), this, (Map)this.proxyCache, methodObject9519))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject9519, onErrorForAll(methodObject9519, e))).booleanValue();
    } 
  }
  
  public InputStream getBinaryStream() throws SQLException {
    try {
      preForAll(methodObject9520, this, new Object[0]);
      return (InputStream)postForAll(methodObject9520, this.proxyFactory.proxyFor(this.delegate.getBinaryStream(), this, (Map)this.proxyCache, methodObject9520));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject9520, onErrorForAll(methodObject9520, e));
    } 
  }
  
  public void openFile() throws SQLException {
    try {
      preForAll(methodObject9523, this, new Object[0]);
      this.delegate.openFile();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject9523, e);
      return;
    } 
  }
  
  public boolean isFileOpen() throws SQLException {
    try {
      preForAll(methodObject9524, this, new Object[0]);
      return ((Boolean)postForAll(methodObject9524, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isFileOpen()), this, (Map)this.proxyCache, methodObject9524))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject9524, onErrorForAll(methodObject9524, e))).booleanValue();
    } 
  }
  
  public boolean fileExists() throws SQLException {
    try {
      preForAll(methodObject9525, this, new Object[0]);
      return ((Boolean)postForAll(methodObject9525, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.fileExists()), this, (Map)this.proxyCache, methodObject9525))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject9525, onErrorForAll(methodObject9525, e))).booleanValue();
    } 
  }
  
  public void close() throws SQLException {
    try {
      preForAll(methodObject9517, this, new Object[0]);
      this.delegate.close();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject9517, e);
      return;
    } 
  }
  
  public void closeFile() throws SQLException {
    try {
      preForAll(methodObject9526, this, new Object[0]);
      this.delegate.closeFile();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject9526, e);
      return;
    } 
  }
  
  public int getBytes(long arg0, int arg1, byte[] arg2) throws SQLException {
    try {
      preForAll(methodObject9513, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return ((Integer)postForAll(methodObject9513, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBytes(arg0, arg1, arg2)), this, (Map)this.proxyCache, methodObject9513))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject9513, onErrorForAll(methodObject9513, e))).intValue();
    } 
  }
  
  public byte[] getBytes(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject9512, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (byte[])postForAll(methodObject9512, this.proxyFactory.proxyFor(this.delegate.getBytes(arg0, arg1), this, (Map)this.proxyCache, methodObject9512));
    } catch (SQLException e) {
      return (byte[])postForAll(methodObject9512, onErrorForAll(methodObject9512, e));
    } 
  }
  
  public long position(OracleBfile arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject9516, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject9516, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position((arg0 instanceof _Proxy_) ? ((_Proxy_<OracleBfile>)arg0)._getDelegate_() : arg0, arg1)), this, (Map)this.proxyCache, methodObject9516))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject9516, onErrorForAll(methodObject9516, e))).longValue();
    } 
  }
  
  public String getName() throws SQLException {
    try {
      preForAll(methodObject9511, this, new Object[0]);
      return (String)postForAll(methodObject9511, this.proxyFactory.proxyFor(this.delegate.getName(), this, (Map)this.proxyCache, methodObject9511));
    } catch (SQLException e) {
      return (String)postForAll(methodObject9511, onErrorForAll(methodObject9511, e));
    } 
  }
  
  public InputStream getBinaryStream(long arg0) throws SQLException {
    try {
      preForAll(methodObject9521, this, new Object[] { Long.valueOf(arg0) });
      return (InputStream)postForAll(methodObject9521, this.proxyFactory.proxyFor(this.delegate.getBinaryStream(arg0), this, (Map)this.proxyCache, methodObject9521));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject9521, onErrorForAll(methodObject9521, e));
    } 
  }
  
  public void open(LargeObjectAccessMode arg0) throws SQLException {
    try {
      preForAll(methodObject9518, this, new Object[] { arg0 });
      this.delegate.open(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject9518, e);
      return;
    } 
  }
  
  public String getDirAlias() throws SQLException {
    try {
      preForAll(methodObject9522, this, new Object[0]);
      return (String)postForAll(methodObject9522, this.proxyFactory.proxyFor(this.delegate.getDirAlias(), this, (Map)this.proxyCache, methodObject9522));
    } catch (SQLException e) {
      return (String)postForAll(methodObject9522, onErrorForAll(methodObject9522, e));
    } 
  }
  
  public OracleBfile _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleBfile delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject9515 = OracleBfile.class.getDeclaredMethod("position", new Class[] { byte[].class, long.class });
      methodObject9514 = OracleBfile.class.getDeclaredMethod("length", new Class[0]);
      methodObject9519 = OracleBfile.class.getDeclaredMethod("isOpen", new Class[0]);
      methodObject9520 = OracleBfile.class.getDeclaredMethod("getBinaryStream", new Class[0]);
      methodObject9523 = OracleBfile.class.getDeclaredMethod("openFile", new Class[0]);
      methodObject9524 = OracleBfile.class.getDeclaredMethod("isFileOpen", new Class[0]);
      methodObject9525 = OracleBfile.class.getDeclaredMethod("fileExists", new Class[0]);
      methodObject9517 = OracleBfile.class.getDeclaredMethod("close", new Class[0]);
      methodObject9526 = OracleBfile.class.getDeclaredMethod("closeFile", new Class[0]);
      methodObject9513 = OracleBfile.class.getDeclaredMethod("getBytes", new Class[] { long.class, int.class, byte[].class });
      methodObject9512 = OracleBfile.class.getDeclaredMethod("getBytes", new Class[] { long.class, int.class });
      methodObject9516 = OracleBfile.class.getDeclaredMethod("position", new Class[] { OracleBfile.class, long.class });
      methodObject9511 = OracleBfile.class.getDeclaredMethod("getName", new Class[0]);
      methodObject9521 = OracleBfile.class.getDeclaredMethod("getBinaryStream", new Class[] { long.class });
      methodObject9518 = OracleBfile.class.getDeclaredMethod("open", new Class[] { LargeObjectAccessMode.class });
      methodObject9522 = OracleBfile.class.getDeclaredMethod("getDirAlias", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1OracleBfile$$$Proxy(OracleBfile paramOracleBfile, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleBfile;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBfile$2oracle$1jdbc$1OracleBfile$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */