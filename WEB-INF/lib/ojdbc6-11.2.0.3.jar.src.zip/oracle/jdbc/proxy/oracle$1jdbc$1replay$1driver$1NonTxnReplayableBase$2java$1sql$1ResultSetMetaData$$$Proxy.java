package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ResultSetMetaData$$$Proxy extends NonTxnReplayableBase implements ResultSetMetaData, _Proxy_ {
  private ResultSetMetaData delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject24935;
  
  private static Method methodObject24928;
  
  private static Method methodObject24924;
  
  private static Method methodObject24927;
  
  private static Method methodObject24932;
  
  private static Method methodObject24938;
  
  private static Method methodObject24925;
  
  private static Method methodObject24934;
  
  private static Method methodObject24917;
  
  private static Method methodObject24936;
  
  private static Method methodObject24937;
  
  private static Method methodObject24930;
  
  private static Method methodObject24918;
  
  private static Method methodObject24916;
  
  private static Method methodObject24921;
  
  private static Method methodObject24933;
  
  private static Method methodObject24931;
  
  private static Method methodObject24920;
  
  private static Method methodObject24922;
  
  private static Method methodObject24919;
  
  private static Method methodObject24929;
  
  private static Method methodObject24926;
  
  private static Method methodObject24923;
  
  public boolean isSearchable(int arg0) throws SQLException {
    try {
      preForAll(methodObject24935, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24935, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSearchable(arg0)), this, (Map)this.proxyCache, methodObject24935))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24935, onErrorForAll(methodObject24935, e))).booleanValue();
    } 
  }
  
  public String getColumnTypeName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24928, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24928, this.proxyFactory.proxyFor(this.delegate.getColumnTypeName(arg0), this, (Map)this.proxyCache, methodObject24928));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24928, onErrorForAll(methodObject24928, e));
    } 
  }
  
  public int getColumnDisplaySize(int arg0) throws SQLException {
    try {
      preForAll(methodObject24924, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24924, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnDisplaySize(arg0)), this, (Map)this.proxyCache, methodObject24924))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24924, onErrorForAll(methodObject24924, e))).intValue();
    } 
  }
  
  public int getColumnType(int arg0) throws SQLException {
    try {
      preForAll(methodObject24927, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24927, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnType(arg0)), this, (Map)this.proxyCache, methodObject24927))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24927, onErrorForAll(methodObject24927, e))).intValue();
    } 
  }
  
  public boolean isCaseSensitive(int arg0) throws SQLException {
    try {
      preForAll(methodObject24932, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24932, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCaseSensitive(arg0)), this, (Map)this.proxyCache, methodObject24932))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24932, onErrorForAll(methodObject24932, e))).booleanValue();
    } 
  }
  
  public Object unwrap(Class<?> arg0) throws SQLException {
    return this.delegate.unwrap(arg0);
  }
  
  public String getColumnLabel(int arg0) throws SQLException {
    try {
      preForAll(methodObject24925, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24925, this.proxyFactory.proxyFor(this.delegate.getColumnLabel(arg0), this, (Map)this.proxyCache, methodObject24925));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24925, onErrorForAll(methodObject24925, e));
    } 
  }
  
  public boolean isDefinitelyWritable(int arg0) throws SQLException {
    try {
      preForAll(methodObject24934, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24934, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isDefinitelyWritable(arg0)), this, (Map)this.proxyCache, methodObject24934))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24934, onErrorForAll(methodObject24934, e))).booleanValue();
    } 
  }
  
  public int getPrecision(int arg0) throws SQLException {
    try {
      preForAll(methodObject24917, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24917, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, (Map)this.proxyCache, methodObject24917))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24917, onErrorForAll(methodObject24917, e))).intValue();
    } 
  }
  
  public boolean isWritable(int arg0) throws SQLException {
    try {
      preForAll(methodObject24936, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24936, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isWritable(arg0)), this, (Map)this.proxyCache, methodObject24936))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24936, onErrorForAll(methodObject24936, e))).booleanValue();
    } 
  }
  
  public boolean isWrapperFor(Class<?> arg0) throws SQLException {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public String getTableName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24930, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24930, this.proxyFactory.proxyFor(this.delegate.getTableName(arg0), this, (Map)this.proxyCache, methodObject24930));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24930, onErrorForAll(methodObject24930, e));
    } 
  }
  
  public int getScale(int arg0) throws SQLException {
    try {
      preForAll(methodObject24918, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24918, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, (Map)this.proxyCache, methodObject24918))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24918, onErrorForAll(methodObject24918, e))).intValue();
    } 
  }
  
  public boolean isReadOnly(int arg0) throws SQLException {
    try {
      preForAll(methodObject24916, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24916, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isReadOnly(arg0)), this, (Map)this.proxyCache, methodObject24916))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24916, onErrorForAll(methodObject24916, e))).booleanValue();
    } 
  }
  
  public String getCatalogName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24921, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24921, this.proxyFactory.proxyFor(this.delegate.getCatalogName(arg0), this, (Map)this.proxyCache, methodObject24921));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24921, onErrorForAll(methodObject24921, e));
    } 
  }
  
  public boolean isCurrency(int arg0) throws SQLException {
    try {
      preForAll(methodObject24933, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24933, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCurrency(arg0)), this, (Map)this.proxyCache, methodObject24933))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24933, onErrorForAll(methodObject24933, e))).booleanValue();
    } 
  }
  
  public boolean isAutoIncrement(int arg0) throws SQLException {
    try {
      preForAll(methodObject24931, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24931, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isAutoIncrement(arg0)), this, (Map)this.proxyCache, methodObject24931))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24931, onErrorForAll(methodObject24931, e))).booleanValue();
    } 
  }
  
  public boolean isSigned(int arg0) throws SQLException {
    try {
      preForAll(methodObject24920, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject24920, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, (Map)this.proxyCache, methodObject24920))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject24920, onErrorForAll(methodObject24920, e))).booleanValue();
    } 
  }
  
  public String getColumnClassName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24922, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24922, this.proxyFactory.proxyFor(this.delegate.getColumnClassName(arg0), this, (Map)this.proxyCache, methodObject24922));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24922, onErrorForAll(methodObject24922, e));
    } 
  }
  
  public int isNullable(int arg0) throws SQLException {
    try {
      preForAll(methodObject24919, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject24919, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, (Map)this.proxyCache, methodObject24919))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24919, onErrorForAll(methodObject24919, e))).intValue();
    } 
  }
  
  public String getSchemaName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24929, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24929, this.proxyFactory.proxyFor(this.delegate.getSchemaName(arg0), this, (Map)this.proxyCache, methodObject24929));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24929, onErrorForAll(methodObject24929, e));
    } 
  }
  
  public String getColumnName(int arg0) throws SQLException {
    try {
      preForAll(methodObject24926, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject24926, this.proxyFactory.proxyFor(this.delegate.getColumnName(arg0), this, (Map)this.proxyCache, methodObject24926));
    } catch (SQLException e) {
      return (String)postForAll(methodObject24926, onErrorForAll(methodObject24926, e));
    } 
  }
  
  public int getColumnCount() throws SQLException {
    try {
      preForAll(methodObject24923, this, new Object[0]);
      return ((Integer)postForAll(methodObject24923, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnCount()), this, (Map)this.proxyCache, methodObject24923))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject24923, onErrorForAll(methodObject24923, e))).intValue();
    } 
  }
  
  public ResultSetMetaData _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(ResultSetMetaData delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject24935 = ResultSetMetaData.class.getDeclaredMethod("isSearchable", new Class[] { int.class });
      methodObject24928 = ResultSetMetaData.class.getDeclaredMethod("getColumnTypeName", new Class[] { int.class });
      methodObject24924 = ResultSetMetaData.class.getDeclaredMethod("getColumnDisplaySize", new Class[] { int.class });
      methodObject24927 = ResultSetMetaData.class.getDeclaredMethod("getColumnType", new Class[] { int.class });
      methodObject24932 = ResultSetMetaData.class.getDeclaredMethod("isCaseSensitive", new Class[] { int.class });
      methodObject24938 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject24925 = ResultSetMetaData.class.getDeclaredMethod("getColumnLabel", new Class[] { int.class });
      methodObject24934 = ResultSetMetaData.class.getDeclaredMethod("isDefinitelyWritable", new Class[] { int.class });
      methodObject24917 = ResultSetMetaData.class.getDeclaredMethod("getPrecision", new Class[] { int.class });
      methodObject24936 = ResultSetMetaData.class.getDeclaredMethod("isWritable", new Class[] { int.class });
      methodObject24937 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject24930 = ResultSetMetaData.class.getDeclaredMethod("getTableName", new Class[] { int.class });
      methodObject24918 = ResultSetMetaData.class.getDeclaredMethod("getScale", new Class[] { int.class });
      methodObject24916 = ResultSetMetaData.class.getDeclaredMethod("isReadOnly", new Class[] { int.class });
      methodObject24921 = ResultSetMetaData.class.getDeclaredMethod("getCatalogName", new Class[] { int.class });
      methodObject24933 = ResultSetMetaData.class.getDeclaredMethod("isCurrency", new Class[] { int.class });
      methodObject24931 = ResultSetMetaData.class.getDeclaredMethod("isAutoIncrement", new Class[] { int.class });
      methodObject24920 = ResultSetMetaData.class.getDeclaredMethod("isSigned", new Class[] { int.class });
      methodObject24922 = ResultSetMetaData.class.getDeclaredMethod("getColumnClassName", new Class[] { int.class });
      methodObject24919 = ResultSetMetaData.class.getDeclaredMethod("isNullable", new Class[] { int.class });
      methodObject24929 = ResultSetMetaData.class.getDeclaredMethod("getSchemaName", new Class[] { int.class });
      methodObject24926 = ResultSetMetaData.class.getDeclaredMethod("getColumnName", new Class[] { int.class });
      methodObject24923 = ResultSetMetaData.class.getDeclaredMethod("getColumnCount", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ResultSetMetaData$$$Proxy(ResultSetMetaData paramResultSetMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramResultSetMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1ResultSetMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */