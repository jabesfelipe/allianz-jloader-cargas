/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyFactory
/*     */ {
/*  32 */   final AnnotationsRegistry annotationsRegistry = new AnnotationsRegistry();
/*  33 */   private final GeneratedProxiesRegistry generatedRegistry = new GeneratedProxiesRegistry();
/*  34 */   private Map<Class, Class> delegateClassToProxyClass = Collections.synchronizedMap(new HashMap<Class<?>, Class<?>>());
/*  35 */   private final Map<Object, WeakReference<Object>> delegateToProxy = Collections.synchronizedMap(new WeakIdentityHashMap<Object, WeakReference<Object>>());
/*  36 */   private Map<Class, Class> delegateToMostSuitableIface = (Map)new HashMap<Class<?>, Class<?>>();
/*     */   
/*  38 */   private static Object STALE_DELEGATE = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProxyFactory createProxyFactory(Class... paramVarArgs) {
/*  49 */     ProxyFactory proxyFactory = new ProxyFactory();
/*  50 */     proxyFactory.annotationsRegistry.register(paramVarArgs);
/*  51 */     return proxyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProxyFactory createJDBCProxyFactory(Class... paramVarArgs) {
/*  65 */     ProxyFactory proxyFactory = new ProxyFactory();
/*  66 */     proxyFactory.annotationsRegistry.register(new Class[] { NullProxy.class });
/*  67 */     proxyFactory.annotationsRegistry.register(paramVarArgs);
/*  68 */     return proxyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isProxied(Class paramClass) {
/*  78 */     return this.annotationsRegistry.containsKey(paramClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T proxyFor(T paramT) {
/*  90 */     return proxyFor(paramT, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T proxyFor(T paramT, Object paramObject) {
/* 104 */     return proxyFor(paramT, paramObject, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T proxyFor(T paramT, Object paramObject, Map<Object, WeakReference<Object>> paramMap, Method paramMethod) {
/* 137 */     if (null == paramT) {
/* 138 */       return null;
/*     */     }
/* 140 */     Class<?> clazz1 = paramT.getClass();
/* 141 */     Class<?> clazz2 = findMostSuitableIface(clazz1);
/*     */ 
/*     */     
/* 144 */     if (null != paramMethod && null != clazz2 && 
/* 145 */       !paramMethod.getReturnType().isAssignableFrom(clazz2)) {
/* 146 */       return paramT;
/*     */     }
/* 148 */     AnnotationsRegistry.Value value = this.annotationsRegistry.get(clazz2);
/* 149 */     if (null == value) {
/* 150 */       return paramT;
/*     */     }
/* 152 */     if (null == paramMap) {
/* 153 */       paramMap = value.isProxyLocale() ? new WeakIdentityHashMap<Object, WeakReference<Object>>() : this.delegateToProxy;
/*     */     }
/*     */ 
/*     */     
/* 157 */     WeakReference<Object> weakReference = paramMap.get(paramT);
/* 158 */     if (null != weakReference) {
/*     */       
/* 160 */       T t = (T)weakReference.get();
/* 161 */       if (null != t) {
/*     */         
/* 163 */         if (STALE_DELEGATE == t) {
/* 164 */           throw new RuntimeException("stale delegate");
/*     */         }
/* 166 */         return t;
/*     */       } 
/*     */     } 
/*     */     
/* 170 */     Class<Object> clazz = getProxyClass(clazz2, clazz1);
/* 171 */     if (null == clazz) {
/*     */       
/* 173 */       T t = (T)createProxy(clazz2, (Object)paramT, paramObject, paramMap);
/* 174 */       paramMap.put(paramT, new WeakReference(t));
/* 175 */       return t;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 180 */       T t = (T)clazz.getConstructor(new Class[] { clazz2, Object.class, ProxyFactory.class, Map.class }).newInstance(new Object[] { paramT, paramObject, this, paramMap });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 187 */       paramMap.put(paramT, new WeakReference(t));
/* 188 */       return t;
/*     */     }
/* 190 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       
/* 192 */       throw new RuntimeException(noSuchMethodException);
/*     */     }
/* 194 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 196 */       throw new RuntimeException(illegalAccessException);
/*     */     }
/* 198 */     catch (InvocationTargetException invocationTargetException) {
/*     */       
/* 200 */       throw new RuntimeException(invocationTargetException);
/*     */     }
/* 202 */     catch (InstantiationException instantiationException) {
/*     */       
/* 204 */       throw new RuntimeException(instantiationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void updateDelegate(Object paramObject, T paramT1, T paramT2) {
/* 227 */     this.delegateToProxy.put(paramT1, new WeakReference(STALE_DELEGATE));
/* 228 */     this.delegateToProxy.put(paramT2, new WeakReference(paramObject));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T createProxy(Class paramClass, T paramT, Object paramObject, Map<Object, WeakReference<Object>> paramMap) {
/* 244 */     if (null == paramClass) {
/* 245 */       return paramT;
/*     */     }
/* 247 */     AnnotationsRegistry.Value value = this.annotationsRegistry.get(paramClass);
/*     */     
/* 249 */     Class clazz = value.getSuperclass();
/*     */     
/* 251 */     GeneratedProxiesRegistry.Value value1 = this.generatedRegistry.get(paramClass, clazz);
/*     */ 
/*     */     
/* 254 */     Constructor<T> constructor = (null == value1) ? prepareProxy(paramClass, clazz) : value1.getConstructor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 261 */       return constructor.newInstance(new Object[] { paramT, paramObject, this, paramMap });
/*     */     }
/* 263 */     catch (InvocationTargetException invocationTargetException) {
/*     */       
/* 265 */       throw new RuntimeException(invocationTargetException.getTargetException());
/*     */     }
/* 267 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 269 */       throw new RuntimeException(illegalAccessException);
/*     */     }
/* 271 */     catch (InstantiationException instantiationException) {
/*     */       
/* 273 */       throw new RuntimeException(instantiationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Constructor prepareProxy(Class<?> paramClass1, Class paramClass2) {
/*     */     Constructor<?> constructor;
/* 281 */     Class<?> clazz = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 286 */       clazz = Class.forName((new GeneratedProxiesRegistry.Key(paramClass1, paramClass2)).toString());
/*     */     
/*     */     }
/* 289 */     catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */       
/* 292 */       clazz = ClassGenerator.generate(paramClass1, paramClass2, this.annotationsRegistry);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 302 */       constructor = clazz.getConstructor(new Class[] { paramClass1, Object.class, ProxyFactory.class, Map.class });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 308 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       
/* 310 */       throw new RuntimeException(noSuchMethodException);
/*     */     } 
/*     */     
/* 313 */     this.generatedRegistry.put(paramClass1, paramClass2, new GeneratedProxiesRegistry.Value(null, null, clazz, constructor));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     return constructor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class getProxyClass(Class paramClass1, Class<?> paramClass2) {
/* 327 */     if (null == paramClass2) {
/* 328 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 332 */     if (this.delegateClassToProxyClass.containsKey(paramClass2)) {
/* 333 */       return this.delegateClassToProxyClass.get(paramClass2);
/*     */     }
/*     */     
/* 336 */     if (null == paramClass1) {
/* 337 */       return null;
/*     */     }
/* 339 */     GeneratedProxiesRegistry.Value value = this.generatedRegistry.get(paramClass1, this.annotationsRegistry.get(paramClass1).getSuperclass());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 344 */     if (null == value) {
/* 345 */       return null;
/*     */     }
/* 347 */     Class<?> clazz = value.getClazz();
/*     */ 
/*     */     
/* 350 */     synchronized (this) {
/*     */ 
/*     */ 
/*     */       
/* 354 */       HashMap<Class<?>, Class<?>> hashMap = new HashMap<Class<?>, Class<?>>((Map)this.delegateClassToProxyClass);
/* 355 */       hashMap.put(paramClass2, clazz);
/* 356 */       this.delegateClassToProxyClass = (Map)hashMap;
/*     */     } 
/*     */     
/* 359 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class findMostSuitableIface(Class<?> paramClass) {
/* 371 */     if (null == paramClass) {
/* 372 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 377 */     if (this.delegateToMostSuitableIface.containsKey(paramClass)) {
/* 378 */       return this.delegateToMostSuitableIface.get(paramClass);
/*     */     }
/*     */     
/* 381 */     int i = -1;
/* 382 */     Class<?> clazz = null;
/* 383 */     for (Class clazz1 : this.annotationsRegistry.keySet()) {
/*     */       
/* 385 */       int j = intersectionCardinality(paramClass, clazz1);
/* 386 */       if (j < 1)
/*     */         continue; 
/* 388 */       if (j <= i) {
/*     */         continue;
/*     */       }
/*     */       
/* 392 */       i = j;
/* 393 */       clazz = clazz1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 398 */     synchronized (this) {
/*     */ 
/*     */ 
/*     */       
/* 402 */       HashMap<Class<?>, Class<?>> hashMap = new HashMap<Class<?>, Class<?>>((Map)this.delegateToMostSuitableIface);
/* 403 */       hashMap.put(paramClass, clazz);
/* 404 */       this.delegateToMostSuitableIface = (Map)hashMap;
/*     */     } 
/*     */     
/* 407 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int intersectionCardinality(Class paramClass1, Class paramClass2) {
/* 414 */     HashSet<Class> hashSet1 = new HashSet();
/*     */ 
/*     */     
/* 417 */     collectIfaces(paramClass2, hashSet1);
/*     */     
/* 419 */     HashSet<Class> hashSet2 = new HashSet();
/*     */ 
/*     */     
/* 422 */     collectIfaces(paramClass1, hashSet2);
/*     */     
/* 424 */     int i = hashSet1.size();
/* 425 */     hashSet1.removeAll(hashSet2);
/*     */     
/* 427 */     if (hashSet1.size() > 0) {
/* 428 */       return -1;
/*     */     }
/* 430 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void collectIfaces(Class paramClass, Set<Class> paramSet) {
/* 437 */     if (paramClass.isInterface()) {
/* 438 */       paramSet.add(paramClass);
/*     */     }
/* 440 */     for (Class<?> clazz1 : paramClass.getInterfaces()) {
/* 441 */       collectIfaces(clazz1, paramSet);
/*     */     }
/* 443 */     Class clazz = paramClass.getSuperclass();
/* 444 */     if (null != clazz)
/* 445 */       collectIfaces(clazz, paramSet); 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\ProxyFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */