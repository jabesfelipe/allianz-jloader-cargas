package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Wrapper;
import java.util.Map;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.internal.OracleResultSetMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetMetaData$$$Proxy extends NonTxnReplayableBase implements OracleResultSetMetaData, _Proxy_ {
  private OracleResultSetMetaData delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25124;
  
  private static Method methodObject25113;
  
  private static Method methodObject25116;
  
  private static Method methodObject25123;
  
  private static Method methodObject25106;
  
  private static Method methodObject25103;
  
  private static Method methodObject25125;
  
  private static Method methodObject25126;
  
  private static Method methodObject25110;
  
  private static Method methodObject25109;
  
  private static Method methodObject25111;
  
  private static Method methodObject25118;
  
  private static Method methodObject25112;
  
  private static Method methodObject25117;
  
  private static Method methodObject25121;
  
  private static Method methodObject25114;
  
  private static Method methodObject25127;
  
  private static Method methodObject25119;
  
  private static Method methodObject25107;
  
  private static Method methodObject25105;
  
  private static Method methodObject25122;
  
  private static Method methodObject25120;
  
  private static Method methodObject25108;
  
  private static Method methodObject25115;
  
  private static Method methodObject25104;
  
  public boolean isSearchable(int arg0) throws SQLException {
    try {
      preForAll(methodObject25124, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25124, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSearchable(arg0)), this, (Map)this.proxyCache, methodObject25124))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25124, onErrorForAll(methodObject25124, e))).booleanValue();
    } 
  }
  
  public int getColumnDisplaySize(int arg0) throws SQLException {
    try {
      preForAll(methodObject25113, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25113, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnDisplaySize(arg0)), this, (Map)this.proxyCache, methodObject25113))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25113, onErrorForAll(methodObject25113, e))).intValue();
    } 
  }
  
  public int getColumnType(int arg0) throws SQLException {
    try {
      preForAll(methodObject25116, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25116, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnType(arg0)), this, (Map)this.proxyCache, methodObject25116))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25116, onErrorForAll(methodObject25116, e))).intValue();
    } 
  }
  
  public boolean isDefinitelyWritable(int arg0) throws SQLException {
    try {
      preForAll(methodObject25123, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25123, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isDefinitelyWritable(arg0)), this, (Map)this.proxyCache, methodObject25123))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25123, onErrorForAll(methodObject25123, e))).booleanValue();
    } 
  }
  
  public int getPrecision(int arg0) throws SQLException {
    try {
      preForAll(methodObject25106, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25106, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getPrecision(arg0)), this, (Map)this.proxyCache, methodObject25106))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25106, onErrorForAll(methodObject25106, e))).intValue();
    } 
  }
  
  public boolean isNCHAR(int arg0) throws SQLException {
    try {
      preForAll(methodObject25103, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25103, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isNCHAR(arg0)), this, (Map)this.proxyCache, methodObject25103))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25103, onErrorForAll(methodObject25103, e))).booleanValue();
    } 
  }
  
  public boolean isWritable(int arg0) throws SQLException {
    try {
      preForAll(methodObject25125, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25125, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isWritable(arg0)), this, (Map)this.proxyCache, methodObject25125))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25125, onErrorForAll(methodObject25125, e))).booleanValue();
    } 
  }
  
  public boolean isWrapperFor(Class arg0) throws SQLException {
    return this.delegate.isWrapperFor(arg0);
  }
  
  public String getCatalogName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25110, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25110, this.proxyFactory.proxyFor(this.delegate.getCatalogName(arg0), this, (Map)this.proxyCache, methodObject25110));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25110, onErrorForAll(methodObject25110, e));
    } 
  }
  
  public boolean isSigned(int arg0) throws SQLException {
    try {
      preForAll(methodObject25109, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25109, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSigned(arg0)), this, (Map)this.proxyCache, methodObject25109))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25109, onErrorForAll(methodObject25109, e))).booleanValue();
    } 
  }
  
  public String getColumnClassName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25111, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25111, this.proxyFactory.proxyFor(this.delegate.getColumnClassName(arg0), this, (Map)this.proxyCache, methodObject25111));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25111, onErrorForAll(methodObject25111, e));
    } 
  }
  
  public String getSchemaName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25118, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25118, this.proxyFactory.proxyFor(this.delegate.getSchemaName(arg0), this, (Map)this.proxyCache, methodObject25118));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25118, onErrorForAll(methodObject25118, e));
    } 
  }
  
  public int getColumnCount() throws SQLException {
    try {
      preForAll(methodObject25112, this, new Object[0]);
      return ((Integer)postForAll(methodObject25112, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getColumnCount()), this, (Map)this.proxyCache, methodObject25112))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25112, onErrorForAll(methodObject25112, e))).intValue();
    } 
  }
  
  public String getColumnTypeName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25117, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25117, this.proxyFactory.proxyFor(this.delegate.getColumnTypeName(arg0), this, (Map)this.proxyCache, methodObject25117));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25117, onErrorForAll(methodObject25117, e));
    } 
  }
  
  public boolean isCaseSensitive(int arg0) throws SQLException {
    try {
      preForAll(methodObject25121, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25121, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCaseSensitive(arg0)), this, (Map)this.proxyCache, methodObject25121))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25121, onErrorForAll(methodObject25121, e))).booleanValue();
    } 
  }
  
  public String getColumnLabel(int arg0) throws SQLException {
    try {
      preForAll(methodObject25114, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25114, this.proxyFactory.proxyFor(this.delegate.getColumnLabel(arg0), this, (Map)this.proxyCache, methodObject25114));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25114, onErrorForAll(methodObject25114, e));
    } 
  }
  
  public Object unwrap(Class arg0) throws SQLException {
    return this.delegate.unwrap(arg0);
  }
  
  public String getTableName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25119, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25119, this.proxyFactory.proxyFor(this.delegate.getTableName(arg0), this, (Map)this.proxyCache, methodObject25119));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25119, onErrorForAll(methodObject25119, e));
    } 
  }
  
  public int getScale(int arg0) throws SQLException {
    try {
      preForAll(methodObject25107, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25107, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getScale(arg0)), this, (Map)this.proxyCache, methodObject25107))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25107, onErrorForAll(methodObject25107, e))).intValue();
    } 
  }
  
  public boolean isReadOnly(int arg0) throws SQLException {
    try {
      preForAll(methodObject25105, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25105, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isReadOnly(arg0)), this, (Map)this.proxyCache, methodObject25105))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25105, onErrorForAll(methodObject25105, e))).booleanValue();
    } 
  }
  
  public boolean isCurrency(int arg0) throws SQLException {
    try {
      preForAll(methodObject25122, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25122, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isCurrency(arg0)), this, (Map)this.proxyCache, methodObject25122))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25122, onErrorForAll(methodObject25122, e))).booleanValue();
    } 
  }
  
  public boolean isAutoIncrement(int arg0) throws SQLException {
    try {
      preForAll(methodObject25120, this, new Object[] { Integer.valueOf(arg0) });
      return ((Boolean)postForAll(methodObject25120, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isAutoIncrement(arg0)), this, (Map)this.proxyCache, methodObject25120))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25120, onErrorForAll(methodObject25120, e))).booleanValue();
    } 
  }
  
  public int isNullable(int arg0) throws SQLException {
    try {
      preForAll(methodObject25108, this, new Object[] { Integer.valueOf(arg0) });
      return ((Integer)postForAll(methodObject25108, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.isNullable(arg0)), this, (Map)this.proxyCache, methodObject25108))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25108, onErrorForAll(methodObject25108, e))).intValue();
    } 
  }
  
  public String getColumnName(int arg0) throws SQLException {
    try {
      preForAll(methodObject25115, this, new Object[] { Integer.valueOf(arg0) });
      return (String)postForAll(methodObject25115, this.proxyFactory.proxyFor(this.delegate.getColumnName(arg0), this, (Map)this.proxyCache, methodObject25115));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25115, onErrorForAll(methodObject25115, e));
    } 
  }
  
  public OracleResultSetMetaData.SecurityAttribute getSecurityAttribute(int arg0) throws SQLException {
    try {
      preForAll(methodObject25104, this, new Object[] { Integer.valueOf(arg0) });
      return (OracleResultSetMetaData.SecurityAttribute)postForAll(methodObject25104, this.proxyFactory.proxyFor(this.delegate.getSecurityAttribute(arg0), this, (Map)this.proxyCache, methodObject25104));
    } catch (SQLException e) {
      return (OracleResultSetMetaData.SecurityAttribute)postForAll(methodObject25104, onErrorForAll(methodObject25104, e));
    } 
  }
  
  public OracleResultSetMetaData _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleResultSetMetaData delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25124 = ResultSetMetaData.class.getDeclaredMethod("isSearchable", new Class[] { int.class });
      methodObject25113 = ResultSetMetaData.class.getDeclaredMethod("getColumnDisplaySize", new Class[] { int.class });
      methodObject25116 = ResultSetMetaData.class.getDeclaredMethod("getColumnType", new Class[] { int.class });
      methodObject25123 = ResultSetMetaData.class.getDeclaredMethod("isDefinitelyWritable", new Class[] { int.class });
      methodObject25106 = ResultSetMetaData.class.getDeclaredMethod("getPrecision", new Class[] { int.class });
      methodObject25103 = OracleResultSetMetaData.class.getDeclaredMethod("isNCHAR", new Class[] { int.class });
      methodObject25125 = ResultSetMetaData.class.getDeclaredMethod("isWritable", new Class[] { int.class });
      methodObject25126 = Wrapper.class.getDeclaredMethod("isWrapperFor", new Class[] { Class.class });
      methodObject25110 = ResultSetMetaData.class.getDeclaredMethod("getCatalogName", new Class[] { int.class });
      methodObject25109 = ResultSetMetaData.class.getDeclaredMethod("isSigned", new Class[] { int.class });
      methodObject25111 = ResultSetMetaData.class.getDeclaredMethod("getColumnClassName", new Class[] { int.class });
      methodObject25118 = ResultSetMetaData.class.getDeclaredMethod("getSchemaName", new Class[] { int.class });
      methodObject25112 = ResultSetMetaData.class.getDeclaredMethod("getColumnCount", new Class[0]);
      methodObject25117 = ResultSetMetaData.class.getDeclaredMethod("getColumnTypeName", new Class[] { int.class });
      methodObject25121 = ResultSetMetaData.class.getDeclaredMethod("isCaseSensitive", new Class[] { int.class });
      methodObject25114 = ResultSetMetaData.class.getDeclaredMethod("getColumnLabel", new Class[] { int.class });
      methodObject25127 = Wrapper.class.getDeclaredMethod("unwrap", new Class[] { Class.class });
      methodObject25119 = ResultSetMetaData.class.getDeclaredMethod("getTableName", new Class[] { int.class });
      methodObject25107 = ResultSetMetaData.class.getDeclaredMethod("getScale", new Class[] { int.class });
      methodObject25105 = ResultSetMetaData.class.getDeclaredMethod("isReadOnly", new Class[] { int.class });
      methodObject25122 = ResultSetMetaData.class.getDeclaredMethod("isCurrency", new Class[] { int.class });
      methodObject25120 = ResultSetMetaData.class.getDeclaredMethod("isAutoIncrement", new Class[] { int.class });
      methodObject25108 = ResultSetMetaData.class.getDeclaredMethod("isNullable", new Class[] { int.class });
      methodObject25115 = ResultSetMetaData.class.getDeclaredMethod("getColumnName", new Class[] { int.class });
      methodObject25104 = OracleResultSetMetaData.class.getDeclaredMethod("getSecurityAttribute", new Class[] { int.class });
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetMetaData$$$Proxy(OracleResultSetMetaData paramOracleResultSetMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleResultSetMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleResultSetMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */