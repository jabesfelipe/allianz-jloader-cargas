package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBlob;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBlob$2java$1sql$1Blob$$$Proxy extends NonTxnReplayableBlob implements Blob, _Proxy_ {
  private Blob delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject28977;
  
  private static Method methodObject28983;
  
  private static Method methodObject28976;
  
  private static Method methodObject28984;
  
  private static Method methodObject28982;
  
  private static Method methodObject28978;
  
  private static Method methodObject28975;
  
  private static Method methodObject28985;
  
  private static Method methodObject28979;
  
  private static Method methodObject28981;
  
  private static Method methodObject28980;
  
  public long position(byte[] arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject28977, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject28977, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position(arg0, arg1)), this, (Map)this.proxyCache, methodObject28977))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject28977, onErrorForAll(methodObject28977, e))).longValue();
    } 
  }
  
  public void free() throws SQLException {
    try {
      preForAll(methodObject28983, this, new Object[0]);
      this.delegate.free();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28983, e);
      return;
    } 
  }
  
  public long length() throws SQLException {
    try {
      preForAll(methodObject28976, this, new Object[0]);
      return ((Long)postForAll(methodObject28976, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.length()), this, (Map)this.proxyCache, methodObject28976))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject28976, onErrorForAll(methodObject28976, e))).longValue();
    } 
  }
  
  public InputStream getBinaryStream() throws SQLException {
    try {
      preForAll(methodObject28984, this, new Object[0]);
      return (InputStream)postForAll(methodObject28984, this.proxyFactory.proxyFor(this.delegate.getBinaryStream(), this, (Map)this.proxyCache, methodObject28984));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject28984, onErrorForAll(methodObject28984, e));
    } 
  }
  
  public void truncate(long arg0) throws SQLException {
    try {
      preForBlobWrites(methodObject28982, this, new Object[] { Long.valueOf(arg0) });
      this.delegate.truncate(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject28982, e);
      return;
    } 
  }
  
  public long position(Blob arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject28978, this, new Object[] { arg0, Long.valueOf(arg1) });
      return ((Long)postForAll(methodObject28978, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.position((arg0 instanceof _Proxy_) ? ((_Proxy_<Blob>)arg0)._getDelegate_() : arg0, arg1)), this, (Map)this.proxyCache, methodObject28978))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject28978, onErrorForAll(methodObject28978, e))).longValue();
    } 
  }
  
  public byte[] getBytes(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject28975, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (byte[])postForAll(methodObject28975, this.proxyFactory.proxyFor(this.delegate.getBytes(arg0, arg1), this, (Map)this.proxyCache, methodObject28975));
    } catch (SQLException e) {
      return (byte[])postForAll(methodObject28975, onErrorForAll(methodObject28975, e));
    } 
  }
  
  public InputStream getBinaryStream(long arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject28985, this, new Object[] { Long.valueOf(arg0), Long.valueOf(arg1) });
      return (InputStream)postForAll(methodObject28985, this.proxyFactory.proxyFor(this.delegate.getBinaryStream(arg0, arg1), this, (Map)this.proxyCache, methodObject28985));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject28985, onErrorForAll(methodObject28985, e));
    } 
  }
  
  public OutputStream setBinaryStream(long arg0) throws SQLException {
    try {
      preForAll(methodObject28979, this, new Object[] { Long.valueOf(arg0) });
      return (OutputStream)postForAll(methodObject28979, this.proxyFactory.proxyFor(this.delegate.setBinaryStream(arg0), this, (Map)this.proxyCache, methodObject28979));
    } catch (SQLException e) {
      return (OutputStream)postForAll(methodObject28979, onErrorForAll(methodObject28979, e));
    } 
  }
  
  public int setBytes(long arg0, byte[] arg1, int arg2, int arg3) throws SQLException {
    try {
      preForBlobWrites(methodObject28981, this, new Object[] { Long.valueOf(arg0), arg1, Integer.valueOf(arg2), Integer.valueOf(arg3) });
      return ((Integer)postForAll(methodObject28981, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.setBytes(arg0, arg1, arg2, arg3)), this, (Map)this.proxyCache, methodObject28981))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28981, onErrorForAll(methodObject28981, e))).intValue();
    } 
  }
  
  public int setBytes(long arg0, byte[] arg1) throws SQLException {
    try {
      preForBlobWrites(methodObject28980, this, new Object[] { Long.valueOf(arg0), arg1 });
      return ((Integer)postForAll(methodObject28980, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.setBytes(arg0, arg1)), this, (Map)this.proxyCache, methodObject28980))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject28980, onErrorForAll(methodObject28980, e))).intValue();
    } 
  }
  
  public Blob _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(Blob delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject28977 = Blob.class.getDeclaredMethod("position", new Class[] { byte[].class, long.class });
      methodObject28983 = Blob.class.getDeclaredMethod("free", new Class[0]);
      methodObject28976 = Blob.class.getDeclaredMethod("length", new Class[0]);
      methodObject28984 = Blob.class.getDeclaredMethod("getBinaryStream", new Class[0]);
      methodObject28982 = Blob.class.getDeclaredMethod("truncate", new Class[] { long.class });
      methodObject28978 = Blob.class.getDeclaredMethod("position", new Class[] { Blob.class, long.class });
      methodObject28975 = Blob.class.getDeclaredMethod("getBytes", new Class[] { long.class, int.class });
      methodObject28985 = Blob.class.getDeclaredMethod("getBinaryStream", new Class[] { long.class, long.class });
      methodObject28979 = Blob.class.getDeclaredMethod("setBinaryStream", new Class[] { long.class });
      methodObject28981 = Blob.class.getDeclaredMethod("setBytes", new Class[] { long.class, byte[].class, int.class, int.class });
      methodObject28980 = Blob.class.getDeclaredMethod("setBytes", new Class[] { long.class, byte[].class });
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBlob$2java$1sql$1Blob$$$Proxy(Blob paramBlob, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramBlob;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBlob$2java$1sql$1Blob$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */