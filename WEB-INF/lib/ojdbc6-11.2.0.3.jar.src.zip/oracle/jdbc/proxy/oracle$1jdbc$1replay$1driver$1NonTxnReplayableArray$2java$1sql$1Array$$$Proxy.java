package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy extends NonTxnReplayableArray implements Array, _Proxy_ {
  private Array delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25188;
  
  private static Method methodObject25186;
  
  private static Method methodObject25183;
  
  private static Method methodObject25185;
  
  private static Method methodObject25191;
  
  private static Method methodObject25182;
  
  private static Method methodObject25184;
  
  private static Method methodObject25192;
  
  private static Method methodObject25187;
  
  private static Method methodObject25190;
  
  private static Method methodObject25189;
  
  public String getBaseTypeName() throws SQLException {
    try {
      preForAll(methodObject25188, this, new Object[0]);
      return (String)postForAll(methodObject25188, this.proxyFactory.proxyFor(this.delegate.getBaseTypeName(), this, (Map)this.proxyCache, methodObject25188));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25188, onErrorForAll(methodObject25188, e));
    } 
  }
  
  public void free() throws SQLException {
    try {
      preForAll(methodObject25186, this, new Object[0]);
      this.delegate.free();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25186, e);
      return;
    } 
  }
  
  public Object getArray(Map<String, Class<?>> arg0) throws SQLException {
    try {
      preForAll(methodObject25183, this, new Object[] { arg0 });
      return postForAll(methodObject25183, this.proxyFactory.proxyFor(this.delegate.getArray(arg0), this, (Map)this.proxyCache, methodObject25183));
    } catch (SQLException e) {
      return postForAll(methodObject25183, onErrorForAll(methodObject25183, e));
    } 
  }
  
  public Object getArray(long arg0, int arg1, Map<String, Class<?>> arg2) throws SQLException {
    try {
      preForAll(methodObject25185, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject25185, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject25185));
    } catch (SQLException e) {
      return postForAll(methodObject25185, onErrorForAll(methodObject25185, e));
    } 
  }
  
  public ResultSet getResultSet(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25191, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject25191, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0, arg1), this, (Map)this.proxyCache, methodObject25191));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25191, onErrorForAll(methodObject25191, e));
    } 
  }
  
  public Object getArray() throws SQLException {
    try {
      preForAll(methodObject25182, this, new Object[0]);
      return postForAll(methodObject25182, this.proxyFactory.proxyFor(this.delegate.getArray(), this, (Map)this.proxyCache, methodObject25182));
    } catch (SQLException e) {
      return postForAll(methodObject25182, onErrorForAll(methodObject25182, e));
    } 
  }
  
  public Object getArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25184, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject25184, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25184));
    } catch (SQLException e) {
      return postForAll(methodObject25184, onErrorForAll(methodObject25184, e));
    } 
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map<String, Class<?>> arg2) throws SQLException {
    try {
      preForAll(methodObject25192, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject25192, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject25192));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25192, onErrorForAll(methodObject25192, e));
    } 
  }
  
  public int getBaseType() throws SQLException {
    try {
      preForAll(methodObject25187, this, new Object[0]);
      return ((Integer)postForAll(methodObject25187, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBaseType()), this, (Map)this.proxyCache, methodObject25187))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25187, onErrorForAll(methodObject25187, e))).intValue();
    } 
  }
  
  public ResultSet getResultSet(Map<String, Class<?>> arg0) throws SQLException {
    try {
      preForAll(methodObject25190, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject25190, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0), this, (Map)this.proxyCache, methodObject25190));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25190, onErrorForAll(methodObject25190, e));
    } 
  }
  
  public ResultSet getResultSet() throws SQLException {
    try {
      preForAll(methodObject25189, this, new Object[0]);
      return (ResultSet)postForAll(methodObject25189, this.proxyFactory.proxyFor(this.delegate.getResultSet(), this, (Map)this.proxyCache, methodObject25189));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25189, onErrorForAll(methodObject25189, e));
    } 
  }
  
  public Array _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(Array delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25188 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject25186 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject25183 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject25185 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class, Map.class });
      methodObject25191 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class });
      methodObject25182 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject25184 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class });
      methodObject25192 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class, Map.class });
      methodObject25187 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject25190 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject25189 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy(Array paramArray, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2java$1sql$1Array$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */