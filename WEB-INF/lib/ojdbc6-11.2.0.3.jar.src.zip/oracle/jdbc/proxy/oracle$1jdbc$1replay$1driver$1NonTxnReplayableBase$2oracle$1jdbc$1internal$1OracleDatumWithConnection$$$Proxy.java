package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleDatumWithConnection;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleDatumWithConnection$$$Proxy extends NonTxnReplayableBase implements OracleDatumWithConnection, _Proxy_ {
  private OracleDatumWithConnection delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25095;
  
  private static Method methodObject25075;
  
  private static Method methodObject25093;
  
  private static Method methodObject25066;
  
  private static Method methodObject25084;
  
  private static Method methodObject25067;
  
  private static Method methodObject25086;
  
  private static Method methodObject25080;
  
  private static Method methodObject25089;
  
  private static Method methodObject25085;
  
  private static Method methodObject25071;
  
  private static Method methodObject25094;
  
  private static Method methodObject25077;
  
  private static Method methodObject25079;
  
  private static Method methodObject25091;
  
  private static Method methodObject25096;
  
  private static Method methodObject25088;
  
  private static Method methodObject25090;
  
  private static Method methodObject25076;
  
  private static Method methodObject25082;
  
  private static Method methodObject25069;
  
  private static Method methodObject25081;
  
  private static Method methodObject25092;
  
  private static Method methodObject25072;
  
  private static Method methodObject25068;
  
  private static Method methodObject25070;
  
  private static Method methodObject25087;
  
  private static Method methodObject25078;
  
  private static Method methodObject25073;
  
  private static Method methodObject25083;
  
  private static Method methodObject25074;
  
  public OracleConnection getInternalConnection() throws SQLException {
    try {
      preForAll(methodObject25095, this, new Object[0]);
      return (OracleConnection)postForAll(methodObject25095, this.proxyFactory.proxyFor(this.delegate.getInternalConnection(), this, (Map)this.proxyCache, methodObject25095));
    } catch (SQLException e) {
      return (OracleConnection)postForAll(methodObject25095, onErrorForAll(methodObject25095, e));
    } 
  }
  
  public void setBytes(byte[] arg0) {
    preForAll(methodObject25075, this, new Object[] { arg0 });
    this.delegate.setBytes(arg0);
    postForAll(methodObject25075);
  }
  
  public Connection getJavaSqlConnection() throws SQLException {
    try {
      preForAll(methodObject25093, this, new Object[0]);
      return (Connection)postForAll(methodObject25093, this.proxyFactory.proxyFor(this.delegate.getJavaSqlConnection(), this, (Map)this.proxyCache, methodObject25093));
    } catch (SQLException e) {
      return (Connection)postForAll(methodObject25093, onErrorForAll(methodObject25093, e));
    } 
  }
  
  public byte[] getBytes() {
    preForAll(methodObject25066, this, new Object[0]);
    return (byte[])postForAll(methodObject25066, this.proxyFactory.proxyFor(this.delegate.getBytes(), this, (Map)this.proxyCache, methodObject25066));
  }
  
  public Time timeValue(Calendar arg0) throws SQLException {
    try {
      preForAll(methodObject25084, this, new Object[] { arg0 });
      return (Time)postForAll(methodObject25084, this.proxyFactory.proxyFor(this.delegate.timeValue(arg0), this, (Map)this.proxyCache, methodObject25084));
    } catch (SQLException e) {
      return (Time)postForAll(methodObject25084, onErrorForAll(methodObject25084, e));
    } 
  }
  
  public boolean booleanValue() throws SQLException {
    try {
      preForAll(methodObject25067, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25067, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.booleanValue()), this, (Map)this.proxyCache, methodObject25067))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25067, onErrorForAll(methodObject25067, e))).booleanValue();
    } 
  }
  
  public Timestamp timestampValue(Calendar arg0) throws SQLException {
    try {
      preForAll(methodObject25086, this, new Object[] { arg0 });
      return (Timestamp)postForAll(methodObject25086, this.proxyFactory.proxyFor(this.delegate.timestampValue(arg0), this, (Map)this.proxyCache, methodObject25086));
    } catch (SQLException e) {
      return (Timestamp)postForAll(methodObject25086, onErrorForAll(methodObject25086, e));
    } 
  }
  
  public String stringValue(Connection arg0) throws SQLException {
    try {
      preForAll(methodObject25080, this, new Object[] { arg0 });
      return (String)postForAll(methodObject25080, this.proxyFactory.proxyFor(this.delegate.stringValue((arg0 instanceof _Proxy_) ? ((_Proxy_<Connection>)arg0)._getDelegate_() : arg0), this, (Map)this.proxyCache, methodObject25080));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25080, onErrorForAll(methodObject25080, e));
    } 
  }
  
  public InputStream binaryStreamValue() throws SQLException {
    try {
      preForAll(methodObject25089, this, new Object[0]);
      return (InputStream)postForAll(methodObject25089, this.proxyFactory.proxyFor(this.delegate.binaryStreamValue(), this, (Map)this.proxyCache, methodObject25089));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject25089, onErrorForAll(methodObject25089, e));
    } 
  }
  
  public Timestamp timestampValue() throws SQLException {
    try {
      preForAll(methodObject25085, this, new Object[0]);
      return (Timestamp)postForAll(methodObject25085, this.proxyFactory.proxyFor(this.delegate.timestampValue(), this, (Map)this.proxyCache, methodObject25085));
    } catch (SQLException e) {
      return (Timestamp)postForAll(methodObject25085, onErrorForAll(methodObject25085, e));
    } 
  }
  
  public int intValue() throws SQLException {
    try {
      preForAll(methodObject25071, this, new Object[0]);
      return ((Integer)postForAll(methodObject25071, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.intValue()), this, (Map)this.proxyCache, methodObject25071))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25071, onErrorForAll(methodObject25071, e))).intValue();
    } 
  }
  
  public OracleConnection getOracleConnection() throws SQLException {
    try {
      preForAll(methodObject25094, this, new Object[0]);
      return (OracleConnection)postForAll(methodObject25094, this.proxyFactory.proxyFor(this.delegate.getOracleConnection(), this, (Map)this.proxyCache, methodObject25094));
    } catch (SQLException e) {
      return (OracleConnection)postForAll(methodObject25094, onErrorForAll(methodObject25094, e));
    } 
  }
  
  public void setShareBytes(byte[] arg0) {
    preForAll(methodObject25077, this, new Object[] { arg0 });
    this.delegate.setShareBytes(arg0);
    postForAll(methodObject25077);
  }
  
  public String stringValue() throws SQLException {
    try {
      preForAll(methodObject25079, this, new Object[0]);
      return (String)postForAll(methodObject25079, this.proxyFactory.proxyFor(this.delegate.stringValue(), this, (Map)this.proxyCache, methodObject25079));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25079, onErrorForAll(methodObject25079, e));
    } 
  }
  
  public Object toJdbc() throws SQLException {
    try {
      preForAll(methodObject25091, this, new Object[0]);
      return postForAll(methodObject25091, this.proxyFactory.proxyFor(this.delegate.toJdbc(), this, (Map)this.proxyCache, methodObject25091));
    } catch (SQLException e) {
      return postForAll(methodObject25091, onErrorForAll(methodObject25091, e));
    } 
  }
  
  public void setPhysicalConnectionOf(Connection arg0) {
    preForAll(methodObject25096, this, new Object[] { arg0 });
    this.delegate.setPhysicalConnectionOf((arg0 instanceof _Proxy_) ? ((_Proxy_<Connection>)arg0)._getDelegate_() : arg0);
    postForAll(methodObject25096);
  }
  
  public InputStream asciiStreamValue() throws SQLException {
    try {
      preForAll(methodObject25088, this, new Object[0]);
      return (InputStream)postForAll(methodObject25088, this.proxyFactory.proxyFor(this.delegate.asciiStreamValue(), this, (Map)this.proxyCache, methodObject25088));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject25088, onErrorForAll(methodObject25088, e));
    } 
  }
  
  public boolean isConvertibleTo(Class arg0) {
    preForAll(methodObject25090, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject25090, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isConvertibleTo(arg0)), this, (Map)this.proxyCache, methodObject25090))).booleanValue();
  }
  
  public byte[] shareBytes() {
    preForAll(methodObject25076, this, new Object[0]);
    return (byte[])postForAll(methodObject25076, this.proxyFactory.proxyFor(this.delegate.shareBytes(), this, (Map)this.proxyCache, methodObject25076));
  }
  
  public Date dateValue() throws SQLException {
    try {
      preForAll(methodObject25082, this, new Object[0]);
      return (Date)postForAll(methodObject25082, this.proxyFactory.proxyFor(this.delegate.dateValue(), this, (Map)this.proxyCache, methodObject25082));
    } catch (SQLException e) {
      return (Date)postForAll(methodObject25082, onErrorForAll(methodObject25082, e));
    } 
  }
  
  public double doubleValue() throws SQLException {
    try {
      preForAll(methodObject25069, this, new Object[0]);
      return ((Double)postForAll(methodObject25069, this.proxyFactory.proxyFor(Double.valueOf(this.delegate.doubleValue()), this, (Map)this.proxyCache, methodObject25069))).doubleValue();
    } catch (SQLException e) {
      return ((Double)postForAll(methodObject25069, onErrorForAll(methodObject25069, e))).doubleValue();
    } 
  }
  
  public BigDecimal bigDecimalValue() throws SQLException {
    try {
      preForAll(methodObject25081, this, new Object[0]);
      return (BigDecimal)postForAll(methodObject25081, this.proxyFactory.proxyFor(this.delegate.bigDecimalValue(), this, (Map)this.proxyCache, methodObject25081));
    } catch (SQLException e) {
      return (BigDecimal)postForAll(methodObject25081, onErrorForAll(methodObject25081, e));
    } 
  }
  
  public Object makeJdbcArray(int arg0) {
    preForAll(methodObject25092, this, new Object[] { Integer.valueOf(arg0) });
    return postForAll(methodObject25092, this.proxyFactory.proxyFor(this.delegate.makeJdbcArray(arg0), this, (Map)this.proxyCache, methodObject25092));
  }
  
  public long longValue() throws SQLException {
    try {
      preForAll(methodObject25072, this, new Object[0]);
      return ((Long)postForAll(methodObject25072, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.longValue()), this, (Map)this.proxyCache, methodObject25072))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject25072, onErrorForAll(methodObject25072, e))).longValue();
    } 
  }
  
  public byte byteValue() throws SQLException {
    try {
      preForAll(methodObject25068, this, new Object[0]);
      return ((Byte)postForAll(methodObject25068, this.proxyFactory.proxyFor(Byte.valueOf(this.delegate.byteValue()), this, (Map)this.proxyCache, methodObject25068))).byteValue();
    } catch (SQLException e) {
      return ((Byte)postForAll(methodObject25068, onErrorForAll(methodObject25068, e))).byteValue();
    } 
  }
  
  public float floatValue() throws SQLException {
    try {
      preForAll(methodObject25070, this, new Object[0]);
      return ((Float)postForAll(methodObject25070, this.proxyFactory.proxyFor(Float.valueOf(this.delegate.floatValue()), this, (Map)this.proxyCache, methodObject25070))).floatValue();
    } catch (SQLException e) {
      return ((Float)postForAll(methodObject25070, onErrorForAll(methodObject25070, e))).floatValue();
    } 
  }
  
  public Reader characterStreamValue() throws SQLException {
    try {
      preForAll(methodObject25087, this, new Object[0]);
      return (Reader)postForAll(methodObject25087, this.proxyFactory.proxyFor(this.delegate.characterStreamValue(), this, (Map)this.proxyCache, methodObject25087));
    } catch (SQLException e) {
      return (Reader)postForAll(methodObject25087, onErrorForAll(methodObject25087, e));
    } 
  }
  
  public InputStream getStream() throws SQLException {
    try {
      preForAll(methodObject25078, this, new Object[0]);
      return (InputStream)postForAll(methodObject25078, this.proxyFactory.proxyFor(this.delegate.getStream(), this, (Map)this.proxyCache, methodObject25078));
    } catch (SQLException e) {
      return (InputStream)postForAll(methodObject25078, onErrorForAll(methodObject25078, e));
    } 
  }
  
  public long getLength() {
    preForAll(methodObject25073, this, new Object[0]);
    return ((Long)postForAll(methodObject25073, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getLength()), this, (Map)this.proxyCache, methodObject25073))).longValue();
  }
  
  public Time timeValue() throws SQLException {
    try {
      preForAll(methodObject25083, this, new Object[0]);
      return (Time)postForAll(methodObject25083, this.proxyFactory.proxyFor(this.delegate.timeValue(), this, (Map)this.proxyCache, methodObject25083));
    } catch (SQLException e) {
      return (Time)postForAll(methodObject25083, onErrorForAll(methodObject25083, e));
    } 
  }
  
  public OracleConnection getConnection() throws SQLException {
    try {
      preForAll(methodObject25074, this, new Object[0]);
      return (OracleConnection)postForAll(methodObject25074, this.proxyFactory.proxyFor(this.delegate.getConnection(), this, (Map)this.proxyCache, methodObject25074));
    } catch (SQLException e) {
      return (OracleConnection)postForAll(methodObject25074, onErrorForAll(methodObject25074, e));
    } 
  }
  
  public OracleDatumWithConnection _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleDatumWithConnection delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25095 = OracleDatumWithConnection.class.getDeclaredMethod("getInternalConnection", new Class[0]);
      methodObject25075 = OracleDatumWithConnection.class.getDeclaredMethod("setBytes", new Class[] { byte[].class });
      methodObject25093 = OracleDatumWithConnection.class.getDeclaredMethod("getJavaSqlConnection", new Class[0]);
      methodObject25066 = OracleDatumWithConnection.class.getDeclaredMethod("getBytes", new Class[0]);
      methodObject25084 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[] { Calendar.class });
      methodObject25067 = OracleDatumWithConnection.class.getDeclaredMethod("booleanValue", new Class[0]);
      methodObject25086 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[] { Calendar.class });
      methodObject25080 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[] { Connection.class });
      methodObject25089 = OracleDatumWithConnection.class.getDeclaredMethod("binaryStreamValue", new Class[0]);
      methodObject25085 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[0]);
      methodObject25071 = OracleDatumWithConnection.class.getDeclaredMethod("intValue", new Class[0]);
      methodObject25094 = OracleDatumWithConnection.class.getDeclaredMethod("getOracleConnection", new Class[0]);
      methodObject25077 = OracleDatumWithConnection.class.getDeclaredMethod("setShareBytes", new Class[] { byte[].class });
      methodObject25079 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[0]);
      methodObject25091 = OracleDatumWithConnection.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject25096 = OracleDatumWithConnection.class.getDeclaredMethod("setPhysicalConnectionOf", new Class[] { Connection.class });
      methodObject25088 = OracleDatumWithConnection.class.getDeclaredMethod("asciiStreamValue", new Class[0]);
      methodObject25090 = OracleDatumWithConnection.class.getDeclaredMethod("isConvertibleTo", new Class[] { Class.class });
      methodObject25076 = OracleDatumWithConnection.class.getDeclaredMethod("shareBytes", new Class[0]);
      methodObject25082 = OracleDatumWithConnection.class.getDeclaredMethod("dateValue", new Class[0]);
      methodObject25069 = OracleDatumWithConnection.class.getDeclaredMethod("doubleValue", new Class[0]);
      methodObject25081 = OracleDatumWithConnection.class.getDeclaredMethod("bigDecimalValue", new Class[0]);
      methodObject25092 = OracleDatumWithConnection.class.getDeclaredMethod("makeJdbcArray", new Class[] { int.class });
      methodObject25072 = OracleDatumWithConnection.class.getDeclaredMethod("longValue", new Class[0]);
      methodObject25068 = OracleDatumWithConnection.class.getDeclaredMethod("byteValue", new Class[0]);
      methodObject25070 = OracleDatumWithConnection.class.getDeclaredMethod("floatValue", new Class[0]);
      methodObject25087 = OracleDatumWithConnection.class.getDeclaredMethod("characterStreamValue", new Class[0]);
      methodObject25078 = OracleDatumWithConnection.class.getDeclaredMethod("getStream", new Class[0]);
      methodObject25073 = OracleDatumWithConnection.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject25083 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[0]);
      methodObject25074 = OracleDatumWithConnection.class.getDeclaredMethod("getConnection", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleDatumWithConnection$$$Proxy(OracleDatumWithConnection paramOracleDatumWithConnection, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleDatumWithConnection;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1internal$1OracleDatumWithConnection$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */