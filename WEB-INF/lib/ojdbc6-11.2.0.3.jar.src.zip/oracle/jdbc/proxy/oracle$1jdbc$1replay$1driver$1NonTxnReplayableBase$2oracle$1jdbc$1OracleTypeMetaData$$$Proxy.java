package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.sql.SQLName;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$$$Proxy extends NonTxnReplayableBase implements OracleTypeMetaData, _Proxy_ {
  private OracleTypeMetaData delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25027;
  
  private static Method methodObject25025;
  
  private static Method methodObject25028;
  
  private static Method methodObject25026;
  
  private static Method methodObject25029;
  
  private static Method methodObject25024;
  
  public OracleTypeMetaData.Kind getKind() {
    preForAll(methodObject25027, this, new Object[0]);
    return (OracleTypeMetaData.Kind)postForAll(methodObject25027, this.proxyFactory.proxyFor(this.delegate.getKind(), this, (Map)this.proxyCache, methodObject25027));
  }
  
  public int getTypeCode() throws SQLException {
    try {
      preForAll(methodObject25025, this, new Object[0]);
      return ((Integer)postForAll(methodObject25025, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeCode()), this, (Map)this.proxyCache, methodObject25025))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25025, onErrorForAll(methodObject25025, e))).intValue();
    } 
  }
  
  public SQLName getSQLName() throws SQLException {
    try {
      preForAll(methodObject25028, this, new Object[0]);
      return (SQLName)postForAll(methodObject25028, this.proxyFactory.proxyFor(this.delegate.getSQLName(), this, (Map)this.proxyCache, methodObject25028));
    } catch (SQLException e) {
      return (SQLName)postForAll(methodObject25028, onErrorForAll(methodObject25028, e));
    } 
  }
  
  public String getSchemaName() throws SQLException {
    try {
      preForAll(methodObject25026, this, new Object[0]);
      return (String)postForAll(methodObject25026, this.proxyFactory.proxyFor(this.delegate.getSchemaName(), this, (Map)this.proxyCache, methodObject25026));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25026, onErrorForAll(methodObject25026, e));
    } 
  }
  
  public String getTypeCodeName() throws SQLException {
    try {
      preForAll(methodObject25029, this, new Object[0]);
      return (String)postForAll(methodObject25029, this.proxyFactory.proxyFor(this.delegate.getTypeCodeName(), this, (Map)this.proxyCache, methodObject25029));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25029, onErrorForAll(methodObject25029, e));
    } 
  }
  
  public String getName() throws SQLException {
    try {
      preForAll(methodObject25024, this, new Object[0]);
      return (String)postForAll(methodObject25024, this.proxyFactory.proxyFor(this.delegate.getName(), this, (Map)this.proxyCache, methodObject25024));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25024, onErrorForAll(methodObject25024, e));
    } 
  }
  
  public OracleTypeMetaData _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleTypeMetaData delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25027 = OracleTypeMetaData.class.getDeclaredMethod("getKind", new Class[0]);
      methodObject25025 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCode", new Class[0]);
      methodObject25028 = OracleTypeMetaData.class.getDeclaredMethod("getSQLName", new Class[0]);
      methodObject25026 = OracleTypeMetaData.class.getDeclaredMethod("getSchemaName", new Class[0]);
      methodObject25029 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCodeName", new Class[0]);
      methodObject25024 = OracleTypeMetaData.class.getDeclaredMethod("getName", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$$$Proxy(OracleTypeMetaData paramOracleTypeMetaData, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleTypeMetaData;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */