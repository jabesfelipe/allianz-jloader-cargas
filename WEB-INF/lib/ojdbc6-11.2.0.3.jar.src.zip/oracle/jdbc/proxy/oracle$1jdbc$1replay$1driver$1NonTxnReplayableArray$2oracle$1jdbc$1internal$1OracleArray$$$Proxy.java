package oracle.jdbc.proxy;

import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleArray;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.internal.OracleArray;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleDatumWithConnection;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;
import oracle.sql.ArrayDescriptor;
import oracle.sql.Datum;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy extends NonTxnReplayableArray implements OracleArray, _Proxy_ {
  private OracleArray delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25285;
  
  private static Method methodObject25293;
  
  private static Method methodObject25234;
  
  private static Method methodObject25248;
  
  private static Method methodObject25300;
  
  private static Method methodObject25274;
  
  private static Method methodObject25267;
  
  private static Method methodObject25290;
  
  private static Method methodObject25238;
  
  private static Method methodObject25228;
  
  private static Method methodObject25247;
  
  private static Method methodObject25250;
  
  private static Method methodObject25301;
  
  private static Method methodObject25269;
  
  private static Method methodObject25279;
  
  private static Method methodObject25263;
  
  private static Method methodObject25283;
  
  private static Method methodObject25282;
  
  private static Method methodObject25221;
  
  private static Method methodObject25268;
  
  private static Method methodObject25297;
  
  private static Method methodObject25254;
  
  private static Method methodObject25284;
  
  private static Method methodObject25260;
  
  private static Method methodObject25262;
  
  private static Method methodObject25240;
  
  private static Method methodObject25220;
  
  private static Method methodObject25296;
  
  private static Method methodObject25295;
  
  private static Method methodObject25271;
  
  private static Method methodObject25288;
  
  private static Method methodObject25259;
  
  private static Method methodObject25252;
  
  private static Method methodObject25237;
  
  private static Method methodObject25232;
  
  private static Method methodObject25231;
  
  private static Method methodObject25244;
  
  private static Method methodObject25286;
  
  private static Method methodObject25235;
  
  private static Method methodObject25246;
  
  private static Method methodObject25255;
  
  private static Method methodObject25245;
  
  private static Method methodObject25278;
  
  private static Method methodObject25276;
  
  private static Method methodObject25218;
  
  private static Method methodObject25224;
  
  private static Method methodObject25292;
  
  private static Method methodObject25289;
  
  private static Method methodObject25258;
  
  private static Method methodObject25302;
  
  private static Method methodObject25242;
  
  private static Method methodObject25225;
  
  private static Method methodObject25249;
  
  private static Method methodObject25243;
  
  private static Method methodObject25219;
  
  private static Method methodObject25272;
  
  private static Method methodObject25236;
  
  private static Method methodObject25287;
  
  private static Method methodObject25275;
  
  private static Method methodObject25280;
  
  private static Method methodObject25298;
  
  private static Method methodObject25291;
  
  private static Method methodObject25233;
  
  private static Method methodObject25277;
  
  private static Method methodObject25230;
  
  private static Method methodObject25222;
  
  private static Method methodObject25265;
  
  private static Method methodObject25227;
  
  private static Method methodObject25264;
  
  private static Method methodObject25223;
  
  private static Method methodObject25281;
  
  private static Method methodObject25251;
  
  private static Method methodObject25229;
  
  private static Method methodObject25270;
  
  private static Method methodObject25239;
  
  private static Method methodObject25253;
  
  private static Method methodObject25294;
  
  private static Method methodObject25226;
  
  private static Method methodObject25261;
  
  private static Method methodObject25256;
  
  private static Method methodObject25266;
  
  private static Method methodObject25241;
  
  private static Method methodObject25299;
  
  private static Method methodObject25257;
  
  public double[] getDoubleArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25285, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (double[])postForAll(methodObject25285, this.proxyFactory.proxyFor(this.delegate.getDoubleArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25285));
    } catch (SQLException e) {
      return (double[])postForAll(methodObject25285, onErrorForAll(methodObject25285, e));
    } 
  }
  
  public Object getArray(Map arg0) throws SQLException {
    try {
      preForAll(methodObject25293, this, new Object[] { arg0 });
      return postForAll(methodObject25293, this.proxyFactory.proxyFor(this.delegate.getArray(arg0), this, (Map)this.proxyCache, methodObject25293));
    } catch (SQLException e) {
      return postForAll(methodObject25293, onErrorForAll(methodObject25293, e));
    } 
  }
  
  public boolean isInline() {
    preForAll(methodObject25234, this, new Object[0]);
    return ((Boolean)postForAll(methodObject25234, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isInline()), this, (Map)this.proxyCache, methodObject25234))).booleanValue();
  }
  
  public long getImageLength() {
    preForAll(methodObject25248, this, new Object[0]);
    return ((Long)postForAll(methodObject25248, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getImageLength()), this, (Map)this.proxyCache, methodObject25248))).longValue();
  }
  
  public ResultSet getResultSet(Map arg0) throws SQLException {
    try {
      preForAll(methodObject25300, this, new Object[] { arg0 });
      return (ResultSet)postForAll(methodObject25300, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0), this, (Map)this.proxyCache, methodObject25300));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25300, onErrorForAll(methodObject25300, e));
    } 
  }
  
  public Connection getJavaSqlConnection() throws SQLException {
    return this.delegate.getJavaSqlConnection();
  }
  
  public Time timeValue(Calendar arg0) throws SQLException {
    return this.delegate.timeValue(arg0);
  }
  
  public float[] getFloatArray() throws SQLException {
    try {
      preForAll(methodObject25290, this, new Object[0]);
      return (float[])postForAll(methodObject25290, this.proxyFactory.proxyFor(this.delegate.getFloatArray(), this, (Map)this.proxyCache, methodObject25290));
    } catch (SQLException e) {
      return (float[])postForAll(methodObject25290, onErrorForAll(methodObject25290, e));
    } 
  }
  
  public void setAutoIndexing(boolean arg0) throws SQLException {
    try {
      preForAll(methodObject25238, this, new Object[] { Boolean.valueOf(arg0) });
      this.delegate.setAutoIndexing(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25238, e);
      return;
    } 
  }
  
  public void setObjArray(Object arg0) throws SQLException {
    try {
      preForAll(methodObject25228, this, new Object[] { arg0 });
      this.delegate.setObjArray((arg0 instanceof _Proxy_) ? ((_Proxy_)arg0)._getDelegate_() : arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25228, e);
      return;
    } 
  }
  
  public long getImageOffset() {
    preForAll(methodObject25247, this, new Object[0]);
    return ((Long)postForAll(methodObject25247, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getImageOffset()), this, (Map)this.proxyCache, methodObject25247))).longValue();
  }
  
  public boolean booleanValue() throws SQLException {
    return this.delegate.booleanValue();
  }
  
  public ResultSet getResultSet(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25301, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (ResultSet)postForAll(methodObject25301, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0, arg1), this, (Map)this.proxyCache, methodObject25301));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25301, onErrorForAll(methodObject25301, e));
    } 
  }
  
  public Timestamp timestampValue(Calendar arg0) throws SQLException {
    return this.delegate.timestampValue(arg0);
  }
  
  public String getSQLTypeName() throws SQLException {
    try {
      preForAll(methodObject25279, this, new Object[0]);
      return (String)postForAll(methodObject25279, this.proxyFactory.proxyFor(this.delegate.getSQLTypeName(), this, (Map)this.proxyCache, methodObject25279));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25279, onErrorForAll(methodObject25279, e));
    } 
  }
  
  public String stringValue(Connection arg0) throws SQLException {
    return this.delegate.stringValue((arg0 instanceof _Proxy_) ? ((_Proxy_<Connection>)arg0)._getDelegate_() : arg0);
  }
  
  public int[] getIntArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25283, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (int[])postForAll(methodObject25283, this.proxyFactory.proxyFor(this.delegate.getIntArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25283));
    } catch (SQLException e) {
      return (int[])postForAll(methodObject25283, onErrorForAll(methodObject25283, e));
    } 
  }
  
  public int[] getIntArray() throws SQLException {
    try {
      preForAll(methodObject25282, this, new Object[0]);
      return (int[])postForAll(methodObject25282, this.proxyFactory.proxyFor(this.delegate.getIntArray(), this, (Map)this.proxyCache, methodObject25282));
    } catch (SQLException e) {
      return (int[])postForAll(methodObject25282, onErrorForAll(methodObject25282, e));
    } 
  }
  
  public Map getMap() throws SQLException {
    try {
      preForAll(methodObject25221, this, new Object[0]);
      return (Map)postForAll(methodObject25221, this.proxyFactory.proxyFor(this.delegate.getMap(), this, (Map)this.proxyCache, methodObject25221));
    } catch (SQLException e) {
      return (Map)postForAll(methodObject25221, onErrorForAll(methodObject25221, e));
    } 
  }
  
  public Timestamp timestampValue() throws SQLException {
    return this.delegate.timestampValue();
  }
  
  public int getBaseType() throws SQLException {
    try {
      preForAll(methodObject25297, this, new Object[0]);
      return ((Integer)postForAll(methodObject25297, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getBaseType()), this, (Map)this.proxyCache, methodObject25297))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25297, onErrorForAll(methodObject25297, e))).intValue();
    } 
  }
  
  public int intValue() throws SQLException {
    return this.delegate.intValue();
  }
  
  public double[] getDoubleArray() throws SQLException {
    try {
      preForAll(methodObject25284, this, new Object[0]);
      return (double[])postForAll(methodObject25284, this.proxyFactory.proxyFor(this.delegate.getDoubleArray(), this, (Map)this.proxyCache, methodObject25284));
    } catch (SQLException e) {
      return (double[])postForAll(methodObject25284, onErrorForAll(methodObject25284, e));
    } 
  }
  
  public void setShareBytes(byte[] arg0) {
    this.delegate.setShareBytes(arg0);
  }
  
  public String stringValue() throws SQLException {
    return this.delegate.stringValue();
  }
  
  public int getAccessDirection() throws SQLException {
    try {
      preForAll(methodObject25240, this, new Object[0]);
      return ((Integer)postForAll(methodObject25240, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getAccessDirection()), this, (Map)this.proxyCache, methodObject25240))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25240, onErrorForAll(methodObject25240, e))).intValue();
    } 
  }
  
  public long getOffset(long arg0) throws SQLException {
    try {
      preForAll(methodObject25220, this, new Object[] { Long.valueOf(arg0) });
      return ((Long)postForAll(methodObject25220, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getOffset(arg0)), this, (Map)this.proxyCache, methodObject25220))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject25220, onErrorForAll(methodObject25220, e))).longValue();
    } 
  }
  
  public void free() throws SQLException {
    try {
      preForAll(methodObject25296, this, new Object[0]);
      this.delegate.free();
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25296, e);
      return;
    } 
  }
  
  public Object getArray(long arg0, int arg1, Map arg2) throws SQLException {
    try {
      preForAll(methodObject25295, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return postForAll(methodObject25295, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject25295));
    } catch (SQLException e) {
      return postForAll(methodObject25295, onErrorForAll(methodObject25295, e));
    } 
  }
  
  public InputStream asciiStreamValue() throws SQLException {
    return this.delegate.asciiStreamValue();
  }
  
  public long[] getLongArray() throws SQLException {
    try {
      preForAll(methodObject25288, this, new Object[0]);
      return (long[])postForAll(methodObject25288, this.proxyFactory.proxyFor(this.delegate.getLongArray(), this, (Map)this.proxyCache, methodObject25288));
    } catch (SQLException e) {
      return (long[])postForAll(methodObject25288, onErrorForAll(methodObject25288, e));
    } 
  }
  
  public byte[] shareBytes() {
    return this.delegate.shareBytes();
  }
  
  public double doubleValue() throws SQLException {
    return this.delegate.doubleValue();
  }
  
  public void setAutoIndexing(boolean arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25237, this, new Object[] { Boolean.valueOf(arg0), Integer.valueOf(arg1) });
      this.delegate.setAutoIndexing(arg0, arg1);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25237, e);
      return;
    } 
  }
  
  public byte[] getLocator() {
    preForAll(methodObject25232, this, new Object[0]);
    return (byte[])postForAll(methodObject25232, this.proxyFactory.proxyFor(this.delegate.getLocator(), this, (Map)this.proxyCache, methodObject25232));
  }
  
  public void setPrefixFlag(byte arg0) {
    preForAll(methodObject25231, this, new Object[] { Byte.valueOf(arg0) });
    this.delegate.setPrefixFlag(arg0);
  }
  
  public long getLastOffset() throws SQLException {
    try {
      preForAll(methodObject25244, this, new Object[0]);
      return ((Long)postForAll(methodObject25244, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getLastOffset()), this, (Map)this.proxyCache, methodObject25244))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject25244, onErrorForAll(methodObject25244, e))).longValue();
    } 
  }
  
  public short[] getShortArray() throws SQLException {
    try {
      preForAll(methodObject25286, this, new Object[0]);
      return (short[])postForAll(methodObject25286, this.proxyFactory.proxyFor(this.delegate.getShortArray(), this, (Map)this.proxyCache, methodObject25286));
    } catch (SQLException e) {
      return (short[])postForAll(methodObject25286, onErrorForAll(methodObject25286, e));
    } 
  }
  
  public void setAutoBuffering(boolean arg0) throws SQLException {
    try {
      preForAll(methodObject25235, this, new Object[] { Boolean.valueOf(arg0) });
      this.delegate.setAutoBuffering(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25235, e);
      return;
    } 
  }
  
  public void setImageLength(long arg0) throws SQLException {
    try {
      preForAll(methodObject25246, this, new Object[] { Long.valueOf(arg0) });
      this.delegate.setImageLength(arg0);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25246, e);
      return;
    } 
  }
  
  public long longValue() throws SQLException {
    return this.delegate.longValue();
  }
  
  public void setImage(byte[] arg0, long arg1, long arg2) throws SQLException {
    try {
      preForAll(methodObject25245, this, new Object[] { arg0, Long.valueOf(arg1), Long.valueOf(arg2) });
      this.delegate.setImage(arg0, arg1, arg2);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25245, e);
      return;
    } 
  }
  
  public int length() throws SQLException {
    try {
      preForAll(methodObject25278, this, new Object[0]);
      return ((Integer)postForAll(methodObject25278, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.length()), this, (Map)this.proxyCache, methodObject25278))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25278, onErrorForAll(methodObject25278, e))).intValue();
    } 
  }
  
  public OracleConnection getInternalConnection() throws SQLException {
    return this.delegate.getInternalConnection();
  }
  
  public ArrayDescriptor getDescriptor() throws SQLException {
    try {
      preForAll(methodObject25218, this, new Object[0]);
      return (ArrayDescriptor)postForAll(methodObject25218, this.proxyFactory.proxyFor(this.delegate.getDescriptor(), this, (Map)this.proxyCache, methodObject25218));
    } catch (SQLException e) {
      return (ArrayDescriptor)postForAll(methodObject25218, onErrorForAll(methodObject25218, e));
    } 
  }
  
  public Datum[] getOracleArray() throws SQLException {
    try {
      preForAll(methodObject25224, this, new Object[0]);
      return (Datum[])postForAll(methodObject25224, this.proxyFactory.proxyFor(this.delegate.getOracleArray(), this, (Map)this.proxyCache, methodObject25224));
    } catch (SQLException e) {
      return (Datum[])postForAll(methodObject25224, onErrorForAll(methodObject25224, e));
    } 
  }
  
  public Object getArray() throws SQLException {
    try {
      preForAll(methodObject25292, this, new Object[0]);
      return postForAll(methodObject25292, this.proxyFactory.proxyFor(this.delegate.getArray(), this, (Map)this.proxyCache, methodObject25292));
    } catch (SQLException e) {
      return postForAll(methodObject25292, onErrorForAll(methodObject25292, e));
    } 
  }
  
  public long[] getLongArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25289, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (long[])postForAll(methodObject25289, this.proxyFactory.proxyFor(this.delegate.getLongArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25289));
    } catch (SQLException e) {
      return (long[])postForAll(methodObject25289, onErrorForAll(methodObject25289, e));
    } 
  }
  
  public void setBytes(byte[] arg0) {
    this.delegate.setBytes(arg0);
  }
  
  public ResultSet getResultSet(long arg0, int arg1, Map arg2) throws SQLException {
    try {
      preForAll(methodObject25302, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1), arg2 });
      return (ResultSet)postForAll(methodObject25302, this.proxyFactory.proxyFor(this.delegate.getResultSet(arg0, arg1, arg2), this, (Map)this.proxyCache, methodObject25302));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25302, onErrorForAll(methodObject25302, e));
    } 
  }
  
  public void setIndexOffset(long arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject25242, this, new Object[] { Long.valueOf(arg0), Long.valueOf(arg1) });
      this.delegate.setIndexOffset(arg0, arg1);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25242, e);
      return;
    } 
  }
  
  public Datum[] getOracleArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25225, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (Datum[])postForAll(methodObject25225, this.proxyFactory.proxyFor(this.delegate.getOracleArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25225));
    } catch (SQLException e) {
      return (Datum[])postForAll(methodObject25225, onErrorForAll(methodObject25225, e));
    } 
  }
  
  public byte[] getBytes() {
    return this.delegate.getBytes();
  }
  
  public long getLastIndex() throws SQLException {
    try {
      preForAll(methodObject25243, this, new Object[0]);
      return ((Long)postForAll(methodObject25243, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getLastIndex()), this, (Map)this.proxyCache, methodObject25243))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject25243, onErrorForAll(methodObject25243, e))).longValue();
    } 
  }
  
  public void setLength(int arg0) {
    preForAll(methodObject25219, this, new Object[] { Integer.valueOf(arg0) });
    this.delegate.setLength(arg0);
  }
  
  public InputStream binaryStreamValue() throws SQLException {
    return this.delegate.binaryStreamValue();
  }
  
  public boolean getAutoBuffering() throws SQLException {
    try {
      preForAll(methodObject25236, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25236, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.getAutoBuffering()), this, (Map)this.proxyCache, methodObject25236))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25236, onErrorForAll(methodObject25236, e))).booleanValue();
    } 
  }
  
  public short[] getShortArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25287, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (short[])postForAll(methodObject25287, this.proxyFactory.proxyFor(this.delegate.getShortArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25287));
    } catch (SQLException e) {
      return (short[])postForAll(methodObject25287, onErrorForAll(methodObject25287, e));
    } 
  }
  
  public OracleConnection getOracleConnection() throws SQLException {
    return this.delegate.getOracleConnection();
  }
  
  public Object toJdbc() throws SQLException {
    try {
      preForAll(methodObject25280, this, new Object[0]);
      return postForAll(methodObject25280, this.proxyFactory.proxyFor(this.delegate.toJdbc(), this, (Map)this.proxyCache, methodObject25280));
    } catch (SQLException e) {
      return postForAll(methodObject25280, onErrorForAll(methodObject25280, e));
    } 
  }
  
  public String getBaseTypeName() throws SQLException {
    try {
      preForAll(methodObject25298, this, new Object[0]);
      return (String)postForAll(methodObject25298, this.proxyFactory.proxyFor(this.delegate.getBaseTypeName(), this, (Map)this.proxyCache, methodObject25298));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25298, onErrorForAll(methodObject25298, e));
    } 
  }
  
  public float[] getFloatArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25291, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return (float[])postForAll(methodObject25291, this.proxyFactory.proxyFor(this.delegate.getFloatArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25291));
    } catch (SQLException e) {
      return (float[])postForAll(methodObject25291, onErrorForAll(methodObject25291, e));
    } 
  }
  
  public boolean hasDataSeg() {
    preForAll(methodObject25233, this, new Object[0]);
    return ((Boolean)postForAll(methodObject25233, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.hasDataSeg()), this, (Map)this.proxyCache, methodObject25233))).booleanValue();
  }
  
  public void setPhysicalConnectionOf(Connection arg0) {
    this.delegate.setPhysicalConnectionOf((arg0 instanceof _Proxy_) ? ((_Proxy_<Connection>)arg0)._getDelegate_() : arg0);
  }
  
  public void setPrefixSegment(byte[] arg0) {
    preForAll(methodObject25230, this, new Object[] { arg0 });
    this.delegate.setPrefixSegment(arg0);
  }
  
  public boolean isConvertibleTo(Class arg0) {
    preForAll(methodObject25222, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject25222, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isConvertibleTo(arg0)), this, (Map)this.proxyCache, methodObject25222))).booleanValue();
  }
  
  public Date dateValue() throws SQLException {
    return this.delegate.dateValue();
  }
  
  public void setDatumArray(Datum[] arg0) {
    preForAll(methodObject25227, this, new Object[] { arg0 });
    this.delegate.setDatumArray(arg0);
  }
  
  public BigDecimal bigDecimalValue() throws SQLException {
    return this.delegate.bigDecimalValue();
  }
  
  public Object makeJdbcArray(int arg0) {
    preForAll(methodObject25223, this, new Object[] { Integer.valueOf(arg0) });
    return postForAll(methodObject25223, this.proxyFactory.proxyFor(this.delegate.makeJdbcArray(arg0), this, (Map)this.proxyCache, methodObject25223));
  }
  
  public OracleTypeMetaData getOracleMetaData() throws SQLException {
    try {
      preForAll(methodObject25281, this, new Object[0]);
      return (OracleTypeMetaData)postForAll(methodObject25281, this.proxyFactory.proxyFor(this.delegate.getOracleMetaData(), this, (Map)this.proxyCache, methodObject25281));
    } catch (SQLException e) {
      return (OracleTypeMetaData)postForAll(methodObject25281, onErrorForAll(methodObject25281, e));
    } 
  }
  
  public byte byteValue() throws SQLException {
    return this.delegate.byteValue();
  }
  
  public void setLocator(byte[] arg0) {
    preForAll(methodObject25229, this, new Object[] { arg0 });
    this.delegate.setLocator(arg0);
  }
  
  public Reader characterStreamValue() throws SQLException {
    return this.delegate.characterStreamValue();
  }
  
  public boolean getAutoIndexing() throws SQLException {
    try {
      preForAll(methodObject25239, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25239, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.getAutoIndexing()), this, (Map)this.proxyCache, methodObject25239))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25239, onErrorForAll(methodObject25239, e))).booleanValue();
    } 
  }
  
  public float floatValue() throws SQLException {
    return this.delegate.floatValue();
  }
  
  public Object getArray(long arg0, int arg1) throws SQLException {
    try {
      preForAll(methodObject25294, this, new Object[] { Long.valueOf(arg0), Integer.valueOf(arg1) });
      return postForAll(methodObject25294, this.proxyFactory.proxyFor(this.delegate.getArray(arg0, arg1), this, (Map)this.proxyCache, methodObject25294));
    } catch (SQLException e) {
      return postForAll(methodObject25294, onErrorForAll(methodObject25294, e));
    } 
  }
  
  public byte[] toBytes() throws SQLException {
    try {
      preForAll(methodObject25226, this, new Object[0]);
      return (byte[])postForAll(methodObject25226, this.proxyFactory.proxyFor(this.delegate.toBytes(), this, (Map)this.proxyCache, methodObject25226));
    } catch (SQLException e) {
      return (byte[])postForAll(methodObject25226, onErrorForAll(methodObject25226, e));
    } 
  }
  
  public InputStream getStream() throws SQLException {
    return this.delegate.getStream();
  }
  
  public long getLength() {
    return this.delegate.getLength();
  }
  
  public Time timeValue() throws SQLException {
    return this.delegate.timeValue();
  }
  
  public void setLastIndexOffset(long arg0, long arg1) throws SQLException {
    try {
      preForAll(methodObject25241, this, new Object[] { Long.valueOf(arg0), Long.valueOf(arg1) });
      this.delegate.setLastIndexOffset(arg0, arg1);
      return;
    } catch (SQLException e) {
      onErrorVoidForAll(methodObject25241, e);
      return;
    } 
  }
  
  public ResultSet getResultSet() throws SQLException {
    try {
      preForAll(methodObject25299, this, new Object[0]);
      return (ResultSet)postForAll(methodObject25299, this.proxyFactory.proxyFor(this.delegate.getResultSet(), this, (Map)this.proxyCache, methodObject25299));
    } catch (SQLException e) {
      return (ResultSet)postForAll(methodObject25299, onErrorForAll(methodObject25299, e));
    } 
  }
  
  public OracleConnection getConnection() throws SQLException {
    return this.delegate.getConnection();
  }
  
  public OracleArray _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleArray delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25285 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[] { long.class, int.class });
      methodObject25293 = Array.class.getDeclaredMethod("getArray", new Class[] { Map.class });
      methodObject25234 = OracleArray.class.getDeclaredMethod("isInline", new Class[0]);
      methodObject25248 = OracleArray.class.getDeclaredMethod("getImageLength", new Class[0]);
      methodObject25300 = Array.class.getDeclaredMethod("getResultSet", new Class[] { Map.class });
      methodObject25274 = OracleDatumWithConnection.class.getDeclaredMethod("getJavaSqlConnection", new Class[0]);
      methodObject25267 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[] { Calendar.class });
      methodObject25290 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[0]);
      methodObject25238 = OracleArray.class.getDeclaredMethod("setAutoIndexing", new Class[] { boolean.class });
      methodObject25228 = OracleArray.class.getDeclaredMethod("setObjArray", new Class[] { Object.class });
      methodObject25247 = OracleArray.class.getDeclaredMethod("getImageOffset", new Class[0]);
      methodObject25250 = OracleDatumWithConnection.class.getDeclaredMethod("booleanValue", new Class[0]);
      methodObject25301 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class });
      methodObject25269 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[] { Calendar.class });
      methodObject25279 = OracleArray.class.getDeclaredMethod("getSQLTypeName", new Class[0]);
      methodObject25263 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[] { Connection.class });
      methodObject25283 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[] { long.class, int.class });
      methodObject25282 = OracleArray.class.getDeclaredMethod("getIntArray", new Class[0]);
      methodObject25221 = OracleArray.class.getDeclaredMethod("getMap", new Class[0]);
      methodObject25268 = OracleDatumWithConnection.class.getDeclaredMethod("timestampValue", new Class[0]);
      methodObject25297 = Array.class.getDeclaredMethod("getBaseType", new Class[0]);
      methodObject25254 = OracleDatumWithConnection.class.getDeclaredMethod("intValue", new Class[0]);
      methodObject25284 = OracleArray.class.getDeclaredMethod("getDoubleArray", new Class[0]);
      methodObject25260 = OracleDatumWithConnection.class.getDeclaredMethod("setShareBytes", new Class[] { byte[].class });
      methodObject25262 = OracleDatumWithConnection.class.getDeclaredMethod("stringValue", new Class[0]);
      methodObject25240 = OracleArray.class.getDeclaredMethod("getAccessDirection", new Class[0]);
      methodObject25220 = OracleArray.class.getDeclaredMethod("getOffset", new Class[] { long.class });
      methodObject25296 = Array.class.getDeclaredMethod("free", new Class[0]);
      methodObject25295 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class, Map.class });
      methodObject25271 = OracleDatumWithConnection.class.getDeclaredMethod("asciiStreamValue", new Class[0]);
      methodObject25288 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[0]);
      methodObject25259 = OracleDatumWithConnection.class.getDeclaredMethod("shareBytes", new Class[0]);
      methodObject25252 = OracleDatumWithConnection.class.getDeclaredMethod("doubleValue", new Class[0]);
      methodObject25237 = OracleArray.class.getDeclaredMethod("setAutoIndexing", new Class[] { boolean.class, int.class });
      methodObject25232 = OracleArray.class.getDeclaredMethod("getLocator", new Class[0]);
      methodObject25231 = OracleArray.class.getDeclaredMethod("setPrefixFlag", new Class[] { byte.class });
      methodObject25244 = OracleArray.class.getDeclaredMethod("getLastOffset", new Class[0]);
      methodObject25286 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[0]);
      methodObject25235 = OracleArray.class.getDeclaredMethod("setAutoBuffering", new Class[] { boolean.class });
      methodObject25246 = OracleArray.class.getDeclaredMethod("setImageLength", new Class[] { long.class });
      methodObject25255 = OracleDatumWithConnection.class.getDeclaredMethod("longValue", new Class[0]);
      methodObject25245 = OracleArray.class.getDeclaredMethod("setImage", new Class[] { byte[].class, long.class, long.class });
      methodObject25278 = OracleArray.class.getDeclaredMethod("length", new Class[0]);
      methodObject25276 = OracleDatumWithConnection.class.getDeclaredMethod("getInternalConnection", new Class[0]);
      methodObject25218 = OracleArray.class.getDeclaredMethod("getDescriptor", new Class[0]);
      methodObject25224 = OracleArray.class.getDeclaredMethod("getOracleArray", new Class[0]);
      methodObject25292 = Array.class.getDeclaredMethod("getArray", new Class[0]);
      methodObject25289 = OracleArray.class.getDeclaredMethod("getLongArray", new Class[] { long.class, int.class });
      methodObject25258 = OracleDatumWithConnection.class.getDeclaredMethod("setBytes", new Class[] { byte[].class });
      methodObject25302 = Array.class.getDeclaredMethod("getResultSet", new Class[] { long.class, int.class, Map.class });
      methodObject25242 = OracleArray.class.getDeclaredMethod("setIndexOffset", new Class[] { long.class, long.class });
      methodObject25225 = OracleArray.class.getDeclaredMethod("getOracleArray", new Class[] { long.class, int.class });
      methodObject25249 = OracleDatumWithConnection.class.getDeclaredMethod("getBytes", new Class[0]);
      methodObject25243 = OracleArray.class.getDeclaredMethod("getLastIndex", new Class[0]);
      methodObject25219 = OracleArray.class.getDeclaredMethod("setLength", new Class[] { int.class });
      methodObject25272 = OracleDatumWithConnection.class.getDeclaredMethod("binaryStreamValue", new Class[0]);
      methodObject25236 = OracleArray.class.getDeclaredMethod("getAutoBuffering", new Class[0]);
      methodObject25287 = OracleArray.class.getDeclaredMethod("getShortArray", new Class[] { long.class, int.class });
      methodObject25275 = OracleDatumWithConnection.class.getDeclaredMethod("getOracleConnection", new Class[0]);
      methodObject25280 = OracleArray.class.getDeclaredMethod("toJdbc", new Class[0]);
      methodObject25298 = Array.class.getDeclaredMethod("getBaseTypeName", new Class[0]);
      methodObject25291 = OracleArray.class.getDeclaredMethod("getFloatArray", new Class[] { long.class, int.class });
      methodObject25233 = OracleArray.class.getDeclaredMethod("hasDataSeg", new Class[0]);
      methodObject25277 = OracleDatumWithConnection.class.getDeclaredMethod("setPhysicalConnectionOf", new Class[] { Connection.class });
      methodObject25230 = OracleArray.class.getDeclaredMethod("setPrefixSegment", new Class[] { byte[].class });
      methodObject25222 = OracleArray.class.getDeclaredMethod("isConvertibleTo", new Class[] { Class.class });
      methodObject25265 = OracleDatumWithConnection.class.getDeclaredMethod("dateValue", new Class[0]);
      methodObject25227 = OracleArray.class.getDeclaredMethod("setDatumArray", new Class[] { Datum[].class });
      methodObject25264 = OracleDatumWithConnection.class.getDeclaredMethod("bigDecimalValue", new Class[0]);
      methodObject25223 = OracleArray.class.getDeclaredMethod("makeJdbcArray", new Class[] { int.class });
      methodObject25281 = OracleArray.class.getDeclaredMethod("getOracleMetaData", new Class[0]);
      methodObject25251 = OracleDatumWithConnection.class.getDeclaredMethod("byteValue", new Class[0]);
      methodObject25229 = OracleArray.class.getDeclaredMethod("setLocator", new Class[] { byte[].class });
      methodObject25270 = OracleDatumWithConnection.class.getDeclaredMethod("characterStreamValue", new Class[0]);
      methodObject25239 = OracleArray.class.getDeclaredMethod("getAutoIndexing", new Class[0]);
      methodObject25253 = OracleDatumWithConnection.class.getDeclaredMethod("floatValue", new Class[0]);
      methodObject25294 = Array.class.getDeclaredMethod("getArray", new Class[] { long.class, int.class });
      methodObject25226 = OracleArray.class.getDeclaredMethod("toBytes", new Class[0]);
      methodObject25261 = OracleDatumWithConnection.class.getDeclaredMethod("getStream", new Class[0]);
      methodObject25256 = OracleDatumWithConnection.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject25266 = OracleDatumWithConnection.class.getDeclaredMethod("timeValue", new Class[0]);
      methodObject25241 = OracleArray.class.getDeclaredMethod("setLastIndexOffset", new Class[] { long.class, long.class });
      methodObject25299 = Array.class.getDeclaredMethod("getResultSet", new Class[0]);
      methodObject25257 = OracleDatumWithConnection.class.getDeclaredMethod("getConnection", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy(OracleArray paramOracleArray, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOracleArray;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableArray$2oracle$1jdbc$1internal$1OracleArray$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */