package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.sql.SQLName;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Struct$$$Proxy extends NonTxnReplayableBase implements OracleTypeMetaData.Struct, _Proxy_ {
  private OracleTypeMetaData.Struct delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25059;
  
  private static Method methodObject25064;
  
  private static Method methodObject25065;
  
  private static Method methodObject25054;
  
  private static Method methodObject25063;
  
  private static Method methodObject25055;
  
  private static Method methodObject25061;
  
  private static Method methodObject25056;
  
  private static Method methodObject25057;
  
  private static Method methodObject25062;
  
  private static Method methodObject25052;
  
  private static Method methodObject25053;
  
  private static Method methodObject25051;
  
  private static Method methodObject25060;
  
  private static Method methodObject25058;
  
  public String[] getSubtypeNames() throws SQLException {
    try {
      preForAll(methodObject25059, this, new Object[0]);
      return (String[])postForAll(methodObject25059, this.proxyFactory.proxyFor(this.delegate.getSubtypeNames(), this, (Map)this.proxyCache, methodObject25059));
    } catch (SQLException e) {
      return (String[])postForAll(methodObject25059, onErrorForAll(methodObject25059, e));
    } 
  }
  
  public SQLName getSQLName() throws SQLException {
    try {
      preForAll(methodObject25064, this, new Object[0]);
      return (SQLName)postForAll(methodObject25064, this.proxyFactory.proxyFor(this.delegate.getSQLName(), this, (Map)this.proxyCache, methodObject25064));
    } catch (SQLException e) {
      return (SQLName)postForAll(methodObject25064, onErrorForAll(methodObject25064, e));
    } 
  }
  
  public String getTypeCodeName() throws SQLException {
    try {
      preForAll(methodObject25065, this, new Object[0]);
      return (String)postForAll(methodObject25065, this.proxyFactory.proxyFor(this.delegate.getTypeCodeName(), this, (Map)this.proxyCache, methodObject25065));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25065, onErrorForAll(methodObject25065, e));
    } 
  }
  
  public ResultSetMetaData getMetaData() throws SQLException {
    try {
      preForAll(methodObject25054, this, new Object[0]);
      return (ResultSetMetaData)postForAll(methodObject25054, this.proxyFactory.proxyFor(this.delegate.getMetaData(), this, (Map)this.proxyCache, methodObject25054));
    } catch (SQLException e) {
      return (ResultSetMetaData)postForAll(methodObject25054, onErrorForAll(methodObject25054, e));
    } 
  }
  
  public OracleTypeMetaData.Kind getKind() {
    preForAll(methodObject25063, this, new Object[0]);
    return (OracleTypeMetaData.Kind)postForAll(methodObject25063, this.proxyFactory.proxyFor(this.delegate.getKind(), this, (Map)this.proxyCache, methodObject25063));
  }
  
  public boolean isFinalType() throws SQLException {
    try {
      preForAll(methodObject25055, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25055, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isFinalType()), this, (Map)this.proxyCache, methodObject25055))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25055, onErrorForAll(methodObject25055, e))).booleanValue();
    } 
  }
  
  public int getTypeCode() throws SQLException {
    try {
      preForAll(methodObject25061, this, new Object[0]);
      return ((Integer)postForAll(methodObject25061, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeCode()), this, (Map)this.proxyCache, methodObject25061))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25061, onErrorForAll(methodObject25061, e))).intValue();
    } 
  }
  
  public boolean isSubtype() throws SQLException {
    try {
      preForAll(methodObject25056, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25056, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isSubtype()), this, (Map)this.proxyCache, methodObject25056))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25056, onErrorForAll(methodObject25056, e))).booleanValue();
    } 
  }
  
  public String getSupertypeName() throws SQLException {
    try {
      preForAll(methodObject25057, this, new Object[0]);
      return (String)postForAll(methodObject25057, this.proxyFactory.proxyFor(this.delegate.getSupertypeName(), this, (Map)this.proxyCache, methodObject25057));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25057, onErrorForAll(methodObject25057, e));
    } 
  }
  
  public String getSchemaName() throws SQLException {
    try {
      preForAll(methodObject25062, this, new Object[0]);
      return (String)postForAll(methodObject25062, this.proxyFactory.proxyFor(this.delegate.getSchemaName(), this, (Map)this.proxyCache, methodObject25062));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25062, onErrorForAll(methodObject25062, e));
    } 
  }
  
  public boolean isInstantiable() throws SQLException {
    try {
      preForAll(methodObject25052, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25052, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isInstantiable()), this, (Map)this.proxyCache, methodObject25052))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25052, onErrorForAll(methodObject25052, e))).booleanValue();
    } 
  }
  
  public int getTypeVersion() throws SQLException {
    try {
      preForAll(methodObject25053, this, new Object[0]);
      return ((Integer)postForAll(methodObject25053, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeVersion()), this, (Map)this.proxyCache, methodObject25053))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25053, onErrorForAll(methodObject25053, e))).intValue();
    } 
  }
  
  public int getLength() throws SQLException {
    try {
      preForAll(methodObject25051, this, new Object[0]);
      return ((Integer)postForAll(methodObject25051, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getLength()), this, (Map)this.proxyCache, methodObject25051))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25051, onErrorForAll(methodObject25051, e))).intValue();
    } 
  }
  
  public String getName() throws SQLException {
    try {
      preForAll(methodObject25060, this, new Object[0]);
      return (String)postForAll(methodObject25060, this.proxyFactory.proxyFor(this.delegate.getName(), this, (Map)this.proxyCache, methodObject25060));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25060, onErrorForAll(methodObject25060, e));
    } 
  }
  
  public int getLocalAttributeCount() throws SQLException {
    try {
      preForAll(methodObject25058, this, new Object[0]);
      return ((Integer)postForAll(methodObject25058, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getLocalAttributeCount()), this, (Map)this.proxyCache, methodObject25058))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25058, onErrorForAll(methodObject25058, e))).intValue();
    } 
  }
  
  public OracleTypeMetaData.Struct _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleTypeMetaData.Struct delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25059 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getSubtypeNames", new Class[0]);
      methodObject25064 = OracleTypeMetaData.class.getDeclaredMethod("getSQLName", new Class[0]);
      methodObject25065 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCodeName", new Class[0]);
      methodObject25054 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getMetaData", new Class[0]);
      methodObject25063 = OracleTypeMetaData.class.getDeclaredMethod("getKind", new Class[0]);
      methodObject25055 = OracleTypeMetaData.Struct.class.getDeclaredMethod("isFinalType", new Class[0]);
      methodObject25061 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCode", new Class[0]);
      methodObject25056 = OracleTypeMetaData.Struct.class.getDeclaredMethod("isSubtype", new Class[0]);
      methodObject25057 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getSupertypeName", new Class[0]);
      methodObject25062 = OracleTypeMetaData.class.getDeclaredMethod("getSchemaName", new Class[0]);
      methodObject25052 = OracleTypeMetaData.Struct.class.getDeclaredMethod("isInstantiable", new Class[0]);
      methodObject25053 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getTypeVersion", new Class[0]);
      methodObject25051 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getLength", new Class[0]);
      methodObject25060 = OracleTypeMetaData.class.getDeclaredMethod("getName", new Class[0]);
      methodObject25058 = OracleTypeMetaData.Struct.class.getDeclaredMethod("getLocalAttributeCount", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Struct$$$Proxy(OracleTypeMetaData.Struct paramStruct, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramStruct;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Struct$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */