/*     */ package oracle.jdbc.proxy;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MethodSignature
/*     */ {
/*     */   private final String name;
/*     */   private final Class[] parameterTypes;
/*     */   private final Class returnType;
/*     */   private Integer hashCode;
/*     */   
/*     */   MethodSignature(Method paramMethod) {
/*  92 */     this.hashCode = null; this.name = paramMethod.getName(); this.parameterTypes = paramMethod.getParameterTypes(); this.returnType = paramMethod.getReturnType(); } MethodSignature(String paramString, Class[] paramArrayOfClass, Class paramClass) { this.hashCode = null;
/*     */     this.name = paramString;
/*     */     this.parameterTypes = paramArrayOfClass;
/*     */     this.returnType = paramClass; }
/*  96 */   public int hashCode() { if (null == this.hashCode) {
/*     */       
/*  98 */       this.hashCode = new Integer(23);
/*  99 */       this.hashCode = Integer.valueOf(HashUtil.hash(this.hashCode.intValue(), this.name));
/* 100 */       this.hashCode = Integer.valueOf(HashUtil.hash(this.hashCode.intValue(), this.parameterTypes));
/*     */     } 
/* 102 */     return this.hashCode.intValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getName() {
/* 110 */     return this.name;
/*     */   } public boolean equals(Object paramObject) { if (null == paramObject)
/*     */       return false;  if (!(paramObject instanceof MethodSignature))
/*     */       return false;  MethodSignature methodSignature = (MethodSignature)paramObject; if (this == methodSignature)
/*     */       return true;  if (!this.name.equals(methodSignature.name))
/*     */       return false;  if (!Arrays.deepEquals((Object[])this.parameterTypes, (Object[])methodSignature.parameterTypes))
/*     */       return false;  if (null != this.returnType && null != methodSignature.returnType && !this.returnType.equals(methodSignature.returnType))
/*     */       throw new RuntimeException("methods \"" + this.name + "\" have the same signature \"" + this.parameterTypes + "\" but different return types: \"" + this.returnType + "\" and \"" + methodSignature.returnType + '"'); 
/* 118 */     return true; } Class[] getParameterTypes() { return this.parameterTypes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class getReturnType() {
/* 126 */     return this.returnType;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\MethodSignature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */