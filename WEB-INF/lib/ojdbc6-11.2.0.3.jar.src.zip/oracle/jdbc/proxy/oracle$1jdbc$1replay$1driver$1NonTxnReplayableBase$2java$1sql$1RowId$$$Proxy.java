package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.RowId;
import java.util.Map;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1RowId$$$Proxy extends NonTxnReplayableBase implements RowId, _Proxy_ {
  private RowId delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject24940;
  
  private static Method methodObject24941;
  
  private static Method methodObject24939;
  
  private static Method methodObject24942;
  
  public boolean equals(Object arg0) {
    preForAll(methodObject24940, this, new Object[] { arg0 });
    return ((Boolean)postForAll(methodObject24940, this.proxyFactory.proxyFor(Boolean.valueOf(super.equals((arg0 instanceof _Proxy_) ? ((_Proxy_)arg0)._getDelegate_() : arg0)), this, (Map)this.proxyCache, methodObject24940))).booleanValue();
  }
  
  public String toString() {
    preForAll(methodObject24941, this, new Object[0]);
    return (String)postForAll(methodObject24941, this.proxyFactory.proxyFor(super.toString(), this, (Map)this.proxyCache, methodObject24941));
  }
  
  public int hashCode() {
    preForAll(methodObject24939, this, new Object[0]);
    return ((Integer)postForAll(methodObject24939, this.proxyFactory.proxyFor(Integer.valueOf(super.hashCode()), this, (Map)this.proxyCache, methodObject24939))).intValue();
  }
  
  public byte[] getBytes() {
    preForAll(methodObject24942, this, new Object[0]);
    return (byte[])postForAll(methodObject24942, this.proxyFactory.proxyFor(this.delegate.getBytes(), this, (Map)this.proxyCache, methodObject24942));
  }
  
  public RowId _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(RowId delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject24940 = RowId.class.getDeclaredMethod("equals", new Class[] { Object.class });
      methodObject24941 = RowId.class.getDeclaredMethod("toString", new Class[0]);
      methodObject24939 = RowId.class.getDeclaredMethod("hashCode", new Class[0]);
      methodObject24942 = RowId.class.getDeclaredMethod("getBytes", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1RowId$$$Proxy(RowId paramRowId, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramRowId;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2java$1sql$1RowId$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */