package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.sql.SQLName;

public class oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Opaque$$$Proxy extends NonTxnReplayableBase implements OracleTypeMetaData.Opaque, _Proxy_ {
  private OracleTypeMetaData.Opaque delegate;
  
  private final Object creator;
  
  private final ProxyFactory proxyFactory;
  
  private final Map<Object, Object> proxyCache;
  
  private static Method methodObject25042;
  
  private static Method methodObject25048;
  
  private static Method methodObject25041;
  
  private static Method methodObject25046;
  
  private static Method methodObject25044;
  
  private static Method methodObject25043;
  
  private static Method methodObject25040;
  
  private static Method methodObject25049;
  
  private static Method methodObject25047;
  
  private static Method methodObject25050;
  
  private static Method methodObject25045;
  
  public boolean isModeledInC() throws SQLException {
    try {
      preForAll(methodObject25042, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25042, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isModeledInC()), this, (Map)this.proxyCache, methodObject25042))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25042, onErrorForAll(methodObject25042, e))).booleanValue();
    } 
  }
  
  public OracleTypeMetaData.Kind getKind() {
    preForAll(methodObject25048, this, new Object[0]);
    return (OracleTypeMetaData.Kind)postForAll(methodObject25048, this.proxyFactory.proxyFor(this.delegate.getKind(), this, (Map)this.proxyCache, methodObject25048));
  }
  
  public boolean isTrustedLibrary() throws SQLException {
    try {
      preForAll(methodObject25041, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25041, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.isTrustedLibrary()), this, (Map)this.proxyCache, methodObject25041))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25041, onErrorForAll(methodObject25041, e))).booleanValue();
    } 
  }
  
  public int getTypeCode() throws SQLException {
    try {
      preForAll(methodObject25046, this, new Object[0]);
      return ((Integer)postForAll(methodObject25046, this.proxyFactory.proxyFor(Integer.valueOf(this.delegate.getTypeCode()), this, (Map)this.proxyCache, methodObject25046))).intValue();
    } catch (SQLException e) {
      return ((Integer)postForAll(methodObject25046, onErrorForAll(methodObject25046, e))).intValue();
    } 
  }
  
  public boolean hasFixedSize() throws SQLException {
    try {
      preForAll(methodObject25044, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25044, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.hasFixedSize()), this, (Map)this.proxyCache, methodObject25044))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25044, onErrorForAll(methodObject25044, e))).booleanValue();
    } 
  }
  
  public boolean hasUnboundedSize() throws SQLException {
    try {
      preForAll(methodObject25043, this, new Object[0]);
      return ((Boolean)postForAll(methodObject25043, this.proxyFactory.proxyFor(Boolean.valueOf(this.delegate.hasUnboundedSize()), this, (Map)this.proxyCache, methodObject25043))).booleanValue();
    } catch (SQLException e) {
      return ((Boolean)postForAll(methodObject25043, onErrorForAll(methodObject25043, e))).booleanValue();
    } 
  }
  
  public long getMaxLength() throws SQLException {
    try {
      preForAll(methodObject25040, this, new Object[0]);
      return ((Long)postForAll(methodObject25040, this.proxyFactory.proxyFor(Long.valueOf(this.delegate.getMaxLength()), this, (Map)this.proxyCache, methodObject25040))).longValue();
    } catch (SQLException e) {
      return ((Long)postForAll(methodObject25040, onErrorForAll(methodObject25040, e))).longValue();
    } 
  }
  
  public SQLName getSQLName() throws SQLException {
    try {
      preForAll(methodObject25049, this, new Object[0]);
      return (SQLName)postForAll(methodObject25049, this.proxyFactory.proxyFor(this.delegate.getSQLName(), this, (Map)this.proxyCache, methodObject25049));
    } catch (SQLException e) {
      return (SQLName)postForAll(methodObject25049, onErrorForAll(methodObject25049, e));
    } 
  }
  
  public String getSchemaName() throws SQLException {
    try {
      preForAll(methodObject25047, this, new Object[0]);
      return (String)postForAll(methodObject25047, this.proxyFactory.proxyFor(this.delegate.getSchemaName(), this, (Map)this.proxyCache, methodObject25047));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25047, onErrorForAll(methodObject25047, e));
    } 
  }
  
  public String getTypeCodeName() throws SQLException {
    try {
      preForAll(methodObject25050, this, new Object[0]);
      return (String)postForAll(methodObject25050, this.proxyFactory.proxyFor(this.delegate.getTypeCodeName(), this, (Map)this.proxyCache, methodObject25050));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25050, onErrorForAll(methodObject25050, e));
    } 
  }
  
  public String getName() throws SQLException {
    try {
      preForAll(methodObject25045, this, new Object[0]);
      return (String)postForAll(methodObject25045, this.proxyFactory.proxyFor(this.delegate.getName(), this, (Map)this.proxyCache, methodObject25045));
    } catch (SQLException e) {
      return (String)postForAll(methodObject25045, onErrorForAll(methodObject25045, e));
    } 
  }
  
  public OracleTypeMetaData.Opaque _getDelegate_() {
    return this.delegate;
  }
  
  public Object getDelegate() {
    return this.delegate;
  }
  
  public void setDelegate(OracleTypeMetaData.Opaque delegate) {
    this.proxyFactory.updateDelegate(this, this.delegate, delegate);
    this.delegate = delegate;
  }
  
  public Object getCreator() {
    return this.creator;
  }
  
  static {
    try {
      methodObject25042 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("isModeledInC", new Class[0]);
      methodObject25048 = OracleTypeMetaData.class.getDeclaredMethod("getKind", new Class[0]);
      methodObject25041 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("isTrustedLibrary", new Class[0]);
      methodObject25046 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCode", new Class[0]);
      methodObject25044 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("hasFixedSize", new Class[0]);
      methodObject25043 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("hasUnboundedSize", new Class[0]);
      methodObject25040 = OracleTypeMetaData.Opaque.class.getDeclaredMethod("getMaxLength", new Class[0]);
      methodObject25049 = OracleTypeMetaData.class.getDeclaredMethod("getSQLName", new Class[0]);
      methodObject25047 = OracleTypeMetaData.class.getDeclaredMethod("getSchemaName", new Class[0]);
      methodObject25050 = OracleTypeMetaData.class.getDeclaredMethod("getTypeCodeName", new Class[0]);
      methodObject25045 = OracleTypeMetaData.class.getDeclaredMethod("getName", new Class[0]);
    } catch (Throwable throwable) {
      throw new RuntimeException(throwable);
    } 
  }
  
  public oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Opaque$$$Proxy(OracleTypeMetaData.Opaque paramOpaque, Object paramObject, ProxyFactory paramProxyFactory, Map<Object, Object> paramMap) {
    this.delegate = paramOpaque;
    this.creator = paramObject;
    this.proxyFactory = paramProxyFactory;
    this.proxyCache = paramMap;
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\proxy\oracle$1jdbc$1replay$1driver$1NonTxnReplayableBase$2oracle$1jdbc$1OracleTypeMetaData$Opaque$$$Proxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */