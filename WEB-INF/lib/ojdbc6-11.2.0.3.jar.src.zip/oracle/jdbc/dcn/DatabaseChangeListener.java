package oracle.jdbc.dcn;

import java.util.EventListener;

public interface DatabaseChangeListener extends EventListener {
  void onDatabaseChangeNotification(DatabaseChangeEvent paramDatabaseChangeEvent);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\dcn\DatabaseChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */