/*     */ package oracle.jdbc.dcn;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TableChangeDescription
/*     */ {
/*     */   EnumSet<TableOperation> getTableOperations();
/*     */   
/*     */   String getTableName();
/*     */   
/*     */   int getObjectNumber();
/*     */   
/*     */   RowChangeDescription[] getRowChangeDescription();
/*     */   
/*     */   public enum TableOperation
/*     */   {
/*  59 */     ALL_ROWS(1),
/*     */ 
/*     */ 
/*     */     
/*  63 */     INSERT(2),
/*     */ 
/*     */ 
/*     */     
/*  67 */     UPDATE(4),
/*     */ 
/*     */ 
/*     */     
/*  71 */     DELETE(8),
/*     */ 
/*     */ 
/*     */     
/*  75 */     ALTER(16),
/*     */ 
/*     */ 
/*     */     
/*  79 */     DROP(32);
/*     */     private final int code;
/*     */     
/*     */     TableOperation(int param1Int1) {
/*  83 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  90 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final EnumSet<TableOperation> getTableOperations(int param1Int) {
/*  97 */       EnumSet<TableOperation> enumSet = EnumSet.noneOf(TableOperation.class);
/*  98 */       if ((param1Int & ALL_ROWS.getCode()) != 0)
/*  99 */         enumSet.add(ALL_ROWS); 
/* 100 */       if ((param1Int & INSERT.getCode()) != 0)
/* 101 */         enumSet.add(INSERT); 
/* 102 */       if ((param1Int & UPDATE.getCode()) != 0)
/* 103 */         enumSet.add(UPDATE); 
/* 104 */       if ((param1Int & DELETE.getCode()) != 0)
/* 105 */         enumSet.add(DELETE); 
/* 106 */       if ((param1Int & ALTER.getCode()) != 0)
/* 107 */         enumSet.add(ALTER); 
/* 108 */       if ((param1Int & DROP.getCode()) != 0)
/* 109 */         enumSet.add(DROP); 
/* 110 */       return enumSet;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\dcn\TableChangeDescription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */