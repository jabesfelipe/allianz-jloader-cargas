/*     */ package oracle.jdbc.dcn;
/*     */ 
/*     */ import java.util.EventObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DatabaseChangeEvent
/*     */   extends EventObject
/*     */ {
/*     */   protected DatabaseChangeEvent(Object paramObject) {
/*  51 */     super(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum EventType
/*     */   {
/*  61 */     NONE(0),
/*     */ 
/*     */ 
/*     */     
/*  65 */     STARTUP(1),
/*     */ 
/*     */ 
/*     */     
/*  69 */     SHUTDOWN(2),
/*     */ 
/*     */ 
/*     */     
/*  73 */     SHUTDOWN_ANY(3),
/*     */ 
/*     */ 
/*     */     
/*  77 */     DEREG(5),
/*     */ 
/*     */ 
/*     */     
/*  81 */     OBJCHANGE(6),
/*     */ 
/*     */ 
/*     */     
/*  85 */     QUERYCHANGE(7);
/*     */     
/*     */     private final int code;
/*     */     
/*     */     EventType(int param1Int1) {
/*  90 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  98 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final EventType getEventType(int param1Int) {
/* 105 */       if (param1Int == STARTUP.getCode())
/* 106 */         return STARTUP; 
/* 107 */       if (param1Int == SHUTDOWN.getCode())
/* 108 */         return SHUTDOWN; 
/* 109 */       if (param1Int == SHUTDOWN_ANY.getCode())
/* 110 */         return SHUTDOWN_ANY; 
/* 111 */       if (param1Int == DEREG.getCode())
/* 112 */         return DEREG; 
/* 113 */       if (param1Int == OBJCHANGE.getCode())
/* 114 */         return OBJCHANGE; 
/* 115 */       if (param1Int == QUERYCHANGE.getCode()) {
/* 116 */         return QUERYCHANGE;
/*     */       }
/* 118 */       return NONE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum AdditionalEventType
/*     */   {
/* 133 */     NONE(0),
/*     */ 
/*     */ 
/*     */     
/* 137 */     TIMEOUT(1),
/*     */ 
/*     */ 
/*     */     
/* 141 */     GROUPING(2);
/*     */     
/*     */     private final int code;
/*     */ 
/*     */     
/*     */     AdditionalEventType(int param1Int1) {
/* 147 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/* 155 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final AdditionalEventType getEventType(int param1Int) {
/* 162 */       if (param1Int == TIMEOUT.getCode())
/* 163 */         return TIMEOUT; 
/* 164 */       if (param1Int == GROUPING.getCode()) {
/* 165 */         return GROUPING;
/*     */       }
/* 167 */       return NONE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 258 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */   public abstract EventType getEventType();
/*     */   
/*     */   public abstract AdditionalEventType getAdditionalEventType();
/*     */   
/*     */   public abstract TableChangeDescription[] getTableChangeDescription();
/*     */   
/*     */   public abstract QueryChangeDescription[] getQueryChangeDescription();
/*     */   
/*     */   public abstract String getConnectionInformation();
/*     */   
/*     */   public abstract String getDatabaseName();
/*     */   
/*     */   public abstract int getRegistrationId();
/*     */   
/*     */   public abstract long getRegId();
/*     */   
/*     */   public abstract byte[] getTransactionId();
/*     */   
/*     */   public abstract String getTransactionId(boolean paramBoolean);
/*     */   
/*     */   public abstract String toString();
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\dcn\DatabaseChangeEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */