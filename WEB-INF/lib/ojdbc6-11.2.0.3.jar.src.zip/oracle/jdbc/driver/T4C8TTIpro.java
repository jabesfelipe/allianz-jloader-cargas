/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4C8TTIpro
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   short svrCharSet;
/*     */   short svrCharSetElem;
/*     */   byte svrFlags;
/*     */   byte[] proSvrStr;
/*     */   short proSvrVer;
/*  67 */   short oVersion = -1;
/*     */ 
/*     */   
/*     */   boolean svrInfoAvailable = false;
/*     */   
/*  72 */   byte[] proCliVerTTC8 = new byte[] { 6, 5, 4, 3, 2, 1, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   byte[] proCliStrTTC8 = new byte[] { 74, 97, 118, 97, 95, 84, 84, 67, 45, 56, 46, 50, 46, 48, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   short NCHAR_CHARSET = 0;
/*     */   
/*  87 */   byte[] runtimeCapabilities = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4C8TTIpro(T4CConnection paramT4CConnection) throws SQLException, IOException {
/*  98 */     super(paramT4CConnection, (byte)1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] receive() throws SQLException, IOException {
/*     */     SQLException sQLException;
/* 129 */     if (this.meg.unmarshalUB1() != 1) {
/*     */       
/* 131 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 132 */       sQLException1.fillInStackTrace();
/* 133 */       throw sQLException1;
/*     */     } 
/*     */     
/* 136 */     this.proSvrVer = this.meg.unmarshalUB1();
/* 137 */     this.meg.proSvrVer = this.proSvrVer;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     switch (this.proSvrVer) {
/*     */ 
/*     */       
/*     */       case 4:
/* 146 */         this.oVersion = 7230;
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 152 */         this.oVersion = 8030;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 6:
/* 157 */         this.oVersion = 8100;
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 163 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 444);
/* 164 */         sQLException.fillInStackTrace();
/* 165 */         throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 169 */     this.meg.unmarshalUB1();
/*     */     
/* 171 */     this.proSvrStr = this.meg.unmarshalTEXT(50);
/* 172 */     this.oVersion = getOracleVersion();
/*     */ 
/*     */     
/* 175 */     this.svrCharSet = (short)this.meg.unmarshalUB2();
/* 176 */     this.svrFlags = (byte)this.meg.unmarshalUB1();
/*     */ 
/*     */     
/* 179 */     if ((this.svrCharSetElem = (short)this.meg.unmarshalUB2()) > 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       this.meg.unmarshalNBytes(this.svrCharSetElem * 5);
/*     */     }
/*     */     
/* 188 */     this.svrInfoAvailable = true;
/*     */ 
/*     */     
/* 191 */     if (this.proSvrVer < 5) {
/* 192 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     byte b = this.meg.types.getRep((byte)1);
/* 199 */     this.meg.types.setRep((byte)1, (byte)0);
/* 200 */     int i = this.meg.unmarshalUB2();
/*     */     
/* 202 */     this.meg.types.setRep((byte)1, b);
/*     */     
/* 204 */     byte[] arrayOfByte1 = this.meg.unmarshalNBytes(i);
/*     */ 
/*     */     
/* 207 */     int j = 6 + (arrayOfByte1[5] & 0xFF) + (arrayOfByte1[6] & 0xFF);
/*     */     
/* 209 */     this.NCHAR_CHARSET = (short)((arrayOfByte1[j + 3] & 0xFF) << 8);
/* 210 */     this.NCHAR_CHARSET = (short)(this.NCHAR_CHARSET | (short)(arrayOfByte1[j + 4] & 0xFF));
/*     */     
/* 212 */     if (this.proSvrVer < 6) {
/* 213 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 217 */     short s = this.meg.unmarshalUB1();
/* 218 */     byte[] arrayOfByte2 = new byte[s]; byte b1;
/* 219 */     for (b1 = 0; b1 < s; b1++) {
/* 220 */       arrayOfByte2[b1] = (byte)this.meg.unmarshalUB1();
/*     */     }
/*     */     
/* 223 */     s = this.meg.unmarshalUB1();
/* 224 */     if (s > 0) {
/*     */       
/* 226 */       this.runtimeCapabilities = new byte[s];
/* 227 */       for (b1 = 0; b1 < s; b1++) {
/* 228 */         this.runtimeCapabilities[b1] = (byte)this.meg.unmarshalUB1();
/*     */       }
/*     */     } 
/* 231 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getOracleVersion() {
/* 243 */     return this.oVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getServerRuntimeCapabilities() {
/* 250 */     return this.runtimeCapabilities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getCharacterSet() {
/* 262 */     return this.svrCharSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getncharCHARSET() {
/* 269 */     return this.NCHAR_CHARSET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte getFlags() {
/* 281 */     return this.svrFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws SQLException, IOException {
/* 288 */     marshalTTCcode();
/*     */     
/* 290 */     this.meg.marshalB1Array(this.proCliVerTTC8);
/* 291 */     this.meg.marshalB1Array(this.proCliStrTTC8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void printServerInfo() {
/* 305 */     if (this.svrInfoAvailable) {
/*     */       
/* 307 */       byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 312 */       StringWriter stringWriter = new StringWriter();
/*     */       
/* 314 */       stringWriter.write("Protocol string  =");
/*     */       
/* 316 */       while (b < this.proSvrStr.length) {
/* 317 */         stringWriter.write((char)this.proSvrStr[b++]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 334 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4C8TTIpro.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */