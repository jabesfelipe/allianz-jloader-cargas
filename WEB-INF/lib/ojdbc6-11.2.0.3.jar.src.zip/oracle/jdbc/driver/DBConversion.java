/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.util.RepConversion;
/*      */ import oracle.sql.CharacterSet;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DBConversion
/*      */ {
/*      */   public static final boolean DO_CONVERSION_WITH_REPLACEMENT = true;
/*      */   public static final short ORACLE8_PROD_VERSION = 8030;
/*      */   protected short serverNCharSetId;
/*      */   protected short serverCharSetId;
/*      */   protected short clientCharSetId;
/*      */   protected CharacterSet serverCharSet;
/*      */   protected CharacterSet serverNCharSet;
/*      */   protected CharacterSet clientCharSet;
/*      */   protected CharacterSet asciiCharSet;
/*      */   protected boolean isServerCharSetFixedWidth;
/*      */   protected boolean isServerNCharSetFixedWidth;
/*      */   protected int c2sNlsRatio;
/*      */   protected int s2cNlsRatio;
/*      */   protected int sMaxCharSize;
/*      */   protected int cMaxCharSize;
/*      */   protected int maxNCharSize;
/*      */   protected boolean isServerCSMultiByte;
/*      */   private boolean isStrictASCIIConversion;
/*      */   public static final short DBCS_CHARSET = -1;
/*      */   public static final short UCS2_CHARSET = -5;
/*      */   public static final short ASCII_CHARSET = 1;
/*      */   public static final short ISO_LATIN_1_CHARSET = 31;
/*      */   public static final short AL24UTFFSS_CHARSET = 870;
/*      */   public static final short UTF8_CHARSET = 871;
/*      */   public static final short AL32UTF8_CHARSET = 873;
/*      */   public static final short AL16UTF16_CHARSET = 2000;
/*      */   
/*      */   public DBConversion(short paramShort1, short paramShort2, short paramShort3, boolean paramBoolean) throws SQLException {
/*  117 */     this.isStrictASCIIConversion = paramBoolean;
/*  118 */     if (paramShort2 != -1)
/*      */     {
/*  120 */       init(paramShort1, paramShort2, paramShort3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DBConversion(short paramShort1, short paramShort2, short paramShort3) throws SQLException {
/*  129 */     this(paramShort1, paramShort2, paramShort3, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void init(short paramShort1, short paramShort2, short paramShort3) throws SQLException {
/*  140 */     switch (paramShort2) {
/*      */       case -5:
/*      */       case 1:
/*      */       case 2:
/*      */       case 31:
/*      */       case 178:
/*      */       case 870:
/*      */       case 871:
/*      */       case 873:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  162 */         unexpectedCharset(paramShort2);
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  167 */     this.serverCharSetId = paramShort1;
/*  168 */     this.clientCharSetId = paramShort2;
/*  169 */     this.serverCharSet = CharacterSet.make(this.serverCharSetId);
/*      */     
/*  171 */     this.serverNCharSetId = paramShort3;
/*  172 */     this.serverNCharSet = CharacterSet.make(this.serverNCharSetId);
/*      */     
/*  174 */     this.clientCharSet = CharacterSet.make(this.clientCharSetId);
/*      */     
/*  176 */     this.c2sNlsRatio = CharacterSetMetaData.getRatio(paramShort1, paramShort2);
/*  177 */     this.s2cNlsRatio = CharacterSetMetaData.getRatio(paramShort2, paramShort1);
/*  178 */     this.sMaxCharSize = CharacterSetMetaData.getRatio(paramShort1, 1);
/*  179 */     this.cMaxCharSize = CharacterSetMetaData.getRatio(paramShort2, 1);
/*  180 */     this.maxNCharSize = CharacterSetMetaData.getRatio(paramShort3, 1);
/*      */     
/*  182 */     findFixedWidthInfo();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void findFixedWidthInfo() throws SQLException {
/*  193 */     this.isServerCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(this.serverCharSetId);
/*  194 */     this.isServerNCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(this.serverNCharSetId);
/*  195 */     this.isServerCSMultiByte = (this.sMaxCharSize > 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getServerCharSetId() {
/*  207 */     return this.serverCharSetId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getNCharSetId() {
/*  219 */     return this.serverNCharSetId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean IsNCharFixedWith() {
/*  228 */     return (this.serverNCharSetId == 2000);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getClientCharSet() {
/*  243 */     if (this.clientCharSetId == -1) {
/*  244 */       return this.serverCharSetId;
/*      */     }
/*  246 */     return this.clientCharSetId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterSet getDbCharSetObj() {
/*  260 */     return this.serverCharSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterSet getDriverCharSetObj() {
/*  275 */     return this.clientCharSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterSet getDriverNCharSetObj() {
/*  283 */     return this.serverNCharSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final short findDriverCharSet(short paramShort1, short paramShort2) {
/*  346 */     short s = 0;
/*      */     
/*  348 */     switch (paramShort1)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/*      */       case 31:
/*      */       case 178:
/*      */       case 873:
/*  362 */         s = paramShort1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  373 */         return s; }  s = (paramShort2 >= 8030) ? 871 : 870; return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final byte[] stringToDriverCharBytes(String paramString, short paramShort) throws SQLException {
/*  408 */     if (paramString == null)
/*      */     {
/*  410 */       return null;
/*      */     }
/*      */     
/*  413 */     byte[] arrayOfByte = null;
/*      */     
/*  415 */     switch (paramShort)
/*      */     
/*      */     { 
/*      */       
/*      */       case -5:
/*      */       case 2000:
/*  421 */         arrayOfByte = CharacterSet.stringToAL16UTF16Bytes(paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  459 */         return arrayOfByte;case 1: case 2: arrayOfByte = CharacterSet.stringToASCII(paramString); return arrayOfByte;case 870: case 871: arrayOfByte = CharacterSet.stringToUTF(paramString); return arrayOfByte;case 873: arrayOfByte = CharacterSet.stringToAL32UTF8(paramString); return arrayOfByte; }  unexpectedCharset(paramShort); return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] StringToCharBytes(String paramString) throws SQLException {
/*  481 */     if (paramString.length() == 0) {
/*  482 */       return null;
/*      */     }
/*  484 */     switch (this.clientCharSetId) {
/*      */ 
/*      */       
/*      */       case -1:
/*  488 */         return this.serverCharSet.convertWithReplacement(paramString);
/*      */       
/*      */       case 2:
/*      */       case 31:
/*      */       case 178:
/*  493 */         return this.clientCharSet.convertWithReplacement(paramString);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  501 */     return stringToDriverCharBytes(paramString, this.clientCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String CharBytesToString(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
/*  551 */     return CharBytesToString(paramArrayOfbyte, paramInt, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String CharBytesToString(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) throws SQLException {
/*  560 */     String str = null;
/*  561 */     if (paramArrayOfbyte.length == 0) {
/*  562 */       return str;
/*      */     }
/*  564 */     switch (this.clientCharSetId)
/*      */     
/*      */     { 
/*      */       case -5:
/*  568 */         str = CharacterSet.AL16UTF16BytesToString(paramArrayOfbyte, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  619 */         return str;case 1: str = new String(paramArrayOfbyte, 0, 0, paramInt); return str;case 2: case 31: case 178: if (paramBoolean) { str = this.clientCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); } else { str = this.clientCharSet.toString(paramArrayOfbyte, 0, paramInt); }  return str;case 870: case 871: str = CharacterSet.UTFToString(paramArrayOfbyte, 0, paramInt, paramBoolean); return str;case 873: str = CharacterSet.AL32UTF8ToString(paramArrayOfbyte, 0, paramInt, paramBoolean); return str;case -1: str = this.serverCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); return str; }  unexpectedCharset(this.clientCharSetId); return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String NCharBytesToString(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
/*  627 */     String str = null;
/*      */     
/*  629 */     if (this.clientCharSetId == -1)
/*      */     
/*      */     { 
/*      */       
/*  633 */       str = this.serverNCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); }
/*      */     
/*      */     else
/*      */     
/*  637 */     { switch (this.serverNCharSetId)
/*      */       
/*      */       { 
/*      */         
/*      */         case -5:
/*      */         case 2000:
/*  643 */           str = CharacterSet.AL16UTF16BytesToString(paramArrayOfbyte, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  691 */           return str;case 1: case 2: str = new String(paramArrayOfbyte, 0, 0, paramInt); return str;case 31: case 178: str = this.serverNCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); return str;case 870: case 871: str = CharacterSet.UTFToString(paramArrayOfbyte, 0, paramInt); return str;case 873: str = CharacterSet.AL32UTF8ToString(paramArrayOfbyte, 0, paramInt); return str;case -1: str = this.serverCharSet.toStringWithReplacement(paramArrayOfbyte, 0, paramInt); return str; }  unexpectedCharset(this.clientCharSetId); }  return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  718 */     return javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte, this.clientCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/*  728 */     return javaCharsToCHARBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, this.clientCharSetId, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  738 */     return javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte, this.serverNCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/*  748 */     return javaCharsToCHARBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, this.serverNCharSetId, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte, short paramShort) throws SQLException {
/*  758 */     return javaCharsToCHARBytes(paramArrayOfchar, 0, paramArrayOfbyte, 0, paramShort, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, short paramShort, int paramInt3) throws SQLException {
/*      */     byte[] arrayOfByte;
/*  767 */     int i = 0;
/*      */     
/*  769 */     switch (paramShort)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */       
/*      */       case -5:
/*      */       case 2000:
/*  777 */         i = CharacterSet.convertJavaCharsToAL16UTF16Bytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  836 */         return i;case 2: case 178: arrayOfByte = this.clientCharSet.convertWithReplacement(new String(paramArrayOfchar, paramInt1, paramInt3)); System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, 0, arrayOfByte.length); i = arrayOfByte.length; return i;case 1: i = CharacterSet.convertJavaCharsToASCIIBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3, this.isStrictASCIIConversion); return i;case 31: i = CharacterSet.convertJavaCharsToISOLATIN1Bytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3); return i;case 870: case 871: i = CharacterSet.convertJavaCharsToUTFBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3); return i;case 873: i = CharacterSet.convertJavaCharsToAL32UTF8Bytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3); return i;case -1: i = javaCharsToDbCsBytes(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramInt3); return i; }  unexpectedCharset(this.clientCharSetId); return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int[] paramArrayOfint, int paramInt3) throws SQLException {
/*  867 */     return _CHARBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, this.clientCharSetId, paramArrayOfint, paramInt3, this.serverCharSet, this.serverNCharSet, this.clientCharSet, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int[] paramArrayOfint, int paramInt3) throws SQLException {
/*  885 */     return _CHARBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, this.serverNCharSetId, paramArrayOfint, paramInt3, this.serverCharSet, this.serverNCharSet, this.clientCharSet, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int _CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, short paramShort, int[] paramArrayOfint, int paramInt3, CharacterSet paramCharacterSet1, CharacterSet paramCharacterSet2, CharacterSet paramCharacterSet3, boolean paramBoolean) throws SQLException {
/*  912 */     int i = 0;
/*  913 */     int j = 0;
/*      */     
/*  915 */     switch (paramShort)
/*      */     
/*      */     { 
/*      */       
/*      */       case -5:
/*      */       case 2000:
/*  921 */         j = paramArrayOfint[0] - paramArrayOfint[0] % 2;
/*      */ 
/*      */         
/*  924 */         if (paramInt3 > paramArrayOfchar.length - paramInt2) {
/*  925 */           paramInt3 = paramArrayOfchar.length - paramInt2;
/*      */         }
/*      */ 
/*      */         
/*  929 */         if (paramInt3 * 2 < j) {
/*  930 */           j = paramInt3 * 2;
/*      */         }
/*  932 */         i = CharacterSet.convertAL16UTF16BytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, j, true);
/*      */ 
/*      */ 
/*      */         
/*  936 */         paramArrayOfint[0] = paramArrayOfint[0] - j;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1036 */         return i;case 1: j = paramArrayOfint[0]; if (paramInt3 > paramArrayOfchar.length - paramInt2) paramInt3 = paramArrayOfchar.length - paramInt2;  if (paramInt3 < j) j = paramInt3;  i = CharacterSet.convertASCIIBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, j); paramArrayOfint[0] = paramArrayOfint[0] - j; return i;case 31: case 178: j = paramArrayOfint[0]; i = paramCharacterSet1.toCharWithReplacement(paramArrayOfbyte, 0, paramArrayOfchar, paramInt2, j); paramArrayOfint[0] = paramArrayOfint[0] - i; return i;case 870: case 871: if (paramInt3 > paramArrayOfchar.length - paramInt2) paramInt3 = paramArrayOfchar.length - paramInt2;  i = CharacterSet.convertUTFBytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, paramArrayOfint, true, paramInt3); return i;case 873: if (paramInt3 > paramArrayOfchar.length - paramInt2) paramInt3 = paramArrayOfchar.length - paramInt2;  i = CharacterSet.convertAL32UTF8BytesToJavaChars(paramArrayOfbyte, paramInt1, paramArrayOfchar, paramInt2, paramArrayOfint, true, paramInt3); return i;case -1: unexpectedCharset((short)-1); return i; }  CharacterSet characterSet = paramCharacterSet3; if (paramBoolean) characterSet = paramCharacterSet2;  String str = characterSet.toStringWithReplacement(paramArrayOfbyte, paramInt1, paramArrayOfint[0]); char[] arrayOfChar = str.toCharArray(); int k = arrayOfChar.length; if (k > paramInt3) k = paramInt3;  i = k; paramArrayOfint[0] = paramArrayOfint[0] - k; System.arraycopy(arrayOfChar, 0, paramArrayOfchar, paramInt2, k); return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] asciiBytesToCHARBytes(byte[] paramArrayOfbyte) {
/*      */     byte b1, b2;
/* 1058 */     byte[] arrayOfByte = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1068 */     switch (this.clientCharSetId)
/*      */     
/*      */     { 
/*      */       case -5:
/* 1072 */         arrayOfByte = new byte[paramArrayOfbyte.length * 2];
/*      */         
/* 1074 */         for (b1 = 0, b2 = 0; b1 < paramArrayOfbyte.length; b1++) {
/*      */           
/* 1076 */           arrayOfByte[b2++] = 0;
/* 1077 */           arrayOfByte[b2++] = paramArrayOfbyte[b1];
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1103 */         return arrayOfByte;case -1: if (this.asciiCharSet == null) this.asciiCharSet = CharacterSet.make(1);  try { arrayOfByte = this.serverCharSet.convert(this.asciiCharSet, paramArrayOfbyte, 0, paramArrayOfbyte.length); } catch (SQLException sQLException) {} return arrayOfByte; }  arrayOfByte = paramArrayOfbyte; return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToDbCsBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1140 */     return javaCharsToDbCsBytes(paramArrayOfchar, 0, paramArrayOfbyte, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int javaCharsToDbCsBytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/* 1179 */     int i = 0;
/*      */ 
/*      */     
/* 1182 */     catchCharsLen(paramArrayOfchar, paramInt1, paramInt3);
/*      */     
/* 1184 */     String str = new String(paramArrayOfchar, paramInt1, paramInt3);
/* 1185 */     byte[] arrayOfByte = this.serverCharSet.convertWithReplacement(str);
/*      */     
/* 1187 */     str = null;
/*      */     
/* 1189 */     if (arrayOfByte != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1195 */       i = arrayOfByte.length;
/*      */       
/* 1197 */       catchBytesLen(paramArrayOfbyte, paramInt2, i);
/* 1198 */       System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, paramInt2, i);
/*      */       
/* 1200 */       arrayOfByte = null;
/*      */     } 
/*      */     
/* 1203 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int javaCharsToUcs2Bytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1236 */     return javaCharsToUcs2Bytes(paramArrayOfchar, 0, paramArrayOfbyte, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int javaCharsToUcs2Bytes(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/* 1274 */     catchCharsLen(paramArrayOfchar, paramInt1, paramInt3);
/* 1275 */     catchBytesLen(paramArrayOfbyte, paramInt2, paramInt3 * 2);
/*      */     
/* 1277 */     int k = paramInt3 + paramInt1;
/*      */     int j;
/* 1279 */     for (int i = paramInt1; i < k; i++) {
/*      */       
/* 1281 */       paramArrayOfbyte[j++] = (byte)(paramArrayOfchar[i] >> 8 & 0xFF);
/* 1282 */       paramArrayOfbyte[j++] = (byte)(paramArrayOfchar[i] & 0xFF);
/*      */     } 
/*      */     
/* 1285 */     return j - paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ucs2BytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 1335 */     return CharacterSet.AL16UTF16BytesToJavaChars(paramArrayOfbyte, paramInt, paramArrayOfchar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final byte[] stringToAsciiBytes(String paramString) {
/* 1357 */     return CharacterSet.stringToASCII(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int asciiBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 1384 */     return CharacterSet.convertASCIIBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int javaCharsToAsciiBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1412 */     return CharacterSet.convertJavaCharsToASCIIBytes(paramArrayOfchar, 0, paramArrayOfbyte, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean isCharSetMultibyte(short paramShort) {
/* 1591 */     switch (paramShort) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 31:
/* 1597 */         return false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -5:
/*      */       case -1:
/*      */       case 870:
/*      */       case 871:
/*      */       case 873:
/* 1608 */         return true;
/*      */     } 
/*      */     
/* 1611 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxCharbyteSize() {
/* 1649 */     return _getMaxCharbyteSize(this.clientCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxNCharbyteSize() {
/* 1657 */     return _getMaxCharbyteSize(this.serverNCharSetId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int _getMaxCharbyteSize(short paramShort) {
/* 1665 */     switch (paramShort) {
/*      */ 
/*      */       
/*      */       case 1:
/* 1669 */         return 1;
/*      */       
/*      */       case 31:
/* 1672 */         return 1;
/*      */ 
/*      */       
/*      */       case 870:
/*      */       case 871:
/* 1677 */         return 3;
/*      */ 
/*      */       
/*      */       case -5:
/*      */       case 2000:
/* 1682 */         return 2;
/*      */       
/*      */       case -1:
/* 1685 */         return 4;
/*      */       
/*      */       case 873:
/* 1688 */         return 4;
/*      */     } 
/*      */     
/* 1691 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUcs2CharSet() {
/* 1702 */     return (this.clientCharSetId == -5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int RAWBytesToHexChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) {
/*      */     byte b2;
/* 1714 */     for (byte b1 = 0; b1 < paramInt; b1++) {
/*      */       
/* 1716 */       paramArrayOfchar[b2++] = (char)RepConversion.nibbleToHex((byte)(paramArrayOfbyte[b1] >> 4 & 0xF));
/*      */ 
/*      */       
/* 1719 */       paramArrayOfchar[b2++] = (char)RepConversion.nibbleToHex((byte)(paramArrayOfbyte[b1] & 0xF));
/*      */     } 
/*      */ 
/*      */     
/* 1723 */     return b2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int hexDigit2Nibble(char paramChar) throws SQLException {
/* 1739 */     int i = Character.digit(paramChar, 16);
/*      */     
/* 1741 */     if (i == -1) {
/*      */ 
/*      */       
/* 1744 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, "Invalid hex digit: " + paramChar);
/* 1745 */       sQLException.fillInStackTrace();
/* 1746 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1750 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final byte[] hexString2Bytes(String paramString) throws SQLException {
/* 1766 */     int i = paramString.length();
/* 1767 */     char[] arrayOfChar = new char[i];
/*      */     
/* 1769 */     paramString.getChars(0, i, arrayOfChar, 0);
/* 1770 */     return hexChars2Bytes(arrayOfChar, 0, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final byte[] hexChars2Bytes(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/*      */     byte[] arrayOfByte;
/* 1778 */     byte b = 0;
/* 1779 */     int i = paramInt1;
/*      */     
/* 1781 */     if (paramInt2 == 0) {
/* 1782 */       return new byte[0];
/*      */     }
/* 1784 */     if (paramInt2 % 2 > 0) {
/*      */       
/* 1786 */       arrayOfByte = new byte[(paramInt2 + 1) / 2];
/* 1787 */       arrayOfByte[b++] = (byte)hexDigit2Nibble(paramArrayOfchar[i++]);
/*      */     }
/*      */     else {
/*      */       
/* 1791 */       arrayOfByte = new byte[paramInt2 / 2];
/*      */     } 
/*      */     
/* 1794 */     for (; b < arrayOfByte.length; b++)
/*      */     {
/* 1796 */       arrayOfByte[b] = (byte)(hexDigit2Nibble(paramArrayOfchar[i++]) << 4 | hexDigit2Nibble(paramArrayOfchar[i++]));
/*      */     }
/*      */     
/* 1799 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStream(InputStream paramInputStream, int paramInt) {
/* 1808 */     return new OracleConversionInputStream(this, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStream(InputStream paramInputStream, int paramInt1, int paramInt2) {
/* 1817 */     return new OracleConversionInputStream(this, paramInputStream, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStreamInternal(InputStream paramInputStream, int paramInt1, int paramInt2) {
/* 1826 */     return new OracleConversionInputStreamInternal(this, paramInputStream, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStream(Reader paramReader, int paramInt1, int paramInt2, short paramShort) {
/* 1848 */     return new OracleConversionInputStream(this, paramReader, paramInt1, paramInt2, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream ConvertStreamInternal(Reader paramReader, int paramInt1, int paramInt2, short paramShort) {
/* 1860 */     return new OracleConversionInputStreamInternal(this, paramReader, paramInt1, paramInt2, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader ConvertCharacterStream(InputStream paramInputStream, int paramInt) throws SQLException {
/* 1873 */     return new OracleConversionReader(this, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader ConvertCharacterStream(InputStream paramInputStream, int paramInt, short paramShort) throws SQLException {
/* 1882 */     OracleConversionReader oracleConversionReader = new OracleConversionReader(this, paramInputStream, paramInt);
/*      */ 
/*      */     
/* 1885 */     oracleConversionReader.setFormOfUse(paramShort);
/*      */     
/* 1887 */     return oracleConversionReader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream CharsToStream(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1896 */     if (paramInt3 == 10) {
/* 1897 */       return new AsciiStream(paramArrayOfchar, paramInt1, paramInt2);
/*      */     }
/* 1899 */     if (paramInt3 == 11) {
/* 1900 */       return new UnicodeStream(paramArrayOfchar, paramInt1, paramInt2);
/*      */     }
/*      */     
/* 1903 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 39, "unknownConversion");
/* 1904 */     sQLException.fillInStackTrace();
/* 1905 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class AsciiStream
/*      */     extends OracleBufferedStream
/*      */   {
/*      */     AsciiStream(char[] param1ArrayOfchar, int param1Int1, int param1Int2) {
/* 1915 */       super(param1Int2);
/* 1916 */       this.currentBufferSize = this.initialBufferSize;
/* 1917 */       this.resizableBuffer = new byte[this.currentBufferSize];
/*      */       
/* 1919 */       if (DBConversion.this.serverCharSetId == 1 || !DBConversion.this.isStrictASCIIConversion) {
/*      */         int i; byte b;
/* 1921 */         for (i = param1Int1, b = 0; b < param1Int2; b++) {
/* 1922 */           this.resizableBuffer[b] = (byte)param1ArrayOfchar[i++];
/*      */         }
/*      */       } else {
/*      */         
/* 1926 */         if (DBConversion.this.asciiCharSet == null)
/* 1927 */           DBConversion.this.asciiCharSet = CharacterSet.make(1); 
/* 1928 */         this.resizableBuffer = DBConversion.this.asciiCharSet.convertWithReplacement(new String(param1ArrayOfchar, param1Int1, param1Int2));
/*      */       } 
/*      */       
/* 1931 */       this.count = param1Int2;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean needBytes() {
/* 1936 */       return (!this.closed && this.pos < this.count);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean needBytes(int param1Int) {
/* 1941 */       return (!this.closed && this.pos < this.count);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class UnicodeStream
/*      */     extends OracleBufferedStream
/*      */   {
/*      */     UnicodeStream(char[] param1ArrayOfchar, int param1Int1, int param1Int2) {
/* 1950 */       super(param1Int2);
/* 1951 */       this.currentBufferSize = this.initialBufferSize;
/* 1952 */       this.resizableBuffer = new byte[this.currentBufferSize]; int i;
/*      */       byte b;
/* 1954 */       for (i = param1Int1, b = 0; b < param1Int2; ) {
/*      */         
/* 1956 */         char c = param1ArrayOfchar[i++];
/*      */         
/* 1958 */         this.resizableBuffer[b++] = (byte)(c >> 8 & 0xFF);
/* 1959 */         this.resizableBuffer[b++] = (byte)(c & 0xFF);
/*      */       } 
/*      */       
/* 1962 */       this.count = param1Int2;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean needBytes() {
/* 1967 */       return (!this.closed && this.pos < this.count);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean needBytes(int param1Int) {
/* 1972 */       return (!this.closed && this.pos < this.count);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void unexpectedCharset(short paramShort) throws SQLException {
/* 1990 */     SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 35, "DBConversion");
/* 1991 */     sQLException.fillInStackTrace();
/* 1992 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void catchBytesLen(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 2023 */     if (paramInt1 + paramInt2 > paramArrayOfbyte.length) {
/*      */ 
/*      */       
/* 2026 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 39, "catchBytesLen");
/* 2027 */       sQLException.fillInStackTrace();
/* 2028 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void catchCharsLen(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 2059 */     if (paramInt1 + paramInt2 > paramArrayOfchar.length) {
/*      */ 
/*      */       
/* 2062 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 39, "catchCharsLen");
/* 2063 */       sQLException.fillInStackTrace();
/* 2064 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int getUtfLen(char paramChar) {
/* 2081 */     byte b = 0;
/*      */     
/* 2083 */     if ((paramChar & 0xFF80) == 0) {
/*      */       
/* 2085 */       b = 1;
/*      */     }
/* 2087 */     else if ((paramChar & 0xF800) == 0) {
/*      */       
/* 2089 */       b = 2;
/*      */     }
/*      */     else {
/*      */       
/* 2093 */       b = 3;
/*      */     } 
/*      */     
/* 2096 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int encodedByteLength(String paramString, boolean paramBoolean) {
/* 2112 */     int i = 0;
/* 2113 */     if (paramString != null) {
/*      */       
/* 2115 */       i = paramString.length();
/* 2116 */       if (i != 0)
/*      */       {
/* 2118 */         if (paramBoolean) {
/*      */           
/* 2120 */           i = this.isServerNCharSetFixedWidth ? (i * this.maxNCharSize) : this.serverNCharSet.encodedByteLength(paramString);
/*      */         }
/*      */         else {
/*      */           
/* 2124 */           i = this.isServerCharSetFixedWidth ? (i * this.sMaxCharSize) : this.serverCharSet.encodedByteLength(paramString);
/*      */         } 
/*      */       }
/*      */     } 
/* 2128 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int encodedByteLength(char[] paramArrayOfchar, boolean paramBoolean) {
/* 2143 */     int i = 0;
/* 2144 */     if (paramArrayOfchar != null) {
/*      */       
/* 2146 */       i = paramArrayOfchar.length;
/* 2147 */       if (i != 0)
/*      */       {
/* 2149 */         if (paramBoolean) {
/*      */           
/* 2151 */           i = this.isServerNCharSetFixedWidth ? (i * this.maxNCharSize) : this.serverNCharSet.encodedByteLength(paramArrayOfchar);
/*      */         }
/*      */         else {
/*      */           
/* 2155 */           i = this.isServerCharSetFixedWidth ? (i * this.sMaxCharSize) : this.serverCharSet.encodedByteLength(paramArrayOfchar);
/*      */         } 
/*      */       }
/*      */     } 
/* 2159 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2174 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2203 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\DBConversion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */