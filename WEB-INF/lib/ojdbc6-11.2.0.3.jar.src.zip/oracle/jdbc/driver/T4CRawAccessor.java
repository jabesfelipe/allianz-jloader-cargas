/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CRawAccessor
/*     */   extends RawAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   final int[] meta;
/*     */   final int[] escapeSequenceArr;
/*     */   final boolean[] readHeaderArr;
/*     */   final boolean[] readAsNonStreamArr;
/*     */   
/*     */   T4CRawAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  44 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     this.meta = new int[1];
/* 109 */     this.escapeSequenceArr = new int[1];
/* 110 */     this.readHeaderArr = new boolean[1];
/* 111 */     this.readAsNonStreamArr = new boolean[1]; this.mare = paramT4CMAREngine; } T4CRawAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1]; this.escapeSequenceArr = new int[1]; this.readHeaderArr = new boolean[1]; this.readAsNonStreamArr = new boolean[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       this.definedColumnType = 0;
/*     */       this.definedColumnSize = 0;
/*     */     } else {
/*     */       this.definedColumnType = paramInt7;
/*     */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     if (paramInt1 == -1) {
/*     */       this.underlyingLongRaw = true;
/*     */     } }
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 126 */     if (this.isUseLess) {
/*     */       
/* 128 */       this.lastRowProcessed++;
/*     */       
/* 130 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 134 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 135 */     int j = this.lengthIndex + this.lastRowProcessed;
/* 136 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */     
/* 138 */     if (!this.underlyingLongRaw) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 147 */         byte[] arrayOfByte = new byte[16000];
/*     */         
/* 149 */         this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 150 */         processIndicator(this.meta[0]);
/*     */         
/* 152 */         this.lastRowProcessed++;
/*     */         
/* 154 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 159 */       if (this.isNullByDescribe) {
/*     */         
/* 161 */         this.rowSpaceIndicator[i] = -1;
/* 162 */         this.rowSpaceIndicator[j] = 0;
/* 163 */         this.lastRowProcessed++;
/*     */         
/* 165 */         if (this.statement.connection.versionNumber < 9200) {
/* 166 */           processIndicator(0);
/*     */         }
/* 168 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 173 */       this.mare.unmarshalCLR(this.rowSpaceByte, k + 2, this.meta, this.byteLength - 2);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 180 */       this.escapeSequenceArr[0] = this.mare.unmarshalUB1();
/*     */ 
/*     */       
/* 183 */       if (this.mare.escapeSequenceNull(this.escapeSequenceArr[0])) {
/*     */ 
/*     */ 
/*     */         
/* 187 */         this.meta[0] = 0;
/*     */         
/* 189 */         this.mare.processIndicator(false, 0);
/*     */         
/* 191 */         int m = (int)this.mare.unmarshalUB4();
/*     */       }
/*     */       else {
/*     */         
/* 195 */         int m = 0;
/* 196 */         int n = 0;
/* 197 */         byte[] arrayOfByte = this.rowSpaceByte;
/* 198 */         int i1 = k + 2;
/*     */         
/* 200 */         this.readHeaderArr[0] = true;
/* 201 */         this.readAsNonStreamArr[0] = false;
/*     */         
/* 203 */         while (m != -1) {
/*     */           
/* 205 */           if (arrayOfByte == this.rowSpaceByte && n + 255 > this.byteLength - 2)
/*     */           {
/*     */             
/* 208 */             arrayOfByte = new byte[255];
/*     */           }
/* 210 */           if (arrayOfByte != this.rowSpaceByte) {
/* 211 */             i1 = 0;
/*     */           }
/* 213 */           m = T4CLongRawAccessor.readStreamFromWire(arrayOfByte, i1, 255, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
/*     */ 
/*     */ 
/*     */           
/* 217 */           if (this.statement.connection.calculateChecksum && m != -1) {
/*     */ 
/*     */             
/* 220 */             long l = CRC64.updateChecksum(this.statement.checkSum, arrayOfByte, i1, m);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 225 */             this.statement.checkSum = l;
/*     */           } 
/*     */ 
/*     */           
/* 229 */           if (m != -1) {
/*     */             
/* 231 */             if (arrayOfByte == this.rowSpaceByte) {
/*     */               
/* 233 */               n += m;
/* 234 */               i1 += m; continue;
/*     */             } 
/* 236 */             if (this.byteLength - 2 - n > 0) {
/*     */ 
/*     */ 
/*     */               
/* 240 */               int i2 = this.byteLength - 2 - n;
/*     */               
/* 242 */               System.arraycopy(arrayOfByte, 0, this.rowSpaceByte, k, i2);
/*     */ 
/*     */               
/* 245 */               n += i2;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 250 */         if (arrayOfByte != this.rowSpaceByte) {
/* 251 */           arrayOfByte = null;
/*     */         }
/* 253 */         this.meta[0] = n;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 258 */     this.rowSpaceByte[k] = (byte)((this.meta[0] & 0xFF00) >> 8);
/* 259 */     this.rowSpaceByte[k + 1] = (byte)(this.meta[0] & 0xFF);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     if (!this.underlyingLongRaw) {
/* 266 */       processIndicator(this.meta[0]);
/*     */     }
/* 268 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 272 */       this.rowSpaceIndicator[i] = -1;
/* 273 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 277 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 282 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 285 */     this.lastRowProcessed++;
/*     */     
/* 287 */     return false; }
/*     */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2(); this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     }  } void copyRow() throws SQLException, IOException { int i;
/* 297 */     if (this.lastRowProcessed == 0) {
/* 298 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 300 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 303 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 304 */     int k = this.columnIndex + i * this.byteLength;
/* 305 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 306 */     int n = this.indicatorIndex + i;
/* 307 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 308 */     int i2 = this.lengthIndex + i;
/* 309 */     short s = this.rowSpaceIndicator[i2];
/* 310 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 312 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 316 */     this.rowSpaceIndicator[i1] = (short)s;
/* 317 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 320 */     if (!this.isNullByDescribe)
/*     */     {
/* 322 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s + 2);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 327 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 330 */     this.lastRowProcessed++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 342 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 344 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 346 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 347 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 348 */     int n = this.lengthIndex + paramInt2 - 1;
/* 349 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 350 */     short s = paramArrayOfshort[i1];
/*     */     
/* 352 */     this.rowSpaceIndicator[n] = (short)s;
/* 353 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 356 */     if (s != 0)
/*     */     {
/* 358 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s + 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 371 */     String str = super.getString(paramInt);
/*     */ 
/*     */ 
/*     */     
/* 375 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize * 2)
/*     */     {
/* 377 */       str = str.substring(0, this.definedColumnSize * 2);
/*     */     }
/* 379 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 386 */     if (this.definedColumnType == 0) {
/* 387 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 390 */     Object object = null;
/*     */     
/* 392 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 394 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 395 */       sQLException.fillInStackTrace();
/* 396 */       throw sQLException;
/*     */     } 
/*     */     
/* 399 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 401 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -16:
/*     */         case -15:
/*     */         case -9:
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 418 */           return getString(paramInt);
/*     */         
/*     */         case -2:
/* 421 */           return getRAW(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 425 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 426 */       sQLException.fillInStackTrace();
/* 427 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 433 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 441 */     byte[] arrayOfByte = super.getBytes(paramInt);
/*     */     
/* 443 */     if (arrayOfByte != null && this.definedColumnSize > 0 && this.definedColumnSize < arrayOfByte.length) {
/*     */ 
/*     */ 
/*     */       
/* 447 */       byte[] arrayOfByte1 = new byte[this.definedColumnSize];
/*     */       
/* 449 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, this.definedColumnSize);
/*     */       
/* 451 */       arrayOfByte = arrayOfByte1;
/*     */     } 
/*     */     
/* 454 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 459 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CRawAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */