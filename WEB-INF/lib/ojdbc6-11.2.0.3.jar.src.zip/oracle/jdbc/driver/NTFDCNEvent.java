/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import oracle.jdbc.dcn.DatabaseChangeEvent;
/*     */ import oracle.jdbc.dcn.QueryChangeDescription;
/*     */ import oracle.jdbc.dcn.TableChangeDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFDCNEvent
/*     */   extends DatabaseChangeEvent
/*     */ {
/*  49 */   private int notifVersion = 0;
/*  50 */   private int notifRegid = 0;
/*     */   private DatabaseChangeEvent.EventType eventType;
/*  52 */   private DatabaseChangeEvent.AdditionalEventType additionalEventType = DatabaseChangeEvent.AdditionalEventType.NONE;
/*  53 */   private String databaseName = null;
/*  54 */   private byte[] notifXid = new byte[8];
/*  55 */   private int notifScn1 = 0;
/*  56 */   private int notifScn2 = 0;
/*     */   
/*  58 */   private int numberOfTables = 0;
/*  59 */   private NTFDCNTableChanges[] tcdesc = null;
/*     */ 
/*     */   
/*  62 */   private int numberOfQueries = 0;
/*  63 */   private NTFDCNQueryChanges[] qdesc = null;
/*     */   
/*     */   private long registrationId;
/*     */   
/*     */   private NTFConnection conn;
/*     */   
/*     */   private int csid;
/*     */   
/*     */   private boolean isReady = false;
/*     */   private ByteBuffer dataBuffer;
/*     */   private boolean isDeregistrationEvent = false;
/*     */   private short databaseVersion;
/*     */   
/*     */   NTFDCNEvent(NTFConnection paramNTFConnection, short paramShort) throws IOException {
/*  77 */     super(paramNTFConnection);
/*     */     
/*  79 */     this.conn = paramNTFConnection;
/*  80 */     this.csid = this.conn.charset.getOracleId();
/*     */ 
/*     */     
/*  83 */     int i = this.conn.readInt();
/*  84 */     byte[] arrayOfByte = new byte[i];
/*  85 */     this.conn.readBuffer(arrayOfByte, 0, i);
/*  86 */     this.dataBuffer = ByteBuffer.wrap(arrayOfByte);
/*  87 */     this.databaseVersion = paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initEvent() {
/*  95 */     byte b1 = this.dataBuffer.get();
/*  96 */     int i = this.dataBuffer.getInt();
/*  97 */     byte[] arrayOfByte1 = new byte[i];
/*  98 */     this.dataBuffer.get(arrayOfByte1, 0, i);
/*     */ 
/*     */ 
/*     */     
/* 102 */     String str = null;
/*     */     try {
/* 104 */       str = new String(arrayOfByte1, "UTF-8");
/* 105 */     } catch (Exception exception) {}
/*     */     
/* 107 */     str = str.replaceFirst("CHNF", "");
/* 108 */     this.registrationId = Long.parseLong(str);
/*     */ 
/*     */     
/* 111 */     byte b2 = this.dataBuffer.get();
/* 112 */     int j = this.dataBuffer.getInt();
/* 113 */     byte[] arrayOfByte2 = new byte[j];
/* 114 */     this.dataBuffer.get(arrayOfByte2, 0, j);
/*     */ 
/*     */     
/* 117 */     byte b3 = this.dataBuffer.get();
/* 118 */     int k = this.dataBuffer.getInt();
/* 119 */     if (this.dataBuffer.hasRemaining()) {
/*     */ 
/*     */ 
/*     */       
/* 123 */       this.notifVersion = this.dataBuffer.getShort();
/* 124 */       this.notifRegid = this.dataBuffer.getInt();
/* 125 */       this.eventType = DatabaseChangeEvent.EventType.getEventType(this.dataBuffer.getInt());
/* 126 */       short s = this.dataBuffer.getShort();
/* 127 */       byte[] arrayOfByte = new byte[s];
/* 128 */       this.dataBuffer.get(arrayOfByte, 0, s);
/*     */       try {
/* 130 */         this.databaseName = new String(arrayOfByte, "UTF-8");
/* 131 */       } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 139 */       this.dataBuffer.get(this.notifXid);
/*     */       
/* 141 */       this.notifScn1 = this.dataBuffer.getInt();
/* 142 */       this.notifScn2 = this.dataBuffer.getShort();
/*     */       
/* 144 */       if (this.eventType == DatabaseChangeEvent.EventType.OBJCHANGE) {
/*     */         
/* 146 */         this.numberOfTables = this.dataBuffer.getShort();
/* 147 */         this.tcdesc = new NTFDCNTableChanges[this.numberOfTables];
/* 148 */         for (byte b = 0; b < this.tcdesc.length; b++) {
/* 149 */           this.tcdesc[b] = new NTFDCNTableChanges(this.dataBuffer, this.csid);
/*     */         }
/* 151 */       } else if (this.eventType == DatabaseChangeEvent.EventType.QUERYCHANGE) {
/*     */         
/* 153 */         this.numberOfQueries = this.dataBuffer.getShort();
/* 154 */         this.qdesc = new NTFDCNQueryChanges[this.numberOfQueries];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 163 */         for (byte b = 0; b < this.numberOfQueries; b++)
/*     */         {
/* 165 */           this.qdesc[b] = new NTFDCNQueryChanges(this.dataBuffer, this.csid);
/*     */         }
/*     */       } 
/*     */     } 
/* 169 */     this.isReady = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDatabaseName() {
/* 177 */     if (!this.isReady)
/* 178 */       initEvent(); 
/* 179 */     return this.databaseName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableChangeDescription[] getTableChangeDescription() {
/* 186 */     if (!this.isReady)
/* 187 */       initEvent(); 
/* 188 */     if (this.eventType == DatabaseChangeEvent.EventType.OBJCHANGE)
/*     */     {
/* 190 */       return (TableChangeDescription[])this.tcdesc;
/*     */     }
/*     */     
/* 193 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryChangeDescription[] getQueryChangeDescription() {
/* 200 */     if (!this.isReady)
/* 201 */       initEvent(); 
/* 202 */     if (this.eventType == DatabaseChangeEvent.EventType.QUERYCHANGE)
/*     */     {
/* 204 */       return (QueryChangeDescription[])this.qdesc;
/*     */     }
/*     */     
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getTransactionId() {
/* 214 */     if (!this.isReady)
/* 215 */       initEvent(); 
/* 216 */     return this.notifXid;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTransactionId(boolean paramBoolean) {
/*     */     int i;
/*     */     int j;
/*     */     long l;
/* 224 */     if (!this.isReady) {
/* 225 */       initEvent();
/*     */     }
/*     */     
/* 228 */     if (!paramBoolean) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 233 */       i = (this.notifXid[0] & 0xFF) << 8 | this.notifXid[1] & 0xFF;
/*     */ 
/*     */       
/* 236 */       j = (this.notifXid[2] & 0xFF) << 8 | this.notifXid[3] & 0xFF;
/*     */ 
/*     */       
/* 239 */       l = (((this.notifXid[4] & 0xFF) << 24 | (this.notifXid[5] & 0xFF) << 16 | (this.notifXid[6] & 0xFF) << 8 | this.notifXid[7] & 0xFF) & 0xFFFFFFFF);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 248 */       i = (this.notifXid[1] & 0xFF) << 8 | this.notifXid[0] & 0xFF;
/*     */       
/* 250 */       j = (this.notifXid[3] & 0xFF) << 8 | this.notifXid[2] & 0xFF;
/*     */       
/* 252 */       l = (((this.notifXid[7] & 0xFF) << 24 | (this.notifXid[6] & 0xFF) << 16 | (this.notifXid[5] & 0xFF) << 8 | this.notifXid[4] & 0xFF) & 0xFFFFFFFF);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 259 */     return "" + i + "." + j + "." + l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEventType(DatabaseChangeEvent.EventType paramEventType) throws IOException {
/* 268 */     if (!this.isReady)
/* 269 */       initEvent(); 
/* 270 */     this.eventType = paramEventType;
/* 271 */     if (this.eventType == DatabaseChangeEvent.EventType.DEREG) {
/* 272 */       this.isDeregistrationEvent = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setAdditionalEventType(DatabaseChangeEvent.AdditionalEventType paramAdditionalEventType) {
/* 279 */     this.additionalEventType = paramAdditionalEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseChangeEvent.EventType getEventType() {
/* 286 */     if (!this.isReady)
/* 287 */       initEvent(); 
/* 288 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseChangeEvent.AdditionalEventType getAdditionalEventType() {
/* 295 */     return this.additionalEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDeregistrationEvent() {
/* 304 */     return this.isDeregistrationEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionInformation() {
/* 311 */     return this.conn.connectionDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRegistrationId() {
/* 318 */     if (!this.isReady)
/* 319 */       initEvent(); 
/* 320 */     return (int)this.registrationId;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRegId() {
/* 326 */     if (!this.isReady)
/* 327 */       initEvent(); 
/* 328 */     return this.registrationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 335 */     if (!this.isReady)
/* 336 */       initEvent(); 
/* 337 */     StringBuffer stringBuffer = new StringBuffer();
/* 338 */     stringBuffer.append("Connection information  : " + this.conn.connectionDescription + "\n");
/* 339 */     stringBuffer.append("Registration ID         : " + this.registrationId + "\n");
/* 340 */     stringBuffer.append("Notification version    : " + this.notifVersion + "\n");
/* 341 */     stringBuffer.append("Event type              : " + this.eventType + "\n");
/* 342 */     if (this.additionalEventType != DatabaseChangeEvent.AdditionalEventType.NONE)
/* 343 */       stringBuffer.append("Additional event type   : " + this.additionalEventType + "\n"); 
/* 344 */     if (this.databaseName != null) {
/* 345 */       stringBuffer.append("Database name           : " + this.databaseName + "\n");
/*     */     }
/*     */ 
/*     */     
/* 349 */     TableChangeDescription[] arrayOfTableChangeDescription = getTableChangeDescription();
/* 350 */     if (arrayOfTableChangeDescription != null) {
/*     */       
/* 352 */       stringBuffer.append("Table Change Description (length=" + this.numberOfTables + ")\n");
/* 353 */       for (byte b = 0; b < arrayOfTableChangeDescription.length; b++)
/* 354 */         stringBuffer.append(arrayOfTableChangeDescription[b].toString()); 
/*     */     } 
/* 356 */     QueryChangeDescription[] arrayOfQueryChangeDescription = getQueryChangeDescription();
/* 357 */     if (arrayOfQueryChangeDescription != null) {
/*     */       
/* 359 */       stringBuffer.append("Query Change Description (length=" + this.numberOfQueries + ")\n");
/* 360 */       for (byte b = 0; b < arrayOfQueryChangeDescription.length; b++) {
/* 361 */         stringBuffer.append(arrayOfQueryChangeDescription[b].toString());
/*     */       }
/*     */     } 
/* 364 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 368 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NTFDCNEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */