/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.net.SocketException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.zip.CRC32;
/*      */ import oracle.jdbc.NotificationRegistration;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.aq.AQDequeueOptions;
/*      */ import oracle.jdbc.aq.AQEnqueueOptions;
/*      */ import oracle.jdbc.internal.KeywordValue;
/*      */ import oracle.jdbc.internal.KeywordValueLong;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.XSEventListener;
/*      */ import oracle.jdbc.internal.XSNamespace;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.net.ns.Communication;
/*      */ import oracle.net.ns.NSProtocol;
/*      */ import oracle.net.ns.NetException;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CConnection
/*      */   extends PhysicalConnection
/*      */   implements BfileDBAccess, BlobDBAccess, ClobDBAccess
/*      */ {
/*      */   static final short MIN_TTCVER_SUPPORTED = 4;
/*      */   static final short V8_TTCVER_SUPPORTED = 5;
/*      */   static final short MAX_TTCVER_SUPPORTED = 6;
/*      */   static final int DEFAULT_LONG_PREFETCH_SIZE = 4080;
/*      */   static final String DEFAULT_CONNECT_STRING = "localhost:1521:orcl";
/*      */   static final int STREAM_CHUNK_SIZE = 255;
/*      */   static final int REFCURSOR_SIZE = 5;
/*   94 */   long LOGON_MODE = 0L;
/*      */ 
/*      */ 
/*      */   
/*      */   static final long SYSDBA = 8L;
/*      */ 
/*      */ 
/*      */   
/*      */   static final long SYSOPER = 16L;
/*      */ 
/*      */ 
/*      */   
/*      */   static final long SYSASM = 128L;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isLoggedOn;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useZeroCopyIO;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useLobPrefetch;
/*      */ 
/*      */ 
/*      */   
/*      */   private String password;
/*      */ 
/*      */ 
/*      */   
/*      */   Communication net;
/*      */ 
/*      */   
/*      */   int eocs;
/*      */ 
/*      */   
/*  132 */   private NTFEventListener[] xsListeners = new NTFEventListener[0];
/*      */   
/*      */   boolean readAsNonStream;
/*      */   
/*      */   T4CTTIoer oer;
/*      */   
/*      */   T4CMAREngine mare;
/*      */   
/*      */   T4C8TTIpro pro;
/*      */   
/*      */   T4CTTIrxd rxd;
/*      */   
/*      */   T4CTTIsto sto;
/*      */   
/*      */   T4CTTIspfp spfp;
/*      */   
/*      */   T4CTTIoauthenticate auth;
/*      */   
/*      */   T4C8Odscrarr describe;
/*      */   
/*      */   T4C8Oall all8;
/*      */   
/*      */   T4C8Oclose close8;
/*      */   T4C7Ocommoncall commoncall;
/*      */   T4Caqe aqe;
/*      */   T4Caqdq aqdq;
/*      */   T4C8TTIBfile bfileMsg;
/*      */   T4C8TTIBlob blobMsg;
/*      */   T4C8TTIClob clobMsg;
/*      */   T4CTTIoses oses;
/*      */   T4CTTIoping oping;
/*      */   T4CTTIokpn okpn;
/*  164 */   byte[] EMPTY_BYTE = new byte[0]; T4CTTIOtxen otxen; T4CTTIOtxse otxse; T4CTTIk2rpc k2rpc; T4CTTIoscid oscid; T4CTTIokeyval okeyval; T4CTTIoxsscs oxsscs; T4CTTIoxssro oxssro; T4CTTIoxsspo oxsspo; T4CTTIxsnsop xsnsop; int[] cursorToClose; int cursorToCloseOffset; int[] queryToClose; int queryToCloseOffset; int[] lusFunctionId2; byte[][] lusSessionId2; KeywordValueLong[][] lusInKeyVal2; int[] lusInFlags2; int lusOffset2; int sessionId; int serialNumber; byte negotiatedTTCversion; byte[] serverRuntimeCapabilities; byte[] serverCompileTimeCapabilities; Hashtable namespaces; byte[] internalName; byte[] externalName; static final int FREE = -1; static final int SEND = 1; static final int RECEIVE = 2; boolean sentCancel = false; private final CRC32 checksumEngine; private final Hashtable<Long, Integer> tempLobRefCount; static final int MAX_SIZE_VSESSION_OSUSER = 30; static final int MAX_SIZE_VSESSION_PROCESS = 24; static final int MAX_SIZE_VSESSION_MACHINE = 64; static final int MAX_SIZE_VSESSION_TERMINAL = 30; static final int MAX_SIZE_VSESSION_PROGRAM = 48; final void initializePassword(String paramString) throws SQLException { this.password = paramString; }
/*      */   void logon() throws SQLException { SQLException sQLException = null; try {
/*      */       if (this.isLoggedOn) {
/*      */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 428); sQLException1.fillInStackTrace(); throw sQLException1;
/*      */       }  if (this.database == null)
/*      */         this.database = "localhost:1521:orcl";  connect(this.database); this.all8 = new T4C8Oall(this); this.okpn = new T4CTTIokpn(this); this.close8 = new T4C8Oclose(this); this.sto = new T4CTTIsto(this); this.spfp = new T4CTTIspfp(this); this.commoncall = new T4C7Ocommoncall(this); this.describe = new T4C8Odscrarr(this); this.bfileMsg = new T4C8TTIBfile(this); this.blobMsg = new T4C8TTIBlob(this); this.clobMsg = new T4C8TTIClob(this); this.otxen = new T4CTTIOtxen(this); this.otxse = new T4CTTIOtxse(this); this.oping = new T4CTTIoping(this); this.k2rpc = new T4CTTIk2rpc(this); this.oses = new T4CTTIoses(this); this.okeyval = new T4CTTIokeyval(this); this.oxssro = new T4CTTIoxssro(this); this.oxsspo = new T4CTTIoxsspo(this); this.oxsscs = new T4CTTIoxsscs(this); this.xsnsop = new T4CTTIxsnsop(this); this.aqe = new T4Caqe(this); this.aqdq = new T4Caqdq(this); this.oscid = new T4CTTIoscid(this); this.LOGON_MODE = 0L; if (this.internalLogon != null)
/*      */         if (this.internalLogon.equalsIgnoreCase("sysoper")) {
/*      */           this.LOGON_MODE = 64L;
/*      */         } else if (this.internalLogon.equalsIgnoreCase("sysdba")) {
/*      */           this.LOGON_MODE = 32L;
/*      */         } else if (this.internalLogon.equalsIgnoreCase("sysasm")) {
/*      */           this.LOGON_MODE = 4194304L;
/*      */         }   if (this.prelimAuth)
/*      */         this.LOGON_MODE |= 0x80L;  this.auth = new T4CTTIoauthenticate(this, this.resourceManagerId, this.serverCompileTimeCapabilities); if (this.userName != null && this.userName.length() != 0)
/*      */         try {
/*      */           this.auth.doOSESSKEY(this.userName, this.LOGON_MODE);
/*      */         } catch (SQLException sQLException1) {
/*      */           if (sQLException1.getErrorCode() == 1017) {
/*      */             sQLException = sQLException1; this.userName = null;
/*      */           } else {
/*      */             throw sQLException1;
/*      */           } 
/*      */         }   this.auth.doOAUTH(this.userName, this.password, this.LOGON_MODE); this.sessionId = getSessionId(); this.serialNumber = getSerialNumber(); this.internalName = this.auth.internalName; this.externalName = this.auth.externalName; this.instanceName = this.sessionProperties.getProperty("AUTH_INSTANCENAME"); if (!this.prelimAuth) {
/*      */         T4C7Oversion t4C7Oversion = new T4C7Oversion(this); t4C7Oversion.doOVERSION(); byte[] arrayOfByte = t4C7Oversion.getVersion(); try {
/*      */           this.databaseProductVersion = new String(arrayOfByte, "UTF8");
/*      */         } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedEncodingException); sQLException1.fillInStackTrace(); throw sQLException1;
/*      */         }  this.versionNumber = t4C7Oversion.getVersionNumber();
/*      */       } else {
/*      */         this.versionNumber = 0;
/*      */       }  this.isLoggedOn = true; if (getVersionNumber() < 11000)
/*      */         this.enableTempLobRefCnt = false; 
/*      */     } catch (NetException netException) {
/*      */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException);
/*      */       sQLException1.fillInStackTrace();
/*      */       throw sQLException1;
/*      */     } catch (IOException iOException) {
/*      */       handleIOException(iOException);
/*      */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*      */       sQLException1.fillInStackTrace();
/*      */       throw sQLException1;
/*      */     } catch (SQLException sQLException1) {
/*      */       if (sQLException != null)
/*      */         sQLException1.initCause(sQLException); 
/*      */       try {
/*      */         this.net.disconnect();
/*      */       } catch (Exception exception) {}
/*      */       this.isLoggedOn = false;
/*      */       throw sQLException1;
/*      */     }  }
/*      */   void handleIOException(IOException paramIOException) throws SQLException { try {
/*      */       this.pipeState = -1;
/*      */       this.net.disconnect();
/*      */       this.net = null;
/*      */     } catch (Exception exception) {}
/*      */     this.isLoggedOn = false;
/*      */     this.lifecycle = 4; }
/*  221 */   int pipeState = -1; synchronized void logoff() throws SQLException { try { assertLoggedOn("T4CConnection.logoff"); if (this.lifecycle == 8) return;  sendPiggyBackedMessages(); this.commoncall.doOLOGOFF(); this.net.disconnect(); this.net = null; } catch (IOException iOException) { handleIOException(iOException); if (this.lifecycle != 8) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } finally { try { if (this.net != null) this.net.disconnect();  } catch (Exception exception) {} this.isLoggedOn = false; }  }
/*      */   T4CMAREngine getMarshalEngine() { return this.mare; }
/*      */   synchronized void doCommit(int paramInt) throws SQLException { assertLoggedOn("T4CConnection.do_commit"); try { sendPiggyBackedMessages(); if (paramInt == 0) { this.commoncall.doOCOMMIT(); } else { int i = 0; if ((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0) { i = i | 0x2 | 0x1; } else if ((paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) { i |= 0x2; }  if ((paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0) { i = i | 0x8 | 0x4; } else if ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0) { i |= 0x8; }  this.otxen.doOTXEN(1, null, null, 0, 0, 0, 0, 4, i); int j = this.otxen.getOutStateFromServer(); if (j == 2 || j != 4); }  } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   synchronized void doRollback() throws SQLException { try { assertLoggedOn("T4CConnection.do_rollback"); sendPiggyBackedMessages(); this.commoncall.doOROLLBACK(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   synchronized void doSetAutoCommit(boolean paramBoolean) throws SQLException { this.autocommit = paramBoolean; }
/*      */   public synchronized void open(OracleStatement paramOracleStatement) throws SQLException { assertLoggedOn("T4CConnection.open"); paramOracleStatement.setCursorId(0); }
/*      */   synchronized String doGetDatabaseProductVersion() throws SQLException { assertLoggedOn("T4CConnection.do_getDatabaseProductVersion"); T4C7Oversion t4C7Oversion = new T4C7Oversion(this); try { t4C7Oversion.doOVERSION(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  String str = null; byte[] arrayOfByte = t4C7Oversion.getVersion(); try { str = new String(arrayOfByte, "UTF8"); } catch (UnsupportedEncodingException unsupportedEncodingException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedEncodingException); sQLException.fillInStackTrace(); throw sQLException; }  return str; }
/*      */   synchronized short doGetVersionNumber() throws SQLException { assertLoggedOn("T4CConnection.do_getVersionNumber"); T4C7Oversion t4C7Oversion = new T4C7Oversion(this); try { t4C7Oversion.doOVERSION(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return t4C7Oversion.getVersionNumber(); }
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException { T4CStatement t4CStatement = new T4CStatement(this, -1, -1); try { int i = this.mare.unmarshalRefCursor(paramArrayOfbyte); t4CStatement.setCursorId(i); t4CStatement.isOpen = true; t4CStatement.sqlObject = paramOracleStatement.sqlObject; t4CStatement.serverCursor = true; paramOracleStatement.addChild(t4CStatement); t4CStatement.prepareForNewResults(true, false); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  t4CStatement.sqlStringChanged = false; t4CStatement.needToParse = false; return t4CStatement; }
/*      */   void cancelOperationOnServer() throws SQLException { try { switch (this.pipeState) { case -1: return;case 1: this.net.sendBreak(); break;case 2: this.net.sendInterrupt(); break; }  this.sentCancel = true; } catch (NetException netException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException); sQLException.fillInStackTrace(); throw sQLException; } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   void connect(String paramString) throws IOException, SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433); sQLException.fillInStackTrace(); throw sQLException; }  Properties properties = new Properties(); if (this.thinNetProfile != null) properties.setProperty("oracle.net.profile", this.thinNetProfile);  if (this.thinNetAuthenticationServices != null) properties.setProperty("oracle.net.authentication_services", this.thinNetAuthenticationServices);  if (this.thinNetAuthenticationKrb5Mutual != null) properties.setProperty("oracle.net.kerberos5_mutual_authentication", this.thinNetAuthenticationKrb5Mutual);  if (this.thinNetAuthenticationKrb5CcName != null) properties.setProperty("oracle.net.kerberos5_cc_name", this.thinNetAuthenticationKrb5CcName);  if (this.thinNetEncryptionLevel != null) properties.setProperty("oracle.net.encryption_client", this.thinNetEncryptionLevel);  if (this.thinNetEncryptionTypes != null) properties.setProperty("oracle.net.encryption_types_client", this.thinNetEncryptionTypes);  if (this.thinNetChecksumLevel != null) properties.setProperty("oracle.net.crypto_checksum_client", this.thinNetChecksumLevel);  if (this.thinNetChecksumTypes != null) properties.setProperty("oracle.net.crypto_checksum_types_client", this.thinNetChecksumTypes);  if (this.thinNetCryptoSeed != null) properties.setProperty("oracle.net.crypto_seed", this.thinNetCryptoSeed);  if (this.thinTcpNoDelay) properties.setProperty("TCP.NODELAY", "YES");  if (this.thinReadTimeout != null) properties.setProperty("oracle.net.READ_TIMEOUT", this.thinReadTimeout);  if (this.thinNetConnectTimeout != null) properties.setProperty("oracle.net.CONNECT_TIMEOUT", this.thinNetConnectTimeout);  if (this.thinSslServerDnMatch != null) properties.setProperty("oracle.net.ssl_server_dn_match", this.thinSslServerDnMatch);  if (this.walletLocation != null) properties.setProperty("oracle.net.wallet_location", this.walletLocation);  if (this.walletPassword != null) properties.setProperty("oracle.net.wallet_password", this.walletPassword);  if (this.thinSslVersion != null) properties.setProperty("oracle.net.ssl_version", this.thinSslVersion);  if (this.thinSslCipherSuites != null) properties.setProperty("oracle.net.ssl_cipher_suites", this.thinSslCipherSuites);  if (this.thinJavaxNetSslKeystore != null) properties.setProperty("javax.net.ssl.keyStore", this.thinJavaxNetSslKeystore);  if (this.thinJavaxNetSslKeystoretype != null) properties.setProperty("javax.net.ssl.keyStoreType", this.thinJavaxNetSslKeystoretype);  if (this.thinJavaxNetSslKeystorepassword != null) properties.setProperty("javax.net.ssl.keyStorePassword", this.thinJavaxNetSslKeystorepassword);  if (this.thinJavaxNetSslTruststore != null) properties.setProperty("javax.net.ssl.trustStore", this.thinJavaxNetSslTruststore);  if (this.thinJavaxNetSslTruststoretype != null) properties.setProperty("javax.net.ssl.trustStoreType", this.thinJavaxNetSslTruststoretype);  if (this.thinJavaxNetSslTruststorepassword != null) properties.setProperty("javax.net.ssl.trustStorePassword", this.thinJavaxNetSslTruststorepassword);  if (this.thinSslKeymanagerfactoryAlgorithm != null) properties.setProperty("ssl.keyManagerFactory.algorithm", this.thinSslKeymanagerfactoryAlgorithm);  if (this.thinSslTrustmanagerfactoryAlgorithm != null) properties.setProperty("ssl.trustManagerFactory.algorithm", this.thinSslTrustmanagerfactoryAlgorithm);  if (this.thinNetOldsyntax != null) properties.setProperty("oracle.net.oldSyntax", this.thinNetOldsyntax);  if (this.thinNamingContextInitial != null) properties.setProperty("java.naming.factory.initial", this.thinNamingContextInitial);  if (this.thinNamingProviderUrl != null) properties.setProperty("java.naming.provider.url", this.thinNamingProviderUrl);  if (this.thinNamingSecurityAuthentication != null) properties.setProperty("java.naming.security.authentication", this.thinNamingSecurityAuthentication);  if (this.thinNamingSecurityPrincipal != null) properties.setProperty("java.naming.security.principal", this.thinNamingSecurityPrincipal);  if (this.thinNamingSecurityCredentials != null)
/*      */       properties.setProperty("java.naming.security.credentials", this.thinNamingSecurityCredentials);  if (this.thinNetDisableOutOfBandBreak)
/*      */       properties.setProperty("DISABLE_OOB", "" + this.thinNetDisableOutOfBandBreak);  if (this.thinNetEnableSDP)
/*      */       properties.setProperty("oracle.net.SDP", "" + this.thinNetEnableSDP);  properties.setProperty("USE_ZERO_COPY_IO", "" + this.thinNetUseZeroCopyIO); properties.setProperty("FORCE_DNS_LOAD_BALANCING", "" + this.thinForceDnsLoadBalancing); properties.setProperty("ENABLE_JAVANET_FASTPATH", "" + this.enableJavaNetFastPath); properties.setProperty("oracle.jdbc.v$session.osuser", this.thinVsessionOsuser); properties.setProperty("oracle.jdbc.v$session.program", this.thinVsessionProgram); properties.setProperty("T4CConnection.hashCode", Integer.toHexString(hashCode()).toUpperCase()); properties.setProperty("oracle.net.keepAlive", Boolean.toString(this.keepAlive)); this.net = (Communication)new NSProtocol(); this.net.connect(paramString, properties); this.mare = new T4CMAREngine(this.net, this.enableJavaNetFastPath); this.oer = new T4CTTIoer(this); this.mare.setConnectionDuringExceptionHandling(this); this.pro = new T4C8TTIpro(this); this.pro.marshal(); this.serverCompileTimeCapabilities = this.pro.receive(); this.serverRuntimeCapabilities = this.pro.getServerRuntimeCapabilities(); short s1 = this.pro.getOracleVersion(); short s2 = this.pro.getCharacterSet(); short s3 = DBConversion.findDriverCharSet(s2, s1); this.conversion = new DBConversion(s2, s3, this.pro.getncharCHARSET(), this.isStrictAsciiConversion); this.mare.types.setServerConversion(!(s3 == s2)); if (DBConversion.isCharSetMultibyte(s3)) { if (DBConversion.isCharSetMultibyte(this.pro.getCharacterSet())) { this.mare.types.setFlags((byte)1); } else { this.mare.types.setFlags((byte)2); }  } else { this.mare.types.setFlags(this.pro.getFlags()); }  this.mare.conv = this.conversion; T4C8TTIdty t4C8TTIdty = new T4C8TTIdty(this, this.serverCompileTimeCapabilities, this.serverRuntimeCapabilities, (this.logonCap != null && this.logonCap.trim().equals("o3")), this.thinNetUseZeroCopyIO); t4C8TTIdty.doRPC(); this.negotiatedTTCversion = this.serverCompileTimeCapabilities[7]; if (t4C8TTIdty.jdbcThinCompileTimeCapabilities[7] < this.serverCompileTimeCapabilities[7])
/*      */       this.negotiatedTTCversion = t4C8TTIdty.jdbcThinCompileTimeCapabilities[7];  if (this.serverRuntimeCapabilities != null && this.serverRuntimeCapabilities.length > 6 && (this.serverRuntimeCapabilities[6] & T4C8TTIdty.KPCCAP_RTB_TTC_ZCPY) != 0 && this.thinNetUseZeroCopyIO && (this.net.getSessionAttributes().getNegotiatedOptions() & 0x40) != 0 && getDataIntegrityAlgorithmName().equals("") && getEncryptionAlgorithmName().equals("")) { this.useZeroCopyIO = true; } else { this.useZeroCopyIO = false; }  if (this.serverCompileTimeCapabilities.length > 23 && (this.serverCompileTimeCapabilities[23] & 0x40) != 0 && (t4C8TTIdty.jdbcThinCompileTimeCapabilities[23] & 0x40) != 0) { this.useLobPrefetch = true; } else { this.useLobPrefetch = false; }  }
/*  236 */   T4CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { super(paramString, paramProperties, paramOracleDriverExtension);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2603 */     this.checksumEngine = new CRC32();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2620 */     this.tempLobRefCount = new Hashtable<Long, Integer>(); this.cursorToClose = new int[4]; this.cursorToCloseOffset = 0; this.queryToClose = new int[10]; this.queryToCloseOffset = 0; this.lusFunctionId2 = new int[10]; this.lusSessionId2 = new byte[10][]; this.lusInKeyVal2 = new KeywordValueLong[10][]; this.lusInFlags2 = new int[10]; this.lusOffset2 = 0; this.minVcsBindSize = 0; this.streamChunkSize = 255; this.namespaces = new Hashtable<Object, Object>(5); } boolean isZeroCopyIOEnabled() { return this.useZeroCopyIO; } final T4CTTIoer getT4CTTIoer() { return this.oer; } final byte getTTCVersion() { return this.negotiatedTTCversion; } void doStartup(int paramInt) throws SQLException { try { byte b = 0; if (paramInt == OracleConnection.DatabaseStartupMode.FORCE.getMode()) { b = 16; } else if (paramInt == OracleConnection.DatabaseStartupMode.RESTRICT.getMode()) { b = 1; }  this.spfp.doOSPFPPUT(); this.sto.doOV6STRT(b); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void doShutdown(int paramInt) throws SQLException { try { char c = '\004'; if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL.getMode()) { c = ''; } else if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL_LOCAL.getMode()) { c = 'Ā'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.IMMEDIATE.getMode()) { c = '\002'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.FINAL.getMode()) { c = '\b'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.ABORT.getMode()) { c = '@'; }  sendPiggyBackedMessages(); this.sto.doOV6STOP(c); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void sendPiggyBackedMessages() throws SQLException, IOException { sendPiggyBackedClose(); if (this.endToEndAnyChanged && getTTCVersion() >= 3) { this.oscid.doOSCID(this.endToEndHasChanged, this.endToEndValues, this.endToEndECIDSequenceNumber); for (byte b = 0; b < 4; b++) { if (this.endToEndHasChanged[b]) this.endToEndHasChanged[b] = false;  }  }  this.endToEndAnyChanged = false; if (!this.namespaces.isEmpty()) { if (getTTCVersion() >= 4) { Object[] arrayOfObject = this.namespaces.values().toArray(); for (byte b = 0; b < arrayOfObject.length; b++) this.okeyval.doOKEYVAL((Namespace)arrayOfObject[b]);  }  this.namespaces.clear(); }  if (this.lusOffset2 > 0) { for (byte b = 0; b < this.lusOffset2; b++) this.oxsspo.doOXSSPO(this.lusFunctionId2[b], this.lusSessionId2[b], this.lusInKeyVal2[b], this.lusInFlags2[b]);  this.lusOffset2 = 0; }  } private void sendPiggyBackedClose() throws SQLException, IOException { if (this.queryToCloseOffset > 0) { this.close8.doOCANA(this.queryToClose, this.queryToCloseOffset); this.queryToCloseOffset = 0; }  if (this.cursorToCloseOffset > 0) { this.close8.doOCCA(this.cursorToClose, this.cursorToCloseOffset); this.cursorToCloseOffset = 0; }  } void doProxySession(int paramInt, Properties paramProperties) throws SQLException { try { sendPiggyBackedMessages(); this.auth.doOAUTH(paramInt, paramProperties, this.sessionId, this.serialNumber); int i = getSessionId(); int j = getSerialNumber(); this.oses.doO80SES(i, j, 1); this.savedUser = this.userName; if (paramInt == 1) { this.userName = paramProperties.getProperty("PROXY_USER_NAME"); } else { this.userName = null; }  this.isProxy = true; } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void closeProxySession() throws SQLException { try { sendPiggyBackedMessages(); this.commoncall.doOLOGOFF(); this.oses.doO80SES(this.sessionId, this.serialNumber, 1); this.userName = this.savedUser; } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void updateSessionProperties(KeywordValue[] paramArrayOfKeywordValue) throws SQLException { for (byte b = 0; b < paramArrayOfKeywordValue.length; b++) { int i = paramArrayOfKeywordValue[b].getKeyword(); byte[] arrayOfByte = paramArrayOfKeywordValue[b].getBinaryValue(); if (i < T4C8Oall.NLS_KEYS.length) { String str = T4C8Oall.NLS_KEYS[i]; if (str != null) if (arrayOfByte != null) { this.sessionProperties.setProperty(str, this.mare.conv.CharBytesToString(arrayOfByte, arrayOfByte.length)); } else if (paramArrayOfKeywordValue[b].getTextValue() != null) { this.sessionProperties.setProperty(str, paramArrayOfKeywordValue[b].getTextValue().trim()); }   } else if (i == 163) { if (arrayOfByte != null) { int j = arrayOfByte[4]; int k = arrayOfByte[5]; if ((arrayOfByte[4] & 0xFF) > 120) { int m = (arrayOfByte[4] & 0xFF) - 181; int n = (arrayOfByte[5] & 0xFF) - 60; } else { j = (arrayOfByte[4] & 0xFF) - 60; k = (arrayOfByte[5] & 0xFF) - 60; }  String str = ((j > 0) ? "+" : "") + j + ((k <= 9) ? ":0" : ":") + k; this.sessionProperties.setProperty("SESSION_TIME_ZONE", str); }  } else if (i != 165) { if (i != 166) if (i != 167) if (i != 168) if (i != 169) if (i != 170) if (i == 171);      }  }  } public Properties getServerSessionInfo() throws SQLException { if (getVersionNumber() >= 10000 && getVersionNumber() < 10200) queryFCFProperties(this.sessionProperties);  return this.sessionProperties; }
/*      */   public String getSessionTimeZoneOffset() throws SQLException { String str = getServerSessionInfo().getProperty("SESSION_TIME_ZONE"); if (str == null) { str = super.getSessionTimeZoneOffset(); } else { str = tzToOffset(str); }  return str; }
/*      */   int getSessionId() { int i = -1; String str = this.sessionProperties.getProperty("AUTH_SESSION_ID"); try { i = Integer.parseInt(str); } catch (NumberFormatException numberFormatException) {} return i; }
/*      */   int getSerialNumber() { int i = -1; String str = this.sessionProperties.getProperty("AUTH_SERIAL_NUM"); try { i = Integer.parseInt(str); } catch (NumberFormatException numberFormatException) {} return i; }
/* 2624 */   private final synchronized Long getLocatorHash(byte[] paramArrayOfbyte) { this.checksumEngine.reset();
/* 2625 */     this.checksumEngine.update(paramArrayOfbyte, 12, 8);
/* 2626 */     long l = this.checksumEngine.getValue();
/* 2627 */     return Long.valueOf(l); }
/*      */   public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { byte b = 0; if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED) { if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 6) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256); sQLException.fillInStackTrace(); throw sQLException; }  b = this.serverRuntimeCapabilities[5]; } else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE) { if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 4) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256); sQLException.fillInStackTrace(); throw sQLException; }  b = this.serverRuntimeCapabilities[3]; }  return b; }
/*      */   public synchronized BlobDBAccess createBlobDBAccess() throws SQLException { return this; }
/*      */   public synchronized ClobDBAccess createClobDBAccess() throws SQLException { return this; }
/*      */   public synchronized BfileDBAccess createBfileDBAccess() throws SQLException { return this; }
/*      */   public synchronized long length(BFILE paramBFILE) throws SQLException { assertLoggedOn("length"); assertNotNull(paramBFILE.shareBytes(), "length"); needLine(); long l = 0L; try { l = this.bfileMsg.getLength(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return l; }
/*      */   public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfbyte, long paramLong) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfbyte, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong) throws SQLException { assertNotNull(paramBFILE1.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong); l = (l == 0L) ? -1L : l; return l; }
/* 2635 */   public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException { assertLoggedOn("getBytes"); assertNotNull(paramBFILE.shareBytes(), "getBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt <= 0 || paramArrayOfbyte == null) return 0;  if (this.pipeState != -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  needLine(); long l = 0L; if (paramInt != 0) try { l = this.bfileMsg.read(paramBFILE.shareBytes(), paramLong, paramInt, paramArrayOfbyte, 0); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   return (int)l; } public String getName(BFILE paramBFILE) throws SQLException { assertLoggedOn("getName"); assertNotNull(paramBFILE.shareBytes(), "getName"); return LobPlsqlUtil.fileGetName(paramBFILE); } public String getDirAlias(BFILE paramBFILE) throws SQLException { assertLoggedOn("getDirAlias"); assertNotNull(paramBFILE.shareBytes(), "getDirAlias"); return LobPlsqlUtil.fileGetDirAlias(paramBFILE); } public synchronized void openFile(BFILE paramBFILE) throws SQLException { assertLoggedOn("openFile"); assertNotNull(paramBFILE.shareBytes(), "openFile"); needLine(); try { this.bfileMsg.open(paramBFILE.shareBytes(), 11); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized boolean isFileOpen(BFILE paramBFILE) throws SQLException { assertLoggedOn("openFile"); assertNotNull(paramBFILE.shareBytes(), "openFile"); needLine(); boolean bool = false; try { bool = this.bfileMsg.isOpen(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; } public synchronized boolean fileExists(BFILE paramBFILE) throws SQLException { assertLoggedOn("fileExists"); assertNotNull(paramBFILE.shareBytes(), "fileExists"); needLine(); boolean bool = false; try { bool = this.bfileMsg.doesExist(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; } public synchronized void closeFile(BFILE paramBFILE) throws SQLException { assertLoggedOn("closeFile"); assertNotNull(paramBFILE.shareBytes(), "closeFile"); needLine(); try { this.bfileMsg.close(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public final synchronized int decrementTempLobReferenceCount(byte[] paramArrayOfbyte) { int i = 0;
/* 2636 */     if (this.enableTempLobRefCnt && paramArrayOfbyte != null && paramArrayOfbyte.length > 20 && ((paramArrayOfbyte[7] & 0x1) > 0 || (paramArrayOfbyte[4] & 0x40) > 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2642 */       Long long_ = getLocatorHash(paramArrayOfbyte);
/* 2643 */       Integer integer = this.tempLobRefCount.get(long_);
/* 2644 */       if (integer != null) {
/*      */         
/* 2646 */         i = integer.intValue() - 1;
/* 2647 */         if (i == 0) {
/* 2648 */           this.tempLobRefCount.remove(long_);
/*      */         } else {
/* 2650 */           this.tempLobRefCount.put(long_, Integer.valueOf(i));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2659 */     return i; }
/*      */   public synchronized void open(BFILE paramBFILE, int paramInt) throws SQLException { assertLoggedOn("open"); assertNotNull(paramBFILE.shareBytes(), "open"); needLine(); try { this.bfileMsg.open(paramBFILE.shareBytes(), paramInt); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public synchronized void close(BFILE paramBFILE) throws SQLException { assertLoggedOn("close"); assertNotNull(paramBFILE.shareBytes(), "close"); needLine(); try { this.bfileMsg.close(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public synchronized boolean isOpen(BFILE paramBFILE) throws SQLException { assertLoggedOn("isOpen"); assertNotNull(paramBFILE.shareBytes(), "isOpen"); needLine(); boolean bool = false; try { bool = this.bfileMsg.isOpen(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; }
/* 2663 */   public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException { if (paramLong == 0L) return new OracleBlobInputStream(paramBFILE, paramInt);  return new OracleBlobInputStream(paramBFILE, paramInt, paramLong); } public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "newConversionInputStream"); return new OracleConversionInputStream(this.conversion, paramBFILE.getBinaryStream(), paramInt); } public Reader newConversionReader(BFILE paramBFILE, int paramInt) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "newConversionReader"); return new OracleConversionReader(this.conversion, paramBFILE.getBinaryStream(), paramInt); } public synchronized long length(BLOB paramBLOB) throws SQLException { assertLoggedOn("length"); assertNotNull(paramBLOB.shareBytes(), "length"); needLine(); long l = 0L; try { l = this.blobMsg.getLength(paramBLOB.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return l; } public long position(BLOB paramBLOB, byte[] paramArrayOfbyte, long paramLong) throws SQLException { assertLoggedOn("position"); assertNotNull(paramBLOB.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfbyte, paramLong); l = (l == 0L) ? -1L : l; return l; } public long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong) throws SQLException { assertLoggedOn("position"); assertNotNull(paramBLOB1.shareBytes(), "position"); assertNotNull(paramBLOB2.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong); l = (l == 0L) ? -1L : l; return l; } public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException { assertLoggedOn("getBytes"); assertNotNull(paramBLOB.shareBytes(), "getBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (this.pipeState != -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt <= 0 || paramArrayOfbyte == null) return 0;  long l1 = 0L; long l2 = -1L; if (paramBLOB.isActivePrefetch()) { byte[] arrayOfByte = paramBLOB.getPrefetchedData(); int i = paramBLOB.getPrefetchedDataSize(); l2 = paramBLOB.length(); int j = 0; if (arrayOfByte != null) j = Math.min(i, arrayOfByte.length);  if (j > 0 && paramLong <= j) { int k = Math.min(j - (int)paramLong + 1, paramInt); System.arraycopy(arrayOfByte, (int)paramLong - 1, paramArrayOfbyte, 0, k); l1 += k; }  }  if (l1 < paramInt && (l2 == -1L || paramLong - 1L + l1 < l2)) { needLine(); try { l1 += this.blobMsg.read(paramBLOB.shareBytes(), paramLong + l1, paramInt - l1, paramArrayOfbyte, (int)l1); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }  return (int)l1; } public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException { assertLoggedOn("putBytes"); assertNotNull(paramBLOB.shareBytes(), "putBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramArrayOfbyte == null || paramInt2 <= 0) return 0;  needLine(); long l = 0L; if (paramInt2 != 0) try { paramBLOB.setActivePrefetch(false); paramBLOB.clearCachedData(); l = this.blobMsg.write(paramBLOB.shareBytes(), paramLong, paramArrayOfbyte, paramInt1, paramInt2); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   return (int)l; } public synchronized int getChunkSize(BLOB paramBLOB) throws SQLException { assertLoggedOn("getChunkSize"); assertNotNull(paramBLOB.shareBytes(), "getChunkSize"); needLine(); long l = 0L; try { l = this.blobMsg.getChunkSize(paramBLOB.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return (int)l; } public synchronized void trim(BLOB paramBLOB, long paramLong) throws SQLException { assertLoggedOn("trim"); assertNotNull(paramBLOB.shareBytes(), "trim"); if (paramLong < 0L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()"); sQLException.fillInStackTrace(); throw sQLException; }  needLine(); try { paramBLOB.setActivePrefetch(false); paramBLOB.clearCachedData(); this.blobMsg.trim(paramBLOB.shareBytes(), paramLong); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException { assertLoggedOn("createTemporaryBlob"); needLine(); BLOB bLOB = null; try { bLOB = (BLOB)this.blobMsg.createTemporaryLob((Connection)this, paramBoolean, paramInt); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bLOB; } public final synchronized void incrementTempLobReferenceCount(byte[] paramArrayOfbyte) { if (this.enableTempLobRefCnt && paramArrayOfbyte != null && paramArrayOfbyte.length >= 20 && ((paramArrayOfbyte[7] & 0x1) > 0 || (paramArrayOfbyte[4] & 0x40) > 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2669 */       Long long_ = getLocatorHash(paramArrayOfbyte);
/* 2670 */       Integer integer = this.tempLobRefCount.get(long_);
/*      */       
/* 2672 */       if (integer != null) {
/*      */         
/* 2674 */         int i = integer.intValue();
/* 2675 */         this.tempLobRefCount.put(long_, Integer.valueOf(i + 1));
/*      */       }
/*      */       else {
/*      */         
/* 2679 */         this.tempLobRefCount.put(long_, Integer.valueOf(1));
/*      */       } 
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean) throws SQLException {
/* 2695 */     assertLoggedOn("freeTemporary");
/* 2696 */     assertNotNull(paramBLOB.shareBytes(), "freeTemporary");
/*      */     
/* 2698 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2702 */       this.blobMsg.freeTemporaryLob(paramBLOB.shareBytes());
/*      */     }
/* 2704 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2707 */       handleIOException(iOException);
/*      */       
/* 2709 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2710 */       sQLException.fillInStackTrace();
/* 2711 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTemporary(BLOB paramBLOB) throws SQLException {
/* 2730 */     assertNotNull(paramBLOB.shareBytes(), "isTemporary");
/*      */ 
/*      */ 
/*      */     
/* 2734 */     boolean bool = false;
/* 2735 */     byte[] arrayOfByte = paramBLOB.shareBytes();
/*      */     
/* 2737 */     if ((arrayOfByte[7] & 0x1) > 0 || (arrayOfByte[4] & 0x40) > 0) {
/* 2738 */       bool = true;
/*      */     }
/* 2740 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2753 */     assertLoggedOn("open");
/* 2754 */     assertNotNull(paramBLOB.shareBytes(), "open");
/*      */     
/* 2756 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2760 */       this.blobMsg.open(paramBLOB.shareBytes(), paramInt);
/*      */     }
/* 2762 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2765 */       handleIOException(iOException);
/*      */       
/* 2767 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2768 */       sQLException.fillInStackTrace();
/* 2769 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BLOB paramBLOB) throws SQLException {
/* 2784 */     assertLoggedOn("close");
/* 2785 */     assertNotNull(paramBLOB.shareBytes(), "close");
/*      */     
/* 2787 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2791 */       this.blobMsg.close(paramBLOB.shareBytes());
/*      */     }
/* 2793 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2796 */       handleIOException(iOException);
/*      */       
/* 2798 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2799 */       sQLException.fillInStackTrace();
/* 2800 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BLOB paramBLOB) throws SQLException {
/* 2816 */     assertLoggedOn("isOpen");
/* 2817 */     assertNotNull(paramBLOB.shareBytes(), "isOpen");
/*      */     
/* 2819 */     needLine();
/*      */     
/* 2821 */     boolean bool = false;
/*      */ 
/*      */     
/*      */     try {
/* 2825 */       bool = this.blobMsg.isOpen(paramBLOB.shareBytes());
/*      */     }
/* 2827 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2830 */       handleIOException(iOException);
/*      */       
/* 2832 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2833 */       sQLException.fillInStackTrace();
/* 2834 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2839 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/* 2858 */     if (paramLong == 0L)
/*      */     {
/* 2860 */       return new OracleBlobInputStream(paramBLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 2864 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 2887 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 2907 */     if (paramLong == 0L) {
/*      */       
/* 2909 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 2912 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2913 */         sQLException.fillInStackTrace();
/* 2914 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2919 */       return new OracleBlobOutputStream(paramBLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2924 */     return new OracleBlobOutputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2943 */     assertNotNull(paramBLOB.shareBytes(), "newConversionInputStream");
/*      */     
/* 2945 */     return new OracleConversionInputStream(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2966 */     assertNotNull(paramBLOB.shareBytes(), "newConversionReader");
/*      */     
/* 2968 */     return new OracleConversionReader(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(CLOB paramCLOB) throws SQLException {
/* 2996 */     assertLoggedOn("length");
/* 2997 */     assertNotNull(paramCLOB.shareBytes(), "length");
/*      */     
/* 2999 */     needLine();
/*      */     
/* 3001 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/* 3005 */       l = this.clobMsg.getLength(paramCLOB.shareBytes());
/*      */     }
/* 3007 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3010 */       handleIOException(iOException);
/*      */       
/* 3012 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3013 */       sQLException.fillInStackTrace();
/* 3014 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3019 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long position(CLOB paramCLOB, String paramString, long paramLong) throws SQLException {
/* 3036 */     if (paramString == null) {
/*      */       
/* 3038 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3039 */       sQLException.fillInStackTrace();
/* 3040 */       throw sQLException;
/*      */     } 
/*      */     
/* 3043 */     assertLoggedOn("position");
/* 3044 */     assertNotNull(paramCLOB.shareBytes(), "position");
/*      */ 
/*      */     
/* 3047 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3050 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3051 */       sQLException.fillInStackTrace();
/* 3052 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3057 */     char[] arrayOfChar = new char[paramString.length()];
/*      */     
/* 3059 */     paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
/*      */     
/* 3061 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, arrayOfChar, paramLong);
/*      */     
/* 3063 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 3065 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong) throws SQLException {
/* 3081 */     if (paramCLOB2 == null) {
/*      */       
/* 3083 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3084 */       sQLException.fillInStackTrace();
/* 3085 */       throw sQLException;
/*      */     } 
/*      */     
/* 3088 */     assertLoggedOn("position");
/* 3089 */     assertNotNull(paramCLOB1.shareBytes(), "position");
/* 3090 */     assertNotNull(paramCLOB2.shareBytes(), "position");
/*      */     
/* 3092 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3095 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3096 */       sQLException.fillInStackTrace();
/* 3097 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3101 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 3103 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 3105 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 3122 */     assertLoggedOn("getChars");
/* 3123 */     assertNotNull(paramCLOB.shareBytes(), "getChars");
/*      */     
/* 3125 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3128 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getChars()");
/* 3129 */       sQLException.fillInStackTrace();
/* 3130 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3136 */     if (this.pipeState != -1) {
/*      */ 
/*      */       
/* 3139 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getChars()");
/* 3140 */       sQLException.fillInStackTrace();
/* 3141 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3146 */     if (paramInt <= 0 || paramArrayOfchar == null) {
/* 3147 */       return 0;
/*      */     }
/*      */     
/* 3150 */     long l1 = 0L;
/*      */ 
/*      */     
/* 3153 */     long l2 = -1L;
/*      */ 
/*      */     
/* 3156 */     if (paramCLOB.isActivePrefetch()) {
/*      */       
/* 3158 */       l2 = paramCLOB.length();
/* 3159 */       char[] arrayOfChar = paramCLOB.getPrefetchedData();
/* 3160 */       int i = paramCLOB.getPrefetchedDataSize();
/*      */       
/* 3162 */       int j = 0;
/* 3163 */       if (arrayOfChar != null) {
/* 3164 */         j = Math.min(i, arrayOfChar.length);
/*      */       }
/* 3166 */       if (j > 0 && paramLong <= j) {
/*      */ 
/*      */ 
/*      */         
/* 3170 */         int k = Math.min(j - (int)paramLong + 1, paramInt);
/*      */ 
/*      */ 
/*      */         
/* 3174 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfchar, 0, k);
/* 3175 */         l1 += k;
/*      */       } 
/*      */     } 
/*      */     
/* 3179 */     if (l1 < paramInt && (l2 == -1L || paramLong - 1L + l1 < l2)) {
/*      */ 
/*      */       
/* 3182 */       needLine();
/*      */       
/*      */       try {
/* 3185 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3187 */         l1 += this.clobMsg.read(paramCLOB.shareBytes(), (int)paramLong + l1, paramInt - l1, bool, paramArrayOfchar, (int)l1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 3194 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3197 */         handleIOException(iOException);
/*      */         
/* 3199 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3200 */         sQLException.fillInStackTrace();
/* 3201 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3208 */     return (int)l1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 3228 */     assertLoggedOn("putChars");
/* 3229 */     assertNotNull(paramCLOB.shareBytes(), "putChars");
/*      */     
/* 3231 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3234 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putChars()");
/* 3235 */       sQLException.fillInStackTrace();
/* 3236 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3240 */     if (paramArrayOfchar == null || paramInt2 <= 0) {
/* 3241 */       return 0;
/*      */     }
/* 3243 */     needLine();
/*      */     
/* 3245 */     long l = 0L;
/*      */     
/* 3247 */     if (paramInt2 != 0) {
/*      */       
/*      */       try {
/*      */         
/* 3251 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3253 */         paramCLOB.setActivePrefetch(false);
/* 3254 */         paramCLOB.clearCachedData();
/* 3255 */         l = this.clobMsg.write(paramCLOB.shareBytes(), paramLong, bool, paramArrayOfchar, paramInt1, paramInt2);
/*      */       
/*      */       }
/* 3258 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3261 */         handleIOException(iOException);
/*      */         
/* 3263 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3264 */         sQLException.fillInStackTrace();
/* 3265 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3271 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(CLOB paramCLOB) throws SQLException {
/* 3283 */     assertLoggedOn("getChunkSize");
/* 3284 */     assertNotNull(paramCLOB.shareBytes(), "getChunkSize");
/*      */     
/* 3286 */     needLine();
/*      */     
/* 3288 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/* 3292 */       l = this.clobMsg.getChunkSize(paramCLOB.shareBytes());
/*      */     }
/* 3294 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3297 */       handleIOException(iOException);
/*      */       
/* 3299 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3300 */       sQLException.fillInStackTrace();
/* 3301 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3306 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong) throws SQLException {
/* 3320 */     assertLoggedOn("trim");
/* 3321 */     assertNotNull(paramCLOB.shareBytes(), "trim");
/*      */ 
/*      */     
/* 3324 */     if (paramLong < 0L) {
/*      */ 
/*      */       
/* 3327 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()");
/* 3328 */       sQLException.fillInStackTrace();
/* 3329 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3334 */     needLine();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3339 */       paramCLOB.setActivePrefetch(false);
/* 3340 */       paramCLOB.clearCachedData();
/* 3341 */       this.clobMsg.trim(paramCLOB.shareBytes(), paramLong);
/*      */     }
/* 3343 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3346 */       handleIOException(iOException);
/*      */       
/* 3348 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3349 */       sQLException.fillInStackTrace();
/* 3350 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/* 3373 */     assertLoggedOn("createTemporaryClob");
/*      */ 
/*      */     
/* 3376 */     if (paramShort != 2 && paramShort != 1) {
/*      */ 
/*      */ 
/*      */       
/* 3380 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
/* 3381 */       sQLException.fillInStackTrace();
/* 3382 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3386 */     needLine();
/*      */     
/* 3388 */     CLOB cLOB = null;
/*      */ 
/*      */     
/*      */     try {
/* 3392 */       cLOB = (CLOB)this.clobMsg.createTemporaryLob((Connection)this, paramBoolean, paramInt, paramShort);
/*      */     
/*      */     }
/* 3395 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3398 */       handleIOException(iOException);
/*      */       
/* 3400 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3401 */       sQLException.fillInStackTrace();
/* 3402 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3407 */     return cLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean) throws SQLException {
/* 3422 */     assertLoggedOn("freeTemporary");
/* 3423 */     assertNotNull(paramCLOB.shareBytes(), "freeTemporary");
/*      */     
/* 3425 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3429 */       this.clobMsg.freeTemporaryLob(paramCLOB.shareBytes());
/*      */     }
/* 3431 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3434 */       handleIOException(iOException);
/*      */       
/* 3436 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3437 */       sQLException.fillInStackTrace();
/* 3438 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTemporary(CLOB paramCLOB) throws SQLException {
/* 3459 */     boolean bool = false;
/* 3460 */     byte[] arrayOfByte = paramCLOB.shareBytes();
/*      */     
/* 3462 */     if ((arrayOfByte[7] & 0x1) > 0 || (arrayOfByte[4] & 0x40) > 0) {
/* 3463 */       bool = true;
/*      */     }
/* 3465 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt) throws SQLException {
/* 3478 */     assertLoggedOn("open");
/* 3479 */     assertNotNull(paramCLOB.shareBytes(), "open");
/*      */     
/* 3481 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3485 */       this.clobMsg.open(paramCLOB.shareBytes(), paramInt);
/*      */     }
/* 3487 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3490 */       handleIOException(iOException);
/*      */       
/* 3492 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3493 */       sQLException.fillInStackTrace();
/* 3494 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(CLOB paramCLOB) throws SQLException {
/* 3509 */     assertLoggedOn("close");
/* 3510 */     assertNotNull(paramCLOB.shareBytes(), "close");
/*      */     
/* 3512 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3516 */       this.clobMsg.close(paramCLOB.shareBytes());
/*      */     }
/* 3518 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3521 */       handleIOException(iOException);
/*      */       
/* 3523 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3524 */       sQLException.fillInStackTrace();
/* 3525 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(CLOB paramCLOB) throws SQLException {
/* 3541 */     assertLoggedOn("isOpen");
/* 3542 */     assertNotNull(paramCLOB.shareBytes(), "isOpen");
/*      */     
/* 3544 */     boolean bool = false;
/*      */     
/* 3546 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3550 */       bool = this.clobMsg.isOpen(paramCLOB.shareBytes());
/*      */     }
/* 3552 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3555 */       handleIOException(iOException);
/*      */       
/* 3557 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3558 */       sQLException.fillInStackTrace();
/* 3559 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3564 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3583 */     if (paramLong == 0L)
/*      */     {
/* 3585 */       return new OracleClobInputStream(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3589 */     return new OracleClobInputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3610 */     if (paramLong == 0L) {
/*      */       
/* 3612 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3615 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3616 */         sQLException.fillInStackTrace();
/* 3617 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3622 */       return new OracleClobOutputStream(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3627 */     return new OracleClobOutputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3647 */     if (paramLong == 0L)
/*      */     {
/* 3649 */       return new OracleClobReader(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3653 */     return new OracleClobReader(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3674 */     return new OracleClobReader(paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3693 */     if (paramLong == 0L) {
/*      */       
/* 3695 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3698 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3699 */         sQLException.fillInStackTrace();
/* 3700 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3705 */       return new OracleClobWriter(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3710 */     return new OracleClobWriter(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertLoggedOn(String paramString) throws SQLException {
/* 3736 */     if (!this.isLoggedOn) {
/*      */ 
/*      */       
/* 3739 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 430);
/* 3740 */       sQLException.fillInStackTrace();
/* 3741 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertNotNull(byte[] paramArrayOfbyte, String paramString) throws NullPointerException {
/* 3759 */     if (paramArrayOfbyte == null)
/*      */     {
/* 3761 */       throw new NullPointerException("bytes are null");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internalClose() throws SQLException {
/* 3770 */     super.internalClose();
/*      */     
/* 3772 */     this.isLoggedOn = false;
/*      */     
/*      */     try {
/* 3775 */       if (this.net != null) {
/* 3776 */         this.net.disconnect();
/*      */       }
/* 3778 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAbort() throws SQLException {
/*      */     try {
/* 3790 */       this.net.abort();
/*      */     }
/* 3792 */     catch (NetException netException) {
/*      */ 
/*      */ 
/*      */       
/* 3796 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException);
/* 3797 */       sQLException.fillInStackTrace();
/* 3798 */       throw sQLException;
/*      */ 
/*      */     
/*      */     }
/* 3802 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3805 */       handleIOException(iOException);
/*      */       
/* 3807 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3808 */       sQLException.fillInStackTrace();
/* 3809 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/* 3820 */     T4CStatement t4CStatement = new T4CStatement(this, -1, -1);
/* 3821 */     t4CStatement.open();
/*      */     
/* 3823 */     String str1 = paramAutoKeyInfo.getTableName();
/* 3824 */     String str2 = "SELECT * FROM " + str1;
/*      */     
/* 3826 */     t4CStatement.sqlObject.initialize(str2);
/*      */     
/* 3828 */     Accessor[] arrayOfAccessor = null;
/*      */ 
/*      */     
/*      */     try {
/* 3832 */       this.describe.doODNY(t4CStatement, 0, arrayOfAccessor, t4CStatement.sqlObject.getSqlBytes(false, false));
/* 3833 */       arrayOfAccessor = this.describe.getAccessors();
/*      */     }
/* 3835 */     catch (IOException iOException) {
/*      */       
/* 3837 */       handleIOException(iOException);
/*      */       
/* 3839 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3840 */       sQLException.fillInStackTrace();
/* 3841 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3845 */     int i = this.describe.numuds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3856 */     paramAutoKeyInfo.allocateSpaceForDescribedData(i);
/*      */     
/* 3858 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 3860 */       Accessor accessor = arrayOfAccessor[b];
/* 3861 */       String str3 = accessor.columnName;
/* 3862 */       int j = accessor.describeType;
/* 3863 */       int k = accessor.describeMaxLength;
/* 3864 */       boolean bool = accessor.nullable;
/* 3865 */       short s = accessor.formOfUse;
/* 3866 */       int m = accessor.precision;
/* 3867 */       int n = accessor.scale;
/* 3868 */       String str4 = accessor.describeTypeName;
/*      */       
/* 3870 */       paramAutoKeyInfo.fillDescribedData(b, str3, j, k, bool, s, m, n, str4);
/*      */     } 
/*      */ 
/*      */     
/* 3874 */     t4CStatement.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 3885 */     Namespace namespace = (Namespace)this.namespaces.get(paramString1);
/* 3886 */     if (namespace == null) {
/*      */       
/* 3888 */       namespace = new Namespace(paramString1);
/* 3889 */       this.namespaces.put(paramString1, namespace);
/*      */     } 
/* 3891 */     namespace.setAttribute(paramString2, paramString3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClearAllApplicationContext(String paramString) throws SQLException {
/* 3900 */     Namespace namespace = new Namespace(paramString);
/* 3901 */     namespace.clear();
/* 3902 */     this.namespaces.put(paramString, namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 3910 */     getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void getPasswordInternal(T4CXAResource paramT4CXAResource) throws SQLException {
/* 3918 */     paramT4CXAResource.setPasswordInternal(this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 3936 */       needLine();
/* 3937 */       sendPiggyBackedMessages();
/* 3938 */       this.aqe.doOAQEQ(paramString, paramAQEnqueueOptions, paramAQMessagePropertiesI, paramArrayOfbyte2, paramArrayOfbyte1, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3945 */       if (paramAQEnqueueOptions.getRetrieveMessageId()) {
/* 3946 */         paramArrayOfbyte[0] = this.aqe.getMessageId();
/*      */       }
/* 3948 */     } catch (IOException iOException) {
/*      */       
/* 3950 */       handleIOException(iOException);
/*      */       
/* 3952 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3953 */       sQLException.fillInStackTrace();
/* 3954 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException {
/* 3971 */     boolean bool = false;
/*      */     
/*      */     try {
/* 3974 */       needLine();
/* 3975 */       sendPiggyBackedMessages();
/* 3976 */       this.aqdq.doOAQDQ(paramString, paramAQDequeueOptions, paramArrayOfbyte, paramBoolean, paramAQMessagePropertiesI);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3982 */       paramArrayOfbyte1[0] = this.aqdq.getPayload();
/* 3983 */       paramArrayOfbyte2[0] = this.aqdq.getDequeuedMessageId();
/* 3984 */       bool = this.aqdq.hasAMessageBeenDequeued();
/*      */     }
/* 3986 */     catch (IOException iOException) {
/*      */       
/* 3988 */       handleIOException(iOException);
/*      */       
/* 3990 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3991 */       sQLException.fillInStackTrace();
/* 3992 */       throw sQLException;
/*      */     } 
/*      */     
/* 3995 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int doPingDatabase() throws SQLException {
/* 4002 */     if (this.versionNumber >= 10102) {
/*      */ 
/*      */       
/*      */       try {
/* 4006 */         needLine();
/* 4007 */         sendPiggyBackedMessages();
/* 4008 */         this.oping.doOPING();
/*      */       }
/* 4010 */       catch (IOException iOException) {
/*      */         
/* 4012 */         return -1;
/*      */       }
/* 4014 */       catch (SQLException sQLException) {
/*      */         
/* 4016 */         return -1;
/*      */       } 
/* 4018 */       return 0;
/*      */     } 
/*      */ 
/*      */     
/* 4022 */     return super.doPingDatabase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException {
/* 4035 */     int i = paramArrayOfString.length;
/* 4036 */     int[] arrayOfInt1 = new int[i];
/* 4037 */     byte[][] arrayOfByte = new byte[i][];
/* 4038 */     int[] arrayOfInt2 = new int[i];
/* 4039 */     int[] arrayOfInt3 = new int[i];
/* 4040 */     int[] arrayOfInt4 = new int[i];
/* 4041 */     int[] arrayOfInt5 = new int[i];
/* 4042 */     int[] arrayOfInt6 = new int[i];
/* 4043 */     int[] arrayOfInt7 = new int[i];
/* 4044 */     long[] arrayOfLong = new long[i];
/* 4045 */     byte[] arrayOfByte1 = new byte[i];
/* 4046 */     int[] arrayOfInt8 = new int[i];
/* 4047 */     byte[] arrayOfByte2 = new byte[i];
/* 4048 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[i];
/* 4049 */     int[] arrayOfInt9 = new int[i];
/*      */     
/* 4051 */     boolean bool = false;
/* 4052 */     if (paramInt == 0) {
/*      */ 
/*      */       
/* 4055 */       bool = true;
/* 4056 */       paramInt = 47632;
/*      */     } 
/*      */     
/* 4059 */     for (byte b1 = 0; b1 < i; b1++) {
/*      */       
/* 4061 */       arrayOfInt1[b1] = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4062 */       arrayOfByte[b1] = new byte[4];
/* 4063 */       arrayOfByte[b1][0] = (byte)((arrayOfInt1[b1] & 0xFF000000) >> 24);
/* 4064 */       arrayOfByte[b1][1] = (byte)((arrayOfInt1[b1] & 0xFF0000) >> 16);
/* 4065 */       arrayOfByte[b1][2] = (byte)((arrayOfInt1[b1] & 0xFF00) >> 8);
/* 4066 */       arrayOfByte[b1][3] = (byte)(arrayOfInt1[b1] & 0xFF);
/* 4067 */       arrayOfInt2[b1] = 1;
/* 4068 */       arrayOfInt3[b1] = 23;
/*      */ 
/*      */       
/* 4071 */       if (paramArrayOfProperties.length > b1 && paramArrayOfProperties[b1] != null) {
/*      */         
/* 4073 */         if (paramArrayOfProperties[b1].getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4075 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x1; } 
/* 4076 */         if (paramArrayOfProperties[b1].getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4078 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x10; } 
/* 4079 */         if (paramArrayOfProperties[b1].getProperty("NTF_AQ_PAYLOAD", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4081 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x2; } 
/* 4082 */         arrayOfInt5[b1] = readNTFtimeout(paramArrayOfProperties[b1]);
/*      */       } 
/*      */     } 
/*      */     
/* 4086 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9, paramArrayOfProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4093 */     int[] arrayOfInt10 = new int[1];
/* 4094 */     arrayOfInt10[0] = paramInt;
/*      */ 
/*      */ 
/*      */     
/* 4098 */     boolean bool1 = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt10, bool);
/* 4099 */     paramInt = arrayOfInt10[0];
/*      */     
/* 4101 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt + "))?PR=0";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/* 4108 */         boolean bool2 = bool1 ? true : false;
/* 4109 */         sendPiggyBackedMessages();
/* 4110 */         this.okpn.doOKPN(1, bool2, this.userName, str, i, arrayOfInt2, paramArrayOfString, arrayOfByte, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfLong, arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 4132 */       catch (IOException iOException) {
/*      */         
/* 4134 */         handleIOException(iOException);
/*      */         
/* 4136 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4137 */         sQLException.fillInStackTrace();
/* 4138 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/* 4142 */     catch (SQLException sQLException) {
/*      */       
/* 4144 */       if (bool1) {
/* 4145 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt);
/*      */       }
/* 4147 */       throw sQLException;
/*      */     } 
/* 4149 */     NTFAQRegistration[] arrayOfNTFAQRegistration = new NTFAQRegistration[i];
/*      */     byte b2;
/* 4151 */     for (b2 = 0; b2 < i; b2++) {
/* 4152 */       arrayOfNTFAQRegistration[b2] = new NTFAQRegistration(arrayOfInt1[b2], true, this.instanceName, this.userName, paramString, paramInt, paramArrayOfProperties[b2], paramArrayOfString[b2], this.versionNumber);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4162 */     for (b2 = 0; b2 < arrayOfNTFAQRegistration.length; b2++)
/* 4163 */       PhysicalConnection.ntfManager.addRegistration(arrayOfNTFAQRegistration[b2]); 
/* 4164 */     return arrayOfNTFAQRegistration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setNtfGroupingOptions(byte[] paramArrayOfbyte1, int[] paramArrayOfint1, byte[] paramArrayOfbyte2, TIMESTAMPTZ[] paramArrayOfTIMESTAMPTZ, int[] paramArrayOfint2, Properties[] paramArrayOfProperties) throws SQLException {
/* 4183 */     for (byte b = 0; b < paramArrayOfProperties.length; b++) {
/*      */       
/* 4185 */       String str1 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_CLASS", "NTF_GROUPING_CLASS_NONE");
/* 4186 */       String str2 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_VALUE");
/* 4187 */       String str3 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_TYPE");
/* 4188 */       TIMESTAMPTZ tIMESTAMPTZ = null;
/* 4189 */       if (paramArrayOfProperties[b].get("NTF_GROUPING_START_TIME") != null)
/* 4190 */         tIMESTAMPTZ = (TIMESTAMPTZ)paramArrayOfProperties[b].get("NTF_GROUPING_START_TIME"); 
/* 4191 */       String str4 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_REPEAT_TIME", "NTF_GROUPING_REPEAT_FOREVER");
/*      */ 
/*      */       
/* 4194 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") != 0 && str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0) {
/*      */ 
/*      */ 
/*      */         
/* 4198 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4199 */         sQLException.fillInStackTrace();
/* 4200 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4205 */       if (str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0 && getTTCVersion() < 5) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4210 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4211 */         sQLException.fillInStackTrace();
/* 4212 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4218 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") == 0) {
/*      */         
/* 4220 */         paramArrayOfbyte1[b] = 1;
/*      */         
/* 4222 */         paramArrayOfint1[b] = 600;
/* 4223 */         if (str2 != null) {
/* 4224 */           paramArrayOfint1[b] = Integer.parseInt(str2);
/*      */         }
/* 4226 */         paramArrayOfbyte2[b] = 1;
/* 4227 */         if (str3 != null)
/*      */         {
/* 4229 */           if (str3.compareTo("NTF_GROUPING_TYPE_SUMMARY") == 0) {
/* 4230 */             paramArrayOfbyte2[b] = 1;
/* 4231 */           } else if (str3.compareTo("NTF_GROUPING_TYPE_LAST") == 0) {
/* 4232 */             paramArrayOfbyte2[b] = 2;
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 4238 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4239 */             sQLException.fillInStackTrace();
/* 4240 */             throw sQLException;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 4245 */         paramArrayOfTIMESTAMPTZ[b] = tIMESTAMPTZ;
/* 4246 */         if (str4.compareTo("NTF_GROUPING_REPEAT_FOREVER") == 0) {
/* 4247 */           paramArrayOfint2[b] = 0;
/*      */         } else {
/* 4249 */           paramArrayOfint2[b] = Integer.parseInt(str4);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException {
/* 4261 */     String str1 = paramNTFAQRegistration.getClientHost();
/* 4262 */     int i = paramNTFAQRegistration.getClientTCPPort();
/* 4263 */     if (str1 == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4274 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFAQRegistration);
/* 4275 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFAQRegistration.getJdbcRegId());
/* 4276 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFAQRegistration.getClientTCPPort());
/* 4277 */     paramNTFAQRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 4279 */     String str2 = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + i + "))?PR=0";
/*      */ 
/*      */     
/* 4282 */     int[] arrayOfInt1 = { 1 };
/* 4283 */     String[] arrayOfString = new String[1];
/* 4284 */     arrayOfString[0] = paramNTFAQRegistration.getQueueName();
/* 4285 */     int[] arrayOfInt2 = { 0 };
/* 4286 */     int[] arrayOfInt3 = { 0 };
/* 4287 */     int[] arrayOfInt4 = { 0 };
/* 4288 */     int[] arrayOfInt5 = { 0 };
/* 4289 */     int[] arrayOfInt6 = { 0 };
/* 4290 */     long[] arrayOfLong = { 0L };
/* 4291 */     byte[] arrayOfByte1 = { 0 };
/* 4292 */     int[] arrayOfInt7 = { 0 };
/* 4293 */     byte[] arrayOfByte2 = { 0 };
/* 4294 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 4295 */     int[] arrayOfInt8 = { 0 };
/* 4296 */     byte[][] arrayOfByte = new byte[1][];
/* 4297 */     int j = paramNTFAQRegistration.getJdbcRegId();
/* 4298 */     arrayOfByte[0] = new byte[4];
/* 4299 */     arrayOfByte[0][0] = (byte)((j & 0xFF000000) >> 24);
/* 4300 */     arrayOfByte[0][1] = (byte)((j & 0xFF0000) >> 16);
/* 4301 */     arrayOfByte[0][2] = (byte)((j & 0xFF00) >> 8);
/* 4302 */     arrayOfByte[0][3] = (byte)(j & 0xFF);
/*      */     
/*      */     try {
/* 4305 */       sendPiggyBackedMessages();
/* 4306 */       this.okpn.doOKPN(2, 0, this.userName, str2, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 4328 */     catch (IOException iOException) {
/*      */       
/* 4330 */       handleIOException(iOException);
/*      */       
/* 4332 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4333 */       sQLException.fillInStackTrace();
/* 4334 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException {
/* 4350 */     int i = 0;
/* 4351 */     int j = 0;
/* 4352 */     boolean bool1 = false;
/* 4353 */     boolean bool2 = false;
/* 4354 */     boolean bool3 = false;
/* 4355 */     Object object = null;
/* 4356 */     boolean bool4 = false;
/* 4357 */     boolean bool5 = false;
/* 4358 */     if (paramInt1 == 0) {
/*      */ 
/*      */       
/* 4361 */       bool5 = true;
/* 4362 */       paramInt1 = 47632;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4367 */     if (paramProperties.getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4369 */       j |= 0x1; } 
/* 4370 */     if (paramProperties.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4372 */       j |= 0x10;
/*      */     }
/*      */ 
/*      */     
/* 4376 */     if (paramProperties.getProperty("DCN_NOTIFY_ROWIDS", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4378 */       i |= 0x10;
/*      */     }
/*      */     
/* 4381 */     if (paramProperties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4383 */       i |= 0x20;
/*      */     }
/*      */     
/* 4386 */     if (paramProperties.getProperty("DCN_BEST_EFFORT", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4388 */       i |= 0x40;
/*      */     }
/* 4390 */     boolean bool6 = false;
/* 4391 */     boolean bool7 = false;
/* 4392 */     boolean bool8 = false;
/* 4393 */     if (paramProperties.getProperty("DCN_IGNORE_INSERTOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4395 */       bool6 = true; } 
/* 4396 */     if (paramProperties.getProperty("DCN_IGNORE_UPDATEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4398 */       bool7 = true; } 
/* 4399 */     if (paramProperties.getProperty("DCN_IGNORE_DELETEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4401 */       bool8 = true;
/*      */     }
/* 4403 */     if (bool6 || bool7 || bool8) {
/*      */       
/* 4405 */       i |= 0xF;
/*      */ 
/*      */ 
/*      */       
/* 4409 */       if (bool6)
/* 4410 */         i -= 2; 
/* 4411 */       if (bool7)
/* 4412 */         i -= 4; 
/* 4413 */       if (bool8) {
/* 4414 */         i -= 8;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4420 */     byte[] arrayOfByte1 = new byte[1];
/* 4421 */     int[] arrayOfInt1 = new int[1];
/* 4422 */     byte[] arrayOfByte2 = new byte[1];
/* 4423 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[1];
/* 4424 */     int[] arrayOfInt2 = new int[1];
/* 4425 */     Properties[] arrayOfProperties = { paramProperties };
/* 4426 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2, arrayOfProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4442 */     int[] arrayOfInt3 = new int[1];
/* 4443 */     arrayOfInt3[0] = paramInt1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4448 */     boolean bool = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt3, bool5);
/* 4449 */     paramInt1 = arrayOfInt3[0];
/*      */     
/* 4451 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt1 + "))?PR=0";
/*      */ 
/*      */ 
/*      */     
/* 4455 */     int[] arrayOfInt4 = { 2 };
/* 4456 */     String[] arrayOfString = new String[1];
/* 4457 */     int[] arrayOfInt5 = { 23 };
/*      */ 
/*      */     
/* 4460 */     int[] arrayOfInt6 = { j };
/* 4461 */     int[] arrayOfInt7 = { paramInt2 };
/* 4462 */     int[] arrayOfInt8 = { i };
/* 4463 */     int[] arrayOfInt9 = { paramInt3 };
/* 4464 */     long[] arrayOfLong = { 0L };
/* 4465 */     int k = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4466 */     byte[][] arrayOfByte = new byte[1][];
/* 4467 */     arrayOfByte[0] = new byte[4];
/* 4468 */     arrayOfByte[0][0] = (byte)((k & 0xFF000000) >> 24);
/* 4469 */     arrayOfByte[0][1] = (byte)((k & 0xFF0000) >> 16);
/* 4470 */     arrayOfByte[0][2] = (byte)((k & 0xFF00) >> 8);
/* 4471 */     arrayOfByte[0][3] = (byte)(k & 0xFF);
/* 4472 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/* 4477 */         boolean bool9 = bool ? true : false;
/* 4478 */         sendPiggyBackedMessages();
/* 4479 */         this.okpn.doOKPN(1, bool9, this.userName, str, 1, arrayOfInt4, arrayOfString, arrayOfByte, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfInt8, arrayOfInt9, arrayOfLong, arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4500 */         l = this.okpn.getRegistrationId();
/*      */       }
/* 4502 */       catch (IOException iOException) {
/*      */         
/* 4504 */         handleIOException(iOException);
/*      */         
/* 4506 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4507 */         sQLException.fillInStackTrace();
/* 4508 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/* 4512 */     catch (SQLException sQLException) {
/*      */       
/* 4514 */       if (bool) {
/* 4515 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt1);
/*      */       }
/* 4517 */       throw sQLException;
/*      */     } 
/* 4519 */     return new NTFDCNRegistration(k, true, this.instanceName, l, this.userName, paramString, paramInt1, paramProperties, this.versionNumber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException {
/* 4543 */     int[] arrayOfInt1 = { 2 };
/* 4544 */     String[] arrayOfString = new String[1];
/* 4545 */     int[] arrayOfInt2 = { 0 };
/* 4546 */     int[] arrayOfInt3 = { 0 };
/* 4547 */     int[] arrayOfInt4 = { 0 };
/* 4548 */     int[] arrayOfInt5 = { 0 };
/* 4549 */     int[] arrayOfInt6 = { 0 };
/* 4550 */     byte[] arrayOfByte1 = { 0 };
/* 4551 */     int[] arrayOfInt7 = { 0 };
/* 4552 */     byte[] arrayOfByte2 = { 0 };
/* 4553 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 4554 */     int[] arrayOfInt8 = { 0 };
/* 4555 */     long[] arrayOfLong = { paramLong };
/* 4556 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/*      */     try {
/* 4559 */       sendPiggyBackedMessages();
/* 4560 */       this.okpn.doOKPN(2, 0, null, paramString, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 4582 */     catch (IOException iOException) {
/*      */       
/* 4584 */       handleIOException(iOException);
/*      */       
/* 4586 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4587 */       sQLException.fillInStackTrace();
/* 4588 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException {
/* 4601 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFDCNRegistration);
/* 4602 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFDCNRegistration.getJdbcRegId());
/* 4603 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFDCNRegistration.getClientTCPPort());
/* 4604 */     paramNTFDCNRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 4606 */     doUnregisterDatabaseChangeNotification(paramNTFDCNRegistration.getRegId(), "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramNTFDCNRegistration.getClientHost() + ")(PORT=" + paramNTFDCNRegistration.getClientTCPPort() + "))?PR=0");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDataIntegrityAlgorithmName() throws SQLException {
/* 4616 */     return this.net.getDataIntegrityName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getEncryptionAlgorithmName() throws SQLException {
/* 4623 */     return this.net.getEncryptionName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAuthenticationAdaptorName() throws SQLException {
/* 4630 */     return this.net.getAuthenticationAdaptorName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void validateConnectionProperties() throws SQLException {
/* 4645 */     super.validateConnectionProperties();
/*      */     
/* 4647 */     String str = ".*[\\00\\(\\)].*";
/* 4648 */     if (this.thinVsessionOsuser != null && (this.thinVsessionOsuser.matches(str) || this.thinVsessionOsuser.length() > 30)) {
/*      */ 
/*      */ 
/*      */       
/* 4652 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.osuser' and value is '" + this.thinVsessionOsuser + "'");
/* 4653 */       sQLException.fillInStackTrace();
/* 4654 */       throw sQLException;
/*      */     } 
/*      */     
/* 4657 */     if (this.thinVsessionTerminal != null && (this.thinVsessionTerminal.matches(str) || this.thinVsessionTerminal.length() > 30)) {
/*      */ 
/*      */ 
/*      */       
/* 4661 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.terminal' and value is '" + this.thinVsessionTerminal + "'");
/* 4662 */       sQLException.fillInStackTrace();
/* 4663 */       throw sQLException;
/*      */     } 
/*      */     
/* 4666 */     if (this.thinVsessionMachine != null && (this.thinVsessionMachine.matches(str) || this.thinVsessionMachine.length() > 64)) {
/*      */ 
/*      */ 
/*      */       
/* 4670 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.machine' and value is '" + this.thinVsessionMachine + "'");
/* 4671 */       sQLException.fillInStackTrace();
/* 4672 */       throw sQLException;
/*      */     } 
/*      */     
/* 4675 */     if (this.thinVsessionProgram != null && (this.thinVsessionProgram.matches(str) || this.thinVsessionProgram.length() > 48)) {
/*      */ 
/*      */ 
/*      */       
/* 4679 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.program' and value is '" + this.thinVsessionProgram + "'");
/* 4680 */       sQLException.fillInStackTrace();
/* 4681 */       throw sQLException;
/*      */     } 
/*      */     
/* 4684 */     if (this.thinVsessionProcess != null && (this.thinVsessionProcess.matches(str) || this.thinVsessionProcess.length() > 24)) {
/*      */ 
/*      */ 
/*      */       
/* 4688 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.process' and value is '" + this.thinVsessionProcess + "'");
/* 4689 */       sQLException.fillInStackTrace();
/* 4690 */       throw sQLException;
/*      */     } 
/*      */     
/* 4693 */     if (this.thinVsessionIname != null && this.thinVsessionIname.matches(str)) {
/*      */       
/* 4695 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.iname' and value is '" + this.thinVsessionIname + "'");
/* 4696 */       sQLException.fillInStackTrace();
/* 4697 */       throw sQLException;
/*      */     } 
/*      */     
/* 4700 */     if (this.thinVsessionEname != null && this.thinVsessionEname.matches(str)) {
/*      */       
/* 4702 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.ename' and value is '" + this.thinVsessionEname + "'");
/* 4703 */       sQLException.fillInStackTrace();
/* 4704 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 4710 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean TRACE = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 4725 */     if (paramArrayOfKeywordValueLong1.length != 1 || paramArrayOfint.length != 1) {
/*      */       
/* 4727 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4728 */       sQLException.fillInStackTrace();
/* 4729 */       throw sQLException;
/*      */     } 
/*      */     
/* 4732 */     byte[] arrayOfByte = null;
/*      */     
/*      */     try {
/* 4735 */       sendPiggyBackedMessages();
/* 4736 */       this.oxsscs.doOXSSCS(paramString, paramArrayOfKeywordValueLong, paramInt);
/* 4737 */       arrayOfByte = this.oxsscs.getSessionId();
/* 4738 */       paramArrayOfKeywordValueLong1[0] = this.oxsscs.getOutKV();
/* 4739 */       paramArrayOfint[0] = this.oxsscs.getOutFlags();
/*      */     }
/* 4741 */     catch (IOException iOException) {
/*      */       
/* 4743 */       handleIOException(iOException);
/*      */       
/* 4745 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4746 */       sQLException.fillInStackTrace();
/* 4747 */       throw sQLException;
/*      */     } 
/*      */     
/* 4750 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, boolean paramBoolean) throws SQLException {
/* 4766 */     XSNamespace[] arrayOfXSNamespace = null;
/*      */     
/*      */     try {
/* 4769 */       if (paramBoolean)
/* 4770 */         sendPiggyBackedMessages(); 
/* 4771 */       this.xsnsop.doOXSNS(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramBoolean);
/* 4772 */       if (paramBoolean) {
/* 4773 */         arrayOfXSNamespace = this.xsnsop.getNamespaces();
/*      */       }
/* 4775 */     } catch (IOException iOException) {
/*      */       
/* 4777 */       handleIOException(iOException);
/*      */       
/* 4779 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4780 */       sQLException.fillInStackTrace();
/* 4781 */       throw sQLException;
/*      */     } 
/*      */     
/* 4784 */     if (paramArrayOfXSNamespace1 != null && paramArrayOfXSNamespace1.length > 0) {
/* 4785 */       paramArrayOfXSNamespace1[0] = arrayOfXSNamespace;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1) throws SQLException {
/* 4799 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramArrayOfXSNamespace1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace) throws SQLException {
/* 4811 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, (XSNamespace[][])null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 4823 */     if (paramArrayOfKeywordValueLong1.length != 1 || paramArrayOfint.length != 1) {
/*      */       
/* 4825 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4826 */       sQLException.fillInStackTrace();
/* 4827 */       throw sQLException;
/*      */     } 
/*      */     
/*      */     try {
/* 4831 */       sendPiggyBackedMessages();
/* 4832 */       this.oxssro.doOXSSRO(paramInt1, paramArrayOfbyte, paramArrayOfKeywordValueLong, paramInt2);
/* 4833 */       paramArrayOfKeywordValueLong1[0] = this.oxssro.getOutKV();
/* 4834 */       paramArrayOfint[0] = this.oxssro.getOutFlags();
/*      */     }
/* 4836 */     catch (IOException iOException) {
/*      */       
/* 4838 */       handleIOException(iOException);
/*      */       
/* 4840 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4841 */       sQLException.fillInStackTrace();
/* 4842 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException {
/* 4855 */     if (this.lusOffset2 == this.lusFunctionId2.length) {
/*      */       
/* 4857 */       int i = this.lusFunctionId2.length;
/* 4858 */       int[] arrayOfInt1 = new int[i * 2];
/* 4859 */       System.arraycopy(this.lusFunctionId2, 0, arrayOfInt1, 0, i);
/* 4860 */       byte[][] arrayOfByte = new byte[i * 2][];
/* 4861 */       System.arraycopy(this.lusSessionId2, 0, arrayOfByte, 0, i);
/* 4862 */       KeywordValueLong[][] arrayOfKeywordValueLong = new KeywordValueLong[i * 2][];
/* 4863 */       System.arraycopy(this.lusInKeyVal2, 0, arrayOfKeywordValueLong, 0, i);
/* 4864 */       int[] arrayOfInt2 = new int[i * 2];
/* 4865 */       System.arraycopy(this.lusInFlags2, 0, arrayOfInt2, 0, i);
/* 4866 */       this.lusFunctionId2 = arrayOfInt1;
/* 4867 */       this.lusSessionId2 = arrayOfByte;
/* 4868 */       this.lusInKeyVal2 = arrayOfKeywordValueLong;
/* 4869 */       this.lusInFlags2 = arrayOfInt2;
/*      */     } 
/* 4871 */     this.lusFunctionId2[this.lusOffset2] = paramInt1;
/* 4872 */     this.lusSessionId2[this.lusOffset2] = paramArrayOfbyte;
/* 4873 */     this.lusInKeyVal2[this.lusOffset2] = paramArrayOfKeywordValueLong;
/* 4874 */     this.lusInFlags2[this.lusOffset2] = paramInt2;
/* 4875 */     this.lusOffset2++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException {
/* 4886 */     if (this.lifecycle != 1) {
/*      */       
/* 4888 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4889 */       sQLException.fillInStackTrace();
/* 4890 */       throw sQLException;
/*      */     } 
/*      */     
/* 4893 */     NTFEventListener nTFEventListener = new NTFEventListener(paramXSEventListener);
/* 4894 */     nTFEventListener.setExecutor(paramExecutor);
/* 4895 */     synchronized (this.xsListeners) {
/*      */       
/* 4897 */       int i = this.xsListeners.length;
/* 4898 */       for (byte b = 0; b < i; b++) {
/* 4899 */         if (this.xsListeners[b].getXSEventListener() == paramXSEventListener) {
/*      */ 
/*      */ 
/*      */           
/* 4903 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
/* 4904 */           sQLException.fillInStackTrace();
/* 4905 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */       
/* 4909 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i + 1];
/* 4910 */       System.arraycopy(this.xsListeners, 0, arrayOfNTFEventListener, 0, i);
/*      */       
/* 4912 */       arrayOfNTFEventListener[i] = nTFEventListener;
/*      */       
/* 4914 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 4925 */     addXSEventListener(paramXSEventListener, (Executor)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 4933 */     synchronized (this.xsListeners) {
/*      */ 
/*      */       
/* 4936 */       byte b1 = 0;
/* 4937 */       int i = this.xsListeners.length;
/*      */       
/* 4939 */       for (b1 = 0; b1 < i && 
/* 4940 */         this.xsListeners[b1].getXSEventListener() != paramXSEventListener; b1++);
/*      */       
/* 4942 */       if (b1 == i) {
/*      */ 
/*      */ 
/*      */         
/* 4946 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
/* 4947 */         sQLException.fillInStackTrace();
/* 4948 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4952 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i - 1];
/* 4953 */       byte b2 = 0;
/* 4954 */       for (b1 = 0; b1 < i; b1++) {
/* 4955 */         if (this.xsListeners[b1].getXSEventListener() != paramXSEventListener) {
/* 4956 */           arrayOfNTFEventListener[b2++] = this.xsListeners[b1];
/*      */         }
/*      */       } 
/* 4959 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void notify(final NTFXSEvent event) {
/* 4972 */     NTFEventListener[] arrayOfNTFEventListener = this.xsListeners;
/*      */ 
/*      */ 
/*      */     
/* 4976 */     int i = arrayOfNTFEventListener.length;
/* 4977 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 4979 */       Executor executor = arrayOfNTFEventListener[b].getExecutor();
/* 4980 */       if (executor != null) {
/*      */         
/* 4982 */         final XSEventListener l = arrayOfNTFEventListener[b].getXSEventListener();
/*      */         
/* 4984 */         executor.execute(new Runnable() {
/*      */               public void run() {
/* 4986 */                 l.onXSEvent(event);
/*      */               }
/*      */             });
/*      */       }
/*      */       else {
/*      */         
/* 4992 */         arrayOfNTFEventListener[b].getXSEventListener().onXSEvent(event);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean hasServerCompileTimeCapability(int paramInt1, int paramInt2) {
/* 5015 */     boolean bool = false;
/* 5016 */     if (this.serverCompileTimeCapabilities != null && this.serverCompileTimeCapabilities.length > paramInt1 && (this.serverCompileTimeCapabilities[paramInt1] & paramInt2) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 5021 */       bool = true;
/*      */     }
/* 5023 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long doGetCurrentSCN() throws SQLException {
/* 5031 */     return this.outScn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException {
/* 5038 */     EnumSet<OracleConnection.TransactionState> enumSet = EnumSet.noneOf(OracleConnection.TransactionState.class);
/* 5039 */     if ((this.eocs & 0x1) != 0)
/*      */     {
/* 5041 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_READONLY);
/*      */     }
/* 5043 */     if ((this.eocs & 0x2) != 0)
/*      */     {
/* 5045 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_STARTED);
/*      */     }
/* 5047 */     if ((this.eocs & 0x4) != 0)
/*      */     {
/* 5049 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_ENDED);
/*      */     }
/* 5051 */     if ((this.eocs & 0x400) != 0)
/*      */     {
/* 5053 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_INTENTION);
/*      */     }
/* 5055 */     return enumSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConnectionSocketKeepAlive() throws SocketException {
/* 5062 */     return this.net.isConnectionSocketKeepAlive();
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */