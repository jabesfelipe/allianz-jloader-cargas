/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.aq.AQMessage;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.sql.ANYDATA;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.sql.RAW;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ import oracle.xdb.XMLType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AQMessageI
/*     */   implements AQMessage
/*     */ {
/*  64 */   private byte[] id = null;
/*  65 */   private AQMessagePropertiesI properties = null;
/*  66 */   private byte[] toid = null;
/*     */   
/*     */   private byte[] payload;
/*     */   
/*     */   private STRUCT payLoadSTRUCT;
/*     */   
/*     */   private ANYDATA payLoadANYDATA;
/*     */   
/*     */   private RAW payLoadRAW;
/*     */   private XMLType payLoadXMLType;
/*     */   private Connection conn;
/*     */   private String typeName;
/*     */   private TypeDescriptor sd;
/*     */   
/*     */   AQMessageI(AQMessagePropertiesI paramAQMessagePropertiesI, Connection paramConnection) {
/*  81 */     this.properties = paramAQMessagePropertiesI;
/*  82 */     this.conn = paramConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AQMessageI(AQMessagePropertiesI paramAQMessagePropertiesI) throws SQLException {
/*  90 */     this.properties = paramAQMessagePropertiesI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTypeName(String paramString) {
/*  97 */     this.typeName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTypeDescriptor(TypeDescriptor paramTypeDescriptor) {
/* 104 */     this.sd = paramTypeDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getMessageId() {
/* 111 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMessageId(byte[] paramArrayOfbyte) throws SQLException {
/* 118 */     this.id = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties getMessageProperties() {
/* 125 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AQMessagePropertiesI getMessagePropertiesI() {
/* 132 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(byte[] paramArrayOfbyte) throws SQLException {
/* 145 */     this.payload = paramArrayOfbyte;
/* 146 */     this.toid = TypeDescriptor.RAWTOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws SQLException {
/* 154 */     this.payload = paramArrayOfbyte1;
/* 155 */     this.toid = paramArrayOfbyte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(STRUCT paramSTRUCT) throws SQLException {
/* 163 */     this.payload = paramSTRUCT.toBytes();
/* 164 */     this.payLoadSTRUCT = paramSTRUCT;
/* 165 */     this.toid = paramSTRUCT.getDescriptor().getOracleTypeADT().getTOID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(ANYDATA paramANYDATA) throws SQLException {
/* 173 */     this.payload = paramANYDATA.toDatum(this.conn).shareBytes();
/* 174 */     this.payLoadANYDATA = paramANYDATA;
/* 175 */     this.toid = TypeDescriptor.ANYDATATOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(RAW paramRAW) throws SQLException {
/* 182 */     this.payload = paramRAW.shareBytes();
/* 183 */     this.payLoadRAW = paramRAW;
/* 184 */     this.toid = TypeDescriptor.RAWTOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayload(XMLType paramXMLType) throws SQLException {
/* 191 */     this.payload = paramXMLType.toBytes();
/* 192 */     this.payLoadXMLType = paramXMLType;
/* 193 */     this.toid = TypeDescriptor.XMLTYPETOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPayload() {
/* 200 */     return this.payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RAW getRAWPayload() throws SQLException {
/* 207 */     RAW rAW = null;
/* 208 */     if (this.payLoadRAW != null) {
/* 209 */       rAW = this.payLoadRAW;
/* 210 */     } else if (isRAWPayload()) {
/*     */       
/* 212 */       this.payLoadRAW = new RAW(this.payload);
/* 213 */       rAW = this.payLoadRAW;
/*     */     }
/*     */     else {
/*     */       
/* 217 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 218 */       sQLException.fillInStackTrace();
/* 219 */       throw sQLException;
/*     */     } 
/* 221 */     return rAW;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRAWPayload() throws SQLException {
/* 229 */     if (this.toid == null || this.toid.length != 16) {
/*     */       
/* 231 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
/* 232 */       sQLException.fillInStackTrace();
/* 233 */       throw sQLException;
/*     */     } 
/*     */     
/* 236 */     if (compareToid(this.toid, TypeDescriptor.RAWTOID)) {
/* 237 */       return true;
/*     */     }
/* 239 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public STRUCT getSTRUCTPayload() throws SQLException {
/* 247 */     STRUCT sTRUCT = null;
/*     */     
/* 249 */     if (!isSTRUCTPayload()) {
/*     */       
/* 251 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 252 */       sQLException.fillInStackTrace();
/* 253 */       throw sQLException;
/*     */     } 
/*     */     
/* 256 */     if (this.payLoadSTRUCT != null) {
/* 257 */       sTRUCT = this.payLoadSTRUCT;
/*     */     } else {
/*     */       
/* 260 */       if (this.sd == null) {
/*     */         
/* 262 */         this.typeName = OracleTypeADT.toid2typename(this.conn, this.toid);
/* 263 */         this.sd = TypeDescriptor.getTypeDescriptor(this.typeName, (OracleConnection)this.conn);
/*     */       } 
/*     */       
/* 266 */       if (this.sd instanceof StructDescriptor) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 271 */         sTRUCT = new STRUCT((StructDescriptor)this.sd, this.payload, this.conn);
/* 272 */         this.payLoadSTRUCT = sTRUCT;
/*     */       }
/*     */       else {
/*     */         
/* 276 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 277 */         sQLException.fillInStackTrace();
/* 278 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */     
/* 282 */     return sTRUCT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSTRUCTPayload() throws SQLException {
/* 289 */     if (this.toid == null || this.toid.length != 16) {
/*     */       
/* 291 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
/* 292 */       sQLException.fillInStackTrace();
/* 293 */       throw sQLException;
/*     */     } 
/*     */     
/* 296 */     boolean bool1 = true;
/*     */     
/* 298 */     boolean bool2 = true;
/* 299 */     for (byte b = 0; b < 15; b++) {
/* 300 */       if (this.toid[b] != 0) {
/*     */         
/* 302 */         bool2 = false;
/*     */         break;
/*     */       } 
/*     */     } 
/* 306 */     if (bool2 || isRAWPayload() || isANYDATAPayload()) {
/* 307 */       bool1 = false;
/*     */     }
/* 309 */     return bool1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ANYDATA getANYDATAPayload() throws SQLException {
/* 316 */     ANYDATA aNYDATA = null;
/*     */     
/* 318 */     if (this.payLoadANYDATA != null) {
/* 319 */       aNYDATA = this.payLoadANYDATA;
/* 320 */     } else if (isANYDATAPayload()) {
/*     */       
/* 322 */       OpaqueDescriptor opaqueDescriptor = OpaqueDescriptor.createDescriptor("SYS.ANYDATA", this.conn);
/*     */       
/* 324 */       OPAQUE oPAQUE = new OPAQUE(opaqueDescriptor, this.payload, this.conn);
/* 325 */       this.payLoadANYDATA = new ANYDATA(oPAQUE);
/* 326 */       aNYDATA = this.payLoadANYDATA;
/*     */     }
/*     */     else {
/*     */       
/* 330 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 331 */       sQLException.fillInStackTrace();
/* 332 */       throw sQLException;
/*     */     } 
/* 334 */     return aNYDATA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isANYDATAPayload() throws SQLException {
/* 341 */     if (this.toid == null || this.toid.length != 16) {
/*     */       
/* 343 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
/* 344 */       sQLException.fillInStackTrace();
/* 345 */       throw sQLException;
/*     */     } 
/* 347 */     if ((this.typeName != null && this.typeName.equals("SYS.ANYDATA")) || compareToid(this.toid, TypeDescriptor.ANYDATATOID))
/*     */     {
/* 349 */       return true;
/*     */     }
/* 351 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLType getXMLTypePayload() throws SQLException {
/* 358 */     XMLType xMLType = null;
/*     */     
/* 360 */     if (this.payLoadXMLType != null) {
/* 361 */       xMLType = this.payLoadXMLType;
/* 362 */     } else if (isXMLTypePayload()) {
/*     */       
/* 364 */       OpaqueDescriptor opaqueDescriptor = OpaqueDescriptor.createDescriptor("SYS.XMLTYPE", this.conn);
/*     */       
/* 366 */       OPAQUE oPAQUE = new OPAQUE(opaqueDescriptor, this.payload, this.conn);
/* 367 */       this.payLoadXMLType = XMLType.createXML(oPAQUE);
/* 368 */       xMLType = this.payLoadXMLType;
/*     */     }
/*     */     else {
/*     */       
/* 372 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
/* 373 */       sQLException.fillInStackTrace();
/* 374 */       throw sQLException;
/*     */     } 
/* 376 */     return xMLType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isXMLTypePayload() throws SQLException {
/* 383 */     if (this.toid == null || this.toid.length != 16) {
/*     */       
/* 385 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
/* 386 */       sQLException.fillInStackTrace();
/* 387 */       throw sQLException;
/*     */     } 
/* 389 */     if ((this.typeName != null && this.typeName.equals("SYS.XMLTYPE")) || compareToid(this.toid, TypeDescriptor.XMLTYPETOID))
/*     */     {
/* 391 */       return true;
/*     */     }
/* 393 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPayloadTOID() {
/* 400 */     return this.toid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean compareToid(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 407 */     boolean bool = false;
/*     */     
/* 409 */     if (paramArrayOfbyte1 != null)
/*     */     {
/* 411 */       if (paramArrayOfbyte1 == paramArrayOfbyte2) {
/* 412 */         bool = true;
/* 413 */       } else if (paramArrayOfbyte1.length == paramArrayOfbyte2.length) {
/*     */         
/* 415 */         boolean bool1 = true;
/* 416 */         for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/* 417 */           if (paramArrayOfbyte1[b] != paramArrayOfbyte2[b]) {
/*     */             
/* 419 */             bool1 = false; break;
/*     */           } 
/*     */         } 
/* 422 */         if (bool1)
/* 423 */           bool = true; 
/*     */       } 
/*     */     }
/* 426 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 433 */     StringBuffer stringBuffer = new StringBuffer();
/* 434 */     stringBuffer.append("Message Properties={");
/* 435 */     stringBuffer.append(this.properties);
/* 436 */     stringBuffer.append("} ");
/* 437 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 452 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 457 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\AQMessageI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */