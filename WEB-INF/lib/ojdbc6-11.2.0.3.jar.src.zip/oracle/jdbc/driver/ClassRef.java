/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.OPAQUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClassRef
/*     */ {
/*  42 */   static final XMLTypeClassRef XMLTYPE = XMLTypeClassRef.newInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ClassRef newInstance(String paramString) throws ClassNotFoundException {
/*  53 */     return new ClassRef(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private final ThreadLocal<Class> ref = new ThreadLocal<Class<?>>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String className;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassRef(String paramString) throws ClassNotFoundException {
/*  73 */     this.className = paramString;
/*     */ 
/*     */ 
/*     */     
/*  77 */     this.ref.set(Class.forName(this.className, true, Thread.currentThread().getContextClassLoader()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class get() {
/*  93 */     Class<?> clazz = this.ref.get();
/*  94 */     if (clazz == null) {
/*     */       try {
/*  96 */         clazz = Class.forName(this.className, true, Thread.currentThread().getContextClassLoader());
/*     */       }
/*  98 */       catch (ClassNotFoundException classNotFoundException) {
/*  99 */         NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
/* 100 */         noClassDefFoundError.initCause(classNotFoundException);
/* 101 */         throw noClassDefFoundError;
/*     */       } 
/* 103 */       this.ref.set(clazz);
/*     */     } 
/* 105 */     return clazz;
/*     */   }
/*     */ 
/*     */   
/*     */   static class XMLTypeClassRef
/*     */     extends ClassRef
/*     */   {
/*     */     protected final Method CREATEXML;
/*     */     
/*     */     static final XMLTypeClassRef newInstance() {
/*     */       
/* 116 */       try { return new XMLTypeClassRef(); }
/*     */       
/* 118 */       catch (ClassNotFoundException classNotFoundException) {  }
/* 119 */       catch (NoClassDefFoundError noClassDefFoundError) {}
/* 120 */       return null;
/*     */     }
/*     */     
/*     */     private XMLTypeClassRef() throws ClassNotFoundException {
/* 124 */       super("oracle.xdb.XMLType");
/* 125 */       Method method = null;
/*     */       try {
/* 127 */         method = get().getDeclaredMethod("createXML", new Class[] { OPAQUE.class });
/*     */       }
/* 129 */       catch (NoSuchMethodException noSuchMethodException) {}
/* 130 */       this.CREATEXML = method;
/*     */     }
/*     */ 
/*     */     
/*     */     OPAQUE createXML(OPAQUE param1OPAQUE) throws SQLException {
/* 135 */       get();
/*     */       
/* 137 */       try { return (OPAQUE)this.CREATEXML.invoke(null, new Object[] { param1OPAQUE }); }
/*     */       
/* 139 */       catch (IllegalAccessException illegalAccessException) {  }
/* 140 */       catch (InvocationTargetException invocationTargetException) {}
/* 141 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 147 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\ClassRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */