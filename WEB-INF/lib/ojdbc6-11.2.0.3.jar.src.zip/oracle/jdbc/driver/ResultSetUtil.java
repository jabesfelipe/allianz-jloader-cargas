/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResultSetUtil
/*     */ {
/*  25 */   static final int[][] allRsetTypes = new int[][] { { 0, 0 }, { 1003, 1007 }, { 1003, 1008 }, { 1004, 1007 }, { 1004, 1008 }, { 1005, 1007 }, { 1005, 1008 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OracleResultSet createScrollResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSet paramOracleResultSet, int paramInt) throws SQLException {
/*     */     ScrollableResultSet scrollableResultSet;
/*     */     SensitiveScrollableResultSet sensitiveScrollableResultSet;
/*  62 */     switch (paramInt) {
/*     */ 
/*     */       
/*     */       case 1:
/*  66 */         return paramOracleResultSet;
/*     */       
/*     */       case 2:
/*  69 */         return new UpdatableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/*  75 */         return new ScrollableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/*  81 */         scrollableResultSet = new ScrollableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));
/*     */ 
/*     */ 
/*     */         
/*  85 */         return new UpdatableResultSet(paramScrollRsetStatement, scrollableResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));
/*     */ 
/*     */       
/*     */       case 5:
/*  89 */         return new SensitiveScrollableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/*  95 */         sensitiveScrollableResultSet = new SensitiveScrollableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));
/*     */ 
/*     */ 
/*     */         
/*  99 */         return new UpdatableResultSet(paramScrollRsetStatement, sensitiveScrollableResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 104 */     SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 23, (Object)null);
/* 105 */     sQLException.fillInStackTrace();
/* 106 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getScrollType(int paramInt) {
/* 120 */     return allRsetTypes[paramInt][0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getUpdateConcurrency(int paramInt) {
/* 131 */     return allRsetTypes[paramInt][1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getRsetTypeCode(int paramInt1, int paramInt2) throws SQLException {
/* 144 */     for (byte b = 0; b < allRsetTypes.length; b++) {
/*     */       
/* 146 */       if (allRsetTypes[b][0] == paramInt1 && allRsetTypes[b][1] == paramInt2)
/*     */       {
/*     */ 
/*     */         
/* 150 */         return b;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 155 */     SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 68);
/* 156 */     sQLException.fillInStackTrace();
/* 157 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean needIdentifier(int paramInt) throws SQLException {
/* 172 */     return (paramInt != 1 && paramInt != 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean needIdentifier(int paramInt1, int paramInt2) throws SQLException {
/* 180 */     return needIdentifier(getRsetTypeCode(paramInt1, paramInt2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean needCache(int paramInt) throws SQLException {
/* 192 */     return (paramInt >= 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean needCache(int paramInt1, int paramInt2) throws SQLException {
/* 199 */     return needCache(getRsetTypeCode(paramInt1, paramInt2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean supportRefreshRow(int paramInt) throws SQLException {
/* 210 */     return (paramInt >= 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean supportRefreshRow(int paramInt1, int paramInt2) throws SQLException {
/* 218 */     return supportRefreshRow(getRsetTypeCode(paramInt1, paramInt2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 238 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\ResultSetUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */