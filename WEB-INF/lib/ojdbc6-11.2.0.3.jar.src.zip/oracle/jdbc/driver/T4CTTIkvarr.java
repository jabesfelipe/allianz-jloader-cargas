/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIkvarr
/*     */   extends T4CTTIMsg
/*     */ {
/* 106 */   KeywordValue[] kpdkvarrptr = null;
/*     */   long kpdkvarrflg;
/*     */   
/*     */   T4CTTIkvarr(T4CConnection paramT4CConnection) {
/* 110 */     super(paramT4CConnection, (byte)0);
/*     */   }
/*     */   
/*     */   void unmarshal() throws SQLException, IOException {
/* 114 */     int i = (int)this.meg.unmarshalUB4();
/* 115 */     byte b = (byte)this.meg.unmarshalUB1();
/* 116 */     if (i > 0) {
/*     */       
/* 118 */       this.kpdkvarrptr = (KeywordValue[])new KeywordValueI[i];
/* 119 */       for (byte b1 = 0; b1 < i; b1++)
/* 120 */         this.kpdkvarrptr[b1] = KeywordValueI.unmarshal(this.meg); 
/* 121 */       this.connection.updateSessionProperties(this.kpdkvarrptr);
/*     */     } else {
/*     */       
/* 124 */       this.kpdkvarrptr = null;
/* 125 */     }  this.kpdkvarrflg = this.meg.unmarshalUB4();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CTTIkvarr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */