/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.oracore.OracleType;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.sql.ARRAY;
/*     */ import oracle.sql.ArrayDescriptor;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.JAVA_STRUCT;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NamedTypeAccessor
/*     */   extends TypeAccessor
/*     */ {
/*     */   private static final Class xmlType;
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean) throws SQLException {
/*  38 */     init(paramOracleStatement, 109, 109, paramShort, paramBoolean);
/*  39 */     initForDataAccess(paramInt, 0, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString) throws SQLException {
/*  49 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*  50 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */     
/*  52 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, OracleType paramOracleType) throws SQLException {
/*  62 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*     */     
/*  64 */     this.describeOtype = paramOracleType;
/*     */     
/*  66 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */ 
/*     */     
/*  69 */     this.internalOtype = paramOracleType;
/*     */     
/*  71 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleType otypeFromName(String paramString) throws SQLException {
/*  78 */     if (!this.outBind) {
/*  79 */       return (OracleType)TypeDescriptor.getTypeDescriptor(paramString, (OracleConnection)this.statement.connection).getPickler();
/*     */     }
/*  81 */     if (this.externalType == 2003) {
/*  82 */       return (OracleType)ArrayDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeCOLLECTION();
/*     */     }
/*  84 */     if (this.externalType == 2007 || this.externalType == 2009)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       return (OracleType)OpaqueDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getPickler();
/*     */     }
/*     */     
/*  94 */     return (OracleType)StructDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeADT();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 103 */     super.initForDataAccess(paramInt1, paramInt2, paramString);
/*     */     
/* 105 */     this.byteLength = this.statement.connection.namedTypeAccessorByteLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 121 */     return getObject(paramInt, this.statement.connection.getTypeMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 131 */     Class<?> clazz = null;
/*     */     try {
/* 133 */       clazz = Class.forName("oracle.xdb.XMLType");
/*     */     }
/* 135 */     catch (Throwable throwable) {}
/* 136 */     xmlType = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 148 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 150 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 151 */       sQLException.fillInStackTrace();
/* 152 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       Datum datum;
/*     */ 
/*     */       
/* 162 */       if (this.externalType == 0) {
/*     */         
/* 164 */         Datum datum1 = getOracleObject(paramInt);
/*     */ 
/*     */ 
/*     */         
/* 168 */         if (datum1 == null) {
/* 169 */           return null;
/*     */         }
/* 171 */         if (datum1 instanceof STRUCT) {
/* 172 */           return ((STRUCT)datum1).toJdbc(paramMap);
/*     */         }
/* 174 */         if (datum1 instanceof OPAQUE) {
/* 175 */           return ((OPAQUE)datum1).toJdbc(paramMap);
/*     */         }
/*     */ 
/*     */         
/* 179 */         return datum1.toJdbc();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 184 */       switch (this.externalType) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2008:
/* 190 */           paramMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2000:
/*     */         case 2002:
/*     */         case 2003:
/*     */         case 2007:
/* 199 */           datum = getOracleObject(paramInt);
/*     */ 
/*     */ 
/*     */           
/* 203 */           if (datum == null) {
/* 204 */             return null;
/*     */           }
/* 206 */           if (datum instanceof STRUCT) {
/* 207 */             return ((STRUCT)datum).toJdbc(paramMap);
/*     */           }
/* 209 */           return datum.toJdbc();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2009:
/* 215 */           datum = getOracleObject(paramInt);
/* 216 */           if (datum == null) {
/* 217 */             return null;
/*     */           }
/*     */           try {
/* 220 */             return datum;
/*     */           }
/* 222 */           catch (ClassCastException classCastException) {
/*     */ 
/*     */             
/* 225 */             SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 226 */             sQLException1.fillInStackTrace();
/* 227 */             throw sQLException1;
/*     */           } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 235 */       sQLException.fillInStackTrace();
/* 236 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/*     */     STRUCT sTRUCT;
/*     */     OPAQUE oPAQUE;
/* 259 */     ARRAY aRRAY = null;
/*     */ 
/*     */     
/* 262 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 264 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 265 */       sQLException1.fillInStackTrace();
/* 266 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     byte[] arrayOfByte = pickledBytes(paramInt);
/*     */     
/* 275 */     if (arrayOfByte == null || arrayOfByte.length == 0)
/*     */     {
/* 277 */       return null;
/*     */     }
/*     */     
/* 280 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 281 */     OracleTypeADT oracleTypeADT = (OracleTypeADT)this.internalOtype;
/* 282 */     TypeDescriptor typeDescriptor = TypeDescriptor.getTypeDescriptor(oracleTypeADT.getFullName(), (OracleConnection)physicalConnection, arrayOfByte, 0L);
/*     */ 
/*     */     
/* 285 */     switch (typeDescriptor.getTypeCode()) {
/*     */ 
/*     */       
/*     */       case 2003:
/* 289 */         aRRAY = new ARRAY((ArrayDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 330 */         return (Datum)aRRAY;case 2002: return (Datum)new STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);case 2009: oPAQUE = ClassRef.XMLTYPE.createXML(new OPAQUE((OpaqueDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection)); return (Datum)oPAQUE;case 2007: oPAQUE = new OPAQUE((OpaqueDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection); return (Datum)oPAQUE;
/*     */       case 2008:
/*     */         return (Datum)new JAVA_STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */     } 
/*     */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ARRAY getARRAY(int paramInt) throws SQLException {
/* 346 */     return (ARRAY)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 362 */     return (STRUCT)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 378 */     return (OPAQUE)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isNull(int paramInt) throws SQLException {
/* 385 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 389 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 390 */       sQLException.fillInStackTrace();
/* 391 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 396 */     byte[] arrayOfByte = pickledBytes(paramInt);
/* 397 */     return (arrayOfByte == null || arrayOfByte.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLXML getSQLXML(int paramInt) throws SQLException {
/*     */     try {
/* 413 */       OPAQUE oPAQUE = (OPAQUE)getOracleObject(paramInt);
/* 414 */       if (oPAQUE == null) return null; 
/* 415 */       return (SQLXML)oPAQUE;
/*     */     }
/* 417 */     catch (ClassCastException classCastException) {
/*     */       
/* 419 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 420 */       sQLException.fillInStackTrace();
/* 421 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 430 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NamedTypeAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */