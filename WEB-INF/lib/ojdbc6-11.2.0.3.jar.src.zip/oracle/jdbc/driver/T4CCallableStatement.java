/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CCallableStatement
/*      */   extends OracleCallableStatement
/*      */ {
/*      */   T4CCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   28 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/*   30 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*   31 */     this.nbPostPonedColumns = new int[1];
/*   32 */     this.nbPostPonedColumns[0] = 0;
/*   33 */     this.indexOfPostPonedColumn = new int[1][3];
/*      */     
/*   35 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   36 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   37 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   38 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   44 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   64 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   65 */       this.oacdefSent = null;
/*      */     }
/*   67 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.doOall8");
/*      */     
/*   69 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   73 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   74 */       sQLException.fillInStackTrace();
/*   75 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   79 */     if (paramBoolean3) {
/*   80 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   82 */     int i = this.numberOfDefinePositions;
/*      */     
/*   84 */     if (this.sqlKind.isDML()) {
/*   85 */       i = 0;
/*      */     }
/*      */     
/*   88 */     if (this.accessors != null)
/*   89 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   90 */         if (this.accessors[b] != null)
/*   91 */           (this.accessors[b]).lastRowProcessed = 0; 
/*   92 */       }   if (this.outBindAccessors != null)
/*   93 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   94 */         if (this.outBindAccessors[b] != null)
/*   95 */           (this.outBindAccessors[b]).lastRowProcessed = 0; 
/*   96 */       }   if (this.returnParamAccessors != null) {
/*   97 */       for (byte b = 0; b < this.returnParamAccessors.length; b++) {
/*   98 */         if (this.returnParamAccessors[b] != null) {
/*   99 */           (this.returnParamAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  106 */     if (this.bindIndicators != null) {
/*      */       
/*  108 */       int j = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  111 */       int k = 0;
/*      */       
/*  113 */       if (this.ibtBindChars != null) {
/*  114 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  116 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  118 */         int m = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  122 */         int n = this.bindIndicators[m + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  126 */         if (n != 0) {
/*      */ 
/*      */           
/*  129 */           int i1 = this.bindIndicators[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  133 */           if (i1 == 2) {
/*      */             
/*  135 */             k = Math.max(n * this.connection.conversion.maxNCharSize, k);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  140 */             k = Math.max(n * this.connection.conversion.cMaxCharSize, k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  146 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  148 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  150 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  152 */         this.tmpBindsByteArray = null;
/*  153 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  165 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  170 */     int[] arrayOfInt1 = this.definedColumnType;
/*  171 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  172 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  178 */     if (paramBoolean5 && paramBoolean4 && this.sqlObject.includeRowid) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  183 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  184 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  185 */       arrayOfInt1[0] = -8;
/*  186 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  187 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  188 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  189 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  195 */     allocateTmpByteArray();
/*      */     
/*  197 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */     
/*  199 */     this.t4Connection.sendPiggyBackedMessages();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  204 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  216 */       int j = t4C8Oall.getCursorId();
/*  217 */       if (j != 0) {
/*  218 */         this.cursorId = j;
/*      */       }
/*  220 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*      */     }
/*  222 */     catch (SQLException sQLException) {
/*      */       
/*  224 */       int j = t4C8Oall.getCursorId();
/*  225 */       if (j != 0) {
/*  226 */         this.cursorId = j;
/*      */       }
/*  228 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  231 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  236 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  246 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  249 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  251 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  255 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  267 */     super.releaseBuffers();
/*  268 */     this.tmpByteArray = null;
/*  269 */     this.tmpBindsByteArray = null;
/*      */     
/*  271 */     this.t4Connection.all8.bindChars = null;
/*  272 */     this.t4Connection.all8.bindBytes = null;
/*  273 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  280 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  293 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  304 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  312 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  314 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  320 */     if (paramInt1 < 1) {
/*      */       
/*  322 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  323 */       sQLException.fillInStackTrace();
/*  324 */       throw sQLException;
/*      */     } 
/*  326 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/*  330 */       if (paramInt2 == 1 || paramInt2 == 12 || paramInt2 == -15 || paramInt2 == -9)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  336 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  342 */     else if (paramInt3 < 0) {
/*      */       
/*  344 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  345 */       sQLException.fillInStackTrace();
/*  346 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  350 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  352 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  353 */       sQLException.fillInStackTrace();
/*  354 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  361 */     int i = paramInt1 - 1;
/*      */     
/*  363 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  365 */       if (this.definedColumnType == null) {
/*      */         
/*  367 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  379 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  381 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  384 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  390 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  392 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  394 */       if (this.definedColumnSize == null) {
/*  395 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  398 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  400 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  403 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  407 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  409 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  411 */       if (this.definedColumnFormOfUse == null) {
/*  412 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  415 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  417 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  420 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  424 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  426 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  428 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  433 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  437 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  443 */           this.needToPrepareDefineBuffer = true;
/*  444 */           this.columnsDefinedByUser = true;
/*      */           
/*  446 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  447 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  456 */     synchronized (this.connection) {
/*      */       
/*  458 */       super.clearDefines();
/*  459 */       this.definedColumnType = null;
/*  460 */       this.definedColumnSize = null;
/*  461 */       this.definedColumnFormOfUse = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException {
/*  479 */     boolean bool = (this.rowPrefetchInLastFetch < this.rowPrefetch) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  508 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  517 */       paramArrayOfshort = new short[this.defineIndicators.length];
/*  518 */       int j = (this.accessors[0]).lengthIndexLastRow;
/*  519 */       int k = (this.accessors[0]).indicatorIndexLastRow;
/*      */       
/*  521 */       int m = bool ? this.accessors.length : 1;
/*  522 */       for (; bool ? (m >= 1) : (m <= this.accessors.length); 
/*  523 */         m += bool ? -1 : 1) {
/*      */         
/*  525 */         int n = j + this.rowPrefetchInLastFetch * m - 1;
/*  526 */         int i1 = k + this.rowPrefetchInLastFetch * m - 1;
/*  527 */         paramArrayOfshort[i1] = this.defineIndicators[i1];
/*  528 */         paramArrayOfshort[n] = this.defineIndicators[n];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  535 */     int i = bool ? (this.accessors.length - 1) : 0;
/*  536 */     for (; bool ? (i > -1) : (i < this.accessors.length); 
/*  537 */       i += bool ? -1 : 1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  544 */       this.accessors[i].saveDataFromOldDefineBuffers(paramArrayOfbyte, paramArrayOfchar, paramArrayOfshort, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  551 */     super.saveDefineBuffersIfRequired(paramArrayOfchar, paramArrayOfbyte, paramArrayOfshort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  561 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  581 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  583 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  587 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  593 */         if (!paramBoolean) {
/*      */           
/*  595 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  603 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  609 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  615 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  621 */         if (!paramBoolean) {
/*      */           
/*  623 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  631 */         if (paramBoolean && paramString != null) {
/*      */           
/*  633 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  634 */           sQLException1.fillInStackTrace();
/*  635 */           throw sQLException1;
/*      */         } 
/*      */         
/*  638 */         if (paramBoolean) {
/*  639 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  642 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  648 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  654 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  660 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  666 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  670 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  673 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  680 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  686 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  692 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  698 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  704 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  710 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  713 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  718 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  721 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  728 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  734 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  740 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  746 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  752 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  768 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  769 */         sQLException.fillInStackTrace();
/*  770 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  774 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  801 */     if (!this.isOpen) {
/*      */ 
/*      */       
/*  804 */       this.connection.open(this);
/*  805 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  811 */       this.t4Connection.needLine();
/*  812 */       this.t4Connection.sendPiggyBackedMessages();
/*  813 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  814 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  816 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  818 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  819 */         this.accessors[b].initMetadata();
/*      */       }
/*  821 */     } catch (IOException iOException) {
/*      */       
/*  823 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  826 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  827 */       sQLException.fillInStackTrace();
/*  828 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  832 */     this.describedWithNames = true;
/*  833 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  868 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.execute_for_describe");
/*      */     
/*      */     try {
/*  871 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  877 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  881 */         doOall8(true, true, false, true, (this.definedColumnType != null));
/*      */       }
/*      */     
/*  884 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  887 */       throw sQLException;
/*      */     }
/*  889 */     catch (IOException iOException) {
/*      */       
/*  891 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  893 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  894 */       sQLException.fillInStackTrace();
/*  895 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  900 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  901 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     } 
/*      */     
/*  904 */     this.needToParse = false;
/*      */ 
/*      */     
/*  907 */     if (this.connection.calculateChecksum) {
/*  908 */       if (this.validRows > 0) {
/*  909 */         calculateCheckSum();
/*  910 */       } else if (this.rowsProcessed > 0) {
/*  911 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  913 */         this.checkSum = l;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  923 */     if (this.definedColumnType == null) {
/*  924 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  926 */     this.aFetchWasDoneDuringDescribe = false;
/*  927 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  929 */       this.aFetchWasDoneDuringDescribe = true;
/*  930 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  934 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  935 */       this.accessors[b].initMetadata();
/*      */     }
/*  937 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  979 */         boolean bool = false;
/*  980 */         if (this.columnsDefinedByUser) {
/*  981 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1001 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1009 */           boolean bool1 = false;
/* 1010 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1011 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1013 */           for (byte b = 0; b < this.accessors.length; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1018 */             arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/* 1019 */             if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1025 */               bool1 = true;
/* 1026 */               (this.accessors[b]).lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1027 */               arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */             } 
/*      */           } 
/*      */           
/* 1031 */           if (bool1) {
/*      */             
/* 1033 */             this.definedColumnType = arrayOfInt1;
/* 1034 */             this.definedColumnSize = arrayOfInt2;
/* 1035 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1041 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1043 */         this.needToParse = false;
/* 1044 */         if (bool) {
/* 1045 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/* 1049 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     
/* 1052 */     } catch (SQLException sQLException) {
/*      */       
/* 1054 */       throw sQLException;
/*      */     }
/* 1056 */     catch (IOException iOException) {
/*      */       
/* 1058 */       ((T4CConnection)this.connection).handleIOException(iOException);
/* 1059 */       calculateCheckSum();
/*      */       
/* 1061 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1062 */       sQLException.fillInStackTrace();
/* 1063 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1090 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1094 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1098 */           this.nextStream.close();
/*      */         }
/* 1100 */         catch (IOException iOException) {
/*      */           
/* 1102 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1104 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1105 */           sQLException.fillInStackTrace();
/* 1106 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1110 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1116 */       doOall8(false, false, true, false, false);
/*      */       
/* 1118 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/* 1120 */     catch (IOException iOException) {
/*      */       
/* 1122 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1124 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1125 */       sQLException.fillInStackTrace();
/* 1126 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1132 */     calculateCheckSum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1147 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1149 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1151 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1154 */     } catch (IOException iOException) {
/*      */       
/* 1156 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1159 */       sQLException.fillInStackTrace();
/* 1160 */       throw sQLException;
/*      */     
/*      */     }
/* 1163 */     catch (SQLException sQLException) {
/*      */       
/* 1165 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1168 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1173 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1197 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.do_close");
/*      */ 
/*      */     
/*      */     try {
/* 1201 */       if (this.cursorId != 0)
/*      */       {
/* 1203 */         this.t4Connection.cursorToClose[this.t4Connection.cursorToCloseOffset++] = this.cursorId;
/*      */ 
/*      */         
/* 1206 */         if (this.t4Connection.cursorToCloseOffset >= this.t4Connection.cursorToClose.length)
/*      */         {
/*      */           
/* 1209 */           this.t4Connection.sendPiggyBackedMessages();
/*      */         }
/*      */       }
/*      */     
/* 1213 */     } catch (IOException iOException) {
/*      */       
/* 1215 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1217 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1218 */       sQLException.fillInStackTrace();
/* 1219 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1223 */     this.tmpByteArray = null;
/* 1224 */     this.tmpBindsByteArray = null;
/* 1225 */     this.definedColumnType = null;
/* 1226 */     this.definedColumnSize = null;
/* 1227 */     this.definedColumnFormOfUse = null;
/* 1228 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1248 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CCallableStatement.closeQuery");
/*      */ 
/*      */     
/* 1251 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1255 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1259 */           this.nextStream.close();
/*      */         }
/* 1261 */         catch (IOException iOException) {
/*      */           
/* 1263 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1265 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1266 */           sQLException.fillInStackTrace();
/* 1267 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1271 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Binder getRowidNullBinder(int paramInt) {
/* 1320 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */       
/* 1323 */       this.currentRowCharLens[paramInt] = 1;
/* 1324 */       return this.theVarcharNullBinder;
/*      */     } 
/*      */     
/* 1327 */     return this.theRowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean) throws SQLException {
/* 1341 */     return new T4CPlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1351 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */