/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NCLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8TTIClob
/*     */   extends T4C8TTILob
/*     */ {
/*     */   int[] nBytes;
/*     */   
/*     */   T4C8TTIClob(T4CConnection paramT4CConnection) {
/* 147 */     super(paramT4CConnection);
/*     */     
/* 149 */     this.nBytes = new int[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long read(byte[] paramArrayOfbyte, long paramLong1, long paramLong2, boolean paramBoolean, char[] paramArrayOfchar, int paramInt) throws SQLException, IOException {
/* 184 */     long l1 = 0L;
/* 185 */     long l2 = paramLong2;
/* 186 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     byte[] arrayOfByte = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 203 */       initializeLobdef();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 211 */       if ((paramArrayOfbyte[6] & 0x80) == 128) {
/* 212 */         bool = true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       int i = 0;
/* 220 */       if (bool == true) {
/* 221 */         i = (int)paramLong2 * 2;
/*     */       } else {
/* 223 */         i = (int)paramLong2 * 3;
/*     */       } 
/*     */       
/* 226 */       arrayOfByte = this.connection.getByteBuffer(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       if ((paramArrayOfbyte[7] & 0x40) > 0) {
/* 235 */         this.littleEndianClob = true;
/*     */       }
/*     */ 
/*     */       
/* 239 */       this.lobops = 2L;
/* 240 */       this.sourceLobLocator = paramArrayOfbyte;
/* 241 */       this.sourceOffset = paramLong1;
/* 242 */       this.lobamt = paramLong2;
/* 243 */       this.sendLobamt = true;
/* 244 */       this.outBuffer = arrayOfByte;
/*     */       
/* 246 */       doRPC();
/*     */       
/* 248 */       l2 = this.lobamt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 254 */       long l = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 259 */       if (bool == true)
/*     */       {
/* 261 */         if (this.connection.versionNumber < 10101)
/*     */         {
/*     */ 
/*     */           
/* 265 */           DBConversion.ucs2BytesToJavaChars(this.outBuffer, (int)this.lobBytesRead, paramArrayOfchar);
/*     */         
/*     */         }
/* 268 */         else if (this.littleEndianClob)
/*     */         {
/* 270 */           CharacterSet.convertAL16UTF16LEBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, (int)this.lobBytesRead, true);
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 275 */           CharacterSet.convertAL16UTF16BytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, (int)this.lobBytesRead, true);
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 283 */       else if (!paramBoolean)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 288 */         this.nBytes[0] = (int)this.lobBytesRead;
/*     */         
/* 290 */         this.meg.conv.CHARBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, this.nBytes, paramArrayOfchar.length);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 301 */         this.nBytes[0] = (int)this.lobBytesRead;
/*     */         
/* 303 */         this.meg.conv.NCHARBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, this.nBytes, paramArrayOfchar.length);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 310 */       this.outBuffer = null;
/* 311 */       this.connection.cacheBuffer(arrayOfByte);
/*     */     } 
/*     */     
/* 314 */     return l2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long write(byte[] paramArrayOfbyte, long paramLong1, boolean paramBoolean, char[] paramArrayOfchar, long paramLong2, long paramLong3) throws SQLException, IOException {
/* 356 */     boolean bool = false;
/* 357 */     if ((paramArrayOfbyte[6] & 0x80) == 128) {
/* 358 */       bool = true;
/*     */     }
/* 360 */     if ((paramArrayOfbyte[7] & 0x40) == 64) {
/* 361 */       this.littleEndianClob = true;
/*     */     }
/*     */ 
/*     */     
/* 365 */     long l = 0L;
/* 366 */     byte[] arrayOfByte = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 372 */     if (bool == true) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 377 */       arrayOfByte = new byte[(int)paramLong3 * 2];
/*     */       
/* 379 */       if (this.connection.versionNumber < 10101)
/*     */       {
/* 381 */         DBConversion.javaCharsToUcs2Bytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       }
/* 383 */       else if (this.littleEndianClob)
/*     */       {
/* 385 */         CharacterSet.convertJavaCharsToAL16UTF16LEBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       }
/*     */       else
/*     */       {
/* 389 */         CharacterSet.convertJavaCharsToAL16UTF16Bytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 397 */       arrayOfByte = new byte[(int)paramLong3 * 3];
/*     */       
/* 399 */       if (!paramBoolean) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 404 */         l = this.meg.conv.javaCharsToCHARBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 412 */         l = this.meg.conv.javaCharsToNCHARBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 419 */     initializeLobdef();
/*     */ 
/*     */     
/* 422 */     this.lobops = 64L;
/* 423 */     this.sourceLobLocator = paramArrayOfbyte;
/* 424 */     this.sourceOffset = paramLong1;
/* 425 */     this.lobamt = paramLong3;
/* 426 */     this.sendLobamt = true;
/* 427 */     this.inBuffer = arrayOfByte;
/* 428 */     this.inBufferOffset = 0L;
/*     */ 
/*     */ 
/*     */     
/* 432 */     if (bool == true) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 437 */       if (this.connection.versionNumber < 10101) {
/* 438 */         this.inBufferNumBytes = paramLong3;
/*     */       } else {
/* 440 */         this.inBufferNumBytes = paramLong3 * 2L;
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 447 */       this.inBufferNumBytes = l;
/*     */     } 
/* 449 */     doRPC();
/*     */     
/* 451 */     return this.lobamt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
/* 473 */     return createTemporaryLob(paramConnection, paramBoolean, paramInt, (short)1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException, IOException {
/*     */     NCLOB nCLOB;
/* 488 */     if (paramInt == 12) {
/*     */       
/* 490 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
/* 491 */       sQLException.fillInStackTrace();
/* 492 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 497 */     CLOB cLOB = null;
/*     */ 
/*     */     
/* 500 */     initializeLobdef();
/*     */ 
/*     */     
/* 503 */     this.lobops = 272L;
/* 504 */     this.sourceLobLocator = new byte[86];
/* 505 */     this.sourceLobLocator[1] = 84;
/*     */ 
/*     */     
/* 508 */     if (paramShort == 1) {
/* 509 */       this.sourceOffset = 1L;
/*     */     } else {
/* 511 */       this.sourceOffset = 2L;
/*     */     } 
/*     */ 
/*     */     
/* 515 */     this.destinationOffset = 112L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 524 */     this.destinationLength = paramInt;
/*     */     
/* 526 */     this.lobamt = paramInt;
/* 527 */     this.sendLobamt = true;
/*     */ 
/*     */     
/* 530 */     this.nullO2U = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 535 */     this.characterSet = (paramShort == 2) ? this.meg.conv.getNCharSetId() : this.meg.conv.getServerCharSetId();
/*     */     
/* 537 */     if (this.connection.versionNumber >= 9000) {
/*     */       
/* 539 */       this.lobscn = new int[1];
/* 540 */       this.lobscn[0] = paramBoolean ? 1 : 0;
/* 541 */       this.lobscnl = 1;
/*     */     } 
/*     */     
/* 544 */     doRPC();
/*     */ 
/*     */ 
/*     */     
/* 548 */     if (this.sourceLobLocator != null)
/*     */     {
/* 550 */       if (paramShort == 1) {
/* 551 */         cLOB = new CLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */       }
/*     */       else {
/*     */         
/* 555 */         nCLOB = new NCLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */       } 
/*     */     }
/*     */     
/* 559 */     return (Datum)nCLOB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 578 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */     
/* 582 */     byte b = 2;
/*     */     
/* 584 */     if (paramInt == 0) {
/* 585 */       b = 1;
/*     */     }
/* 587 */     bool = _open(paramArrayOfbyte, b, 32768);
/*     */     
/* 589 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 607 */     boolean bool = false;
/*     */     
/* 609 */     bool = _close(paramArrayOfbyte, 65536);
/*     */     
/* 611 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 630 */     boolean bool = false;
/*     */     
/* 632 */     bool = _isOpen(paramArrayOfbyte, 69632);
/*     */     
/* 634 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 639 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4C8TTIClob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */