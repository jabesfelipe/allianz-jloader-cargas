/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleParameterMetaData;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleParameterMetaData
/*     */   implements OracleParameterMetaData
/*     */ {
/*  25 */   int parameterCount = 0;
/*     */ 
/*     */   
/*     */   int parameterNoNulls;
/*     */ 
/*     */   
/*     */   int parameterNullable;
/*     */   
/*     */   int parameterNullableUnknown;
/*     */   
/*     */   int parameterModeUnknown;
/*     */   
/*     */   int parameterModeIn;
/*     */   
/*     */   int parameterModeInOut;
/*     */   
/*     */   int parameterModeOut;
/*     */ 
/*     */   
/*     */   public int getParameterCount() throws SQLException {
/*  45 */     return this.parameterCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int isNullable(int paramInt) throws SQLException {
/*  64 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  65 */     sQLException.fillInStackTrace();
/*  66 */     throw sQLException;
/*     */   } public boolean isSigned(int paramInt) throws SQLException {
/*     */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   } public int getPrecision(int paramInt) throws SQLException {
/*     */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   } OracleParameterMetaData(int paramInt) throws SQLException {
/*  76 */     this.parameterNoNulls = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.parameterNullable = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     this.parameterNullableUnknown = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     this.parameterModeUnknown = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     this.parameterModeIn = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     this.parameterModeInOut = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     this.parameterModeOut = 4;
/*     */     this.parameterCount = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale(int paramInt) throws SQLException {
/*     */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParameterMode(int paramInt) throws SQLException {
/* 261 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 262 */     sQLException.fillInStackTrace();
/* 263 */     throw sQLException;
/*     */   }
/*     */   public int getParameterType(int paramInt) throws SQLException {
/*     */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */   public String getParameterTypeName(int paramInt) throws SQLException {
/*     */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */   public String getParameterClassName(int paramInt) throws SQLException {
/*     */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 281 */     if (paramClass.isInterface()) return paramClass.isInstance(this);
/*     */     
/* 283 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 284 */     sQLException.fillInStackTrace();
/* 285 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 302 */     if (paramClass.isInterface() && paramClass.isInstance(this)) return (T)this;
/*     */     
/* 304 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 305 */     sQLException.fillInStackTrace();
/* 306 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 328 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleParameterMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */