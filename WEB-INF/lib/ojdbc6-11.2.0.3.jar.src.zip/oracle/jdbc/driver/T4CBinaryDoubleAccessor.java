/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CBinaryDoubleAccessor
/*     */   extends BinaryDoubleAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   final int[] meta;
/*     */   
/*     */   T4CBinaryDoubleAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  44 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CBinaryDoubleAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       this.definedColumnType = 0;
/*     */       this.definedColumnSize = 0;
/*     */     } else {
/*     */       this.definedColumnType = paramInt7;
/*     */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     if (paramInt1 == -1) {
/*     */       this.underlyingLongRaw = true;
/*     */     } }
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 144 */     if (this.isUseLess) {
/*     */       
/* 146 */       this.lastRowProcessed++;
/*     */       
/* 148 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 157 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 159 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 160 */       processIndicator(this.meta[0]);
/*     */       
/* 162 */       this.lastRowProcessed++;
/*     */       
/* 164 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 168 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 169 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 173 */     if (this.isNullByDescribe) {
/*     */       
/* 175 */       this.rowSpaceIndicator[i] = -1;
/* 176 */       this.rowSpaceIndicator[j] = 0;
/* 177 */       this.lastRowProcessed++;
/*     */       
/* 179 */       if (this.statement.connection.versionNumber < 9200) {
/* 180 */         processIndicator(0);
/*     */       }
/* 182 */       return false;
/*     */     } 
/*     */     
/* 185 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */ 
/*     */ 
/*     */     
/* 189 */     this.mare.unmarshalCLR(this.rowSpaceByte, k, this.meta, this.byteLength);
/*     */     
/* 191 */     processIndicator(this.meta[0]);
/*     */     
/* 193 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 197 */       this.rowSpaceIndicator[i] = -1;
/* 198 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 202 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/* 203 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 206 */     this.lastRowProcessed++;
/*     */     
/* 208 */     return false; }
/*     */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2(); this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     }  }
/*     */   String getString(int paramInt) throws SQLException { String str = super.getString(paramInt); if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/* 218 */       str = str.substring(0, this.definedColumnSize);  return str; } void copyRow() throws SQLException, IOException { int i; if (this.lastRowProcessed == 0) {
/* 219 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 221 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 224 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 225 */     int k = this.columnIndex + i * this.byteLength;
/* 226 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 227 */     int n = this.indicatorIndex + i;
/* 228 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 229 */     int i2 = this.lengthIndex + i;
/* 230 */     short s = this.rowSpaceIndicator[i2];
/* 231 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 233 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 237 */     this.rowSpaceIndicator[i1] = (short)s;
/* 238 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 241 */     if (!this.isNullByDescribe)
/*     */     {
/* 243 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 248 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 251 */     this.lastRowProcessed++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 263 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 265 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 267 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 268 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 269 */     int n = this.lengthIndex + paramInt2 - 1;
/* 270 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 271 */     short s = paramArrayOfshort[i1];
/*     */     
/* 273 */     this.rowSpaceIndicator[n] = (short)s;
/* 274 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 277 */     if (s != 0)
/*     */     {
/* 279 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 291 */     if (this.definedColumnType == 0) {
/* 292 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 295 */     Object object = null;
/*     */     
/* 297 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 299 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 300 */       sQLException.fillInStackTrace();
/* 301 */       throw sQLException;
/*     */     } 
/*     */     
/* 304 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 306 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -15:
/*     */         case -9:
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 320 */           return getString(paramInt);
/*     */ 
/*     */         
/*     */         case 2:
/*     */         case 3:
/* 325 */           return getBigDecimal(paramInt);
/*     */ 
/*     */         
/*     */         case 6:
/*     */         case 8:
/* 330 */           return Double.valueOf(getDouble(paramInt));
/*     */         
/*     */         case 101:
/* 333 */           return getBINARY_DOUBLE(paramInt);
/*     */         
/*     */         case 7:
/* 336 */           return Float.valueOf(getFloat(paramInt));
/*     */         
/*     */         case -5:
/* 339 */           return Long.valueOf(getLong(paramInt));
/*     */         
/*     */         case -6:
/* 342 */           return Byte.valueOf(getByte(paramInt));
/*     */         
/*     */         case 5:
/* 345 */           return Short.valueOf(getShort(paramInt));
/*     */         
/*     */         case 4:
/* 348 */           return Integer.valueOf(getInt(paramInt));
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 355 */           return getBytes(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 359 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 360 */       sQLException.fillInStackTrace();
/* 361 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 372 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CBinaryDoubleAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */