/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import oracle.jdbc.aq.AQAgent;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AQMessagePropertiesI
/*     */   implements AQMessageProperties
/*     */ {
/*  66 */   private int attrAttempts = -1;
/*  67 */   private String attrCorrelation = null;
/*  68 */   private int attrDelay = 0;
/*  69 */   private Timestamp attrEnqTime = null;
/*  70 */   private String attrExceptionQueue = null;
/*  71 */   private int attrExpiration = -1;
/*  72 */   private AQMessageProperties.MessageState attrMsgState = null;
/*  73 */   private int attrPriority = 0;
/*  74 */   private AQAgentI[] attrRecipientList = null;
/*  75 */   private AQAgentI attrSenderId = null;
/*  76 */   private String attrTransactionGroup = null;
/*  77 */   private byte[] attrPreviousQueueMsgId = null;
/*  78 */   private AQMessageProperties.DeliveryMode deliveryMode = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDequeueAttemptsCount() {
/*  86 */     return this.attrAttempts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCorrelation(String paramString) throws SQLException {
/*  94 */     this.attrCorrelation = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCorrelation() {
/* 101 */     return this.attrCorrelation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelay(int paramInt) throws SQLException {
/* 108 */     this.attrDelay = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDelay() {
/* 115 */     return this.attrDelay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timestamp getEnqueueTime() {
/* 122 */     return this.attrEnqTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExceptionQueue(String paramString) throws SQLException {
/* 130 */     this.attrExceptionQueue = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExceptionQueue() {
/* 137 */     return this.attrExceptionQueue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpiration(int paramInt) throws SQLException {
/* 145 */     this.attrExpiration = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExpiration() {
/* 152 */     return this.attrExpiration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties.MessageState getState() {
/* 159 */     return this.attrMsgState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPriority(int paramInt) throws SQLException {
/* 166 */     this.attrPriority = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPriority() {
/* 173 */     return this.attrPriority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRecipientList(AQAgent[] paramArrayOfAQAgent) throws SQLException {
/* 181 */     this.attrRecipientList = new AQAgentI[paramArrayOfAQAgent.length];
/* 182 */     for (byte b = 0; b < paramArrayOfAQAgent.length; b++) {
/* 183 */       this.attrRecipientList[b] = (AQAgentI)paramArrayOfAQAgent[b];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AQAgent[] getRecipientList() {
/* 190 */     return (AQAgent[])this.attrRecipientList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSender(AQAgent paramAQAgent) throws SQLException {
/* 197 */     this.attrSenderId = (AQAgentI)paramAQAgent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQAgent getSender() {
/* 204 */     return this.attrSenderId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransactionGroup() {
/* 211 */     return this.attrTransactionGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTransactionGroup(String paramString) {
/* 218 */     this.attrTransactionGroup = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPreviousQueueMessageId(byte[] paramArrayOfbyte) {
/* 225 */     this.attrPreviousQueueMsgId = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPreviousQueueMessageId() {
/* 232 */     return this.attrPreviousQueueMsgId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties.DeliveryMode getDeliveryMode() {
/* 239 */     return this.deliveryMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDeliveryMode(AQMessageProperties.DeliveryMode paramDeliveryMode) {
/* 246 */     this.deliveryMode = paramDeliveryMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 284 */     StringBuffer stringBuffer = new StringBuffer();
/* 285 */     stringBuffer.append("Correlation             : " + getCorrelation() + "\n");
/* 286 */     Timestamp timestamp = getEnqueueTime();
/* 287 */     if (timestamp != null)
/* 288 */       stringBuffer.append("Enqueue time            : " + timestamp + "\n"); 
/* 289 */     stringBuffer.append("Exception Queue         : " + getExceptionQueue() + "\n");
/* 290 */     stringBuffer.append("Sender                  : (" + getSender() + ")\n");
/* 291 */     int i = getDequeueAttemptsCount();
/* 292 */     if (i != -1)
/* 293 */       stringBuffer.append("Attempts                : " + i + "\n"); 
/* 294 */     stringBuffer.append("Delay                   : " + getDelay() + "\n");
/* 295 */     stringBuffer.append("Expiration              : " + getExpiration() + "\n");
/* 296 */     AQMessageProperties.MessageState messageState = getState();
/*     */     
/* 298 */     if (messageState != null)
/* 299 */       stringBuffer.append("State                   : " + messageState + "\n"); 
/* 300 */     stringBuffer.append("Priority                : " + getPriority() + "\n");
/* 301 */     AQMessageProperties.DeliveryMode deliveryMode = getDeliveryMode();
/*     */     
/* 303 */     if (deliveryMode != null)
/* 304 */       stringBuffer.append("Delivery Mode           : " + deliveryMode + "\n"); 
/* 305 */     stringBuffer.append("Recipient List          : {");
/* 306 */     AQAgent[] arrayOfAQAgent = getRecipientList();
/* 307 */     if (arrayOfAQAgent != null)
/*     */     {
/* 309 */       for (byte b = 0; b < arrayOfAQAgent.length; b++) {
/*     */         
/* 311 */         stringBuffer.append(arrayOfAQAgent[b]);
/* 312 */         if (b != arrayOfAQAgent.length - 1)
/* 313 */           stringBuffer.append("; "); 
/*     */       } 
/*     */     }
/* 316 */     stringBuffer.append("}");
/*     */     
/* 318 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAttempts(int paramInt) throws SQLException {
/* 325 */     this.attrAttempts = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEnqueueTime(Timestamp paramTimestamp) throws SQLException {
/* 334 */     this.attrEnqTime = paramTimestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setMessageState(AQMessageProperties.MessageState paramMessageState) throws SQLException {
/* 342 */     this.attrMsgState = paramMessageState;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 347 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\AQMessagePropertiesI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */