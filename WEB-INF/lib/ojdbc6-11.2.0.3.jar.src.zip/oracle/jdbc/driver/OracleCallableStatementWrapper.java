/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleCallableStatement;
/*      */ import oracle.jdbc.OraclePreparedStatement;
/*      */ import oracle.jdbc.internal.OracleCallableStatement;
/*      */ import oracle.jdbc.internal.OraclePreparedStatement;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ class OracleCallableStatementWrapper
/*      */   extends OraclePreparedStatementWrapper
/*      */   implements OracleCallableStatement
/*      */ {
/*   56 */   protected OracleCallableStatement callableStatement = null;
/*      */ 
/*      */   
/*      */   OracleCallableStatementWrapper(OracleCallableStatement paramOracleCallableStatement) throws SQLException {
/*   60 */     super((OraclePreparedStatement)paramOracleCallableStatement);
/*   61 */     this.callableStatement = (OracleCallableStatement)paramOracleCallableStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(String paramString, Array paramArray) throws SQLException {
/*   83 */     this.callableStatement.setArray(paramString, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*   91 */     this.callableStatement.setBigDecimal(paramString, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, Blob paramBlob) throws SQLException {
/*   99 */     this.callableStatement.setBlob(paramString, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
/*  107 */     this.callableStatement.setBoolean(paramString, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte) throws SQLException {
/*  115 */     this.callableStatement.setByte(paramString, paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  123 */     this.callableStatement.setBytes(paramString, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Clob paramClob) throws SQLException {
/*  131 */     this.callableStatement.setClob(paramString, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate) throws SQLException {
/*  139 */     this.callableStatement.setDate(paramString, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  147 */     this.callableStatement.setDate(paramString, paramDate, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLException {
/*  155 */     this.callableStatement.setDouble(paramString, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLException {
/*  163 */     this.callableStatement.setFloat(paramString, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt) throws SQLException {
/*  171 */     this.callableStatement.setInt(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong) throws SQLException {
/*  179 */     this.callableStatement.setLong(paramString, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, NClob paramNClob) throws SQLException {
/*  187 */     this.callableStatement.setNClob(paramString, paramNClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(String paramString1, String paramString2) throws SQLException {
/*  195 */     this.callableStatement.setNString(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject) throws SQLException {
/*  203 */     this.callableStatement.setObject(paramString, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  211 */     this.callableStatement.setObject(paramString, paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(String paramString, Ref paramRef) throws SQLException {
/*  219 */     this.callableStatement.setRef(paramString, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowId(String paramString, RowId paramRowId) throws SQLException {
/*  227 */     this.callableStatement.setRowId(paramString, paramRowId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort) throws SQLException {
/*  235 */     this.callableStatement.setShort(paramString, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
/*  243 */     this.callableStatement.setSQLXML(paramString, paramSQLXML);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) throws SQLException {
/*  251 */     this.callableStatement.setString(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime) throws SQLException {
/*  259 */     this.callableStatement.setTime(paramString, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  267 */     this.callableStatement.setTime(paramString, paramTime, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  275 */     this.callableStatement.setTimestamp(paramString, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  283 */     this.callableStatement.setTimestamp(paramString, paramTimestamp, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String paramString, URL paramURL) throws SQLException {
/*  291 */     this.callableStatement.setURL(paramString, paramURL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/*  299 */     this.callableStatement.setARRAY(paramString, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/*  307 */     this.callableStatement.setBFILE(paramString, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
/*  315 */     this.callableStatement.setBfile(paramString, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
/*  323 */     this.callableStatement.setBinaryFloat(paramString, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  331 */     this.callableStatement.setBinaryFloat(paramString, paramBINARY_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
/*  339 */     this.callableStatement.setBinaryDouble(paramString, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  347 */     this.callableStatement.setBinaryDouble(paramString, paramBINARY_DOUBLE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/*  355 */     this.callableStatement.setBLOB(paramString, paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/*  363 */     this.callableStatement.setCHAR(paramString, paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/*  371 */     this.callableStatement.setCLOB(paramString, paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/*  379 */     this.callableStatement.setCursor(paramString, paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/*  387 */     this.callableStatement.setCustomDatum(paramString, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(String paramString, DATE paramDATE) throws SQLException {
/*  395 */     this.callableStatement.setDATE(paramString, paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
/*  403 */     this.callableStatement.setFixedCHAR(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/*  411 */     this.callableStatement.setINTERVALDS(paramString, paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/*  419 */     this.callableStatement.setINTERVALYM(paramString, paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/*  427 */     this.callableStatement.setNUMBER(paramString, paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/*  435 */     this.callableStatement.setOPAQUE(paramString, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
/*  443 */     this.callableStatement.setOracleObject(paramString, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
/*  451 */     this.callableStatement.setORAData(paramString, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(String paramString, RAW paramRAW) throws SQLException {
/*  459 */     this.callableStatement.setRAW(paramString, paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(String paramString, REF paramREF) throws SQLException {
/*  467 */     this.callableStatement.setREF(paramString, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(String paramString, REF paramREF) throws SQLException {
/*  475 */     this.callableStatement.setRefType(paramString, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
/*  483 */     this.callableStatement.setROWID(paramString, paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/*  491 */     this.callableStatement.setSTRUCT(paramString, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/*  499 */     this.callableStatement.setTIMESTAMPLTZ(paramString, paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/*  507 */     this.callableStatement.setTIMESTAMPTZ(paramString, paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/*  515 */     this.callableStatement.setTIMESTAMP(paramString, paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, InputStream paramInputStream) throws SQLException {
/*  523 */     this.callableStatement.setBlob(paramString, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/*  531 */     this.callableStatement.setBlob(paramString, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Reader paramReader) throws SQLException {
/*  539 */     this.callableStatement.setClob(paramString, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/*  547 */     this.callableStatement.setClob(paramString, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, Reader paramReader) throws SQLException {
/*  555 */     this.callableStatement.setNClob(paramString, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/*  563 */     this.callableStatement.setNClob(paramString, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
/*  571 */     this.callableStatement.setAsciiStream(paramString, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  579 */     this.callableStatement.setAsciiStream(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/*  587 */     this.callableStatement.setAsciiStream(paramString, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
/*  595 */     this.callableStatement.setBinaryStream(paramString, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  603 */     this.callableStatement.setBinaryStream(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/*  611 */     this.callableStatement.setBinaryStream(paramString, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader) throws SQLException {
/*  619 */     this.callableStatement.setCharacterStream(paramString, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/*  627 */     this.callableStatement.setCharacterStream(paramString, paramReader, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/*  635 */     this.callableStatement.setCharacterStream(paramString, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String paramString, Reader paramReader) throws SQLException {
/*  643 */     this.callableStatement.setNCharacterStream(paramString, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/*  651 */     this.callableStatement.setNCharacterStream(paramString, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  659 */     this.callableStatement.setUnicodeStream(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
/*  669 */     this.callableStatement.setNull(paramString1, paramInt, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString, int paramInt) throws SQLException {
/*  678 */     this.callableStatement.setNull(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/*  688 */     return this.callableStatement.getArray(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*  696 */     return this.callableStatement.getBigDecimal(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  704 */     return this.callableStatement.getBigDecimal(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/*  712 */     return this.callableStatement.getBlob(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  720 */     return this.callableStatement.getBoolean(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  728 */     return this.callableStatement.getByte(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  736 */     return this.callableStatement.getBytes(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/*  744 */     return this.callableStatement.getClob(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  752 */     return this.callableStatement.getDate(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  760 */     return this.callableStatement.getDate(paramInt, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  768 */     return this.callableStatement.getDouble(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  776 */     return this.callableStatement.getFloat(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  784 */     return this.callableStatement.getInt(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  792 */     return this.callableStatement.getLong(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/*  800 */     return this.callableStatement.getNClob(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/*  808 */     return this.callableStatement.getNString(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/*  816 */     return this.callableStatement.getObject(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/*  824 */     return this.callableStatement.getObject(paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/*  832 */     return this.callableStatement.getRef(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/*  840 */     return this.callableStatement.getRowId(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/*  848 */     return this.callableStatement.getShort(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/*  856 */     return this.callableStatement.getSQLXML(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  864 */     return this.callableStatement.getString(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/*  872 */     return this.callableStatement.getTime(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/*  880 */     return this.callableStatement.getTime(paramInt, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  888 */     return this.callableStatement.getTimestamp(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/*  896 */     return this.callableStatement.getTimestamp(paramInt, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/*  904 */     return this.callableStatement.getURL(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  912 */     return this.callableStatement.getARRAY(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/*  920 */     return this.callableStatement.getBFILE(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/*  928 */     return this.callableStatement.getBfile(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/*  936 */     return this.callableStatement.getBLOB(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/*  944 */     return this.callableStatement.getCHAR(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/*  952 */     return this.callableStatement.getCLOB(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/*  960 */     return this.callableStatement.getCursor(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/*  968 */     return this.callableStatement.getCustomDatum(paramInt, paramCustomDatumFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/*  976 */     return this.callableStatement.getDATE(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/*  984 */     return this.callableStatement.getINTERVALDS(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/*  992 */     return this.callableStatement.getINTERVALYM(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1000 */     return this.callableStatement.getNUMBER(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1008 */     return this.callableStatement.getOPAQUE(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/* 1016 */     return this.callableStatement.getOracleObject(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1024 */     return this.callableStatement.getORAData(paramInt, paramORADataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 1032 */     return this.callableStatement.getRAW(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 1040 */     return this.callableStatement.getREF(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 1048 */     return this.callableStatement.getROWID(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 1056 */     return this.callableStatement.getSTRUCT(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1064 */     return this.callableStatement.getTIMESTAMPLTZ(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1072 */     return this.callableStatement.getTIMESTAMPTZ(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1080 */     return this.callableStatement.getTIMESTAMP(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 1088 */     return this.callableStatement.getAsciiStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 1096 */     return this.callableStatement.getBinaryStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1104 */     return this.callableStatement.getCharacterStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 1112 */     return this.callableStatement.getNCharacterStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 1120 */     return this.callableStatement.getUnicodeStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/* 1129 */     return this.callableStatement.getArray(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/* 1137 */     return this.callableStatement.getBigDecimal(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/* 1145 */     return this.callableStatement.getBigDecimal(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/* 1153 */     return this.callableStatement.getBlob(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/* 1161 */     return this.callableStatement.getBoolean(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/* 1169 */     return this.callableStatement.getByte(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/* 1177 */     return this.callableStatement.getBytes(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/* 1185 */     return this.callableStatement.getClob(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/* 1193 */     return this.callableStatement.getDate(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/* 1201 */     return this.callableStatement.getDate(paramString, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/* 1209 */     return this.callableStatement.getDouble(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/* 1217 */     return this.callableStatement.getFloat(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/* 1225 */     return this.callableStatement.getInt(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/* 1233 */     return this.callableStatement.getLong(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(String paramString) throws SQLException {
/* 1241 */     return this.callableStatement.getNClob(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(String paramString) throws SQLException {
/* 1249 */     return this.callableStatement.getNString(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLException {
/* 1257 */     return this.callableStatement.getObject(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/* 1265 */     return this.callableStatement.getObject(paramString, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/* 1273 */     return this.callableStatement.getRef(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(String paramString) throws SQLException {
/* 1281 */     return this.callableStatement.getRowId(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/* 1289 */     return this.callableStatement.getShort(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(String paramString) throws SQLException {
/* 1297 */     return this.callableStatement.getSQLXML(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/* 1305 */     return this.callableStatement.getString(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/* 1313 */     return this.callableStatement.getTime(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/* 1321 */     return this.callableStatement.getTime(paramString, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/* 1329 */     return this.callableStatement.getTimestamp(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/* 1337 */     return this.callableStatement.getTimestamp(paramString, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/* 1345 */     return this.callableStatement.getURL(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/* 1353 */     return this.callableStatement.getAsciiStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/* 1361 */     return this.callableStatement.getBinaryStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/* 1369 */     return this.callableStatement.getCharacterStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(String paramString) throws SQLException {
/* 1377 */     return this.callableStatement.getNCharacterStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/* 1385 */     return this.callableStatement.getUnicodeStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 1399 */     this.callableStatement.setObject(paramString, paramObject, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
/* 1407 */     return this.callableStatement.getAnyDataEmbeddedObject(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException {
/* 1416 */     this.callableStatement.setStructDescriptor(paramInt, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 1425 */     this.callableStatement.setStructDescriptor(paramString, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/* 1434 */     super.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeWithKey(String paramString) throws SQLException {
/* 1441 */     this.callableStatement.closeWithKey(paramString);
/* 1442 */     this.statement = (OracleStatement)(this.preparedStatement = (OraclePreparedStatement)(this.callableStatement = closedStatement));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 1455 */     this.callableStatement.registerOutParameter(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 1463 */     this.callableStatement.registerOutParameterBytes(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 1471 */     this.callableStatement.registerOutParameterChars(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 1479 */     this.callableStatement.registerIndexTableOutParameter(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1487 */     this.callableStatement.registerOutParameter(paramString, paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 1497 */     this.callableStatement.registerOutParameter(paramString1, paramInt, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/* 1505 */     return this.callableStatement.sendBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExecuteBatch(int paramInt) throws SQLException {
/* 1513 */     this.callableStatement.setExecuteBatch(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt) throws SQLException {
/* 1521 */     return this.callableStatement.getPlsqlIndexTable(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
/* 1529 */     return this.callableStatement.getPlsqlIndexTable(paramInt, paramClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 1537 */     return this.callableStatement.getOraclePlsqlIndexTable(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(String paramString1, String paramString2) throws SQLException {
/* 1545 */     this.callableStatement.setStringForClob(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 1553 */     this.callableStatement.setBytesForBlob(paramString, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/* 1561 */     return this.callableStatement.wasNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/* 1569 */     this.callableStatement.registerOutParameter(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1577 */     this.callableStatement.registerOutParameter(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 1585 */     this.callableStatement.registerOutParameter(paramInt1, paramInt2, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLException {
/* 1594 */     this.callableStatement.registerOutParameter(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 1602 */     this.callableStatement.registerOutParameter(paramString, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] privateGetBytes(int paramInt) throws SQLException {
/* 1610 */     return ((OracleCallableStatement)this.callableStatement).privateGetBytes(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleStatement.SqlKind getSqlKind() throws SQLException {
/* 1616 */     return this.callableStatement.getSqlKind();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1621 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleCallableStatementWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */