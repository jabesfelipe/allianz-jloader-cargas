/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleConversionInputStream
/*     */   extends OracleBufferedStream
/*     */ {
/*     */   static final int CHUNK_SIZE = 4096;
/*     */   DBConversion converter;
/*     */   int conversion;
/*     */   InputStream istream;
/*     */   Reader reader;
/*     */   byte[] convbuf;
/*     */   char[] javaChars;
/*     */   int maxSize;
/*     */   int totalSize;
/*     */   int numUnconvertedBytes;
/*     */   boolean endOfStream;
/*     */   private short csform;
/*     */   int[] nbytes;
/*     */   
/*     */   public OracleConversionInputStream(DBConversion paramDBConversion, InputStream paramInputStream, int paramInt) {
/*  52 */     this(paramDBConversion, paramInputStream, paramInt, (short)1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConversionInputStream(DBConversion paramDBConversion, InputStream paramInputStream, int paramInt, short paramShort) {
/*  62 */     super(4096);
/*     */     int i;
/*  64 */     this.istream = paramInputStream;
/*  65 */     this.conversion = paramInt;
/*  66 */     this.converter = paramDBConversion;
/*  67 */     this.maxSize = 0;
/*  68 */     this.totalSize = 0;
/*  69 */     this.numUnconvertedBytes = 0;
/*  70 */     this.endOfStream = false;
/*  71 */     this.nbytes = new int[1];
/*  72 */     this.csform = paramShort;
/*  73 */     this.currentBufferSize = this.initialBufferSize;
/*  74 */     this.resizableBuffer = new byte[this.currentBufferSize];
/*     */     
/*  76 */     switch (paramInt) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 0:
/*  81 */         this.javaChars = new char[4096];
/*  82 */         this.convbuf = new byte[4096];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*  89 */         this.convbuf = new byte[2048];
/*  90 */         this.javaChars = new char[2048];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*  97 */         this.convbuf = new byte[2048];
/*  98 */         this.javaChars = new char[4096];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 105 */         this.convbuf = new byte[1024];
/* 106 */         this.javaChars = new char[2048];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 113 */         i = 4096 / this.converter.getMaxCharbyteSize();
/*     */         
/* 115 */         this.convbuf = new byte[i * 2];
/* 116 */         this.javaChars = new char[i];
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 123 */         if (this.converter.isUcs2CharSet()) {
/*     */           
/* 125 */           this.convbuf = new byte[2048];
/* 126 */           this.javaChars = new char[2048];
/*     */         }
/*     */         else {
/*     */           
/* 130 */           this.convbuf = new byte[4096];
/* 131 */           this.javaChars = new char[4096];
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 139 */         i = 4096 / ((paramShort == 2) ? this.converter.getMaxNCharbyteSize() : this.converter.getMaxCharbyteSize());
/*     */         
/* 141 */         this.javaChars = new char[i];
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     this.convbuf = new byte[4096];
/* 149 */     this.javaChars = new char[4096];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConversionInputStream(DBConversion paramDBConversion, InputStream paramInputStream, int paramInt1, int paramInt2) {
/* 160 */     this(paramDBConversion, paramInputStream, paramInt1, (short)1);
/*     */     
/* 162 */     this.maxSize = paramInt2;
/* 163 */     this.totalSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConversionInputStream(DBConversion paramDBConversion, Reader paramReader, int paramInt1, int paramInt2, short paramShort) {
/* 172 */     this(paramDBConversion, (InputStream)null, paramInt1, paramShort);
/*     */     
/* 174 */     this.reader = paramReader;
/* 175 */     this.maxSize = paramInt2;
/* 176 */     this.totalSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormOfUse(short paramShort) {
/* 184 */     this.csform = paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytes(int paramInt) throws IOException {
/* 191 */     return needBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytes() throws IOException {
/* 201 */     if (this.closed) {
/* 202 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 206 */     if (this.pos < this.count) {
/* 207 */       return true;
/*     */     }
/* 209 */     if (this.istream != null)
/*     */     {
/* 211 */       return needBytesFromStream();
/*     */     }
/* 213 */     if (this.reader != null)
/*     */     {
/* 215 */       return needBytesFromReader();
/*     */     }
/*     */     
/* 218 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytesFromReader() throws IOException {
/*     */     
/* 228 */     try { int i = 0;
/*     */       
/* 230 */       if (this.maxSize == 0) {
/*     */         
/* 232 */         i = this.javaChars.length;
/*     */       }
/*     */       else {
/*     */         
/* 236 */         i = Math.min(this.maxSize - this.totalSize, this.javaChars.length);
/*     */       } 
/*     */       
/* 239 */       if (i <= 0)
/*     */       {
/* 241 */         return false;
/*     */       }
/*     */       
/* 244 */       int j = this.reader.read(this.javaChars, 0, i);
/*     */       
/* 246 */       if (j == -1)
/*     */       {
/* 248 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 252 */       this.totalSize += j;
/*     */ 
/*     */ 
/*     */       
/* 256 */       switch (this.conversion)
/*     */       
/*     */       { 
/*     */         
/*     */         case 7:
/* 261 */           if (this.csform == 2) {
/* 262 */             this.count = this.converter.javaCharsToNCHARBytes(this.javaChars, j, this.resizableBuffer);
/*     */           } else {
/* 264 */             this.count = this.converter.javaCharsToCHARBytes(this.javaChars, j, this.resizableBuffer);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 287 */           this.pos = 0;
/*     */ 
/*     */           
/* 290 */           return true; }  System.arraycopy(this.convbuf, 0, this.resizableBuffer, 0, j); this.count = j; } catch (SQLException sQLException) { IOException iOException = DatabaseError.createIOException(sQLException); iOException.fillInStackTrace(); throw iOException; }  this.pos = 0; return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytesFromStream() throws IOException {
/* 298 */     if (!this.endOfStream) {
/*     */       
/*     */       try { int k;
/*     */         byte b;
/* 302 */         int i = 0;
/*     */         
/* 304 */         if (this.maxSize == 0) {
/*     */           
/* 306 */           i = this.convbuf.length;
/*     */         }
/*     */         else {
/*     */           
/* 310 */           i = Math.min(this.maxSize - this.totalSize, this.convbuf.length);
/*     */         } 
/*     */         
/* 313 */         int j = 0;
/*     */         
/* 315 */         if (i <= 0) {
/*     */ 
/*     */ 
/*     */           
/* 319 */           this.endOfStream = true;
/*     */           
/* 321 */           this.istream.close();
/*     */           
/* 323 */           if (this.numUnconvertedBytes != 0)
/*     */           {
/* 325 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 55);
/* 326 */             sQLException.fillInStackTrace();
/* 327 */             throw sQLException;
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 334 */           j = this.istream.read(this.convbuf, this.numUnconvertedBytes, i - this.numUnconvertedBytes);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 340 */         if (j == -1) {
/*     */ 
/*     */ 
/*     */           
/* 344 */           this.endOfStream = true;
/*     */           
/* 346 */           this.istream.close();
/*     */           
/* 348 */           if (this.numUnconvertedBytes != 0)
/*     */           {
/* 350 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 55);
/* 351 */             sQLException.fillInStackTrace();
/* 352 */             throw sQLException;
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 357 */           j += this.numUnconvertedBytes;
/* 358 */           this.totalSize += j;
/*     */         } 
/*     */         
/* 361 */         if (j <= 0)
/*     */         {
/* 363 */           return false;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 369 */         switch (this.conversion)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */           
/*     */           case 0:
/* 376 */             this.nbytes[0] = j;
/*     */             
/* 378 */             k = this.converter.CHARBytesToJavaChars(this.convbuf, 0, this.javaChars, 0, this.nbytes, this.javaChars.length);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 383 */             this.numUnconvertedBytes = this.nbytes[0];
/*     */             
/* 385 */             for (b = 0; b < this.numUnconvertedBytes; b++) {
/* 386 */               this.convbuf[b] = this.convbuf[j - this.numUnconvertedBytes];
/*     */             }
/*     */             
/* 389 */             this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, k, this.resizableBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 502 */             this.pos = 0;
/*     */ 
/*     */             
/* 505 */             return true;case 1: this.nbytes[0] = j; k = this.converter.CHARBytesToJavaChars(this.convbuf, 0, this.javaChars, 0, this.nbytes, this.javaChars.length); this.numUnconvertedBytes = this.nbytes[0]; for (b = 0; b < this.numUnconvertedBytes; b++) this.convbuf[b] = this.convbuf[j - this.numUnconvertedBytes];  this.count = DBConversion.javaCharsToUcs2Bytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 2: k = DBConversion.RAWBytesToHexChars(this.convbuf, j, this.javaChars); this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 3: k = DBConversion.RAWBytesToHexChars(this.convbuf, j, this.javaChars); this.count = DBConversion.javaCharsToUcs2Bytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 4: k = DBConversion.ucs2BytesToJavaChars(this.convbuf, j, this.javaChars); this.count = this.converter.javaCharsToCHARBytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 12: k = DBConversion.ucs2BytesToJavaChars(this.convbuf, j, this.javaChars); this.count = DBConversion.javaCharsToAsciiBytes(this.javaChars, k, this.resizableBuffer); this.pos = 0; return true;case 5: DBConversion.asciiBytesToJavaChars(this.convbuf, j, this.javaChars); this.count = this.converter.javaCharsToCHARBytes(this.javaChars, j, this.resizableBuffer); this.pos = 0; return true; }  System.arraycopy(this.convbuf, 0, this.resizableBuffer, 0, j); this.count = j; } catch (SQLException sQLException) { IOException iOException = DatabaseError.createIOException(sQLException); iOException.fillInStackTrace(); throw iOException; }  this.pos = 0; return true;
/*     */     } 
/*     */     
/* 508 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 523 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 528 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleConversionInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */