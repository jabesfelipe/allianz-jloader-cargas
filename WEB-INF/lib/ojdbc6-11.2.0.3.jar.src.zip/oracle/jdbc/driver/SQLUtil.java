/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.oracore.OracleNamedType;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ import oracle.jdbc.oracore.OracleTypeCOLLECTION;
/*      */ import oracle.jdbc.oracore.OracleTypeOPAQUE;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.ArrayDescriptor;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CharacterSet;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.OpaqueDescriptor;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLUtil
/*      */ {
/*      */   public static Object SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfbyte, int paramInt, String paramString, Class paramClass, Map paramMap) throws SQLException {
/*   87 */     Datum datum = makeDatum(paramOracleConnection, paramArrayOfbyte, paramInt, paramString, 0);
/*   88 */     return SQLToJava(paramOracleConnection, datum, paramClass, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CustomDatum SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfbyte, int paramInt, String paramString, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/*  128 */     Datum datum = makeDatum(paramOracleConnection, paramArrayOfbyte, paramInt, paramString, 0);
/*  129 */     return paramCustomDatumFactory.create(datum, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ORAData SQLToJava(OracleConnection paramOracleConnection, byte[] paramArrayOfbyte, int paramInt, String paramString, ORADataFactory paramORADataFactory) throws SQLException {
/*  169 */     Datum datum = makeDatum(paramOracleConnection, paramArrayOfbyte, paramInt, paramString, 0);
/*  170 */     return paramORADataFactory.create(datum, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object SQLToJava(OracleConnection paramOracleConnection, Datum paramDatum, Class paramClass, Map paramMap) throws SQLException {
/*  212 */     Object object = null;
/*      */     
/*  214 */     if (paramDatum instanceof STRUCT)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */       
/*  220 */       if (paramClass == null)
/*      */       {
/*  222 */         object = (paramMap != null) ? ((STRUCT)paramDatum).toJdbc(paramMap) : paramDatum.toJdbc();
/*      */       }
/*      */       else
/*      */       {
/*  226 */         object = (paramMap != null) ? ((STRUCT)paramDatum).toClass(paramClass, paramMap) : ((STRUCT)paramDatum).toClass(paramClass);
/*      */       }
/*      */        }
/*      */     
/*  230 */     else if (paramClass == null)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */       
/*  236 */       object = paramDatum.toJdbc();
/*      */       
/*      */        }
/*      */     
/*      */     else
/*      */     
/*      */     { 
/*      */       
/*  244 */       int i = classNumber(paramClass);
/*      */       
/*  246 */       switch (i)
/*      */       
/*      */       { 
/*      */         case 0:
/*  250 */           object = paramDatum.stringValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  318 */           return object;case 1: object = Boolean.valueOf((paramDatum.longValue() != 0L)); return object;case 2: object = Integer.valueOf((int)paramDatum.longValue()); return object;case 3: object = Long.valueOf(paramDatum.longValue()); return object;case 4: object = Float.valueOf(paramDatum.bigDecimalValue().floatValue()); return object;case 5: object = Double.valueOf(paramDatum.bigDecimalValue().doubleValue()); return object;case 6: object = paramDatum.bigDecimalValue(); return object;case 7: object = paramDatum.dateValue(); return object;case 8: object = paramDatum.timeValue(); return object;case 9: object = paramDatum.timestampValue(); return object; }  object = paramDatum.toJdbc(); if (!paramClass.isInstance(object)) { SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 59, "invalid data conversion"); sQLException.fillInStackTrace(); throw sQLException; }  }  return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] JavaToSQL(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString) throws SQLException {
/*      */     STRUCT sTRUCT;
/*      */     Datum datum1;
/*  356 */     if (paramObject == null)
/*      */     {
/*      */       
/*  359 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  367 */     Datum datum2 = null;
/*      */     
/*  369 */     if (paramObject instanceof Datum) {
/*      */       
/*  371 */       datum2 = (Datum)paramObject;
/*      */     }
/*  373 */     else if (paramObject instanceof ORAData) {
/*      */       
/*  375 */       datum2 = ((ORAData)paramObject).toDatum((Connection)paramOracleConnection);
/*      */     }
/*  377 */     else if (paramObject instanceof CustomDatum) {
/*      */       
/*  379 */       datum2 = paramOracleConnection.toDatum((CustomDatum)paramObject);
/*      */     }
/*  381 */     else if (paramObject instanceof java.sql.SQLData) {
/*      */       
/*  383 */       sTRUCT = STRUCT.toSTRUCT(paramObject, (OracleConnection)paramOracleConnection);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  390 */     if (sTRUCT != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  400 */       if (!checkDatumType((Datum)sTRUCT, paramInt, paramString))
/*      */       {
/*  402 */         sTRUCT = null;
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  415 */       datum1 = makeDatum(paramOracleConnection, paramObject, paramInt, paramString);
/*      */     } 
/*      */     
/*  418 */     byte[] arrayOfByte = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  423 */     if (datum1 != null) {
/*      */       
/*  425 */       if (datum1 instanceof STRUCT) {
/*  426 */         arrayOfByte = ((STRUCT)datum1).toBytes();
/*  427 */       } else if (datum1 instanceof ARRAY) {
/*  428 */         arrayOfByte = ((ARRAY)datum1).toBytes();
/*  429 */       } else if (datum1 instanceof OPAQUE) {
/*  430 */         arrayOfByte = ((OPAQUE)datum1).toBytes();
/*      */       } else {
/*  432 */         arrayOfByte = datum1.shareBytes();
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  438 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, "attempt to convert a Datum to incompatible SQL type");
/*  439 */       sQLException.fillInStackTrace();
/*  440 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  444 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, byte[] paramArrayOfbyte, int paramInt1, String paramString, int paramInt2) throws SQLException {
/*      */     NUMBER nUMBER;
/*      */     BINARY_FLOAT bINARY_FLOAT;
/*      */     BINARY_DOUBLE bINARY_DOUBLE;
/*      */     RAW rAW;
/*      */     ROWID rOWID;
/*      */     DATE dATE;
/*      */     INTERVALYM iNTERVALYM;
/*      */     INTERVALDS iNTERVALDS;
/*      */     TIMESTAMP tIMESTAMP;
/*      */     TIMESTAMPTZ tIMESTAMPTZ;
/*      */     TIMESTAMPLTZ tIMESTAMPLTZ;
/*      */     BLOB bLOB;
/*      */     CLOB cLOB;
/*      */     BFILE bFILE;
/*      */     STRUCT sTRUCT;
/*      */     ARRAY aRRAY;
/*      */     OPAQUE oPAQUE;
/*      */     REF rEF;
/*      */     SQLException sQLException;
/*      */     TypeDescriptor typeDescriptor;
/*  486 */     CHAR cHAR = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  501 */     short s1 = paramOracleConnection.getDbCsId();
/*  502 */     short s2 = paramOracleConnection.getJdbcCsId();
/*  503 */     int i = CharacterSetMetaData.getRatio(s2, s1);
/*      */     
/*  505 */     switch (paramInt1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 96:
/*  514 */         if (paramInt2 != 0 && paramInt2 < paramArrayOfbyte.length && i == 1) {
/*      */           
/*  516 */           cHAR = new CHAR(paramArrayOfbyte, 0, paramInt2, CharacterSet.make(paramOracleConnection.getJdbcCsId()));
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  521 */           cHAR = new CHAR(paramArrayOfbyte, CharacterSet.make(paramOracleConnection.getJdbcCsId()));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  687 */         return (Datum)cHAR;case 1: case 8: cHAR = new CHAR(paramArrayOfbyte, CharacterSet.make(paramOracleConnection.getJdbcCsId())); return (Datum)cHAR;case 2: case 6: return (Datum)new NUMBER(paramArrayOfbyte);case 100: return (Datum)new BINARY_FLOAT(paramArrayOfbyte);case 101: return (Datum)new BINARY_DOUBLE(paramArrayOfbyte);case 23: case 24: return (Datum)new RAW(paramArrayOfbyte);case 104: return (Datum)new ROWID(paramArrayOfbyte);case 102: sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, "need resolution: do we want to handle ResultSet?"); sQLException.fillInStackTrace(); throw sQLException;case 12: return (Datum)new DATE(paramArrayOfbyte);case 182: return (Datum)new INTERVALYM(paramArrayOfbyte);case 183: return (Datum)new INTERVALDS(paramArrayOfbyte);case 180: return (Datum)new TIMESTAMP(paramArrayOfbyte);case 181: return (Datum)new TIMESTAMPTZ(paramArrayOfbyte);case 231: return (Datum)new TIMESTAMPLTZ(paramArrayOfbyte);case 113: return (Datum)paramOracleConnection.createBlob(paramArrayOfbyte);case 112: return (Datum)paramOracleConnection.createClob(paramArrayOfbyte);case 114: return (Datum)paramOracleConnection.createBfile(paramArrayOfbyte);case 109: typeDescriptor = TypeDescriptor.getTypeDescriptor(paramString, (OracleConnection)paramOracleConnection, paramArrayOfbyte, 0L); switch (typeDescriptor.getTypeCode()) { case 2002: sTRUCT = new STRUCT((StructDescriptor)typeDescriptor, paramArrayOfbyte, (Connection)paramOracleConnection); break;case 2003: aRRAY = new ARRAY((ArrayDescriptor)typeDescriptor, paramArrayOfbyte, (Connection)paramOracleConnection); break;case 2009: oPAQUE = ClassRef.XMLTYPE.createXML(new OPAQUE((OpaqueDescriptor)typeDescriptor, paramArrayOfbyte, (Connection)paramOracleConnection)); break;case 2007: oPAQUE = new OPAQUE((OpaqueDescriptor)typeDescriptor, paramArrayOfbyte, (Connection)paramOracleConnection); break; }  return (Datum)oPAQUE;case 111: object = getTypeDescriptor(paramString, paramOracleConnection); if (object instanceof StructDescriptor) { rEF = new REF((StructDescriptor)object, (Connection)paramOracleConnection, paramArrayOfbyte); } else { SQLException sQLException1 = DatabaseError.createSqlException((OracleConnection)null, 1, "program error: REF points to a non-STRUCT"); sQLException1.fillInStackTrace(); throw sQLException1; }  return (Datum)rEF;
/*      */     } 
/*      */     Object object = DatabaseError.createSqlException((OracleConnection)null, 1, "program error: invalid SQL type code");
/*      */     object.fillInStackTrace();
/*      */     throw object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Datum makeNDatum(OracleConnection paramOracleConnection, byte[] paramArrayOfbyte, int paramInt1, String paramString, short paramShort, int paramInt2) throws SQLException {
/*      */     int i;
/*  703 */     CHAR cHAR = null;
/*      */     
/*  705 */     switch (paramInt1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 96:
/*  713 */         i = paramInt2 * CharacterSetMetaData.getRatio(paramOracleConnection.getNCharSet(), 1);
/*      */ 
/*      */ 
/*      */         
/*  717 */         if (paramInt2 != 0 && i < paramArrayOfbyte.length) {
/*  718 */           cHAR = new CHAR(paramArrayOfbyte, 0, paramInt2, CharacterSet.make(paramOracleConnection.getNCharSet()));
/*      */         } else {
/*      */           
/*  721 */           cHAR = new CHAR(paramArrayOfbyte, CharacterSet.make(paramOracleConnection.getNCharSet()));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  751 */         return (Datum)cHAR;case 1: case 8: cHAR = new CHAR(paramArrayOfbyte, CharacterSet.make(paramOracleConnection.getNCharSet())); return (Datum)cHAR;
/*      */       case 112:
/*      */         return (Datum)paramOracleConnection.createClob(paramArrayOfbyte, paramShort);
/*      */     } 
/*      */     SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, "program error: invalid SQL type code");
/*      */     sQLException.fillInStackTrace();
/*      */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString) throws SQLException {
/*  785 */     return makeDatum(paramOracleConnection, paramObject, paramInt, paramString, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Datum makeDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString, boolean paramBoolean) throws SQLException {
/*      */     NUMBER nUMBER;
/*      */     BINARY_FLOAT bINARY_FLOAT;
/*      */     BINARY_DOUBLE bINARY_DOUBLE;
/*      */     RAW rAW;
/*      */     DATE dATE;
/*      */     Datum datum;
/*      */     SQLException sQLException;
/*  799 */     CHAR cHAR = null;
/*      */     
/*  801 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 8:
/*      */       case 96:
/*  811 */         cHAR = new CHAR(paramObject, CharacterSet.make(paramBoolean ? paramOracleConnection.getNCharSet() : paramOracleConnection.getJdbcCsId()));
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 6:
/*  819 */         nUMBER = new NUMBER(paramObject);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 100:
/*  824 */         if (paramObject instanceof String) {
/*  825 */           BINARY_FLOAT bINARY_FLOAT1 = new BINARY_FLOAT((String)paramObject); break;
/*  826 */         }  if (paramObject instanceof Boolean) {
/*  827 */           BINARY_FLOAT bINARY_FLOAT1 = new BINARY_FLOAT((Boolean)paramObject); break;
/*      */         } 
/*  829 */         bINARY_FLOAT = new BINARY_FLOAT((Float)paramObject);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 101:
/*  834 */         if (paramObject instanceof String) {
/*  835 */           BINARY_DOUBLE bINARY_DOUBLE1 = new BINARY_DOUBLE((String)paramObject); break;
/*  836 */         }  if (paramObject instanceof Boolean) {
/*  837 */           BINARY_DOUBLE bINARY_DOUBLE1 = new BINARY_DOUBLE((Boolean)paramObject); break;
/*      */         } 
/*  839 */         bINARY_DOUBLE = new BINARY_DOUBLE((Double)paramObject);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*      */       case 24:
/*  846 */         rAW = new RAW(paramObject);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 104:
/*  851 */         if (paramObject instanceof String) {
/*  852 */           ROWID rOWID = new ROWID((String)paramObject); break;
/*  853 */         }  if (paramObject instanceof byte[]) {
/*  854 */           ROWID rOWID = new ROWID((byte[])paramObject);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  864 */         sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, "need resolution: do we want to handle ResultSet");
/*  865 */         sQLException.fillInStackTrace();
/*  866 */         throw sQLException;
/*      */ 
/*      */       
/*      */       case 12:
/*  870 */         dATE = new DATE(paramObject);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 180:
/*  875 */         if (paramObject instanceof TIMESTAMP) {
/*      */           
/*  877 */           datum = (Datum)paramObject; break;
/*      */         } 
/*  879 */         if (paramObject instanceof Timestamp) {
/*  880 */           TIMESTAMP tIMESTAMP = new TIMESTAMP((Timestamp)paramObject); break;
/*  881 */         }  if (paramObject instanceof Date) {
/*  882 */           TIMESTAMP tIMESTAMP = new TIMESTAMP((Date)paramObject); break;
/*  883 */         }  if (paramObject instanceof Time) {
/*  884 */           TIMESTAMP tIMESTAMP = new TIMESTAMP((Time)paramObject); break;
/*  885 */         }  if (paramObject instanceof DATE) {
/*  886 */           TIMESTAMP tIMESTAMP = new TIMESTAMP((DATE)paramObject); break;
/*  887 */         }  if (paramObject instanceof String) {
/*  888 */           TIMESTAMP tIMESTAMP = new TIMESTAMP((String)paramObject); break;
/*  889 */         }  if (paramObject instanceof byte[]) {
/*  890 */           TIMESTAMP tIMESTAMP = new TIMESTAMP((byte[])paramObject);
/*      */         }
/*      */         break;
/*      */       
/*      */       case 181:
/*  895 */         if (paramObject instanceof TIMESTAMPTZ) {
/*      */           
/*  897 */           datum = (Datum)paramObject; break;
/*      */         } 
/*  899 */         if (paramObject instanceof Timestamp) {
/*  900 */           TIMESTAMPTZ tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (Timestamp)paramObject); break;
/*  901 */         }  if (paramObject instanceof Date) {
/*  902 */           TIMESTAMPTZ tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (Date)paramObject); break;
/*  903 */         }  if (paramObject instanceof Time) {
/*  904 */           TIMESTAMPTZ tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (Time)paramObject); break;
/*  905 */         }  if (paramObject instanceof DATE) {
/*  906 */           TIMESTAMPTZ tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (DATE)paramObject); break;
/*  907 */         }  if (paramObject instanceof String) {
/*  908 */           TIMESTAMPTZ tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (String)paramObject); break;
/*  909 */         }  if (paramObject instanceof byte[]) {
/*  910 */           TIMESTAMPTZ tIMESTAMPTZ = new TIMESTAMPTZ((byte[])paramObject);
/*      */         }
/*      */         break;
/*      */       
/*      */       case 231:
/*  915 */         if (paramObject instanceof TIMESTAMPLTZ) {
/*      */           
/*  917 */           datum = (Datum)paramObject; break;
/*      */         } 
/*  919 */         if (paramObject instanceof Timestamp) {
/*  920 */           TIMESTAMPLTZ tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (Timestamp)paramObject); break;
/*  921 */         }  if (paramObject instanceof Date) {
/*  922 */           TIMESTAMPLTZ tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (Date)paramObject); break;
/*  923 */         }  if (paramObject instanceof Time) {
/*  924 */           TIMESTAMPLTZ tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (Time)paramObject); break;
/*  925 */         }  if (paramObject instanceof DATE) {
/*  926 */           TIMESTAMPLTZ tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (DATE)paramObject); break;
/*  927 */         }  if (paramObject instanceof String) {
/*  928 */           TIMESTAMPLTZ tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (String)paramObject); break;
/*  929 */         }  if (paramObject instanceof byte[]) {
/*  930 */           TIMESTAMPLTZ tIMESTAMPLTZ = new TIMESTAMPLTZ((byte[])paramObject);
/*      */         }
/*      */         break;
/*      */       
/*      */       case 113:
/*  935 */         if (paramObject instanceof BLOB)
/*      */         {
/*  937 */           datum = (Datum)paramObject;
/*      */         }
/*  939 */         if (paramObject instanceof byte[])
/*      */         {
/*  941 */           RAW rAW1 = new RAW((byte[])paramObject);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 112:
/*  947 */         if (paramObject instanceof CLOB)
/*      */         {
/*  949 */           datum = (Datum)paramObject;
/*      */         }
/*      */         
/*  952 */         if (paramObject instanceof String) {
/*      */           
/*  954 */           CharacterSet characterSet = CharacterSet.make(paramBoolean ? paramOracleConnection.getNCharSet() : paramOracleConnection.getJdbcCsId());
/*  955 */           CHAR cHAR1 = new CHAR((String)paramObject, characterSet);
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 114:
/*  961 */         if (paramObject instanceof BFILE)
/*      */         {
/*  963 */           datum = (Datum)paramObject;
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 109:
/*  969 */         if (paramObject instanceof STRUCT || paramObject instanceof ARRAY || paramObject instanceof OPAQUE)
/*      */         {
/*      */           
/*  972 */           datum = (Datum)paramObject;
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  978 */         if (paramObject instanceof REF)
/*      */         {
/*  980 */           datum = (Datum)paramObject;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  989 */     if (datum == null) {
/*      */ 
/*      */ 
/*      */       
/*  993 */       sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, "Unable to construct a Datum from the specified input");
/*  994 */       sQLException.fillInStackTrace();
/*  995 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  999 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int classNumber(Class paramClass) {
/* 1016 */     int i = -1;
/* 1017 */     Integer integer = (Integer)classTable.get(paramClass);
/*      */     
/* 1019 */     if (integer != null)
/*      */     {
/* 1021 */       i = integer.intValue();
/*      */     }
/*      */     
/* 1024 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getTypeDescriptor(String paramString, OracleConnection paramOracleConnection) throws SQLException {
/* 1058 */     Object object = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1063 */     SQLName sQLName = new SQLName(paramString, (OracleConnection)paramOracleConnection);
/* 1064 */     String str = sQLName.getName();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1069 */     object = paramOracleConnection.getDescriptor(str);
/*      */     
/* 1071 */     if (object != null)
/*      */     {
/*      */       
/* 1074 */       return object;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1080 */     OracleTypeADT oracleTypeADT = new OracleTypeADT(str, (Connection)paramOracleConnection);
/* 1081 */     oracleTypeADT.init(paramOracleConnection);
/*      */     
/* 1083 */     OracleNamedType oracleNamedType = oracleTypeADT.cleanup();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1088 */     switch (oracleNamedType.getTypeCode()) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 2003:
/* 1093 */         object = new ArrayDescriptor(sQLName, (OracleTypeCOLLECTION)oracleNamedType, (Connection)paramOracleConnection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1129 */         paramOracleConnection.putDescriptor(str, object);
/*      */         
/* 1131 */         return object;case 2002: case 2008: object = new StructDescriptor(sQLName, (OracleTypeADT)oracleNamedType, (Connection)paramOracleConnection); paramOracleConnection.putDescriptor(str, object); return object;case 2007: object = new OpaqueDescriptor(sQLName, (OracleTypeOPAQUE)oracleNamedType, (Connection)paramOracleConnection); paramOracleConnection.putDescriptor(str, object); return object;
/*      */     } 
/*      */     SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 1, "Unrecognized type code");
/*      */     sQLException.fillInStackTrace();
/*      */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean checkDatumType(Datum paramDatum, int paramInt, String paramString) throws SQLException {
/* 1161 */     boolean bool = false;
/*      */     
/* 1163 */     switch (paramInt)
/*      */     
/*      */     { 
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 8:
/*      */       case 96:
/* 1171 */         bool = paramDatum instanceof CHAR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1267 */         return bool;case 2: case 6: bool = paramDatum instanceof NUMBER; return bool;case 100: bool = paramDatum instanceof BINARY_FLOAT; return bool;case 101: bool = paramDatum instanceof BINARY_DOUBLE; return bool;case 23: case 24: bool = paramDatum instanceof RAW; return bool;case 104: bool = paramDatum instanceof ROWID; return bool;case 12: bool = paramDatum instanceof DATE; return bool;case 180: bool = paramDatum instanceof TIMESTAMP; return bool;case 181: bool = paramDatum instanceof TIMESTAMPTZ; return bool;case 231: bool = paramDatum instanceof TIMESTAMPLTZ; return bool;case 113: bool = paramDatum instanceof BLOB; return bool;case 112: bool = paramDatum instanceof CLOB; return bool;case 114: bool = paramDatum instanceof BFILE; return bool;case 111: bool = (paramDatum instanceof REF && ((REF)paramDatum).getBaseTypeName().equals(paramString)); return bool;case 109: if (paramDatum instanceof STRUCT) { bool = ((STRUCT)paramDatum).isInHierarchyOf(paramString); } else if (paramDatum instanceof ARRAY) { bool = ((ARRAY)paramDatum).getSQLTypeName().equals(paramString); } else if (paramDatum instanceof OPAQUE) { bool = ((OPAQUE)paramDatum).getSQLTypeName().equals(paramString); }  return bool; }  bool = false; return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean implementsInterface(Class paramClass1, Class paramClass2) {
/* 1287 */     if (paramClass1 == null)
/*      */     {
/* 1289 */       return false;
/*      */     }
/*      */     
/* 1292 */     if (paramClass1 == paramClass2)
/*      */     {
/* 1294 */       return true;
/*      */     }
/*      */     
/* 1297 */     Class[] arrayOfClass = paramClass1.getInterfaces();
/*      */     
/* 1299 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/*      */       
/* 1301 */       if (implementsInterface(arrayOfClass[b], paramClass2))
/*      */       {
/* 1303 */         return true;
/*      */       }
/*      */     } 
/*      */     
/* 1307 */     return implementsInterface(paramClass1.getSuperclass(), paramClass2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Datum makeOracleDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString) throws SQLException {
/* 1338 */     return makeOracleDatum(paramOracleConnection, paramObject, paramInt, paramString, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Datum makeOracleDatum(OracleConnection paramOracleConnection, Object paramObject, int paramInt, String paramString, boolean paramBoolean) throws SQLException {
/* 1353 */     return makeDatum(paramOracleConnection, paramObject, getInternalType(paramInt), paramString, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getInternalType(int paramInt) throws SQLException {
/* 1364 */     char c = Character.MIN_VALUE;
/*      */     
/* 1366 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -7:
/*      */       case -6:
/*      */       case -5:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/* 1388 */         c = '\006';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1542 */         return c;case 100: c = 'd'; return c;case 101: c = 'e'; return c;case 999: c = 'ϧ'; return c;case 1: c = '`'; return c;case -15: c = '`'; return c;case 12: c = '\001'; return c;case -9: c = '\001'; return c;case -1: c = '\b'; return c;case 91: case 92: c = '\f'; return c;case -100: case 93: c = '´'; return c;case -101: c = 'µ'; return c;case -102: c = 'ç'; return c;case -104: c = '·'; return c;case -103: c = '¶'; return c;case -3: case -2: c = '\027'; return c;case -4: c = '\030'; return c;case -8: c = 'h'; return c;case 2004: c = 'q'; return c;case 2005: c = 'p'; return c;case 2011: c = 'p'; return c;case -13: c = 'r'; return c;case -10: c = 'f'; return c;case 2002: case 2003: case 2007: case 2008: c = 'm'; return c;case 2006: c = 'o'; return c;
/*      */     } 
/*      */     SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 4, "get_internal_type");
/*      */     sQLException.fillInStackTrace();
/*      */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1557 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1737 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   private static final int CLASS_NOT_FOUND = -1;
/*      */   
/*      */   private static final int CLASS_STRING = 0;
/*      */   
/*      */   private static final int CLASS_BOOLEAN = 1;
/*      */   
/*      */   private static final int CLASS_INTEGER = 2;
/*      */   
/*      */   private static final int CLASS_LONG = 3;
/*      */   
/*      */   private static final int CLASS_FLOAT = 4;
/*      */   private static final int CLASS_DOUBLE = 5;
/*      */   private static final int CLASS_BIGDECIMAL = 6;
/*      */   private static final int CLASS_DATE = 7;
/*      */   private static final int CLASS_TIME = 8;
/*      */   private static final int CLASS_TIMESTAMP = 9;
/*      */   private static final int TOTAL_CLASSES = 10;
/* 1760 */   private static Hashtable classTable = new Hashtable<Object, Object>(10);
/*      */   
/*      */   static {
/*      */     try {
/* 1764 */       classTable.put(Class.forName("java.lang.String"), Integer.valueOf(0));
/*      */       
/* 1766 */       classTable.put(Class.forName("java.lang.Boolean"), Integer.valueOf(1));
/*      */       
/* 1768 */       classTable.put(Class.forName("java.lang.Integer"), Integer.valueOf(2));
/*      */       
/* 1770 */       classTable.put(Class.forName("java.lang.Long"), Integer.valueOf(3));
/* 1771 */       classTable.put(Class.forName("java.lang.Float"), Integer.valueOf(4));
/*      */       
/* 1773 */       classTable.put(Class.forName("java.lang.Double"), Integer.valueOf(5));
/*      */       
/* 1775 */       classTable.put(Class.forName("java.math.BigDecimal"), Integer.valueOf(6));
/*      */       
/* 1777 */       classTable.put(Class.forName("java.sql.Date"), Integer.valueOf(7));
/* 1778 */       classTable.put(Class.forName("java.sql.Time"), Integer.valueOf(8));
/* 1779 */       classTable.put(Class.forName("java.sql.Timestamp"), Integer.valueOf(9));
/*      */     
/*      */     }
/* 1782 */     catch (ClassNotFoundException classNotFoundException) {}
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\SQLUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */