/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4C8TTILobd
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   static final int LOBD_STATE0 = 0;
/*     */   static final int LOBD_STATE1 = 1;
/*     */   static final int LOBD_STATE2 = 2;
/*     */   static final int LOBD_STATE3 = 3;
/*     */   static final int LOBD_STATE_EXIT = 4;
/*     */   static final short TTCG_LNG = 254;
/*     */   static final short LOBDATALENGTH = 252;
/* 127 */   static byte[] ucs2Char = new byte[2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4C8TTILobd(T4CConnection paramT4CConnection) {
/* 140 */     super(paramT4CConnection, (byte)14);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshalLobData(byte[] paramArrayOfbyte, long paramLong1, long paramLong2, boolean paramBoolean) throws IOException {
/* 178 */     long l = paramLong2;
/*     */ 
/*     */     
/* 181 */     marshalTTCcode();
/* 182 */     if (paramBoolean) {
/*     */       
/* 184 */       this.meg.outStream.flush();
/* 185 */       this.meg.outStream.writeZeroCopyIO(paramArrayOfbyte, (int)paramLong1, (int)paramLong2);
/*     */     }
/*     */     else {
/*     */       
/* 189 */       boolean bool = false;
/*     */       
/* 191 */       if (l > 252L) {
/*     */         
/* 193 */         bool = true;
/*     */         
/* 195 */         this.meg.marshalUB1((short)254);
/*     */       } 
/*     */ 
/*     */       
/* 199 */       long l1 = 0L;
/*     */       
/* 201 */       for (; l > 252L; l1++, l -= 252L) {
/*     */         
/* 203 */         this.meg.marshalUB1((short)252);
/* 204 */         this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l1 * 252L), 252);
/*     */       } 
/*     */ 
/*     */       
/* 208 */       if (l > 0L) {
/*     */         
/* 210 */         this.meg.marshalUB1((short)(int)l);
/* 211 */         this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l1 * 252L), (int)l);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 216 */       if (bool == true) {
/* 217 */         this.meg.marshalUB1((short)0);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshalClobUB2_For9iDB(byte[] paramArrayOfbyte, long paramLong1, long paramLong2) throws IOException {
/* 232 */     long l1 = paramLong2;
/* 233 */     boolean bool = false;
/*     */     
/* 235 */     marshalTTCcode();
/*     */ 
/*     */     
/* 238 */     if (l1 > 84L) {
/*     */       
/* 240 */       bool = true;
/*     */       
/* 242 */       this.meg.marshalUB1((short)254);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     long l2 = 0L;
/*     */     
/* 250 */     for (; l1 > 84L; l2++, l1 -= 84L) {
/*     */ 
/*     */ 
/*     */       
/* 254 */       this.meg.marshalUB1((short)252);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 259 */       for (byte b = 0; b < 84; b++) {
/*     */ 
/*     */ 
/*     */         
/* 263 */         this.meg.marshalUB1((short)2);
/*     */ 
/*     */         
/* 266 */         this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l2 * 168L + (b * 2)), 2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 272 */     if (l1 > 0L) {
/*     */ 
/*     */ 
/*     */       
/* 276 */       long l = l1 * 3L;
/*     */       
/* 278 */       this.meg.marshalUB1((short)(int)l);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 283 */       for (byte b = 0; b < l1; b++) {
/*     */ 
/*     */ 
/*     */         
/* 287 */         this.meg.marshalUB1((short)2);
/*     */ 
/*     */         
/* 290 */         this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l2 * 168L + (b * 2)), 2);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     if (bool == true) {
/* 298 */       this.meg.marshalUB1((short)0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long unmarshalLobData(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) throws SQLException, IOException {
/* 361 */     int i = 0;
/* 362 */     if (paramBoolean) {
/*     */       
/* 364 */       int j = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 369 */       int[] arrayOfInt = new int[1];
/*     */ 
/*     */       
/* 372 */       boolean bool = false;
/* 373 */       while (!bool) {
/*     */         
/* 375 */         bool = this.meg.inStream.readZeroCopyIO(paramArrayOfbyte, paramInt + j, arrayOfInt);
/*     */ 
/*     */ 
/*     */         
/* 379 */         j += arrayOfInt[0];
/*     */       } 
/* 381 */       i = j;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 386 */       int j = paramInt;
/* 387 */       short s = 0;
/*     */ 
/*     */       
/* 390 */       byte b = 0;
/*     */ 
/*     */       
/* 393 */       while (b != 4) {
/*     */         
/* 395 */         switch (b) {
/*     */ 
/*     */ 
/*     */           
/*     */           case false:
/* 400 */             s = this.meg.unmarshalUB1();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 405 */             if (s == 254) {
/* 406 */               b = 2;
/*     */ 
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 412 */             b = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case true:
/* 424 */             if (paramArrayOfbyte.length >= j + s) {
/*     */               
/* 426 */               this.meg.getNBytes(paramArrayOfbyte, j, s);
/*     */             }
/*     */             else {
/*     */               
/* 430 */               byte[] arrayOfByte = new byte[s];
/* 431 */               this.meg.getNBytes(arrayOfByte, 0, s);
/* 432 */               int k = Math.min(paramArrayOfbyte.length - j, s);
/* 433 */               System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, j, k);
/*     */             } 
/*     */             
/* 436 */             i += s;
/* 437 */             b = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case true:
/* 448 */             s = this.meg.unmarshalUB1();
/*     */ 
/*     */             
/* 451 */             if (s > 0) {
/* 452 */               b = 3;
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 457 */             b = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case true:
/* 473 */             if (paramArrayOfbyte.length >= j + s) {
/*     */ 
/*     */               
/* 476 */               this.meg.getNBytes(paramArrayOfbyte, j, s);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             }
/*     */             else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 491 */               byte[] arrayOfByte = new byte[s];
/* 492 */               this.meg.getNBytes(arrayOfByte, 0, s);
/* 493 */               int k = Math.min(paramArrayOfbyte.length - j, s);
/* 494 */               System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, j, k);
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 499 */             i += s;
/*     */ 
/*     */             
/* 502 */             j += s;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 507 */             b = 2;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 523 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long unmarshalClobUB2_For9iDB(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 557 */     long l1 = 0L;
/* 558 */     long l2 = paramInt;
/* 559 */     short s = 0;
/* 560 */     int i = 0;
/* 561 */     int j = 0;
/*     */ 
/*     */     
/* 564 */     byte b = 0;
/*     */ 
/*     */     
/* 567 */     while (b != 4) {
/*     */       
/* 569 */       switch (b) {
/*     */ 
/*     */ 
/*     */         
/*     */         case false:
/* 574 */           s = this.meg.unmarshalUB1();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 579 */           if (s == 254) {
/* 580 */             b = 2;
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 586 */           b = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 596 */           for (i = 0; i < s; i += j, l2 += 2L, l1 += 2L)
/*     */           {
/* 598 */             j = this.meg.unmarshalUCS2(paramArrayOfbyte, l2);
/*     */           }
/*     */           
/* 601 */           b = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 612 */           s = this.meg.unmarshalUB1();
/*     */ 
/*     */           
/* 615 */           if (s > 0) {
/* 616 */             b = 3;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 621 */           b = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 633 */           for (i = 0; i < s; i += j, l2 += 2L, l1 += 2L)
/*     */           {
/* 635 */             j = this.meg.unmarshalUCS2(paramArrayOfbyte, l2);
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 642 */           b = 2;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 655 */     return l1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 660 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4C8TTILobd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */