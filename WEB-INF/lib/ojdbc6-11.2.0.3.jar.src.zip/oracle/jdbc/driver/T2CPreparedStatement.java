/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.ShortBuffer;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.oracore.OracleType;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T2CPreparedStatement
/*      */   extends OraclePreparedStatement
/*      */ {
/*   40 */   T2CConnection connection = null;
/*   41 */   int userResultSetType = -1;
/*   42 */   int userResultSetConcur = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   48 */   static int T2C_EXTEND_BUFFER = -3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   63 */   long[] t2cOutput = new long[10];
/*      */ 
/*      */ 
/*      */   
/*      */   static final int T2C_OUTPUT_USE_NIO = 5;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int T2C_OUTPUT_STMT_LOB_PREFETCH_SIZE = 6;
/*      */ 
/*      */ 
/*      */   
/*      */   int extractedCharOffset;
/*      */ 
/*      */ 
/*      */   
/*      */   int extractedByteOffset;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_SIZE_THIS_COLUMN_OFFSET = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_LOB_LENGTH_OFFSET = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_FORM_OFFSET = 2;
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_CHUNK_OFFSET = 3;
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_DATA_OFFSET = 4;
/*      */ 
/*      */ 
/*      */   
/*      */   T2CPreparedStatement(T2CConnection paramT2CConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  102 */     super(paramT2CConnection, paramString, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */ 
/*      */     
/*  105 */     this.userResultSetType = paramInt3;
/*  106 */     this.userResultSetConcur = paramInt4;
/*      */ 
/*      */     
/*  109 */     this.connection = paramT2CConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String bytes2String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  125 */     byte[] arrayOfByte = new byte[paramInt2];
/*      */     
/*  127 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*      */     
/*  129 */     return this.connection.conversion.CharBytesToString(arrayOfByte, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processDescribeData() throws SQLException {
/*  145 */     this.described = true;
/*  146 */     this.describedWithNames = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  157 */     if (this.accessors == null || this.numberOfDefinePositions > this.accessors.length) {
/*  158 */       this.accessors = new Accessor[this.numberOfDefinePositions];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  174 */     int i = this.connection.queryMetaData1Offset;
/*  175 */     int j = this.connection.queryMetaData2Offset;
/*  176 */     short[] arrayOfShort = this.connection.queryMetaData1;
/*  177 */     byte[] arrayOfByte = this.connection.queryMetaData2;
/*      */     
/*  179 */     for (byte b = 0; b < this.numberOfDefinePositions; 
/*  180 */       b++, i += 13) {
/*      */       
/*  182 */       short s1 = arrayOfShort[i + 0];
/*  183 */       short s2 = arrayOfShort[i + 1];
/*  184 */       short s3 = arrayOfShort[i + 11];
/*  185 */       boolean bool1 = (arrayOfShort[i + 2] != 0) ? true : false;
/*  186 */       short s4 = arrayOfShort[i + 3];
/*  187 */       short s5 = arrayOfShort[i + 4];
/*  188 */       boolean bool2 = false;
/*  189 */       boolean bool3 = false;
/*  190 */       boolean bool4 = false;
/*  191 */       short s6 = arrayOfShort[i + 5];
/*  192 */       short s7 = arrayOfShort[i + 6];
/*  193 */       String str1 = bytes2String(arrayOfByte, j, s7);
/*  194 */       short s8 = arrayOfShort[i + 12];
/*  195 */       String str2 = null;
/*  196 */       OracleTypeADT oracleTypeADT = null;
/*      */       
/*  198 */       j += s7;
/*      */       
/*  200 */       if (s8 > 0) {
/*      */         
/*  202 */         str2 = bytes2String(arrayOfByte, j, s8);
/*  203 */         j += s8;
/*  204 */         oracleTypeADT = new OracleTypeADT(str2, (Connection)this.connection);
/*  205 */         oracleTypeADT.tdoCState = (arrayOfShort[i + 7] & 0xFFFFL) << 48L | (arrayOfShort[i + 8] & 0xFFFFL) << 32L | (arrayOfShort[i + 9] & 0xFFFFL) << 16L | arrayOfShort[i + 10] & 0xFFFFL;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  213 */       Accessor accessor = this.accessors[b];
/*      */       
/*  215 */       if (accessor != null && !accessor.useForDescribeIfPossible(s1, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2))
/*      */       {
/*      */ 
/*      */         
/*  219 */         accessor = null;
/*      */       }
/*      */       
/*  222 */       if (accessor == null) {
/*      */         SQLException sQLException;
/*  224 */         switch (s1) {
/*      */ 
/*      */           
/*      */           case 1:
/*  228 */             accessor = new VarcharAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */             
/*  232 */             if (s3 > 0) {
/*  233 */               accessor.setDisplaySize(s3);
/*      */             }
/*      */             break;
/*      */           
/*      */           case 96:
/*  238 */             accessor = new CharAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */             
/*  242 */             if (s3 > 0) {
/*  243 */               accessor.setDisplaySize(s3);
/*      */             }
/*      */             break;
/*      */           
/*      */           case 2:
/*  248 */             accessor = new NumberAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 23:
/*  255 */             accessor = new RawAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 100:
/*  262 */             accessor = new BinaryFloatAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 101:
/*  269 */             accessor = new BinaryDoubleAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/*  276 */             accessor = new LongAccessor(this, b + 1, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  283 */             this.rowPrefetch = 1;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 24:
/*  288 */             accessor = new LongRawAccessor(this, b + 1, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  295 */             this.rowPrefetch = 1;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 104:
/*  300 */             accessor = new RowidAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 102:
/*      */           case 116:
/*  309 */             accessor = new T2CResultSetAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 12:
/*  316 */             accessor = new DateAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 180:
/*  323 */             accessor = new TimestampAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 181:
/*  330 */             accessor = new TimestamptzAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 231:
/*  337 */             accessor = new TimestampltzAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 182:
/*  344 */             accessor = new IntervalymAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 183:
/*  351 */             accessor = new IntervaldsAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 112:
/*  358 */             accessor = new ClobAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 113:
/*  365 */             accessor = new BlobAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 114:
/*  372 */             accessor = new BfileAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 109:
/*  379 */             accessor = new NamedTypeAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2, (OracleType)oracleTypeADT);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 111:
/*  387 */             accessor = new RefTypeAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2, (OracleType)oracleTypeADT);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  396 */             sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unknown or unimplemented accessor type: " + s1);
/*      */             
/*  398 */             sQLException.fillInStackTrace();
/*  399 */             throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  404 */         this.accessors[b] = accessor;
/*      */       }
/*  406 */       else if (oracleTypeADT != null) {
/*      */ 
/*      */ 
/*      */         
/*  410 */         accessor.describeOtype = (OracleType)oracleTypeADT;
/*  411 */         accessor.initMetadata();
/*      */       } 
/*      */       
/*  414 */       accessor.columnName = str1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*      */     boolean bool3;
/*  455 */     this.t2cOutput[0] = 0L;
/*  456 */     this.t2cOutput[2] = 0L;
/*      */ 
/*      */ 
/*      */     
/*  460 */     this.lobPrefetchMetaData = null;
/*      */     
/*  462 */     boolean bool1 = !this.described ? true : false;
/*  463 */     boolean bool2 = false;
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/*  468 */       bool3 = false;
/*      */ 
/*      */       
/*  471 */       if (this.connection.endToEndAnyChanged) {
/*      */         
/*  473 */         pushEndToEndValues();
/*      */         
/*  475 */         this.connection.endToEndAnyChanged = false;
/*      */       } 
/*      */ 
/*      */       
/*  479 */       byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
/*      */       
/*  481 */       int i = 0;
/*      */       
/*      */       try {
/*  484 */         i = T2CStatement.t2cParseExecuteDescribe(this, this.c_state, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, false, this.needToParse, bool1, bool2, arrayOfByte, arrayOfByte.length, T2CStatement.convertSqlKindEnumToByte(this.sqlKind), this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, this.ibtBindIndicators, this.ibtBindIndicatorOffset, this.ibtBindIndicatorSize, this.ibtBindBytes, this.ibtBindChars, this.ibtBindByteOffset, this.ibtBindCharOffset, this.returnParamMeta, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, this.preparedAllBinds, this.preparedCharBinds, this.accessors, this.parameterDatum, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.connection.plsqlCompilerWarnings);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  531 */       catch (IOException iOException) {
/*      */ 
/*      */         
/*  534 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
/*  535 */         sQLException.fillInStackTrace();
/*  536 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  541 */       this.validRows = (int)this.t2cOutput[1];
/*      */ 
/*      */       
/*  544 */       if (i == -1 || i == -4) {
/*      */         
/*  546 */         this.connection.checkError(i);
/*      */       }
/*  548 */       else if (i == T2C_EXTEND_BUFFER) {
/*      */         
/*  550 */         i = this.connection.queryMetaData1Size * 2;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  555 */       if (this.t2cOutput[3] != 0L) {
/*      */         
/*  557 */         foundPlsqlCompilerWarning();
/*      */       }
/*  559 */       else if (this.t2cOutput[2] != 0L) {
/*      */         
/*  561 */         this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  566 */       this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4];
/*      */ 
/*      */       
/*  569 */       this.needToParse = false;
/*  570 */       bool2 = true;
/*      */       
/*  572 */       if (this.sqlKind.isSELECT())
/*      */       {
/*  574 */         this.numberOfDefinePositions = i;
/*      */         
/*  576 */         if (this.numberOfDefinePositions > this.connection.queryMetaData1Size)
/*      */         {
/*  578 */           bool3 = true;
/*  579 */           bool2 = true;
/*      */ 
/*      */           
/*  582 */           this.connection.reallocateQueryMetaData(this.numberOfDefinePositions, this.numberOfDefinePositions * 8);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*  589 */         this.numberOfDefinePositions = 0;
/*  590 */         this.validRows = i;
/*      */       }
/*      */     
/*  593 */     } while (bool3);
/*      */     
/*  595 */     processDescribeData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void pushEndToEndValues() throws SQLException {
/*  602 */     T2CConnection t2CConnection = this.connection;
/*  603 */     byte[] arrayOfByte1 = new byte[0];
/*  604 */     byte[] arrayOfByte2 = new byte[0];
/*  605 */     byte[] arrayOfByte3 = new byte[0];
/*  606 */     byte[] arrayOfByte4 = new byte[0];
/*      */     
/*  608 */     if (t2CConnection.endToEndValues != null) {
/*      */       
/*  610 */       if (t2CConnection.endToEndHasChanged[0]) {
/*      */         
/*  612 */         String str = t2CConnection.endToEndValues[0];
/*      */         
/*  614 */         if (str != null) {
/*  615 */           arrayOfByte1 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  618 */         t2CConnection.endToEndHasChanged[0] = false;
/*      */       } 
/*      */       
/*  621 */       if (t2CConnection.endToEndHasChanged[1]) {
/*      */         
/*  623 */         String str = t2CConnection.endToEndValues[1];
/*      */         
/*  625 */         if (str != null) {
/*  626 */           arrayOfByte2 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  629 */         t2CConnection.endToEndHasChanged[1] = false;
/*      */       } 
/*      */       
/*  632 */       if (t2CConnection.endToEndHasChanged[2]) {
/*      */         
/*  634 */         String str = t2CConnection.endToEndValues[2];
/*      */         
/*  636 */         if (str != null) {
/*  637 */           arrayOfByte3 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  640 */         t2CConnection.endToEndHasChanged[2] = false;
/*      */       } 
/*      */       
/*  643 */       if (t2CConnection.endToEndHasChanged[3]) {
/*      */         
/*  645 */         String str = t2CConnection.endToEndValues[3];
/*      */         
/*  647 */         if (str != null) {
/*  648 */           arrayOfByte4 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  651 */         t2CConnection.endToEndHasChanged[3] = false;
/*      */       } 
/*      */       
/*  654 */       T2CStatement.t2cEndToEndUpdate(this.c_state, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, t2CConnection.endToEndECIDSequenceNumber);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*  707 */     if (this.connection.endToEndAnyChanged) {
/*      */       
/*  709 */       pushEndToEndValues();
/*      */       
/*  711 */       this.connection.endToEndAnyChanged = false;
/*      */     } 
/*      */ 
/*      */     
/*  715 */     if (!paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  723 */       if (this.numberOfDefinePositions > 0)
/*      */       {
/*  725 */         doDefineExecuteFetch();
/*      */       }
/*      */       else
/*      */       {
/*  729 */         executeForDescribe();
/*      */       }
/*      */     
/*  732 */     } else if (this.numberOfDefinePositions > 0) {
/*  733 */       doDefineFetch();
/*      */     } 
/*      */ 
/*      */     
/*  737 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setupForDefine() throws SQLException {
/*  747 */     if (this.numberOfDefinePositions > this.connection.queryMetaData1Size) {
/*      */       
/*  749 */       int j = this.numberOfDefinePositions / 100 + 1;
/*      */       
/*  751 */       this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * j, this.connection.queryMetaData2Size * j * 8);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  756 */     short[] arrayOfShort = this.connection.queryMetaData1;
/*  757 */     int i = this.connection.queryMetaData1Offset;
/*      */ 
/*      */     
/*  760 */     for (byte b = 0; b < this.numberOfDefinePositions; 
/*  761 */       b++, i += 13) {
/*      */       
/*  763 */       Accessor accessor = this.accessors[b];
/*      */       
/*  765 */       if (accessor == null) {
/*      */         
/*  767 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  768 */         sQLException.fillInStackTrace();
/*  769 */         throw sQLException;
/*      */       } 
/*      */       
/*  772 */       arrayOfShort[i + 0] = (short)accessor.defineType;
/*      */       
/*  774 */       arrayOfShort[i + 11] = (short)accessor.charLength;
/*      */       
/*  776 */       arrayOfShort[i + 1] = (short)accessor.byteLength;
/*      */       
/*  778 */       arrayOfShort[i + 5] = accessor.formOfUse;
/*      */ 
/*      */       
/*  781 */       if (accessor.internalOtype != null) {
/*      */         
/*  783 */         long l = ((OracleTypeADT)accessor.internalOtype).getTdoCState();
/*      */ 
/*      */         
/*  786 */         arrayOfShort[i + 7] = (short)(int)((l & 0xFFFF000000000000L) >> 48L);
/*      */         
/*  788 */         arrayOfShort[i + 8] = (short)(int)((l & 0xFFFF00000000L) >> 32L);
/*      */         
/*  790 */         arrayOfShort[i + 9] = (short)(int)((l & 0xFFFF0000L) >> 16L);
/*      */         
/*  792 */         arrayOfShort[i + 10] = (short)(int)(l & 0xFFFFL);
/*      */       } 
/*      */ 
/*      */       
/*  796 */       switch (accessor.internalType) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 112:
/*      */         case 113:
/*  802 */           if (accessor.lobPrefetchSizeForThisColumn == -1) {
/*  803 */             accessor.lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/*      */           }
/*      */           
/*  806 */           arrayOfShort[i + 7] = (short)accessor.lobPrefetchSizeForThisColumn;
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object[] getLobPrefetchMetaData() {
/*  826 */     Object[] arrayOfObject = null;
/*  827 */     Object object = null;
/*  828 */     int[] arrayOfInt = null;
/*  829 */     byte b1 = 0;
/*  830 */     byte b2 = 0;
/*      */     
/*  832 */     if (this.accessors != null) {
/*  833 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */         
/*  835 */         switch ((this.accessors[b]).internalType) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 24:
/*  842 */             b2 = b;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 112:
/*      */           case 113:
/*  849 */             if (arrayOfInt == null)
/*      */             {
/*  851 */               arrayOfInt = new int[this.accessors.length];
/*      */             }
/*      */             
/*  854 */             if ((this.accessors[b]).lobPrefetchSizeForThisColumn != -1) {
/*      */               
/*  856 */               b1++;
/*      */               
/*  858 */               arrayOfInt[b] = (this.accessors[b]).lobPrefetchSizeForThisColumn;
/*      */               
/*      */               break;
/*      */             } 
/*  862 */             arrayOfInt[b] = -1;
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/*      */     }
/*  870 */     if (b1 > 0) {
/*      */       
/*  872 */       if (arrayOfObject == null)
/*      */       {
/*  874 */         arrayOfObject = new Object[] { null, new long[this.rowPrefetch * b1], new byte[this.accessors.length], new int[this.accessors.length], new Object[this.rowPrefetch * b1] };
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  896 */       for (byte b = 0; b < b2; b++) {
/*      */         
/*  898 */         switch ((this.accessors[b]).internalType) {
/*      */           
/*      */           case 112:
/*      */           case 113:
/*  902 */             (this.accessors[b]).lobPrefetchSizeForThisColumn = -1;
/*  903 */             arrayOfInt[b] = -1;
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/*  908 */       arrayOfObject[0] = arrayOfInt;
/*      */     } 
/*      */ 
/*      */     
/*  912 */     return arrayOfObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processLobPrefetchMetaData(Object[] paramArrayOfObject) {
/*  919 */     byte b1 = 0;
/*  920 */     byte b2 = (this.validRows == -2) ? 1 : this.validRows;
/*      */     
/*  922 */     byte[] arrayOfByte = (byte[])paramArrayOfObject[2];
/*  923 */     int[] arrayOfInt1 = (int[])paramArrayOfObject[3];
/*  924 */     long[] arrayOfLong = (long[])paramArrayOfObject[1];
/*  925 */     Object[] arrayOfObject = (Object[])paramArrayOfObject[4];
/*  926 */     int[] arrayOfInt2 = (int[])paramArrayOfObject[0];
/*      */     
/*  928 */     if (this.accessors != null) {
/*  929 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */         
/*  931 */         switch ((this.accessors[b]).internalType) {
/*      */ 
/*      */           
/*      */           case 112:
/*      */           case 113:
/*  936 */             if ((this.accessors[b]).lobPrefetchSizeForThisColumn >= 0) {
/*      */               
/*  938 */               Accessor accessor = this.accessors[b];
/*      */               
/*  940 */               if (accessor.prefetchedLobDataL == null || accessor.prefetchedLobDataL.length < this.rowPrefetch) {
/*      */ 
/*      */                 
/*  943 */                 if (accessor.internalType == 112) {
/*  944 */                   accessor.prefetchedLobCharData = new char[this.rowPrefetch][];
/*      */                 } else {
/*  946 */                   accessor.prefetchedLobData = new byte[this.rowPrefetch][];
/*      */                 } 
/*  948 */                 accessor.prefetchedLobChunkSize = new int[this.rowPrefetch];
/*  949 */                 accessor.prefetchedClobFormOfUse = new byte[this.rowPrefetch];
/*  950 */                 accessor.prefetchedLobDataL = new int[this.rowPrefetch];
/*  951 */                 accessor.prefetchedLobSize = new long[this.rowPrefetch];
/*      */               } 
/*      */               
/*  954 */               int i = b2 * b1;
/*  955 */               for (byte b3 = 0; b3 < b2; b3++) {
/*      */                 
/*  957 */                 accessor.prefetchedLobChunkSize[b3] = arrayOfInt1[b];
/*      */                 
/*  959 */                 accessor.prefetchedClobFormOfUse[b3] = arrayOfByte[b];
/*      */ 
/*      */                 
/*  962 */                 accessor.prefetchedLobSize[b3] = arrayOfLong[i + b3];
/*      */ 
/*      */                 
/*  965 */                 accessor.prefetchedLobDataL[b3] = 0;
/*  966 */                 if (arrayOfInt2[b] > 0 && arrayOfLong[i + b3] > 0L)
/*      */                 {
/*      */                   
/*  969 */                   if (accessor.internalType == 112) {
/*      */                     
/*  971 */                     accessor.prefetchedLobCharData[b3] = (char[])arrayOfObject[i + b3];
/*      */                     
/*  973 */                     if (accessor.prefetchedLobCharData[b3] != null) {
/*  974 */                       accessor.prefetchedLobDataL[b3] = (accessor.prefetchedLobCharData[b3]).length;
/*      */                     }
/*      */                   }
/*      */                   else {
/*      */                     
/*  979 */                     accessor.prefetchedLobData[b3] = (byte[])arrayOfObject[i + b3];
/*      */                     
/*  981 */                     if (accessor.prefetchedLobData[b3] != null) {
/*  982 */                       accessor.prefetchedLobDataL[b3] = (accessor.prefetchedLobData[b3]).length;
/*      */                     }
/*      */                   } 
/*      */                 }
/*      */               } 
/*  987 */               b1++;
/*      */             } 
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDefineFetch() throws SQLException {
/* 1000 */     if (!this.needToPrepareDefineBuffer) {
/* 1001 */       throw new Error("doDefineFetch called when needToPrepareDefineBuffer=false " + this.sqlObject.getSql(this.processEscapes, this.convertNcharLiterals));
/*      */     }
/*      */     
/* 1004 */     setupForDefine();
/*      */     
/* 1006 */     this.t2cOutput[2] = 0L;
/* 1007 */     this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1008 */     this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1009 */     if (this.connection.useNio) {
/* 1010 */       resetNioAttributesBeforeFetch();
/* 1011 */       allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1017 */     if (this.lobPrefetchMetaData == null) {
/* 1018 */       this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */     }
/* 1020 */     this.validRows = T2CStatement.t2cDefineFetch(this, this.c_state, this.rowPrefetch, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1033 */     if (this.validRows == -1 || this.validRows == -4) {
/* 1034 */       this.connection.checkError(this.validRows);
/*      */     }
/*      */     
/* 1037 */     if (this.t2cOutput[2] != 0L)
/*      */     {
/* 1039 */       this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */     }
/*      */ 
/*      */     
/* 1043 */     if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */     {
/* 1045 */       extractNioDefineBuffers(0);
/*      */     }
/* 1047 */     if (this.lobPrefetchMetaData != null)
/*      */     {
/* 1049 */       processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateNioBuffersIfRequired(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1059 */     if (this.nioBuffers == null) {
/* 1060 */       this.nioBuffers = new ByteBuffer[4];
/*      */     }
/* 1062 */     if (paramInt2 > 0)
/*      */     {
/* 1064 */       if (this.nioBuffers[0] == null || this.nioBuffers[0].capacity() < paramInt2) {
/*      */ 
/*      */         
/* 1067 */         this.nioBuffers[0] = ByteBuffer.allocateDirect(paramInt2);
/* 1068 */       } else if (this.nioBuffers[0] != null) {
/*      */         
/* 1070 */         this.nioBuffers[0].rewind();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1077 */     paramInt1 *= 2;
/* 1078 */     if (paramInt1 > 0)
/*      */     {
/* 1080 */       if (this.nioBuffers[1] == null || this.nioBuffers[1].capacity() < paramInt1) {
/*      */ 
/*      */         
/* 1083 */         this.nioBuffers[1] = ByteBuffer.allocateDirect(paramInt1);
/* 1084 */       } else if (this.nioBuffers[1] != null) {
/*      */         
/* 1086 */         this.nioBuffers[1].rewind();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1093 */     paramInt3 *= 2;
/* 1094 */     if (paramInt3 > 0)
/*      */     {
/* 1096 */       if (this.nioBuffers[2] == null || this.nioBuffers[2].capacity() < paramInt3) {
/*      */ 
/*      */         
/* 1099 */         this.nioBuffers[2] = ByteBuffer.allocateDirect(paramInt3);
/* 1100 */       } else if (this.nioBuffers[2] != null) {
/*      */         
/* 1102 */         this.nioBuffers[2].rewind();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDefineExecuteFetch() throws SQLException {
/* 1111 */     short[] arrayOfShort = null;
/*      */     
/* 1113 */     if (this.needToPrepareDefineBuffer || this.needToParse) {
/*      */       
/* 1115 */       setupForDefine();
/*      */       
/* 1117 */       arrayOfShort = this.connection.queryMetaData1;
/*      */     } 
/*      */     
/* 1120 */     this.t2cOutput[0] = 0L;
/* 1121 */     this.t2cOutput[2] = 0L;
/*      */     
/* 1123 */     byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
/* 1124 */     this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1125 */     this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1126 */     if (this.connection.useNio) {
/* 1127 */       resetNioAttributesBeforeFetch();
/* 1128 */       allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1134 */     if (this.lobPrefetchMetaData == null) {
/* 1135 */       this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */     }
/*      */     try {
/* 1138 */       this.validRows = T2CStatement.t2cDefineExecuteFetch(this, this.c_state, this.numberOfDefinePositions, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, false, this.needToParse, arrayOfByte, arrayOfByte.length, T2CStatement.convertSqlKindEnumToByte(this.sqlKind), this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, arrayOfShort, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.preparedAllBinds, this.preparedCharBinds, this.accessors, this.parameterDatum, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1176 */     catch (IOException iOException) {
/*      */       
/* 1178 */       this.validRows = 0;
/*      */       
/* 1180 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1181 */       sQLException.fillInStackTrace();
/* 1182 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1186 */     if (this.validRows == -1) {
/* 1187 */       this.connection.checkError(this.validRows);
/*      */     }
/* 1189 */     if (this.t2cOutput[2] != 0L) {
/* 1190 */       this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1195 */     this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4];
/*      */     
/* 1197 */     if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */     {
/* 1199 */       extractNioDefineBuffers(0);
/*      */     }
/* 1201 */     if (this.lobPrefetchMetaData != null)
/*      */     {
/* 1203 */       processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */     }
/*      */     
/* 1206 */     this.needToParse = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1249 */     if (this.numberOfDefinePositions > 0)
/*      */     {
/* 1251 */       if (this.needToPrepareDefineBuffer) {
/* 1252 */         doDefineFetch();
/*      */       } else {
/*      */         
/* 1255 */         this.t2cOutput[2] = 0L;
/* 1256 */         this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1257 */         this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1258 */         if (this.connection.useNio) {
/* 1259 */           resetNioAttributesBeforeFetch();
/* 1260 */           allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1267 */         if (this.lobPrefetchMetaData == null) {
/* 1268 */           this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */         }
/* 1270 */         this.validRows = T2CStatement.t2cFetch(this.c_state, this.needToPrepareDefineBuffer, this.rowPrefetch, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1278 */         if (this.validRows == -1 || this.validRows == -4) {
/* 1279 */           this.connection.checkError(this.validRows);
/*      */         }
/* 1281 */         if (this.t2cOutput[2] != 0L)
/*      */         {
/* 1283 */           this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */         }
/*      */         
/* 1286 */         if (this.lobPrefetchMetaData != null)
/*      */         {
/* 1288 */           processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */         }
/* 1290 */         if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */         {
/* 1292 */           extractNioDefineBuffers(0);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void resetNioAttributesBeforeFetch() {
/* 1301 */     this.extractedCharOffset = 0;
/* 1302 */     this.extractedByteOffset = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void extractNioDefineBuffers(int paramInt) throws SQLException {
/* 1311 */     if (this.accessors == null || this.defineIndicators == null || paramInt == this.numberOfDefinePositions) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1316 */     int i = 0;
/* 1317 */     int j = 0;
/* 1318 */     int k = 0;
/* 1319 */     int m = 0;
/* 1320 */     int n = 0;
/*      */ 
/*      */     
/* 1323 */     if (!this.hasStream) {
/*      */       
/* 1325 */       i = (this.defineBytes != null) ? this.defineBytes.length : 0;
/* 1326 */       j = (this.defineChars != null) ? this.defineChars.length : 0;
/* 1327 */       k = this.defineIndicators.length;
/*      */     }
/*      */     else {
/*      */       
/* 1331 */       if (this.numberOfDefinePositions > paramInt) {
/*      */         
/* 1333 */         n = (this.accessors[paramInt]).indicatorIndex;
/* 1334 */         m = (this.accessors[paramInt]).lengthIndex;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1339 */       for (int i1 = paramInt; i1 < this.numberOfDefinePositions; i1++) {
/*      */         
/* 1341 */         switch ((this.accessors[i1]).internalType) {
/*      */           case 8:
/*      */           case 24:
/*      */             break;
/*      */         } 
/*      */         
/* 1347 */         i += (this.accessors[i1]).byteLength;
/* 1348 */         j += (this.accessors[i1]).charLength;
/* 1349 */         k++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1354 */     ByteBuffer byteBuffer = this.nioBuffers[0];
/* 1355 */     if (byteBuffer != null && this.defineBytes != null)
/*      */     {
/* 1357 */       if (i > 0) {
/*      */         
/* 1359 */         byteBuffer.position(this.extractedByteOffset);
/* 1360 */         byteBuffer.get(this.defineBytes, this.extractedByteOffset, i);
/* 1361 */         this.extractedByteOffset += i;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1376 */     if (this.nioBuffers[1] != null && this.defineChars != null) {
/*      */       
/* 1378 */       byteBuffer = this.nioBuffers[1].order(ByteOrder.LITTLE_ENDIAN);
/* 1379 */       CharBuffer charBuffer = byteBuffer.asCharBuffer();
/*      */       
/* 1381 */       if (j > 0) {
/*      */         
/* 1383 */         charBuffer.position(this.extractedCharOffset);
/* 1384 */         charBuffer.get(this.defineChars, this.extractedCharOffset, j);
/* 1385 */         this.extractedCharOffset += j;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1404 */     if (this.nioBuffers[2] != null) {
/* 1405 */       byteBuffer = this.nioBuffers[2].order(ByteOrder.LITTLE_ENDIAN);
/* 1406 */       ShortBuffer shortBuffer = byteBuffer.asShortBuffer();
/* 1407 */       if (this.hasStream) {
/*      */         
/* 1409 */         if (k > 0) {
/*      */           
/* 1411 */           shortBuffer.position(n);
/* 1412 */           shortBuffer.get(this.defineIndicators, n, k);
/* 1413 */           shortBuffer.position(m);
/* 1414 */           shortBuffer.get(this.defineIndicators, m, k);
/*      */         } 
/*      */       } else {
/*      */         
/* 1418 */         shortBuffer.get(this.defineIndicators);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1466 */     if (this.defineBytes != null) {
/*      */       
/* 1468 */       this.defineBytes = null;
/* 1469 */       this.accessorByteOffset = 0;
/*      */     } 
/*      */     
/* 1472 */     if (this.defineChars != null) {
/*      */       
/* 1474 */       this.defineChars = null;
/* 1475 */       this.accessorCharOffset = 0;
/*      */     } 
/*      */     
/* 1478 */     if (this.defineIndicators != null) {
/*      */       
/* 1480 */       this.defineIndicators = null;
/* 1481 */       this.accessorShortOffset = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1485 */     int i = T2CStatement.t2cCloseStatement(this.c_state);
/*      */     
/* 1487 */     this.nioBuffers = null;
/*      */     
/* 1489 */     if (i != 0) {
/* 1490 */       this.connection.checkError(i);
/*      */     }
/* 1492 */     this.t2cOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1510 */     if (this.streamList != null)
/*      */     {
/* 1512 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1516 */           this.nextStream.close();
/*      */         }
/* 1518 */         catch (IOException iOException) {
/*      */ 
/*      */           
/* 1521 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1522 */           sQLException.fillInStackTrace();
/* 1523 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1527 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException {
/* 1544 */     if (paramInt1 == 116 || paramInt1 == 102) {
/*      */ 
/*      */       
/* 1547 */       if (paramBoolean && paramString != null) {
/*      */         
/* 1549 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 1550 */         sQLException.fillInStackTrace();
/* 1551 */         throw sQLException;
/*      */       } 
/*      */       
/* 1554 */       return new T2CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1560 */     return super.allocateAccessor(paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramString, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeUsedStreams(int paramInt) throws SQLException {
/* 1568 */     while (this.nextStream != null && this.nextStream.columnIndex < paramInt) {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 1574 */         this.nextStream.close();
/*      */       }
/* 1576 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 1579 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1580 */         sQLException.fillInStackTrace();
/* 1581 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1585 */       this.nextStream = this.nextStream.nextStream;
/*      */     } 
/*      */     
/* 1588 */     if (this.nextStream != null) {
/*      */       
/*      */       try {
/* 1591 */         this.nextStream.needBytes();
/*      */       }
/* 1593 */       catch (IOException iOException) {
/*      */         
/* 1595 */         interalCloseOnIOException(iOException);
/*      */         
/* 1597 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1598 */         sQLException.fillInStackTrace();
/* 1599 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void interalCloseOnIOException(IOException paramIOException) throws SQLException {
/* 1608 */     this.closed = true;
/*      */     
/* 1610 */     if (this.currentResultSet != null) {
/* 1611 */       this.currentResultSet.closed = true;
/*      */     }
/* 1613 */     doClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetchDmlReturnParams() throws SQLException {
/* 1620 */     this.rowsDmlReturned = T2CStatement.t2cGetRowsDmlReturned(this.c_state);
/*      */     
/* 1622 */     if (this.rowsDmlReturned != 0) {
/*      */       
/* 1624 */       allocateDmlReturnStorage();
/*      */       
/* 1626 */       int i = T2CStatement.t2cFetchDmlReturnParams(this.c_state, this.returnParamAccessors, this.returnParamBytes, this.returnParamChars, this.returnParamIndicators);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1634 */       if (i == -1 || i == -4) {
/* 1635 */         this.connection.checkError(i);
/*      */       }
/*      */       
/* 1638 */       if (this.t2cOutput[2] != 0L)
/*      */       {
/* 1640 */         this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */       }
/*      */ 
/*      */       
/* 1644 */       if (this.connection.useNio && (i > 0 || i == -2))
/*      */       {
/* 1646 */         extractNioDefineBuffers(0);
/*      */       }
/*      */     } 
/* 1649 */     this.returnParamsFetched = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1660 */   static int PREAMBLE_PER_POSITION = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initializeIndicatorSubRange() {
/* 1666 */     this.bindIndicatorSubRange = this.numberOfBindPositions * PREAMBLE_PER_POSITION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int calculateIndicatorSubRangeSize() {
/* 1673 */     return this.numberOfBindPositions * PREAMBLE_PER_POSITION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   short getInoutIndicator(int paramInt) {
/* 1680 */     return this.bindIndicators[paramInt * PREAMBLE_PER_POSITION];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareBindPreambles(int paramInt1, int paramInt2) {
/* 1693 */     int i = calculateIndicatorSubRangeSize();
/* 1694 */     int j = this.bindIndicatorSubRange - i;
/* 1695 */     OracleTypeADT[] arrayOfOracleTypeADT = (this.parameterOtype == null) ? null : this.parameterOtype[this.firstRowInBatch];
/*      */ 
/*      */ 
/*      */     
/* 1699 */     for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */       short s;
/*      */       OracleTypeADT oracleTypeADT;
/* 1702 */       Binder binder = this.lastBinders[b];
/*      */ 
/*      */       
/* 1705 */       if (binder == this.theReturnParamBinder) {
/*      */         
/* 1707 */         oracleTypeADT = (OracleTypeADT)(this.returnParamAccessors[b]).internalOtype;
/* 1708 */         s = 0;
/*      */       }
/*      */       else {
/*      */         
/* 1712 */         oracleTypeADT = (arrayOfOracleTypeADT == null) ? null : arrayOfOracleTypeADT[b];
/*      */         
/* 1714 */         if (this.outBindAccessors == null) {
/* 1715 */           s = 0;
/*      */         } else {
/*      */           
/* 1718 */           Accessor accessor = this.outBindAccessors[b];
/*      */           
/* 1720 */           if (accessor == null) {
/* 1721 */             s = 0;
/* 1722 */           } else if (binder == this.theOutBinder) {
/*      */             
/* 1724 */             s = 1;
/*      */             
/* 1726 */             if (oracleTypeADT == null) {
/* 1727 */               oracleTypeADT = (OracleTypeADT)accessor.internalOtype;
/*      */             }
/*      */           } else {
/* 1730 */             s = 2;
/*      */           } 
/* 1732 */         }  s = binder.updateInoutIndicatorValue(s);
/*      */       } 
/*      */       
/* 1735 */       this.bindIndicators[j++] = s;
/*      */       
/* 1737 */       if (oracleTypeADT != null) {
/*      */         
/* 1739 */         long l = oracleTypeADT.getTdoCState();
/*      */         
/* 1741 */         this.bindIndicators[j + 0] = (short)(int)(l >> 48L & 0xFFFFL);
/*      */         
/* 1743 */         this.bindIndicators[j + 1] = (short)(int)(l >> 32L & 0xFFFFL);
/*      */         
/* 1745 */         this.bindIndicators[j + 2] = (short)(int)(l >> 16L & 0xFFFFL);
/*      */         
/* 1747 */         this.bindIndicators[j + 3] = (short)(int)(l & 0xFFFFL);
/*      */       } 
/*      */       
/* 1750 */       j += 4;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/* 1758 */     super.releaseBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*      */     boolean bool;
/* 1777 */     if (this.closed) {
/*      */       
/* 1779 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1780 */       sQLException.fillInStackTrace();
/* 1781 */       throw sQLException;
/*      */     } 
/*      */     
/* 1784 */     if (this.described == true) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1789 */     if (!this.isOpen) {
/*      */ 
/*      */ 
/*      */       
/* 1793 */       this.connection.open(this);
/* 1794 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 1802 */       bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1811 */       boolean bool1 = (this.sqlKind.isSELECT() && this.needToParse && (!this.described || !this.serverCursor)) ? true : false;
/* 1812 */       byte[] arrayOfByte = bool1 ? this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals) : PhysicalConnection.EMPTY_BYTE_ARRAY;
/* 1813 */       this.numberOfDefinePositions = T2CStatement.t2cDescribe(this.c_state, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, arrayOfByte, arrayOfByte.length, bool1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1824 */       if (!this.described) {
/* 1825 */         this.described = true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1832 */       if (this.numberOfDefinePositions == -1)
/*      */       {
/* 1834 */         this.connection.checkError(this.numberOfDefinePositions);
/*      */       }
/*      */ 
/*      */       
/* 1838 */       if (this.numberOfDefinePositions != T2C_EXTEND_BUFFER)
/*      */         continue; 
/* 1840 */       bool = true;
/*      */ 
/*      */ 
/*      */       
/* 1844 */       this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * 2, this.connection.queryMetaData2Size * 2);
/*      */ 
/*      */     
/*      */     }
/* 1848 */     while (bool);
/*      */     
/* 1850 */     processDescribeData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1856 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T2CPreparedStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */