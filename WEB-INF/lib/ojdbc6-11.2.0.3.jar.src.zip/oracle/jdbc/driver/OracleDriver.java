/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import oracle.jdbc.OracleDatabaseMetaData;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleDriver
/*     */   implements Driver
/*     */ {
/*     */   public static final String oracle_string = "oracle";
/*     */   public static final String jdbc_string = "jdbc";
/*     */   public static final String protocol_string = "protocol";
/*     */   public static final String user_string = "user";
/*     */   public static final String password_string = "password";
/*     */   public static final String database_string = "database";
/*     */   public static final String server_string = "server";
/*     */   public static final String access_string = "access";
/*     */   public static final String protocolFullName_string = "protocolFullName";
/*     */   public static final String logon_as_internal_str = "internal_logon";
/*     */   public static final String proxy_client_name = "oracle.jdbc.proxyClientName";
/*     */   public static final String prefetch_string = "prefetch";
/*     */   public static final String row_prefetch_string = "rowPrefetch";
/*     */   public static final String default_row_prefetch_string = "defaultRowPrefetch";
/*     */   public static final String batch_string = "batch";
/*     */   public static final String execute_batch_string = "executeBatch";
/*     */   public static final String default_execute_batch_string = "defaultExecuteBatch";
/*     */   public static final String process_escapes_string = "processEscapes";
/*     */   public static final String accumulate_batch_result = "AccumulateBatchResult";
/*     */   public static final String j2ee_compliance = "oracle.jdbc.J2EE13Compliant";
/*     */   public static final String v8compatible_string = "V8Compatible";
/*     */   public static final String permit_timestamp_date_mismatch_string = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
/*     */   public static final String StreamChunkSize_string = "oracle.jdbc.StreamChunkSize";
/*     */   public static final String prelim_auth_string = "prelim_auth";
/*     */   public static final String SetFloatAndDoubleUseBinary_string = "SetFloatAndDoubleUseBinary";
/*     */   public static final String xa_trans_loose = "oracle.jdbc.XATransLoose";
/*     */   public static final String tcp_no_delay = "oracle.jdbc.TcpNoDelay";
/*     */   public static final String read_timeout = "oracle.jdbc.ReadTimeout";
/*     */   public static final String defaultnchar_string = "oracle.jdbc.defaultNChar";
/*     */   public static final String defaultncharprop_string = "defaultNChar";
/*     */   public static final String useFetchSizeWithLongColumn_prop_string = "useFetchSizeWithLongColumn";
/*     */   public static final String useFetchSizeWithLongColumn_string = "oracle.jdbc.useFetchSizeWithLongColumn";
/*     */   public static final String remarks_string = "remarks";
/*     */   public static final String report_remarks_string = "remarksReporting";
/*     */   public static final String synonyms_string = "synonyms";
/*     */   public static final String include_synonyms_string = "includeSynonyms";
/*     */   public static final String restrict_getTables_string = "restrictGetTables";
/*     */   public static final String fixed_string_string = "fixedString";
/*     */   public static final String dll_string = "oracle.jdbc.ocinativelibrary";
/*     */   public static final String nls_lang_backdoor = "oracle.jdbc.ociNlsLangBackwardCompatible";
/*     */   public static final String disable_defineColumnType_string = "disableDefineColumnType";
/*     */   public static final String convert_nchar_literals_string = "oracle.jdbc.convertNcharLiterals";
/*     */   public static final String dataSizeUnitsPropertyName = "";
/*     */   public static final String dataSizeBytes = "";
/*     */   public static final String dataSizeChars = "";
/*     */   public static final String set_new_password_string = "OCINewPassword";
/*     */   public static final String retain_v9_bind_behavior_string = "oracle.jdbc.RetainV9LongBindBehavior";
/*     */   public static final String no_caching_buffers = "oracle.jdbc.FreeMemoryOnEnterImplicitCache";
/*     */   static final int EXTENSION_TYPE_ORACLE_ERROR = -3;
/*     */   static final int EXTENSION_TYPE_GEN_ERROR = -2;
/*     */   static final int EXTENSION_TYPE_TYPE4_CLIENT = 0;
/*     */   static final int EXTENSION_TYPE_TYPE4_SERVER = 1;
/*     */   static final int EXTENSION_TYPE_TYPE2_CLIENT = 2;
/*     */   static final int EXTENSION_TYPE_TYPE2_SERVER = 3;
/*     */   private static final int NUMBER_OF_EXTENSION_TYPES = 4;
/* 142 */   private OracleDriverExtension[] driverExtensions = new OracleDriverExtension[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DRIVER_PACKAGE_STRING = "driver";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   private static final String[] driverExtensionClassNames = new String[] { "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T2CDriverExtension", "oracle.jdbc.driver.T2SDriverExtension" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Properties driverAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   protected static Connection defaultConn = null;
/* 178 */   private static OracleDriver defaultDriver = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 185 */       if (defaultDriver == null) {
/*     */         
/* 187 */         defaultDriver = (OracleDriver)new oracle.jdbc.OracleDriver();
/* 188 */         DriverManager.registerDriver(defaultDriver);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run()
/*     */             {
/* 199 */               OracleDriver.registerMBeans();
/* 200 */               return null;
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 216 */       Timestamp timestamp = Timestamp.valueOf("2000-01-01 00:00:00.0");
/*     */ 
/*     */     
/*     */     }
/* 220 */     catch (SQLException sQLException) {
/* 221 */       Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "SQLException in static block.", sQLException);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 226 */     catch (RuntimeException runtimeException) {
/* 227 */       Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "RuntimeException in static block.", runtimeException);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 241 */       ClassRef classRef = ClassRef.newInstance("oracle.security.pki.OraclePKIProvider");
/* 242 */       Object object = classRef.get().newInstance();
/*     */     }
/* 244 */     catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 253 */   public static final Map<String, ClassRef> systemTypeMap = new Hashtable<String, ClassRef>(3);
/*     */   
/*     */   private static final String DEFAULT_CONNECTION_PROPERTIES_RESOURCE_NAME = "/oracle/jdbc/defaultConnectionProperties.properties";
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 260 */       systemTypeMap.put("SYS.XMLTYPE", ClassRef.newInstance("oracle.xdb.XMLTypeFactory"));
/*     */     }
/* 262 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 270 */       systemTypeMap.put("SYS.ANYDATA", ClassRef.newInstance("oracle.sql.AnyDataFactory"));
/* 271 */       systemTypeMap.put("SYS.ANYTYPE", ClassRef.newInstance("oracle.sql.TypeDescriptorFactory"));
/*     */     }
/* 273 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   protected static final Properties DEFAULT_CONNECTION_PROPERTIES = new Properties();
/*     */   static {
/*     */     try {
/* 289 */       InputStream inputStream = PhysicalConnection.class.getResourceAsStream("/oracle/jdbc/defaultConnectionProperties.properties");
/* 290 */       if (inputStream != null) DEFAULT_CONNECTION_PROPERTIES.load(inputStream);
/*     */     
/* 292 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerMBeans() {
/*     */     try {
/* 308 */       MBeanServer mBeanServer = null;
/*     */       
/*     */       try {
/* 311 */         ClassRef classRef = ClassRef.newInstance("oracle.as.jmx.framework.PortableMBeanFactory");
/* 312 */         Constructor<Object> constructor = classRef.get().getConstructor(new Class[0]);
/* 313 */         Object object = constructor.newInstance(new Object[0]);
/* 314 */         Method method = classRef.get().getMethod("getMBeanServer", new Class[0]);
/* 315 */         mBeanServer = (MBeanServer)method.invoke(object, new Object[0]);
/*     */       }
/* 317 */       catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */         
/* 320 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 322 */       catch (NoSuchMethodException noSuchMethodException) {
/* 323 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but not the getMBeanServer method.", noSuchMethodException);
/*     */ 
/*     */ 
/*     */         
/* 327 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 329 */       catch (InstantiationException instantiationException) {
/* 330 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not create an instance.", instantiationException);
/*     */ 
/*     */ 
/*     */         
/* 334 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 336 */       catch (IllegalAccessException illegalAccessException) {
/* 337 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not access the getMBeanServer method.", illegalAccessException);
/*     */ 
/*     */ 
/*     */         
/* 341 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 343 */       catch (InvocationTargetException invocationTargetException) {
/* 344 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but the getMBeanServer method threw an exception.", invocationTargetException);
/*     */ 
/*     */ 
/*     */         
/* 348 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       } 
/* 350 */       if (mBeanServer != null) {
/* 351 */         ClassLoader classLoader = OracleDriver.class.getClassLoader();
/* 352 */         String str = (classLoader == null) ? "nullLoader" : classLoader.getClass().getName();
/* 353 */         byte b = 0;
/*     */         while (true) {
/* 355 */           String str1 = str + "@" + Integer.toHexString(((classLoader == null) ? 0 : classLoader.hashCode()) + b++);
/*     */           
/* 357 */           ObjectName objectName = new ObjectName("com.oracle.jdbc:type=diagnosability,name=" + str1);
/*     */           
/*     */           try {
/* 360 */             mBeanServer.registerMBean(new OracleDiagnosabilityMBean(), objectName);
/*     */             
/*     */             break;
/* 363 */           } catch (InstanceAlreadyExistsException instanceAlreadyExistsException) {}
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 368 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Unable to find an MBeanServer so no MBears are registered.");
/*     */       }
/*     */     
/*     */     }
/* 372 */     catch (JMException jMException) {
/* 373 */       Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", jMException);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 378 */     catch (Throwable throwable) {
/* 379 */       Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection connect(String paramString, Properties paramProperties) throws SQLException {
/* 413 */     if (paramString.regionMatches(0, "jdbc:default:connection", 0, 23)) {
/*     */       
/* 415 */       String str = "jdbc:oracle:kprb";
/* 416 */       int j = paramString.length();
/*     */       
/* 418 */       if (j > 23) {
/* 419 */         paramString = str.concat(paramString.substring(23, paramString.length()));
/*     */       } else {
/* 421 */         paramString = str.concat(":");
/*     */       } 
/* 423 */       str = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 433 */     int i = oracleDriverExtensionTypeFromURL(paramString);
/*     */     
/* 435 */     if (i == -2) {
/* 436 */       return null;
/*     */     }
/* 438 */     if (i == -3) {
/*     */       
/* 440 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
/* 441 */       sQLException.fillInStackTrace();
/* 442 */       throw sQLException;
/*     */     } 
/*     */     
/* 445 */     OracleDriverExtension oracleDriverExtension = null;
/*     */     
/* 447 */     oracleDriverExtension = this.driverExtensions[i];
/*     */     
/* 449 */     if (oracleDriverExtension == null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 454 */         synchronized (this)
/*     */         {
/* 456 */           if (oracleDriverExtension == null)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 462 */             oracleDriverExtension = (OracleDriverExtension)Class.forName(driverExtensionClassNames[i]).newInstance();
/*     */             
/* 464 */             this.driverExtensions[i] = oracleDriverExtension;
/*     */           }
/*     */           else
/*     */           {
/* 468 */             oracleDriverExtension = this.driverExtensions[i];
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 473 */       } catch (Exception exception) {
/*     */ 
/*     */         
/* 476 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), exception);
/* 477 */         sQLException.fillInStackTrace();
/* 478 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 485 */     if (paramProperties == null) {
/* 486 */       paramProperties = new Properties();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 497 */     Enumeration<Driver> enumeration = DriverManager.getDrivers();
/*     */ 
/*     */     
/* 500 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 502 */       Driver driver = enumeration.nextElement();
/*     */       
/* 504 */       if (driver instanceof OracleDriver) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 509 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 511 */       Driver driver = enumeration.nextElement();
/*     */       
/* 513 */       if (driver instanceof OracleDriver) {
/* 514 */         DriverManager.deregisterDriver(driver);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 521 */     PhysicalConnection physicalConnection = (PhysicalConnection)oracleDriverExtension.getConnection(paramString, paramProperties);
/*     */ 
/*     */     
/* 524 */     physicalConnection.protocolId = i;
/*     */     
/* 526 */     return (Connection)physicalConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection defaultConnection() throws SQLException {
/* 539 */     if (defaultConn == null || defaultConn.isClosed())
/*     */     {
/* 541 */       synchronized (OracleDriver.class) {
/*     */         
/* 543 */         if (defaultConn == null || defaultConn.isClosed())
/*     */         {
/* 545 */           defaultConn = connect("jdbc:oracle:kprb:", new Properties());
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 550 */     return defaultConn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int oracleDriverExtensionTypeFromURL(String paramString) {
/* 575 */     int i = paramString.indexOf(':');
/*     */     
/* 577 */     if (i == -1) {
/* 578 */       return -2;
/*     */     }
/* 580 */     if (!paramString.regionMatches(true, 0, "jdbc", 0, i)) {
/* 581 */       return -2;
/*     */     }
/* 583 */     i++;
/*     */     
/* 585 */     int j = paramString.indexOf(':', i);
/*     */     
/* 587 */     if (j == -1) {
/* 588 */       return -2;
/*     */     }
/* 590 */     if (!paramString.regionMatches(true, i, "oracle", 0, j - i))
/*     */     {
/* 592 */       return -2;
/*     */     }
/* 594 */     j++;
/*     */     
/* 596 */     int k = paramString.indexOf(':', j);
/*     */     
/* 598 */     String str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 605 */     if (k == -1) {
/* 606 */       return -3;
/*     */     }
/* 608 */     str = paramString.substring(j, k);
/*     */     
/* 610 */     if (str.equals("thin")) {
/* 611 */       return 0;
/*     */     }
/* 613 */     if (str.equals("oci8") || str.equals("oci")) {
/* 614 */       return 2;
/*     */     }
/*     */ 
/*     */     
/* 618 */     return -3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean acceptsURL(String paramString) {
/* 638 */     if (paramString.startsWith("jdbc:oracle:"))
/*     */     {
/* 640 */       return (oracleDriverExtensionTypeFromURL(paramString) > -2);
/*     */     }
/*     */     
/* 643 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties) throws SQLException {
/* 651 */     Class clazz = null;
/*     */     
/*     */     try {
/* 654 */       clazz = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
/*     */     
/*     */     }
/* 657 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */     
/* 659 */     byte b1 = 0;
/* 660 */     String[] arrayOfString1 = new String[150];
/* 661 */     String[] arrayOfString2 = new String[150];
/*     */     
/* 663 */     Field[] arrayOfField = clazz.getFields();
/* 664 */     for (byte b2 = 0; b2 < arrayOfField.length; b2++) {
/*     */       
/* 666 */       if (arrayOfField[b2].getName().startsWith("CONNECTION_PROPERTY_") && !arrayOfField[b2].getName().endsWith("_DEFAULT") && !arrayOfField[b2].getName().endsWith("_ACCESSMODE")) {
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */           
/* 672 */           String str1 = (String)arrayOfField[b2].get(null);
/* 673 */           Field field = clazz.getField(arrayOfField[b2].getName() + "_DEFAULT");
/* 674 */           String str2 = (String)field.get(null);
/* 675 */           if (b1 == arrayOfString1.length) {
/*     */             
/* 677 */             String[] arrayOfString3 = new String[arrayOfString1.length * 2];
/* 678 */             String[] arrayOfString4 = new String[arrayOfString1.length * 2];
/* 679 */             System.arraycopy(arrayOfString1, 0, arrayOfString3, 0, arrayOfString1.length);
/* 680 */             System.arraycopy(arrayOfString2, 0, arrayOfString4, 0, arrayOfString1.length);
/* 681 */             arrayOfString1 = arrayOfString3;
/* 682 */             arrayOfString2 = arrayOfString4;
/*     */           } 
/* 684 */           arrayOfString1[b1] = str1;
/* 685 */           arrayOfString2[b1] = str2;
/* 686 */           b1++;
/*     */         }
/* 688 */         catch (IllegalAccessException illegalAccessException) {
/*     */         
/* 690 */         } catch (NoSuchFieldException noSuchFieldException) {}
/*     */       }
/*     */     } 
/*     */     
/* 694 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = new DriverPropertyInfo[b1];
/* 695 */     for (byte b3 = 0; b3 < b1; b3++)
/* 696 */       arrayOfDriverPropertyInfo[b3] = new DriverPropertyInfo(arrayOfString1[b3], arrayOfString2[b3]); 
/* 697 */     return arrayOfDriverPropertyInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMajorVersion() {
/* 704 */     return OracleDatabaseMetaData.getDriverMajorVersionInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinorVersion() {
/* 711 */     return OracleDatabaseMetaData.getDriverMinorVersionInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean jdbcCompliant() {
/* 718 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String processSqlEscapes(String paramString) throws SQLException {
/* 733 */     OracleSql oracleSql = new OracleSql(null);
/*     */ 
/*     */ 
/*     */     
/* 737 */     oracleSql.initialize(paramString);
/*     */     
/* 739 */     return oracleSql.parse(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCompileTime() {
/* 754 */     return "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSystemPropertyFastConnectionFailover(String paramString) {
/* 761 */     return PhysicalConnection.getSystemPropertyFastConnectionFailover(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 776 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 781 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleDriver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */