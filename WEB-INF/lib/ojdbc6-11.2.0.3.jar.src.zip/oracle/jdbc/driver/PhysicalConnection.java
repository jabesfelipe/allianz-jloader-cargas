/*       */ package oracle.jdbc.driver;
/*       */ import java.lang.reflect.Field;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.InetAddress;
/*       */ import java.security.PrivilegedAction;
/*       */ import java.sql.Array;
/*       */ import java.sql.Blob;
/*       */ import java.sql.CallableStatement;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Connection;
/*       */ import java.sql.DatabaseMetaData;
/*       */ import java.sql.Date;
/*       */ import java.sql.DriverManager;
/*       */ import java.sql.NClob;
/*       */ import java.sql.PreparedStatement;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLWarning;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Savepoint;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Struct;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Calendar;
/*       */ import java.util.EnumSet;
/*       */ import java.util.Enumeration;
/*       */ import java.util.Hashtable;
/*       */ import java.util.Map;
/*       */ import java.util.Properties;
/*       */ import java.util.TimeZone;
/*       */ import java.util.Vector;
/*       */ import java.util.regex.Pattern;
/*       */ import oracle.jdbc.OracleCallableStatement;
/*       */ import oracle.jdbc.OracleConnection;
/*       */ import oracle.jdbc.OraclePreparedStatement;
/*       */ import oracle.jdbc.OracleSQLPermission;
/*       */ import oracle.jdbc.OracleSavepoint;
/*       */ import oracle.jdbc.OracleStatement;
/*       */ import oracle.jdbc.aq.AQDequeueOptions;
/*       */ import oracle.jdbc.aq.AQEnqueueOptions;
/*       */ import oracle.jdbc.aq.AQMessage;
/*       */ import oracle.jdbc.aq.AQNotificationRegistration;
/*       */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*       */ import oracle.jdbc.internal.KeywordValueLong;
/*       */ import oracle.jdbc.internal.OracleConnection;
/*       */ import oracle.jdbc.internal.OracleStatement;
/*       */ import oracle.jdbc.internal.XSEventListener;
/*       */ import oracle.jdbc.internal.XSNamespace;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.pool.OracleConnectionCacheCallback;
/*       */ import oracle.jdbc.pool.OraclePooledConnection;
/*       */ import oracle.net.nt.CustomSSLSocketFactory;
/*       */ import oracle.security.pki.OracleSecretStore;
/*       */ import oracle.security.pki.OracleWallet;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.BfileDBAccess;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NCLOB;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.SQLName;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ import oracle.sql.TIMEZONETAB;
/*       */ import oracle.sql.TypeDescriptor;
/*       */ 
/*       */ abstract class PhysicalConnection extends OracleConnection {
/*       */   public static final String SECRET_STORE_CONNECT = "oracle.security.client.connect_string";
/*       */   public static final String SECRET_STORE_USERNAME = "oracle.security.client.username";
/*       */   public static final String SECRET_STORE_PASSWORD = "oracle.security.client.password";
/*       */   public static final String SECRET_STORE_DEFAULT_USERNAME = "oracle.security.client.default_username";
/*       */   public static final String SECRET_STORE_DEFAULT_PASSWORD = "oracle.security.client.default_password";
/*    89 */   static final CRC64 CHECKSUM = new CRC64();
/*       */   public static final char slash_character = '/';
/*       */   public static final char at_sign_character = '@';
/*       */   public static final char left_square_bracket_character = '[';
/*       */   public static final char right_square_bracket_character = ']';
/*    94 */   static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*    99 */   long outScn = 0L;
/*       */   
/*   101 */   char[][] charOutput = new char[1][];
/*   102 */   byte[][] byteOutput = new byte[1][];
/*   103 */   short[][] shortOutput = new short[1][];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   109 */   Properties sessionProperties = null;
/*       */   
/*       */   boolean retainV9BindBehavior;
/*       */   
/*       */   String userName;
/*       */   
/*       */   String database;
/*       */   
/*       */   boolean autocommit;
/*       */   
/*       */   String protocol;
/*       */   
/*       */   int streamChunkSize;
/*       */   
/*       */   boolean setFloatAndDoubleUseBinary;
/*       */   String ocidll;
/*       */   String thinVsessionTerminal;
/*       */   String thinVsessionMachine;
/*       */   String thinVsessionOsuser;
/*       */   String thinVsessionProgram;
/*       */   String thinVsessionProcess;
/*       */   String thinVsessionIname;
/*       */   String thinVsessionEname;
/*       */   String thinNetProfile;
/*       */   String thinNetAuthenticationServices;
/*       */   String thinNetAuthenticationKrb5Mutual;
/*       */   String thinNetAuthenticationKrb5CcName;
/*       */   String thinNetEncryptionLevel;
/*       */   String thinNetEncryptionTypes;
/*       */   String thinNetChecksumLevel;
/*       */   String thinNetChecksumTypes;
/*       */   String thinNetCryptoSeed;
/*       */   boolean thinTcpNoDelay;
/*       */   String thinReadTimeout;
/*       */   String thinNetConnectTimeout;
/*       */   boolean thinNetDisableOutOfBandBreak;
/*       */   boolean thinNetUseZeroCopyIO;
/*       */   boolean thinNetEnableSDP;
/*       */   boolean use1900AsYearForTime;
/*       */   boolean timestamptzInGmt;
/*       */   boolean timezoneAsRegion;
/*       */   String thinSslServerDnMatch;
/*       */   String thinSslVersion;
/*       */   String thinSslCipherSuites;
/*       */   String thinJavaxNetSslKeystore;
/*       */   String thinJavaxNetSslKeystoretype;
/*       */   String thinJavaxNetSslKeystorepassword;
/*       */   String thinJavaxNetSslTruststore;
/*       */   String thinJavaxNetSslTruststoretype;
/*       */   String thinJavaxNetSslTruststorepassword;
/*       */   String thinSslKeymanagerfactoryAlgorithm;
/*       */   String thinSslTrustmanagerfactoryAlgorithm;
/*       */   String thinNetOldsyntax;
/*       */   String thinNamingContextInitial;
/*       */   String thinNamingProviderUrl;
/*       */   String thinNamingSecurityAuthentication;
/*       */   String thinNamingSecurityPrincipal;
/*       */   String thinNamingSecurityCredentials;
/*       */   String walletLocation;
/*       */   String walletPassword;
/*       */   String proxyClientName;
/*       */   boolean useNio;
/*       */   String ociDriverCharset;
/*       */   String editionName;
/*       */   String logonCap;
/*       */   String internalLogon;
/*       */   boolean createDescriptorUseCurrentSchemaForSchemaName;
/*       */   long ociSvcCtxHandle;
/*       */   long ociEnvHandle;
/*       */   long ociErrHandle;
/*       */   boolean prelimAuth;
/*       */   boolean nlsLangBackdoor;
/*       */   String setNewPassword;
/*       */   boolean spawnNewThreadToCancel;
/*       */   int defaultExecuteBatch;
/*       */   int defaultRowPrefetch;
/*       */   int defaultLobPrefetchSize;
/*       */   boolean enableDataInLocator;
/*       */   boolean enableReadDataInLocator;
/*       */   boolean overrideEnableReadDataInLocator;
/*       */   boolean reportRemarks;
/*       */   boolean includeSynonyms;
/*       */   boolean restrictGettables;
/*       */   boolean accumulateBatchResult;
/*       */   boolean useFetchSizeWithLongColumn;
/*       */   boolean processEscapes;
/*       */   boolean fixedString;
/*       */   boolean defaultnchar;
/*       */   boolean permitTimestampDateMismatch;
/*       */   String resourceManagerId;
/*       */   boolean disableDefinecolumntype;
/*       */   boolean convertNcharLiterals;
/*       */   boolean j2ee13Compliant;
/*       */   boolean mapDateToTimestamp;
/*       */   boolean useThreadLocalBufferCache;
/*       */   String driverNameAttribute;
/*       */   int maxCachedBufferSize;
/*       */   int implicitStatementCacheSize;
/*       */   boolean lobStreamPosStandardCompliant;
/*       */   boolean isStrictAsciiConversion;
/*       */   boolean thinForceDnsLoadBalancing;
/*       */   boolean calculateChecksum;
/*       */   boolean enableJavaNetFastPath;
/*       */   boolean enableTempLobRefCnt;
/*       */   boolean keepAlive;
/*       */   String url;
/*       */   String savedUser;
/*       */   int commitOption;
/*   217 */   int ociConnectionPoolMinLimit = 0;
/*   218 */   int ociConnectionPoolMaxLimit = 0;
/*   219 */   int ociConnectionPoolIncrement = 0;
/*   220 */   int ociConnectionPoolTimeout = 0;
/*       */   boolean ociConnectionPoolNoWait = false;
/*       */   boolean ociConnectionPoolTransactionDistributed = false;
/*   223 */   String ociConnectionPoolLogonMode = null;
/*       */   boolean ociConnectionPoolIsPooling = false;
/*   225 */   Object ociConnectionPoolObject = null;
/*   226 */   Object ociConnectionPoolConnID = null;
/*   227 */   String ociConnectionPoolProxyType = null;
/*   228 */   Integer ociConnectionPoolProxyNumRoles = Integer.valueOf(0);
/*   229 */   Object ociConnectionPoolProxyRoles = null;
/*   230 */   String ociConnectionPoolProxyUserName = null;
/*   231 */   String ociConnectionPoolProxyPassword = null;
/*   232 */   String ociConnectionPoolProxyDistinguishedName = null;
/*   233 */   Object ociConnectionPoolProxyCertificate = null;
/*       */   
/*   235 */   static NTFManager ntfManager = new NTFManager();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   246 */   public int protocolId = -3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTimeout timeout;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   DBConversion conversion;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean xaWantsError;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean usingXA;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   271 */   int txnMode = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] fdo;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Boolean bigEndian;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleStatement statements;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int lifecycle;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int OPEN = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int CLOSING = 2;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int CLOSED = 4;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int ABORTED = 8;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BLOCKED = 16;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean clientIdSet = false;
/*       */ 
/*       */ 
/*       */   
/*   321 */   String clientId = null;
/*       */ 
/*       */ 
/*       */   
/*       */   int txnLevel;
/*       */ 
/*       */ 
/*       */   
/*       */   Map map;
/*       */ 
/*       */ 
/*       */   
/*       */   Map javaObjectMap;
/*       */ 
/*       */ 
/*       */   
/*   337 */   final Hashtable[] descriptorCacheStack = new Hashtable[2];
/*       */   
/*   339 */   int dci = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleStatement statementHoldingLine;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   351 */   OracleDatabaseMetaData databaseMetaData = null;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   LogicalConnection logicalConnectionAttached;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isProxy = false;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   366 */   OracleSql sqlObj = null;
/*       */ 
/*       */   
/*   369 */   SQLWarning sqlWarning = null;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean readOnly = false;
/*       */ 
/*       */ 
/*       */   
/*   377 */   LRUStatementCache statementCache = null;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean clearStatementMetaData = false;
/*       */ 
/*       */ 
/*       */   
/*   386 */   OracleCloseCallback closeCallback = null;
/*   387 */   Object privateData = null;
/*       */ 
/*       */   
/*   390 */   Statement savepointStatement = null;
/*       */ 
/*       */   
/*       */   boolean isUsable = true;
/*       */   
/*   395 */   TimeZone defaultTimeZone = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   420 */   final int[] endToEndMaxLength = new int[4];
/*       */   
/*       */   boolean endToEndAnyChanged = false;
/*   423 */   final boolean[] endToEndHasChanged = new boolean[4];
/*   424 */   short endToEndECIDSequenceNumber = Short.MIN_VALUE;
/*       */ 
/*       */   
/*       */   static final int DMS_NONE = 0;
/*       */ 
/*       */   
/*       */   static final int DMS_10G = 1;
/*       */   
/*       */   static final int DMS_11 = 2;
/*       */   
/*   434 */   String[] endToEndValues = null;
/*   435 */   final int whichDMS = 0;
/*       */ 
/*       */ 
/*       */   
/*   439 */   OracleConnection wrapper = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int minVcsBindSize;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesPlsql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsCharsSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsNCharsSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxIbtVarcharElementLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   492 */   String instanceName = null;
/*       */   OracleDriverExtension driverExtension;
/*       */   static final String uninitializedMarker = "";
/*   495 */   String databaseProductVersion = "";
/*   496 */   short versionNumber = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int namedTypeAccessorByteLen;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int refTypeAccessorByteLen;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CharacterSet setCHARCharSetObj;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CharacterSet setCHARNCharSetObj;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean plsqlCompilerWarnings = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String propertyVariableName(String paramString) {
/*   675 */     char[] arrayOfChar = new char[paramString.length()];
/*   676 */     paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*   677 */     String str = "";
/*   678 */     for (byte b = 0; b < arrayOfChar.length; b++) {
/*       */       
/*   680 */       if (Character.isUpperCase(arrayOfChar[b]))
/*   681 */         str = str + "_"; 
/*   682 */       str = str + Character.toUpperCase(arrayOfChar[b]);
/*       */     } 
/*   684 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void initializeUserDefaults(Properties paramProperties) {
/*   699 */     for (String str : OracleDriver.DEFAULT_CONNECTION_PROPERTIES.stringPropertyNames()) {
/*   700 */       if (!paramProperties.containsKey(str)) {
/*   701 */         paramProperties.setProperty(str, OracleDriver.DEFAULT_CONNECTION_PROPERTIES.getProperty(str));
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void readConnectionProperties(String paramString, Properties paramProperties) throws SQLException {
/*   730 */     initializeUserDefaults(paramProperties);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   735 */     String str1 = null;
/*       */ 
/*       */     
/*   738 */     str1 = null;
/*   739 */     if (paramProperties != null)
/*       */     {
/*   741 */       str1 = paramProperties.getProperty("oracle.jdbc.RetainV9LongBindBehavior");
/*       */     }
/*   743 */     if (str1 == null)
/*   744 */       str1 = getSystemProperty("oracle.jdbc.RetainV9LongBindBehavior", (String)null); 
/*   745 */     if (str1 == null) {
/*   746 */       str1 = "false";
/*       */     }
/*       */     
/*   749 */     this.retainV9BindBehavior = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   752 */     str1 = null;
/*   753 */     if (paramProperties != null) {
/*       */       
/*   755 */       str1 = paramProperties.getProperty("user");
/*   756 */       if (str1 == null)
/*   757 */         str1 = paramProperties.getProperty("oracle.jdbc.user"); 
/*       */     } 
/*   759 */     if (str1 == null)
/*   760 */       str1 = getSystemProperty("oracle.jdbc.user", (String)null); 
/*   761 */     if (str1 == null) {
/*   762 */       str1 = null;
/*       */     }
/*       */     
/*   765 */     this.userName = str1;
/*       */ 
/*       */     
/*   768 */     str1 = null;
/*   769 */     if (paramProperties != null) {
/*       */       
/*   771 */       str1 = paramProperties.getProperty("database");
/*   772 */       if (str1 == null)
/*   773 */         str1 = paramProperties.getProperty("oracle.jdbc.database"); 
/*       */     } 
/*   775 */     if (str1 == null)
/*   776 */       str1 = getSystemProperty("oracle.jdbc.database", (String)null); 
/*   777 */     if (str1 == null) {
/*   778 */       str1 = null;
/*       */     }
/*       */     
/*   781 */     this.database = str1;
/*       */ 
/*       */     
/*   784 */     str1 = null;
/*   785 */     if (paramProperties != null) {
/*       */       
/*   787 */       str1 = paramProperties.getProperty("autoCommit");
/*   788 */       if (str1 == null)
/*   789 */         str1 = paramProperties.getProperty("oracle.jdbc.autoCommit"); 
/*       */     } 
/*   791 */     if (str1 == null)
/*   792 */       str1 = getSystemProperty("oracle.jdbc.autoCommit", (String)null); 
/*   793 */     if (str1 == null) {
/*   794 */       str1 = "true";
/*       */     }
/*       */     
/*   797 */     this.autocommit = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   800 */     str1 = null;
/*   801 */     if (paramProperties != null) {
/*       */       
/*   803 */       str1 = paramProperties.getProperty("protocol");
/*   804 */       if (str1 == null)
/*   805 */         str1 = paramProperties.getProperty("oracle.jdbc.protocol"); 
/*       */     } 
/*   807 */     if (str1 == null)
/*   808 */       str1 = getSystemProperty("oracle.jdbc.protocol", (String)null); 
/*   809 */     if (str1 == null) {
/*   810 */       str1 = null;
/*       */     }
/*       */     
/*   813 */     this.protocol = str1;
/*       */ 
/*       */     
/*   816 */     str1 = null;
/*   817 */     if (paramProperties != null)
/*       */     {
/*   819 */       str1 = paramProperties.getProperty("oracle.jdbc.StreamChunkSize");
/*       */     }
/*   821 */     if (str1 == null)
/*   822 */       str1 = getSystemProperty("oracle.jdbc.StreamChunkSize", (String)null); 
/*   823 */     if (str1 == null) {
/*   824 */       str1 = "16384";
/*       */     }
/*       */     try {
/*   827 */       this.streamChunkSize = Integer.parseInt(str1);
/*   828 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*   832 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'streamChunkSize'");
/*   833 */       sQLException.fillInStackTrace();
/*   834 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   840 */     str1 = null;
/*   841 */     if (paramProperties != null) {
/*       */       
/*   843 */       str1 = paramProperties.getProperty("SetFloatAndDoubleUseBinary");
/*   844 */       if (str1 == null)
/*   845 */         str1 = paramProperties.getProperty("oracle.jdbc.SetFloatAndDoubleUseBinary"); 
/*       */     } 
/*   847 */     if (str1 == null)
/*   848 */       str1 = getSystemProperty("oracle.jdbc.SetFloatAndDoubleUseBinary", (String)null); 
/*   849 */     if (str1 == null) {
/*   850 */       str1 = "false";
/*       */     }
/*       */     
/*   853 */     this.setFloatAndDoubleUseBinary = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   856 */     str1 = null;
/*   857 */     if (paramProperties != null)
/*       */     {
/*   859 */       str1 = paramProperties.getProperty("oracle.jdbc.ocinativelibrary");
/*       */     }
/*   861 */     if (str1 == null)
/*   862 */       str1 = getSystemProperty("oracle.jdbc.ocinativelibrary", (String)null); 
/*   863 */     if (str1 == null) {
/*   864 */       str1 = null;
/*       */     }
/*       */     
/*   867 */     this.ocidll = str1;
/*       */ 
/*       */     
/*   870 */     str1 = null;
/*   871 */     if (paramProperties != null) {
/*       */       
/*   873 */       str1 = paramProperties.getProperty("v$session.terminal");
/*   874 */       if (str1 == null)
/*   875 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.terminal"); 
/*       */     } 
/*   877 */     if (str1 == null)
/*   878 */       str1 = getSystemProperty("oracle.jdbc.v$session.terminal", (String)null); 
/*   879 */     if (str1 == null) {
/*   880 */       str1 = "unknown";
/*       */     }
/*       */     
/*   883 */     this.thinVsessionTerminal = str1;
/*       */ 
/*       */     
/*   886 */     str1 = null;
/*   887 */     if (paramProperties != null) {
/*       */       
/*   889 */       str1 = paramProperties.getProperty("v$session.machine");
/*   890 */       if (str1 == null)
/*   891 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.machine"); 
/*       */     } 
/*   893 */     if (str1 == null)
/*   894 */       str1 = getSystemProperty("oracle.jdbc.v$session.machine", (String)null); 
/*   895 */     if (str1 == null) {
/*   896 */       str1 = null;
/*       */     }
/*       */     
/*   899 */     this.thinVsessionMachine = str1;
/*       */ 
/*       */     
/*   902 */     str1 = null;
/*   903 */     if (paramProperties != null) {
/*       */       
/*   905 */       str1 = paramProperties.getProperty("v$session.osuser");
/*   906 */       if (str1 == null)
/*   907 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.osuser"); 
/*       */     } 
/*   909 */     if (str1 == null)
/*   910 */       str1 = getSystemProperty("oracle.jdbc.v$session.osuser", (String)null); 
/*   911 */     if (str1 == null) {
/*   912 */       str1 = null;
/*       */     }
/*       */     
/*   915 */     this.thinVsessionOsuser = str1;
/*       */ 
/*       */     
/*   918 */     str1 = null;
/*   919 */     if (paramProperties != null) {
/*       */       
/*   921 */       str1 = paramProperties.getProperty("v$session.program");
/*   922 */       if (str1 == null)
/*   923 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.program"); 
/*       */     } 
/*   925 */     if (str1 == null)
/*   926 */       str1 = getSystemProperty("oracle.jdbc.v$session.program", (String)null); 
/*   927 */     if (str1 == null) {
/*   928 */       str1 = "JDBC Thin Client";
/*       */     }
/*       */     
/*   931 */     this.thinVsessionProgram = str1;
/*       */ 
/*       */     
/*   934 */     str1 = null;
/*   935 */     if (paramProperties != null) {
/*       */       
/*   937 */       str1 = paramProperties.getProperty("v$session.process");
/*   938 */       if (str1 == null)
/*   939 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.process"); 
/*       */     } 
/*   941 */     if (str1 == null)
/*   942 */       str1 = getSystemProperty("oracle.jdbc.v$session.process", (String)null); 
/*   943 */     if (str1 == null) {
/*   944 */       str1 = "1234";
/*       */     }
/*       */     
/*   947 */     this.thinVsessionProcess = str1;
/*       */ 
/*       */     
/*   950 */     str1 = null;
/*   951 */     if (paramProperties != null) {
/*       */       
/*   953 */       str1 = paramProperties.getProperty("v$session.iname");
/*   954 */       if (str1 == null)
/*   955 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.iname"); 
/*       */     } 
/*   957 */     if (str1 == null)
/*   958 */       str1 = getSystemProperty("oracle.jdbc.v$session.iname", (String)null); 
/*   959 */     if (str1 == null) {
/*   960 */       str1 = "jdbc_ttc_impl";
/*       */     }
/*       */     
/*   963 */     this.thinVsessionIname = str1;
/*       */ 
/*       */     
/*   966 */     str1 = null;
/*   967 */     if (paramProperties != null) {
/*       */       
/*   969 */       str1 = paramProperties.getProperty("v$session.ename");
/*   970 */       if (str1 == null)
/*   971 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.ename"); 
/*       */     } 
/*   973 */     if (str1 == null)
/*   974 */       str1 = getSystemProperty("oracle.jdbc.v$session.ename", (String)null); 
/*   975 */     if (str1 == null) {
/*   976 */       str1 = null;
/*       */     }
/*       */     
/*   979 */     this.thinVsessionEname = str1;
/*       */ 
/*       */     
/*   982 */     str1 = null;
/*   983 */     if (paramProperties != null)
/*       */     {
/*   985 */       str1 = paramProperties.getProperty("oracle.net.profile");
/*       */     }
/*   987 */     if (str1 == null)
/*   988 */       str1 = getSystemProperty("oracle.net.profile", (String)null); 
/*   989 */     if (str1 == null) {
/*   990 */       str1 = null;
/*       */     }
/*       */     
/*   993 */     this.thinNetProfile = str1;
/*       */ 
/*       */     
/*   996 */     str1 = null;
/*   997 */     if (paramProperties != null)
/*       */     {
/*   999 */       str1 = paramProperties.getProperty("oracle.net.authentication_services");
/*       */     }
/*  1001 */     if (str1 == null)
/*  1002 */       str1 = getSystemProperty("oracle.net.authentication_services", (String)null); 
/*  1003 */     if (str1 == null) {
/*  1004 */       str1 = null;
/*       */     }
/*       */     
/*  1007 */     this.thinNetAuthenticationServices = str1;
/*       */ 
/*       */     
/*  1010 */     str1 = null;
/*  1011 */     if (paramProperties != null)
/*       */     {
/*  1013 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_mutual_authentication");
/*       */     }
/*  1015 */     if (str1 == null)
/*  1016 */       str1 = getSystemProperty("oracle.net.kerberos5_mutual_authentication", (String)null); 
/*  1017 */     if (str1 == null) {
/*  1018 */       str1 = null;
/*       */     }
/*       */     
/*  1021 */     this.thinNetAuthenticationKrb5Mutual = str1;
/*       */ 
/*       */     
/*  1024 */     str1 = null;
/*  1025 */     if (paramProperties != null)
/*       */     {
/*  1027 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_cc_name");
/*       */     }
/*  1029 */     if (str1 == null)
/*  1030 */       str1 = getSystemProperty("oracle.net.kerberos5_cc_name", (String)null); 
/*  1031 */     if (str1 == null) {
/*  1032 */       str1 = null;
/*       */     }
/*       */     
/*  1035 */     this.thinNetAuthenticationKrb5CcName = str1;
/*       */ 
/*       */     
/*  1038 */     str1 = null;
/*  1039 */     if (paramProperties != null)
/*       */     {
/*  1041 */       str1 = paramProperties.getProperty("oracle.net.encryption_client");
/*       */     }
/*  1043 */     if (str1 == null)
/*  1044 */       str1 = getSystemProperty("oracle.net.encryption_client", (String)null); 
/*  1045 */     if (str1 == null) {
/*  1046 */       str1 = null;
/*       */     }
/*       */     
/*  1049 */     this.thinNetEncryptionLevel = str1;
/*       */ 
/*       */     
/*  1052 */     str1 = null;
/*  1053 */     if (paramProperties != null)
/*       */     {
/*  1055 */       str1 = paramProperties.getProperty("oracle.net.encryption_types_client");
/*       */     }
/*  1057 */     if (str1 == null)
/*  1058 */       str1 = getSystemProperty("oracle.net.encryption_types_client", (String)null); 
/*  1059 */     if (str1 == null) {
/*  1060 */       str1 = null;
/*       */     }
/*       */     
/*  1063 */     this.thinNetEncryptionTypes = str1;
/*       */ 
/*       */     
/*  1066 */     str1 = null;
/*  1067 */     if (paramProperties != null)
/*       */     {
/*  1069 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_client");
/*       */     }
/*  1071 */     if (str1 == null)
/*  1072 */       str1 = getSystemProperty("oracle.net.crypto_checksum_client", (String)null); 
/*  1073 */     if (str1 == null) {
/*  1074 */       str1 = null;
/*       */     }
/*       */     
/*  1077 */     this.thinNetChecksumLevel = str1;
/*       */ 
/*       */     
/*  1080 */     str1 = null;
/*  1081 */     if (paramProperties != null)
/*       */     {
/*  1083 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_types_client");
/*       */     }
/*  1085 */     if (str1 == null)
/*  1086 */       str1 = getSystemProperty("oracle.net.crypto_checksum_types_client", (String)null); 
/*  1087 */     if (str1 == null) {
/*  1088 */       str1 = null;
/*       */     }
/*       */     
/*  1091 */     this.thinNetChecksumTypes = str1;
/*       */ 
/*       */     
/*  1094 */     str1 = null;
/*  1095 */     if (paramProperties != null)
/*       */     {
/*  1097 */       str1 = paramProperties.getProperty("oracle.net.crypto_seed");
/*       */     }
/*  1099 */     if (str1 == null)
/*  1100 */       str1 = getSystemProperty("oracle.net.crypto_seed", (String)null); 
/*  1101 */     if (str1 == null) {
/*  1102 */       str1 = null;
/*       */     }
/*       */     
/*  1105 */     this.thinNetCryptoSeed = str1;
/*       */ 
/*       */     
/*  1108 */     str1 = null;
/*  1109 */     if (paramProperties != null)
/*       */     {
/*  1111 */       str1 = paramProperties.getProperty("oracle.jdbc.TcpNoDelay");
/*       */     }
/*  1113 */     if (str1 == null)
/*  1114 */       str1 = getSystemProperty("oracle.jdbc.TcpNoDelay", (String)null); 
/*  1115 */     if (str1 == null) {
/*  1116 */       str1 = "false";
/*       */     }
/*       */     
/*  1119 */     this.thinTcpNoDelay = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1122 */     str1 = null;
/*  1123 */     if (paramProperties != null)
/*       */     {
/*  1125 */       str1 = paramProperties.getProperty("oracle.jdbc.ReadTimeout");
/*       */     }
/*  1127 */     if (str1 == null)
/*  1128 */       str1 = getSystemProperty("oracle.jdbc.ReadTimeout", (String)null); 
/*  1129 */     if (str1 == null) {
/*  1130 */       str1 = null;
/*       */     }
/*       */     
/*  1133 */     this.thinReadTimeout = str1;
/*       */ 
/*       */     
/*  1136 */     str1 = null;
/*  1137 */     if (paramProperties != null)
/*       */     {
/*  1139 */       str1 = paramProperties.getProperty("oracle.net.CONNECT_TIMEOUT");
/*       */     }
/*  1141 */     if (str1 == null)
/*  1142 */       str1 = getSystemProperty("oracle.net.CONNECT_TIMEOUT", (String)null); 
/*  1143 */     if (str1 == null) {
/*  1144 */       str1 = null;
/*       */     }
/*       */     
/*  1147 */     this.thinNetConnectTimeout = str1;
/*       */ 
/*       */     
/*  1150 */     str1 = null;
/*  1151 */     if (paramProperties != null)
/*       */     {
/*  1153 */       str1 = paramProperties.getProperty("oracle.net.disableOob");
/*       */     }
/*  1155 */     if (str1 == null)
/*  1156 */       str1 = getSystemProperty("oracle.net.disableOob", (String)null); 
/*  1157 */     if (str1 == null) {
/*  1158 */       str1 = "false";
/*       */     }
/*       */     
/*  1161 */     this.thinNetDisableOutOfBandBreak = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1164 */     str1 = null;
/*  1165 */     if (paramProperties != null)
/*       */     {
/*  1167 */       str1 = paramProperties.getProperty("oracle.net.useZeroCopyIO");
/*       */     }
/*  1169 */     if (str1 == null)
/*  1170 */       str1 = getSystemProperty("oracle.net.useZeroCopyIO", (String)null); 
/*  1171 */     if (str1 == null) {
/*  1172 */       str1 = "true";
/*       */     }
/*       */     
/*  1175 */     this.thinNetUseZeroCopyIO = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1178 */     str1 = null;
/*  1179 */     if (paramProperties != null)
/*       */     {
/*  1181 */       str1 = paramProperties.getProperty("oracle.net.SDP");
/*       */     }
/*  1183 */     if (str1 == null)
/*  1184 */       str1 = getSystemProperty("oracle.net.SDP", (String)null); 
/*  1185 */     if (str1 == null) {
/*  1186 */       str1 = "false";
/*       */     }
/*       */     
/*  1189 */     this.thinNetEnableSDP = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1192 */     str1 = null;
/*  1193 */     if (paramProperties != null)
/*       */     {
/*  1195 */       str1 = paramProperties.getProperty("oracle.jdbc.use1900AsYearForTime");
/*       */     }
/*  1197 */     if (str1 == null)
/*  1198 */       str1 = getSystemProperty("oracle.jdbc.use1900AsYearForTime", (String)null); 
/*  1199 */     if (str1 == null) {
/*  1200 */       str1 = "false";
/*       */     }
/*       */     
/*  1203 */     this.use1900AsYearForTime = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1206 */     str1 = null;
/*  1207 */     if (paramProperties != null)
/*       */     {
/*  1209 */       str1 = paramProperties.getProperty("oracle.jdbc.timestampTzInGmt");
/*       */     }
/*  1211 */     if (str1 == null)
/*  1212 */       str1 = getSystemProperty("oracle.jdbc.timestampTzInGmt", (String)null); 
/*  1213 */     if (str1 == null) {
/*  1214 */       str1 = "true";
/*       */     }
/*       */     
/*  1217 */     this.timestamptzInGmt = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1220 */     str1 = null;
/*  1221 */     if (paramProperties != null)
/*       */     {
/*  1223 */       str1 = paramProperties.getProperty("oracle.jdbc.timezoneAsRegion");
/*       */     }
/*  1225 */     if (str1 == null)
/*  1226 */       str1 = getSystemProperty("oracle.jdbc.timezoneAsRegion", (String)null); 
/*  1227 */     if (str1 == null) {
/*  1228 */       str1 = "true";
/*       */     }
/*       */     
/*  1231 */     this.timezoneAsRegion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1234 */     str1 = null;
/*  1235 */     if (paramProperties != null)
/*       */     {
/*  1237 */       str1 = paramProperties.getProperty("oracle.net.ssl_server_dn_match");
/*       */     }
/*  1239 */     if (str1 == null)
/*  1240 */       str1 = getSystemProperty("oracle.net.ssl_server_dn_match", (String)null); 
/*  1241 */     if (str1 == null) {
/*  1242 */       str1 = null;
/*       */     }
/*       */     
/*  1245 */     this.thinSslServerDnMatch = str1;
/*       */ 
/*       */     
/*  1248 */     str1 = null;
/*  1249 */     if (paramProperties != null)
/*       */     {
/*  1251 */       str1 = paramProperties.getProperty("oracle.net.ssl_version");
/*       */     }
/*  1253 */     if (str1 == null)
/*  1254 */       str1 = getSystemProperty("oracle.net.ssl_version", (String)null); 
/*  1255 */     if (str1 == null) {
/*  1256 */       str1 = null;
/*       */     }
/*       */     
/*  1259 */     this.thinSslVersion = str1;
/*       */ 
/*       */     
/*  1262 */     str1 = null;
/*  1263 */     if (paramProperties != null)
/*       */     {
/*  1265 */       str1 = paramProperties.getProperty("oracle.net.ssl_cipher_suites");
/*       */     }
/*  1267 */     if (str1 == null)
/*  1268 */       str1 = getSystemProperty("oracle.net.ssl_cipher_suites", (String)null); 
/*  1269 */     if (str1 == null) {
/*  1270 */       str1 = null;
/*       */     }
/*       */     
/*  1273 */     this.thinSslCipherSuites = str1;
/*       */ 
/*       */     
/*  1276 */     str1 = null;
/*  1277 */     if (paramProperties != null)
/*       */     {
/*  1279 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStore");
/*       */     }
/*  1281 */     if (str1 == null)
/*  1282 */       str1 = getSystemProperty("javax.net.ssl.keyStore", (String)null); 
/*  1283 */     if (str1 == null) {
/*  1284 */       str1 = null;
/*       */     }
/*       */     
/*  1287 */     this.thinJavaxNetSslKeystore = str1;
/*       */ 
/*       */     
/*  1290 */     str1 = null;
/*  1291 */     if (paramProperties != null)
/*       */     {
/*  1293 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStoreType");
/*       */     }
/*  1295 */     if (str1 == null)
/*  1296 */       str1 = getSystemProperty("javax.net.ssl.keyStoreType", (String)null); 
/*  1297 */     if (str1 == null) {
/*  1298 */       str1 = null;
/*       */     }
/*       */     
/*  1301 */     this.thinJavaxNetSslKeystoretype = str1;
/*       */ 
/*       */     
/*  1304 */     str1 = null;
/*  1305 */     if (paramProperties != null)
/*       */     {
/*  1307 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStorePassword");
/*       */     }
/*  1309 */     if (str1 == null)
/*  1310 */       str1 = getSystemProperty("javax.net.ssl.keyStorePassword", (String)null); 
/*  1311 */     if (str1 == null) {
/*  1312 */       str1 = null;
/*       */     }
/*       */     
/*  1315 */     this.thinJavaxNetSslKeystorepassword = str1;
/*       */ 
/*       */     
/*  1318 */     str1 = null;
/*  1319 */     if (paramProperties != null)
/*       */     {
/*  1321 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStore");
/*       */     }
/*  1323 */     if (str1 == null)
/*  1324 */       str1 = getSystemProperty("javax.net.ssl.trustStore", (String)null); 
/*  1325 */     if (str1 == null) {
/*  1326 */       str1 = null;
/*       */     }
/*       */     
/*  1329 */     this.thinJavaxNetSslTruststore = str1;
/*       */ 
/*       */     
/*  1332 */     str1 = null;
/*  1333 */     if (paramProperties != null)
/*       */     {
/*  1335 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStoreType");
/*       */     }
/*  1337 */     if (str1 == null)
/*  1338 */       str1 = getSystemProperty("javax.net.ssl.trustStoreType", (String)null); 
/*  1339 */     if (str1 == null) {
/*  1340 */       str1 = null;
/*       */     }
/*       */     
/*  1343 */     this.thinJavaxNetSslTruststoretype = str1;
/*       */ 
/*       */     
/*  1346 */     str1 = null;
/*  1347 */     if (paramProperties != null)
/*       */     {
/*  1349 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStorePassword");
/*       */     }
/*  1351 */     if (str1 == null)
/*  1352 */       str1 = getSystemProperty("javax.net.ssl.trustStorePassword", (String)null); 
/*  1353 */     if (str1 == null) {
/*  1354 */       str1 = null;
/*       */     }
/*       */     
/*  1357 */     this.thinJavaxNetSslTruststorepassword = str1;
/*       */ 
/*       */     
/*  1360 */     str1 = null;
/*  1361 */     if (paramProperties != null) {
/*       */       
/*  1363 */       str1 = paramProperties.getProperty("ssl.keyManagerFactory.algorithm");
/*  1364 */       if (str1 == null)
/*  1365 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm"); 
/*       */     } 
/*  1367 */     if (str1 == null)
/*  1368 */       str1 = getSystemProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm", (String)null); 
/*  1369 */     if (str1 == null) {
/*  1370 */       str1 = null;
/*       */     }
/*       */     
/*  1373 */     this.thinSslKeymanagerfactoryAlgorithm = str1;
/*       */ 
/*       */     
/*  1376 */     str1 = null;
/*  1377 */     if (paramProperties != null) {
/*       */       
/*  1379 */       str1 = paramProperties.getProperty("ssl.trustManagerFactory.algorithm");
/*  1380 */       if (str1 == null)
/*  1381 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm"); 
/*       */     } 
/*  1383 */     if (str1 == null)
/*  1384 */       str1 = getSystemProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm", (String)null); 
/*  1385 */     if (str1 == null) {
/*  1386 */       str1 = null;
/*       */     }
/*       */     
/*  1389 */     this.thinSslTrustmanagerfactoryAlgorithm = str1;
/*       */ 
/*       */     
/*  1392 */     str1 = null;
/*  1393 */     if (paramProperties != null)
/*       */     {
/*  1395 */       str1 = paramProperties.getProperty("oracle.net.oldSyntax");
/*       */     }
/*  1397 */     if (str1 == null)
/*  1398 */       str1 = getSystemProperty("oracle.net.oldSyntax", (String)null); 
/*  1399 */     if (str1 == null) {
/*  1400 */       str1 = null;
/*       */     }
/*       */     
/*  1403 */     this.thinNetOldsyntax = str1;
/*       */ 
/*       */     
/*  1406 */     str1 = null;
/*  1407 */     if (paramProperties != null)
/*       */     {
/*  1409 */       str1 = paramProperties.getProperty("java.naming.factory.initial");
/*       */     }
/*  1411 */     if (str1 == null) {
/*  1412 */       str1 = null;
/*       */     }
/*       */     
/*  1415 */     this.thinNamingContextInitial = str1;
/*       */ 
/*       */     
/*  1418 */     str1 = null;
/*  1419 */     if (paramProperties != null)
/*       */     {
/*  1421 */       str1 = paramProperties.getProperty("java.naming.provider.url");
/*       */     }
/*  1423 */     if (str1 == null) {
/*  1424 */       str1 = null;
/*       */     }
/*       */     
/*  1427 */     this.thinNamingProviderUrl = str1;
/*       */ 
/*       */     
/*  1430 */     str1 = null;
/*  1431 */     if (paramProperties != null)
/*       */     {
/*  1433 */       str1 = paramProperties.getProperty("java.naming.security.authentication");
/*       */     }
/*  1435 */     if (str1 == null) {
/*  1436 */       str1 = null;
/*       */     }
/*       */     
/*  1439 */     this.thinNamingSecurityAuthentication = str1;
/*       */ 
/*       */     
/*  1442 */     str1 = null;
/*  1443 */     if (paramProperties != null)
/*       */     {
/*  1445 */       str1 = paramProperties.getProperty("java.naming.security.principal");
/*       */     }
/*  1447 */     if (str1 == null) {
/*  1448 */       str1 = null;
/*       */     }
/*       */     
/*  1451 */     this.thinNamingSecurityPrincipal = str1;
/*       */ 
/*       */     
/*  1454 */     str1 = null;
/*  1455 */     if (paramProperties != null)
/*       */     {
/*  1457 */       str1 = paramProperties.getProperty("java.naming.security.credentials");
/*       */     }
/*  1459 */     if (str1 == null) {
/*  1460 */       str1 = null;
/*       */     }
/*       */     
/*  1463 */     this.thinNamingSecurityCredentials = str1;
/*       */ 
/*       */     
/*  1466 */     str1 = null;
/*  1467 */     if (paramProperties != null)
/*       */     {
/*  1469 */       str1 = paramProperties.getProperty("oracle.net.wallet_location");
/*       */     }
/*  1471 */     if (str1 == null)
/*  1472 */       str1 = getSystemProperty("oracle.net.wallet_location", (String)null); 
/*  1473 */     if (str1 == null) {
/*  1474 */       str1 = null;
/*       */     }
/*       */     
/*  1477 */     this.walletLocation = str1;
/*       */ 
/*       */     
/*  1480 */     str1 = null;
/*  1481 */     if (paramProperties != null)
/*       */     {
/*  1483 */       str1 = paramProperties.getProperty("oracle.net.wallet_password");
/*       */     }
/*  1485 */     if (str1 == null)
/*  1486 */       str1 = getSystemProperty("oracle.net.wallet_password", (String)null); 
/*  1487 */     if (str1 == null) {
/*  1488 */       str1 = null;
/*       */     }
/*       */     
/*  1491 */     this.walletPassword = str1;
/*       */ 
/*       */     
/*  1494 */     str1 = null;
/*  1495 */     if (paramProperties != null)
/*       */     {
/*  1497 */       str1 = paramProperties.getProperty("oracle.jdbc.proxyClientName");
/*       */     }
/*  1499 */     if (str1 == null)
/*  1500 */       str1 = getSystemProperty("oracle.jdbc.proxyClientName", (String)null); 
/*  1501 */     if (str1 == null) {
/*  1502 */       str1 = null;
/*       */     }
/*       */     
/*  1505 */     this.proxyClientName = str1;
/*       */ 
/*       */     
/*  1508 */     str1 = null;
/*  1509 */     if (paramProperties != null)
/*       */     {
/*  1511 */       str1 = paramProperties.getProperty("oracle.jdbc.useNio");
/*       */     }
/*  1513 */     if (str1 == null)
/*  1514 */       str1 = getSystemProperty("oracle.jdbc.useNio", (String)null); 
/*  1515 */     if (str1 == null) {
/*  1516 */       str1 = "false";
/*       */     }
/*       */     
/*  1519 */     this.useNio = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1522 */     str1 = null;
/*  1523 */     if (paramProperties != null) {
/*       */       
/*  1525 */       str1 = paramProperties.getProperty("JDBCDriverCharSetId");
/*  1526 */       if (str1 == null)
/*  1527 */         str1 = paramProperties.getProperty("oracle.jdbc.JDBCDriverCharSetId"); 
/*       */     } 
/*  1529 */     if (str1 == null)
/*  1530 */       str1 = getSystemProperty("oracle.jdbc.JDBCDriverCharSetId", (String)null); 
/*  1531 */     if (str1 == null) {
/*  1532 */       str1 = null;
/*       */     }
/*       */     
/*  1535 */     this.ociDriverCharset = str1;
/*       */ 
/*       */     
/*  1538 */     str1 = null;
/*  1539 */     if (paramProperties != null)
/*       */     {
/*  1541 */       str1 = paramProperties.getProperty("oracle.jdbc.editionName");
/*       */     }
/*  1543 */     if (str1 == null)
/*  1544 */       str1 = getSystemProperty("oracle.jdbc.editionName", (String)null); 
/*  1545 */     if (str1 == null) {
/*  1546 */       str1 = null;
/*       */     }
/*       */     
/*  1549 */     this.editionName = str1;
/*       */ 
/*       */     
/*  1552 */     str1 = null;
/*  1553 */     if (paramProperties != null)
/*       */     {
/*  1555 */       str1 = paramProperties.getProperty("oracle.jdbc.thinLogonCapability");
/*       */     }
/*  1557 */     if (str1 == null)
/*  1558 */       str1 = getSystemProperty("oracle.jdbc.thinLogonCapability", (String)null); 
/*  1559 */     if (str1 == null) {
/*  1560 */       str1 = "o5";
/*       */     }
/*       */     
/*  1563 */     this.logonCap = str1;
/*       */ 
/*       */     
/*  1566 */     str1 = null;
/*  1567 */     if (paramProperties != null) {
/*       */       
/*  1569 */       str1 = paramProperties.getProperty("internal_logon");
/*  1570 */       if (str1 == null)
/*  1571 */         str1 = paramProperties.getProperty("oracle.jdbc.internal_logon"); 
/*       */     } 
/*  1573 */     if (str1 == null)
/*  1574 */       str1 = getSystemProperty("oracle.jdbc.internal_logon", (String)null); 
/*  1575 */     if (str1 == null) {
/*  1576 */       str1 = null;
/*       */     }
/*       */     
/*  1579 */     this.internalLogon = str1;
/*       */ 
/*       */     
/*  1582 */     str1 = null;
/*  1583 */     if (paramProperties != null)
/*       */     {
/*  1585 */       str1 = paramProperties.getProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName");
/*       */     }
/*  1587 */     if (str1 == null)
/*  1588 */       str1 = getSystemProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName", (String)null); 
/*  1589 */     if (str1 == null) {
/*  1590 */       str1 = "false";
/*       */     }
/*       */     
/*  1593 */     this.createDescriptorUseCurrentSchemaForSchemaName = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1596 */     str1 = null;
/*  1597 */     if (paramProperties != null) {
/*       */       
/*  1599 */       str1 = paramProperties.getProperty("OCISvcCtxHandle");
/*  1600 */       if (str1 == null)
/*  1601 */         str1 = paramProperties.getProperty("oracle.jdbc.OCISvcCtxHandle"); 
/*       */     } 
/*  1603 */     if (str1 == null)
/*  1604 */       str1 = getSystemProperty("oracle.jdbc.OCISvcCtxHandle", (String)null); 
/*  1605 */     if (str1 == null) {
/*  1606 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1609 */       this.ociSvcCtxHandle = Long.parseLong(str1);
/*  1610 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1614 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociSvcCtxHandle'");
/*  1615 */       sQLException.fillInStackTrace();
/*  1616 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1622 */     str1 = null;
/*  1623 */     if (paramProperties != null) {
/*       */       
/*  1625 */       str1 = paramProperties.getProperty("OCIEnvHandle");
/*  1626 */       if (str1 == null)
/*  1627 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIEnvHandle"); 
/*       */     } 
/*  1629 */     if (str1 == null)
/*  1630 */       str1 = getSystemProperty("oracle.jdbc.OCIEnvHandle", (String)null); 
/*  1631 */     if (str1 == null) {
/*  1632 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1635 */       this.ociEnvHandle = Long.parseLong(str1);
/*  1636 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1640 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociEnvHandle'");
/*  1641 */       sQLException.fillInStackTrace();
/*  1642 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1648 */     str1 = null;
/*  1649 */     if (paramProperties != null) {
/*       */       
/*  1651 */       str1 = paramProperties.getProperty("OCIErrHandle");
/*  1652 */       if (str1 == null)
/*  1653 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIErrHandle"); 
/*       */     } 
/*  1655 */     if (str1 == null)
/*  1656 */       str1 = getSystemProperty("oracle.jdbc.OCIErrHandle", (String)null); 
/*  1657 */     if (str1 == null) {
/*  1658 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1661 */       this.ociErrHandle = Long.parseLong(str1);
/*  1662 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1666 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociErrHandle'");
/*  1667 */       sQLException.fillInStackTrace();
/*  1668 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1674 */     str1 = null;
/*  1675 */     if (paramProperties != null) {
/*       */       
/*  1677 */       str1 = paramProperties.getProperty("prelim_auth");
/*  1678 */       if (str1 == null)
/*  1679 */         str1 = paramProperties.getProperty("oracle.jdbc.prelim_auth"); 
/*       */     } 
/*  1681 */     if (str1 == null)
/*  1682 */       str1 = getSystemProperty("oracle.jdbc.prelim_auth", (String)null); 
/*  1683 */     if (str1 == null) {
/*  1684 */       str1 = "false";
/*       */     }
/*       */     
/*  1687 */     this.prelimAuth = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1690 */     str1 = null;
/*  1691 */     if (paramProperties != null)
/*       */     {
/*  1693 */       str1 = paramProperties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
/*       */     }
/*  1695 */     if (str1 == null)
/*  1696 */       str1 = getSystemProperty("oracle.jdbc.ociNlsLangBackwardCompatible", (String)null); 
/*  1697 */     if (str1 == null) {
/*  1698 */       str1 = "false";
/*       */     }
/*       */     
/*  1701 */     this.nlsLangBackdoor = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1704 */     str1 = null;
/*  1705 */     if (paramProperties != null) {
/*       */       
/*  1707 */       str1 = paramProperties.getProperty("OCINewPassword");
/*  1708 */       if (str1 == null)
/*  1709 */         str1 = paramProperties.getProperty("oracle.jdbc.OCINewPassword"); 
/*       */     } 
/*  1711 */     if (str1 == null)
/*  1712 */       str1 = getSystemProperty("oracle.jdbc.OCINewPassword", (String)null); 
/*  1713 */     if (str1 == null) {
/*  1714 */       str1 = null;
/*       */     }
/*       */     
/*  1717 */     this.setNewPassword = str1;
/*       */ 
/*       */     
/*  1720 */     str1 = null;
/*  1721 */     if (paramProperties != null)
/*       */     {
/*  1723 */       str1 = paramProperties.getProperty("oracle.jdbc.spawnNewThreadToCancel");
/*       */     }
/*  1725 */     if (str1 == null)
/*  1726 */       str1 = getSystemProperty("oracle.jdbc.spawnNewThreadToCancel", (String)null); 
/*  1727 */     if (str1 == null) {
/*  1728 */       str1 = "false";
/*       */     }
/*       */     
/*  1731 */     this.spawnNewThreadToCancel = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1734 */     str1 = null;
/*  1735 */     if (paramProperties != null) {
/*       */       
/*  1737 */       str1 = paramProperties.getProperty("defaultExecuteBatch");
/*  1738 */       if (str1 == null)
/*  1739 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultExecuteBatch"); 
/*       */     } 
/*  1741 */     if (str1 == null)
/*  1742 */       str1 = getSystemProperty("oracle.jdbc.defaultExecuteBatch", (String)null); 
/*  1743 */     if (str1 == null) {
/*  1744 */       str1 = "1";
/*       */     }
/*       */     try {
/*  1747 */       this.defaultExecuteBatch = Integer.parseInt(str1);
/*  1748 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1752 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultExecuteBatch'");
/*  1753 */       sQLException.fillInStackTrace();
/*  1754 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1760 */     str1 = null;
/*  1761 */     if (paramProperties != null) {
/*       */       
/*  1763 */       str1 = paramProperties.getProperty("defaultRowPrefetch");
/*  1764 */       if (str1 == null)
/*  1765 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultRowPrefetch"); 
/*       */     } 
/*  1767 */     if (str1 == null)
/*  1768 */       str1 = getSystemProperty("oracle.jdbc.defaultRowPrefetch", (String)null); 
/*  1769 */     if (str1 == null) {
/*  1770 */       str1 = "10";
/*       */     }
/*       */     try {
/*  1773 */       this.defaultRowPrefetch = Integer.parseInt(str1);
/*  1774 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1778 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultRowPrefetch'");
/*  1779 */       sQLException.fillInStackTrace();
/*  1780 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1786 */     str1 = null;
/*  1787 */     if (paramProperties != null)
/*       */     {
/*  1789 */       str1 = paramProperties.getProperty("oracle.jdbc.defaultLobPrefetchSize");
/*       */     }
/*  1791 */     if (str1 == null)
/*  1792 */       str1 = getSystemProperty("oracle.jdbc.defaultLobPrefetchSize", (String)null); 
/*  1793 */     if (str1 == null) {
/*  1794 */       str1 = "4000";
/*       */     }
/*       */     try {
/*  1797 */       this.defaultLobPrefetchSize = Integer.parseInt(str1);
/*  1798 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1802 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultLobPrefetchSize'");
/*  1803 */       sQLException.fillInStackTrace();
/*  1804 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1810 */     str1 = null;
/*  1811 */     if (paramProperties != null)
/*       */     {
/*  1813 */       str1 = paramProperties.getProperty("oracle.jdbc.enableDataInLocator");
/*       */     }
/*  1815 */     if (str1 == null)
/*  1816 */       str1 = getSystemProperty("oracle.jdbc.enableDataInLocator", (String)null); 
/*  1817 */     if (str1 == null) {
/*  1818 */       str1 = "true";
/*       */     }
/*       */     
/*  1821 */     this.enableDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1824 */     str1 = null;
/*  1825 */     if (paramProperties != null)
/*       */     {
/*  1827 */       str1 = paramProperties.getProperty("oracle.jdbc.enableReadDataInLocator");
/*       */     }
/*  1829 */     if (str1 == null)
/*  1830 */       str1 = getSystemProperty("oracle.jdbc.enableReadDataInLocator", (String)null); 
/*  1831 */     if (str1 == null) {
/*  1832 */       str1 = "true";
/*       */     }
/*       */     
/*  1835 */     this.enableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1838 */     str1 = null;
/*  1839 */     if (paramProperties != null)
/*       */     {
/*  1841 */       str1 = paramProperties.getProperty("oracle.jdbc.overrideEnableReadDataInLocator");
/*       */     }
/*  1843 */     if (str1 == null)
/*  1844 */       str1 = getSystemProperty("oracle.jdbc.overrideEnableReadDataInLocator", (String)null); 
/*  1845 */     if (str1 == null) {
/*  1846 */       str1 = "false";
/*       */     }
/*       */     
/*  1849 */     this.overrideEnableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1852 */     str1 = null;
/*  1853 */     if (paramProperties != null) {
/*       */       
/*  1855 */       str1 = paramProperties.getProperty("remarksReporting");
/*  1856 */       if (str1 == null)
/*  1857 */         str1 = paramProperties.getProperty("oracle.jdbc.remarksReporting"); 
/*       */     } 
/*  1859 */     if (str1 == null)
/*  1860 */       str1 = getSystemProperty("oracle.jdbc.remarksReporting", (String)null); 
/*  1861 */     if (str1 == null) {
/*  1862 */       str1 = "false";
/*       */     }
/*       */     
/*  1865 */     this.reportRemarks = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1868 */     str1 = null;
/*  1869 */     if (paramProperties != null) {
/*       */       
/*  1871 */       str1 = paramProperties.getProperty("includeSynonyms");
/*  1872 */       if (str1 == null)
/*  1873 */         str1 = paramProperties.getProperty("oracle.jdbc.includeSynonyms"); 
/*       */     } 
/*  1875 */     if (str1 == null)
/*  1876 */       str1 = getSystemProperty("oracle.jdbc.includeSynonyms", (String)null); 
/*  1877 */     if (str1 == null) {
/*  1878 */       str1 = "false";
/*       */     }
/*       */     
/*  1881 */     this.includeSynonyms = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1884 */     str1 = null;
/*  1885 */     if (paramProperties != null) {
/*       */       
/*  1887 */       str1 = paramProperties.getProperty("restrictGetTables");
/*  1888 */       if (str1 == null)
/*  1889 */         str1 = paramProperties.getProperty("oracle.jdbc.restrictGetTables"); 
/*       */     } 
/*  1891 */     if (str1 == null)
/*  1892 */       str1 = getSystemProperty("oracle.jdbc.restrictGetTables", (String)null); 
/*  1893 */     if (str1 == null) {
/*  1894 */       str1 = "false";
/*       */     }
/*       */     
/*  1897 */     this.restrictGettables = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1900 */     str1 = null;
/*  1901 */     if (paramProperties != null) {
/*       */       
/*  1903 */       str1 = paramProperties.getProperty("AccumulateBatchResult");
/*  1904 */       if (str1 == null)
/*  1905 */         str1 = paramProperties.getProperty("oracle.jdbc.AccumulateBatchResult"); 
/*       */     } 
/*  1907 */     if (str1 == null)
/*  1908 */       str1 = getSystemProperty("oracle.jdbc.AccumulateBatchResult", (String)null); 
/*  1909 */     if (str1 == null) {
/*  1910 */       str1 = "true";
/*       */     }
/*       */     
/*  1913 */     this.accumulateBatchResult = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1916 */     str1 = null;
/*  1917 */     if (paramProperties != null) {
/*       */       
/*  1919 */       str1 = paramProperties.getProperty("useFetchSizeWithLongColumn");
/*  1920 */       if (str1 == null)
/*  1921 */         str1 = paramProperties.getProperty("oracle.jdbc.useFetchSizeWithLongColumn"); 
/*       */     } 
/*  1923 */     if (str1 == null)
/*  1924 */       str1 = getSystemProperty("oracle.jdbc.useFetchSizeWithLongColumn", (String)null); 
/*  1925 */     if (str1 == null) {
/*  1926 */       str1 = "false";
/*       */     }
/*       */     
/*  1929 */     this.useFetchSizeWithLongColumn = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1932 */     str1 = null;
/*  1933 */     if (paramProperties != null) {
/*       */       
/*  1935 */       str1 = paramProperties.getProperty("processEscapes");
/*  1936 */       if (str1 == null)
/*  1937 */         str1 = paramProperties.getProperty("oracle.jdbc.processEscapes"); 
/*       */     } 
/*  1939 */     if (str1 == null)
/*  1940 */       str1 = getSystemProperty("oracle.jdbc.processEscapes", (String)null); 
/*  1941 */     if (str1 == null) {
/*  1942 */       str1 = "true";
/*       */     }
/*       */     
/*  1945 */     this.processEscapes = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1948 */     str1 = null;
/*  1949 */     if (paramProperties != null) {
/*       */       
/*  1951 */       str1 = paramProperties.getProperty("fixedString");
/*  1952 */       if (str1 == null)
/*  1953 */         str1 = paramProperties.getProperty("oracle.jdbc.fixedString"); 
/*       */     } 
/*  1955 */     if (str1 == null)
/*  1956 */       str1 = getSystemProperty("oracle.jdbc.fixedString", (String)null); 
/*  1957 */     if (str1 == null) {
/*  1958 */       str1 = "false";
/*       */     }
/*       */     
/*  1961 */     this.fixedString = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1964 */     str1 = null;
/*  1965 */     if (paramProperties != null) {
/*       */       
/*  1967 */       str1 = paramProperties.getProperty("defaultNChar");
/*  1968 */       if (str1 == null)
/*  1969 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultNChar"); 
/*       */     } 
/*  1971 */     if (str1 == null)
/*  1972 */       str1 = getSystemProperty("oracle.jdbc.defaultNChar", (String)null); 
/*  1973 */     if (str1 == null) {
/*  1974 */       str1 = "false";
/*       */     }
/*       */     
/*  1977 */     this.defaultnchar = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1980 */     str1 = null;
/*  1981 */     if (paramProperties != null)
/*       */     {
/*  1983 */       str1 = paramProperties.getProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch");
/*       */     }
/*  1985 */     if (str1 == null)
/*  1986 */       str1 = getSystemProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch", (String)null); 
/*  1987 */     if (str1 == null) {
/*  1988 */       str1 = "false";
/*       */     }
/*       */     
/*  1991 */     this.permitTimestampDateMismatch = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1994 */     str1 = null;
/*  1995 */     if (paramProperties != null) {
/*       */       
/*  1997 */       str1 = paramProperties.getProperty("RessourceManagerId");
/*  1998 */       if (str1 == null)
/*  1999 */         str1 = paramProperties.getProperty("oracle.jdbc.RessourceManagerId"); 
/*       */     } 
/*  2001 */     if (str1 == null)
/*  2002 */       str1 = getSystemProperty("oracle.jdbc.RessourceManagerId", (String)null); 
/*  2003 */     if (str1 == null) {
/*  2004 */       str1 = "0000";
/*       */     }
/*       */     
/*  2007 */     this.resourceManagerId = str1;
/*       */ 
/*       */     
/*  2010 */     str1 = null;
/*  2011 */     if (paramProperties != null) {
/*       */       
/*  2013 */       str1 = paramProperties.getProperty("disableDefineColumnType");
/*  2014 */       if (str1 == null)
/*  2015 */         str1 = paramProperties.getProperty("oracle.jdbc.disableDefineColumnType"); 
/*       */     } 
/*  2017 */     if (str1 == null)
/*  2018 */       str1 = getSystemProperty("oracle.jdbc.disableDefineColumnType", (String)null); 
/*  2019 */     if (str1 == null) {
/*  2020 */       str1 = "false";
/*       */     }
/*       */     
/*  2023 */     this.disableDefinecolumntype = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2026 */     str1 = null;
/*  2027 */     if (paramProperties != null)
/*       */     {
/*  2029 */       str1 = paramProperties.getProperty("oracle.jdbc.convertNcharLiterals");
/*       */     }
/*  2031 */     if (str1 == null)
/*  2032 */       str1 = getSystemProperty("oracle.jdbc.convertNcharLiterals", (String)null); 
/*  2033 */     if (str1 == null) {
/*  2034 */       str1 = "false";
/*       */     }
/*       */     
/*  2037 */     this.convertNcharLiterals = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2040 */     str1 = null;
/*  2041 */     if (paramProperties != null)
/*       */     {
/*  2043 */       str1 = paramProperties.getProperty("oracle.jdbc.J2EE13Compliant");
/*       */     }
/*  2045 */     if (str1 == null)
/*  2046 */       str1 = getSystemProperty("oracle.jdbc.J2EE13Compliant", (String)null); 
/*  2047 */     if (str1 == null) {
/*  2048 */       str1 = "false";
/*       */     }
/*       */     
/*  2051 */     this.j2ee13Compliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2054 */     str1 = null;
/*  2055 */     if (paramProperties != null)
/*       */     {
/*  2057 */       str1 = paramProperties.getProperty("oracle.jdbc.mapDateToTimestamp");
/*       */     }
/*  2059 */     if (str1 == null)
/*  2060 */       str1 = getSystemProperty("oracle.jdbc.mapDateToTimestamp", (String)null); 
/*  2061 */     if (str1 == null) {
/*  2062 */       str1 = "true";
/*       */     }
/*       */     
/*  2065 */     this.mapDateToTimestamp = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2068 */     str1 = null;
/*  2069 */     if (paramProperties != null)
/*       */     {
/*  2071 */       str1 = paramProperties.getProperty("oracle.jdbc.useThreadLocalBufferCache");
/*       */     }
/*  2073 */     if (str1 == null)
/*  2074 */       str1 = getSystemProperty("oracle.jdbc.useThreadLocalBufferCache", (String)null); 
/*  2075 */     if (str1 == null) {
/*  2076 */       str1 = "false";
/*       */     }
/*       */     
/*  2079 */     this.useThreadLocalBufferCache = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2082 */     str1 = null;
/*  2083 */     if (paramProperties != null)
/*       */     {
/*  2085 */       str1 = paramProperties.getProperty("oracle.jdbc.driverNameAttribute");
/*       */     }
/*  2087 */     if (str1 == null)
/*  2088 */       str1 = getSystemProperty("oracle.jdbc.driverNameAttribute", (String)null); 
/*  2089 */     if (str1 == null) {
/*  2090 */       str1 = null;
/*       */     }
/*       */     
/*  2093 */     this.driverNameAttribute = str1;
/*       */ 
/*       */     
/*  2096 */     str1 = null;
/*  2097 */     if (paramProperties != null)
/*       */     {
/*  2099 */       str1 = paramProperties.getProperty("oracle.jdbc.maxCachedBufferSize");
/*       */     }
/*  2101 */     if (str1 == null)
/*  2102 */       str1 = getSystemProperty("oracle.jdbc.maxCachedBufferSize", (String)null); 
/*  2103 */     if (str1 == null) {
/*  2104 */       str1 = "30";
/*       */     }
/*       */     try {
/*  2107 */       this.maxCachedBufferSize = Integer.parseInt(str1);
/*  2108 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2112 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'maxCachedBufferSize'");
/*  2113 */       sQLException.fillInStackTrace();
/*  2114 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2120 */     str1 = null;
/*  2121 */     if (paramProperties != null)
/*       */     {
/*  2123 */       str1 = paramProperties.getProperty("oracle.jdbc.implicitStatementCacheSize");
/*       */     }
/*  2125 */     if (str1 == null)
/*  2126 */       str1 = getSystemProperty("oracle.jdbc.implicitStatementCacheSize", (String)null); 
/*  2127 */     if (str1 == null) {
/*  2128 */       str1 = "0";
/*       */     }
/*       */     try {
/*  2131 */       this.implicitStatementCacheSize = Integer.parseInt(str1);
/*  2132 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2136 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'implicitStatementCacheSize'");
/*  2137 */       sQLException.fillInStackTrace();
/*  2138 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2144 */     str1 = null;
/*  2145 */     if (paramProperties != null)
/*       */     {
/*  2147 */       str1 = paramProperties.getProperty("oracle.jdbc.LobStreamPosStandardCompliant");
/*       */     }
/*  2149 */     if (str1 == null)
/*  2150 */       str1 = getSystemProperty("oracle.jdbc.LobStreamPosStandardCompliant", (String)null); 
/*  2151 */     if (str1 == null) {
/*  2152 */       str1 = "false";
/*       */     }
/*       */     
/*  2155 */     this.lobStreamPosStandardCompliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2158 */     str1 = null;
/*  2159 */     if (paramProperties != null)
/*       */     {
/*  2161 */       str1 = paramProperties.getProperty("oracle.jdbc.strictASCIIConversion");
/*       */     }
/*  2163 */     if (str1 == null)
/*  2164 */       str1 = getSystemProperty("oracle.jdbc.strictASCIIConversion", (String)null); 
/*  2165 */     if (str1 == null) {
/*  2166 */       str1 = "false";
/*       */     }
/*       */     
/*  2169 */     this.isStrictAsciiConversion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2172 */     str1 = null;
/*  2173 */     if (paramProperties != null)
/*       */     {
/*  2175 */       str1 = paramProperties.getProperty("oracle.jdbc.thinForceDNSLoadBalancing");
/*       */     }
/*  2177 */     if (str1 == null)
/*  2178 */       str1 = getSystemProperty("oracle.jdbc.thinForceDNSLoadBalancing", (String)null); 
/*  2179 */     if (str1 == null) {
/*  2180 */       str1 = "false";
/*       */     }
/*       */     
/*  2183 */     this.thinForceDnsLoadBalancing = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2186 */     str1 = null;
/*  2187 */     if (paramProperties != null)
/*       */     {
/*  2189 */       str1 = paramProperties.getProperty("oracle.jdbc.calculateChecksum");
/*       */     }
/*  2191 */     if (str1 == null)
/*  2192 */       str1 = getSystemProperty("oracle.jdbc.calculateChecksum", (String)null); 
/*  2193 */     if (str1 == null) {
/*  2194 */       str1 = "false";
/*       */     }
/*       */     
/*  2197 */     this.calculateChecksum = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2200 */     str1 = null;
/*  2201 */     if (paramProperties != null)
/*       */     {
/*  2203 */       str1 = paramProperties.getProperty("oracle.jdbc.enableJavaNetFastPath");
/*       */     }
/*  2205 */     if (str1 == null)
/*  2206 */       str1 = getSystemProperty("oracle.jdbc.enableJavaNetFastPath", (String)null); 
/*  2207 */     if (str1 == null) {
/*  2208 */       str1 = "false";
/*       */     }
/*       */     
/*  2211 */     this.enableJavaNetFastPath = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2214 */     str1 = null;
/*  2215 */     if (paramProperties != null)
/*       */     {
/*  2217 */       str1 = paramProperties.getProperty("oracle.jdbc.enableTempLobRefCnt");
/*       */     }
/*  2219 */     if (str1 == null)
/*  2220 */       str1 = getSystemProperty("oracle.jdbc.enableTempLobRefCnt", (String)null); 
/*  2221 */     if (str1 == null) {
/*  2222 */       str1 = "true";
/*       */     }
/*       */     
/*  2225 */     this.enableTempLobRefCnt = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2228 */     str1 = null;
/*  2229 */     if (paramProperties != null)
/*       */     {
/*  2231 */       str1 = paramProperties.getProperty("oracle.net.keepAlive");
/*       */     }
/*  2233 */     if (str1 == null)
/*  2234 */       str1 = getSystemProperty("oracle.net.keepAlive", (String)null); 
/*  2235 */     if (str1 == null) {
/*  2236 */       str1 = "false";
/*       */     }
/*       */     
/*  2239 */     this.keepAlive = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */ 
/*       */     
/*  2243 */     str1 = null;
/*  2244 */     if (paramProperties != null)
/*  2245 */       str1 = paramProperties.getProperty("oracle.jdbc.commitOption"); 
/*  2246 */     if (str1 == null)
/*  2247 */       str1 = getSystemProperty("oracle.jdbc.commitOption", (String)null); 
/*  2248 */     if (str1 != null) {
/*       */       
/*  2250 */       this.commitOption = 0;
/*  2251 */       String[] arrayOfString = str1.split(",");
/*  2252 */       if (arrayOfString != null && arrayOfString.length > 0)
/*       */       {
/*  2254 */         for (String str : arrayOfString) {
/*  2255 */           if (str.trim() != "") {
/*  2256 */             this.commitOption |= OracleConnection.CommitOption.valueOf(str.trim()).getCode();
/*       */           }
/*       */         } 
/*       */       }
/*       */     } 
/*       */ 
/*       */     
/*  2263 */     this.includeSynonyms = parseConnectionProperty_boolean(paramProperties, "synonyms", (byte)3, this.includeSynonyms);
/*       */ 
/*       */     
/*  2266 */     this.reportRemarks = parseConnectionProperty_boolean(paramProperties, "remarks", (byte)3, this.reportRemarks);
/*       */ 
/*       */     
/*  2269 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "prefetch", (byte)3, this.defaultRowPrefetch);
/*       */ 
/*       */     
/*  2272 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "rowPrefetch", (byte)3, this.defaultRowPrefetch);
/*       */ 
/*       */     
/*  2275 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "batch", (byte)3, this.defaultExecuteBatch);
/*       */ 
/*       */     
/*  2278 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "executeBatch", (byte)3, this.defaultExecuteBatch);
/*       */ 
/*       */     
/*  2281 */     this.proxyClientName = parseConnectionProperty_String(paramProperties, "PROXY_CLIENT_NAME", (byte)1, this.proxyClientName);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2287 */     if (this.defaultRowPrefetch <= 0) {
/*  2288 */       this.defaultRowPrefetch = Integer.parseInt("10");
/*       */     }
/*  2290 */     if (this.defaultExecuteBatch <= 0) {
/*  2291 */       this.defaultExecuteBatch = Integer.parseInt("1");
/*       */     }
/*  2293 */     if (this.defaultLobPrefetchSize < -1) {
/*       */       
/*  2295 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/*  2296 */       sQLException.fillInStackTrace();
/*  2297 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2304 */     if (this.streamChunkSize > 0) {
/*  2305 */       this.streamChunkSize = Math.max(4096, this.streamChunkSize);
/*       */     } else {
/*  2307 */       this.streamChunkSize = Integer.parseInt("16384");
/*       */     } 
/*       */ 
/*       */     
/*  2311 */     if (this.thinVsessionOsuser == null) {
/*       */       
/*  2313 */       this.thinVsessionOsuser = getSystemProperty("user.name", (String)null);
/*  2314 */       if (this.thinVsessionOsuser == null) {
/*  2315 */         this.thinVsessionOsuser = "jdbcuser";
/*       */       }
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2322 */     if (this.thinNetConnectTimeout == CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT_DEFAULT) {
/*       */       
/*  2324 */       int i = DriverManager.getLoginTimeout();
/*  2325 */       if (i != 0) {
/*  2326 */         this.thinNetConnectTimeout = "" + (i * 1000);
/*       */       }
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2334 */     this.url = paramString;
/*  2335 */     Hashtable hashtable = parseUrl(this.url, this.walletLocation, this.walletPassword);
/*       */     
/*  2337 */     if (this.userName == CONNECTION_PROPERTY_USER_NAME_DEFAULT)
/*  2338 */       this.userName = (String)hashtable.get("user"); 
/*  2339 */     String[] arrayOfString1 = new String[1];
/*  2340 */     String[] arrayOfString2 = new String[1];
/*  2341 */     this.userName = parseLoginOption(this.userName, paramProperties, arrayOfString1, arrayOfString2);
/*  2342 */     if (arrayOfString1[0] != null)
/*  2343 */       this.internalLogon = arrayOfString1[0]; 
/*  2344 */     if (arrayOfString2[0] != null) {
/*  2345 */       this.proxyClientName = arrayOfString2[0];
/*       */     }
/*  2347 */     String str2 = paramProperties.getProperty("password", CONNECTION_PROPERTY_PASSWORD_DEFAULT);
/*       */     
/*  2349 */     if (str2 == CONNECTION_PROPERTY_PASSWORD_DEFAULT)
/*  2350 */       str2 = (String)hashtable.get("password"); 
/*  2351 */     initializePassword(str2);
/*       */     
/*  2353 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2354 */       this.database = paramProperties.getProperty("server", CONNECTION_PROPERTY_DATABASE_DEFAULT);
/*       */     }
/*  2356 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2357 */       this.database = (String)hashtable.get("database");
/*       */     }
/*  2359 */     this.protocol = (String)hashtable.get("protocol");
/*       */ 
/*       */     
/*  2362 */     if (this.protocol == null) {
/*       */ 
/*       */       
/*  2365 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 40, "Protocol is not specified in URL");
/*  2366 */       sQLException.fillInStackTrace();
/*  2367 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  2372 */     if (this.protocol.equals("oci8") || this.protocol.equals("oci")) {
/*  2373 */       this.database = translateConnStr(this.database);
/*       */     }
/*       */     
/*  2376 */     if (paramProperties.getProperty("is_connection_pooling") == "true")
/*       */     {
/*       */       
/*  2379 */       if (this.database == null) {
/*  2380 */         this.database = "";
/*       */       }
/*       */     }
/*  2383 */     if (this.userName != null && !this.userName.startsWith("\"")) {
/*       */ 
/*       */       
/*  2386 */       char[] arrayOfChar = this.userName.toCharArray();
/*  2387 */       for (byte b = 0; b < arrayOfChar.length; b++)
/*  2388 */         arrayOfChar[b] = Character.toUpperCase(arrayOfChar[b]); 
/*  2389 */       this.userName = String.copyValueOf(arrayOfChar);
/*       */     } 
/*       */ 
/*       */     
/*  2393 */     this.xaWantsError = false;
/*  2394 */     this.usingXA = false;
/*       */     
/*  2396 */     readOCIConnectionPoolProperties(paramProperties);
/*  2397 */     validateConnectionProperties();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void readOCIConnectionPoolProperties(Properties paramProperties) throws SQLException {
/*  2406 */     this.ociConnectionPoolMinLimit = parseConnectionProperty_int(paramProperties, "connpool_min_limit", (byte)1, 0);
/*       */ 
/*       */     
/*  2409 */     this.ociConnectionPoolMaxLimit = parseConnectionProperty_int(paramProperties, "connpool_max_limit", (byte)1, 0);
/*       */ 
/*       */     
/*  2412 */     this.ociConnectionPoolIncrement = parseConnectionProperty_int(paramProperties, "connpool_increment", (byte)1, 0);
/*       */ 
/*       */     
/*  2415 */     this.ociConnectionPoolTimeout = parseConnectionProperty_int(paramProperties, "connpool_timeout", (byte)1, 0);
/*       */ 
/*       */     
/*  2418 */     this.ociConnectionPoolNoWait = parseConnectionProperty_boolean(paramProperties, "connpool_nowait", (byte)1, false);
/*       */ 
/*       */     
/*  2421 */     this.ociConnectionPoolTransactionDistributed = parseConnectionProperty_boolean(paramProperties, "transactions_distributed", (byte)1, false);
/*       */ 
/*       */     
/*  2424 */     this.ociConnectionPoolLogonMode = parseConnectionProperty_String(paramProperties, "connection_pool", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2427 */     this.ociConnectionPoolIsPooling = parseConnectionProperty_boolean(paramProperties, "is_connection_pooling", (byte)1, false);
/*       */ 
/*       */     
/*  2430 */     this.ociConnectionPoolObject = parseConnectionProperty_Object(paramProperties, "connpool_object", (Object)null);
/*       */     
/*  2432 */     this.ociConnectionPoolConnID = parseConnectionProperty_Object(paramProperties, "connection_id", (Object)null);
/*       */     
/*  2434 */     this.ociConnectionPoolProxyType = parseConnectionProperty_String(paramProperties, "proxytype", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2437 */     this.ociConnectionPoolProxyNumRoles = (Integer)parseConnectionProperty_Object(paramProperties, "proxy_num_roles", Integer.valueOf(0));
/*       */     
/*  2439 */     this.ociConnectionPoolProxyRoles = parseConnectionProperty_Object(paramProperties, "proxy_roles", (Object)null);
/*       */     
/*  2441 */     this.ociConnectionPoolProxyUserName = parseConnectionProperty_String(paramProperties, "proxy_user_name", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2444 */     this.ociConnectionPoolProxyPassword = parseConnectionProperty_String(paramProperties, "proxy_password", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2447 */     this.ociConnectionPoolProxyDistinguishedName = parseConnectionProperty_String(paramProperties, "proxy_distinguished_name", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2450 */     this.ociConnectionPoolProxyCertificate = parseConnectionProperty_Object(paramProperties, "proxy_certificate", (Object)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  2457 */   private static final Pattern driverNameAttributePattern = Pattern.compile("[\\x20-\\x7e]{0,8}");
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void validateConnectionProperties() throws SQLException {
/*  2467 */     if (this.driverNameAttribute != null && !driverNameAttributePattern.matcher(this.driverNameAttribute).matches()) {
/*       */ 
/*       */       
/*  2470 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 257);
/*  2471 */       sQLException.fillInStackTrace();
/*  2472 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final Object parseConnectionProperty_Object(Properties paramProperties, String paramString, Object paramObject) throws SQLException {
/*  2489 */     Object object = paramObject;
/*  2490 */     if (paramProperties != null) {
/*       */       
/*  2492 */       Object object1 = paramProperties.get(paramString);
/*  2493 */       if (object1 != null)
/*  2494 */         object = object1; 
/*       */     } 
/*  2496 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String parseConnectionProperty_String(Properties paramProperties, String paramString1, byte paramByte, String paramString2) throws SQLException {
/*  2525 */     String str = null;
/*  2526 */     if ((paramByte == 1 || paramByte == 3) && paramProperties != null) {
/*       */ 
/*       */       
/*  2529 */       str = paramProperties.getProperty(paramString1);
/*  2530 */       if (str == null && !paramString1.startsWith("oracle.") && !paramString1.startsWith("java.") && !paramString1.startsWith("javax."))
/*  2531 */         str = paramProperties.getProperty("oracle.jdbc." + paramString1); 
/*       */     } 
/*  2533 */     if (str == null && (paramByte == 2 || paramByte == 3))
/*       */     {
/*       */       
/*  2536 */       if (paramString1.startsWith("oracle.") || paramString1.startsWith("java.") || paramString1.startsWith("javax.")) {
/*  2537 */         str = getSystemProperty(paramString1, (String)null);
/*       */       } else {
/*  2539 */         str = getSystemProperty("oracle.jdbc." + paramString1, (String)null);
/*       */       }  } 
/*  2541 */     if (str == null)
/*  2542 */       str = paramString2; 
/*  2543 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int parseConnectionProperty_int(Properties paramProperties, String paramString, byte paramByte, int paramInt) throws SQLException {
/*  2554 */     int i = paramInt;
/*  2555 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2560 */     if (str != null) {
/*       */       
/*       */       try {
/*       */         
/*  2564 */         i = Integer.parseInt(str);
/*       */       }
/*  2566 */       catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */         
/*  2570 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2571 */         sQLException.fillInStackTrace();
/*  2572 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2577 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final long parseConnectionProperty_long(Properties paramProperties, String paramString, byte paramByte, long paramLong) throws SQLException {
/*  2588 */     long l = paramLong;
/*  2589 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2594 */     if (str != null) {
/*       */       
/*       */       try {
/*       */         
/*  2598 */         l = Long.parseLong(str);
/*       */       }
/*  2600 */       catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */         
/*  2604 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2605 */         sQLException.fillInStackTrace();
/*  2606 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2611 */     return l;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final boolean parseConnectionProperty_boolean(Properties paramProperties, String paramString, byte paramByte, boolean paramBoolean) throws SQLException {
/*  2622 */     boolean bool = paramBoolean;
/*  2623 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2628 */     if (str != null)
/*       */     {
/*  2630 */       if (str.equalsIgnoreCase("false")) {
/*  2631 */         bool = false;
/*  2632 */       } else if (str.equalsIgnoreCase("true")) {
/*  2633 */         bool = true;
/*       */       }  } 
/*  2635 */     return bool;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String parseLoginOption(String paramString, Properties paramProperties, String[] paramArrayOfString1, String[] paramArrayOfString2) {
/*  2655 */     int j = 0;
/*  2656 */     String str1 = null;
/*  2657 */     String str2 = null;
/*       */ 
/*       */     
/*  2660 */     if (paramString == null) {
/*  2661 */       return null;
/*       */     }
/*  2663 */     int k = paramString.length();
/*       */     
/*  2665 */     if (k == 0) {
/*  2666 */       return null;
/*       */     }
/*       */     
/*  2669 */     int i = paramString.indexOf('[');
/*  2670 */     if (i > 0) {
/*  2671 */       j = paramString.indexOf(']');
/*  2672 */       str2 = paramString.substring(i + 1, j);
/*  2673 */       str2 = str2.trim();
/*       */       
/*  2675 */       if (str2.length() > 0) {
/*  2676 */         paramArrayOfString2[0] = str2;
/*       */       }
/*       */       
/*  2679 */       paramString = paramString.substring(0, i) + paramString.substring(j + 1, k);
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  2684 */     String str3 = paramString.toLowerCase();
/*       */ 
/*       */     
/*  2687 */     i = str3.lastIndexOf(" as ");
/*       */     
/*  2689 */     if (i == -1 || i < str3.lastIndexOf("\"")) {
/*  2690 */       return paramString;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  2695 */     str1 = paramString.substring(0, i);
/*       */     
/*  2697 */     i += 4;
/*       */ 
/*       */     
/*  2700 */     while (i < k && str3.charAt(i) == ' ') {
/*  2701 */       i++;
/*       */     }
/*  2703 */     if (i == k) {
/*  2704 */       return paramString;
/*       */     }
/*  2706 */     String str4 = str3.substring(i).trim();
/*       */     
/*  2708 */     if (str4.length() > 0) {
/*  2709 */       paramArrayOfString1[0] = str4;
/*       */     }
/*  2711 */     return str1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final Hashtable parseUrl(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  2732 */     Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>(5);
/*  2733 */     int i = paramString1.indexOf(':', paramString1.indexOf(':') + 1) + 1;
/*  2734 */     int j = paramString1.length();
/*       */ 
/*       */     
/*  2737 */     if (i == j) {
/*  2738 */       return hashtable;
/*       */     }
/*  2740 */     int k = paramString1.indexOf(':', i);
/*       */ 
/*       */     
/*  2743 */     if (k == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2749 */       return hashtable;
/*       */     }
/*       */ 
/*       */     
/*  2753 */     hashtable.put("protocol", paramString1.substring(i, k));
/*       */     
/*  2755 */     int m = k + 1;
/*  2756 */     int n = paramString1.indexOf('/', m);
/*       */     
/*  2758 */     int i1 = paramString1.indexOf('@', m);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2763 */     if (i1 > m && m > i && n == -1) {
/*       */ 
/*       */       
/*  2766 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 67);
/*  2767 */       sQLException.fillInStackTrace();
/*  2768 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2772 */     if (i1 == -1) {
/*  2773 */       i1 = j;
/*       */     }
/*  2775 */     if (n == -1) {
/*  2776 */       n = i1;
/*       */     }
/*  2778 */     if (n < i1 && n != m && i1 != m) {
/*       */       
/*  2780 */       hashtable.put("user", paramString1.substring(m, n));
/*  2781 */       hashtable.put("password", paramString1.substring(n + 1, i1));
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2787 */     if (n <= i1 && (n == m || i1 == m))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2794 */       if (i1 < j) {
/*       */         
/*  2796 */         String str = paramString1.substring(i1 + 1);
/*  2797 */         String[] arrayOfString = getSecretStoreCredentials(str, paramString2, paramString3);
/*  2798 */         if (arrayOfString[0] != null || arrayOfString[1] != null) {
/*       */           
/*  2800 */           hashtable.put("user", arrayOfString[0]);
/*  2801 */           hashtable.put("password", arrayOfString[1]);
/*       */         } 
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2807 */     if (i1 < j) {
/*  2808 */       hashtable.put("database", paramString1.substring(i1 + 1));
/*       */     }
/*  2810 */     return hashtable;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String[] getSecretStoreCredentials(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  2971 */     String[] arrayOfString = new String[2];
/*  2972 */     arrayOfString[0] = null;
/*  2973 */     arrayOfString[1] = null;
/*       */     
/*  2975 */     if (paramString2 != null) {
/*       */       
/*       */       try {
/*       */         
/*  2979 */         if (paramString2.startsWith("(")) {
/*  2980 */           paramString2 = "file:" + CustomSSLSocketFactory.processWalletLocation(paramString2);
/*       */         }
/*  2982 */         OracleWallet oracleWallet = new OracleWallet();
/*  2983 */         if (oracleWallet.exists(paramString2)) {
/*       */ 
/*       */ 
/*       */           
/*  2987 */           char[] arrayOfChar = null;
/*  2988 */           if (paramString3 != null) {
/*  2989 */             arrayOfChar = paramString3.toCharArray();
/*       */           }
/*       */ 
/*       */           
/*  2993 */           oracleWallet.open(paramString2, arrayOfChar);
/*  2994 */           OracleSecretStore oracleSecretStore = oracleWallet.getSecretStore();
/*       */ 
/*       */ 
/*       */           
/*  2998 */           if (oracleSecretStore.containsAlias("oracle.security.client.default_username")) {
/*  2999 */             arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.default_username"));
/*       */           }
/*  3001 */           if (oracleSecretStore.containsAlias("oracle.security.client.default_password")) {
/*  3002 */             arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.default_password"));
/*       */           }
/*       */           
/*  3005 */           Enumeration<String> enumeration = oracleWallet.getSecretStore().internalAliases();
/*       */           
/*  3007 */           String str = null;
/*  3008 */           while (enumeration.hasMoreElements()) {
/*       */             
/*  3010 */             str = enumeration.nextElement();
/*  3011 */             if (str.startsWith("oracle.security.client.connect_string"))
/*       */             {
/*  3013 */               if (paramString1.equalsIgnoreCase(new String(oracleSecretStore.getSecret(str)))) {
/*       */ 
/*       */                 
/*  3016 */                 String str1 = str.substring("oracle.security.client.connect_string".length());
/*  3017 */                 arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.username" + str1));
/*       */                 
/*  3019 */                 arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.password" + str1));
/*       */ 
/*       */                 
/*       */                 break;
/*       */               } 
/*       */             }
/*       */           } 
/*       */         } 
/*  3027 */       } catch (NoClassDefFoundError noClassDefFoundError) {
/*       */ 
/*       */         
/*  3030 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 167, noClassDefFoundError);
/*  3031 */         sQLException.fillInStackTrace();
/*  3032 */         throw sQLException;
/*       */       
/*       */       }
/*  3035 */       catch (Exception exception) {
/*       */         
/*  3037 */         if (exception instanceof RuntimeException) throw (RuntimeException)exception;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3047 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 168, exception);
/*  3048 */         sQLException.fillInStackTrace();
/*  3049 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  3054 */     return arrayOfString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private String translateConnStr(String paramString) throws SQLException {
/*  3073 */     int i = 0;
/*  3074 */     int j = 0;
/*       */     
/*  3076 */     if (paramString == null || paramString.equals("")) {
/*  3077 */       return paramString;
/*       */     }
/*       */     
/*  3080 */     if (paramString.indexOf(')') != -1) {
/*  3081 */       return paramString;
/*       */     }
/*  3083 */     boolean bool = false;
/*  3084 */     if (paramString.indexOf('[') != -1) {
/*       */ 
/*       */       
/*  3087 */       i = paramString.indexOf(']');
/*  3088 */       if (i == -1) {
/*       */         
/*  3090 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3091 */         sQLException.fillInStackTrace();
/*  3092 */         throw sQLException;
/*       */       } 
/*  3094 */       bool = true;
/*       */     } 
/*       */     
/*  3097 */     i = paramString.indexOf(':', i);
/*  3098 */     if (i == -1)
/*  3099 */       return paramString; 
/*  3100 */     j = paramString.indexOf(':', i + 1);
/*  3101 */     if (j == -1) {
/*  3102 */       return paramString;
/*       */     }
/*       */     
/*  3105 */     if (paramString.indexOf(':', j + 1) != -1) {
/*       */ 
/*       */       
/*  3108 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3109 */       sQLException.fillInStackTrace();
/*  3110 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3114 */     String str1 = null;
/*  3115 */     if (bool) {
/*  3116 */       str1 = paramString.substring(1, i - 1);
/*       */     } else {
/*  3118 */       str1 = paramString.substring(0, i);
/*       */     } 
/*  3120 */     String str2 = paramString.substring(i + 1, j);
/*  3121 */     String str3 = paramString.substring(j + 1, paramString.length());
/*       */     
/*  3123 */     return "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + str2 + "))(CONNECT_DATA=(SID=" + str3 + ")))";
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static String getSystemPropertyPollInterval() {
/*  3136 */     return getSystemProperty("oracle.jdbc.TimeoutPollInterval", "1000");
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSystemPropertyFastConnectionFailover(String paramString) {
/*  3145 */     return getSystemProperty("oracle.jdbc.FastConnectionFailover", paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSystemPropertyJserverVersion() {
/*  3153 */     return getSystemProperty("oracle.jserver.version", (String)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String getSystemProperty(String paramString1, String paramString2) {
/*  3160 */     if (paramString1 != null) {
/*       */       
/*  3162 */       final String fstr = paramString1;
/*  3163 */       final String fdefaultValue = paramString2;
/*  3164 */       final String[] rets = { paramString2 };
/*  3165 */       AccessController.doPrivileged(new PrivilegedAction()
/*       */           {
/*       */             public Object run()
/*       */             {
/*  3169 */               rets[0] = System.getProperty(fstr, fdefaultValue);
/*  3170 */               return null;
/*       */             }
/*       */           });
/*  3173 */       return arrayOfString[0];
/*       */     } 
/*       */     
/*  3176 */     return paramString2;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Properties getProperties() {
/*  3187 */     Properties properties = new Properties();
/*       */     
/*       */     try {
/*  3190 */       Class clazz1 = null;
/*  3191 */       Class clazz2 = null;
/*       */       
/*       */       try {
/*  3194 */         clazz1 = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
/*  3195 */         clazz2 = ClassRef.newInstance("oracle.jdbc.driver.PhysicalConnection").get();
/*       */       }
/*  3197 */       catch (ClassNotFoundException classNotFoundException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3204 */       Field[] arrayOfField = clazz2.getDeclaredFields();
/*  3205 */       for (byte b = 0; b < arrayOfField.length; b++) {
/*       */         
/*  3207 */         int i = arrayOfField[b].getModifiers();
/*  3208 */         if (!Modifier.isStatic(i)) {
/*       */ 
/*       */           
/*  3211 */           String str1 = arrayOfField[b].getName();
/*       */ 
/*       */           
/*  3214 */           String str2 = "CONNECTION_PROPERTY_" + propertyVariableName(str1);
/*       */ 
/*       */ 
/*       */           
/*  3218 */           Field field = null;
/*       */ 
/*       */           
/*       */           try {
/*  3222 */             field = clazz1.getField(str2);
/*       */           }
/*  3224 */           catch (NoSuchFieldException noSuchFieldException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*  3230 */           if (!str2.matches(".*PASSWORD.*")) {
/*       */ 
/*       */             
/*  3233 */             String str3 = (String)field.get(null);
/*  3234 */             String str4 = arrayOfField[b].getType().getName();
/*  3235 */             if (str4.equals("boolean"))
/*       */             
/*  3237 */             { boolean bool = arrayOfField[b].getBoolean(this);
/*  3238 */               if (bool) {
/*  3239 */                 properties.setProperty(str3, "true");
/*       */               } else {
/*  3241 */                 properties.setProperty(str3, "false");
/*       */               }  }
/*  3243 */             else if (str4.equals("int"))
/*       */             
/*  3245 */             { int j = arrayOfField[b].getInt(this);
/*  3246 */               properties.setProperty(str3, Integer.toString(j)); }
/*       */             
/*  3248 */             else if (str4.equals("long"))
/*       */             
/*  3250 */             { long l = arrayOfField[b].getLong(this);
/*  3251 */               properties.setProperty(str3, Long.toString(l)); }
/*       */             
/*  3253 */             else if (str4.equals("java.lang.String"))
/*       */             
/*  3255 */             { String str = (String)arrayOfField[b].get(this);
/*  3256 */               if (str != null)
/*  3257 */                 properties.setProperty(str3, str);  } 
/*       */           } 
/*       */         } 
/*       */       } 
/*  3261 */     } catch (IllegalAccessException illegalAccessException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3266 */     return properties;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Connection _getPC() {
/*  3287 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleConnection getPhysicalConnection() {
/*  3303 */     return this;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isLogicalConnection() {
/*  3316 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void initialize(Hashtable paramHashtable, Map paramMap1, Map paramMap2) throws SQLException {
/*  3329 */     this.clearStatementMetaData = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3335 */     if (paramHashtable != null) {
/*  3336 */       this.descriptorCacheStack[this.dci] = paramHashtable;
/*       */     } else {
/*  3338 */       this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */     } 
/*  3340 */     this.map = paramMap1;
/*       */     
/*  3342 */     if (paramMap2 != null) {
/*  3343 */       this.javaObjectMap = paramMap2;
/*       */     } else {
/*  3345 */       this.javaObjectMap = new Hashtable<Object, Object>(10);
/*       */     } 
/*  3347 */     this.lifecycle = 1;
/*  3348 */     this.txnLevel = 2;
/*       */ 
/*       */     
/*  3351 */     this.clientIdSet = false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void initializeSetCHARCharSetObjs() {
/*  3359 */     this.setCHARNCharSetObj = this.conversion.getDriverNCharSetObj();
/*  3360 */     this.setCHARCharSetObj = this.conversion.getDriverCharSetObj();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTimeout getTimeout() throws SQLException {
/*  3374 */     if (this.timeout == null)
/*       */     {
/*  3376 */       this.timeout = OracleTimeout.newTimeout(this.url);
/*       */     }
/*       */     
/*  3379 */     return this.timeout;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Statement createStatement() throws SQLException {
/*  3398 */     return createStatement(-1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Statement createStatement(int paramInt1, int paramInt2) throws SQLException {
/*  3420 */     if (this.lifecycle != 1) {
/*       */       
/*  3422 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3423 */       sQLException.fillInStackTrace();
/*  3424 */       throw sQLException;
/*       */     } 
/*       */     
/*  3427 */     OracleStatement oracleStatement = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3433 */     oracleStatement = this.driverExtension.allocateStatement(this, paramInt1, paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3440 */     return (Statement)new OracleStatementWrapper((OracleStatement)oracleStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatement(String paramString) throws SQLException {
/*  3461 */     return prepareStatement(paramString, -1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatementWithKey(String paramString) throws SQLException {
/*       */     OraclePreparedStatementWrapper oraclePreparedStatementWrapper;
/*  3482 */     if (this.lifecycle != 1) {
/*       */       
/*  3484 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3485 */       sQLException.fillInStackTrace();
/*  3486 */       throw sQLException;
/*       */     } 
/*       */     
/*  3489 */     if (paramString == null) {
/*  3490 */       return null;
/*       */     }
/*  3492 */     if (!isStatementCacheInitialized()) {
/*       */       
/*  3494 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3495 */       sQLException.fillInStackTrace();
/*  3496 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3503 */     OraclePreparedStatement oraclePreparedStatement = null;
/*       */     
/*  3505 */     oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3516 */     if (oraclePreparedStatement != null) {
/*  3517 */       oraclePreparedStatementWrapper = new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
/*       */     }
/*  3519 */     return (PreparedStatement)oraclePreparedStatementWrapper;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  3550 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  3552 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  3553 */       sQLException.fillInStackTrace();
/*  3554 */       throw sQLException;
/*       */     } 
/*       */     
/*  3557 */     if (this.lifecycle != 1) {
/*       */       
/*  3559 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3560 */       sQLException.fillInStackTrace();
/*  3561 */       throw sQLException;
/*       */     } 
/*       */     
/*  3564 */     OraclePreparedStatement oraclePreparedStatement = null;
/*       */ 
/*       */     
/*  3567 */     if (this.statementCache != null) {
/*  3568 */       oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchImplicitCache(paramString, 1, (paramInt1 != -1 || paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3574 */     if (oraclePreparedStatement == null) {
/*  3575 */       oraclePreparedStatement = this.driverExtension.allocatePreparedStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3587 */     return (PreparedStatement)new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCall(String paramString) throws SQLException {
/*  3606 */     return prepareCall(paramString, -1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  3635 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  3637 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  3638 */       sQLException.fillInStackTrace();
/*  3639 */       throw sQLException;
/*       */     } 
/*       */     
/*  3642 */     if (this.lifecycle != 1) {
/*       */       
/*  3644 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3645 */       sQLException.fillInStackTrace();
/*  3646 */       throw sQLException;
/*       */     } 
/*       */     
/*  3649 */     OracleCallableStatement oracleCallableStatement = null;
/*       */     
/*  3651 */     if (this.statementCache != null) {
/*  3652 */       oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchImplicitCache(paramString, 2, (paramInt1 != -1 || paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3658 */     if (oracleCallableStatement == null) {
/*  3659 */       oracleCallableStatement = this.driverExtension.allocateCallableStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3670 */     return (CallableStatement)new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCallWithKey(String paramString) throws SQLException {
/*       */     OracleCallableStatementWrapper oracleCallableStatementWrapper;
/*  3690 */     if (this.lifecycle != 1) {
/*       */       
/*  3692 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3693 */       sQLException.fillInStackTrace();
/*  3694 */       throw sQLException;
/*       */     } 
/*       */     
/*  3697 */     if (paramString == null) {
/*  3698 */       return null;
/*       */     }
/*  3700 */     if (!isStatementCacheInitialized()) {
/*       */       
/*  3702 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3703 */       sQLException.fillInStackTrace();
/*  3704 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3711 */     OracleCallableStatement oracleCallableStatement = null;
/*       */     
/*  3713 */     oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3723 */     if (oracleCallableStatement != null) {
/*  3724 */       oracleCallableStatementWrapper = new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
/*       */     }
/*  3726 */     return (CallableStatement)oracleCallableStatementWrapper;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String nativeSQL(String paramString) throws SQLException {
/*  3738 */     if (this.sqlObj == null)
/*       */     {
/*  3740 */       this.sqlObj = new OracleSql(this.conversion);
/*       */     }
/*       */     
/*  3743 */     this.sqlObj.initialize(paramString);
/*       */     
/*  3745 */     return this.sqlObj.getSql(this.processEscapes, this.convertNcharLiterals);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAutoCommit(boolean paramBoolean) throws SQLException {
/*  3757 */     if (paramBoolean) {
/*  3758 */       disallowGlobalTxnMode(116);
/*       */     }
/*  3760 */     if (this.lifecycle != 1) {
/*       */       
/*  3762 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3763 */       sQLException.fillInStackTrace();
/*  3764 */       throw sQLException;
/*       */     } 
/*       */     
/*  3767 */     needLine();
/*  3768 */     doSetAutoCommit(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getAutoCommit() throws SQLException {
/*  3776 */     return this.autocommit;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void cancel() throws SQLException {
/*  3795 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3797 */     if (this.lifecycle != 1 && this.lifecycle != 16) {
/*       */       
/*  3799 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3800 */       sQLException.fillInStackTrace();
/*  3801 */       throw sQLException;
/*       */     } 
/*       */     
/*  3804 */     boolean bool = false;
/*       */     
/*  3806 */     while (oracleStatement != null) {
/*       */ 
/*       */       
/*       */       try {
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3814 */         if (oracleStatement.doCancel()) {
/*  3815 */           bool = true;
/*       */         }
/*  3817 */       } catch (SQLException sQLException) {}
/*       */ 
/*       */ 
/*       */       
/*  3821 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*       */ 
/*       */     
/*  3825 */     if (!bool) {
/*  3826 */       cancelOperationOnServer();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public void commit(EnumSet<OracleConnection.CommitOption> paramEnumSet) throws SQLException {
/*  3833 */     int i = 0;
/*  3834 */     if (paramEnumSet != null) {
/*       */       
/*  3836 */       if ((paramEnumSet.contains(OracleConnection.CommitOption.WRITEBATCH) && paramEnumSet.contains(OracleConnection.CommitOption.WRITEIMMED)) || (paramEnumSet.contains(OracleConnection.CommitOption.WAIT) && paramEnumSet.contains(OracleConnection.CommitOption.NOWAIT))) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3842 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  3843 */         sQLException.fillInStackTrace();
/*  3844 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*  3848 */       for (OracleConnection.CommitOption commitOption : paramEnumSet)
/*  3849 */         i |= commitOption.getCode(); 
/*       */     } 
/*  3851 */     commit(i);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void commit(int paramInt) throws SQLException {
/*  3862 */     disallowGlobalTxnMode(114);
/*       */     
/*  3864 */     if (this.lifecycle != 1) {
/*       */       
/*  3866 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3867 */       sQLException.fillInStackTrace();
/*  3868 */       throw sQLException;
/*       */     } 
/*       */     
/*  3871 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3873 */     while (oracleStatement != null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3878 */       if (!oracleStatement.closed) {
/*  3879 */         oracleStatement.sendBatch();
/*       */       }
/*  3881 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*  3883 */     if (((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) || ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0)) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3889 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  3890 */       sQLException.fillInStackTrace();
/*  3891 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3898 */     registerHeartbeat();
/*       */     
/*  3900 */     needLine();
/*  3901 */     doCommit(paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public void commit() throws SQLException {
/*  3907 */     commit(this.commitOption);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void rollback() throws SQLException {
/*  3916 */     disallowGlobalTxnMode(115);
/*       */     
/*  3918 */     if (this.lifecycle != 1) {
/*       */       
/*  3920 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3921 */       sQLException.fillInStackTrace();
/*  3922 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3926 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3928 */     while (oracleStatement != null) {
/*       */       
/*  3930 */       if (oracleStatement.isOracleBatchStyle()) {
/*  3931 */         oracleStatement.clearBatch();
/*       */       }
/*  3933 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3940 */     registerHeartbeat();
/*       */     
/*  3942 */     needLine();
/*  3943 */     doRollback();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close() throws SQLException {
/*  3957 */     if (this.lifecycle == 2 || this.lifecycle == 4) {
/*       */       return;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  3963 */     needLineUnchecked();
/*       */ 
/*       */     
/*       */     try {
/*  3967 */       if (this.closeCallback != null) {
/*  3968 */         this.closeCallback.beforeClose(this, this.privateData);
/*       */       }
/*  3970 */       closeStatementCache();
/*  3971 */       closeStatements(false);
/*       */       
/*  3973 */       if (this.lifecycle == 1) this.lifecycle = 2;
/*       */ 
/*       */       
/*  3976 */       if (this.isProxy)
/*       */       {
/*  3978 */         close(1);
/*       */       }
/*       */       
/*  3981 */       if (this.timeZoneTab != null) {
/*  3982 */         this.timeZoneTab.freeInstance();
/*       */       }
/*  3984 */       logoff();
/*  3985 */       cleanup();
/*       */       
/*  3987 */       if (this.timeout != null) {
/*  3988 */         this.timeout.close();
/*       */       }
/*  3990 */       if (this.closeCallback != null) {
/*  3991 */         this.closeCallback.afterClose(this.privateData);
/*       */       }
/*       */     } finally {
/*       */       
/*  3995 */       this.lifecycle = 4;
/*  3996 */       this.isUsable = false;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDataIntegrityAlgorithmName() throws SQLException {
/*  4007 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4008 */     sQLException.fillInStackTrace();
/*  4009 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getEncryptionAlgorithmName() throws SQLException {
/*  4016 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4017 */     sQLException.fillInStackTrace();
/*  4018 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getAuthenticationAdaptorName() throws SQLException {
/*  4025 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4026 */     sQLException.fillInStackTrace();
/*  4027 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void closeInternal(boolean paramBoolean) throws SQLException {
/*  4037 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4038 */     sQLException.fillInStackTrace();
/*  4039 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void cleanupAndClose(boolean paramBoolean) throws SQLException {
/*  4050 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4051 */     sQLException.fillInStackTrace();
/*  4052 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanupAndClose() throws SQLException {
/*  4063 */     if (this.lifecycle != 1) {
/*       */       return;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  4069 */     this.lifecycle = 16;
/*       */ 
/*       */     
/*  4072 */     cancel();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void closeLogicalConnection() throws SQLException {
/*  4079 */     if (this.lifecycle == 1 || this.lifecycle == 16 || this.lifecycle == 2) {
/*       */ 
/*       */ 
/*       */       
/*  4083 */       this.savepointStatement = null;
/*  4084 */       closeStatements(true);
/*       */       
/*  4086 */       if (this.clientIdSet) {
/*  4087 */         clearClientIdentifier(this.clientId);
/*       */       }
/*  4089 */       this.logicalConnectionAttached = null;
/*  4090 */       this.lifecycle = 1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close(Properties paramProperties) throws SQLException {
/*  4110 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4111 */     sQLException.fillInStackTrace();
/*  4112 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close(int paramInt) throws SQLException {
/*  4128 */     if ((paramInt & 0x1000) != 0) {
/*       */       
/*  4130 */       close();
/*       */       
/*       */       return;
/*       */     } 
/*       */     
/*  4135 */     if ((paramInt & 0x1) != 0 && this.isProxy) {
/*       */       
/*  4137 */       purgeStatementCache();
/*  4138 */       closeStatements(false);
/*  4139 */       this.descriptorCacheStack[this.dci--] = null;
/*       */       
/*  4141 */       closeProxySession();
/*       */       
/*  4143 */       this.isProxy = false;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  4150 */   private static final OracleSQLPermission CALL_ABORT_PERMISSION = new OracleSQLPermission("callAbort"); static final String DATABASE_NAME = "DATABASE_NAME"; static final String SERVER_HOST = "SERVER_HOST"; static final String INSTANCE_NAME = "INSTANCE_NAME"; static final String SERVICE_NAME = "SERVICE_NAME"; Hashtable clientData; private BufferCacheStore connectionBufferCacheStore; private static ThreadLocal<BufferCacheStore> threadLocalBufferCacheStore; private int pingResult; String sessionTimeZone; String databaseTimeZone; Calendar dbTzCalendar; static final String RAW_STR = "RAW"; static final String SYS_RAW_STR = "SYS.RAW"; static final String SYS_ANYDATA_STR = "SYS.ANYDATA"; static final String SYS_XMLTYPE_STR = "SYS.XMLTYPE";
/*       */   int timeZoneVersionNumber;
/*       */   TIMEZONETAB timeZoneTab;
/*       */   
/*       */   public void abort() throws SQLException {
/*  4155 */     SecurityManager securityManager = System.getSecurityManager();
/*  4156 */     if (securityManager != null) {
/*  4157 */       securityManager.checkPermission((Permission)CALL_ABORT_PERMISSION);
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  4162 */     if (this.lifecycle == 4 || this.lifecycle == 8) {
/*       */       return;
/*       */     }
/*       */     
/*  4166 */     this.lifecycle = 8;
/*       */ 
/*       */     
/*  4169 */     doAbort();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void closeProxySession() throws SQLException {
/*  4182 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4183 */     sQLException.fillInStackTrace();
/*  4184 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Properties getServerSessionInfo() throws SQLException {
/*  4201 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4202 */     sQLException.fillInStackTrace();
/*  4203 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void applyConnectionAttributes(Properties paramProperties) throws SQLException {
/*  4216 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4217 */     sQLException.fillInStackTrace();
/*  4218 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Properties getConnectionAttributes() throws SQLException {
/*  4231 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4232 */     sQLException.fillInStackTrace();
/*  4233 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Properties getUnMatchedConnectionAttributes() throws SQLException {
/*  4246 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4247 */     sQLException.fillInStackTrace();
/*  4248 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAbandonedTimeoutEnabled(boolean paramBoolean) throws SQLException {
/*  4262 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4263 */     sQLException.fillInStackTrace();
/*  4264 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback paramOracleConnectionCacheCallback, Object paramObject, int paramInt) throws SQLException {
/*  4277 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4278 */     sQLException.fillInStackTrace();
/*  4279 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException {
/*  4292 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4293 */     sQLException.fillInStackTrace();
/*  4294 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getConnectionCacheCallbackPrivObj() throws SQLException {
/*  4306 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4307 */     sQLException.fillInStackTrace();
/*  4308 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getConnectionCacheCallbackFlag() throws SQLException {
/*  4320 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4321 */     sQLException.fillInStackTrace();
/*  4322 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setConnectionReleasePriority(int paramInt) throws SQLException {
/*  4335 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4336 */     sQLException.fillInStackTrace();
/*  4337 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getConnectionReleasePriority() throws SQLException {
/*  4349 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4350 */     sQLException.fillInStackTrace();
/*  4351 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isClosed() throws SQLException {
/*  4364 */     return (this.lifecycle != 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isProxySession() {
/*  4371 */     return this.isProxy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void openProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*  4380 */     boolean bool = true;
/*       */     
/*  4382 */     if (this.isProxy) {
/*       */       
/*  4384 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 149);
/*  4385 */       sQLException.fillInStackTrace();
/*  4386 */       throw sQLException;
/*       */     } 
/*       */     
/*  4389 */     String str1 = paramProperties.getProperty("PROXY_USER_NAME");
/*  4390 */     String str2 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  4391 */     String str3 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*       */     
/*  4393 */     Object object = paramProperties.get("PROXY_CERTIFICATE");
/*       */     
/*  4395 */     if (paramInt == 1) {
/*       */       
/*  4397 */       if (str1 == null && str2 == null)
/*       */       {
/*  4399 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4400 */         sQLException.fillInStackTrace();
/*  4401 */         throw sQLException;
/*       */       }
/*       */     
/*  4404 */     } else if (paramInt == 2) {
/*       */       
/*  4406 */       if (str3 == null)
/*       */       {
/*  4408 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4409 */         sQLException.fillInStackTrace();
/*  4410 */         throw sQLException;
/*       */       }
/*       */     
/*  4413 */     } else if (paramInt == 3) {
/*       */       
/*  4415 */       if (object == null) {
/*       */         
/*  4417 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4418 */         sQLException.fillInStackTrace();
/*  4419 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*       */       try {
/*  4424 */         byte[] arrayOfByte = (byte[])object;
/*       */       }
/*  4426 */       catch (ClassCastException classCastException) {
/*       */ 
/*       */         
/*  4429 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4430 */         sQLException.fillInStackTrace();
/*  4431 */         throw sQLException;
/*       */       }
/*       */     
/*       */     }
/*       */     else {
/*       */       
/*  4437 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4438 */       sQLException.fillInStackTrace();
/*  4439 */       throw sQLException;
/*       */     } 
/*       */     
/*  4442 */     purgeStatementCache();
/*  4443 */     closeStatements(false);
/*       */ 
/*       */ 
/*       */     
/*       */     try {
/*  4448 */       doProxySession(paramInt, paramProperties);
/*  4449 */       this.dci++;
/*       */       
/*  4451 */       bool = false;
/*       */     
/*       */     }
/*       */     finally {
/*       */       
/*  4456 */       if (bool == true) {
/*  4457 */         closeProxySession();
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*  4468 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4469 */     sQLException.fillInStackTrace();
/*  4470 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanup() {
/*  4480 */     this.fdo = null;
/*  4481 */     this.conversion = null;
/*  4482 */     this.statements = null;
/*  4483 */     this.descriptorCacheStack[this.dci] = null;
/*  4484 */     this.map = null;
/*  4485 */     this.javaObjectMap = null;
/*  4486 */     this.statementHoldingLine = null;
/*  4487 */     this.sqlObj = null;
/*  4488 */     this.isProxy = false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized DatabaseMetaData getMetaData() throws SQLException {
/*  4505 */     if (this.lifecycle != 1) {
/*       */       
/*  4507 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4508 */       sQLException.fillInStackTrace();
/*  4509 */       throw sQLException;
/*       */     } 
/*       */     
/*  4512 */     if (this.databaseMetaData == null) {
/*  4513 */       this.databaseMetaData = new OracleDatabaseMetaData(this);
/*       */     }
/*  4515 */     return (DatabaseMetaData)this.databaseMetaData;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setReadOnly(boolean paramBoolean) throws SQLException {
/*  4532 */     this.readOnly = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isReadOnly() throws SQLException {
/*  4548 */     return this.readOnly;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCatalog(String paramString) throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getCatalog() throws SQLException {
/*  4570 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setTransactionIsolation(int paramInt) throws SQLException {
/*  4580 */     if (this.txnLevel == paramInt) {
/*       */       return;
/*       */     }
/*  4583 */     Statement statement = createStatement();
/*       */     
/*       */     try {
/*       */       SQLException sQLException;
/*  4587 */       switch (paramInt) {
/*       */ 
/*       */ 
/*       */         
/*       */         case 2:
/*  4592 */           statement.execute("ALTER SESSION SET ISOLATION_LEVEL = READ COMMITTED");
/*       */           
/*  4594 */           this.txnLevel = 2;
/*       */           break;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         case 8:
/*  4601 */           statement.execute("ALTER SESSION SET ISOLATION_LEVEL = SERIALIZABLE");
/*       */           
/*  4603 */           this.txnLevel = 8;
/*       */           break;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         default:
/*  4610 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 30);
/*  4611 */           sQLException.fillInStackTrace();
/*  4612 */           throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     } finally {
/*  4620 */       statement.close();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getTransactionIsolation() throws SQLException {
/*  4629 */     return this.txnLevel;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAutoClose(boolean paramBoolean) throws SQLException {
/*  4642 */     if (!paramBoolean) {
/*       */       
/*  4644 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 31);
/*  4645 */       sQLException.fillInStackTrace();
/*  4646 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getAutoClose() throws SQLException {
/*  4658 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public SQLWarning getWarnings() throws SQLException {
/*  4668 */     return this.sqlWarning;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearWarnings() throws SQLException {
/*  4675 */     this.sqlWarning = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setWarnings(SQLWarning paramSQLWarning) {
/*  4682 */     this.sqlWarning = paramSQLWarning;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultRowPrefetch(int paramInt) throws SQLException {
/*  4726 */     if (paramInt <= 0) {
/*       */       
/*  4728 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/*  4729 */       sQLException.fillInStackTrace();
/*  4730 */       throw sQLException;
/*       */     } 
/*       */     
/*  4733 */     this.defaultRowPrefetch = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getDefaultRowPrefetch() {
/*  4760 */     return this.defaultRowPrefetch;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getTimestamptzInGmt() {
/*  4767 */     return this.timestamptzInGmt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getUse1900AsYearForTime() {
/*  4774 */     return this.use1900AsYearForTime;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setDefaultExecuteBatch(int paramInt) throws SQLException {
/*  4816 */     if (paramInt <= 0) {
/*       */       
/*  4818 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
/*  4819 */       sQLException.fillInStackTrace();
/*  4820 */       throw sQLException;
/*       */     } 
/*       */     
/*  4823 */     this.defaultExecuteBatch = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getDefaultExecuteBatch() {
/*  4851 */     return this.defaultExecuteBatch;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setRemarksReporting(boolean paramBoolean) {
/*  4874 */     this.reportRemarks = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getRemarksReporting() {
/*  4887 */     return this.reportRemarks;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setIncludeSynonyms(boolean paramBoolean) {
/*  4908 */     this.includeSynonyms = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String[] getEndToEndMetrics() throws SQLException {
/*       */     String[] arrayOfString;
/*  4922 */     if (this.endToEndValues == null) {
/*       */       
/*  4924 */       arrayOfString = null;
/*       */     }
/*       */     else {
/*       */       
/*  4928 */       arrayOfString = new String[this.endToEndValues.length];
/*       */       
/*  4930 */       System.arraycopy(this.endToEndValues, 0, arrayOfString, 0, this.endToEndValues.length);
/*       */     } 
/*  4932 */     return arrayOfString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getEndToEndECIDSequenceNumber() throws SQLException {
/*  4950 */     return this.endToEndECIDSequenceNumber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setEndToEndMetrics(String[] paramArrayOfString, short paramShort) throws SQLException {
/*  4965 */     String[] arrayOfString = new String[paramArrayOfString.length];
/*       */     
/*  4967 */     System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
/*  4968 */     setEndToEndMetricsInternal(arrayOfString, paramShort);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setEndToEndMetricsInternal(String[] paramArrayOfString, short paramShort) throws SQLException {
/*  4983 */     if (paramArrayOfString != this.endToEndValues) {
/*       */       
/*  4985 */       if (paramArrayOfString.length != 4) {
/*       */ 
/*       */ 
/*       */         
/*  4989 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 156);
/*  4990 */         sQLException.fillInStackTrace();
/*  4991 */         throw sQLException;
/*       */       } 
/*       */       
/*       */       byte b;
/*  4995 */       for (b = 0; b < 4; b++) {
/*       */         
/*  4997 */         String str = paramArrayOfString[b];
/*       */         
/*  4999 */         if (str != null && str.length() > this.endToEndMaxLength[b]) {
/*       */ 
/*       */           
/*  5002 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, str);
/*  5003 */           sQLException.fillInStackTrace();
/*  5004 */           throw sQLException;
/*       */         } 
/*       */       } 
/*       */ 
/*       */       
/*  5009 */       if (this.endToEndValues != null) {
/*       */         
/*  5011 */         for (b = 0; b < 4; b++) {
/*       */           
/*  5013 */           String str = paramArrayOfString[b];
/*       */           
/*  5015 */           if ((str == null && this.endToEndValues[b] != null) || (str != null && !str.equals(this.endToEndValues[b]))) {
/*       */ 
/*       */             
/*  5018 */             this.endToEndHasChanged[b] = true;
/*  5019 */             this.endToEndAnyChanged = true;
/*       */           } 
/*       */         } 
/*       */ 
/*       */         
/*  5024 */         this.endToEndHasChanged[0] = this.endToEndHasChanged[0] | this.endToEndHasChanged[3];
/*       */       
/*       */       }
/*       */       else {
/*       */         
/*  5029 */         for (b = 0; b < 4; b++)
/*       */         {
/*  5031 */           this.endToEndHasChanged[b] = true;
/*       */         }
/*       */         
/*  5034 */         this.endToEndAnyChanged = true;
/*       */       } 
/*       */ 
/*       */       
/*  5038 */       this.endToEndValues = paramArrayOfString;
/*       */     } 
/*       */     
/*  5041 */     this.endToEndECIDSequenceNumber = paramShort;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void updateSystemContext() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetSystemContext() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void updateSystemContext11() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getIncludeSynonyms() {
/*  5100 */     return this.includeSynonyms;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRestrictGetTables(boolean paramBoolean) {
/*  5141 */     this.restrictGettables = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getRestrictGetTables() {
/*  5157 */     return this.restrictGettables;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultFixedString(boolean paramBoolean) {
/*  5186 */     this.fixedString = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultNChar(boolean paramBoolean) {
/*  5195 */     this.defaultnchar = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getDefaultFixedString() {
/*  5223 */     return this.fixedString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getNlsRatio() {
/*  5236 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getC2SNlsRatio() {
/*  5243 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void addStatement(OracleStatement paramOracleStatement) {
/*  5252 */     if (paramOracleStatement.next != null) {
/*  5253 */       throw new Error("add_statement called twice on " + paramOracleStatement);
/*       */     }
/*  5255 */     paramOracleStatement.next = this.statements;
/*       */     
/*  5257 */     if (this.statements != null) {
/*  5258 */       this.statements.prev = paramOracleStatement;
/*       */     }
/*  5260 */     this.statements = paramOracleStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void removeStatement(OracleStatement paramOracleStatement) {
/*  5279 */     OracleStatement oracleStatement1 = paramOracleStatement.prev;
/*  5280 */     OracleStatement oracleStatement2 = paramOracleStatement.next;
/*       */     
/*  5282 */     if (oracleStatement1 == null) {
/*       */       
/*  5284 */       if (this.statements != paramOracleStatement) {
/*       */         return;
/*       */       }
/*  5287 */       this.statements = oracleStatement2;
/*       */     } else {
/*       */       
/*  5290 */       oracleStatement1.next = oracleStatement2;
/*       */     } 
/*  5292 */     if (oracleStatement2 != null) {
/*  5293 */       oracleStatement2.prev = oracleStatement1;
/*       */     }
/*  5295 */     paramOracleStatement.next = null;
/*  5296 */     paramOracleStatement.prev = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void closeStatements(boolean paramBoolean) throws SQLException {
/*  5318 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  5320 */     while (oracleStatement != null) {
/*       */       
/*  5322 */       OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*       */       
/*  5324 */       if (oracleStatement.serverCursor) {
/*       */         
/*  5326 */         oracleStatement.close();
/*  5327 */         removeStatement(oracleStatement);
/*       */       } 
/*       */       
/*  5330 */       oracleStatement = oracleStatement1;
/*       */     } 
/*       */ 
/*       */     
/*  5334 */     oracleStatement = this.statements;
/*       */     
/*  5336 */     while (oracleStatement != null) {
/*       */       
/*  5338 */       OracleStatement oracleStatement1 = oracleStatement.next;
/*       */       
/*  5340 */       if (paramBoolean) {
/*  5341 */         oracleStatement.close();
/*       */       } else {
/*  5343 */         oracleStatement.hardClose();
/*  5344 */       }  removeStatement(oracleStatement);
/*       */       
/*  5346 */       oracleStatement = oracleStatement1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final void purgeStatementCache() throws SQLException {
/*  5357 */     if (isStatementCacheInitialized()) {
/*       */       
/*  5359 */       this.statementCache.purgeImplicitCache();
/*  5360 */       this.statementCache.purgeExplicitCache();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final void closeStatementCache() throws SQLException {
/*  5370 */     if (isStatementCacheInitialized()) {
/*       */ 
/*       */ 
/*       */       
/*  5374 */       this.statementCache.close();
/*       */       
/*  5376 */       this.statementCache = null;
/*  5377 */       this.clearStatementMetaData = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void needLine() throws SQLException {
/*  5386 */     if (this.lifecycle != 1) {
/*       */       
/*  5388 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5389 */       sQLException.fillInStackTrace();
/*  5390 */       throw sQLException;
/*       */     } 
/*       */     
/*  5393 */     needLineUnchecked();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void needLineUnchecked() throws SQLException {
/*  5403 */     if (this.statementHoldingLine != null)
/*       */     {
/*  5405 */       this.statementHoldingLine.freeLine();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement) {
/*  5413 */     holdLine((OracleStatement)paramOracleStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement) {
/*  5422 */     this.statementHoldingLine = paramOracleStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void releaseLine() {
/*  5430 */     releaseLineForCancel();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void releaseLineForCancel() {
/*  5439 */     this.statementHoldingLine = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void startup(String paramString, int paramInt) throws SQLException {
/*  5447 */     if (this.lifecycle != 1) {
/*       */       
/*  5449 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5450 */       sQLException1.fillInStackTrace();
/*  5451 */       throw sQLException1;
/*       */     } 
/*       */ 
/*       */     
/*  5455 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5456 */     sQLException.fillInStackTrace();
/*  5457 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void startup(OracleConnection.DatabaseStartupMode paramDatabaseStartupMode) throws SQLException {
/*  5465 */     if (this.lifecycle != 1) {
/*       */       
/*  5467 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5468 */       sQLException.fillInStackTrace();
/*  5469 */       throw sQLException;
/*       */     } 
/*  5471 */     if (paramDatabaseStartupMode == null) {
/*       */       
/*  5473 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5474 */       sQLException.fillInStackTrace();
/*  5475 */       throw sQLException;
/*       */     } 
/*       */     
/*  5478 */     needLine();
/*  5479 */     doStartup(paramDatabaseStartupMode.getMode());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doStartup(int paramInt) throws SQLException {
/*  5488 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5489 */     sQLException.fillInStackTrace();
/*  5490 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void shutdown(OracleConnection.DatabaseShutdownMode paramDatabaseShutdownMode) throws SQLException {
/*  5499 */     if (this.lifecycle != 1) {
/*       */       
/*  5501 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5502 */       sQLException.fillInStackTrace();
/*  5503 */       throw sQLException;
/*       */     } 
/*  5505 */     if (paramDatabaseShutdownMode == null) {
/*       */       
/*  5507 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5508 */       sQLException.fillInStackTrace();
/*  5509 */       throw sQLException;
/*       */     } 
/*       */     
/*  5512 */     needLine();
/*  5513 */     doShutdown(paramDatabaseShutdownMode.getMode());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doShutdown(int paramInt) throws SQLException {
/*  5522 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5523 */     sQLException.fillInStackTrace();
/*  5524 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void archive(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  5535 */     if (this.lifecycle != 1) {
/*       */       
/*  5537 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5538 */       sQLException1.fillInStackTrace();
/*  5539 */       throw sQLException1;
/*       */     } 
/*       */ 
/*       */     
/*  5543 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5544 */     sQLException.fillInStackTrace();
/*  5545 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerSQLType(String paramString1, String paramString2) throws SQLException {
/*  5559 */     if (paramString1 == null || paramString2 == null) {
/*       */       
/*  5561 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5562 */       sQLException.fillInStackTrace();
/*  5563 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*       */     try {
/*  5568 */       registerSQLType(paramString1, Class.forName(paramString2));
/*       */     }
/*  5570 */     catch (ClassNotFoundException classNotFoundException) {
/*       */ 
/*       */       
/*  5573 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Class not found: " + paramString2);
/*  5574 */       sQLException.fillInStackTrace();
/*  5575 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerSQLType(String paramString, Class<?> paramClass) throws SQLException {
/*  5586 */     if (paramString == null || paramClass == null) {
/*       */       
/*  5588 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5589 */       sQLException.fillInStackTrace();
/*  5590 */       throw sQLException;
/*       */     } 
/*       */     
/*  5593 */     if (this.map == null) this.map = new Hashtable<Object, Object>(10);
/*       */     
/*  5595 */     this.map.put(paramString, paramClass);
/*  5596 */     this.map.put(paramClass.getName(), paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String getSQLType(Object paramObject) throws SQLException {
/*  5604 */     if (paramObject != null && this.map != null) {
/*       */       
/*  5606 */       String str = paramObject.getClass().getName();
/*       */       
/*  5608 */       return (String)this.map.get(str);
/*       */     } 
/*       */     
/*  5611 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getJavaObject(String paramString) throws SQLException {
/*  5619 */     Object object = null;
/*       */ 
/*       */     
/*       */     try {
/*  5623 */       if (paramString != null && this.map != null)
/*       */       {
/*  5625 */         Class<Object> clazz = (Class)this.map.get(paramString);
/*       */         
/*  5627 */         object = clazz.newInstance();
/*       */       }
/*       */     
/*  5630 */     } catch (IllegalAccessException illegalAccessException) {
/*       */       
/*  5632 */       illegalAccessException.printStackTrace();
/*       */     }
/*  5634 */     catch (InstantiationException instantiationException) {
/*       */       
/*  5636 */       instantiationException.printStackTrace();
/*       */     } 
/*       */     
/*  5639 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void putDescriptor(String paramString, Object paramObject) throws SQLException {
/*  5652 */     if (paramString != null && paramObject != null) {
/*       */       
/*  5654 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  5655 */         this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */       }
/*  5657 */       ((TypeDescriptor)paramObject).fixupConnection(this);
/*  5658 */       this.descriptorCacheStack[this.dci].put(paramString, paramObject);
/*       */     }
/*       */     else {
/*       */       
/*  5662 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5663 */       sQLException.fillInStackTrace();
/*  5664 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getDescriptor(String paramString) {
/*  5676 */     Object object = null;
/*       */     
/*  5678 */     if (paramString != null) {
/*  5679 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5680 */         object = this.descriptorCacheStack[this.dci].get(paramString); 
/*  5681 */       if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5682 */         object = this.descriptorCacheStack[0].get(paramString);
/*       */       }
/*       */     } 
/*  5685 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDecriptor(String paramString) {
/*  5697 */     removeDescriptor(paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDescriptor(String paramString) {
/*  5711 */     if (paramString != null && this.descriptorCacheStack[this.dci] != null)
/*  5712 */       this.descriptorCacheStack[this.dci].remove(paramString); 
/*  5713 */     if (paramString != null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5714 */       this.descriptorCacheStack[0].remove(paramString);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeAllDescriptor() {
/*  5725 */     for (byte b = 0; b <= this.dci; b++) {
/*  5726 */       if (this.descriptorCacheStack[b] != null) {
/*  5727 */         this.descriptorCacheStack[b].clear();
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int numberOfDescriptorCacheEntries() {
/*  5744 */     int i = 0;
/*  5745 */     for (byte b = 0; b <= this.dci; b++) {
/*  5746 */       if (this.descriptorCacheStack[b] != null)
/*  5747 */         i += this.descriptorCacheStack[b].size(); 
/*       */     } 
/*  5749 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Enumeration descriptorCacheKeys() {
/*  5762 */     if (this.dci == 0) {
/*  5763 */       if (this.descriptorCacheStack[this.dci] != null) {
/*  5764 */         return this.descriptorCacheStack[this.dci].keys();
/*       */       }
/*  5766 */       return null;
/*       */     } 
/*  5768 */     if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] != null)
/*  5769 */       return this.descriptorCacheStack[1].keys(); 
/*  5770 */     if (this.descriptorCacheStack[1] == null && this.descriptorCacheStack[0] != null)
/*  5771 */       return this.descriptorCacheStack[0].keys(); 
/*  5772 */     if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] == null) {
/*  5773 */       return null;
/*       */     }
/*  5775 */     Vector vector = new Vector(this.descriptorCacheStack[1].keySet());
/*  5776 */     vector.addAll(this.descriptorCacheStack[0].keySet());
/*  5777 */     return vector.elements();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void putDescriptor(byte[] paramArrayOfbyte, Object paramObject) throws SQLException {
/*  5791 */     if (paramArrayOfbyte != null && paramObject != null) {
/*       */       
/*  5793 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  5794 */         this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */       }
/*  5796 */       this.descriptorCacheStack[this.dci].put(new ByteArrayKey(paramArrayOfbyte), paramObject);
/*       */     }
/*       */     else {
/*       */       
/*  5800 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5801 */       sQLException.fillInStackTrace();
/*  5802 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getDescriptor(byte[] paramArrayOfbyte) {
/*  5814 */     Object object = null;
/*       */     
/*  5816 */     if (paramArrayOfbyte != null) {
/*  5817 */       ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
/*  5818 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5819 */         object = this.descriptorCacheStack[this.dci].get(byteArrayKey); 
/*  5820 */       if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5821 */         object = this.descriptorCacheStack[0].get(byteArrayKey);
/*       */       }
/*       */     } 
/*  5824 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDecriptor(byte[] paramArrayOfbyte) {
/*  5836 */     if (paramArrayOfbyte != null) {
/*  5837 */       ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
/*  5838 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5839 */         this.descriptorCacheStack[this.dci].remove(byteArrayKey); 
/*  5840 */       if (this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5841 */         this.descriptorCacheStack[0].remove(byteArrayKey);
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getJdbcCsId() throws SQLException {
/*  5864 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5867 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5868 */       sQLException.fillInStackTrace();
/*  5869 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5873 */     return this.conversion.getClientCharSet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getDbCsId() throws SQLException {
/*  5888 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5891 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5892 */       sQLException.fillInStackTrace();
/*  5893 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5897 */     return this.conversion.getServerCharSetId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getNCsId() throws SQLException {
/*  5904 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5907 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5908 */       sQLException.fillInStackTrace();
/*  5909 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5913 */     return this.conversion.getNCharSetId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getStructAttrCsId() throws SQLException {
/*  5929 */     return getDbCsId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getStructAttrNCsId() throws SQLException {
/*  5936 */     return getNCsId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Map getTypeMap() {
/*  5946 */     if (this.map == null) this.map = new Hashtable<Object, Object>(10); 
/*  5947 */     return this.map;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setTypeMap(Map paramMap) {
/*  5954 */     this.map = paramMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setUsingXAFlag(boolean paramBoolean) {
/*  5962 */     this.usingXA = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getUsingXAFlag() {
/*  5969 */     return this.usingXA;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setXAErrorFlag(boolean paramBoolean) {
/*  5977 */     this.xaWantsError = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getXAErrorFlag() {
/*  5984 */     return this.xaWantsError;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String getPropertyFromDatabase(String paramString) throws SQLException {
/*  5992 */     String str = null;
/*  5993 */     Statement statement = null;
/*  5994 */     ResultSet resultSet = null;
/*       */     
/*       */     try {
/*  5997 */       statement = createStatement();
/*  5998 */       statement.setFetchSize(1);
/*  5999 */       resultSet = statement.executeQuery(paramString);
/*  6000 */       if (resultSet.next()) {
/*  6001 */         str = resultSet.getString(1);
/*       */       }
/*       */     } finally {
/*       */       
/*  6005 */       if (resultSet != null)
/*  6006 */         resultSet.close(); 
/*  6007 */       if (statement != null)
/*  6008 */         statement.close(); 
/*       */     } 
/*  6010 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String getUserName() throws SQLException {
/*  6018 */     if (this.userName == null) {
/*  6019 */       this.userName = getPropertyFromDatabase("SELECT USER FROM DUAL");
/*       */     }
/*  6021 */     return this.userName;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getCurrentSchema() throws SQLException {
/*  6037 */     return getPropertyFromDatabase("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL");
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDefaultSchemaNameForNamedTypes() throws SQLException {
/*  6055 */     String str = null;
/*       */     
/*  6057 */     if (this.createDescriptorUseCurrentSchemaForSchemaName) {
/*  6058 */       str = getCurrentSchema();
/*       */     } else {
/*  6060 */       str = getUserName();
/*       */     } 
/*  6062 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStartTime(long paramLong) throws SQLException {
/*  6080 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6081 */     sQLException.fillInStackTrace();
/*  6082 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized long getStartTime() throws SQLException {
/*  6098 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6099 */     sQLException.fillInStackTrace();
/*  6100 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void registerHeartbeat() throws SQLException {
/*  6113 */     if (this.logicalConnectionAttached != null) {
/*  6114 */       this.logicalConnectionAttached.registerHeartbeat();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getHeartbeatNoChangeCount() throws SQLException {
/*  6126 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6127 */     sQLException.fillInStackTrace();
/*  6128 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized byte[] getFDO(boolean paramBoolean) throws SQLException {
/*  6140 */     if (this.fdo == null && paramBoolean) {
/*       */       
/*  6142 */       CallableStatement callableStatement = null;
/*       */ 
/*       */       
/*       */       try {
/*  6146 */         callableStatement = prepareCall("begin :1 := dbms_pickler.get_format (:2); end;");
/*       */ 
/*       */         
/*  6149 */         callableStatement.registerOutParameter(1, 2);
/*  6150 */         callableStatement.registerOutParameter(2, -4);
/*  6151 */         callableStatement.execute();
/*       */         
/*  6153 */         this.fdo = callableStatement.getBytes(2);
/*       */       }
/*       */       finally {
/*       */         
/*  6157 */         if (callableStatement != null) {
/*  6158 */           callableStatement.close();
/*       */         }
/*  6160 */         callableStatement = null;
/*       */       } 
/*       */     } 
/*       */     
/*  6164 */     return this.fdo;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setFDO(byte[] paramArrayOfbyte) throws SQLException {
/*  6175 */     this.fdo = paramArrayOfbyte;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getBigEndian() throws SQLException {
/*  6186 */     if (this.bigEndian == null) {
/*       */       
/*  6188 */       int[] arrayOfInt = Util.toJavaUnsignedBytes(getFDO(true));
/*       */ 
/*       */ 
/*       */       
/*  6192 */       int i = arrayOfInt[6 + arrayOfInt[5] + arrayOfInt[6] + 5];
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6197 */       int j = (byte)(i & 0x10);
/*       */       
/*  6199 */       if (j < 0) {
/*  6200 */         j = j + 256;
/*       */       }
/*  6202 */       if (j > 0) {
/*  6203 */         this.bigEndian = Boolean.TRUE;
/*       */       } else {
/*  6205 */         this.bigEndian = Boolean.FALSE;
/*       */       } 
/*       */     } 
/*  6208 */     return this.bigEndian.booleanValue();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setHoldability(int paramInt) throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getHoldability() throws SQLException {
/*  6261 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Savepoint setSavepoint() throws SQLException {
/*  6270 */     return (Savepoint)oracleSetSavepoint();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Savepoint setSavepoint(String paramString) throws SQLException {
/*  6280 */     return (Savepoint)oracleSetSavepoint(paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void rollback(Savepoint paramSavepoint) throws SQLException {
/*  6291 */     disallowGlobalTxnMode(122);
/*       */ 
/*       */     
/*  6294 */     if (this.autocommit) {
/*       */       
/*  6296 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  6297 */       sQLException.fillInStackTrace();
/*  6298 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6303 */     if (this.savepointStatement == null)
/*       */     {
/*  6305 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6308 */     String str = null;
/*       */ 
/*       */     
/*       */     try {
/*  6312 */       str = paramSavepoint.getSavepointName();
/*       */     }
/*  6314 */     catch (SQLException sQLException) {
/*       */       
/*  6316 */       str = "ORACLE_SVPT_" + paramSavepoint.getSavepointId();
/*       */     } 
/*       */     
/*  6319 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void releaseSavepoint(Savepoint paramSavepoint) throws SQLException {
/*  6329 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6330 */     sQLException.fillInStackTrace();
/*  6331 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6377 */     return createStatement(paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6428 */     return prepareStatement(paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6476 */     return prepareCall(paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLException {
/*  6526 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString);
/*  6527 */     if (paramInt == 2 || !autoKeyInfo.isInsertSqlStmt())
/*       */     {
/*  6529 */       return prepareStatement(paramString);
/*       */     }
/*  6531 */     if (paramInt != 1) {
/*       */       
/*  6533 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6534 */       sQLException.fillInStackTrace();
/*  6535 */       throw sQLException;
/*       */     } 
/*       */     
/*  6538 */     String str = autoKeyInfo.getNewSql();
/*  6539 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6540 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6542 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6543 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6544 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6545 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLException {
/*  6594 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint);
/*       */     
/*  6596 */     if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
/*       */     
/*  6598 */     if (paramArrayOfint == null || paramArrayOfint.length == 0) {
/*       */       
/*  6600 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6601 */       sQLException.fillInStackTrace();
/*  6602 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6607 */     doDescribeTable(autoKeyInfo);
/*       */     
/*  6609 */     String str = autoKeyInfo.getNewSql();
/*  6610 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6611 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6613 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6614 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6615 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6616 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLException {
/*  6666 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/*  6667 */     if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
/*       */     
/*  6669 */     if (paramArrayOfString == null || paramArrayOfString.length == 0) {
/*       */       
/*  6671 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6672 */       sQLException.fillInStackTrace();
/*  6673 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6677 */     doDescribeTable(autoKeyInfo);
/*       */     
/*  6679 */     String str = autoKeyInfo.getNewSql();
/*  6680 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6681 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6683 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6684 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6685 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6686 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleSavepoint oracleSetSavepoint() throws SQLException {
/*  6712 */     disallowGlobalTxnMode(117);
/*       */ 
/*       */     
/*  6715 */     if (this.autocommit) {
/*       */       
/*  6717 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  6718 */       sQLException.fillInStackTrace();
/*  6719 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6724 */     if (this.savepointStatement == null)
/*       */     {
/*  6726 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6729 */     OracleSavepoint oracleSavepoint = new OracleSavepoint();
/*       */     
/*  6731 */     String str = "SAVEPOINT ORACLE_SVPT_" + oracleSavepoint.getSavepointId();
/*       */     
/*  6733 */     this.savepointStatement.executeUpdate(str);
/*       */ 
/*       */     
/*  6736 */     return oracleSavepoint;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleSavepoint oracleSetSavepoint(String paramString) throws SQLException {
/*  6763 */     disallowGlobalTxnMode(117);
/*       */ 
/*       */     
/*  6766 */     if (this.autocommit) {
/*       */       
/*  6768 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  6769 */       sQLException.fillInStackTrace();
/*  6770 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6775 */     if (this.savepointStatement == null)
/*       */     {
/*  6777 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6780 */     OracleSavepoint oracleSavepoint = new OracleSavepoint(paramString);
/*       */     
/*  6782 */     String str = "SAVEPOINT " + oracleSavepoint.getSavepointName();
/*       */     
/*  6784 */     this.savepointStatement.executeUpdate(str);
/*       */ 
/*       */     
/*  6787 */     return oracleSavepoint;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void oracleRollback(OracleSavepoint paramOracleSavepoint) throws SQLException {
/*  6815 */     disallowGlobalTxnMode(115);
/*       */ 
/*       */     
/*  6818 */     if (this.autocommit) {
/*       */       
/*  6820 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  6821 */       sQLException.fillInStackTrace();
/*  6822 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6827 */     if (this.savepointStatement == null)
/*       */     {
/*  6829 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6832 */     String str = null;
/*       */ 
/*       */     
/*       */     try {
/*  6836 */       str = paramOracleSavepoint.getSavepointName();
/*       */     }
/*  6838 */     catch (SQLException sQLException) {
/*       */       
/*  6840 */       str = "ORACLE_SVPT_" + paramOracleSavepoint.getSavepointId();
/*       */     } 
/*       */     
/*  6843 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void oracleReleaseSavepoint(OracleSavepoint paramOracleSavepoint) throws SQLException {
/*  6871 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6872 */     sQLException.fillInStackTrace();
/*  6873 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void disallowGlobalTxnMode(int paramInt) throws SQLException {
/*  6894 */     if (this.txnMode == 1) {
/*       */       
/*  6896 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/*  6897 */       sQLException.fillInStackTrace();
/*  6898 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTxnMode(int paramInt) {
/*  6912 */     this.txnMode = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getTxnMode() {
/*  6919 */     return this.txnMode;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getClientData(Object paramObject) {
/*  6948 */     if (this.clientData == null)
/*       */     {
/*  6950 */       return null;
/*       */     }
/*       */     
/*  6953 */     return this.clientData.get(paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object setClientData(Object paramObject1, Object paramObject2) {
/*  6980 */     if (this.clientData == null)
/*       */     {
/*  6982 */       this.clientData = new Hashtable<Object, Object>();
/*       */     }
/*       */     
/*  6985 */     return this.clientData.put(paramObject1, paramObject2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object removeClientData(Object paramObject) {
/*  7006 */     if (this.clientData == null)
/*       */     {
/*  7008 */       return null;
/*       */     }
/*       */     
/*  7011 */     return this.clientData.remove(paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BlobDBAccess createBlobDBAccess() throws SQLException {
/*  7019 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7020 */     sQLException.fillInStackTrace();
/*  7021 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ClobDBAccess createClobDBAccess() throws SQLException {
/*  7030 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7031 */     sQLException.fillInStackTrace();
/*  7032 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BfileDBAccess createBfileDBAccess() throws SQLException {
/*  7041 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7042 */     sQLException.fillInStackTrace();
/*  7043 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void printState() {
/*       */     try {
/*  7069 */       short s1 = getJdbcCsId();
/*       */ 
/*       */       
/*  7072 */       short s2 = getDbCsId();
/*       */ 
/*       */       
/*  7075 */       short s3 = getStructAttrCsId();
/*       */     
/*       */     }
/*  7078 */     catch (SQLException sQLException) {
/*       */       
/*  7080 */       sQLException.printStackTrace();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getProtocolType() {
/*  7092 */     return this.protocol;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getURL() {
/*  7103 */     return this.url;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStmtCacheSize(int paramInt) throws SQLException {
/*  7117 */     setStatementCacheSize(paramInt);
/*  7118 */     setImplicitCachingEnabled(true);
/*  7119 */     setExplicitCachingEnabled(true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean) throws SQLException {
/*  7134 */     setStatementCacheSize(paramInt);
/*  7135 */     setImplicitCachingEnabled(true);
/*       */ 
/*       */     
/*  7138 */     setExplicitCachingEnabled(true);
/*       */     
/*  7140 */     this.clearStatementMetaData = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getStmtCacheSize() {
/*  7154 */     int i = 0;
/*       */ 
/*       */     
/*       */     try {
/*  7158 */       i = getStatementCacheSize();
/*       */     }
/*  7160 */     catch (SQLException sQLException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7166 */     if (i == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7171 */       i = 0;
/*       */     }
/*       */     
/*  7174 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStatementCacheSize(int paramInt) throws SQLException {
/*  7195 */     if (this.statementCache == null) {
/*       */       
/*  7197 */       this.statementCache = new LRUStatementCache(paramInt);
/*       */ 
/*       */     
/*       */     }
/*       */     else {
/*       */ 
/*       */       
/*  7204 */       this.statementCache.resize(paramInt);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getStatementCacheSize() throws SQLException {
/*  7223 */     if (this.statementCache == null) {
/*  7224 */       return -1;
/*       */     }
/*  7226 */     return this.statementCache.getCacheSize();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setImplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  7249 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7254 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7261 */     this.statementCache.setImplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getImplicitCachingEnabled() throws SQLException {
/*  7280 */     if (this.statementCache == null) {
/*  7281 */       return false;
/*       */     }
/*  7283 */     return this.statementCache.getImplicitCachingEnabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setExplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  7306 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7311 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7318 */     this.statementCache.setExplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getExplicitCachingEnabled() throws SQLException {
/*  7337 */     if (this.statementCache == null) {
/*  7338 */       return false;
/*       */     }
/*  7340 */     return this.statementCache.getExplicitCachingEnabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void purgeImplicitCache() throws SQLException {
/*  7359 */     if (this.statementCache != null) {
/*  7360 */       this.statementCache.purgeImplicitCache();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void purgeExplicitCache() throws SQLException {
/*  7379 */     if (this.statementCache != null) {
/*  7380 */       this.statementCache.purgeExplicitCache();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement getStatementWithKey(String paramString) throws SQLException {
/*  7402 */     if (this.statementCache != null) {
/*       */       
/*  7404 */       OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */       
/*  7407 */       if (oracleStatement == null || oracleStatement.statementType == 1) {
/*  7408 */         return (PreparedStatement)oracleStatement;
/*       */       }
/*       */ 
/*       */       
/*  7412 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  7413 */       sQLException.fillInStackTrace();
/*  7414 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7419 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement getCallWithKey(String paramString) throws SQLException {
/*  7441 */     if (this.statementCache != null) {
/*       */       
/*  7443 */       OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */       
/*  7446 */       if (oracleStatement == null || oracleStatement.statementType == 2) {
/*  7447 */         return (CallableStatement)oracleStatement;
/*       */       }
/*       */ 
/*       */       
/*  7451 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  7452 */       sQLException.fillInStackTrace();
/*  7453 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7458 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void cacheImplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  7474 */     if (this.statementCache == null) {
/*       */       
/*  7476 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  7477 */       sQLException.fillInStackTrace();
/*  7478 */       throw sQLException;
/*       */     } 
/*       */     
/*  7481 */     this.statementCache.addToImplicitCache(paramOraclePreparedStatement, paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void cacheExplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString) throws SQLException {
/*  7498 */     if (this.statementCache == null) {
/*       */       
/*  7500 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  7501 */       sQLException.fillInStackTrace();
/*  7502 */       throw sQLException;
/*       */     } 
/*       */     
/*  7505 */     this.statementCache.addToExplicitCache(paramOraclePreparedStatement, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isStatementCacheInitialized() {
/*  7520 */     if (this.statementCache == null)
/*  7521 */       return false; 
/*  7522 */     if (this.statementCache.getCacheSize() == 0) {
/*  7523 */       return false;
/*       */     }
/*  7525 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final class BufferCacheStore
/*       */   {
/*  7561 */     static int MAX_CACHED_BUFFER_SIZE = Integer.MAX_VALUE;
/*       */     final BufferCache<byte[]> byteBufferCache;
/*       */     final BufferCache<char[]> charBufferCache;
/*       */     
/*       */     BufferCacheStore() {
/*  7566 */       this(MAX_CACHED_BUFFER_SIZE);
/*       */     }
/*       */     
/*       */     BufferCacheStore(int param1Int) {
/*  7570 */       this.byteBufferCache = (BufferCache)new BufferCache<byte>(param1Int);
/*  7571 */       this.charBufferCache = (BufferCache)new BufferCache<char>(param1Int);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private BufferCacheStore getBufferCacheStore() {
/*  7582 */     if (this.useThreadLocalBufferCache) {
/*  7583 */       if (threadLocalBufferCacheStore == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7596 */         BufferCacheStore.MAX_CACHED_BUFFER_SIZE = this.maxCachedBufferSize;
/*  7597 */         threadLocalBufferCacheStore = new ThreadLocal<BufferCacheStore>()
/*       */           {
/*       */             protected PhysicalConnection.BufferCacheStore initialValue()
/*       */             {
/*  7601 */               return new PhysicalConnection.BufferCacheStore();
/*       */             }
/*       */           };
/*       */       } 
/*  7605 */       return threadLocalBufferCacheStore.get();
/*       */     } 
/*       */     
/*  7608 */     if (this.connectionBufferCacheStore == null)
/*       */     {
/*  7610 */       this.connectionBufferCacheStore = new BufferCacheStore(this.maxCachedBufferSize);
/*       */     }
/*  7612 */     return this.connectionBufferCacheStore;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cacheBuffer(byte[] paramArrayOfbyte) {
/*  7623 */     if (paramArrayOfbyte != null) {
/*  7624 */       BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7625 */       bufferCacheStore.byteBufferCache.put(paramArrayOfbyte);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cacheBuffer(char[] paramArrayOfchar) {
/*  7637 */     if (paramArrayOfchar != null) {
/*  7638 */       BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7639 */       bufferCacheStore.charBufferCache.put(paramArrayOfchar);
/*       */     } 
/*       */   }
/*       */ 
/*       */   
/*       */   public void cacheBufferSync(char[] paramArrayOfchar) {
/*  7645 */     synchronized (this) {
/*  7646 */       cacheBuffer(paramArrayOfchar);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] getByteBuffer(int paramInt) {
/*  7658 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7659 */     return bufferCacheStore.byteBufferCache.get(byte.class, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   char[] getCharBuffer(int paramInt) {
/*  7671 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7672 */     return bufferCacheStore.charBufferCache.get(char.class, paramInt);
/*       */   }
/*       */ 
/*       */   
/*       */   public char[] getCharBufferSync(int paramInt) {
/*  7677 */     synchronized (this) {
/*  7678 */       return getCharBuffer(paramInt);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics() {
/*  7689 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7690 */     return bufferCacheStore.byteBufferCache.getStatistics();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics() {
/*  7701 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7702 */     return bufferCacheStore.charBufferCache.getStatistics();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject) throws SQLException {
/*  7725 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7726 */     sQLException.fillInStackTrace();
/*  7727 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDatabaseProductVersion() throws SQLException {
/*  7740 */     if (this.databaseProductVersion == "") {
/*       */       
/*  7742 */       needLine();
/*       */       
/*  7744 */       this.databaseProductVersion = doGetDatabaseProductVersion();
/*       */     } 
/*       */     
/*  7747 */     return this.databaseProductVersion;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getReportRemarks() {
/*  7754 */     return this.reportRemarks;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getVersionNumber() throws SQLException {
/*  7761 */     if (this.versionNumber == -1)
/*       */     {
/*  7763 */       synchronized (this) {
/*       */         
/*  7765 */         if (this.versionNumber == -1) {
/*       */           
/*  7767 */           needLine();
/*       */           
/*  7769 */           this.versionNumber = doGetVersionNumber();
/*       */         } 
/*       */       } 
/*       */     }
/*       */     
/*  7774 */     return this.versionNumber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerCloseCallback(OracleCloseCallback paramOracleCloseCallback, Object paramObject) {
/*  7782 */     this.closeCallback = paramOracleCloseCallback;
/*  7783 */     this.privateData = paramObject;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCreateStatementAsRefCursor(boolean paramBoolean) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getCreateStatementAsRefCursor() {
/*  7831 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int pingDatabase() throws SQLException {
/*  7842 */     if (this.lifecycle != 1)
/*  7843 */       return -1; 
/*  7844 */     return doPingDatabase();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int pingDatabase(int paramInt) throws SQLException {
/*  7857 */     if (this.lifecycle != 1)
/*  7858 */       return -1; 
/*  7859 */     if (paramInt == 0) {
/*  7860 */       return pingDatabase();
/*       */     }
/*       */     
/*       */     try {
/*  7864 */       this.pingResult = -2;
/*  7865 */       Thread thread = new Thread(new Runnable() {
/*       */             public void run() {
/*       */               try {
/*  7868 */                 PhysicalConnection.this.pingResult = PhysicalConnection.this.doPingDatabase();
/*       */               }
/*  7870 */               catch (Throwable throwable) {}
/*       */             }
/*       */           });
/*  7873 */       thread.start();
/*  7874 */       thread.join((paramInt * 1000));
/*  7875 */       return this.pingResult;
/*       */     }
/*  7877 */     catch (InterruptedException interruptedException) {
/*  7878 */       return -3;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int doPingDatabase() throws SQLException {
/*  7887 */     Statement statement = null;
/*       */ 
/*       */     
/*       */     try {
/*  7891 */       statement = createStatement();
/*       */       
/*  7893 */       ((OracleStatement)statement).defineColumnType(1, 12, 1);
/*  7894 */       statement.executeQuery("SELECT 'x' FROM DUAL");
/*       */     }
/*  7896 */     catch (SQLException sQLException) {
/*       */       
/*  7898 */       return -1;
/*       */     }
/*       */     finally {
/*       */       
/*  7902 */       if (statement != null) {
/*  7903 */         statement.close();
/*       */       }
/*       */     } 
/*  7906 */     return 0;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Map getJavaObjectTypeMap() {
/*  7922 */     return this.javaObjectMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setJavaObjectTypeMap(Map paramMap) {
/*  7932 */     this.javaObjectMap = paramMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearClientIdentifier(String paramString) throws SQLException {
/*  7947 */     if (paramString != null && paramString.length() != 0) {
/*       */ 
/*       */ 
/*       */       
/*  7951 */       String[] arrayOfString = getEndToEndMetrics();
/*       */       
/*  7953 */       if (arrayOfString != null && paramString.equals(arrayOfString[1])) {
/*       */ 
/*       */         
/*  7956 */         arrayOfString[1] = null;
/*       */         
/*  7958 */         setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClientIdentifier(String paramString) throws SQLException {
/*  7980 */     String[] arrayOfString = getEndToEndMetrics();
/*       */     
/*  7982 */     if (arrayOfString == null)
/*       */     {
/*  7984 */       arrayOfString = new String[4];
/*       */     }
/*       */ 
/*       */     
/*  7988 */     arrayOfString[1] = paramString;
/*       */     
/*  7990 */     setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected PhysicalConnection()
/*       */   {
/*  8002 */     this.sessionTimeZone = null;
/*  8003 */     this.databaseTimeZone = null;
/*  8004 */     this.dbTzCalendar = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 11046 */     this.timeZoneVersionNumber = -1;
/* 11047 */     this.timeZoneTab = null; } public void setSessionTimeZone(String paramString) throws SQLException { Statement statement = null; Object object = null; try { statement = createStatement(); statement.executeUpdate("ALTER SESSION SET TIME_ZONE = '" + paramString + "'"); if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  } catch (SQLException sQLException) { throw sQLException; } finally { if (statement != null) statement.close();  }  this.sessionTimeZone = paramString; } public String getDatabaseTimeZone() throws SQLException { if (this.databaseTimeZone == null) this.databaseTimeZone = getPropertyFromDatabase("SELECT DBTIMEZONE FROM DUAL");  return this.databaseTimeZone; } public String getSessionTimeZone() { return this.sessionTimeZone; } private static String to2DigitString(int paramInt) { String str; if (paramInt < 10) { str = "0" + paramInt; } else { str = "" + paramInt; }  return str; } public String tzToOffset(String paramString) { if (paramString == null) return paramString;  char c = paramString.charAt(0); if (c != '-' && c != '+') { TimeZone timeZone = TimeZone.getTimeZone(paramString); int i = timeZone.getOffset(System.currentTimeMillis()); if (i != 0) { int j = i / 60000; int k = j / 60; j -= k * 60; if (i > 0) { paramString = "+" + to2DigitString(k) + ":" + to2DigitString(j); } else { paramString = "-" + to2DigitString(-k) + ":" + to2DigitString(-j); }  } else { paramString = "+00:00"; }  }  return paramString; } public String getSessionTimeZoneOffset() throws SQLException { String str = getPropertyFromDatabase("SELECT SESSIONTIMEZONE FROM DUAL"); if (str != null) str = tzToOffset(str.trim());  return str; } private void setDbTzCalendar(String paramString) { char c = paramString.charAt(0); if (c == '-' || c == '+') paramString = "GMT" + paramString;  TimeZone timeZone = TimeZone.getTimeZone(paramString); this.dbTzCalendar = new GregorianCalendar(timeZone); } public Calendar getDbTzCalendar() throws SQLException { if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  return this.dbTzCalendar; } public void setAccumulateBatchResult(boolean paramBoolean) { this.accumulateBatchResult = paramBoolean; } public boolean isAccumulateBatchResult() { return this.accumulateBatchResult; } public void setJ2EE13Compliant(boolean paramBoolean) { this.j2ee13Compliant = paramBoolean; } public boolean getJ2EE13Compliant() { return this.j2ee13Compliant; } public Class classForNameAndSchema(String paramString1, String paramString2) throws ClassNotFoundException { return Class.forName(paramString1); } public Class safelyGetClassForName(String paramString) throws ClassNotFoundException { return Class.forName(paramString); } public int getHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public int getOCIEnvHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public static OracleConnection unwrapCompletely(OracleConnection paramOracleConnection) { OracleConnection oracleConnection1 = paramOracleConnection; OracleConnection oracleConnection2 = oracleConnection1; while (true) { if (oracleConnection2 == null) return (OracleConnection)oracleConnection1;  oracleConnection1 = oracleConnection2; oracleConnection2 = oracleConnection1.unwrap(); }  } public void setWrapper(OracleConnection paramOracleConnection) { this.wrapper = paramOracleConnection; } public OracleConnection unwrap() { return null; } public OracleConnection getWrapper() { if (this.wrapper != null) return this.wrapper;  return (OracleConnection)this; } static OracleConnection _physicalConnectionWithin(Connection paramConnection) { OracleConnection oracleConnection = null; if (paramConnection != null) oracleConnection = unwrapCompletely((OracleConnection)paramConnection);  return oracleConnection; } public OracleConnection physicalConnectionWithin() { return this; } public long getTdoCState(String paramString1, String paramString2) throws SQLException { return 0L; } public void getOracleTypeADT(OracleTypeADT paramOracleTypeADT) throws SQLException {} public Datum toDatum(CustomDatum paramCustomDatum) throws SQLException { return paramCustomDatum.toDatum(this); } public short getNCharSet() { return this.conversion.getNCharSetId(); } public ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramArrayOfDatum, paramLong, paramInt, paramMap); } public ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramARRAY, paramLong, paramInt, paramMap); } public ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayLocatorResultSet(this, paramArrayDescriptor, paramArrayOfbyte, paramLong, paramInt, paramMap); } public ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor) throws SQLException { return (ResultSetMetaData)new StructMetaData(paramStructDescriptor); } public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; arrayOfInt[0] = paramInt; return this.conversion.CHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; return this.conversion.NCHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public boolean IsNCharFixedWith() { return this.conversion.IsNCharFixedWith(); } public short getDriverCharSet() { return this.conversion.getClientCharSet(); } public int getMaxCharSize() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 58); sQLException.fillInStackTrace(); throw sQLException; } public int getMaxCharbyteSize() { return this.conversion.getMaxCharbyteSize(); } public int getMaxNCharbyteSize() { return this.conversion.getMaxNCharbyteSize(); } public boolean isCharSetMultibyte(short paramShort) { return DBConversion.isCharSetMultibyte(paramShort); } PhysicalConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { this.sessionTimeZone = null; this.databaseTimeZone = null; this.dbTzCalendar = null; this.timeZoneVersionNumber = -1; this.timeZoneTab = null; readConnectionProperties(paramString, paramProperties); this.driverExtension = paramOracleDriverExtension; initialize((Hashtable)null, (Map)null, (Map)null); this.logicalConnectionAttached = null; try { needLine(); logon(); setAutoCommit(this.autocommit); if (getVersionNumber() >= 11202) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 64; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 64; } else if (getVersionNumber() >= 11000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (getVersionNumber() >= 10000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (getVersionNumber() >= 9200) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 2000; this.maxVcsCharsSql = 4000; this.maxVcsNCharsSql = 4000; this.maxVcsBytesPlsql = 4000; this.maxIbtVarcharElementLength = 4000; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; }  initializeSetCHARCharSetObjs(); if (this.implicitStatementCacheSize > 0) { setStatementCacheSize(this.implicitStatementCacheSize); setImplicitCachingEnabled(true); }  } catch (SQLException sQLException) { this.lifecycle = 2; try { logoff(); } catch (SQLException sQLException1) {} this.lifecycle = 4; throw sQLException; }  this.txnMode = 0; }
/*       */   public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); }
/*       */   public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToNCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); }
/*       */   final void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection, String paramString) throws SQLException { Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>(); hashtable.put("obj_type_map", this.javaObjectMap); Properties properties = new Properties(); properties.put("user", this.userName); properties.put("password", paramString); properties.put("connection_url", this.url); properties.put("connect_auto_commit", "" + this.autocommit); properties.put("trans_isolation", "" + this.txnLevel); if (getStatementCacheSize() != -1) { properties.put("stmt_cache_size", "" + getStatementCacheSize()); properties.put("implicit_cache_enabled", "" + getImplicitCachingEnabled()); properties.put("explict_cache_enabled", "" + getExplicitCachingEnabled()); }  properties.put("defaultExecuteBatch", "" + this.defaultExecuteBatch); properties.put("defaultRowPrefetch", "" + this.defaultRowPrefetch); properties.put("remarksReporting", "" + this.reportRemarks); properties.put("AccumulateBatchResult", "" + this.accumulateBatchResult); properties.put("oracle.jdbc.J2EE13Compliant", "" + this.j2ee13Compliant); properties.put("processEscapes", "" + this.processEscapes); properties.put("restrictGetTables", "" + this.restrictGettables); properties.put("includeSynonyms", "" + this.includeSynonyms); properties.put("fixedString", "" + this.fixedString); hashtable.put("connection_properties", properties); paramOraclePooledConnection.setProperties(hashtable); }
/* 11051 */   public Properties getDBAccessProperties() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Properties getOCIHandles() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void logoff() throws SQLException {} int getDefaultStreamChunkSize() { return this.streamChunkSize; } public OracleStatement refCursorCursorToStatement(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException { if (this.logicalConnectionAttached != null || paramOraclePooledConnection.getPhysicalHandle() != this) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143); sQLException.fillInStackTrace(); throw sQLException; }  LogicalConnection logicalConnection = new LogicalConnection(paramOraclePooledConnection, this, paramBoolean); this.logicalConnectionAttached = logicalConnection; return (Connection)logicalConnection; } public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {} public CLOB createClob(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte, true); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClob(byte[] paramArrayOfbyte, short paramShort) throws SQLException { if (paramShort == 2) return (CLOB)new NCLOB((OracleConnection)this, paramArrayOfbyte);  return new CLOB((OracleConnection)this, paramArrayOfbyte, paramShort); } public BLOB createBlob(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte); } public BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte, true); } public BFILE createBfile(byte[] paramArrayOfbyte) throws SQLException { return new BFILE((OracleConnection)this, paramArrayOfbyte); } public ARRAY createARRAY(String paramString, Object paramObject) throws SQLException { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this); return new ARRAY(arrayDescriptor, (Connection)this, paramObject); } public Array createOracleArray(String paramString, Object paramObject) throws SQLException { return (Array)createARRAY(paramString, paramObject); } public BINARY_DOUBLE createBINARY_DOUBLE(double paramDouble) throws SQLException { return new BINARY_DOUBLE(paramDouble); } public BINARY_FLOAT createBINARY_FLOAT(float paramFloat) throws SQLException { return new BINARY_FLOAT(paramFloat); } public DATE createDATE(Date paramDate) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(Date paramDate, Calendar paramCalendar) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime, Calendar paramCalendar) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(String paramString) throws SQLException { return new DATE(paramString); } public INTERVALDS createINTERVALDS(String paramString) throws SQLException { return new INTERVALDS(paramString); } public INTERVALYM createINTERVALYM(String paramString) throws SQLException { return new INTERVALYM(paramString); } public NUMBER createNUMBER(boolean paramBoolean) throws SQLException { return new NUMBER(paramBoolean); } public NUMBER createNUMBER(byte paramByte) throws SQLException { return new NUMBER(paramByte); } public NUMBER createNUMBER(short paramShort) throws SQLException { return new NUMBER(paramShort); } public NUMBER createNUMBER(int paramInt) throws SQLException { return new NUMBER(paramInt); } public NUMBER createNUMBER(long paramLong) throws SQLException { return new NUMBER(paramLong); } public NUMBER createNUMBER(float paramFloat) throws SQLException { return new NUMBER(paramFloat); } public NUMBER createNUMBER(double paramDouble) throws SQLException { return new NUMBER(paramDouble); } public NUMBER createNUMBER(BigDecimal paramBigDecimal) throws SQLException { return new NUMBER(paramBigDecimal); } public NUMBER createNUMBER(BigInteger paramBigInteger) throws SQLException { return new NUMBER(paramBigInteger); } public int getTimezoneVersionNumber() throws SQLException { return this.timeZoneVersionNumber; } public NUMBER createNUMBER(String paramString, int paramInt) throws SQLException { return new NUMBER(paramString, paramInt); } public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException { try { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this); return (Struct)new STRUCT(structDescriptor, (Connection)this, paramArrayOfObject); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 17049) removeAllDescriptor();  throw sQLException; }  } public TIMESTAMP createTIMESTAMP(Date paramDate) throws SQLException { return new TIMESTAMP(paramDate); } public TIMESTAMP createTIMESTAMP(DATE paramDATE) throws SQLException { return new TIMESTAMP(paramDATE); } public TIMESTAMP createTIMESTAMP(Time paramTime) throws SQLException { return new TIMESTAMP(paramTime); } public TIMESTAMP createTIMESTAMP(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMP(paramTimestamp); } public TIMESTAMP createTIMESTAMP(String paramString) throws SQLException { return new TIMESTAMP(paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(DATE paramDATE) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDATE); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDate); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTime); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTimestamp); } public TIMESTAMPLTZ createTIMESTAMPLTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramString); } public TIMESTAMPLTZ createTIMESTAMPLTZ(DATE paramDATE, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDATE); } public Blob createBlob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (Blob)createTemporaryBlob((Connection)this, true, 10); } public Clob createClob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (Clob)createTemporaryClob((Connection)this, true, 10, (short)1); } public NClob createNClob() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (NClob)createTemporaryClob((Connection)this, true, 10, (short)2); } public SQLXML createSQLXML() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  return (SQLXML)new XMLType((Connection)this, (String)null); } public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException { PhysicalConnection physicalConnection1 = this; PhysicalConnection physicalConnection2 = (PhysicalConnection)paramOracleConnection.getPhysicalConnection(); return (physicalConnection1 == physicalConnection2 || physicalConnection1.url.equals(physicalConnection2.url) || (physicalConnection2.protocol != null && physicalConnection2.protocol.equals("kprb"))); } boolean useLittleEndianSetCHARBinder() throws SQLException { return false; } public void setPlsqlWarnings(String paramString) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString != null && (paramString = paramString.trim()).length() > 0 && !OracleSql.isValidPlsqlWarning(paramString)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str1 = "ALTER SESSION SET PLSQL_WARNINGS=" + paramString; String str2 = "ALTER SESSION SET EVENTS='10933 TRACE NAME CONTEXT LEVEL 32768'"; Statement statement = null; try { statement = createStatement(-1, -1); statement.execute(str1); if (paramString.equals("'DISABLE:ALL'")) { this.plsqlCompilerWarnings = false; } else { statement.execute(str2); this.plsqlCompilerWarnings = true; }  } finally { if (statement != null) statement.close();  }  }
/*       */   void internalClose() throws SQLException { this.lifecycle = 4; OracleStatement oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.nextChild; if (oracleStatement.serverCursor) { oracleStatement.internalClose(); removeStatement(oracleStatement); }  oracleStatement = oracleStatement1; }  oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.next; oracleStatement.internalClose(); oracleStatement = oracleStatement1; }  this.statements = null; }
/*       */   public XAResource getXAResource() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 164); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { if (paramString1 == null || paramString2 == null || paramString3 == null) throw new NullPointerException();  if (paramString1.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString1.compareToIgnoreCase("CLIENTCONTEXT") != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 174); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString2.length() > 30) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 171); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString3.length() > 4000) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 172); sQLException.fillInStackTrace(); throw sQLException; }  doSetApplicationContext(paramString1, paramString2, paramString3); }
/*       */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void clearAllApplicationContext(String paramString) throws SQLException { if (paramString == null) throw new NullPointerException();  if (paramString.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  doClearAllApplicationContext(paramString); }
/*       */   void doClearAllApplicationContext(String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/* 11061 */   public TIMEZONETAB getTIMEZONETAB() throws SQLException { if (this.timeZoneTab == null) {
/* 11062 */       this.timeZoneTab = TIMEZONETAB.getInstance(getTimezoneVersionNumber());
/*       */     }
/* 11064 */     return this.timeZoneTab; } public void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void enqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessage paramAQMessage) throws SQLException { AQMessageI aQMessageI = (AQMessageI)paramAQMessage; byte[][] arrayOfByte = new byte[1][]; doEnqueue(paramString, paramAQEnqueueOptions, aQMessageI.getMessagePropertiesI(), aQMessageI.getPayloadTOID(), aQMessageI.getPayload(), arrayOfByte, aQMessageI.isRAWPayload()); if (arrayOfByte[0] != null) aQMessageI.setMessageId(arrayOfByte[0]);  } public AQMessage dequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, byte[] paramArrayOfbyte) throws SQLException { byte[][] arrayOfByte1 = new byte[1][]; AQMessagePropertiesI aQMessagePropertiesI = new AQMessagePropertiesI(); byte[][] arrayOfByte2 = new byte[1][]; boolean bool = false; bool = doDequeue(paramString, paramAQDequeueOptions, aQMessagePropertiesI, paramArrayOfbyte, arrayOfByte2, arrayOfByte1, AQMessageI.compareToid(paramArrayOfbyte, TypeDescriptor.RAWTOID)); AQMessageI aQMessageI = null; if (bool) { aQMessageI = new AQMessageI(aQMessagePropertiesI, (Connection)this); aQMessageI.setPayload(arrayOfByte2[0], paramArrayOfbyte); aQMessageI.setMessageId(arrayOfByte1[0]); }  return aQMessageI; } public AQMessage dequeue(String paramString1, AQDequeueOptions paramAQDequeueOptions, String paramString2) throws SQLException { byte[] arrayOfByte = null; TypeDescriptor typeDescriptor = null; if ("RAW".equals(paramString2) || "SYS.RAW".equals(paramString2)) { arrayOfByte = TypeDescriptor.RAWTOID; } else if ("SYS.ANYDATA".equals(paramString2)) { arrayOfByte = TypeDescriptor.ANYDATATOID; } else if ("SYS.XMLTYPE".equals(paramString2)) { arrayOfByte = TypeDescriptor.XMLTYPETOID; } else { typeDescriptor = TypeDescriptor.getTypeDescriptor(paramString2, (OracleConnection)this); arrayOfByte = ((OracleTypeADT)typeDescriptor.getPickler()).getTOID(); }  AQMessageI aQMessageI = (AQMessageI)dequeue(paramString1, paramAQDequeueOptions, arrayOfByte); if (aQMessageI != null) { aQMessageI.setTypeName(paramString2); aQMessageI.setTypeDescriptor(typeDescriptor); }  return aQMessageI; } synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public boolean isV8Compatible() throws SQLException { return this.mapDateToTimestamp; } public boolean getMapDateToTimestamp() { return this.mapDateToTimestamp; } public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public AQNotificationRegistration[] registerAQNotification(String[] paramArrayOfString, Properties[] paramArrayOfProperties, Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); NTFAQRegistration[] arrayOfNTFAQRegistration = doRegisterAQNotification(paramArrayOfString, str, i, paramArrayOfProperties); return (AQNotificationRegistration[])arrayOfNTFAQRegistration; } NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterAQNotification(AQNotificationRegistration paramAQNotificationRegistration) throws SQLException { NTFAQRegistration nTFAQRegistration = (NTFAQRegistration)paramAQNotificationRegistration; doUnregisterAQNotification(nTFAQRegistration); } void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } private String readNTFlocalhost(Properties paramProperties) throws SQLException { String str = null; try { str = paramProperties.getProperty("NTF_LOCAL_HOST", InetAddress.getLocalHost().getHostAddress()); } catch (UnknownHostException unknownHostException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 240); sQLException.fillInStackTrace(); throw sQLException; } catch (SecurityException securityException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 241); sQLException.fillInStackTrace(); throw sQLException; }  return str; } private int readNTFtcpport(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_LOCAL_TCP_PORT", "0")); if (i < 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  return i; } int readNTFtimeout(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_TIMEOUT", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 243); sQLException.fillInStackTrace(); throw sQLException; }  return i; } public DatabaseChangeRegistration registerDatabaseChangeNotification(Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); int j = readNTFtimeout(paramProperties); int k = 0; try { k = Integer.parseInt(paramProperties.getProperty("DCN_NOTIFY_CHANGELAG", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 244); sQLException.fillInStackTrace(); throw sQLException; }  NTFDCNRegistration nTFDCNRegistration = doRegisterDatabaseChangeNotification(str, i, paramProperties, j, k); ntfManager.addRegistration(nTFDCNRegistration); return nTFDCNRegistration; } NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public DatabaseChangeRegistration getDatabaseChangeRegistration(int paramInt) throws SQLException { return new NTFDCNRegistration(this.instanceName, paramInt, this.userName, this.versionNumber); } public void unregisterDatabaseChangeNotification(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException { NTFDCNRegistration nTFDCNRegistration = (NTFDCNRegistration)paramDatabaseChangeRegistration; if (nTFDCNRegistration.getDatabaseName().compareToIgnoreCase(this.instanceName) != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 245); sQLException.fillInStackTrace(); throw sQLException; }  doUnregisterDatabaseChangeNotification(nTFDCNRegistration); } void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterDatabaseChangeNotification(int paramInt) throws SQLException { String str = null; try { str = InetAddress.getLocalHost().getHostAddress(); } catch (Exception exception) {} unregisterDatabaseChangeNotification(paramInt, str, 47632); } public void unregisterDatabaseChangeNotification(int paramInt1, String paramString, int paramInt2) throws SQLException { String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt2 + "))?PR=0"; unregisterDatabaseChangeNotification(paramInt1, str); } public void unregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { doUnregisterDatabaseChangeNotification(paramLong, paramString); }
/*       */   void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema() throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; Statement statement = null; try { statement = createStatement(); ResultSet resultSet = statement.executeQuery("SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info())"); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (statement != null) statement.close();  }  return arrayOfTypeDescriptor; }
/*       */   public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String[] paramArrayOfString) throws SQLException { String str = "SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info(?))"; TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; try { preparedStatement = prepareStatement(str); int i = paramArrayOfString.length; StringBuffer stringBuffer = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer.append(paramArrayOfString[b]); if (b < i - 1) stringBuffer.append(',');  }  preparedStatement.setString(1, stringBuffer.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  }  return arrayOfTypeDescriptor; }
/*       */   public TypeDescriptor[] getTypeDescriptorsFromList(String[][] paramArrayOfString) throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; int i = paramArrayOfString.length; StringBuffer stringBuffer1 = new StringBuffer(i * 8); StringBuffer stringBuffer2 = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer1.append(paramArrayOfString[b][0]); stringBuffer2.append(paramArrayOfString[b][1]); if (b < i - 1) { stringBuffer1.append(','); stringBuffer2.append(','); }  }  try { String str = "SELECT schema_name, typename, typoid, typecode, version, tds FROM TABLE(private_jdbc.Get_All_Type_Shape_Info(?,?))"; preparedStatement = prepareStatement(str); preparedStatement.setString(1, stringBuffer1.toString()); preparedStatement.setString(2, stringBuffer2.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  }  return arrayOfTypeDescriptor; }
/*       */   TypeDescriptor[] getTypeDescriptorsFromResultSet(ResultSet paramResultSet) throws SQLException { ArrayList<StructDescriptor> arrayList = new ArrayList(); while (paramResultSet.next()) { String str1 = paramResultSet.getString(1); String str2 = paramResultSet.getString(2); byte[] arrayOfByte1 = paramResultSet.getBytes(3); String str3 = paramResultSet.getString(4); int i = paramResultSet.getInt(5); byte[] arrayOfByte2 = paramResultSet.getBytes(6); SQLName sQLName = new SQLName(str1, str2, (OracleConnection)this); if (str3.equals("OBJECT")) { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, structDescriptor); putDescriptor(structDescriptor.getName(), structDescriptor); arrayList.add(structDescriptor); continue; }  if (str3.equals("COLLECTION")) { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, arrayDescriptor); putDescriptor(arrayDescriptor.getName(), arrayDescriptor); arrayList.add(arrayDescriptor); }  }  TypeDescriptor[] arrayOfTypeDescriptor = new TypeDescriptor[arrayList.size()]; for (byte b = 0; b < arrayList.size(); b++) { TypeDescriptor typeDescriptor = (TypeDescriptor)arrayList.get(b); arrayOfTypeDescriptor[b] = typeDescriptor; }  return arrayOfTypeDescriptor; }
/*       */   public synchronized boolean isUsable() { return this.isUsable; }
/*       */   public synchronized void setUsable(boolean paramBoolean) { this.isUsable = paramBoolean; }
/*       */   void queryFCFProperties(Properties paramProperties) throws SQLException { Statement statement = null; ResultSet resultSet = null; String str = "select sys_context('userenv', 'instance_name'),sys_context('userenv', 'server_host'),sys_context('userenv', 'service_name'),sys_context('userenv', 'db_unique_name') from dual"; try { statement = createStatement(); statement.setFetchSize(1); resultSet = statement.executeQuery(str); while (resultSet.next()) { String str1 = null; str1 = resultSet.getString(1); if (str1 != null) paramProperties.put("INSTANCE_NAME", str1.trim());  str1 = resultSet.getString(2); if (str1 != null) paramProperties.put("SERVER_HOST", str1.trim());  str1 = resultSet.getString(3); if (str1 != null) paramProperties.put("SERVICE_NAME", str1.trim());  str1 = resultSet.getString(4); if (str1 != null) paramProperties.put("DATABASE_NAME", str1.trim());  }  } finally { if (resultSet != null) resultSet.close();  if (statement != null) statement.close();  }  }
/*       */   public void setDefaultTimeZone(TimeZone paramTimeZone) throws SQLException { this.defaultTimeZone = paramTimeZone; }
/*       */   public TimeZone getDefaultTimeZone() throws SQLException { return this.defaultTimeZone; }
/* 11078 */   public boolean isDataInLocatorEnabled() throws SQLException { return ((getVersionNumber() >= 10200)) & ((getVersionNumber() < 11000)) & this.enableReadDataInLocator | this.overrideEnableReadDataInLocator; }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isLobStreamPosStandardCompliant() throws SQLException {
/* 11087 */     return this.lobStreamPosStandardCompliant;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public long getCurrentSCN() throws SQLException {
/* 11094 */     return doGetCurrentSCN();
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   long doGetCurrentSCN() throws SQLException {
/* 11100 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11101 */     sQLException.fillInStackTrace();
/* 11102 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/* 11109 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11110 */     sQLException.fillInStackTrace();
/* 11111 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public EnumSet<OracleConnection.TransactionState> getTransactionState() throws SQLException {
/* 11117 */     return doGetTransactionState();
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException {
/* 11123 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11124 */     sQLException.fillInStackTrace();
/* 11125 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isConnectionSocketKeepAlive() throws SocketException, SQLException {
/* 11132 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11133 */     sQLException.fillInStackTrace();
/* 11134 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/* 11139 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*       */   public static final boolean TRACE = false;
/*       */   
/*       */   abstract void initializePassword(String paramString) throws SQLException;
/*       */   
/*       */   abstract void doAbort() throws SQLException;
/*       */   
/*       */   public abstract void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException;
/*       */   
/*       */   abstract void logon() throws SQLException;
/*       */   
/*       */   abstract void open(OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   abstract void cancelOperationOnServer() throws SQLException;
/*       */   
/*       */   abstract void doSetAutoCommit(boolean paramBoolean) throws SQLException;
/*       */   
/*       */   abstract void doCommit(int paramInt) throws SQLException;
/*       */   
/*       */   abstract void doRollback() throws SQLException;
/*       */   
/*       */   abstract String doGetDatabaseProductVersion() throws SQLException;
/*       */   
/*       */   abstract short doGetVersionNumber() throws SQLException;
/*       */   
/*       */   abstract OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   public abstract BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException;
/*       */   
/*       */   public abstract CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException;
/*       */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\PhysicalConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */