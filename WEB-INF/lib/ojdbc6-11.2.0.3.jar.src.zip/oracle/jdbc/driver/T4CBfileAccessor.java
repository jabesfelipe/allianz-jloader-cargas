/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CBfileAccessor
/*     */   extends BfileAccessor
/*     */ {
/*     */   static final int maxLength = 530;
/*     */   T4CMAREngine mare;
/*     */   final int[] meta;
/*     */   
/*     */   T4CBfileAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  47 */     super(paramOracleStatement, 530, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CBfileAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, 530, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     this.definedColumnType = paramInt7;
/*     */     this.definedColumnSize = paramInt8; }
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*     */     String str = super.getString(paramInt);
/*     */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize) {
/*     */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/*     */     return str;
/*     */   }
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 137 */     if (this.isUseLess) {
/*     */       
/* 139 */       this.lastRowProcessed++;
/*     */       
/* 141 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 146 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 148 */       int n = (int)this.mare.unmarshalUB4();
/*     */       
/* 150 */       if (n == 0) {
/*     */         
/* 152 */         this.meta[0] = -1;
/*     */         
/* 154 */         processIndicator(0);
/*     */         
/* 156 */         this.lastRowProcessed++;
/*     */         
/* 158 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 162 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 164 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 165 */       processIndicator(this.meta[0]);
/*     */       
/* 167 */       this.lastRowProcessed++;
/*     */       
/* 169 */       return false;
/*     */     } 
/*     */     
/* 172 */     int i = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 173 */     int j = this.indicatorIndex + this.lastRowProcessed;
/* 174 */     int k = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (this.isNullByDescribe) {
/*     */       
/* 180 */       this.rowSpaceIndicator[j] = -1;
/* 181 */       this.rowSpaceIndicator[k] = 0;
/* 182 */       this.lastRowProcessed++;
/*     */       
/* 184 */       if (this.statement.connection.versionNumber < 9200) {
/* 185 */         processIndicator(0);
/*     */       }
/* 187 */       return false;
/*     */     } 
/*     */     
/* 190 */     int m = (int)this.mare.unmarshalUB4();
/*     */     
/* 192 */     if (m == 0) {
/*     */       
/* 194 */       this.meta[0] = -1;
/*     */       
/* 196 */       processIndicator(0);
/*     */ 
/*     */       
/* 199 */       this.rowSpaceIndicator[j] = -1;
/* 200 */       this.rowSpaceIndicator[k] = 0;
/*     */       
/* 202 */       this.lastRowProcessed++;
/*     */       
/* 204 */       return false;
/*     */     } 
/* 206 */     if (this.lobPrefetchSizeForThisColumn != -1)
/* 207 */       handlePrefetch(); 
/* 208 */     this.mare.unmarshalCLR(this.rowSpaceByte, i, this.meta, this.byteLength);
/*     */     
/* 210 */     processIndicator(this.meta[0]);
/*     */     
/* 212 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 216 */       this.rowSpaceIndicator[j] = -1;
/* 217 */       this.rowSpaceIndicator[k] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 221 */       this.rowSpaceIndicator[k] = (short)this.meta[0];
/* 222 */       this.rowSpaceIndicator[j] = 0;
/*     */     } 
/*     */     
/* 225 */     this.lastRowProcessed++;
/*     */     
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/*     */     int i;
/* 237 */     if (this.lastRowProcessed == 0) {
/* 238 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 240 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 243 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 244 */     int k = this.columnIndex + i * this.byteLength;
/* 245 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 246 */     int n = this.indicatorIndex + i;
/* 247 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 248 */     int i2 = this.lengthIndex + i;
/* 249 */     short s = this.rowSpaceIndicator[i2];
/* 250 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 252 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 256 */     this.rowSpaceIndicator[i1] = (short)s;
/* 257 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 260 */     if (!this.isNullByDescribe)
/*     */     {
/* 262 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 267 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 270 */     this.lastRowProcessed++;
/*     */   } void processIndicator(int paramInt) throws IOException, SQLException {
/*     */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   } void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 283 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 285 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 287 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 288 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 289 */     int n = this.lengthIndex + paramInt2 - 1;
/* 290 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 291 */     short s = paramArrayOfshort[i1];
/*     */     
/* 293 */     this.rowSpaceIndicator[n] = (short)s;
/* 294 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 297 */     if (s != 0)
/*     */     {
/* 299 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[][] checkAndAllocateLobPrefetchMemory(byte[][] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
/* 315 */     byte[][] arrayOfByte = paramArrayOfbyte;
/* 316 */     if (arrayOfByte == null) {
/*     */       
/* 318 */       arrayOfByte = new byte[Math.max(paramInt1, paramInt2 + 1)][];
/* 319 */       arrayOfByte[paramInt2] = new byte[paramInt3];
/*     */     }
/*     */     else {
/*     */       
/* 323 */       if (arrayOfByte.length < paramInt2 + 1) {
/*     */ 
/*     */         
/* 326 */         byte[][] arrayOfByte1 = new byte[(paramInt2 + 1) * 2][];
/* 327 */         System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, arrayOfByte.length);
/* 328 */         arrayOfByte = arrayOfByte1;
/*     */       } 
/*     */       
/* 331 */       if (arrayOfByte[paramInt2] == null || (arrayOfByte[paramInt2]).length < paramInt3)
/*     */       {
/*     */ 
/*     */         
/* 335 */         arrayOfByte[paramInt2] = new byte[paramInt3]; } 
/*     */     } 
/* 337 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[][] checkAndAllocateLobPrefetchMemory(char[][] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3) {
/* 345 */     char[][] arrayOfChar = paramArrayOfchar;
/* 346 */     if (arrayOfChar == null) {
/*     */       
/* 348 */       arrayOfChar = new char[Math.max(paramInt1, paramInt2 + 1)][];
/* 349 */       arrayOfChar[paramInt2] = new char[paramInt3];
/*     */     }
/*     */     else {
/*     */       
/* 353 */       if (arrayOfChar.length < paramInt2 + 1) {
/*     */ 
/*     */         
/* 356 */         char[][] arrayOfChar1 = new char[(paramInt2 + 1) * 2][];
/* 357 */         System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, arrayOfChar.length);
/* 358 */         arrayOfChar = arrayOfChar1;
/*     */       } 
/*     */       
/* 361 */       if (arrayOfChar[paramInt2] == null || (arrayOfChar[paramInt2]).length < paramInt3)
/*     */       {
/*     */ 
/*     */         
/* 365 */         arrayOfChar[paramInt2] = new char[paramInt3]; } 
/*     */     } 
/* 367 */     return arrayOfChar;
/*     */   }
/*     */ 
/*     */   
/*     */   long[] checkAndAllocateLobPrefetchMemory(long[] paramArrayOflong, int paramInt1, int paramInt2) {
/* 372 */     long[] arrayOfLong = paramArrayOflong;
/* 373 */     if (arrayOfLong == null) {
/* 374 */       arrayOfLong = new long[Math.max(paramInt1, paramInt2 + 1)];
/* 375 */     } else if (arrayOfLong.length < paramInt2 + 1) {
/*     */       
/* 377 */       long[] arrayOfLong1 = new long[(paramInt2 + 1) * 2];
/* 378 */       System.arraycopy(arrayOfLong, 0, arrayOfLong1, 0, arrayOfLong.length);
/* 379 */       arrayOfLong = arrayOfLong1;
/*     */     } 
/* 381 */     return arrayOfLong;
/*     */   }
/*     */ 
/*     */   
/*     */   int[] checkAndAllocateLobPrefetchMemory(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 386 */     int[] arrayOfInt = paramArrayOfint;
/* 387 */     if (arrayOfInt == null) {
/* 388 */       arrayOfInt = new int[Math.max(paramInt1, paramInt2 + 1)];
/* 389 */     } else if (arrayOfInt.length < paramInt2 + 1) {
/*     */       
/* 391 */       int[] arrayOfInt1 = new int[(paramInt2 + 1) * 2];
/* 392 */       System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
/* 393 */       arrayOfInt = arrayOfInt1;
/*     */     } 
/* 395 */     return arrayOfInt;
/*     */   }
/*     */ 
/*     */   
/*     */   short[] checkAndAllocateLobPrefetchMemory(short[] paramArrayOfshort, int paramInt1, int paramInt2) {
/* 400 */     short[] arrayOfShort = paramArrayOfshort;
/* 401 */     if (arrayOfShort == null) {
/* 402 */       arrayOfShort = new short[Math.max(paramInt1, paramInt2 + 1)];
/* 403 */     } else if (arrayOfShort.length < paramInt2 + 1) {
/*     */       
/* 405 */       short[] arrayOfShort1 = new short[(paramInt2 + 1) * 2];
/* 406 */       System.arraycopy(arrayOfShort, 0, arrayOfShort1, 0, arrayOfShort.length);
/* 407 */       arrayOfShort = arrayOfShort1;
/*     */     } 
/* 409 */     return arrayOfShort;
/*     */   }
/*     */ 
/*     */   
/*     */   byte[] checkAndAllocateLobPrefetchMemory(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 414 */     byte[] arrayOfByte = paramArrayOfbyte;
/* 415 */     if (arrayOfByte == null) {
/* 416 */       arrayOfByte = new byte[Math.max(paramInt1, paramInt2 + 1)];
/* 417 */     } else if (arrayOfByte.length < paramInt2 + 1) {
/*     */       
/* 419 */       byte[] arrayOfByte1 = new byte[(paramInt2 + 1) * 2];
/* 420 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, arrayOfByte.length);
/* 421 */       arrayOfByte = arrayOfByte1;
/*     */     } 
/* 423 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean[] checkAndAllocateLobPrefetchMemory(boolean[] paramArrayOfboolean, int paramInt1, int paramInt2) {
/* 428 */     boolean[] arrayOfBoolean = paramArrayOfboolean;
/* 429 */     if (arrayOfBoolean == null) {
/* 430 */       arrayOfBoolean = new boolean[Math.max(paramInt1, paramInt2 + 1)];
/* 431 */     } else if (arrayOfBoolean.length < paramInt2 + 1) {
/*     */       
/* 433 */       boolean[] arrayOfBoolean1 = new boolean[(paramInt2 + 1) * 2];
/* 434 */       System.arraycopy(arrayOfBoolean, 0, arrayOfBoolean1, 0, arrayOfBoolean.length);
/* 435 */       arrayOfBoolean = arrayOfBoolean1;
/*     */     } 
/* 437 */     return arrayOfBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handlePrefetch() throws SQLException, IOException {
/* 448 */     this.prefetchedLobSize = checkAndAllocateLobPrefetchMemory(this.prefetchedLobSize, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed);
/*     */     
/* 450 */     this.prefetchedLobSize[this.lastRowProcessed] = (int)this.mare.unmarshalSB8();
/*     */ 
/*     */     
/* 453 */     if (this.lobPrefetchSizeForThisColumn > 0)
/* 454 */       this.mare.unmarshalUB1(); 
/*     */   }
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 458 */     if (this.definedColumnType == 0) {
/* 459 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 462 */     Object object = null;
/*     */     
/* 464 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 466 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 467 */       sQLException.fillInStackTrace();
/* 468 */       throw sQLException;
/*     */     } 
/*     */     
/* 471 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 473 */       switch (this.definedColumnType) {
/*     */ 
/*     */         
/*     */         case -13:
/* 477 */           return getBFILE(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 481 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 482 */       sQLException.fillInStackTrace();
/* 483 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 489 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 494 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CBfileAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */