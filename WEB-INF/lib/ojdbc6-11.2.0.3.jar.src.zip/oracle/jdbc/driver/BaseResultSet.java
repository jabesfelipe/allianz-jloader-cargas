/*      */ package oracle.jdbc.driver;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ abstract class BaseResultSet extends OracleResultSet {
/*   33 */   SQLWarning sqlWarning = null;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean autoRefetch = true;
/*      */ 
/*      */   
/*      */   boolean closed = false;
/*      */ 
/*      */   
/*      */   boolean close_statement_on_close = false;
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeStatementOnClose() {
/*   48 */     this.close_statement_on_close = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/*   64 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "beforeFirst");
/*   65 */     sQLException.fillInStackTrace();
/*   66 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/*   75 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "afterLast");
/*   76 */     sQLException.fillInStackTrace();
/*   77 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/*   86 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "first");
/*   87 */     sQLException.fillInStackTrace();
/*   88 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/*   97 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "last");
/*   98 */     sQLException.fillInStackTrace();
/*   99 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int paramInt) throws SQLException {
/*  108 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "absolute");
/*  109 */     sQLException.fillInStackTrace();
/*  110 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int paramInt) throws SQLException {
/*  119 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "relative");
/*  120 */     sQLException.fillInStackTrace();
/*  121 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/*  130 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "previous");
/*  131 */     sQLException.fillInStackTrace();
/*  132 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/*  146 */     if (paramInt == 1000)
/*      */       return; 
/*  148 */     if (paramInt == 1001 || paramInt == 1002) {
/*      */       
/*  150 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "setFetchDirection(FETCH_REVERSE, FETCH_UNKNOWN)");
/*  151 */       sQLException1.fillInStackTrace();
/*  152 */       throw sQLException1;
/*      */     } 
/*      */ 
/*      */     
/*  156 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/*  157 */     sQLException.fillInStackTrace();
/*  158 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/*  166 */     return 1000;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() throws SQLException {
/*  173 */     return 1003;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/*  180 */     return 1007;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/*  187 */     return this.sqlWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*  194 */     this.sqlWarning = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateArray(int paramInt, Array paramArray) throws SQLException {
/*  208 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateArray");
/*  209 */     sQLException.fillInStackTrace();
/*  210 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/*  218 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBigDecimal");
/*  219 */     sQLException.fillInStackTrace();
/*  220 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, Blob paramBlob) throws SQLException {
/*  228 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBlob");
/*  229 */     sQLException.fillInStackTrace();
/*  230 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/*  238 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBoolean");
/*  239 */     sQLException.fillInStackTrace();
/*  240 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(int paramInt, byte paramByte) throws SQLException {
/*  248 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateByte");
/*  249 */     sQLException.fillInStackTrace();
/*  250 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  258 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBytes");
/*  259 */     sQLException.fillInStackTrace();
/*  260 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Clob paramClob) throws SQLException {
/*  268 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateClob");
/*  269 */     sQLException.fillInStackTrace();
/*  270 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(int paramInt, Date paramDate) throws SQLException {
/*  278 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDate");
/*  279 */     sQLException.fillInStackTrace();
/*  280 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  288 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDate");
/*  289 */     sQLException.fillInStackTrace();
/*  290 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(int paramInt, double paramDouble) throws SQLException {
/*  298 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDouble");
/*  299 */     sQLException.fillInStackTrace();
/*  300 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(int paramInt, float paramFloat) throws SQLException {
/*  308 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateFloat");
/*  309 */     sQLException.fillInStackTrace();
/*  310 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(int paramInt1, int paramInt2) throws SQLException {
/*  318 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateInt");
/*  319 */     sQLException.fillInStackTrace();
/*  320 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(int paramInt, long paramLong) throws SQLException {
/*  328 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateLong");
/*  329 */     sQLException.fillInStackTrace();
/*  330 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, NClob paramNClob) throws SQLException {
/*  338 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNClob");
/*  339 */     sQLException.fillInStackTrace();
/*  340 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNString(int paramInt, String paramString) throws SQLException {
/*  348 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNString");
/*  349 */     sQLException.fillInStackTrace();
/*  350 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt, Object paramObject) throws SQLException {
/*  358 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateObject");
/*  359 */     sQLException.fillInStackTrace();
/*  360 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/*  368 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateObject");
/*  369 */     sQLException.fillInStackTrace();
/*  370 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRef(int paramInt, Ref paramRef) throws SQLException {
/*  378 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRef");
/*  379 */     sQLException.fillInStackTrace();
/*  380 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRowId(int paramInt, RowId paramRowId) throws SQLException {
/*  388 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRowId");
/*  389 */     sQLException.fillInStackTrace();
/*  390 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(int paramInt, short paramShort) throws SQLException {
/*  398 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateShort");
/*  399 */     sQLException.fillInStackTrace();
/*  400 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/*  408 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateSQLXML");
/*  409 */     sQLException.fillInStackTrace();
/*  410 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(int paramInt, String paramString) throws SQLException {
/*  418 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateString");
/*  419 */     sQLException.fillInStackTrace();
/*  420 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(int paramInt, Time paramTime) throws SQLException {
/*  428 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTime");
/*  429 */     sQLException.fillInStackTrace();
/*  430 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  438 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTime");
/*  439 */     sQLException.fillInStackTrace();
/*  440 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/*  448 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
/*  449 */     sQLException.fillInStackTrace();
/*  450 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  458 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
/*  459 */     sQLException.fillInStackTrace();
/*  460 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateURL(int paramInt, URL paramURL) throws SQLException {
/*  468 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateURL");
/*  469 */     sQLException.fillInStackTrace();
/*  470 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/*  478 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateARRAY");
/*  479 */     sQLException.fillInStackTrace();
/*  480 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/*  488 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBFILE");
/*  489 */     sQLException.fillInStackTrace();
/*  490 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/*  498 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBfile");
/*  499 */     sQLException.fillInStackTrace();
/*  500 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/*  508 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
/*  509 */     sQLException.fillInStackTrace();
/*  510 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  518 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
/*  519 */     sQLException.fillInStackTrace();
/*  520 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/*  528 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
/*  529 */     sQLException.fillInStackTrace();
/*  530 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  538 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
/*  539 */     sQLException.fillInStackTrace();
/*  540 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/*  548 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBLOB");
/*  549 */     sQLException.fillInStackTrace();
/*  550 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/*  558 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCHAR");
/*  559 */     sQLException.fillInStackTrace();
/*  560 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/*  568 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCLOB");
/*  569 */     sQLException.fillInStackTrace();
/*  570 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/*  578 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCursor");
/*  579 */     sQLException.fillInStackTrace();
/*  580 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/*  588 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCustomDatum");
/*  589 */     sQLException.fillInStackTrace();
/*  590 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDATE(int paramInt, DATE paramDATE) throws SQLException {
/*  598 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDATE");
/*  599 */     sQLException.fillInStackTrace();
/*  600 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFixedCHAR(int paramInt, String paramString) throws SQLException {
/*  608 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateFixedCHAR");
/*  609 */     sQLException.fillInStackTrace();
/*  610 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/*  618 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateINTERVALDS");
/*  619 */     sQLException.fillInStackTrace();
/*  620 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/*  628 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateINTERVALYM");
/*  629 */     sQLException.fillInStackTrace();
/*  630 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/*  638 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNUMBER");
/*  639 */     sQLException.fillInStackTrace();
/*  640 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/*  648 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateOPAQUE");
/*  649 */     sQLException.fillInStackTrace();
/*  650 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/*  658 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateOracleObject");
/*  659 */     sQLException.fillInStackTrace();
/*  660 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateORAData(int paramInt, ORAData paramORAData) throws SQLException {
/*  668 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateORAData");
/*  669 */     sQLException.fillInStackTrace();
/*  670 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRAW(int paramInt, RAW paramRAW) throws SQLException {
/*  678 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRAW");
/*  679 */     sQLException.fillInStackTrace();
/*  680 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateREF(int paramInt, REF paramREF) throws SQLException {
/*  688 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateREF");
/*  689 */     sQLException.fillInStackTrace();
/*  690 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRefType(int paramInt, REF paramREF) throws SQLException {
/*  698 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRefType");
/*  699 */     sQLException.fillInStackTrace();
/*  700 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateROWID(int paramInt, ROWID paramROWID) throws SQLException {
/*  708 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateROWID");
/*  709 */     sQLException.fillInStackTrace();
/*  710 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/*  718 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateSTRUCT");
/*  719 */     sQLException.fillInStackTrace();
/*  720 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/*  728 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPLTZ");
/*  729 */     sQLException.fillInStackTrace();
/*  730 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/*  738 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPTZ");
/*  739 */     sQLException.fillInStackTrace();
/*  740 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/*  748 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMP");
/*  749 */     sQLException.fillInStackTrace();
/*  750 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/*  758 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBlob");
/*  759 */     sQLException.fillInStackTrace();
/*  760 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/*  768 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBlob");
/*  769 */     sQLException.fillInStackTrace();
/*  770 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Reader paramReader) throws SQLException {
/*  778 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateClob");
/*  779 */     sQLException.fillInStackTrace();
/*  780 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/*  788 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateClob");
/*  789 */     sQLException.fillInStackTrace();
/*  790 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, Reader paramReader) throws SQLException {
/*  798 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNClob");
/*  799 */     sQLException.fillInStackTrace();
/*  800 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/*  808 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNClob");
/*  809 */     sQLException.fillInStackTrace();
/*  810 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/*  818 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
/*  819 */     sQLException.fillInStackTrace();
/*  820 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  828 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
/*  829 */     sQLException.fillInStackTrace();
/*  830 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/*  838 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
/*  839 */     sQLException.fillInStackTrace();
/*  840 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/*  848 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
/*  849 */     sQLException.fillInStackTrace();
/*  850 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  858 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
/*  859 */     sQLException.fillInStackTrace();
/*  860 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/*  868 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
/*  869 */     sQLException.fillInStackTrace();
/*  870 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/*  878 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
/*  879 */     sQLException.fillInStackTrace();
/*  880 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/*  888 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
/*  889 */     sQLException.fillInStackTrace();
/*  890 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/*  898 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
/*  899 */     sQLException.fillInStackTrace();
/*  900 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/*  908 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNCharacterStream");
/*  909 */     sQLException.fillInStackTrace();
/*  910 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/*  918 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNCharacterStream");
/*  919 */     sQLException.fillInStackTrace();
/*  920 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  928 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateUnicodeStream");
/*  929 */     sQLException.fillInStackTrace();
/*  930 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(int paramInt) throws SQLException {
/*  943 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNull");
/*  944 */     sQLException.fillInStackTrace();
/*  945 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLException {
/*  954 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLException {
/*  961 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/*  968 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLException {
/*  976 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "insertRow");
/*  977 */     sQLException.fillInStackTrace();
/*  978 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLException {
/*  987 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRow");
/*  988 */     sQLException.fillInStackTrace();
/*  989 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLException {
/*  998 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "deleteRow");
/*  999 */     sQLException.fillInStackTrace();
/* 1000 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/* 1009 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, (Object)null);
/* 1010 */     sQLException.fillInStackTrace();
/* 1011 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowUpdates() throws SQLException {
/* 1020 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "cancelRowUpdates");
/* 1021 */     sQLException.fillInStackTrace();
/* 1022 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLException {
/* 1031 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToInsertRow");
/* 1032 */     sQLException.fillInStackTrace();
/* 1033 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLException {
/* 1042 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToCurrentRow");
/* 1043 */     sQLException.fillInStackTrace();
/* 1044 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoRefetch(boolean paramBoolean) throws SQLException {
/* 1073 */     this.autoRefetch = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAutoRefetch() throws SQLException {
/* 1090 */     return this.autoRefetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/* 1097 */     this.closed = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/* 1108 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHoldability() throws SQLException {
/* 1123 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/* 1130 */     return this.closed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1137 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\BaseResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */