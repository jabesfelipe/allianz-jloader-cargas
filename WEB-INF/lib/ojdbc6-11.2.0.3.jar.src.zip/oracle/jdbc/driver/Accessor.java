/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.OracleResultSetMetaData;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.oracore.OracleType;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class Accessor
/*      */ {
/*      */   static final int FIXED_CHAR = 999;
/*      */   static final int CHAR = 96;
/*      */   static final int VARCHAR = 1;
/*      */   static final int VCS = 9;
/*      */   static final int LONG = 8;
/*      */   static final int NUMBER = 2;
/*      */   static final int VARNUM = 6;
/*      */   static final int BINARY_FLOAT = 100;
/*      */   static final int BINARY_DOUBLE = 101;
/*      */   static final int RAW = 23;
/*      */   static final int VBI = 15;
/*      */   static final int LONG_RAW = 24;
/*      */   static final int ROWID = 104;
/*      */   static final int RESULT_SET = 102;
/*      */   static final int RSET = 116;
/*      */   static final int DATE = 12;
/*      */   static final int BLOB = 113;
/*      */   static final int CLOB = 112;
/*      */   static final int BFILE = 114;
/*      */   static final int NAMED_TYPE = 109;
/*      */   static final int REF_TYPE = 111;
/*      */   static final int TIMESTAMP = 180;
/*      */   static final int TIMESTAMPTZ = 181;
/*      */   static final int TIMESTAMPLTZ = 231;
/*      */   static final int INTERVALYM = 182;
/*      */   static final int INTERVALDS = 183;
/*      */   static final int UROWID = 208;
/*      */   static final int PLSQL_INDEX_TABLE = 998;
/*      */   static final int T2S_OVERLONG_RAW = 997;
/*      */   static final int SET_CHAR_BYTES = 996;
/*      */   static final int NULL_TYPE = 995;
/*      */   static final int DML_RETURN_PARAM = 994;
/*      */   static final int ONLY_FORM_USABLE = 0;
/*      */   static final int NOT_USABLE = 1;
/*      */   static final int NO_NEED_TO_PREPARE = 2;
/*      */   static final int NEED_TO_PREPARE = 3;
/*      */   OracleStatement statement;
/*      */   boolean outBind;
/*      */   int internalType;
/*      */   int internalTypeMaxLength;
/*      */   boolean isStream = false;
/*      */   boolean isColumnNumberAware = false;
/*  141 */   short formOfUse = 2;
/*      */   
/*      */   OracleType internalOtype;
/*      */   
/*      */   int externalType;
/*      */   
/*      */   String internalTypeName;
/*      */   
/*      */   String columnName;
/*      */   
/*      */   int describeType;
/*      */   
/*      */   int describeMaxLength;
/*      */   
/*      */   boolean nullable;
/*      */   
/*      */   int precision;
/*      */   
/*      */   int scale;
/*      */   
/*      */   int flags;
/*      */   
/*      */   int contflag;
/*      */   
/*      */   int total_elems;
/*      */   
/*      */   OracleType describeOtype;
/*      */   String describeTypeName;
/*  169 */   int definedColumnType = 0;
/*  170 */   int definedColumnSize = 0;
/*  171 */   int oacmxl = 0;
/*      */ 
/*      */   
/*  174 */   short udskpos = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  184 */   int lobPrefetchSizeForThisColumn = -1;
/*      */ 
/*      */   
/*  187 */   long[] prefetchedLobSize = null;
/*      */   
/*  189 */   int[] prefetchedLobChunkSize = null;
/*      */ 
/*      */   
/*  192 */   byte[] prefetchedClobFormOfUse = null;
/*      */ 
/*      */ 
/*      */   
/*  196 */   byte[][] prefetchedLobData = (byte[][])null;
/*  197 */   char[][] prefetchedLobCharData = (char[][])null;
/*      */ 
/*      */   
/*  200 */   int[] prefetchedLobDataL = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleResultSetMetaData.SecurityAttribute securityAttribute;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  211 */   byte[] rowSpaceByte = null;
/*  212 */   char[] rowSpaceChar = null;
/*  213 */   short[] rowSpaceIndicator = null;
/*      */   
/*      */   static final byte DATA_UNAUTHORIZED = 1;
/*      */   
/*  217 */   byte[] rowSpaceMetaData = null;
/*      */   
/*  219 */   int columnIndex = 0;
/*  220 */   int lengthIndex = 0;
/*  221 */   int indicatorIndex = 0;
/*  222 */   int metaDataIndex = 0;
/*  223 */   int columnIndexLastRow = 0;
/*  224 */   int lengthIndexLastRow = 0;
/*  225 */   int indicatorIndexLastRow = 0;
/*  226 */   int metaDataIndexLastRow = 0;
/*  227 */   int byteLength = 0;
/*  228 */   int charLength = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int defineType;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isDMLReturnedParam = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setOffsets(int paramInt) {
/*  245 */     this.columnIndex = this.statement.defineByteSubRange;
/*  246 */     this.statement.defineByteSubRange = this.columnIndex + paramInt * this.byteLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, boolean paramBoolean) throws SQLException {
/*  254 */     this.statement = paramOracleStatement;
/*  255 */     this.outBind = paramBoolean;
/*  256 */     this.internalType = paramInt1;
/*  257 */     this.defineType = paramInt2;
/*  258 */     this.formOfUse = paramShort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initForDescribe(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
/*  270 */     this.describeType = paramInt1;
/*  271 */     this.describeMaxLength = paramInt2;
/*  272 */     this.nullable = paramBoolean;
/*  273 */     this.precision = paramInt4;
/*  274 */     this.scale = paramInt5;
/*  275 */     this.flags = paramInt3;
/*  276 */     this.contflag = paramInt6;
/*  277 */     this.total_elems = paramInt7;
/*  278 */     this.formOfUse = paramShort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initForDescribe(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort, String paramString) throws SQLException {
/*  287 */     this.describeTypeName = paramString;
/*  288 */     this.describeOtype = null;
/*      */     
/*  290 */     initForDescribe(paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleInputStream initForNewRow() throws SQLException {
/*  303 */     unimpl("initForNewRow");
/*  304 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int useForDataAccessIfPossible(int paramInt1, int paramInt2, int paramInt3, String paramString) throws SQLException {
/*  319 */     byte b = 3;
/*  320 */     int i = 0;
/*  321 */     int j = 0;
/*      */     
/*  323 */     if (this.internalType != 0)
/*      */     {
/*  325 */       if (this.internalType != paramInt1) {
/*  326 */         b = 0;
/*  327 */       } else if (this.rowSpaceIndicator != null) {
/*      */         
/*  329 */         i = this.byteLength;
/*  330 */         j = this.charLength;
/*      */       } 
/*      */     }
/*      */     
/*  334 */     if (b == 3) {
/*      */       
/*  336 */       initForDataAccess(paramInt2, paramInt3, paramString);
/*      */       
/*  338 */       if (!this.outBind && i >= this.byteLength && j >= this.charLength)
/*      */       {
/*  340 */         b = 2;
/*      */       }
/*      */     } 
/*  343 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useForDescribeIfPossible(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort, String paramString) throws SQLException {
/*  355 */     if (this.externalType == 0 && paramInt1 != this.describeType) {
/*  356 */       return false;
/*      */     }
/*  358 */     initForDescribe(paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, paramString);
/*      */ 
/*      */     
/*  361 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setFormOfUse(short paramShort) {
/*  370 */     this.formOfUse = paramShort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateColumnNumber(int paramInt) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  387 */     return super.toString() + ", statement=" + this.statement + ", outBind=" + this.outBind + ", internalType=" + this.internalType + ", internalTypeMaxLength=" + this.internalTypeMaxLength + ", isStream=" + this.isStream + ", formOfUse=" + this.formOfUse + ", internalOtype=" + this.internalOtype + ", externalType=" + this.externalType + ", internalTypeName=" + this.internalTypeName + ", columnName=" + this.columnName + ", describeType=" + this.describeType + ", describeMaxLength=" + this.describeMaxLength + ", nullable=" + this.nullable + ", precision=" + this.precision + ", scale=" + this.scale + ", flags=" + this.flags + ", contflag=" + this.contflag + ", total_elems=" + this.total_elems + ", describeOtype=" + this.describeOtype + ", describeTypeName=" + this.describeTypeName + ", rowSpaceByte=" + this.rowSpaceByte + ", rowSpaceChar=" + this.rowSpaceChar + ", rowSpaceIndicator=" + this.rowSpaceIndicator + ", columnIndex=" + this.columnIndex + ", lengthIndex=" + this.lengthIndex + ", indicatorIndex=" + this.indicatorIndex + ", byteLength=" + this.byteLength + ", charLength=" + this.charLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unimpl(String paramString) throws SQLException {
/*  410 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, paramString + " not implemented for " + getClass());
/*      */     
/*  412 */     sQLException.fillInStackTrace();
/*  413 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getBoolean(int paramInt) throws SQLException {
/*  425 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  428 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  429 */       sQLException.fillInStackTrace();
/*  430 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  434 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  435 */       return false;
/*      */     }
/*  437 */     unimpl("getBoolean");
/*      */     
/*  439 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte getByte(int paramInt) throws SQLException {
/*  447 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  450 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  451 */       sQLException.fillInStackTrace();
/*  452 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  456 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  457 */       return 0;
/*      */     }
/*  459 */     unimpl("getByte");
/*      */     
/*  461 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/*  467 */     if (this.rowSpaceMetaData == null) {
/*      */ 
/*      */ 
/*      */       
/*  471 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  472 */       sQLException.fillInStackTrace();
/*  473 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  477 */     byte b = this.rowSpaceMetaData[this.metaDataIndex + 1 * paramInt];
/*      */ 
/*      */     
/*  480 */     if ((b & 0x1) != 0)
/*  481 */       return OracleResultSet.AuthorizationIndicator.UNAUTHORIZED; 
/*  482 */     if (this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED || this.securityAttribute == OracleResultSetMetaData.SecurityAttribute.NONE)
/*      */     {
/*  484 */       return OracleResultSet.AuthorizationIndicator.NONE;
/*      */     }
/*  486 */     return OracleResultSet.AuthorizationIndicator.UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   short getShort(int paramInt) throws SQLException {
/*  495 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  498 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  499 */       sQLException.fillInStackTrace();
/*  500 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  504 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  505 */       return 0;
/*      */     }
/*  507 */     unimpl("getShort");
/*      */     
/*  509 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getInt(int paramInt) throws SQLException {
/*  517 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  520 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  521 */       sQLException.fillInStackTrace();
/*  522 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  526 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  527 */       return 0;
/*      */     }
/*  529 */     unimpl("getInt");
/*      */     
/*  531 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getLong(int paramInt) throws SQLException {
/*  539 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  542 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  543 */       sQLException.fillInStackTrace();
/*  544 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  548 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  549 */       return 0L;
/*      */     }
/*  551 */     unimpl("getLong");
/*      */     
/*  553 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float getFloat(int paramInt) throws SQLException {
/*  561 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  564 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  565 */       sQLException.fillInStackTrace();
/*  566 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  570 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  571 */       return 0.0F;
/*      */     }
/*  573 */     unimpl("getFloat");
/*      */ 
/*      */     
/*  576 */     return 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double getDouble(int paramInt) throws SQLException {
/*  585 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/*  588 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  589 */       sQLException.fillInStackTrace();
/*  590 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  594 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  595 */       return 0.0D;
/*      */     }
/*  597 */     unimpl("getDouble");
/*      */     
/*  599 */     return 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*  607 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  611 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  612 */       sQLException.fillInStackTrace();
/*  613 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  618 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  619 */       return null;
/*      */     }
/*  621 */     unimpl("getBigDecimal");
/*      */ 
/*      */     
/*  624 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  633 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  637 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  638 */       sQLException.fillInStackTrace();
/*  639 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  644 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt1] == -1) {
/*  645 */       return null;
/*      */     }
/*  647 */     unimpl("getBigDecimal");
/*      */ 
/*      */     
/*  650 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getString(int paramInt) throws SQLException {
/*  668 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Date getDate(int paramInt) throws SQLException {
/*  676 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  680 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  681 */       sQLException.fillInStackTrace();
/*  682 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  687 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  688 */       return null;
/*      */     }
/*  690 */     unimpl("getDate");
/*      */ 
/*      */     
/*  693 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  702 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  706 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  707 */       sQLException.fillInStackTrace();
/*  708 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  713 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  714 */       return null;
/*      */     }
/*  716 */     unimpl("getDate");
/*      */ 
/*      */     
/*  719 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Time getTime(int paramInt) throws SQLException {
/*  728 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  732 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  733 */       sQLException.fillInStackTrace();
/*  734 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  739 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  740 */       return null;
/*      */     }
/*  742 */     unimpl("getTime");
/*      */ 
/*      */     
/*  745 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/*  754 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  758 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  759 */       sQLException.fillInStackTrace();
/*  760 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  765 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  766 */       return null;
/*      */     }
/*  768 */     unimpl("getTime");
/*      */ 
/*      */     
/*  771 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Timestamp getTimestamp(int paramInt) throws SQLException {
/*  780 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  784 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  785 */       sQLException.fillInStackTrace();
/*  786 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  791 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  792 */       return null;
/*      */     }
/*  794 */     unimpl("getTimestamp");
/*      */ 
/*      */     
/*  797 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/*  806 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  810 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  811 */       sQLException.fillInStackTrace();
/*  812 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  817 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  818 */       return null;
/*      */     }
/*  820 */     unimpl("getTimestamp");
/*      */ 
/*      */     
/*  823 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] privateGetBytes(int paramInt) throws SQLException {
/*  838 */     return getBytes(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getBytes(int paramInt) throws SQLException {
/*  850 */     byte[] arrayOfByte = null;
/*      */     
/*  852 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  856 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  857 */       sQLException.fillInStackTrace();
/*  858 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  863 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*  865 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*  866 */       int i = this.columnIndex + this.byteLength * paramInt;
/*      */       
/*  868 */       arrayOfByte = new byte[s];
/*  869 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/*      */     } 
/*      */     
/*  872 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getAsciiStream(int paramInt) throws SQLException {
/*  880 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  884 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  885 */       sQLException.fillInStackTrace();
/*  886 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  891 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  892 */       return null;
/*      */     }
/*  894 */     unimpl("getAsciiStream");
/*      */ 
/*      */     
/*  897 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/*  906 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  910 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  911 */       sQLException.fillInStackTrace();
/*  912 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  917 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  918 */       return null;
/*      */     }
/*  920 */     unimpl("getUnicodeStream");
/*      */ 
/*      */     
/*  923 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InputStream getBinaryStream(int paramInt) throws SQLException {
/*  932 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  936 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  937 */       sQLException.fillInStackTrace();
/*  938 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  943 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  944 */       return null;
/*      */     }
/*  946 */     unimpl("getBinaryStream");
/*      */ 
/*      */     
/*  949 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt) throws SQLException {
/*  958 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/*  962 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  963 */       sQLException.fillInStackTrace();
/*  964 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  969 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  970 */       return null;
/*      */     }
/*  972 */     unimpl("getObject");
/*      */ 
/*      */     
/*  975 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResultSet getCursor(int paramInt) throws SQLException {
/*  985 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  986 */     sQLException.fillInStackTrace();
/*  987 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Datum getOracleObject(int paramInt) throws SQLException {
/*  996 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1000 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1001 */       sQLException.fillInStackTrace();
/* 1002 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1007 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1008 */       return null;
/*      */     }
/* 1010 */     unimpl("getOracleObject");
/*      */ 
/*      */     
/* 1013 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ROWID getROWID(int paramInt) throws SQLException {
/* 1022 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1026 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1027 */       sQLException1.fillInStackTrace();
/* 1028 */       throw sQLException1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1033 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1034 */       return null;
/*      */     }
/*      */     
/* 1037 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1038 */     sQLException.fillInStackTrace();
/* 1039 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1048 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1052 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1053 */       sQLException.fillInStackTrace();
/* 1054 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1059 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1060 */       return null;
/*      */     }
/* 1062 */     unimpl("getNUMBER");
/*      */ 
/*      */     
/* 1065 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DATE getDATE(int paramInt) throws SQLException {
/* 1074 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1078 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1079 */       sQLException.fillInStackTrace();
/* 1080 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1085 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1086 */       return null;
/*      */     }
/* 1088 */     unimpl("getDATE");
/*      */ 
/*      */     
/* 1091 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ARRAY getARRAY(int paramInt) throws SQLException {
/* 1100 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1104 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1105 */       sQLException.fillInStackTrace();
/* 1106 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1111 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1112 */       return null;
/*      */     }
/* 1114 */     unimpl("getARRAY");
/*      */ 
/*      */     
/* 1117 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 1126 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1130 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1131 */       sQLException.fillInStackTrace();
/* 1132 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1137 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1138 */       return null;
/*      */     }
/* 1140 */     unimpl("getSTRUCT");
/*      */ 
/*      */     
/* 1143 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1152 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1156 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1157 */       sQLException.fillInStackTrace();
/* 1158 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1163 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1164 */       return null;
/*      */     }
/* 1166 */     unimpl("getOPAQUE");
/*      */ 
/*      */     
/* 1169 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   REF getREF(int paramInt) throws SQLException {
/* 1178 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1182 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1183 */       sQLException.fillInStackTrace();
/* 1184 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1189 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1190 */       return null;
/*      */     }
/* 1192 */     unimpl("getREF");
/*      */ 
/*      */     
/* 1195 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CHAR getCHAR(int paramInt) throws SQLException {
/* 1204 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1208 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1209 */       sQLException.fillInStackTrace();
/* 1210 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1215 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1216 */       return null;
/*      */     }
/* 1218 */     unimpl("getCHAR");
/*      */ 
/*      */     
/* 1221 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RAW getRAW(int paramInt) throws SQLException {
/* 1230 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1234 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1235 */       sQLException.fillInStackTrace();
/* 1236 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1241 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1242 */       return null;
/*      */     }
/* 1244 */     unimpl("getRAW");
/*      */ 
/*      */     
/* 1247 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BLOB getBLOB(int paramInt) throws SQLException {
/* 1256 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1260 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1261 */       sQLException.fillInStackTrace();
/* 1262 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1267 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1268 */       return null;
/*      */     }
/* 1270 */     unimpl("getBLOB");
/*      */ 
/*      */     
/* 1273 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CLOB getCLOB(int paramInt) throws SQLException {
/* 1282 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1286 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1287 */       sQLException.fillInStackTrace();
/* 1288 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1293 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1294 */       return null;
/*      */     }
/* 1296 */     unimpl("getCLOB");
/*      */ 
/*      */     
/* 1299 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BFILE getBFILE(int paramInt) throws SQLException {
/* 1308 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1312 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1313 */       sQLException.fillInStackTrace();
/* 1314 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1319 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1320 */       return null;
/*      */     }
/* 1322 */     unimpl("getBFILE");
/*      */ 
/*      */     
/* 1325 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1335 */     Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1340 */     return paramCustomDatumFactory.create(datum, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1348 */     Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1353 */     return paramORADataFactory.create(datum, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1361 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1365 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1366 */       sQLException.fillInStackTrace();
/* 1367 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1372 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1373 */       return null;
/*      */     }
/* 1375 */     unimpl("getObject");
/*      */ 
/*      */     
/* 1378 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 1387 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1391 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1392 */       sQLException.fillInStackTrace();
/* 1393 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1398 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1399 */       return null;
/*      */     }
/* 1401 */     unimpl("getCharacterStream");
/*      */ 
/*      */     
/* 1404 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1413 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1417 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1418 */       sQLException.fillInStackTrace();
/* 1419 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1424 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1425 */       return null;
/*      */     }
/* 1427 */     unimpl("getINTERVALYM");
/*      */ 
/*      */     
/* 1430 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1439 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1443 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1444 */       sQLException.fillInStackTrace();
/* 1445 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1450 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1451 */       return null;
/*      */     }
/* 1453 */     unimpl("getINTERVALDS");
/*      */ 
/*      */     
/* 1456 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1465 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1469 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1470 */       sQLException.fillInStackTrace();
/* 1471 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1476 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1477 */       return null;
/*      */     }
/* 1479 */     unimpl("getTIMESTAMP");
/*      */ 
/*      */     
/* 1482 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1491 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1495 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1496 */       sQLException.fillInStackTrace();
/* 1497 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1502 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1503 */       return null;
/*      */     }
/* 1505 */     unimpl("getTIMESTAMPTZ");
/*      */ 
/*      */     
/* 1508 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1517 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1521 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1522 */       sQLException.fillInStackTrace();
/* 1523 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1528 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1529 */       return null;
/*      */     }
/* 1531 */     unimpl("getTIMESTAMPLTZ");
/*      */ 
/*      */     
/* 1534 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   URL getURL(int paramInt) throws SQLException {
/* 1543 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1547 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1548 */       sQLException.fillInStackTrace();
/* 1549 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1554 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1555 */       return null;
/*      */     }
/* 1557 */     unimpl("getURL");
/*      */ 
/*      */     
/* 1560 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 1569 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1573 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1574 */       sQLException.fillInStackTrace();
/* 1575 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1580 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1581 */       return null;
/*      */     }
/* 1583 */     unimpl("getOraclePlsqlIndexTable");
/*      */ 
/*      */     
/* 1586 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NClob getNClob(int paramInt) throws SQLException {
/* 1597 */     if (this.formOfUse != 2) {
/*      */       
/* 1599 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.valueOf(this.columnIndex));
/* 1600 */       sQLException.fillInStackTrace();
/* 1601 */       throw sQLException;
/*      */     } 
/*      */     
/* 1604 */     return (NClob)getCLOB(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getNString(int paramInt) throws SQLException {
/* 1611 */     return getString(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLXML getSQLXML(int paramInt) throws SQLException {
/* 1618 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */       
/* 1621 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1622 */       sQLException.fillInStackTrace();
/* 1623 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1627 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 1628 */       return null;
/*      */     }
/* 1630 */     unimpl("getSQLXML");
/*      */     
/* 1632 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Reader getNCharacterStream(int paramInt) throws SQLException {
/* 1640 */     return getCharacterStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isNull(int paramInt) throws SQLException {
/* 1649 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1653 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1654 */       sQLException.fillInStackTrace();
/* 1655 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1660 */     return (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setNull(int paramInt, boolean paramBoolean) throws SQLException {
/* 1668 */     if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */       
/* 1672 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1673 */       sQLException.fillInStackTrace();
/* 1674 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1679 */     this.rowSpaceIndicator[this.indicatorIndex + paramInt] = (short)(paramBoolean ? -1 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetchNextColumns() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void calculateSizeTmpByteArray() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 1711 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
/* 1712 */     sQLException.fillInStackTrace();
/* 1713 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copyRow() throws SQLException, IOException {
/* 1724 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
/* 1725 */     sQLException.fillInStackTrace();
/* 1726 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int readStream(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 1735 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
/* 1736 */     sQLException.fillInStackTrace();
/* 1737 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initMetadata() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setDisplaySize(int paramInt) throws SQLException {
/* 1754 */     this.describeMaxLength = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1759 */   int lastRowProcessed = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isUseLess = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1773 */   int physicalColumnIndex = -2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isNullByDescribe = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1805 */     return this.statement.getConnectionDuringExceptionHandling();
/*      */   }
/*      */ 
/*      */   
/* 1809 */   static final byte[] NULL_DATA_BYTES = new byte[] { 2, 3, 5, 7, 11, 13, 17, 19 };
/*      */ 
/*      */ 
/*      */   
/*      */   long updateChecksum(long paramLong, int paramInt) throws SQLException {
/* 1814 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*      */       
/* 1816 */       paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1822 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 1823 */       int i = this.columnIndex + this.byteLength * paramInt;
/*      */       
/* 1825 */       paramLong = CRC64.updateChecksum(paramLong, this.rowSpaceByte, i, s);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1831 */     return paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1836 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\Accessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */