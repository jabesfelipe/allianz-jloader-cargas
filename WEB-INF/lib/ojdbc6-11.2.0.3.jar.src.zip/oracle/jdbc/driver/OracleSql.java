/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleSql
/*      */ {
/*      */   static final int UNINITIALIZED = -1;
/*   39 */   static final String[] EMPTY_LIST = new String[0];
/*      */   
/*      */   DBConversion conversion;
/*      */   
/*      */   String originalSql;
/*      */   
/*      */   String parameterSql;
/*      */   
/*      */   String utickSql;
/*      */   String processedSql;
/*      */   String rowidSql;
/*      */   String actualSql;
/*      */   byte[] sqlBytes;
/*   52 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/*   53 */   byte sqlKindByte = -1;
/*   54 */   int parameterCount = -1;
/*      */   boolean currentConvertNcharLiterals = true;
/*      */   boolean currentProcessEscapes = true;
/*      */   boolean includeRowid = false;
/*   58 */   String[] parameterList = EMPTY_LIST;
/*   59 */   char[] currentParameter = null;
/*      */   
/*   61 */   int bindParameterCount = -1;
/*   62 */   String[] bindParameterList = null;
/*   63 */   int cachedBindParameterCount = -1;
/*   64 */   String[] cachedBindParameterList = null;
/*      */   String cachedParameterSql;
/*      */   String cachedUtickSql;
/*      */   String cachedProcessedSql;
/*      */   String cachedRowidSql;
/*      */   String cachedActualSql;
/*      */   byte[] cachedSqlBytes;
/*   71 */   int selectEndIndex = -1;
/*   72 */   int orderByStartIndex = -1;
/*   73 */   int orderByEndIndex = -1;
/*   74 */   int whereStartIndex = -1;
/*   75 */   int whereEndIndex = -1;
/*   76 */   int forUpdateStartIndex = -1;
/*   77 */   int forUpdateEndIndex = -1;
/*      */   
/*   79 */   int[] ncharLiteralLocation = new int[513];
/*   80 */   int lastNcharLiteralLocation = -1;
/*      */   
/*      */   static final String paramPrefix = "rowid";
/*   83 */   int paramSuffix = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   StringBuffer stringBufferForScrollableStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int cMax = 127;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initialize(String paramString) throws SQLException {
/*  111 */     if (paramString == null || paramString.length() == 0) {
/*      */       
/*  113 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  114 */       sQLException.fillInStackTrace();
/*  115 */       throw sQLException;
/*      */     } 
/*      */     
/*  118 */     this.originalSql = paramString;
/*  119 */     this.utickSql = null;
/*  120 */     this.processedSql = null;
/*  121 */     this.rowidSql = null;
/*  122 */     this.actualSql = null;
/*  123 */     this.sqlBytes = null;
/*  124 */     this.sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/*  125 */     this.parameterCount = -1;
/*  126 */     this.parameterList = EMPTY_LIST;
/*  127 */     this.includeRowid = false;
/*      */     
/*  129 */     this.parameterSql = this.originalSql;
/*  130 */     this.bindParameterCount = -1;
/*  131 */     this.bindParameterList = null;
/*  132 */     this.cachedBindParameterCount = -1;
/*  133 */     this.cachedBindParameterList = null;
/*  134 */     this.cachedParameterSql = null;
/*  135 */     this.cachedActualSql = null;
/*  136 */     this.cachedProcessedSql = null;
/*  137 */     this.cachedRowidSql = null;
/*  138 */     this.cachedSqlBytes = null;
/*  139 */     this.selectEndIndex = -1;
/*  140 */     this.orderByStartIndex = -1;
/*  141 */     this.orderByEndIndex = -1;
/*  142 */     this.whereStartIndex = -1;
/*  143 */     this.whereEndIndex = -1;
/*  144 */     this.forUpdateStartIndex = -1;
/*  145 */     this.forUpdateEndIndex = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getOriginalSql() {
/*  159 */     return this.originalSql;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean setNamedParameters(int paramInt, String[] paramArrayOfString) throws SQLException {
/*  171 */     boolean bool = false;
/*      */     
/*  173 */     if (paramInt == 0) {
/*      */       
/*  175 */       this.bindParameterCount = -1;
/*  176 */       bool = (this.bindParameterCount != this.cachedBindParameterCount) ? true : false;
/*      */     }
/*      */     else {
/*      */       
/*  180 */       this.bindParameterCount = paramInt;
/*  181 */       this.bindParameterList = paramArrayOfString;
/*  182 */       bool = (this.bindParameterCount != this.cachedBindParameterCount) ? true : false;
/*      */       
/*  184 */       if (!bool) {
/*  185 */         for (byte b = 0; b < paramInt; b++) {
/*  186 */           if (this.bindParameterList[b] != this.cachedBindParameterList[b]) {
/*      */             
/*  188 */             bool = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }
/*  193 */       if (bool) {
/*      */         
/*  195 */         if (this.bindParameterCount != getParameterCount()) {
/*      */           
/*  197 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 197);
/*  198 */           sQLException.fillInStackTrace();
/*  199 */           throw sQLException;
/*      */         } 
/*      */         
/*  202 */         char[] arrayOfChar = this.originalSql.toCharArray();
/*  203 */         StringBuffer stringBuffer = new StringBuffer();
/*      */         
/*  205 */         byte b1 = 0;
/*      */         
/*  207 */         for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
/*      */           
/*  209 */           if (arrayOfChar[b2] != '?') {
/*      */             
/*  211 */             stringBuffer.append(arrayOfChar[b2]);
/*      */           }
/*      */           else {
/*      */             
/*  215 */             stringBuffer.append(this.bindParameterList[b1++]);
/*  216 */             stringBuffer.append("=>" + nextArgument());
/*      */           } 
/*      */         } 
/*      */         
/*  220 */         this.parameterSql = stringBuffer.toString();
/*  221 */         this.actualSql = null;
/*  222 */         this.utickSql = null;
/*  223 */         this.processedSql = null;
/*  224 */         this.rowidSql = null;
/*  225 */         this.sqlBytes = null;
/*      */       }
/*      */       else {
/*      */         
/*  229 */         this.parameterSql = this.cachedParameterSql;
/*  230 */         this.actualSql = this.cachedActualSql;
/*  231 */         this.utickSql = this.cachedUtickSql;
/*  232 */         this.processedSql = this.cachedProcessedSql;
/*  233 */         this.rowidSql = this.cachedRowidSql;
/*  234 */         this.sqlBytes = this.cachedSqlBytes;
/*      */       } 
/*      */     } 
/*      */     
/*  238 */     this.cachedBindParameterList = null;
/*  239 */     this.cachedParameterSql = null;
/*  240 */     this.cachedActualSql = null;
/*  241 */     this.cachedUtickSql = null;
/*  242 */     this.cachedProcessedSql = null;
/*  243 */     this.cachedRowidSql = null;
/*  244 */     this.cachedSqlBytes = null;
/*      */     
/*  246 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetNamedParameters() {
/*  256 */     this.cachedBindParameterCount = this.bindParameterCount;
/*      */     
/*  258 */     if (this.bindParameterCount != -1) {
/*      */       
/*  260 */       if (this.cachedBindParameterList == null || this.cachedBindParameterList == this.bindParameterList || this.cachedBindParameterList.length < this.bindParameterCount)
/*      */       {
/*      */         
/*  263 */         this.cachedBindParameterList = new String[this.bindParameterCount];
/*      */       }
/*  265 */       System.arraycopy(this.bindParameterList, 0, this.cachedBindParameterList, 0, this.bindParameterCount);
/*      */ 
/*      */       
/*  268 */       this.cachedParameterSql = this.parameterSql;
/*  269 */       this.cachedActualSql = this.actualSql;
/*  270 */       this.cachedUtickSql = this.utickSql;
/*  271 */       this.cachedProcessedSql = this.processedSql;
/*  272 */       this.cachedRowidSql = this.rowidSql;
/*  273 */       this.cachedSqlBytes = this.sqlBytes;
/*      */       
/*  275 */       this.bindParameterCount = -1;
/*  276 */       this.bindParameterList = null;
/*  277 */       this.parameterSql = this.originalSql;
/*  278 */       this.actualSql = null;
/*  279 */       this.utickSql = null;
/*  280 */       this.processedSql = null;
/*  281 */       this.rowidSql = null;
/*  282 */       this.sqlBytes = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getSql(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
/*  301 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) computeBasicInfo(this.parameterSql); 
/*  302 */     if (paramBoolean1 != this.currentProcessEscapes || paramBoolean2 != this.currentConvertNcharLiterals) {
/*      */ 
/*      */ 
/*      */       
/*  306 */       if (paramBoolean2 != this.currentConvertNcharLiterals) this.utickSql = null; 
/*  307 */       this.processedSql = null;
/*  308 */       this.rowidSql = null;
/*  309 */       this.actualSql = null;
/*  310 */       this.sqlBytes = null;
/*      */     } 
/*      */     
/*  313 */     this.currentConvertNcharLiterals = paramBoolean2;
/*  314 */     this.currentProcessEscapes = paramBoolean1;
/*      */     
/*  316 */     if (this.actualSql == null) {
/*      */       
/*  318 */       if (this.utickSql == null)
/*  319 */         this.utickSql = this.currentConvertNcharLiterals ? convertNcharLiterals(this.parameterSql) : this.parameterSql; 
/*  320 */       if (this.processedSql == null)
/*  321 */         this.processedSql = this.currentProcessEscapes ? parse(this.utickSql) : this.utickSql; 
/*  322 */       if (this.rowidSql == null)
/*  323 */         this.rowidSql = this.includeRowid ? addRowid(this.processedSql) : this.processedSql; 
/*  324 */       this.actualSql = this.rowidSql;
/*      */     } 
/*      */ 
/*      */     
/*  328 */     return this.actualSql;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getRevisedSql() throws SQLException {
/*  337 */     String str = null;
/*      */     
/*  339 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) computeBasicInfo(this.parameterSql);
/*      */     
/*  341 */     str = removeForUpdate(this.parameterSql);
/*      */     
/*  343 */     return addRowid(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String removeForUpdate(String paramString) throws SQLException {
/*  358 */     if (this.orderByStartIndex != -1 && (this.forUpdateStartIndex == -1 || this.forUpdateStartIndex > this.orderByStartIndex)) {
/*      */ 
/*      */ 
/*      */       
/*  362 */       paramString = paramString.substring(0, this.orderByStartIndex);
/*      */     }
/*  364 */     else if (this.forUpdateStartIndex != -1) {
/*      */       
/*  366 */       paramString = paramString.substring(0, this.forUpdateStartIndex);
/*      */     } 
/*      */     
/*  369 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void appendForUpdate(StringBuffer paramStringBuffer) throws SQLException {
/*  387 */     if (this.orderByStartIndex != -1 && (this.forUpdateStartIndex == -1 || this.forUpdateStartIndex > this.orderByStartIndex)) {
/*      */ 
/*      */ 
/*      */       
/*  391 */       paramStringBuffer.append(this.originalSql.substring(this.orderByStartIndex));
/*      */     }
/*  393 */     else if (this.forUpdateStartIndex != -1) {
/*      */       
/*  395 */       paramStringBuffer.append(this.originalSql.substring(this.forUpdateStartIndex));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected OracleSql(DBConversion paramDBConversion) {
/*  400 */     this.stringBufferForScrollableStatement = null;
/*      */     this.conversion = paramDBConversion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getInsertSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet) throws SQLException {
/*  413 */     String str = getOriginalSql();
/*  414 */     boolean bool = generatedSqlNeedEscapeProcessing();
/*      */     
/*  416 */     if (this.stringBufferForScrollableStatement == null) {
/*  417 */       this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
/*      */     } else {
/*  419 */       this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
/*      */     } 
/*  421 */     this.stringBufferForScrollableStatement.append("insert into (");
/*      */     
/*  423 */     this.stringBufferForScrollableStatement.append(removeForUpdate(str));
/*  424 */     this.stringBufferForScrollableStatement.append(") values ( ");
/*      */     
/*  426 */     byte b = 1;
/*  427 */     for (; b < paramUpdatableResultSet.getColumnCount(); 
/*  428 */       b++) {
/*      */       
/*  430 */       if (b != 1) {
/*  431 */         this.stringBufferForScrollableStatement.append(", ");
/*      */       }
/*  433 */       if (bool) {
/*  434 */         this.stringBufferForScrollableStatement.append("?");
/*      */       } else {
/*  436 */         this.stringBufferForScrollableStatement.append(":" + generateParameterName());
/*      */       } 
/*      */     } 
/*  439 */     this.stringBufferForScrollableStatement.append(")");
/*      */     
/*  441 */     this.paramSuffix = 0;
/*      */     
/*  443 */     return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getRefetchSqlForScrollableResultSet(ScrollableResultSet paramScrollableResultSet, int paramInt) throws SQLException {
/*  463 */     String str = getRevisedSql();
/*  464 */     boolean bool = generatedSqlNeedEscapeProcessing();
/*      */     
/*  466 */     if (this.stringBufferForScrollableStatement == null) {
/*  467 */       this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
/*      */     } else {
/*  469 */       this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
/*      */     } 
/*      */     
/*  472 */     this.stringBufferForScrollableStatement.append(str);
/*      */     
/*  474 */     if (this.whereStartIndex == -1) {
/*      */       
/*  476 */       this.stringBufferForScrollableStatement.append(bool ? " WHERE ( ROWID = ?" : (" WHERE ( ROWID = :" + generateParameterName()));
/*      */     } else {
/*      */       
/*  479 */       this.stringBufferForScrollableStatement.append(bool ? " AND ( ROWID = ?" : (" AND ( ROWID = :" + generateParameterName()));
/*      */     } 
/*      */     
/*  482 */     for (byte b = 0; b < paramInt - 1; b++) {
/*  483 */       if (bool) {
/*  484 */         this.stringBufferForScrollableStatement.append(" OR ROWID = ?");
/*      */       } else {
/*      */         
/*  487 */         this.stringBufferForScrollableStatement.append(" OR ROWID = :" + generateParameterName());
/*      */       } 
/*  489 */     }  this.stringBufferForScrollableStatement.append(" ) ");
/*      */ 
/*      */     
/*  492 */     appendForUpdate(this.stringBufferForScrollableStatement);
/*      */     
/*  494 */     this.paramSuffix = 0;
/*      */     
/*  496 */     return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getUpdateSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet, int paramInt, Object[] paramArrayOfObject, int[] paramArrayOfint) throws SQLException {
/*  514 */     String str = getRevisedSql();
/*  515 */     boolean bool = generatedSqlNeedEscapeProcessing();
/*      */     
/*  517 */     if (this.stringBufferForScrollableStatement == null) {
/*  518 */       this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
/*      */     } else {
/*  520 */       this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
/*      */     } 
/*      */ 
/*      */     
/*  524 */     this.stringBufferForScrollableStatement.append("update (");
/*  525 */     this.stringBufferForScrollableStatement.append(str);
/*  526 */     this.stringBufferForScrollableStatement.append(") set ");
/*      */ 
/*      */     
/*  529 */     if (paramArrayOfObject != null)
/*      */     {
/*  531 */       for (byte b = 0; b < paramInt; b++) {
/*      */         
/*  533 */         if (b > 0) {
/*  534 */           this.stringBufferForScrollableStatement.append(", ");
/*      */         }
/*  536 */         this.stringBufferForScrollableStatement.append(paramUpdatableResultSet.getInternalMetadata().getColumnName(paramArrayOfint[b] + 1));
/*      */ 
/*      */         
/*  539 */         if (bool) {
/*  540 */           this.stringBufferForScrollableStatement.append(" = ?");
/*      */         } else {
/*  542 */           this.stringBufferForScrollableStatement.append(" = :" + generateParameterName());
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  547 */     this.stringBufferForScrollableStatement.append(" WHERE ");
/*  548 */     if (bool) {
/*  549 */       this.stringBufferForScrollableStatement.append(" ROWID = ?");
/*      */     } else {
/*  551 */       this.stringBufferForScrollableStatement.append(" ROWID = :" + generateParameterName());
/*      */     } 
/*      */     
/*  554 */     this.paramSuffix = 0;
/*      */     
/*  556 */     return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getDeleteSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet) throws SQLException {
/*  572 */     String str = getRevisedSql();
/*  573 */     boolean bool = generatedSqlNeedEscapeProcessing();
/*      */     
/*  575 */     if (this.stringBufferForScrollableStatement == null) {
/*  576 */       this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
/*      */     } else {
/*  578 */       this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
/*      */     } 
/*      */ 
/*      */     
/*  582 */     this.stringBufferForScrollableStatement.append("delete from (");
/*  583 */     this.stringBufferForScrollableStatement.append(str);
/*  584 */     this.stringBufferForScrollableStatement.append(") where ");
/*      */     
/*  586 */     if (bool) {
/*  587 */       this.stringBufferForScrollableStatement.append(" ROWID = ?");
/*      */     } else {
/*  589 */       this.stringBufferForScrollableStatement.append(" ROWID = :" + generateParameterName());
/*      */     } 
/*      */     
/*  592 */     this.paramSuffix = 0;
/*      */     
/*  594 */     return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean generatedSqlNeedEscapeProcessing() {
/*  606 */     return (this.parameterCount > 0 && this.parameterList == EMPTY_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getSqlBytes(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
/*  619 */     if (this.sqlBytes == null || paramBoolean1 != this.currentProcessEscapes)
/*      */     {
/*  621 */       this.sqlBytes = this.conversion.StringToCharBytes(getSql(paramBoolean1, paramBoolean2));
/*      */     }
/*      */ 
/*      */     
/*  625 */     return this.sqlBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement.SqlKind getSqlKind() throws SQLException {
/*  639 */     if (this.parameterSql == null) {
/*  640 */       return OracleStatement.SqlKind.UNINITIALIZED;
/*      */     }
/*  642 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*  643 */       computeBasicInfo(this.parameterSql);
/*      */     }
/*  645 */     return this.sqlKind;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getParameterCount() throws SQLException {
/*  659 */     if (this.parameterCount == -1)
/*      */     {
/*  661 */       computeBasicInfo(this.parameterSql);
/*      */     }
/*      */     
/*  664 */     return this.parameterCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getParameterList() throws SQLException {
/*  681 */     if (this.parameterCount == -1)
/*      */     {
/*  683 */       computeBasicInfo(this.parameterSql);
/*      */     }
/*      */     
/*  686 */     return this.parameterList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setIncludeRowid(boolean paramBoolean) {
/*  701 */     if (paramBoolean != this.includeRowid) {
/*      */       
/*  703 */       this.includeRowid = paramBoolean;
/*  704 */       this.rowidSql = null;
/*  705 */       this.actualSql = null;
/*  706 */       this.sqlBytes = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  715 */     return (this.parameterSql == null) ? "null" : this.parameterSql;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String hexUnicode(int paramInt) throws SQLException {
/*  731 */     String str = Integer.toHexString(paramInt);
/*  732 */     switch (str.length()) {
/*      */       case 0:
/*  734 */         return "\\0000";
/*  735 */       case 1: return "\\000" + str;
/*  736 */       case 2: return "\\00" + str;
/*  737 */       case 3: return "\\0" + str;
/*  738 */       case 4: return "\\" + str;
/*      */     } 
/*      */     
/*  741 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "Unexpected case in OracleSql.hexUnicode: " + paramInt);
/*  742 */     sQLException.fillInStackTrace();
/*  743 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String convertNcharLiterals(String paramString) throws SQLException {
/*  766 */     if (this.lastNcharLiteralLocation <= 2) return paramString; 
/*  767 */     String str = "";
/*  768 */     byte b = 0;
/*      */     
/*      */     while (true) {
/*  771 */       int i = this.ncharLiteralLocation[b++];
/*  772 */       int j = this.ncharLiteralLocation[b++];
/*      */       
/*  774 */       str = str + paramString.substring(i, j);
/*  775 */       if (b >= this.lastNcharLiteralLocation)
/*  776 */         break;  i = this.ncharLiteralLocation[b];
/*  777 */       str = str + "u'";
/*      */       
/*  779 */       for (int k = j + 2; k < i; k++) {
/*      */         
/*  781 */         char c = paramString.charAt(k);
/*  782 */         if (c == '\\') { str = str + "\\\\"; }
/*  783 */         else if (c < '') { str = str + c; }
/*  784 */         else { str = str + hexUnicode(c); }
/*      */       
/*      */       } 
/*  787 */     }  return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  795 */   private static final int[][] TRANSITION = OracleSqlReadOnly.TRANSITION;
/*      */ 
/*      */   
/*  798 */   private static final int[][] ACTION = OracleSqlReadOnly.ACTION;
/*      */   
/*      */   private static final int NO_ACTION = 0;
/*      */   
/*      */   private static final int DELETE_ACTION = 1;
/*      */   
/*      */   private static final int INSERT_ACTION = 2;
/*      */   
/*      */   private static final int MERGE_ACTION = 3;
/*      */   
/*      */   private static final int UPDATE_ACTION = 4;
/*      */   
/*      */   private static final int PLSQL_ACTION = 5;
/*      */   
/*      */   private static final int CALL_ACTION = 6;
/*      */   
/*      */   private static final int SELECT_ACTION = 7;
/*      */   
/*      */   private static final int ORDER_ACTION = 10;
/*      */   
/*      */   private static final int ORDER_BY_ACTION = 11;
/*      */   
/*      */   private static final int WHERE_ACTION = 9;
/*      */   
/*      */   private static final int FOR_ACTION = 12;
/*      */   private static final int FOR_UPDATE_ACTION = 13;
/*      */   private static final int OTHER_ACTION = 8;
/*      */   private static final int QUESTION_ACTION = 14;
/*      */   private static final int PARAMETER_ACTION = 15;
/*      */   private static final int END_PARAMETER_ACTION = 16;
/*      */   private static final int START_NCHAR_LITERAL_ACTION = 17;
/*      */   private static final int END_NCHAR_LITERAL_ACTION = 18;
/*      */   private static final int SAVE_DELIMITER_ACTION = 19;
/*      */   private static final int LOOK_FOR_DELIMITER_ACTION = 20;
/*      */   private static final int ALTER_SESSION_ACTION = 21;
/*      */   private static final int INITIAL_STATE = 0;
/*      */   private static final int RESTART_STATE = 66;
/*  835 */   private static final OracleSqlReadOnly.ODBCAction[][] ODBC_ACTION = OracleSqlReadOnly.ODBC_ACTION;
/*      */ 
/*      */   
/*      */   private static final boolean DEBUG_CBI = false;
/*      */ 
/*      */   
/*      */   int current_argument;
/*      */ 
/*      */   
/*      */   int i;
/*      */ 
/*      */   
/*      */   int length;
/*      */ 
/*      */   
/*      */   char c;
/*      */ 
/*      */   
/*      */   boolean first;
/*      */ 
/*      */   
/*      */   String odbc_sql;
/*      */ 
/*      */   
/*      */   StringBuffer oracle_sql;
/*      */ 
/*      */   
/*      */   StringBuffer token_buffer;
/*      */ 
/*      */   
/*      */   void computeBasicInfo(String paramString) throws SQLException {
/*  866 */     this.parameterCount = 0;
/*      */     
/*  868 */     this.lastNcharLiteralLocation = 0;
/*  869 */     this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = 0;
/*      */     
/*  871 */     byte b1 = 0;
/*      */     
/*  873 */     byte b2 = 0;
/*      */     
/*  875 */     int i = 0;
/*  876 */     int j = paramString.length();
/*  877 */     int k = -1;
/*  878 */     int m = -1;
/*  879 */     int n = j + 1;
/*      */ 
/*      */     
/*  882 */     for (byte b3 = 0; b3 < n; b3++) {
/*      */       
/*  884 */       byte b4 = (b3 < j) ? paramString.charAt(b3) : 32;
/*  885 */       byte b5 = b4;
/*      */       
/*  887 */       if (b4 > 127)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  893 */         if (Character.isLetterOrDigit(b4)) {
/*  894 */           b5 = 88;
/*      */         } else {
/*  896 */           b5 = 32;
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  901 */       switch (ACTION[i][b5]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 1:
/*  908 */           this.sqlKind = OracleStatement.SqlKind.DELETE;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/*  913 */           this.sqlKind = OracleStatement.SqlKind.INSERT;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*  918 */           this.sqlKind = OracleStatement.SqlKind.MERGE;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/*  923 */           this.sqlKind = OracleStatement.SqlKind.UPDATE;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*  928 */           this.sqlKind = OracleStatement.SqlKind.PLSQL_BLOCK;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 6:
/*  933 */           this.sqlKind = OracleStatement.SqlKind.CALL_BLOCK;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*  938 */           this.sqlKind = OracleStatement.SqlKind.SELECT;
/*  939 */           this.selectEndIndex = b3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*  944 */           this.sqlKind = OracleStatement.SqlKind.OTHER;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*  949 */           this.whereStartIndex = b3 - 5;
/*  950 */           this.whereEndIndex = b3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 10:
/*  955 */           k = b3 - 5;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 11:
/*  960 */           this.orderByStartIndex = k;
/*  961 */           this.orderByEndIndex = b3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 12:
/*  966 */           m = b3 - 3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 13:
/*  971 */           this.forUpdateStartIndex = m;
/*  972 */           this.forUpdateEndIndex = b3;
/*  973 */           if (this.sqlKind == OracleStatement.SqlKind.SELECT) {
/*  974 */             this.sqlKind = OracleStatement.SqlKind.SELECT_FOR_UPDATE;
/*      */           }
/*      */           break;
/*      */         
/*      */         case 21:
/*  979 */           this.sqlKind = OracleStatement.SqlKind.ALTER_SESSION;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 14:
/*  984 */           this.parameterCount++;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 15:
/*  989 */           if (this.currentParameter == null) {
/*  990 */             this.currentParameter = new char[32];
/*      */           }
/*  992 */           if (b2 >= this.currentParameter.length) {
/*      */             
/*  994 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 134, new String(this.currentParameter));
/*  995 */             sQLException.fillInStackTrace();
/*  996 */             throw sQLException;
/*      */           } 
/*      */           
/*  999 */           this.currentParameter[b2++] = b4;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 16:
/* 1004 */           if (b2 > 0) {
/*      */             
/* 1006 */             if (this.parameterList == EMPTY_LIST) {
/*      */               
/* 1008 */               this.parameterList = new String[8];
/*      */             }
/* 1010 */             else if (this.parameterList.length <= this.parameterCount) {
/*      */               
/* 1012 */               String[] arrayOfString = new String[this.parameterList.length * 4];
/*      */               
/* 1014 */               System.arraycopy(this.parameterList, 0, arrayOfString, 0, this.parameterList.length);
/*      */ 
/*      */               
/* 1017 */               this.parameterList = arrayOfString;
/*      */             } 
/*      */             
/* 1020 */             this.parameterList[this.parameterCount] = (new String(this.currentParameter, 0, b2)).intern();
/*      */             
/* 1022 */             b2 = 0;
/* 1023 */             this.parameterCount++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 17:
/* 1029 */           this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = b3 - 1;
/* 1030 */           if (this.lastNcharLiteralLocation >= this.ncharLiteralLocation.length) {
/* 1031 */             growNcharLiteralLocation(this.ncharLiteralLocation.length << 2);
/*      */           }
/*      */           break;
/*      */         case 18:
/* 1035 */           this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = b3;
/* 1036 */           if (this.lastNcharLiteralLocation >= this.ncharLiteralLocation.length) {
/* 1037 */             growNcharLiteralLocation(this.ncharLiteralLocation.length << 2);
/*      */           }
/*      */           break;
/*      */         
/*      */         case 19:
/* 1042 */           if (b4 == 91) { b1 = 93; break; }
/* 1043 */            if (b4 == 123) { b1 = 125; break; }
/* 1044 */            if (b4 == 60) { b1 = 62; break; }
/* 1045 */            if (b4 == 40) { b1 = 41; break; }
/* 1046 */            b1 = b4;
/*      */           break;
/*      */         
/*      */         case 20:
/* 1050 */           if (b4 == b1)
/*      */           {
/*      */             
/* 1053 */             i++;
/*      */           }
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 1059 */       i = TRANSITION[i][b5];
/*      */     } 
/*      */     
/* 1062 */     if (this.lastNcharLiteralLocation + 2 >= this.ncharLiteralLocation.length)
/* 1063 */       growNcharLiteralLocation(this.lastNcharLiteralLocation + 2); 
/* 1064 */     this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = j;
/* 1065 */     this.ncharLiteralLocation[this.lastNcharLiteralLocation] = j;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void growNcharLiteralLocation(int paramInt) {
/* 1073 */     int[] arrayOfInt = new int[paramInt];
/* 1074 */     System.arraycopy(this.ncharLiteralLocation, 0, arrayOfInt, 0, this.ncharLiteralLocation.length);
/* 1075 */     this.ncharLiteralLocation = null;
/* 1076 */     this.ncharLiteralLocation = arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String addRowid(String paramString) throws SQLException {
/* 1083 */     if (this.selectEndIndex == -1) {
/*      */       
/* 1085 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 88);
/* 1086 */       sQLException.fillInStackTrace();
/* 1087 */       throw sQLException;
/*      */     } 
/*      */     
/* 1090 */     return "select rowid as \"__Oracle_JDBC_interal_ROWID__\"," + paramString.substring(this.selectEndIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum ParseMode
/*      */   {
/* 1105 */     NORMAL, SCALAR, LOCATE_1, LOCATE_2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String parse(String paramString) throws SQLException {
/* 1124 */     this.first = true;
/* 1125 */     this.current_argument = 1;
/* 1126 */     this.i = 0;
/* 1127 */     this.odbc_sql = paramString;
/* 1128 */     this.length = this.odbc_sql.length();
/*      */     
/* 1130 */     if (this.oracle_sql == null) {
/*      */       
/* 1132 */       this.oracle_sql = new StringBuffer(this.length);
/* 1133 */       this.token_buffer = new StringBuffer(32);
/*      */     }
/*      */     else {
/*      */       
/* 1137 */       this.oracle_sql.ensureCapacity(this.length);
/*      */     } 
/*      */     
/* 1140 */     this.oracle_sql.delete(0, this.oracle_sql.length());
/* 1141 */     skipSpace();
/* 1142 */     handleODBC(ParseMode.NORMAL);
/*      */     
/* 1144 */     if (this.i < this.length) {
/*      */       
/* 1146 */       Integer integer = Integer.valueOf(this.i);
/*      */ 
/*      */       
/* 1149 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, integer);
/* 1150 */       sQLException.fillInStackTrace();
/* 1151 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1155 */     return this.oracle_sql.substring(0, this.oracle_sql.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleODBC(ParseMode paramParseMode) throws SQLException {
/* 1165 */     int i = (paramParseMode == ParseMode.NORMAL) ? 0 : 66;
/* 1166 */     byte b1 = 0;
/* 1167 */     byte b2 = 0;
/*      */     
/* 1169 */     while (this.i < this.length) {
/*      */       SQLException sQLException;
/* 1171 */       byte b3 = (this.i < this.length) ? this.odbc_sql.charAt(this.i) : 32;
/* 1172 */       byte b4 = b3;
/*      */       
/* 1174 */       if (b3 > 127)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1180 */         if (Character.isLetterOrDigit(b3)) {
/* 1181 */           b4 = 88;
/*      */         } else {
/* 1183 */           b4 = 32;
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1188 */       switch (ODBC_ACTION[i][b4]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case COPY:
/* 1195 */           this.oracle_sql.append(b3);
/*      */           break;
/*      */         
/*      */         case QUESTION:
/* 1199 */           this.oracle_sql.append(nextArgument());
/* 1200 */           this.oracle_sql.append(' ');
/*      */           break;
/*      */         
/*      */         case SAVE_DELIMITER:
/* 1204 */           if (b3 == 91) { b1 = 93; }
/* 1205 */           else if (b3 == 123) { b1 = 125; }
/* 1206 */           else if (b3 == 60) { b1 = 62; }
/* 1207 */           else if (b3 == 40) { b1 = 41; }
/* 1208 */           else { b1 = b3; }
/* 1209 */            this.oracle_sql.append(b3);
/*      */           break;
/*      */         
/*      */         case LOOK_FOR_DELIMITER:
/* 1213 */           if (b3 == b1)
/*      */           {
/*      */             
/* 1216 */             i++;
/*      */           }
/* 1218 */           this.oracle_sql.append(b3);
/*      */           break;
/*      */         
/*      */         case FUNCTION:
/* 1222 */           handleFunction();
/*      */           break;
/*      */         
/*      */         case CALL:
/* 1226 */           handleCall();
/*      */           break;
/*      */         
/*      */         case TIME:
/* 1230 */           handleTime();
/*      */           break;
/*      */         
/*      */         case TIMESTAMP:
/* 1234 */           handleTimestamp();
/*      */           break;
/*      */         
/*      */         case DATE:
/* 1238 */           handleDate();
/*      */           break;
/*      */         
/*      */         case ESCAPE:
/* 1242 */           handleEscape();
/*      */           break;
/*      */         
/*      */         case SCALAR_FUNCTION:
/* 1246 */           handleScalarFunction();
/*      */           break;
/*      */         
/*      */         case OUTER_JOIN:
/* 1250 */           handleOuterJoin();
/*      */           break;
/*      */ 
/*      */         
/*      */         case UNKNOWN_ESCAPE:
/* 1255 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, Integer.valueOf(this.i));
/* 1256 */           sQLException.fillInStackTrace();
/* 1257 */           throw sQLException;
/*      */ 
/*      */         
/*      */         case END_ODBC_ESCAPE:
/* 1261 */           if (paramParseMode == ParseMode.SCALAR) {
/*      */             return;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case COMMA:
/* 1269 */           if (paramParseMode == ParseMode.LOCATE_1 && b2 > 1) {
/* 1270 */             this.oracle_sql.append(b3); break;
/*      */           } 
/* 1272 */           if (paramParseMode == ParseMode.LOCATE_1) {
/*      */             return;
/*      */           }
/*      */           
/* 1276 */           if (paramParseMode == ParseMode.LOCATE_2) {
/*      */             break;
/*      */           }
/*      */ 
/*      */           
/* 1281 */           this.oracle_sql.append(b3);
/*      */           break;
/*      */ 
/*      */         
/*      */         case OPEN_PAREN:
/* 1286 */           if (paramParseMode == ParseMode.LOCATE_1) {
/* 1287 */             if (b2 > 0) this.oracle_sql.append(b3); 
/* 1288 */             b2++; break;
/*      */           } 
/* 1290 */           if (paramParseMode == ParseMode.LOCATE_2) {
/* 1291 */             b2++;
/* 1292 */             this.oracle_sql.append(b3);
/*      */             
/*      */             break;
/*      */           } 
/* 1296 */           this.oracle_sql.append(b3);
/*      */           break;
/*      */ 
/*      */         
/*      */         case CLOSE_PAREN:
/* 1301 */           if (paramParseMode == ParseMode.LOCATE_1) {
/* 1302 */             b2--;
/* 1303 */             this.oracle_sql.append(b3); break;
/*      */           } 
/* 1305 */           if (paramParseMode == ParseMode.LOCATE_2 && b2 > 1) {
/* 1306 */             b2--;
/* 1307 */             this.oracle_sql.append(b3); break;
/*      */           } 
/* 1309 */           if (paramParseMode == ParseMode.LOCATE_2) {
/* 1310 */             this.i++;
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/* 1316 */           this.oracle_sql.append(b3);
/*      */           break;
/*      */ 
/*      */         
/*      */         case BEGIN:
/* 1321 */           this.first = false;
/* 1322 */           this.oracle_sql.append(b3);
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 1327 */       i = TRANSITION[i][b4];
/* 1328 */       this.i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleFunction() throws SQLException {
/* 1337 */     boolean bool = this.first;
/* 1338 */     this.first = false;
/*      */     
/* 1340 */     if (bool) {
/* 1341 */       this.oracle_sql.append("BEGIN ");
/*      */     }
/* 1343 */     appendChar(this.oracle_sql, '?');
/* 1344 */     skipSpace();
/*      */     
/* 1346 */     if (this.c != '=') {
/*      */       
/* 1348 */       String str = this.i + ". Expecting \"=\" got \"" + this.c + "\"";
/*      */ 
/*      */       
/* 1351 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, str);
/* 1352 */       sQLException.fillInStackTrace();
/* 1353 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1357 */     this.i++;
/*      */     
/* 1359 */     skipSpace();
/*      */     
/* 1361 */     if (!this.odbc_sql.startsWith("call", this.i)) {
/*      */       
/* 1363 */       String str = this.i + ". Expecting \"call\"";
/*      */ 
/*      */       
/* 1366 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, str);
/* 1367 */       sQLException.fillInStackTrace();
/* 1368 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1372 */     this.i += 4;
/*      */     
/* 1374 */     this.oracle_sql.append(" := ");
/* 1375 */     skipSpace();
/* 1376 */     handleODBC(ParseMode.SCALAR);
/*      */     
/* 1378 */     if (bool) {
/* 1379 */       this.oracle_sql.append("; END;");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleCall() throws SQLException {
/* 1387 */     boolean bool = this.first;
/* 1388 */     this.first = false;
/*      */     
/* 1390 */     if (bool) {
/* 1391 */       this.oracle_sql.append("BEGIN ");
/*      */     }
/* 1393 */     skipSpace();
/* 1394 */     handleODBC(ParseMode.SCALAR);
/* 1395 */     skipSpace();
/*      */     
/* 1397 */     if (bool) {
/* 1398 */       this.oracle_sql.append("; END;");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleTimestamp() throws SQLException {
/* 1407 */     this.oracle_sql.append("TO_TIMESTAMP (");
/* 1408 */     skipSpace();
/* 1409 */     handleODBC(ParseMode.SCALAR);
/* 1410 */     this.oracle_sql.append(", 'YYYY-MM-DD HH24:MI:SS.FF')");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleTime() throws SQLException {
/* 1417 */     this.oracle_sql.append("TO_DATE (");
/* 1418 */     skipSpace();
/* 1419 */     handleODBC(ParseMode.SCALAR);
/* 1420 */     this.oracle_sql.append(", 'HH24:MI:SS')");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleDate() throws SQLException {
/* 1427 */     this.oracle_sql.append("TO_DATE (");
/* 1428 */     skipSpace();
/* 1429 */     handleODBC(ParseMode.SCALAR);
/* 1430 */     this.oracle_sql.append(", 'YYYY-MM-DD')");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleEscape() throws SQLException {
/* 1437 */     this.oracle_sql.append("ESCAPE ");
/* 1438 */     skipSpace();
/* 1439 */     handleODBC(ParseMode.SCALAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleScalarFunction() throws SQLException {
/* 1446 */     this.token_buffer.delete(0, this.token_buffer.length());
/*      */     
/* 1448 */     this.i++;
/*      */     
/* 1450 */     skipSpace();
/*      */ 
/*      */ 
/*      */     
/* 1454 */     while (this.i < this.length && (Character.isJavaLetterOrDigit(this.c = this.odbc_sql.charAt(this.i)) || this.c == '?')) {
/*      */ 
/*      */       
/* 1457 */       this.token_buffer.append(this.c);
/*      */       
/* 1459 */       this.i++;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1465 */     String str = this.token_buffer.substring(0, this.token_buffer.length()).toUpperCase().intern();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1473 */     if (str == "ABS")
/* 1474 */     { usingFunctionName(str); }
/* 1475 */     else if (str == "ACOS")
/* 1476 */     { usingFunctionName(str); }
/* 1477 */     else if (str == "ASIN")
/* 1478 */     { usingFunctionName(str); }
/* 1479 */     else if (str == "ATAN")
/* 1480 */     { usingFunctionName(str); }
/* 1481 */     else if (str == "ATAN2")
/* 1482 */     { usingFunctionName(str); }
/* 1483 */     else if (str == "CEILING")
/* 1484 */     { usingFunctionName("CEIL"); }
/* 1485 */     else if (str == "COS")
/* 1486 */     { usingFunctionName(str); }
/* 1487 */     else { if (str == "COT") {
/*      */         
/* 1489 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1490 */         sQLException.fillInStackTrace();
/* 1491 */         throw sQLException;
/*      */       } 
/* 1493 */       if (str == "DEGREES") {
/*      */         
/* 1495 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1496 */         sQLException.fillInStackTrace();
/* 1497 */         throw sQLException;
/*      */       } 
/* 1499 */       if (str == "EXP")
/* 1500 */       { usingFunctionName(str); }
/* 1501 */       else if (str == "FLOOR")
/* 1502 */       { usingFunctionName(str); }
/* 1503 */       else if (str == "LOG")
/* 1504 */       { usingFunctionName("LN"); }
/* 1505 */       else if (str == "LOG10")
/* 1506 */       { replacingFunctionPrefix("LOG ( 10, "); }
/* 1507 */       else if (str == "MOD")
/* 1508 */       { usingFunctionName(str); }
/* 1509 */       else if (str == "PI")
/* 1510 */       { replacingFunctionPrefix("( 3.141592653589793238462643383279502884197169399375 "); }
/* 1511 */       else if (str == "POWER")
/* 1512 */       { usingFunctionName(str); }
/* 1513 */       else { if (str == "RADIANS") {
/*      */           
/* 1515 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1516 */           sQLException.fillInStackTrace();
/* 1517 */           throw sQLException;
/*      */         } 
/* 1519 */         if (str == "RAND") {
/*      */           
/* 1521 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1522 */           sQLException.fillInStackTrace();
/* 1523 */           throw sQLException;
/*      */         } 
/* 1525 */         if (str == "ROUND")
/* 1526 */         { usingFunctionName(str); }
/* 1527 */         else if (str == "SIGN")
/* 1528 */         { usingFunctionName(str); }
/* 1529 */         else if (str == "SIN")
/* 1530 */         { usingFunctionName(str); }
/* 1531 */         else if (str == "SQRT")
/* 1532 */         { usingFunctionName(str); }
/* 1533 */         else if (str == "TAN")
/* 1534 */         { usingFunctionName(str); }
/* 1535 */         else if (str == "TRUNCATE")
/* 1536 */         { usingFunctionName("TRUNC");
/*      */            }
/*      */         
/* 1539 */         else if (str == "ASCII")
/* 1540 */         { usingFunctionName(str); }
/* 1541 */         else if (str == "CHAR")
/* 1542 */         { usingFunctionName("CHR");
/*      */           
/*      */            }
/*      */         
/* 1546 */         else if (str == "CHAR_LENGTH")
/* 1547 */         { usingFunctionName("LENGTH"); }
/* 1548 */         else if (str == "CHARACTER_LENGTH")
/* 1549 */         { usingFunctionName("LENGTH"); }
/*      */         
/* 1551 */         else if (str == "CONCAT")
/* 1552 */         { usingFunctionName(str); }
/* 1553 */         else { if (str == "DIFFERENCE") {
/*      */             
/* 1555 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1556 */             sQLException.fillInStackTrace();
/* 1557 */             throw sQLException;
/*      */           } 
/* 1559 */           if (str == "INSERT") {
/*      */             
/* 1561 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1562 */             sQLException.fillInStackTrace();
/* 1563 */             throw sQLException;
/*      */           } 
/* 1565 */           if (str == "LCASE")
/* 1566 */           { usingFunctionName("LOWER"); }
/* 1567 */           else { if (str == "LEFT") {
/*      */               
/* 1569 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1570 */               sQLException.fillInStackTrace();
/* 1571 */               throw sQLException;
/*      */             } 
/* 1573 */             if (str == "LENGTH")
/* 1574 */             { usingFunctionName(str); }
/* 1575 */             else if (str == "LOCATE")
/*      */             
/*      */             { 
/*      */               
/* 1579 */               StringBuffer stringBuffer1 = this.oracle_sql;
/* 1580 */               this.oracle_sql = new StringBuffer();
/* 1581 */               handleODBC(ParseMode.LOCATE_1);
/* 1582 */               StringBuffer stringBuffer2 = this.oracle_sql;
/* 1583 */               this.oracle_sql = stringBuffer1;
/* 1584 */               this.oracle_sql.append("INSTR(");
/* 1585 */               handleODBC(ParseMode.LOCATE_2);
/* 1586 */               this.oracle_sql.append(',');
/* 1587 */               this.oracle_sql.append(stringBuffer2);
/* 1588 */               this.oracle_sql.append(')');
/* 1589 */               handleODBC(ParseMode.SCALAR); }
/*      */             
/* 1591 */             else if (str == "LTRIM")
/* 1592 */             { usingFunctionName(str);
/*      */               
/*      */                }
/*      */             
/* 1596 */             else if (str == "OCTET_LENGTH")
/* 1597 */             { usingFunctionName("LENGTHB"); }
/* 1598 */             else { if (str == "POSITION") {
/*      */                 
/* 1600 */                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1601 */                 sQLException.fillInStackTrace();
/* 1602 */                 throw sQLException;
/*      */               } 
/*      */               
/* 1605 */               if (str == "REPEAT") {
/*      */                 
/* 1607 */                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1608 */                 sQLException.fillInStackTrace();
/* 1609 */                 throw sQLException;
/*      */               } 
/* 1611 */               if (str == "REPLACE")
/* 1612 */               { usingFunctionName(str); }
/* 1613 */               else { if (str == "RIGHT") {
/*      */                   
/* 1615 */                   SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1616 */                   sQLException.fillInStackTrace();
/* 1617 */                   throw sQLException;
/*      */                 } 
/* 1619 */                 if (str == "RTRIM")
/* 1620 */                 { usingFunctionName(str); }
/* 1621 */                 else if (str == "SOUNDEX")
/* 1622 */                 { usingFunctionName(str); }
/* 1623 */                 else { if (str == "SPACE") {
/*      */                     
/* 1625 */                     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1626 */                     sQLException.fillInStackTrace();
/* 1627 */                     throw sQLException;
/*      */                   } 
/* 1629 */                   if (str == "SUBSTRING")
/* 1630 */                   { usingFunctionName("SUBSTR"); }
/* 1631 */                   else if (str == "UCASE")
/* 1632 */                   { usingFunctionName("UPPER");
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*      */                      }
/*      */                   
/* 1639 */                   else if (str == "CURRENT_DATE")
/* 1640 */                   { replacingFunctionPrefix("(CURRENT_DATE"); }
/* 1641 */                   else { if (str == "CURRENT_TIME") {
/*      */                       
/* 1643 */                       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1644 */                       sQLException.fillInStackTrace();
/* 1645 */                       throw sQLException;
/*      */                     } 
/* 1647 */                     if (str == "CURRENT_TIMESTAMP")
/* 1648 */                     { replacingFunctionPrefix("(CURRENT_TIMESTAMP"); }
/*      */                     
/* 1650 */                     else if (str == "CURDATE")
/* 1651 */                     { replacingFunctionPrefix("(CURRENT_DATE"); }
/* 1652 */                     else if (str == "CURTIME")
/* 1653 */                     { replacingFunctionPrefix("(CURRENT_TIMESTAMP"); }
/* 1654 */                     else { if (str == "DAYNAME") {
/*      */                         
/* 1656 */                         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1657 */                         sQLException.fillInStackTrace();
/* 1658 */                         throw sQLException;
/*      */                       } 
/* 1660 */                       if (str == "DAYOFMONTH")
/* 1661 */                       { replacingFunctionPrefix("EXTRACT ( DAY FROM "); }
/* 1662 */                       else { if (str == "DAYOFWEEK") {
/*      */                           
/* 1664 */                           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1665 */                           sQLException.fillInStackTrace();
/* 1666 */                           throw sQLException;
/*      */                         } 
/* 1668 */                         if (str == "DAYOFYEAR") {
/*      */                           
/* 1670 */                           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1671 */                           sQLException.fillInStackTrace();
/* 1672 */                           throw sQLException;
/*      */                         } 
/*      */ 
/*      */ 
/*      */                         
/* 1677 */                         if (str == "EXTRACT")
/* 1678 */                         { usingFunctionName("EXTRACT"); }
/*      */                         
/* 1680 */                         else if (str == "HOUR")
/* 1681 */                         { replacingFunctionPrefix("EXTRACT ( HOUR FROM "); }
/* 1682 */                         else if (str == "MINUTE")
/* 1683 */                         { replacingFunctionPrefix("EXTRACT ( MINUTE FROM "); }
/* 1684 */                         else if (str == "MONTH")
/* 1685 */                         { replacingFunctionPrefix("EXTRACT ( MONTH FROM "); }
/* 1686 */                         else { if (str == "MONTHNAME") {
/*      */                             
/* 1688 */                             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1689 */                             sQLException.fillInStackTrace();
/* 1690 */                             throw sQLException;
/*      */                           } 
/* 1692 */                           if (str == "NOW")
/* 1693 */                           { replacingFunctionPrefix("(CURRENT_TIMESTAMP"); }
/* 1694 */                           else { if (str == "QUARTER") {
/*      */                               
/* 1696 */                               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1697 */                               sQLException.fillInStackTrace();
/* 1698 */                               throw sQLException;
/*      */                             } 
/* 1700 */                             if (str == "SECOND")
/* 1701 */                             { replacingFunctionPrefix("EXTRACT ( SECOND FROM "); }
/* 1702 */                             else { if (str == "TIMESTAMPADD") {
/*      */                                 
/* 1704 */                                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1705 */                                 sQLException.fillInStackTrace();
/* 1706 */                                 throw sQLException;
/*      */                               } 
/* 1708 */                               if (str == "TIMESTAMPDIFF") {
/*      */                                 
/* 1710 */                                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1711 */                                 sQLException.fillInStackTrace();
/* 1712 */                                 throw sQLException;
/*      */                               } 
/* 1714 */                               if (str == "WEEK") {
/*      */                                 
/* 1716 */                                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1717 */                                 sQLException.fillInStackTrace();
/* 1718 */                                 throw sQLException;
/*      */                               } 
/* 1720 */                               if (str == "YEAR")
/* 1721 */                               { replacingFunctionPrefix("EXTRACT ( YEAR FROM "); }
/*      */                               else
/*      */                               
/* 1724 */                               { if (str == "DATABASE") {
/*      */                                   
/* 1726 */                                   SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1727 */                                   sQLException.fillInStackTrace();
/* 1728 */                                   throw sQLException;
/*      */                                 } 
/* 1730 */                                 if (str == "IFNULL")
/* 1731 */                                 { usingFunctionName("NVL"); }
/* 1732 */                                 else if (str == "USER")
/* 1733 */                                 { replacingFunctionPrefix("(USER"); }
/*      */                                 else
/*      */                                 
/* 1736 */                                 { if (str == "CONVERT") {
/*      */ 
/*      */                                     
/* 1739 */                                     SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1740 */                                     sQLException1.fillInStackTrace();
/* 1741 */                                     throw sQLException1;
/*      */                                   } 
/*      */ 
/*      */ 
/*      */ 
/*      */                                   
/* 1747 */                                   SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1748 */                                   sQLException.fillInStackTrace();
/* 1749 */                                   throw sQLException; }  }  }  }  }  }  }  }
/*      */                    }
/*      */                  }
/*      */                }
/*      */              }
/*      */            }
/*      */          }
/*      */        }
/* 1757 */      } void usingFunctionName(String paramString) throws SQLException { this.oracle_sql.append(paramString);
/* 1758 */     skipSpace();
/* 1759 */     handleODBC(ParseMode.SCALAR); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void replacingFunctionPrefix(String paramString) throws SQLException {
/* 1766 */     skipSpace();
/*      */ 
/*      */     
/* 1769 */     if (this.i < this.length && (this.c = this.odbc_sql.charAt(this.i)) == '(') {
/* 1770 */       this.i++;
/*      */     } else {
/*      */       
/* 1773 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33);
/* 1774 */       sQLException.fillInStackTrace();
/* 1775 */       throw sQLException;
/*      */     } 
/*      */     
/* 1778 */     this.oracle_sql.append(paramString);
/* 1779 */     skipSpace();
/* 1780 */     handleODBC(ParseMode.SCALAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleOuterJoin() throws SQLException {
/* 1787 */     this.oracle_sql.append(" ( ");
/* 1788 */     skipSpace();
/* 1789 */     handleODBC(ParseMode.SCALAR);
/* 1790 */     this.oracle_sql.append(" ) ");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String nextArgument() {
/* 1797 */     String str = ":" + this.current_argument;
/*      */     
/* 1799 */     this.current_argument++;
/*      */     
/* 1801 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void appendChar(StringBuffer paramStringBuffer, char paramChar) {
/* 1808 */     if (paramChar == '?') {
/* 1809 */       paramStringBuffer.append(nextArgument());
/*      */     } else {
/* 1811 */       paramStringBuffer.append(paramChar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void skipSpace() {
/* 1818 */     while (this.i < this.length && (this.c = this.odbc_sql.charAt(this.i)) == ' ') {
/* 1819 */       this.i++;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String generateParameterName() {
/*      */     String str;
/* 1830 */     if (this.parameterCount == 0 || this.parameterList == null)
/*      */     {
/* 1832 */       return "rowid" + this.paramSuffix++;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     label13: while (true) {
/* 1838 */       str = "rowid" + this.paramSuffix++;
/* 1839 */       for (byte b = 0; b < this.parameterList.length; b++)
/*      */       
/* 1841 */       { if (str.equals(this.parameterList[b]))
/*      */           continue label13;  }  break;
/* 1843 */     }  return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isValidPlsqlWarning(String paramString) throws SQLException {
/* 1863 */     return paramString.matches("('\\s*([a-zA-Z0-9:,\\(\\)\\s])*')\\s*(,\\s*'([a-zA-Z0-9:,\\(\\)\\s])*')*");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidObjectName(String paramString) throws SQLException {
/* 1881 */     if (paramString.matches("([a-zA-Z]{1}\\w*(\\$|\\#)*\\w*)|(\".*)"))
/*      */     {
/* 1883 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1890 */     char[] arrayOfChar = paramString.toCharArray();
/* 1891 */     int i = arrayOfChar.length;
/*      */ 
/*      */     
/* 1894 */     if (!Character.isLetter(arrayOfChar[0]))
/*      */     {
/* 1896 */       return false;
/*      */     }
/*      */     
/* 1899 */     for (byte b = 1; b < i; b++) {
/*      */       
/* 1901 */       if (!Character.isLetterOrDigit(arrayOfChar[b]) && arrayOfChar[b] != '$' && arrayOfChar[b] != '#' && arrayOfChar[b] != '_')
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1906 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 1910 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] paramArrayOfString) {
/*      */     String[] arrayOfString;
/* 1935 */     if (paramArrayOfString.length < 2) {
/* 1936 */       System.err.println("ERROR: incorrect usage. OracleSql (-transition <file> | <process_escapes> <convert_nchars> { <sql> } )");
/*      */       return;
/*      */     } 
/* 1939 */     if (paramArrayOfString[0].equals("-dump")) {
/* 1940 */       dumpTransitionMatrix(paramArrayOfString[1]);
/*      */       return;
/*      */     } 
/* 1943 */     boolean bool1 = paramArrayOfString[0].equals("true");
/* 1944 */     boolean bool2 = paramArrayOfString[1].equals("true");
/*      */ 
/*      */     
/* 1947 */     if (paramArrayOfString.length > 2) {
/* 1948 */       arrayOfString = new String[paramArrayOfString.length - 2];
/* 1949 */       System.arraycopy(paramArrayOfString, 2, arrayOfString, 0, arrayOfString.length);
/*      */     } else {
/*      */       
/* 1952 */       arrayOfString = new String[] { "select ? from dual", "insert into dual values (?)", "delete from dual", "update dual set dummy = ?", "merge tab into dual", " select ? from dual where ? = ?", "select ?from dual where?=?for update", "select '?', n'?', q'???', q'{?}', q'{cat's}' from dual", "select'?',n'?',q'???',q'{?}',q'{cat's}'from dual", "select--line\n? from dual", "select --line\n? from dual", "--line\nselect ? from dual", " --line\nselect ? from dual", "--line\n select ? from dual", "begin proc4in4out (:x1, :x2, :x3, :x4); end;", "{CALL tkpjpn01(:pin, :pinout, :pout)}", "select :NumberBindVar as the_number from dual", "select {fn locate(bob(carol(),ted(alice,sue)), 'xfy')} from dual", "CREATE USER vijay6 IDENTIFIED BY \"vjay?\"", "ALTER SESSION SET TIME" };
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1980 */     for (String str : arrayOfString) {
/*      */       try {
/* 1982 */         System.out.println("\n\n-----------------------");
/* 1983 */         System.out.println(str);
/* 1984 */         System.out.println();
/* 1985 */         OracleSql oracleSql = new OracleSql(null);
/*      */         
/* 1987 */         oracleSql.initialize(str);
/* 1988 */         String str1 = oracleSql.getSql(bool1, bool2);
/*      */         
/* 1990 */         System.out.println(oracleSql.sqlKind + ", " + oracleSql.parameterCount);
/*      */         
/* 1992 */         String[] arrayOfString1 = oracleSql.getParameterList();
/*      */         
/* 1994 */         if (arrayOfString1 == EMPTY_LIST) {
/* 1995 */           System.out.println("parameterList is empty");
/*      */         } else {
/* 1997 */           for (byte b = 0; b < arrayOfString1.length; b++)
/* 1998 */             System.out.println("parameterList[" + b + "] = " + arrayOfString1[b]); 
/*      */         } 
/* 2000 */         if (oracleSql.lastNcharLiteralLocation == 2) { System.out.println("No NCHAR literals"); }
/*      */         else
/* 2002 */         { System.out.println("NCHAR Literals");
/* 2003 */           for (byte b = 1; b < oracleSql.lastNcharLiteralLocation - 1;)
/* 2004 */             System.out.println(str1.substring(oracleSql.ncharLiteralLocation[b++], oracleSql.ncharLiteralLocation[b++]));  }
/*      */         
/* 2006 */         System.out.println("Keywords");
/* 2007 */         if (oracleSql.selectEndIndex == -1) { System.out.println("no select"); }
/* 2008 */         else { System.out.println("'" + str1.substring(oracleSql.selectEndIndex - 6, oracleSql.selectEndIndex) + "'"); }
/* 2009 */          if (oracleSql.orderByStartIndex == -1) { System.out.println("no order by"); }
/* 2010 */         else { System.out.println("'" + str1.substring(oracleSql.orderByStartIndex, oracleSql.orderByEndIndex) + "'"); }
/* 2011 */          if (oracleSql.whereStartIndex == -1) { System.out.println("no where"); }
/* 2012 */         else { System.out.println("'" + str1.substring(oracleSql.whereStartIndex, oracleSql.whereEndIndex) + "'"); }
/* 2013 */          if (oracleSql.forUpdateStartIndex == -1) { System.out.println("no for update"); }
/* 2014 */         else { System.out.println("'" + str1.substring(oracleSql.forUpdateStartIndex, oracleSql.forUpdateEndIndex) + "'"); }
/*      */         
/* 2016 */         System.out.println("isPlsqlOrCall(): " + oracleSql.getSqlKind().isPlsqlOrCall());
/* 2017 */         System.out.println("isDML(): " + oracleSql.getSqlKind().isDML());
/* 2018 */         System.out.println("isSELECT(): " + oracleSql.getSqlKind().isSELECT());
/* 2019 */         System.out.println("isOTHER(): " + oracleSql.getSqlKind().isOTHER());
/* 2020 */         System.out.println("\"" + str1 + "\"");
/* 2021 */         System.out.println("\"" + oracleSql.getRevisedSql() + "\"");
/*      */       }
/* 2023 */       catch (Exception exception) {
/* 2024 */         System.out.println(exception);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static final void dumpTransitionMatrix(String paramString) {
/*      */     try {
/* 2031 */       PrintWriter printWriter = new PrintWriter(paramString);
/* 2032 */       printWriter.print(",");
/* 2033 */       for (byte b1 = 0; b1 < ''; ) { printWriter.print("'" + ((b1 < 32) ? ("0x" + Integer.toHexString(b1)) : Character.toString((char)b1)) + ((b1 < 127) ? "'," : "'")); b1++; }
/* 2034 */        printWriter.println();
/* 2035 */       int[][] arrayOfInt = OracleSqlReadOnly.TRANSITION;
/* 2036 */       String[] arrayOfString = OracleSqlReadOnly.PARSER_STATE_NAME;
/* 2037 */       for (byte b2 = 0; b2 < TRANSITION.length; b2++) {
/* 2038 */         printWriter.print(arrayOfString[b2] + ",");
/* 2039 */         for (byte b = 0; b < (arrayOfInt[b2]).length; ) { printWriter.print(arrayOfString[arrayOfInt[b2][b]] + ((b < 127) ? "," : "")); b++; }
/* 2040 */          printWriter.println();
/*      */       } 
/* 2042 */       printWriter.close();
/*      */     }
/* 2044 */     catch (Throwable throwable) {
/* 2045 */       System.err.println(throwable);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2062 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getReturnParameterCount() throws SQLException {
/* 2075 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/* 2076 */       computeBasicInfo(this.parameterSql);
/*      */     }
/* 2078 */     if (!this.sqlKind.isDML()) {
/* 2079 */       return -1;
/*      */     }
/* 2081 */     byte b = -1;
/* 2082 */     String str = getOriginalSql().toUpperCase();
/* 2083 */     int i = getSubstrPos(str, "RETURNING");
/*      */     
/* 2085 */     if (i >= 0) {
/*      */       
/* 2087 */       String str1 = str.substring(i);
/* 2088 */       int j = getSubstrPos(str1, "INTO");
/*      */       
/* 2090 */       if (j >= 0) {
/*      */         
/* 2092 */         char[] arrayOfChar = new char[str.length() - i];
/* 2093 */         str.getChars(i, str.length(), arrayOfChar, 0);
/*      */         
/* 2095 */         b = 0;
/* 2096 */         for (byte b1 = 0; b1 < arrayOfChar.length; b1++) {
/*      */ 
/*      */ 
/*      */           
/* 2100 */           switch (arrayOfChar[b1]) {
/*      */             
/*      */             case ':':
/*      */             case '?':
/* 2104 */               b++;
/*      */               break;
/*      */           } 
/*      */         
/*      */         } 
/*      */       } 
/*      */     } 
/* 2111 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getSubstrPos(String paramString1, String paramString2) throws SQLException {
/* 2118 */     int i = -1;
/* 2119 */     int j = paramString1.indexOf(paramString2);
/*      */     
/* 2121 */     if (j >= 1 && Character.isWhitespace(paramString1.charAt(j - 1))) {
/*      */ 
/*      */       
/* 2124 */       int k = j + paramString2.length();
/*      */       
/* 2126 */       if (k < paramString1.length() && Character.isWhitespace(paramString1.charAt(k)))
/*      */       {
/*      */         
/* 2129 */         i = j;
/*      */       }
/*      */     } 
/* 2132 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2138 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleSql.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */