/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NCLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClobAccessor
/*     */   extends Accessor
/*     */ {
/*     */   static final int maxLength = 4000;
/*     */   
/*     */   ClobAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  32 */     init(paramOracleStatement, 112, 112, paramShort, paramBoolean);
/*  33 */     initForDataAccess(paramInt2, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ClobAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  42 */     init(paramOracleStatement, 112, 112, paramShort, false);
/*  43 */     initForDescribe(112, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  45 */     initForDataAccess(0, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  53 */     if (paramInt1 != 0) {
/*  54 */       this.externalType = paramInt1;
/*     */     }
/*  56 */     this.internalTypeMaxLength = 4000;
/*     */     
/*  58 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*  59 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  61 */     this.byteLength = this.internalTypeMaxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/*  82 */     return getCLOB(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/*  99 */     return getCLOB(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 121 */     return (Datum)getCLOB(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CLOB getCLOB(int paramInt) throws SQLException {
/*     */     NCLOB nCLOB;
/* 139 */     CLOB cLOB = null;
/*     */     
/* 141 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 145 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 146 */       sQLException.fillInStackTrace();
/* 147 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 155 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 156 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*     */       
/* 158 */       byte[] arrayOfByte = new byte[s];
/*     */       
/* 160 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/*     */ 
/*     */       
/* 163 */       if (this.formOfUse == 1) {
/* 164 */         cLOB = new CLOB((OracleConnection)this.statement.connection, arrayOfByte, this.formOfUse);
/*     */       } else {
/*     */         
/* 167 */         nCLOB = new NCLOB((OracleConnection)this.statement.connection, arrayOfByte);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       if (this.lobPrefetchSizeForThisColumn != -1 && this.prefetchedLobSize != null) {
/*     */ 
/*     */ 
/*     */         
/* 178 */         nCLOB.setActivePrefetch(true);
/* 179 */         nCLOB.setLength(this.prefetchedLobSize[paramInt]);
/* 180 */         nCLOB.setChunkSize(this.prefetchedLobChunkSize[paramInt]);
/*     */ 
/*     */         
/* 183 */         if (this.prefetchedLobDataL != null && this.prefetchedLobDataL[paramInt] > 0) {
/*     */           
/* 185 */           initializeClobForPrefetch(paramInt, (CLOB)nCLOB);
/*     */         } else {
/*     */           
/* 188 */           nCLOB.setPrefetchedData(null);
/*     */         } 
/*     */       } 
/*     */     } 
/* 192 */     return (CLOB)nCLOB;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   NCLOB getNCLOB(int paramInt) throws SQLException {
/* 198 */     if (this.formOfUse != 2) {
/*     */       
/* 200 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
/* 201 */       sQLException.fillInStackTrace();
/* 202 */       throw sQLException;
/*     */     } 
/*     */     
/* 205 */     return (NCLOB)getCLOB(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void initializeClobForPrefetch(int paramInt, CLOB paramCLOB) throws SQLException {
/* 211 */     paramCLOB.setPrefetchedData(this.prefetchedLobCharData[paramInt]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 226 */     CLOB cLOB = getCLOB(paramInt);
/*     */     
/* 228 */     if (cLOB == null) {
/* 229 */       return null;
/*     */     }
/* 231 */     return cLOB.getAsciiStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 247 */     CLOB cLOB = getCLOB(paramInt);
/*     */     
/* 249 */     if (cLOB == null) {
/* 250 */       return null;
/*     */     }
/* 252 */     return cLOB.getCharacterStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 268 */     CLOB cLOB = getCLOB(paramInt);
/*     */     
/* 270 */     if (cLOB == null) {
/* 271 */       return null;
/*     */     }
/* 273 */     return cLOB.getAsciiStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 290 */     CLOB cLOB = getCLOB(paramInt);
/*     */     
/* 292 */     if (cLOB == null) {
/* 293 */       return null;
/*     */     }
/* 295 */     Reader reader = cLOB.getCharacterStream();
/* 296 */     int i = cLOB.getBufferSize();
/* 297 */     int j = 0;
/* 298 */     StringWriter stringWriter = new StringWriter(i);
/* 299 */     char[] arrayOfChar = new char[i];
/*     */ 
/*     */     
/*     */     try {
/* 303 */       while ((j = reader.read(arrayOfChar)) != -1)
/*     */       {
/* 305 */         stringWriter.write(arrayOfChar, 0, j);
/*     */       }
/*     */     }
/* 308 */     catch (IOException iOException) {
/*     */ 
/*     */       
/* 311 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 312 */       sQLException.fillInStackTrace();
/* 313 */       throw sQLException;
/*     */     
/*     */     }
/* 316 */     catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*     */ 
/*     */       
/* 319 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
/* 320 */       sQLException.fillInStackTrace();
/* 321 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 325 */     if (cLOB.isTemporary()) this.statement.addToTempLobsToFree(cLOB); 
/* 326 */     return stringWriter.getBuffer().substring(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] privateGetBytes(int paramInt) throws SQLException {
/* 340 */     return super.getBytes(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 358 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 359 */     sQLException.fillInStackTrace();
/* 360 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long checksum(long paramLong, int paramInt) throws SQLException {
/* 368 */     unimpl("checksum");
/* 369 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 374 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\ClobAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */