/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import javax.sql.XAConnection;
/*      */ import javax.transaction.xa.XAException;
/*      */ import javax.transaction.xa.XAResource;
/*      */ import javax.transaction.xa.Xid;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.xa.OracleXAConnection;
/*      */ import oracle.jdbc.xa.OracleXAException;
/*      */ import oracle.jdbc.xa.OracleXid;
/*      */ import oracle.jdbc.xa.client.OracleXADataSource;
/*      */ import oracle.jdbc.xa.client.OracleXAResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CXAResource
/*      */   extends OracleXAResource
/*      */ {
/*      */   T4CConnection physicalConn;
/*   37 */   int[] applicationValueArr = new int[1];
/*      */   
/*      */   boolean isTransLoose = false;
/*      */   
/*      */   byte[] context;
/*      */   
/*      */   int errorNumber;
/*      */   
/*      */   private String password;
/*      */   
/*      */   T4CXAResource(T4CConnection paramT4CConnection, OracleXAConnection paramOracleXAConnection, boolean paramBoolean) throws XAException {
/*   48 */     super((Connection)paramT4CConnection, paramOracleXAConnection);
/*      */     
/*   50 */     this.physicalConn = paramT4CConnection;
/*   51 */     this.isTransLoose = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doStart(Xid paramXid, int paramInt) throws XAException {
/*   59 */     synchronized (this.physicalConn) {
/*      */       
/*   61 */       int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   85 */       if (this.isTransLoose) {
/*   86 */         paramInt |= 0x10000;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   93 */       int j = paramInt & 0x8200000;
/*      */ 
/*      */       
/*   96 */       if (j == 134217728 && OracleXid.isLocalTransaction(paramXid)) {
/*   97 */         return 0;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  136 */       this.applicationValueArr[0] = 0;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*      */         try {
/*  142 */           T4CTTIOtxse t4CTTIOtxse = this.physicalConn.otxse;
/*  143 */           byte[] arrayOfByte1 = null;
/*  144 */           byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
/*  145 */           byte[] arrayOfByte3 = paramXid.getBranchQualifier();
/*      */           
/*  147 */           int k = 0;
/*  148 */           int m = 0;
/*      */           
/*  150 */           if (arrayOfByte2 != null && arrayOfByte3 != null) {
/*      */             
/*  152 */             k = Math.min(arrayOfByte2.length, 64);
/*  153 */             m = Math.min(arrayOfByte3.length, 64);
/*  154 */             arrayOfByte1 = new byte[128];
/*      */             
/*  156 */             System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, k);
/*  157 */             System.arraycopy(arrayOfByte3, 0, arrayOfByte1, k, m);
/*      */           } 
/*      */           
/*  160 */           int n = 0;
/*      */ 
/*      */           
/*  163 */           if ((paramInt & 0x200000) != 0 || (paramInt & 0x8000000) != 0) {
/*  164 */             n |= 0x4;
/*      */           } else {
/*  166 */             n |= 0x1;
/*      */           } 
/*  168 */           if ((paramInt & 0x100) != 0) {
/*  169 */             n |= 0x100;
/*      */           }
/*  171 */           if ((paramInt & 0x200) != 0) {
/*  172 */             n |= 0x200;
/*      */           }
/*  174 */           if ((paramInt & 0x400) != 0) {
/*  175 */             n |= 0x400;
/*      */           }
/*  177 */           if ((paramInt & 0x10000) != 0) {
/*  178 */             n |= 0x10000;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  184 */           this.physicalConn.needLine();
/*  185 */           this.physicalConn.sendPiggyBackedMessages();
/*  186 */           t4CTTIOtxse.doOTXSE(1, null, arrayOfByte1, paramXid.getFormatId(), k, m, this.timeout, n, this.applicationValueArr);
/*      */ 
/*      */ 
/*      */           
/*  190 */           this.applicationValueArr[0] = t4CTTIOtxse.getApplicationValue();
/*  191 */           byte[] arrayOfByte4 = t4CTTIOtxse.getContext();
/*      */ 
/*      */ 
/*      */           
/*  195 */           if (arrayOfByte4 != null) {
/*  196 */             this.context = arrayOfByte4;
/*      */           }
/*  198 */           i = 0;
/*      */         }
/*  200 */         catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  207 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  208 */           sQLException.fillInStackTrace();
/*  209 */           throw sQLException;
/*      */         }
/*      */       
/*      */       }
/*  213 */       catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */         
/*  217 */         i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */         
/*  221 */         if (i == 0) {
/*  222 */           throw new XAException(-6);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  262 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doEnd(Xid paramXid, int paramInt, boolean paramBoolean) throws XAException {
/*  271 */     synchronized (this.physicalConn) {
/*      */       
/*  273 */       int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  296 */         T4CTTIOtxse t4CTTIOtxse = this.physicalConn.otxse;
/*  297 */         byte[] arrayOfByte1 = null;
/*  298 */         byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
/*  299 */         byte[] arrayOfByte3 = paramXid.getBranchQualifier();
/*      */         
/*  301 */         int j = 0;
/*  302 */         int k = 0;
/*      */         
/*  304 */         if (arrayOfByte2 != null && arrayOfByte3 != null) {
/*      */           
/*  306 */           j = Math.min(arrayOfByte2.length, 64);
/*  307 */           k = Math.min(arrayOfByte3.length, 64);
/*  308 */           arrayOfByte1 = new byte[128];
/*      */           
/*  310 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, j);
/*  311 */           System.arraycopy(arrayOfByte3, 0, arrayOfByte1, j, k);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  316 */         if (this.context == null) {
/*      */           
/*  318 */           i = doStart(paramXid, 134217728);
/*      */           
/*  320 */           if (i != 0) {
/*  321 */             return i;
/*      */           }
/*      */         } 
/*  324 */         byte[] arrayOfByte4 = this.context;
/*  325 */         int m = 0;
/*  326 */         if ((paramInt & 0x2) == 2) {
/*      */           
/*  328 */           m = 1048576;
/*  329 */         } else if ((paramInt & 0x2000000) == 33554432 && (paramInt & 0x100000) != 1048576) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  342 */           m = 1048576;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  348 */         this.applicationValueArr[0] = this.applicationValueArr[0] >> 16;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  356 */         this.physicalConn.needLine();
/*  357 */         this.physicalConn.sendPiggyBackedMessages();
/*  358 */         t4CTTIOtxse.doOTXSE(2, arrayOfByte4, arrayOfByte1, paramXid.getFormatId(), j, k, this.timeout, m, this.applicationValueArr);
/*      */ 
/*      */ 
/*      */         
/*  362 */         this.applicationValueArr[0] = t4CTTIOtxse.getApplicationValue();
/*  363 */         byte[] arrayOfByte5 = t4CTTIOtxse.getContext();
/*      */ 
/*      */         
/*  366 */         if (arrayOfByte5 != null) {
/*  367 */           this.context = arrayOfByte5;
/*      */         }
/*  369 */         i = 0;
/*      */       }
/*  371 */       catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  378 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  379 */         sQLException.fillInStackTrace();
/*  380 */         throw sQLException;
/*      */ 
/*      */       
/*      */       }
/*  384 */       catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */         
/*  388 */         i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */         
/*  392 */         if (i == 0) {
/*  393 */           throw new XAException(-6);
/*      */         }
/*      */       } 
/*  396 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doCommit(Xid paramXid, boolean paramBoolean) throws SQLException, XAException {
/*  415 */     synchronized (this.physicalConn) {
/*      */ 
/*      */       
/*  418 */       byte b = paramBoolean ? 4 : 2;
/*      */ 
/*      */       
/*      */       try {
/*  422 */         int i = doTransaction(paramXid, 1, b);
/*      */ 
/*      */         
/*  425 */         if (!paramBoolean || (i != 2 && i != 4))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  431 */           if (paramBoolean || i != 5) {
/*      */ 
/*      */ 
/*      */             
/*  435 */             if (i == 8) {
/*  436 */               throw new XAException(106);
/*      */             }
/*  438 */             throw new XAException(-6);
/*      */           }  } 
/*  440 */       } catch (SQLException sQLException) {
/*      */         
/*  442 */         int i = sQLException.getErrorCode();
/*  443 */         if (i == 24756) {
/*      */ 
/*      */ 
/*      */           
/*  447 */           kputxrec(paramXid, 1, this.timeout + 120, sQLException);
/*      */         }
/*  449 */         else if (i == 24780) {
/*      */ 
/*      */ 
/*      */           
/*  453 */           OracleXADataSource oracleXADataSource = null;
/*  454 */           XAConnection xAConnection = null;
/*      */ 
/*      */           
/*      */           try {
/*  458 */             oracleXADataSource = new OracleXADataSource();
/*      */             
/*  460 */             oracleXADataSource.setURL(this.physicalConn.url);
/*  461 */             oracleXADataSource.setUser(this.physicalConn.userName);
/*  462 */             this.physicalConn.getPasswordInternal(this);
/*  463 */             oracleXADataSource.setPassword(this.password);
/*      */             
/*  465 */             xAConnection = oracleXADataSource.getXAConnection();
/*      */             
/*  467 */             XAResource xAResource = xAConnection.getXAResource();
/*      */             
/*  469 */             xAResource.commit(paramXid, paramBoolean);
/*      */           }
/*  471 */           catch (SQLException sQLException1) {
/*      */ 
/*      */ 
/*      */             
/*  475 */             XAException xAException = new XAException(-6);
/*  476 */             xAException.initCause(sQLException1);
/*  477 */             throw xAException;
/*      */           } finally {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/*  483 */               if (xAConnection != null) {
/*  484 */                 xAConnection.close();
/*      */               }
/*  486 */               if (oracleXADataSource != null) {
/*  487 */                 oracleXADataSource.close();
/*      */               }
/*  489 */             } catch (Exception exception) {}
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  495 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doPrepare(Xid paramXid) throws XAException, SQLException {
/*  506 */     synchronized (this.physicalConn) {
/*      */       
/*  508 */       byte b = -1;
/*      */       try {
/*  510 */         int i = doTransaction(paramXid, 3, 0);
/*      */ 
/*      */         
/*  513 */         if (i == 8)
/*      */         {
/*      */           
/*  516 */           throw new XAException(106);
/*      */         }
/*  518 */         if (i == 4) {
/*      */ 
/*      */           
/*  521 */           b = 3;
/*      */         }
/*  523 */         else if (i == 1) {
/*      */ 
/*      */           
/*  526 */           b = 0;
/*      */         } else {
/*  528 */           if (i == 3)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  533 */             throw new XAException(100);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  538 */           throw new XAException(-6);
/*      */         }
/*      */       
/*  541 */       } catch (SQLException sQLException) {
/*      */         
/*  543 */         int i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  549 */         if (i == 25351) {
/*      */ 
/*      */           
/*  552 */           XAException xAException = new XAException(-6);
/*  553 */           xAException.initCause(sQLException);
/*  554 */           throw xAException;
/*      */         } 
/*  556 */         throw sQLException;
/*      */       } 
/*  558 */       return b;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doForget(Xid paramXid) throws XAException, SQLException {
/*  567 */     synchronized (this.physicalConn) {
/*      */       
/*  569 */       boolean bool = false;
/*      */       
/*  571 */       if (OracleXid.isLocalTransaction(paramXid)) {
/*  572 */         return 24771;
/*      */       }
/*      */ 
/*      */       
/*  576 */       int i = doStart(paramXid, 134217728);
/*      */       
/*  578 */       if (i != 24756) {
/*      */ 
/*      */ 
/*      */         
/*  582 */         if (i == 0) {
/*      */           
/*      */           try {
/*      */ 
/*      */ 
/*      */             
/*  588 */             doEnd(paramXid, 0, false);
/*      */           }
/*  590 */           catch (Exception exception) {}
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  596 */         if (i == 0 || i == 2079 || i == 24754 || i == 24761 || i == 24774 || i == 24776 || i == 25351)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  603 */           return 24769; } 
/*  604 */         if (i == 24752) {
/*  605 */           return 24771;
/*      */         }
/*  607 */         return i;
/*      */       } 
/*      */       
/*  610 */       kputxrec(paramXid, 4, 1, null);
/*      */       
/*  612 */       return bool;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRollback(Xid paramXid) throws XAException, SQLException {
/*  620 */     synchronized (this.physicalConn) {
/*      */ 
/*      */       
/*      */       try {
/*  624 */         int i = doTransaction(paramXid, 2, 3);
/*      */ 
/*      */         
/*  627 */         if (i == 8)
/*  628 */           throw new XAException(106); 
/*  629 */         if (i != 3)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  634 */           throw new XAException(-6);
/*      */         }
/*  636 */       } catch (SQLException sQLException) {
/*      */         
/*  638 */         int i = sQLException.getErrorCode();
/*      */ 
/*      */         
/*  641 */         if (i == 24756) {
/*      */ 
/*      */ 
/*      */           
/*  645 */           kputxrec(paramXid, 2, this.timeout + 120, sQLException);
/*      */         }
/*  647 */         else if (i == 24780) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  652 */           OracleXADataSource oracleXADataSource = null;
/*  653 */           XAConnection xAConnection = null;
/*      */ 
/*      */           
/*      */           try {
/*  657 */             oracleXADataSource = new OracleXADataSource();
/*      */             
/*  659 */             oracleXADataSource.setURL(this.physicalConn.url);
/*  660 */             oracleXADataSource.setUser(this.physicalConn.userName);
/*  661 */             this.physicalConn.getPasswordInternal(this);
/*  662 */             oracleXADataSource.setPassword(this.password);
/*      */             
/*  664 */             xAConnection = oracleXADataSource.getXAConnection();
/*      */             
/*  666 */             XAResource xAResource = xAConnection.getXAResource();
/*      */             
/*  668 */             xAResource.rollback(paramXid);
/*      */           
/*      */           }
/*  671 */           catch (SQLException sQLException1) {
/*      */ 
/*      */             
/*  674 */             XAException xAException = new XAException(-6);
/*  675 */             xAException.initCause(sQLException1);
/*  676 */             throw xAException;
/*      */           } finally {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/*  682 */               if (xAConnection != null) {
/*  683 */                 xAConnection.close();
/*      */               }
/*  685 */               if (oracleXADataSource != null) {
/*  686 */                 oracleXADataSource.close();
/*      */               }
/*  688 */             } catch (Exception exception) {}
/*      */           }
/*      */         
/*  691 */         } else if (i != 25402) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  697 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int doTransaction(Xid paramXid, int paramInt1, int paramInt2) throws SQLException {
/*  718 */     int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  724 */       T4CTTIOtxen t4CTTIOtxen = this.physicalConn.otxen;
/*  725 */       byte[] arrayOfByte1 = null;
/*  726 */       byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
/*  727 */       byte[] arrayOfByte3 = paramXid.getBranchQualifier();
/*      */       
/*  729 */       int j = 0;
/*  730 */       int k = 0;
/*      */       
/*  732 */       if (arrayOfByte2 != null && arrayOfByte3 != null) {
/*      */         
/*  734 */         j = Math.min(arrayOfByte2.length, 64);
/*  735 */         k = Math.min(arrayOfByte3.length, 64);
/*  736 */         arrayOfByte1 = new byte[128];
/*      */         
/*  738 */         System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, j);
/*  739 */         System.arraycopy(arrayOfByte3, 0, arrayOfByte1, j, k);
/*      */       } 
/*      */       
/*  742 */       byte[] arrayOfByte4 = this.context;
/*      */       
/*  744 */       this.physicalConn.needLine();
/*  745 */       this.physicalConn.sendPiggyBackedMessages();
/*  746 */       t4CTTIOtxen.doOTXEN(paramInt1, arrayOfByte4, arrayOfByte1, paramXid.getFormatId(), j, k, this.timeout, paramInt2, 0);
/*      */       
/*  748 */       i = t4CTTIOtxen.getOutStateFromServer();
/*      */ 
/*      */     
/*      */     }
/*  752 */     catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  761 */       this.physicalConn.handleIOException(iOException);
/*      */       
/*  763 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  764 */       sQLException.fillInStackTrace();
/*  765 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  769 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void kputxrec(Xid paramXid, int paramInt1, int paramInt2, SQLException paramSQLException) throws XAException, SQLException {
/*      */     byte b1, b2;
/*  786 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 1:
/*  790 */         b1 = 3;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 4:
/*  795 */         b1 = 2;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  800 */         b1 = 0;
/*      */         break;
/*      */     } 
/*      */     
/*  804 */     int i = 0;
/*      */ 
/*      */     
/*  807 */     while (paramInt2-- > 0) {
/*      */       
/*  809 */       i = doTransaction(paramXid, 5, b1);
/*      */       
/*  811 */       if (i == 7) {
/*      */         
/*      */         try {
/*      */ 
/*      */           
/*  816 */           Thread.sleep(1000L);
/*      */         }
/*  818 */         catch (Exception exception) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  828 */     if (i == 7)
/*      */     {
/*      */ 
/*      */       
/*  832 */       throw new XAException(-6);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  841 */     byte b = -1;
/*      */     
/*  843 */     switch (i) {
/*      */ 
/*      */       
/*      */       case 3:
/*  847 */         if (paramInt1 == 1) {
/*  848 */           byte b3 = 7;
/*      */           
/*      */           break;
/*      */         } 
/*  852 */         b2 = 8;
/*  853 */         b = -3;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/*  859 */         if (paramInt1 == 4) {
/*      */           
/*  861 */           b2 = 8;
/*  862 */           b = -3;
/*      */           
/*      */           break;
/*      */         } 
/*  866 */         b2 = 7;
/*  867 */         if (paramInt1 == 1) {
/*  868 */           b = -4;
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  874 */         if (paramInt1 == 4) {
/*      */           
/*  876 */           b2 = 8;
/*      */ 
/*      */           
/*  879 */           b = -6;
/*      */           break;
/*      */         } 
/*      */       case 5:
/*  883 */         if (paramInt1 == 4) {
/*      */           
/*  885 */           b2 = 7;
/*      */           
/*      */           break;
/*      */         } 
/*  889 */         b = 7;
/*  890 */         b2 = 8;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 4:
/*  895 */         if (paramInt1 == 4) {
/*      */           
/*  897 */           b2 = 7;
/*      */           
/*      */           break;
/*      */         } 
/*  901 */         b = 6;
/*  902 */         b2 = 8;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 6:
/*  907 */         if (paramInt1 == 4) {
/*      */           
/*  909 */           b2 = 7;
/*      */           
/*      */           break;
/*      */         } 
/*  913 */         b = 5;
/*  914 */         b2 = 8;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  920 */         b = -3;
/*  921 */         b2 = 8;
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  926 */     T4CTTIk2rpc t4CTTIk2rpc = this.physicalConn.k2rpc;
/*      */ 
/*      */     
/*      */     try {
/*  930 */       t4CTTIk2rpc.doOK2RPC(3, b2);
/*      */     }
/*  932 */     catch (IOException iOException) {
/*      */ 
/*      */       
/*  935 */       XAException xAException = new XAException(-7);
/*  936 */       xAException.initCause(iOException);
/*  937 */       throw xAException;
/*      */     }
/*  939 */     catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  942 */       XAException xAException = new XAException(-6);
/*  943 */       xAException.initCause(sQLException);
/*  944 */       throw xAException;
/*      */     } 
/*      */     
/*  947 */     if (b != -1) {
/*      */ 
/*      */ 
/*      */       
/*  951 */       OracleXAException oracleXAException = null;
/*  952 */       if (paramSQLException != null) {
/*      */         
/*  954 */         oracleXAException = new OracleXAException(paramSQLException.getErrorCode(), b);
/*  955 */         oracleXAException.initCause(paramSQLException);
/*      */       } else {
/*      */         
/*  958 */         oracleXAException = new OracleXAException(0, b);
/*      */       } 
/*  960 */       throw oracleXAException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setPasswordInternal(String paramString) {
/*  969 */     this.password = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*  983 */     return this.physicalConn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1060 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CXAResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */