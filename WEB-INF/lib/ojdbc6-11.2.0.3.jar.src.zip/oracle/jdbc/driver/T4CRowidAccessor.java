/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CRowidAccessor
/*      */   extends RowidAccessor
/*      */ {
/*      */   T4CMAREngine mare;
/*      */   static final int maxLength = 128;
/*      */   final int[] meta;
/*      */   static final int KGRD_EXTENDED_OBJECT = 6;
/*      */   static final int KGRD_EXTENDED_BLOCK = 6;
/*      */   static final int KGRD_EXTENDED_FILE = 3;
/*      */   static final int KGRD_EXTENDED_SLOT = 3;
/*      */   static final int kd4_ubridtype_physical = 1;
/*      */   static final int kd4_ubridtype_logical = 2;
/*      */   static final int kd4_ubridtype_remote = 3;
/*      */   static final int kd4_ubridtype_exttab = 4;
/*      */   static final int kd4_ubridtype_future2 = 5;
/*      */   static final int kd4_ubridtype_max = 5;
/*      */   static final int kd4_ubridlen_typeind = 1;
/*      */   
/*      */   T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*   40 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   95 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; this.defineType = 104; } T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*      */     this.mare = paramT4CMAREngine;
/*      */     this.definedColumnType = paramInt7;
/*      */     this.definedColumnSize = paramInt8;
/*      */     this.defineType = 104; }
/*      */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*      */       this.mare.unmarshalUB2();
/*      */       this.mare.unmarshalUB2();
/*      */     } else if (this.statement.connection.versionNumber < 9200) {
/*      */       this.mare.unmarshalSB2();
/*      */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*      */         this.mare.unmarshalSB2(); 
/*      */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*      */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*      */     }  } boolean unmarshalOneRow() throws SQLException, IOException {
/*  110 */     if (this.isUseLess) {
/*      */       
/*  112 */       this.lastRowProcessed++;
/*      */       
/*  114 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  119 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  121 */       short s = this.mare.unmarshalUB1();
/*  122 */       long l1 = 0L;
/*  123 */       int m = 0;
/*  124 */       short s1 = 0;
/*  125 */       long l2 = 0L;
/*  126 */       int n = 0;
/*      */ 
/*      */ 
/*      */       
/*  130 */       if (s > 0) {
/*      */         
/*  132 */         l1 = this.mare.unmarshalUB4();
/*  133 */         m = this.mare.unmarshalUB2();
/*  134 */         s1 = this.mare.unmarshalUB1();
/*  135 */         l2 = this.mare.unmarshalUB4();
/*  136 */         n = this.mare.unmarshalUB2();
/*      */       } 
/*      */       
/*  139 */       processIndicator(this.meta[0]);
/*      */       
/*  141 */       this.lastRowProcessed++;
/*      */       
/*  143 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  147 */     int i = this.indicatorIndex + this.lastRowProcessed;
/*  148 */     int j = this.lengthIndex + this.lastRowProcessed;
/*      */     
/*  150 */     if (this.isNullByDescribe) {
/*      */       
/*  152 */       this.rowSpaceIndicator[i] = -1;
/*  153 */       this.rowSpaceIndicator[j] = 0;
/*  154 */       this.lastRowProcessed++;
/*      */       
/*  156 */       if (this.statement.connection.versionNumber < 9200) {
/*  157 */         processIndicator(0);
/*      */       }
/*  159 */       return false;
/*      */     } 
/*      */     
/*  162 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  167 */     if (this.describeType != 208) {
/*      */       
/*  169 */       short s = this.mare.unmarshalUB1();
/*  170 */       long l1 = 0L;
/*  171 */       int m = 0;
/*  172 */       short s1 = 0;
/*  173 */       long l2 = 0L;
/*  174 */       int n = 0;
/*      */ 
/*      */ 
/*      */       
/*  178 */       if (s > 0) {
/*      */         
/*  180 */         l1 = this.mare.unmarshalUB4();
/*  181 */         m = this.mare.unmarshalUB2();
/*  182 */         s1 = this.mare.unmarshalUB1();
/*  183 */         l2 = this.mare.unmarshalUB4();
/*  184 */         n = this.mare.unmarshalUB2();
/*      */       } 
/*      */ 
/*      */       
/*  188 */       if (l1 == 0L && m == 0 && s1 == 0 && l2 == 0L && n == 0) {
/*      */         
/*  190 */         this.meta[0] = 0;
/*      */       } else {
/*      */         
/*  193 */         long[] arrayOfLong = { l1, m, l2, n };
/*      */ 
/*      */ 
/*      */         
/*  197 */         byte[] arrayOfByte = rowidToString(arrayOfLong);
/*  198 */         int i1 = 18;
/*      */         
/*  200 */         if (this.byteLength - 2 < 18) {
/*  201 */           i1 = this.byteLength - 2;
/*      */         }
/*  203 */         System.arraycopy(arrayOfByte, 0, this.rowSpaceByte, k + 2, i1);
/*      */ 
/*      */         
/*  206 */         this.meta[0] = i1;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  211 */       this.meta[0] = (int)this.mare.unmarshalUB4(); if ((int)this.mare.unmarshalUB4() > 0) {
/*      */         
/*  213 */         byte[] arrayOfByte = new byte[this.meta[0]];
/*  214 */         this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/*  215 */         this.meta[0] = kgrdub2c(arrayOfByte, this.meta[0], 0, this.rowSpaceByte, k + 2);
/*      */       } 
/*      */     } 
/*      */     
/*  219 */     this.rowSpaceByte[k] = (byte)((this.meta[0] & 0xFF00) >> 8);
/*  220 */     this.rowSpaceByte[k + 1] = (byte)(this.meta[0] & 0xFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  228 */     processIndicator(this.meta[0]);
/*      */     
/*  230 */     if (this.meta[0] == 0) {
/*      */ 
/*      */ 
/*      */       
/*  234 */       this.rowSpaceIndicator[i] = -1;
/*  235 */       this.rowSpaceIndicator[j] = 0;
/*      */     }
/*      */     else {
/*      */       
/*  239 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  244 */       this.rowSpaceIndicator[i] = 0;
/*      */     } 
/*      */     
/*  247 */     this.lastRowProcessed++;
/*      */     
/*  249 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getString(int paramInt) throws SQLException {
/*  260 */     String str = null;
/*      */     
/*  262 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  264 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  265 */       sQLException.fillInStackTrace();
/*  266 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  271 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*  273 */       int i = this.columnIndex + this.byteLength * paramInt;
/*      */ 
/*      */ 
/*      */       
/*  277 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*      */       
/*  279 */       if (this.describeType != 208 || this.rowSpaceByte[i] == 1) {
/*      */ 
/*      */         
/*  282 */         str = new String(this.rowSpaceByte, i + 2, s);
/*      */         
/*  284 */         long[] arrayOfLong = stringToRowid(str.getBytes(), 0, str.length());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  290 */         str = new String(rowidToString(arrayOfLong));
/*      */       }
/*      */       else {
/*      */         
/*  294 */         str = new String(this.rowSpaceByte, i + 2, s);
/*      */       } 
/*      */     } 
/*      */     
/*  298 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt) throws SQLException {
/*  306 */     if (this.definedColumnType == 0) {
/*  307 */       return super.getObject(paramInt);
/*      */     }
/*      */     
/*  310 */     Object object = null;
/*      */     
/*  312 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  314 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  315 */       sQLException.fillInStackTrace();
/*  316 */       throw sQLException;
/*      */     } 
/*      */     
/*  319 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*  321 */       switch (this.definedColumnType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -15:
/*      */         case -9:
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/*  335 */           return getString(paramInt);
/*      */         
/*      */         case -8:
/*  338 */           return getROWID(paramInt);
/*      */       } 
/*      */ 
/*      */       
/*  342 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  343 */       sQLException.fillInStackTrace();
/*  344 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  349 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copyRow() throws SQLException, IOException {
/*      */     int i;
/*  362 */     if (this.lastRowProcessed == 0) {
/*  363 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*      */     } else {
/*  365 */       i = this.lastRowProcessed - 1;
/*      */     } 
/*      */     
/*  368 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*  369 */     int k = this.columnIndex + i * this.byteLength;
/*  370 */     int m = this.indicatorIndex + this.lastRowProcessed;
/*  371 */     int n = this.indicatorIndex + i;
/*  372 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/*  373 */     int i2 = this.lengthIndex + i;
/*  374 */     short s = this.rowSpaceIndicator[i2];
/*  375 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*      */     
/*  377 */     int i4 = this.metaDataIndex + i * 1;
/*      */ 
/*      */ 
/*      */     
/*  381 */     this.rowSpaceIndicator[i1] = (short)s;
/*  382 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*      */ 
/*      */ 
/*      */     
/*  386 */     System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s + 2);
/*      */ 
/*      */ 
/*      */     
/*  390 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*      */ 
/*      */ 
/*      */     
/*  394 */     this.lastRowProcessed++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/*  407 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*      */     
/*  409 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*      */     
/*  411 */     int k = this.indicatorIndex + paramInt2 - 1;
/*  412 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/*  413 */     int n = this.lengthIndex + paramInt2 - 1;
/*  414 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/*  415 */     short s = paramArrayOfshort[i1];
/*      */     
/*  417 */     this.rowSpaceIndicator[n] = (short)s;
/*  418 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*      */ 
/*      */     
/*  421 */     if (s != 0)
/*      */     {
/*  423 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s + 2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] rowidToString(long[] paramArrayOflong) {
/*  437 */     long l1 = paramArrayOflong[0];
/*      */ 
/*      */     
/*  440 */     long l2 = paramArrayOflong[1];
/*      */ 
/*      */     
/*  443 */     long l3 = paramArrayOflong[2];
/*      */ 
/*      */     
/*  446 */     long l4 = paramArrayOflong[3];
/*      */     
/*  448 */     byte b = 18;
/*      */ 
/*      */ 
/*      */     
/*  452 */     byte[] arrayOfByte = new byte[b];
/*  453 */     int i = 0;
/*      */     
/*  455 */     i = kgrd42b(arrayOfByte, l1, 6, i);
/*      */ 
/*      */     
/*  458 */     i = kgrd42b(arrayOfByte, l2, 3, i);
/*      */ 
/*      */     
/*  461 */     i = kgrd42b(arrayOfByte, l3, 6, i);
/*      */ 
/*      */     
/*  464 */     i = kgrd42b(arrayOfByte, l4, 3, i);
/*      */ 
/*      */ 
/*      */     
/*  468 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long[] rcToRowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  484 */     byte b = 18;
/*      */     
/*  486 */     if (paramInt2 != b)
/*      */     {
/*  488 */       throw new SQLException("Rowid size incorrect.");
/*      */     }
/*      */     
/*  491 */     long[] arrayOfLong = new long[3];
/*  492 */     String str = new String(paramArrayOfbyte, paramInt1, paramInt2);
/*      */ 
/*      */     
/*  495 */     long l1 = Long.parseLong(str.substring(0, 8), 16);
/*  496 */     long l2 = Long.parseLong(str.substring(9, 13), 16);
/*  497 */     long l3 = Long.parseLong(str.substring(14, 8), 16);
/*      */     
/*  499 */     arrayOfLong[0] = l3;
/*  500 */     arrayOfLong[1] = l1;
/*  501 */     arrayOfLong[2] = l2;
/*      */     
/*  503 */     return arrayOfLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void kgrdr2rc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte, int paramInt6) throws SQLException {
/*  523 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt4, 8, paramInt6);
/*  524 */     paramArrayOfbyte[paramInt6++] = 46;
/*      */     
/*  526 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt5, 4, paramInt6);
/*  527 */     paramArrayOfbyte[paramInt6++] = 46;
/*      */     
/*  529 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt2, 4, paramInt6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int lmx42h(byte[] paramArrayOfbyte, long paramLong, int paramInt1, int paramInt2) {
/*  544 */     String str = Long.toHexString(paramLong).toUpperCase();
/*      */ 
/*      */     
/*  547 */     int i = paramInt1;
/*  548 */     byte b = 0;
/*      */ 
/*      */     
/*      */     do {
/*  552 */       if (b < str.length())
/*      */       {
/*  554 */         paramArrayOfbyte[paramInt2 + paramInt1 - 1] = (byte)str.charAt(str.length() - b - 1);
/*      */         
/*  556 */         b++;
/*      */       }
/*      */       else
/*      */       {
/*  560 */         paramArrayOfbyte[paramInt2 + paramInt1 - 1] = 48;
/*      */       }
/*      */     
/*  563 */     } while (--paramInt1 > 0);
/*      */     
/*  565 */     return i + paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrdc2ub(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3) throws SQLException {
/*  582 */     byte b = getRowidType(paramArrayOfbyte1, paramInt1);
/*  583 */     byte[] arrayOfByte1 = paramArrayOfbyte2;
/*  584 */     int i = paramInt3 - 1;
/*  585 */     int j = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  590 */     byte[] arrayOfByte2 = kgrd_index_64;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  597 */     int k = 1 + 3 * (paramInt3 - 1) / 4 + (((paramInt3 - 1) % 4 != 0) ? ((paramInt3 - 1) % 4 - 1) : 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  603 */     if (i == 0) {
/*      */ 
/*      */       
/*  606 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  607 */       sQLException.fillInStackTrace();
/*  608 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  613 */     arrayOfByte1[paramInt2 + 0] = b;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  621 */     j = paramInt1 + 1;
/*  622 */     byte b1 = 1;
/*      */     
/*  624 */     while (i > 0) {
/*      */ 
/*      */       
/*  627 */       if (i == 1) {
/*      */ 
/*      */         
/*  630 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  631 */         sQLException.fillInStackTrace();
/*  632 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  637 */       byte b2 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  638 */       if (b2 == -1) {
/*      */ 
/*      */         
/*  641 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  642 */         sQLException.fillInStackTrace();
/*  643 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  647 */       j++;
/*  648 */       byte b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  649 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  652 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  653 */         sQLException.fillInStackTrace();
/*  654 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  662 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0xFF) << 2 | (b3 & 0x30) >> 4);
/*      */ 
/*      */       
/*  665 */       if (i == 2) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  672 */       b1++;
/*  673 */       b2 = b3;
/*  674 */       j++;
/*  675 */       b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  676 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  679 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  680 */         sQLException.fillInStackTrace();
/*  681 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  685 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0xFF) << 4 | (b3 & 0x3C) >> 2);
/*      */ 
/*      */       
/*  688 */       if (i == 3) {
/*      */         break;
/*      */       }
/*      */ 
/*      */       
/*  693 */       b1++;
/*  694 */       b2 = b3;
/*  695 */       j++;
/*  696 */       b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  697 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  700 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  701 */         sQLException.fillInStackTrace();
/*  702 */         throw sQLException;
/*      */       } 
/*      */       
/*  705 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0x3) << 6 | b3);
/*      */ 
/*      */ 
/*      */       
/*  709 */       i -= 4;
/*  710 */       j++;
/*  711 */       b1++;
/*      */     } 
/*      */     
/*  714 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long[] stringToRowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  724 */     byte b = 18;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  729 */     if (paramInt2 != b)
/*      */     {
/*  731 */       throw new SQLException("Rowid size incorrect.");
/*      */     }
/*      */     
/*  734 */     long[] arrayOfLong = new long[4];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  740 */       arrayOfLong[0] = kgrdb42(paramArrayOfbyte, 6, paramInt1);
/*      */ 
/*      */       
/*  743 */       paramInt1 += 6;
/*      */ 
/*      */       
/*  746 */       arrayOfLong[1] = kgrdb42(paramArrayOfbyte, 3, paramInt1);
/*      */ 
/*      */       
/*  749 */       paramInt1 += 3;
/*      */ 
/*      */       
/*  752 */       arrayOfLong[2] = kgrdb42(paramArrayOfbyte, 6, paramInt1);
/*      */ 
/*      */       
/*  755 */       paramInt1 += 6;
/*      */ 
/*      */       
/*  758 */       arrayOfLong[3] = kgrdb42(paramArrayOfbyte, 3, paramInt1);
/*      */ 
/*      */       
/*  761 */       paramInt1 += 3;
/*      */     }
/*  763 */     catch (Exception exception) {
/*      */       
/*  765 */       arrayOfLong[0] = 0L;
/*  766 */       arrayOfLong[1] = 0L;
/*  767 */       arrayOfLong[2] = 0L;
/*  768 */       arrayOfLong[3] = 0L;
/*      */     } 
/*      */     
/*  771 */     return arrayOfLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrd42b(byte[] paramArrayOfbyte, long paramLong, int paramInt1, int paramInt2) {
/*  783 */     int i = paramInt1;
/*  784 */     long l = paramLong;
/*      */     
/*  786 */     for (; paramInt1 > 0; paramInt1--) {
/*      */       
/*  788 */       paramArrayOfbyte[paramInt2 + paramInt1 - 1] = kgrd_basis_64[(int)l & 0x3F];
/*  789 */       l = l >>> 6L & 0x3FFFFFFL;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  795 */     return i + paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long kgrdb42(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  806 */     long l = 0L;
/*      */     
/*  808 */     for (byte b = 0; b < paramInt1; b++) {
/*      */       
/*  810 */       byte b1 = paramArrayOfbyte[paramInt2 + b];
/*      */       
/*  812 */       b1 = kgrd_index_64[b1];
/*      */       
/*  814 */       if (b1 == -1) {
/*  815 */         throw new SQLException("Char data to rowid conversion failed.");
/*      */       }
/*  817 */       l <<= 6L;
/*  818 */       l |= b1;
/*      */     } 
/*      */     
/*  821 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void kgrdr2ec(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte, int paramInt6) throws SQLException {
/*  834 */     paramInt6 = kgrd42b(paramInt1, paramArrayOfbyte, paramInt6, 6);
/*  835 */     paramInt6 = kgrd42b(paramInt2, paramArrayOfbyte, paramInt6, 3);
/*  836 */     paramInt6 = kgrd42b(paramInt4, paramArrayOfbyte, paramInt6, 6);
/*  837 */     paramInt6 = kgrd42b(paramInt5, paramArrayOfbyte, paramInt6, 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrd42b(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/*  848 */     int i = paramInt3;
/*  849 */     while (paramInt3 > 0) {
/*      */       
/*  851 */       paramInt3--;
/*  852 */       paramArrayOfbyte[paramInt2 + paramInt3] = kgrd_basis_64[paramInt1 & 0x3F];
/*      */       
/*  854 */       paramInt1 >>= 6;
/*      */     } 
/*      */     
/*  857 */     return paramInt2 + i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrdub2c(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws SQLException {
/*  870 */     byte b = -1;
/*  871 */     byte b1 = paramArrayOfbyte1[paramInt2];
/*      */     
/*  873 */     if (b1 == 1) {
/*      */ 
/*      */ 
/*      */       
/*  877 */       int[] arrayOfInt = new int[paramArrayOfbyte1.length]; int i;
/*  878 */       for (i = 0; i < paramArrayOfbyte1.length; ) { arrayOfInt[i] = paramArrayOfbyte1[i] & 0xFF; i++; }
/*      */       
/*  880 */       i = paramInt2 + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  888 */       int j = (((arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1] << 8) + arrayOfInt[i + 2] << 8) + arrayOfInt[i + 3];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  893 */       i = paramInt2 + 5;
/*      */       
/*  895 */       int k = (arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1];
/*  896 */       boolean bool = false;
/*      */ 
/*      */       
/*  899 */       i = paramInt2 + 7;
/*  900 */       int m = (((arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1] << 8) + arrayOfInt[i + 2] << 8) + arrayOfInt[i + 3];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  905 */       i = paramInt2 + 11;
/*      */       
/*  907 */       int n = (arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  916 */       if (j == 0) {
/*  917 */         kgrdr2rc(j, k, bool, m, n, paramArrayOfbyte2, paramInt3);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  925 */         kgrdr2ec(j, k, bool, m, n, paramArrayOfbyte2, paramInt3);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  933 */       b = 18;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  939 */       byte b2 = 0;
/*  940 */       int i = paramInt1 - 1;
/*  941 */       int j = 4 * paramInt1 / 3 + ((paramInt1 % 3 == 0) ? (paramInt1 % 3 + 1) : 0);
/*      */       
/*  943 */       int k = 1 + j - 1;
/*      */       
/*  945 */       if (k != 0) {
/*      */         
/*  947 */         paramArrayOfbyte2[paramInt3 + 0] = kgrd_indbyte_char[b1 - 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  961 */         int m = paramInt2 + 1;
/*      */         
/*  963 */         b2 = 1;
/*      */         
/*  965 */         byte b3 = 0;
/*      */         
/*  967 */         while (i > 0) {
/*      */           
/*  969 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0xFF) >> 2];
/*      */ 
/*      */ 
/*      */           
/*  973 */           if (i == 1) {
/*      */ 
/*      */ 
/*      */             
/*  977 */             paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0x3) << 4];
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */           
/*  984 */           b3 = (byte)(paramArrayOfbyte1[m + 1] & 0xFF);
/*      */           
/*  986 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0x3) << 4 | (b3 & 0xF0) >> 4];
/*      */ 
/*      */ 
/*      */           
/*  990 */           if (i == 2) {
/*      */             
/*  992 */             paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(b3 & 0xF) << 2];
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1002 */           m += 2;
/* 1003 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(b3 & 0xF) << 2 | (paramArrayOfbyte1[m] & 0xC0) >> 6];
/*      */ 
/*      */ 
/*      */           
/* 1007 */           paramArrayOfbyte2[paramInt3 + b2] = kgrd_basis_64[paramArrayOfbyte1[m] & 0x3F];
/*      */ 
/*      */ 
/*      */           
/* 1011 */           i -= 3;
/* 1012 */           m++;
/* 1013 */           b2++;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1019 */       b = b2;
/*      */     } 
/*      */     
/* 1022 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean isUROWID(byte[] paramArrayOfbyte, int paramInt) {
/* 1028 */     return (getRowidType(paramArrayOfbyte, paramInt) == 2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte getRowidType(byte[] paramArrayOfbyte, int paramInt) {
/* 1034 */     byte b = 5;
/* 1035 */     switch (paramArrayOfbyte[paramInt]) {
/*      */       
/*      */       case 65:
/* 1038 */         b = 1;
/*      */         break;
/*      */       
/*      */       case 42:
/* 1042 */         b = 2;
/*      */         break;
/*      */       
/*      */       case 45:
/* 1046 */         b = 3;
/*      */         break;
/*      */       
/*      */       case 40:
/* 1050 */         b = 4;
/*      */         break;
/*      */       
/*      */       case 41:
/* 1054 */         b = 5;
/*      */         break;
/*      */     } 
/*      */     
/* 1058 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1086 */   static final byte[] kgrd_indbyte_char = new byte[] { 65, 42, 45, 40, 41 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1093 */   static final byte[] kgrd_basis_64 = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1108 */   static final byte[] kgrd_index_64 = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1134 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CRowidAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */