/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.net.ns.BreakNetException;
/*      */ import oracle.net.ns.Communication;
/*      */ import oracle.net.ns.NetException;
/*      */ import oracle.net.ns.NetInputStream;
/*      */ import oracle.net.ns.NetOutputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CMAREngine
/*      */ {
/*      */   static final int TTCC_MXL = 252;
/*      */   static final int TTCC_ESC = 253;
/*      */   static final int TTCC_LNG = 254;
/*      */   static final int TTCC_ERR = 255;
/*      */   static final int TTCC_MXIN = 64;
/*      */   static final byte TTCLXMULTI = 1;
/*      */   static final byte TTCLXMCONV = 2;
/*      */   T4CTypeRep types;
/*      */   Communication net;
/*      */   DBConversion conv;
/*      */   short proSvrVer;
/*      */   NetInputStream inStream;
/*      */   NetOutputStream outStream;
/*  134 */   final byte[] ignored = new byte[255];
/*  135 */   final byte[] tmpBuffer1 = new byte[1];
/*  136 */   final byte[] tmpBuffer2 = new byte[2];
/*  137 */   final byte[] tmpBuffer3 = new byte[3];
/*  138 */   final byte[] tmpBuffer4 = new byte[4];
/*  139 */   final byte[] tmpBuffer5 = new byte[5];
/*  140 */   final byte[] tmpBuffer6 = new byte[6];
/*  141 */   final byte[] tmpBuffer7 = new byte[7];
/*  142 */   final byte[] tmpBuffer8 = new byte[8];
/*  143 */   final int[] retLen = new int[1];
/*      */ 
/*      */   
/*  146 */   AtomicReference<OracleConnection> connForException = new AtomicReference<OracleConnection>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList refVector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String toHex(long paramLong, int paramInt) {
/*      */     String str;
/*  159 */     switch (paramInt) {
/*      */ 
/*      */       
/*      */       case 1:
/*  163 */         str = "00" + Long.toString(paramLong & 0xFFL, 16);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  205 */         return "0x" + str.substring(str.length() - 2 * paramInt);case 2: str = "0000" + Long.toString(paramLong & 0xFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 3: str = "000000" + Long.toString(paramLong & 0xFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 4: str = "00000000" + Long.toString(paramLong & 0xFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 5: str = "0000000000" + Long.toString(paramLong & 0xFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 6: str = "000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 7: str = "00000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);
/*      */       case 8:
/*      */         return toHex(paramLong >> 32L, 4) + toHex(paramLong, 4).substring(2);
/*      */     } 
/*      */     return "more than 8 bytes"; } static String toHex(byte paramByte) {
/*  210 */     String str = "00" + Integer.toHexString(paramByte & 0xFF);
/*  211 */     return "0x" + str.substring(str.length() - 2);
/*      */   }
/*      */ 
/*      */   
/*      */   static String toHex(short paramShort) {
/*  216 */     return toHex(paramShort, 2);
/*      */   }
/*      */ 
/*      */   
/*      */   static String toHex(int paramInt) {
/*  221 */     return toHex(paramInt, 4);
/*      */   }
/*      */ 
/*      */   
/*      */   static String toHex(byte[] paramArrayOfbyte, int paramInt) {
/*  226 */     if (paramArrayOfbyte == null) {
/*  227 */       return "null";
/*      */     }
/*  229 */     if (paramInt > paramArrayOfbyte.length) {
/*  230 */       return "byte array not long enough";
/*      */     }
/*  232 */     String str = "[";
/*  233 */     int i = Math.min(64, paramInt);
/*      */     
/*  235 */     for (byte b = 0; b < i; b++)
/*      */     {
/*  237 */       str = str + toHex(paramArrayOfbyte[b]) + " ";
/*      */     }
/*      */     
/*  240 */     if (i < paramInt) {
/*  241 */       str = str + "...";
/*      */     }
/*  243 */     return str + "]";
/*      */   }
/*      */ 
/*      */   
/*      */   static String toHex(byte[] paramArrayOfbyte) {
/*  248 */     if (paramArrayOfbyte == null) {
/*  249 */       return "null";
/*      */     }
/*  251 */     return toHex(paramArrayOfbyte, paramArrayOfbyte.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CMAREngine(Communication paramCommunication) throws SQLException, IOException {
/*  258 */     this(paramCommunication, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initBuffers() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalSB1(byte paramByte) throws IOException {
/*      */     try {
/*  357 */       marshalSB2((short)paramByte);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalUB1(short paramShort) throws IOException {
/*      */     try {
/*  376 */       this.outStream.write((byte)(paramShort & 0xFF));
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalSB2(short paramShort) throws IOException {
/*  397 */     byte b = value2Buffer(paramShort, this.tmpBuffer2, (byte)1);
/*      */     
/*  399 */     if (b != 0) {
/*      */       
/*      */       try {
/*      */         
/*  403 */         this.outStream.write(this.tmpBuffer2, 0, b);
/*      */       } finally {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalUB2(int paramInt) throws IOException {
/*  421 */     marshalSB2((short)(paramInt & 0xFFFF));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalSB4(int paramInt) throws IOException {
/*  438 */     byte b = value2Buffer(paramInt, this.tmpBuffer4, (byte)2);
/*      */ 
/*      */     
/*  441 */     if (b != 0) {
/*      */       
/*      */       try {
/*      */         
/*  445 */         this.outStream.write(this.tmpBuffer4, 0, b);
/*      */       } finally {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalUB4(long paramLong) throws IOException {
/*  462 */     marshalSB4((int)(paramLong & 0xFFFFFFFFFFFFFFFFL));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalSB8(long paramLong) throws IOException {
/*  478 */     byte b = value2Buffer(paramLong, this.tmpBuffer8, (byte)3);
/*      */ 
/*      */     
/*  481 */     if (b != 0) {
/*      */       
/*      */       try {
/*      */         
/*  485 */         this.outStream.write(this.tmpBuffer8, 0, b);
/*      */       } finally {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalSWORD(int paramInt) throws IOException {
/*  502 */     marshalSB4(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalUWORD(long paramLong) throws IOException {
/*  514 */     marshalSB4((int)(paramLong & 0xFFFFFFFFFFFFFFFFL));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalB1Array(byte[] paramArrayOfbyte) throws IOException {
/*  527 */     if (paramArrayOfbyte.length > 0) {
/*      */       
/*      */       try {
/*      */         
/*  531 */         this.outStream.write(paramArrayOfbyte);
/*      */       } finally {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalB1Array(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  552 */     if (paramArrayOfbyte.length > 0) {
/*      */       
/*      */       try {
/*      */         
/*  556 */         this.outStream.write(paramArrayOfbyte, paramInt1, paramInt2);
/*      */       } finally {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalUB4Array(long[] paramArrayOflong) throws IOException {
/*  573 */     for (byte b = 0; b < paramArrayOflong.length; b++) {
/*  574 */       marshalSB4((int)(paramArrayOflong[b] & 0xFFFFFFFFFFFFFFFFL));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalO2U(boolean paramBoolean) throws IOException {
/*  616 */     if (paramBoolean) {
/*  617 */       addPtr((byte)1);
/*      */     } else {
/*  619 */       addPtr((byte)0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalNULLPTR() throws IOException {
/*  635 */     addPtr((byte)0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalPTR() throws IOException {
/*  653 */     addPtr((byte)1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCHR(byte[] paramArrayOfbyte) throws IOException {
/*  668 */     marshalCHR(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCHR(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  677 */     if (paramInt2 > 0)
/*      */     {
/*  679 */       if (this.types.isConvNeeded()) {
/*  680 */         marshalCLR(paramArrayOfbyte, paramInt1, paramInt2);
/*      */       } else {
/*      */ 
/*      */         
/*      */         try {
/*  685 */           this.outStream.write(paramArrayOfbyte, paramInt1, paramInt2);
/*      */         } finally {}
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCLR(byte[] paramArrayOfbyte, int paramInt) throws IOException {
/*  704 */     marshalCLR(paramArrayOfbyte, 0, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalCLR(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*      */     try {
/*  716 */       if (paramInt2 > 64) {
/*      */         
/*  718 */         int i = 0;
/*      */ 
/*      */         
/*  721 */         this.outStream.write(-2);
/*      */ 
/*      */         
/*      */         do {
/*  725 */           int j = paramInt2 - i;
/*  726 */           byte b = (j > 64) ? 64 : j;
/*      */ 
/*      */           
/*  729 */           this.outStream.write((byte)(b & 0xFF));
/*  730 */           this.outStream.write(paramArrayOfbyte, paramInt1 + i, b);
/*      */ 
/*      */           
/*  733 */           i += b;
/*      */         }
/*  735 */         while (i < paramInt2);
/*      */         
/*  737 */         this.outStream.write(0);
/*      */       }
/*      */       else {
/*      */         
/*  741 */         this.outStream.write((byte)(paramInt2 & 0xFF));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  748 */         if (paramArrayOfbyte.length != 0) {
/*  749 */           this.outStream.write(paramArrayOfbyte, paramInt1, paramInt2);
/*      */         }
/*      */       } 
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalKEYVAL(byte[][] paramArrayOfbyte1, int[] paramArrayOfint1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint2, byte[] paramArrayOfbyte, int paramInt) throws IOException {
/*  767 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/*  769 */       if (paramArrayOfbyte1[b] != null && paramArrayOfint1[b] > 0) {
/*      */         
/*  771 */         marshalUB4(paramArrayOfint1[b]);
/*  772 */         marshalCLR(paramArrayOfbyte1[b], 0, paramArrayOfint1[b]);
/*      */       } else {
/*      */         
/*  775 */         marshalUB4(0L);
/*      */       } 
/*  777 */       if (paramArrayOfbyte2[b] != null && paramArrayOfint2[b] > 0) {
/*      */         
/*  779 */         marshalUB4(paramArrayOfint2[b]);
/*  780 */         marshalCLR(paramArrayOfbyte2[b], 0, paramArrayOfint2[b]);
/*      */       } else {
/*      */         
/*  783 */         marshalUB4(0L);
/*      */       } 
/*      */       
/*  786 */       if (paramArrayOfbyte[b] != 0) {
/*  787 */         marshalUB4(1L);
/*      */       } else {
/*  789 */         marshalUB4(0L);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalKEYVAL(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, byte[] paramArrayOfbyte, int paramInt) throws IOException {
/*  800 */     int[] arrayOfInt1 = new int[paramInt];
/*  801 */     int[] arrayOfInt2 = new int[paramInt];
/*  802 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/*  804 */       if (paramArrayOfbyte1[b] != null)
/*  805 */         arrayOfInt1[b] = (paramArrayOfbyte1[b]).length; 
/*  806 */       if (paramArrayOfbyte2[b] != null)
/*  807 */         arrayOfInt2[b] = (paramArrayOfbyte2[b]).length; 
/*      */     } 
/*  809 */     marshalKEYVAL(paramArrayOfbyte1, arrayOfInt1, paramArrayOfbyte2, arrayOfInt2, paramArrayOfbyte, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalDALC(byte[] paramArrayOfbyte) throws IOException {
/*  827 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length < 1) {
/*      */ 
/*      */       
/*      */       try {
/*  831 */         this.outStream.write(0);
/*      */       
/*      */       }
/*      */       finally {}
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  839 */       marshalSB4(0xFFFFFFFF & paramArrayOfbyte.length);
/*  840 */       marshalCLR(paramArrayOfbyte, paramArrayOfbyte.length);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void marshalKPDKV(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint) throws IOException {
/*  852 */     for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/*      */       
/*  854 */       if (paramArrayOfbyte1[b] != null) {
/*      */         
/*  856 */         marshalUB4((paramArrayOfbyte1[b]).length);
/*  857 */         marshalCLR(paramArrayOfbyte1[b], 0, (paramArrayOfbyte1[b]).length);
/*      */       } else {
/*      */         
/*  860 */         marshalUB4(0L);
/*  861 */       }  if (paramArrayOfbyte2[b] != null) {
/*      */         
/*  863 */         marshalUB4((paramArrayOfbyte2[b]).length);
/*  864 */         marshalCLR(paramArrayOfbyte2[b], 0, (paramArrayOfbyte2[b]).length);
/*      */       } else {
/*      */         
/*  867 */         marshalUB4(0L);
/*  868 */       }  marshalUB2(paramArrayOfint[b]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unmarshalKPDKV(byte[][] paramArrayOfbyte1, int[] paramArrayOfint1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint2) throws IOException, SQLException {
/*  880 */     int i = 0;
/*  881 */     int[] arrayOfInt = new int[1];
/*      */     
/*  883 */     for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/*      */       
/*  885 */       i = (int)unmarshalUB4();
/*  886 */       if (i > 0) {
/*      */         
/*  888 */         paramArrayOfbyte1[b] = new byte[i];
/*  889 */         unmarshalCLR(paramArrayOfbyte1[b], 0, arrayOfInt, i);
/*  890 */         paramArrayOfint1[b] = arrayOfInt[0];
/*      */       } 
/*  892 */       i = (int)unmarshalUB4();
/*  893 */       if (i > 0) {
/*      */         
/*  895 */         paramArrayOfbyte2[b] = new byte[i];
/*  896 */         unmarshalCLR(paramArrayOfbyte2[b], 0, arrayOfInt, i);
/*      */       } 
/*  898 */       paramArrayOfint2[b] = unmarshalUB2();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void addPtr(byte paramByte) throws IOException {
/*      */     try {
/*  921 */       if ((this.types.rep[4] & 0x1) > 0) {
/*  922 */         this.outStream.write(paramByte);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  928 */         byte b = value2Buffer(paramByte, this.tmpBuffer4, (byte)4);
/*      */ 
/*      */         
/*  931 */         if (b != 0) {
/*  932 */           this.outStream.write(this.tmpBuffer4, 0, b);
/*      */         }
/*      */       } 
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte value2Buffer(int paramInt, byte[] paramArrayOfbyte, byte paramByte) throws IOException {
/*  959 */     boolean bool1 = ((this.types.rep[paramByte] & 0x1) > 0) ? true : false;
/*  960 */     boolean bool2 = true;
/*  961 */     byte b = 0;
/*      */ 
/*      */ 
/*      */     
/*  965 */     for (int i = paramArrayOfbyte.length - 1; i >= 0; i--) {
/*      */       
/*  967 */       paramArrayOfbyte[b] = (byte)(paramInt >>> 8 * i & 0xFF);
/*      */ 
/*      */ 
/*      */       
/*  971 */       if (bool1) {
/*      */         
/*  973 */         if (!bool2 || paramArrayOfbyte[b] != 0) {
/*      */           
/*  975 */           bool2 = false;
/*  976 */           b = (byte)(b + 1);
/*      */         } 
/*      */       } else {
/*      */         
/*  980 */         b = (byte)(b + 1);
/*      */       } 
/*      */     } 
/*      */     
/*  984 */     if (bool1) {
/*      */       
/*      */       try {
/*      */         
/*  988 */         this.outStream.write(b);
/*      */       } finally {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  998 */     if ((this.types.rep[paramByte] & 0x2) > 0) {
/*  999 */       reverseArray(paramArrayOfbyte, b);
/*      */     }
/* 1001 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte value2Buffer(long paramLong, byte[] paramArrayOfbyte, byte paramByte) throws IOException {
/* 1010 */     boolean bool1 = ((this.types.rep[paramByte] & 0x1) > 0) ? true : false;
/* 1011 */     boolean bool2 = true;
/* 1012 */     byte b = 0;
/*      */ 
/*      */ 
/*      */     
/* 1016 */     for (int i = paramArrayOfbyte.length - 1; i >= 0; i--) {
/*      */       
/* 1018 */       paramArrayOfbyte[b] = (byte)(int)(paramLong >>> 8 * i & 0xFFL);
/*      */ 
/*      */ 
/*      */       
/* 1022 */       if (bool1) {
/*      */         
/* 1024 */         if (!bool2 || paramArrayOfbyte[b] != 0) {
/*      */           
/* 1026 */           bool2 = false;
/* 1027 */           b = (byte)(b + 1);
/*      */         } 
/*      */       } else {
/*      */         
/* 1031 */         b = (byte)(b + 1);
/*      */       } 
/*      */     } 
/*      */     
/* 1035 */     if (bool1) {
/*      */       
/*      */       try {
/*      */         
/* 1039 */         this.outStream.write(b);
/*      */       } finally {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1049 */     if ((this.types.rep[paramByte] & 0x2) > 0) {
/* 1050 */       reverseArray(paramArrayOfbyte, b);
/*      */     }
/* 1052 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void reverseArray(byte[] paramArrayOfbyte, byte paramByte) {
/* 1067 */     int i = paramByte / 2;
/*      */     
/* 1069 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 1071 */       byte b1 = paramArrayOfbyte[b];
/* 1072 */       paramArrayOfbyte[b] = paramArrayOfbyte[paramByte - 1 - b];
/* 1073 */       paramArrayOfbyte[paramByte - 1 - b] = b1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte unmarshalSB1() throws SQLException, IOException {
/* 1113 */     return (byte)unmarshalSB2();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final short unmarshalUB1() throws SQLException, IOException {
/* 1132 */     short s = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1137 */       s = (short)this.inStream.read();
/*      */     
/*      */     }
/* 1140 */     catch (BreakNetException breakNetException) {
/*      */ 
/*      */       
/* 1143 */       this.net.sendReset();
/* 1144 */       throw breakNetException;
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1152 */     if (s < 0) {
/*      */ 
/*      */ 
/*      */       
/* 1156 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 1157 */       sQLException.fillInStackTrace();
/* 1158 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1167 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final short unmarshalSB2() throws SQLException, IOException {
/* 1185 */     return (short)unmarshalUB2();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalUB2() throws SQLException, IOException {
/* 1207 */     int i = (int)buffer2Value((byte)1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1215 */     return i & 0xFFFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalUCS2(byte[] paramArrayOfbyte, long paramLong) throws SQLException, IOException {
/* 1233 */     int i = unmarshalUB2();
/*      */     
/* 1235 */     this.tmpBuffer2[0] = (byte)((i & 0xFF00) >> 8);
/* 1236 */     this.tmpBuffer2[1] = (byte)(i & 0xFF);
/*      */ 
/*      */     
/* 1239 */     if (paramLong + 1L < paramArrayOfbyte.length) {
/*      */ 
/*      */ 
/*      */       
/* 1243 */       paramArrayOfbyte[(int)paramLong] = this.tmpBuffer2[0];
/* 1244 */       paramArrayOfbyte[(int)paramLong + 1] = this.tmpBuffer2[1];
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1270 */     return (this.tmpBuffer2[0] == 0) ? ((this.tmpBuffer2[1] == 0) ? 1 : 2) : 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalSB4() throws SQLException, IOException {
/* 1288 */     return (int)unmarshalUB4();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long unmarshalUB4() throws SQLException, IOException {
/* 1310 */     return buffer2Value((byte)2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalSB4(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 1335 */     long l = buffer2Value((byte)2, new ByteArrayInputStream(paramArrayOfbyte));
/*      */     
/* 1337 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long unmarshalSB8() throws SQLException, IOException {
/* 1358 */     return buffer2Value((byte)3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalRefCursor(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 1369 */     return unmarshalSB4(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int unmarshalSWORD() throws SQLException, IOException {
/* 1390 */     return (int)unmarshalUB4();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long unmarshalUWORD() throws SQLException, IOException {
/* 1410 */     return unmarshalUB4();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] unmarshalNBytes(int paramInt) throws SQLException, IOException {
/* 1428 */     byte[] arrayOfByte = new byte[paramInt];
/*      */     
/* 1430 */     if (paramInt > 0) {
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 1435 */         if (this.inStream.read(arrayOfByte) < 0)
/*      */         {
/*      */ 
/*      */           
/* 1439 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 1440 */           sQLException.fillInStackTrace();
/* 1441 */           throw sQLException;
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 1447 */       catch (BreakNetException breakNetException) {
/*      */ 
/*      */         
/* 1450 */         this.net.sendReset();
/* 1451 */         throw breakNetException;
/*      */       } finally {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1458 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int unmarshalNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 1477 */     if (paramInt1 + paramInt2 > paramArrayOfbyte.length)
/*      */     {
/* 1479 */       paramInt2 = paramArrayOfbyte.length - paramInt1;
/*      */     }
/*      */     
/* 1482 */     int i = 0;
/*      */     
/* 1484 */     while (i < paramInt2) {
/* 1485 */       i += getNBytes(paramArrayOfbyte, paramInt1 + i, paramInt2 - i);
/*      */     }
/* 1487 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 1506 */     if (paramInt1 + paramInt2 > paramArrayOfbyte.length)
/*      */     {
/* 1508 */       paramInt2 = paramArrayOfbyte.length - paramInt1;
/*      */     }
/*      */     
/* 1511 */     int i = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1517 */       if ((i = this.inStream.read(paramArrayOfbyte, paramInt1, paramInt2)) < 0)
/*      */       {
/*      */ 
/*      */         
/* 1521 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 1522 */         sQLException.fillInStackTrace();
/* 1523 */         throw sQLException;
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1529 */     catch (BreakNetException breakNetException) {
/*      */ 
/*      */ 
/*      */       
/* 1533 */       this.net.sendReset();
/* 1534 */       throw breakNetException;
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1541 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getNBytes(int paramInt) throws SQLException, IOException {
/* 1557 */     byte[] arrayOfByte = new byte[paramInt];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1563 */       if (this.inStream.read(arrayOfByte) < 0)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1568 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 1569 */         sQLException.fillInStackTrace();
/* 1570 */         throw sQLException;
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1576 */     catch (BreakNetException breakNetException) {
/*      */ 
/*      */ 
/*      */       
/* 1580 */       this.net.sendReset();
/* 1581 */       throw breakNetException;
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1588 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] unmarshalTEXT(int paramInt) throws SQLException, IOException {
/*      */     byte[] arrayOfByte2;
/* 1609 */     byte b = 0;
/*      */ 
/*      */ 
/*      */     
/* 1613 */     byte[] arrayOfByte1 = new byte[paramInt];
/*      */ 
/*      */     
/* 1616 */     while (b < paramInt) {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 1622 */         if (this.inStream.read(arrayOfByte1, b, 1) < 0)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1627 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 1628 */           sQLException.fillInStackTrace();
/* 1629 */           throw sQLException;
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 1635 */       catch (BreakNetException breakNetException) {
/*      */ 
/*      */ 
/*      */         
/* 1639 */         this.net.sendReset();
/* 1640 */         throw breakNetException;
/*      */       } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1647 */       if (arrayOfByte1[b++] == 0) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 1652 */     if (arrayOfByte1.length == --b) {
/*      */       
/* 1654 */       arrayOfByte2 = arrayOfByte1;
/*      */     }
/*      */     else {
/*      */       
/* 1658 */       arrayOfByte2 = new byte[b];
/*      */       
/* 1660 */       System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, b);
/*      */     } 
/*      */     
/* 1663 */     return arrayOfByte2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] unmarshalCHR(int paramInt) throws SQLException, IOException {
/* 1682 */     byte[] arrayOfByte = null;
/*      */     
/* 1684 */     if (this.types.isConvNeeded()) {
/*      */       
/* 1686 */       arrayOfByte = unmarshalCLR(paramInt, this.retLen);
/*      */       
/* 1688 */       if (arrayOfByte.length != this.retLen[0])
/*      */       {
/* 1690 */         byte[] arrayOfByte1 = new byte[this.retLen[0]];
/*      */         
/* 1692 */         System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, this.retLen[0]);
/*      */         
/* 1694 */         arrayOfByte = arrayOfByte1;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1699 */       arrayOfByte = getNBytes(paramInt);
/*      */     } 
/*      */     
/* 1702 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unmarshalCLR(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
/* 1711 */     unmarshalCLR(paramArrayOfbyte, paramInt, paramArrayOfint, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unmarshalCLR(byte[] paramArrayOfbyte, int paramInt1, int[] paramArrayOfint, int paramInt2) throws SQLException, IOException {
/* 1718 */     unmarshalCLR(paramArrayOfbyte, paramInt1, paramArrayOfint, paramInt2, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unmarshalCLR(byte[] paramArrayOfbyte, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3) throws SQLException, IOException {
/* 1741 */     int i = 0;
/* 1742 */     int j = 0;
/* 1743 */     int k = paramInt1;
/* 1744 */     boolean bool = false;
/* 1745 */     int m = 0;
/* 1746 */     int n = 0;
/* 1747 */     int i1 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1753 */     byte b = -1;
/*      */     
/* 1755 */     i = unmarshalUB1();
/*      */ 
/*      */     
/* 1758 */     if (i < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1763 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 1764 */       sQLException.fillInStackTrace();
/* 1765 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1769 */     if (i == 0) {
/*      */       
/* 1771 */       paramArrayOfint[0] = 0;
/*      */       
/*      */       return;
/*      */     } 
/* 1775 */     if (escapeSequenceNull(i)) {
/*      */       
/* 1777 */       paramArrayOfint[0] = 0;
/*      */       
/*      */       return;
/*      */     } 
/* 1781 */     if (i != 254) {
/*      */       
/* 1783 */       if (paramInt3 - i1 >= i) {
/*      */ 
/*      */         
/* 1786 */         unmarshalBuffer(this.ignored, 0, i);
/* 1787 */         i1 += i;
/*      */         
/* 1789 */         i = 0;
/*      */       }
/* 1791 */       else if (paramInt3 - i1 > 0) {
/*      */ 
/*      */ 
/*      */         
/* 1795 */         unmarshalBuffer(this.ignored, 0, paramInt3 - i1);
/*      */         
/* 1797 */         i -= paramInt3 - i1;
/* 1798 */         i1 += paramInt3 - i1;
/*      */       } 
/*      */       
/* 1801 */       if (i > 0) {
/*      */ 
/*      */         
/* 1804 */         n = Math.min(paramInt2 - m, i);
/* 1805 */         k = unmarshalBuffer(paramArrayOfbyte, k, n);
/* 1806 */         m += n;
/*      */ 
/*      */         
/* 1809 */         int i2 = i - n;
/*      */         
/* 1811 */         if (i2 > 0) {
/* 1812 */           unmarshalBuffer(this.ignored, 0, i2);
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/* 1817 */       b = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/* 1824 */         if (b != -1) {
/*      */           
/* 1826 */           i = unmarshalUB1();
/*      */ 
/*      */           
/* 1829 */           if (i <= 0) {
/*      */             break;
/*      */           }
/*      */         } 
/* 1833 */         if (i == 254)
/*      */         {
/* 1835 */           switch (b) {
/*      */ 
/*      */             
/*      */             case -1:
/* 1839 */               b = 1;
/*      */               continue;
/*      */ 
/*      */             
/*      */             case 1:
/* 1844 */               b = 0;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 0:
/* 1849 */               if (bool) {
/*      */                 
/* 1851 */                 b = 0;
/*      */ 
/*      */                 
/*      */                 break;
/*      */               } 
/*      */               
/* 1857 */               b = 0;
/*      */               continue;
/*      */           } 
/*      */ 
/*      */         
/*      */         }
/* 1863 */         if (k == -1) {
/*      */           
/* 1865 */           unmarshalBuffer(this.ignored, 0, i);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1870 */           j = i;
/* 1871 */           if (paramInt3 - i1 >= j) {
/*      */ 
/*      */             
/* 1874 */             unmarshalBuffer(this.ignored, 0, j);
/* 1875 */             i1 += j;
/*      */             
/* 1877 */             j = 0;
/*      */           }
/* 1879 */           else if (paramInt3 - i1 > 0) {
/*      */ 
/*      */ 
/*      */             
/* 1883 */             unmarshalBuffer(this.ignored, 0, paramInt3 - i1);
/*      */             
/* 1885 */             j -= paramInt3 - i1;
/* 1886 */             i1 += paramInt3 - i1;
/*      */           } 
/*      */           
/* 1889 */           if (j > 0) {
/*      */ 
/*      */             
/* 1892 */             n = Math.min(paramInt2 - m, j);
/* 1893 */             k = unmarshalBuffer(paramArrayOfbyte, k, n);
/* 1894 */             m += n;
/*      */ 
/*      */             
/* 1897 */             int i2 = j - n;
/*      */             
/* 1899 */             if (i2 > 0) {
/* 1900 */               unmarshalBuffer(this.ignored, 0, i2);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 1905 */         b = 0;
/*      */         
/* 1907 */         if (i > 252) {
/* 1908 */           bool = true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1914 */     if (paramArrayOfint != null)
/*      */     {
/* 1916 */       if (k != -1) {
/* 1917 */         paramArrayOfint[0] = m;
/*      */       } else {
/*      */         
/* 1920 */         paramArrayOfint[0] = paramArrayOfbyte.length - paramInt1;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte[] unmarshalCLR(int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
/* 1934 */     byte[] arrayOfByte = new byte[paramInt * this.conv.c2sNlsRatio];
/*      */     
/* 1936 */     unmarshalCLR(arrayOfByte, 0, paramArrayOfint, paramInt);
/* 1937 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int[] unmarshalKEYVAL(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, int paramInt) throws SQLException, IOException {
/* 1979 */     byte[] arrayOfByte = new byte[1000];
/* 1980 */     int[] arrayOfInt1 = new int[1];
/* 1981 */     int[] arrayOfInt2 = new int[paramInt];
/*      */ 
/*      */     
/* 1984 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/* 1986 */       int i = unmarshalSB4();
/*      */       
/* 1988 */       if (i > 0) {
/*      */         
/* 1990 */         unmarshalCLR(arrayOfByte, 0, arrayOfInt1);
/*      */         
/* 1992 */         paramArrayOfbyte1[b] = new byte[arrayOfInt1[0]];
/*      */         
/* 1994 */         System.arraycopy(arrayOfByte, 0, paramArrayOfbyte1[b], 0, arrayOfInt1[0]);
/*      */       } 
/*      */       
/* 1997 */       i = unmarshalSB4();
/*      */       
/* 1999 */       if (i > 0) {
/*      */         
/* 2001 */         unmarshalCLR(arrayOfByte, 0, arrayOfInt1);
/*      */         
/* 2003 */         paramArrayOfbyte2[b] = new byte[arrayOfInt1[0]];
/*      */         
/* 2005 */         System.arraycopy(arrayOfByte, 0, paramArrayOfbyte2[b], 0, arrayOfInt1[0]);
/*      */       } 
/*      */       
/* 2008 */       arrayOfInt2[b] = unmarshalSB4();
/*      */     } 
/*      */     
/* 2011 */     arrayOfByte = null;
/*      */ 
/*      */     
/* 2014 */     return arrayOfInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int unmarshalBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 2023 */     if (paramInt2 <= 0) {
/* 2024 */       return paramInt1;
/*      */     }
/* 2026 */     if (paramArrayOfbyte.length < paramInt1 + paramInt2) {
/*      */       
/* 2028 */       unmarshalNBytes(paramArrayOfbyte, paramInt1, paramArrayOfbyte.length - paramInt1);
/*      */ 
/*      */       
/* 2031 */       unmarshalNBytes(this.ignored, 0, paramInt1 + paramInt2 - paramArrayOfbyte.length);
/*      */       
/* 2033 */       paramInt1 = -1;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 2039 */       unmarshalNBytes(paramArrayOfbyte, paramInt1, paramInt2);
/*      */       
/* 2041 */       paramInt1 += paramInt2;
/*      */     } 
/* 2043 */     return paramInt1;
/*      */   }
/*      */ 
/*      */   
/*      */   T4CMAREngine(Communication paramCommunication, boolean paramBoolean) throws SQLException, IOException {
/* 2048 */     this.refVector = null; if (paramCommunication == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433); sQLException.fillInStackTrace(); throw sQLException; }
/*      */      this.net = paramCommunication; try { if (paramBoolean) { this.outStream = paramCommunication.getNetOutputStream(); this.inStream = paramCommunication.getNetInputStream(); }
/*      */       else { this.outStream = new T4CSocketOutputStreamWrapper((NetOutputStream)paramCommunication.getOutputStream()); this.inStream = new T4CSocketInputStreamWrapper((NetInputStream)paramCommunication.getInputStream(), (T4CSocketOutputStreamWrapper)this.outStream); }
/*      */        }
/*      */     catch (NetException netException) { throw new IOException(netException.getMessage()); }
/* 2053 */      this.types = new T4CTypeRep(); this.types.setRep((byte)1, (byte)2); } final byte[] unmarshalCLRforREFS() throws SQLException, IOException { short s1 = 0;
/* 2054 */     short s2 = 0;
/* 2055 */     byte[] arrayOfByte = null;
/*      */ 
/*      */     
/* 2058 */     short s = unmarshalUB1();
/*      */ 
/*      */ 
/*      */     
/* 2062 */     if (s < 0) {
/*      */ 
/*      */ 
/*      */       
/* 2066 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 2067 */       sQLException.fillInStackTrace();
/* 2068 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2072 */     if (s == 0)
/*      */     {
/* 2074 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 2078 */     boolean bool = escapeSequenceNull(s);
/* 2079 */     if (!bool)
/*      */     {
/* 2081 */       if (this.refVector == null) {
/* 2082 */         this.refVector = new ArrayList(10);
/*      */       } else {
/* 2084 */         this.refVector.clear();
/*      */       } 
/*      */     }
/* 2087 */     if (!bool) {
/*      */       
/* 2089 */       if (s == 254) {
/*      */ 
/*      */ 
/*      */         
/* 2093 */         while ((s1 = unmarshalUB1()) > 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2099 */           if (s1 == 254)
/*      */           {
/* 2101 */             if (this.types.isServerConversion()) {
/*      */               continue;
/*      */             }
/*      */           }
/* 2105 */           s2 = (short)(s2 + s1);
/* 2106 */           byte[] arrayOfByte1 = new byte[s1];
/*      */           
/* 2108 */           unmarshalBuffer(arrayOfByte1, 0, s1);
/* 2109 */           this.refVector.add(arrayOfByte1);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 2114 */         s2 = s;
/*      */         
/* 2116 */         byte[] arrayOfByte1 = new byte[s];
/*      */         
/* 2118 */         unmarshalBuffer(arrayOfByte1, 0, s);
/* 2119 */         this.refVector.add(arrayOfByte1);
/*      */       } 
/*      */ 
/*      */       
/* 2123 */       arrayOfByte = new byte[s2];
/*      */       
/* 2125 */       int i = 0;
/*      */       
/* 2127 */       while (this.refVector.size() > 0)
/*      */       {
/* 2129 */         int j = ((byte[])this.refVector.get(0)).length;
/*      */         
/* 2131 */         System.arraycopy(this.refVector.get(0), 0, arrayOfByte, i, j);
/*      */ 
/*      */         
/* 2134 */         i += j;
/*      */ 
/*      */ 
/*      */         
/* 2138 */         this.refVector.remove(0);
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2144 */       arrayOfByte = null;
/*      */     } 
/* 2146 */     return arrayOfByte; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean escapeSequenceNull(int paramInt) throws SQLException {
/*      */     SQLException sQLException;
/* 2159 */     boolean bool = false;
/*      */     
/* 2161 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/* 2167 */         bool = true;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 253:
/* 2174 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 2175 */         sQLException.fillInStackTrace();
/* 2176 */         throw sQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 255:
/* 2186 */         bool = true;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2204 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int processIndicator(boolean paramBoolean, int paramInt) throws SQLException, IOException {
/* 2217 */     short s = unmarshalSB2();
/* 2218 */     int i = 0;
/*      */     
/* 2220 */     if (!paramBoolean)
/*      */     {
/* 2222 */       if (s == 0) {
/* 2223 */         i = paramInt;
/* 2224 */       } else if (s == -2 || s > 0) {
/* 2225 */         i = s;
/*      */       }
/*      */       else {
/*      */         
/* 2229 */         i = 65536 + s;
/*      */       }  } 
/* 2231 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long unmarshalDALC(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
/* 2262 */     long l = unmarshalUB4();
/*      */     
/* 2264 */     if (l > 0L)
/* 2265 */       unmarshalCLR(paramArrayOfbyte, paramInt, paramArrayOfint); 
/* 2266 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte[] unmarshalDALC() throws SQLException, IOException {
/* 2274 */     long l = unmarshalUB4();
/* 2275 */     byte[] arrayOfByte = new byte[(int)(0xFFFFFFFFFFFFFFFFL & l)];
/*      */     
/* 2277 */     if (arrayOfByte.length > 0) {
/*      */       
/* 2279 */       arrayOfByte = unmarshalCLR(arrayOfByte.length, this.retLen);
/*      */       
/* 2281 */       if (arrayOfByte == null)
/*      */       {
/*      */ 
/*      */         
/* 2285 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 2286 */         sQLException.fillInStackTrace();
/* 2287 */         throw sQLException;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 2292 */       arrayOfByte = new byte[0];
/* 2293 */     }  return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final byte[] unmarshalDALC(int[] paramArrayOfint) throws SQLException, IOException {
/* 2301 */     long l = unmarshalUB4();
/* 2302 */     byte[] arrayOfByte = new byte[(int)(0xFFFFFFFFFFFFFFFFL & l)];
/*      */ 
/*      */     
/* 2305 */     if (arrayOfByte.length > 0) {
/*      */       
/* 2307 */       arrayOfByte = unmarshalCLR(arrayOfByte.length, paramArrayOfint);
/*      */       
/* 2309 */       if (arrayOfByte == null)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 2314 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 2315 */         sQLException.fillInStackTrace();
/* 2316 */         throw sQLException;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 2321 */       arrayOfByte = new byte[0];
/* 2322 */     }  return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long buffer2Value(byte paramByte) throws SQLException, IOException {
/* 2350 */     long l = 0L;
/* 2351 */     int i = 1;
/* 2352 */     if ((this.types.rep[paramByte] & 0x1) > 0) {
/*      */       
/* 2354 */       i = this.inStream.readB1();
/*      */     } else {
/*      */       
/* 2357 */       switch (paramByte) {
/*      */         
/*      */         case 1:
/* 2360 */           i = 2;
/*      */           break;
/*      */         case 2:
/* 2363 */           i = 4;
/*      */           break;
/*      */         case 3:
/* 2366 */           i = 8;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 2371 */     if ((this.types.rep[paramByte] & 0x2) > 0) {
/* 2372 */       l = this.inStream.readLongLSB(i);
/*      */     } else {
/* 2374 */       l = this.inStream.readLongMSB(i);
/*      */     } 
/* 2376 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long buffer2Value(byte paramByte, ByteArrayInputStream paramByteArrayInputStream) throws SQLException, IOException {
/* 2399 */     int i = 0;
/*      */     
/* 2401 */     long l = 0L;
/* 2402 */     boolean bool = false;
/*      */ 
/*      */     
/* 2405 */     if ((this.types.rep[paramByte] & 0x1) > 0) {
/*      */       
/* 2407 */       i = paramByteArrayInputStream.read();
/*      */ 
/*      */       
/* 2410 */       if ((i & 0x80) > 0) {
/*      */         
/* 2412 */         i &= 0x7F;
/* 2413 */         bool = true;
/*      */       } 
/*      */       
/* 2416 */       if (i < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2421 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 2422 */         sQLException.fillInStackTrace();
/* 2423 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2430 */       if (i == 0)
/*      */       {
/*      */         
/* 2433 */         return 0L;
/*      */       }
/*      */ 
/*      */       
/* 2437 */       if ((paramByte == 1 && i > 2) || (paramByte == 2 && i > 4))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2443 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 412);
/* 2444 */         sQLException.fillInStackTrace();
/* 2445 */         throw sQLException;
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 2452 */     else if (paramByte == 1) {
/* 2453 */       i = 2;
/* 2454 */     } else if (paramByte == 2) {
/* 2455 */       i = 4;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2463 */     byte[] arrayOfByte = new byte[i];
/*      */     
/* 2465 */     if (paramByteArrayInputStream.read(arrayOfByte) < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2470 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
/* 2471 */       sQLException.fillInStackTrace();
/* 2472 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2476 */     for (byte b = 0; b < arrayOfByte.length; b++) {
/*      */       short s;
/*      */       
/* 2479 */       if ((this.types.rep[paramByte] & 0x2) > 0) {
/* 2480 */         s = (short)(arrayOfByte[arrayOfByte.length - 1 - b] & 0xFF);
/*      */       } else {
/* 2482 */         s = (short)(arrayOfByte[b] & 0xFF);
/*      */       } 
/* 2484 */       l |= (s << 8 * (arrayOfByte.length - 1 - b));
/*      */     } 
/*      */ 
/*      */     
/* 2488 */     l &= 0xFFFFFFFFFFFFFFFFL;
/*      */     
/* 2490 */     if (bool) {
/* 2491 */       l = -l;
/*      */     }
/* 2493 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2508 */     return this.connForException.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConnectionDuringExceptionHandling(OracleConnection paramOracleConnection) {
/* 2519 */     this.connForException.set(paramOracleConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2524 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CMAREngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */