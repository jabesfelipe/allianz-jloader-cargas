/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CLongAccessor
/*     */   extends LongAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   static final int t4MaxLength = 2147483647;
/*     */   static final int t4PlsqlMaxLength = 32760;
/*  37 */   byte[][] data = (byte[][])null;
/*  38 */   int[] nbBytesRead = null;
/*  39 */   int[] bytesReadSoFar = null;
/*     */   final int[] escapeSequenceArr;
/*     */   final boolean[] readHeaderArr;
/*     */   final boolean[] readAsNonStreamArr;
/*     */   
/*     */   T4CLongAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  45 */     super(paramOracleStatement, paramInt1, paramInt2, paramShort, paramInt3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.escapeSequenceArr = new int[1];
/* 123 */     this.readHeaderArr = new boolean[1];
/* 124 */     this.readAsNonStreamArr = new boolean[1]; this.mare = paramT4CMAREngine; if (paramOracleStatement.connection.useFetchSizeWithLongColumn) { this.data = new byte[paramOracleStatement.rowPrefetch][]; for (byte b = 0; b < paramOracleStatement.rowPrefetch; b++) this.data[b] = new byte[4080];  this.nbBytesRead = new int[paramOracleStatement.rowPrefetch]; this.bytesReadSoFar = new int[paramOracleStatement.rowPrefetch]; }  } T4CLongAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort); this.escapeSequenceArr = new int[1]; this.readHeaderArr = new boolean[1]; this.readAsNonStreamArr = new boolean[1]; this.mare = paramT4CMAREngine; this.definedColumnType = paramInt8; this.definedColumnSize = paramInt9; if (paramOracleStatement.connection.useFetchSizeWithLongColumn) {
/*     */       this.data = new byte[paramOracleStatement.rowPrefetch][]; for (byte b = 0; b < paramOracleStatement.rowPrefetch; b++)
/*     */         this.data[b] = new byte[4080]; 
/*     */       this.nbBytesRead = new int[paramOracleStatement.rowPrefetch];
/*     */       this.bytesReadSoFar = new int[paramOracleStatement.rowPrefetch];
/*     */     }  }
/*     */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/* 139 */     }  } boolean unmarshalOneRow() throws SQLException, IOException { if (this.isUseLess) {
/*     */       
/* 141 */       this.lastRowProcessed++;
/*     */       
/* 143 */       return false;
/*     */     } 
/*     */     
/* 146 */     boolean bool = false;
/* 147 */     int i = this.indicatorIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     this.escapeSequenceArr[0] = this.mare.unmarshalUB1();
/*     */ 
/*     */     
/* 156 */     if (this.mare.escapeSequenceNull(this.escapeSequenceArr[0])) {
/*     */ 
/*     */ 
/*     */       
/* 160 */       this.rowSpaceIndicator[i] = -1;
/*     */       
/* 162 */       this.mare.processIndicator(false, 0);
/*     */       
/* 164 */       int j = (int)this.mare.unmarshalUB4();
/*     */       
/* 166 */       bool = false;
/*     */       
/* 168 */       this.escapeSequenceArr[0] = 0;
/* 169 */       this.lastRowProcessed++;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 175 */       this.rowSpaceIndicator[i] = 0;
/* 176 */       this.readHeaderArr[0] = true;
/* 177 */       this.readAsNonStreamArr[0] = false;
/*     */ 
/*     */       
/* 180 */       if (this.statement.connection.useFetchSizeWithLongColumn) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 185 */         int j = 0;
/*     */         
/* 187 */         while (j != -1) {
/*     */ 
/*     */ 
/*     */           
/* 191 */           if ((this.data[this.lastRowProcessed]).length < this.nbBytesRead[this.lastRowProcessed] + 255) {
/*     */ 
/*     */             
/* 194 */             byte[] arrayOfByte = new byte[(this.data[this.lastRowProcessed]).length * 4];
/*     */             
/* 196 */             System.arraycopy(this.data[this.lastRowProcessed], 0, arrayOfByte, 0, this.nbBytesRead[this.lastRowProcessed]);
/*     */ 
/*     */             
/* 199 */             this.data[this.lastRowProcessed] = arrayOfByte;
/*     */           } 
/*     */           
/* 202 */           j = readStreamFromWire(this.data[this.lastRowProcessed], this.nbBytesRead[this.lastRowProcessed], 255, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 208 */           if (this.statement.connection.calculateChecksum && j != -1) {
/*     */             
/* 210 */             long l = CRC64.updateChecksum(this.statement.checkSum, this.data[this.lastRowProcessed], this.nbBytesRead[this.lastRowProcessed], j);
/*     */ 
/*     */ 
/*     */             
/* 214 */             this.statement.checkSum = l;
/*     */           } 
/*     */           
/* 217 */           if (j != -1)
/*     */           {
/* 219 */             this.nbBytesRead[this.lastRowProcessed] = this.nbBytesRead[this.lastRowProcessed] + j;
/*     */           }
/*     */         } 
/*     */         
/* 223 */         this.lastRowProcessed++;
/*     */       }
/*     */       else {
/*     */         
/* 227 */         bool = true;
/*     */       } 
/*     */     } 
/*     */     
/* 231 */     return bool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void fetchNextColumns() throws SQLException {
/* 245 */     this.statement.continueReadRow(this.columnPosition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int readStream(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 264 */     int i = this.statement.currentRow;
/*     */     
/* 266 */     if (this.statement.connection.useFetchSizeWithLongColumn) {
/*     */       
/* 268 */       byte[] arrayOfByte = this.data[i];
/* 269 */       int k = this.nbBytesRead[i];
/* 270 */       int m = this.bytesReadSoFar[i];
/*     */       
/* 272 */       if (m == k) {
/* 273 */         return -1;
/*     */       }
/*     */       
/* 276 */       int n = 0;
/*     */       
/* 278 */       if (paramInt <= k - m) {
/* 279 */         n = paramInt;
/*     */       } else {
/* 281 */         n = k - m;
/*     */       } 
/* 283 */       System.arraycopy(arrayOfByte, m, paramArrayOfbyte, 0, n);
/*     */       
/* 285 */       this.bytesReadSoFar[i] = this.bytesReadSoFar[i] + n;
/*     */       
/* 287 */       return n;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 292 */     int j = readStreamFromWire(paramArrayOfbyte, 0, paramInt, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
/*     */ 
/*     */     
/* 295 */     if (this.statement.connection.calculateChecksum && j != -1) {
/*     */       
/* 297 */       long l = CRC64.updateChecksum(this.statement.checkSum, paramArrayOfbyte, 0, j);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 302 */       this.statement.checkSum = l;
/*     */     } 
/*     */ 
/*     */     
/* 306 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int readStreamFromWire(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, T4CMAREngine paramT4CMAREngine, T4CTTIoer paramT4CTTIoer) throws SQLException, IOException {
/* 334 */     int i = -1;
/*     */ 
/*     */     
/*     */     try {
/* 338 */       if (!paramArrayOfboolean2[0]) {
/*     */ 
/*     */ 
/*     */         
/* 342 */         if (paramInt2 > 255 || paramInt2 < 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 349 */           SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 433);
/* 350 */           sQLException.fillInStackTrace();
/* 351 */           throw sQLException;
/*     */         } 
/*     */ 
/*     */         
/* 355 */         if (paramArrayOfboolean1[0])
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 360 */           if (paramArrayOfint[0] == 254) {
/*     */             
/* 362 */             i = paramT4CMAREngine.unmarshalUB1();
/*     */           }
/*     */           else {
/*     */             
/* 366 */             if (paramArrayOfint[0] == 0) {
/*     */ 
/*     */               
/* 369 */               paramT4CTTIoer.connection.internalClose();
/*     */               
/* 371 */               SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 401);
/* 372 */               sQLException.fillInStackTrace();
/* 373 */               throw sQLException;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 379 */             paramArrayOfboolean2[0] = true;
/* 380 */             i = paramArrayOfint[0];
/*     */           } 
/*     */           
/* 383 */           paramArrayOfboolean1[0] = false;
/* 384 */           paramArrayOfint[0] = 0;
/*     */         }
/*     */         else
/*     */         {
/* 388 */           i = paramT4CMAREngine.unmarshalUB1();
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 395 */         paramArrayOfboolean2[0] = false;
/*     */       } 
/*     */ 
/*     */       
/* 399 */       if (i > 0) {
/*     */ 
/*     */ 
/*     */         
/* 403 */         paramT4CMAREngine.unmarshalNBytes(paramArrayOfbyte, paramInt1, i);
/*     */       }
/*     */       else {
/*     */         
/* 407 */         i = -1;
/*     */       } 
/* 409 */     } catch (BreakNetException breakNetException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 416 */       i = paramT4CMAREngine.unmarshalUB1();
/* 417 */       if (i == 4) {
/*     */         
/* 419 */         paramT4CTTIoer.init();
/* 420 */         paramT4CTTIoer.processError();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 425 */     if (i == -1) {
/*     */       
/* 427 */       paramArrayOfboolean1[0] = true;
/*     */ 
/*     */ 
/*     */       
/* 431 */       paramT4CMAREngine.unmarshalUB2();
/* 432 */       paramT4CMAREngine.unmarshalUB2();
/*     */     } 
/*     */     
/* 435 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 450 */     String str = super.getString(paramInt);
/*     */     
/* 452 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */     {
/* 454 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 456 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long updateChecksum(long paramLong, int paramInt) throws SQLException {
/* 465 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1)
/*     */     {
/* 467 */       paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 473 */     return paramLong;
/*     */   }
/*     */ 
/*     */   
/* 477 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CLongAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */