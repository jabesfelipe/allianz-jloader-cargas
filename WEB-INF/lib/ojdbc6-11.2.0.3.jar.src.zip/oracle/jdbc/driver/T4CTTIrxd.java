/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.SQLException;
/*     */ import java.util.BitSet;
/*     */ import java.util.Vector;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIrxd
/*     */   extends T4CTTIMsg
/*     */ {
/*  46 */   static final byte[] NO_BYTES = new byte[0];
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] buffer;
/*     */ 
/*     */   
/*     */   byte[] bufferCHAR;
/*     */ 
/*     */   
/*  56 */   BitSet bvcColSent = null;
/*  57 */   int nbOfColumns = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean bvcFound = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isFirstCol;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final byte TTICMD_UNAUTHORIZED = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CTTIrxd(T4CConnection paramT4CConnection) {
/*  78 */     super(paramT4CConnection, (byte)7);
/*     */     
/*  80 */     this.isFirstCol = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init() {
/*  87 */     this.isFirstCol = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setNumberOfColumns(int paramInt) {
/*  94 */     this.nbOfColumns = paramInt;
/*  95 */     this.bvcFound = false;
/*     */     
/*  97 */     if (this.bvcColSent == null || this.bvcColSent.length() < this.nbOfColumns) {
/*  98 */       this.bvcColSent = new BitSet(this.nbOfColumns);
/*     */     } else {
/* 100 */       this.bvcColSent.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unmarshalBVC(int paramInt) throws SQLException, IOException {
/* 108 */     byte b1 = 0;
/*     */     
/*     */     int i;
/* 111 */     for (i = 0; i < this.bvcColSent.length(); i++) {
/* 112 */       this.bvcColSent.clear(i);
/*     */     }
/*     */     
/* 115 */     i = this.nbOfColumns / 8 + ((this.nbOfColumns % 8 != 0) ? 1 : 0);
/*     */ 
/*     */     
/* 118 */     for (byte b2 = 0; b2 < i; b2++) {
/*     */       
/* 120 */       byte b = (byte)(this.meg.unmarshalUB1() & 0xFF);
/*     */       
/* 122 */       for (byte b3 = 0; b3 < 8; b3++) {
/*     */         
/* 124 */         if ((b & 1 << b3) != 0) {
/*     */           
/* 126 */           this.bvcColSent.set(b2 * 8 + b3);
/*     */           
/* 128 */           b1++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 133 */     if (b1 != paramInt) {
/*     */ 
/*     */       
/* 136 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.unmarshalBVC: bits missing in vector");
/*     */       
/* 138 */       sQLException.fillInStackTrace();
/* 139 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 143 */     this.bvcFound = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readBitVector(byte[] paramArrayOfbyte) throws SQLException, IOException {
/*     */     byte b;
/* 156 */     for (b = 0; b < this.bvcColSent.length(); b++) {
/* 157 */       this.bvcColSent.clear(b);
/*     */     }
/* 159 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 160 */       this.bvcFound = false;
/*     */     } else {
/*     */       
/* 163 */       for (b = 0; b < paramArrayOfbyte.length; b++) {
/* 164 */         byte b1 = paramArrayOfbyte[b];
/* 165 */         for (byte b2 = 0; b2 < 8; b2++) {
/* 166 */           if ((b1 & 1 << b2) != 0)
/* 167 */             this.bvcColSent.set(b * 8 + b2); 
/*     */         } 
/*     */       } 
/* 170 */       this.bvcFound = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Vector<IOException> marshal(byte[] paramArrayOfbyte1, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt1, byte[] paramArrayOfbyte2, DBConversion paramDBConversion, InputStream[] paramArrayOfInputStream, byte[][] paramArrayOfbyte, OracleTypeADT[] paramArrayOfOracleTypeADT, byte[] paramArrayOfbyte3, char[] paramArrayOfchar2, short[] paramArrayOfshort2, byte[] paramArrayOfbyte4, int paramInt2, int[] paramArrayOfint1, boolean paramBoolean, int[] paramArrayOfint2, int[] paramArrayOfint3, int[][] paramArrayOfint) throws IOException {
/* 198 */     Vector<IOException> vector = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 203 */       marshalTTCcode();
/*     */ 
/*     */       
/* 206 */       int i = paramArrayOfshort1[paramInt1 + 0] & 0xFFFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       byte b1 = 0;
/* 229 */       int j = paramArrayOfint3[0];
/* 230 */       int[] arrayOfInt = paramArrayOfint[0];
/*     */       
/* 232 */       byte b2 = 0;
/*     */       byte b3;
/* 234 */       for (b3 = 0; b3 < i; b3++) {
/*     */         
/* 236 */         if (b1 < j && arrayOfInt[b1] == b3) {
/*     */ 
/*     */           
/* 239 */           b1++;
/*     */           
/*     */           continue;
/*     */         } 
/* 243 */         boolean bool = false;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 248 */         int k = paramInt1 + 5 + 10 * b3;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 253 */         int i1 = paramArrayOfshort1[k + 0] & 0xFFFF;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 258 */         if (paramArrayOfbyte4 != null && (paramArrayOfbyte4[b3] & 0x20) == 0) {
/*     */ 
/*     */ 
/*     */           
/* 262 */           if (i1 == 998) {
/* 263 */             b2++;
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 268 */         int m = ((paramArrayOfshort1[k + 7] & 0xFFFF) << 16) + (paramArrayOfshort1[k + 8] & 0xFFFF) + paramInt2;
/*     */ 
/*     */ 
/*     */         
/* 272 */         int i2 = ((paramArrayOfshort1[k + 5] & 0xFFFF) << 16) + (paramArrayOfshort1[k + 6] & 0xFFFF) + paramInt2;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 277 */         int n = paramArrayOfshort1[m] & 0xFFFF;
/*     */         
/* 279 */         short s = paramArrayOfshort1[i2];
/*     */         
/* 281 */         if (i1 == 116) {
/*     */           
/* 283 */           this.meg.marshalUB1((short)1);
/* 284 */           this.meg.marshalUB1((short)0);
/*     */           
/*     */           continue;
/*     */         } 
/* 288 */         if (i1 == 994) {
/*     */           
/* 290 */           s = -1;
/* 291 */           int i3 = paramArrayOfint2[3 + b3 * 4 + 0];
/*     */ 
/*     */ 
/*     */           
/* 295 */           if (i3 == 109) {
/* 296 */             bool = true;
/*     */           }
/* 298 */         } else if (i1 == 8 || i1 == 24 || (!paramBoolean && paramArrayOfint1 != null && paramArrayOfint1.length > b3 && paramArrayOfint1[b3] > 4000)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 315 */           if (j >= arrayOfInt.length) {
/*     */             
/* 317 */             int[] arrayOfInt1 = new int[arrayOfInt.length << 1];
/*     */ 
/*     */             
/* 320 */             System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
/*     */ 
/*     */ 
/*     */             
/* 324 */             arrayOfInt = arrayOfInt1;
/*     */           } 
/*     */           
/* 327 */           arrayOfInt[j++] = b3;
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/* 335 */         if (s == -1) {
/*     */           
/* 337 */           if (i1 == 109 || bool) {
/*     */ 
/*     */             
/* 340 */             this.meg.marshalDALC(NO_BYTES);
/* 341 */             this.meg.marshalDALC(NO_BYTES);
/* 342 */             this.meg.marshalDALC(NO_BYTES);
/* 343 */             this.meg.marshalUB2(0);
/* 344 */             this.meg.marshalUB4(0L);
/* 345 */             this.meg.marshalUB2(1);
/*     */             
/*     */             continue;
/*     */           } 
/* 349 */           if (i1 == 998) {
/*     */             
/* 351 */             b2++;
/* 352 */             this.meg.marshalUB4(0L);
/*     */             continue;
/*     */           } 
/* 355 */           if (i1 == 112 || i1 == 113 || i1 == 114) {
/*     */             
/* 357 */             this.meg.marshalUB4(0L);
/*     */             continue;
/*     */           } 
/* 360 */           if (i1 != 8 && i1 != 24) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 369 */             this.meg.marshalUB1((short)0);
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } 
/*     */         
/* 375 */         if (i1 == 998) {
/*     */ 
/*     */           
/* 378 */           int i3 = (paramArrayOfshort2[6 + b2 * 8 + 4] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfshort2[6 + b2 * 8 + 5] & 0xFFFF;
/*     */ 
/*     */           
/* 381 */           int i4 = (paramArrayOfshort2[6 + b2 * 8 + 6] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfshort2[6 + b2 * 8 + 7] & 0xFFFF;
/*     */ 
/*     */           
/* 384 */           int i5 = paramArrayOfshort2[6 + b2 * 8] & 0xFFFF;
/* 385 */           int i6 = paramArrayOfshort2[6 + b2 * 8 + 1] & 0xFFFF;
/*     */           
/* 387 */           this.meg.marshalUB4(i3);
/*     */           
/* 389 */           for (byte b = 0; b < i3; b++) {
/*     */             
/* 391 */             int i7 = i4 + b * i6;
/*     */             
/* 393 */             if (i5 == 9) {
/*     */               
/* 395 */               int i8 = paramArrayOfchar2[i7] / 2;
/* 396 */               int i9 = 0;
/* 397 */               i9 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar2, i7 + 1, paramArrayOfbyte2, 0, i8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 403 */               this.meg.marshalCLR(paramArrayOfbyte2, i9);
/*     */             }
/*     */             else {
/*     */               
/* 407 */               n = paramArrayOfbyte3[i7];
/*     */               
/* 409 */               if (n < 1) {
/* 410 */                 this.meg.marshalUB1((short)0);
/*     */               } else {
/* 412 */                 this.meg.marshalCLR(paramArrayOfbyte3, i7 + 1, n);
/*     */               } 
/*     */             } 
/*     */           } 
/* 416 */           b2++;
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 425 */           int i3 = paramArrayOfshort1[k + 1] & 0xFFFF;
/*     */ 
/*     */ 
/*     */           
/* 429 */           if (i3 != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 435 */             int i4 = ((paramArrayOfshort1[k + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[k + 4] & 0xFFFF) + i3 * paramInt2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 442 */             if (i1 == 6) {
/*     */               
/* 444 */               i4++;
/* 445 */               n--;
/*     */             }
/* 447 */             else if (i1 == 9) {
/*     */               
/* 449 */               i4 += 2;
/*     */               
/* 451 */               n -= 2;
/*     */             }
/* 453 */             else if (i1 == 114 || i1 == 113 || i1 == 112) {
/*     */ 
/*     */               
/* 456 */               this.meg.marshalUB4(n);
/*     */             } 
/*     */ 
/*     */             
/* 460 */             if (i1 == 109 || i1 == 111) {
/*     */               
/* 462 */               if (paramArrayOfbyte == null) {
/*     */ 
/*     */                 
/* 465 */                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.marshal: parameterDatum is null");
/*     */                 
/* 467 */                 sQLException.fillInStackTrace();
/* 468 */                 throw sQLException;
/*     */               } 
/*     */ 
/*     */               
/* 472 */               byte[] arrayOfByte = paramArrayOfbyte[b3];
/*     */               
/* 474 */               n = (arrayOfByte == null) ? 0 : arrayOfByte.length;
/*     */               
/* 476 */               if (i1 == 109) {
/*     */                 
/* 478 */                 this.meg.marshalDALC(NO_BYTES);
/* 479 */                 this.meg.marshalDALC(NO_BYTES);
/* 480 */                 this.meg.marshalDALC(NO_BYTES);
/* 481 */                 this.meg.marshalUB2(0);
/*     */                 
/* 483 */                 this.meg.marshalUB4(n);
/* 484 */                 this.meg.marshalUB2(1);
/*     */               } 
/*     */               
/* 487 */               if (n > 0) {
/* 488 */                 this.meg.marshalCLR(arrayOfByte, 0, n);
/*     */               }
/* 490 */             } else if (i1 == 104) {
/*     */ 
/*     */ 
/*     */               
/* 494 */               i4 += 2;
/*     */               
/* 496 */               long[] arrayOfLong = T4CRowidAccessor.stringToRowid(paramArrayOfbyte1, i4, 18);
/*     */               
/* 498 */               byte b = 14;
/* 499 */               long l1 = arrayOfLong[0];
/* 500 */               int i5 = (int)arrayOfLong[1];
/* 501 */               boolean bool1 = false;
/* 502 */               long l2 = arrayOfLong[2];
/* 503 */               int i6 = (int)arrayOfLong[3];
/*     */ 
/*     */               
/* 506 */               if (l1 == 0L && i5 == 0 && l2 == 0L && i6 == 0)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 512 */                 this.meg.marshalUB1((short)0);
/*     */               }
/*     */               else
/*     */               {
/* 516 */                 this.meg.marshalUB1(b);
/* 517 */                 this.meg.marshalUB4(l1);
/* 518 */                 this.meg.marshalUB2(i5);
/* 519 */                 this.meg.marshalUB1(bool1);
/* 520 */                 this.meg.marshalUB4(l2);
/* 521 */                 this.meg.marshalUB2(i6);
/*     */               }
/*     */             
/* 524 */             } else if (i1 == 208) {
/*     */ 
/*     */ 
/*     */               
/* 528 */               i4 += 2;
/* 529 */               n -= 2;
/* 530 */               this.meg.marshalUB4(n);
/* 531 */               this.meg.marshalCLR(paramArrayOfbyte1, i4, n);
/*     */ 
/*     */             
/*     */             }
/* 535 */             else if (n < 1) {
/* 536 */               this.meg.marshalUB1((short)0);
/*     */             } else {
/* 538 */               this.meg.marshalCLR(paramArrayOfbyte1, i4, n);
/*     */ 
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 548 */             int i6 = paramArrayOfshort1[k + 9] & 0xFFFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 555 */             int i4 = paramArrayOfshort1[k + 2] & 0xFFFF;
/*     */ 
/*     */             
/* 558 */             int i5 = ((paramArrayOfshort1[k + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[k + 4] & 0xFFFF) + i4 * paramInt2 + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 563 */             if (i1 == 996) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 572 */               char c = paramArrayOfchar1[i5 - 1];
/*     */               
/* 574 */               if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
/* 575 */                 this.bufferCHAR = new byte[c];
/*     */               }
/* 577 */               for (byte b = 0; b < c; b++) {
/*     */                 
/* 579 */                 this.bufferCHAR[b] = (byte)((paramArrayOfchar1[i5 + b / 2] & 0xFF00) >> 8 & 0xFF);
/*     */ 
/*     */ 
/*     */                 
/* 583 */                 if (b < c - 1) {
/*     */                   
/* 585 */                   this.bufferCHAR[b + 1] = (byte)(paramArrayOfchar1[i5 + b / 2] & 0xFF & 0xFF);
/*     */ 
/*     */                   
/* 588 */                   b++;
/*     */                 } 
/*     */               } 
/*     */               
/* 592 */               this.meg.marshalCLR(this.bufferCHAR, c);
/*     */               
/* 594 */               if (this.bufferCHAR.length > 4000) {
/* 595 */                 this.bufferCHAR = null;
/*     */               }
/*     */             } else {
/*     */               int i7;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 606 */               if (i1 == 96) {
/*     */ 
/*     */ 
/*     */                 
/* 610 */                 i7 = n / 2;
/* 611 */                 i5--;
/*     */               }
/*     */               else {
/*     */                 
/* 615 */                 i7 = (n - 2) / 2;
/*     */               } 
/*     */ 
/*     */               
/* 619 */               int i8 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 624 */               if (i6 == 2) {
/*     */                 
/* 626 */                 i8 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfchar1, i5, paramArrayOfbyte2, 0, i7);
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 631 */                 i8 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar1, i5, paramArrayOfbyte2, 0, i7);
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 637 */               this.meg.marshalCLR(paramArrayOfbyte2, i8);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 647 */       if (j > 0)
/*     */       {
/* 649 */         for (b3 = 0; b3 < j; b3++) {
/*     */           
/* 651 */           int i5 = arrayOfInt[b3];
/*     */           
/* 653 */           int k = paramInt1 + 5 + 10 * i5;
/*     */ 
/*     */ 
/*     */           
/* 657 */           int i3 = paramArrayOfshort1[k + 0] & 0xFFFF;
/*     */ 
/*     */ 
/*     */           
/* 661 */           int m = ((paramArrayOfshort1[k + 7] & 0xFFFF) << 16) + (paramArrayOfshort1[k + 8] & 0xFFFF) + paramInt2;
/*     */ 
/*     */ 
/*     */           
/* 665 */           int i4 = ((paramArrayOfshort1[k + 5] & 0xFFFF) << 16) + (paramArrayOfshort1[k + 6] & 0xFFFF) + paramInt2;
/*     */ 
/*     */ 
/*     */           
/* 669 */           short s = paramArrayOfshort1[i4];
/* 670 */           int n = paramArrayOfshort1[m] & 0xFFFF;
/*     */           
/* 672 */           int i1 = paramArrayOfshort1[k + 2] & 0xFFFF;
/*     */ 
/*     */           
/* 675 */           int i2 = ((paramArrayOfshort1[k + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[k + 4] & 0xFFFF) + i1 * paramInt2 + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 680 */           if (s == -1) {
/*     */             
/* 682 */             this.meg.marshalUB1((short)0);
/*     */ 
/*     */           
/*     */           }
/* 686 */           else if (i3 == 996) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 695 */             char c = paramArrayOfchar1[i2 - 1];
/*     */             
/* 697 */             if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
/* 698 */               this.bufferCHAR = new byte[c];
/*     */             }
/* 700 */             for (byte b = 0; b < c; b++) {
/*     */               
/* 702 */               this.bufferCHAR[b] = (byte)((paramArrayOfchar1[i2 + b / 2] & 0xFF00) >> 8 & 0xFF);
/*     */ 
/*     */ 
/*     */               
/* 706 */               if (b < c - 1) {
/*     */                 
/* 708 */                 this.bufferCHAR[b + 1] = (byte)(paramArrayOfchar1[i2 + b / 2] & 0xFF & 0xFF);
/*     */                 
/* 710 */                 b++;
/*     */               } 
/*     */             } 
/*     */             
/* 714 */             this.meg.marshalCLR(this.bufferCHAR, c);
/*     */             
/* 716 */             if (this.bufferCHAR.length > 4000) {
/* 717 */               this.bufferCHAR = null;
/*     */             }
/* 719 */           } else if (i3 != 8 && i3 != 24) {
/*     */             int i6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 726 */             if (i3 == 96) {
/*     */ 
/*     */ 
/*     */               
/* 730 */               i6 = n / 2;
/* 731 */               i2--;
/*     */             }
/*     */             else {
/*     */               
/* 735 */               i6 = (n - 2) / 2;
/*     */             } 
/*     */             
/* 738 */             int i7 = paramArrayOfshort1[k + 9] & 0xFFFF;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 743 */             int i8 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 748 */             if (i7 == 2) {
/*     */               
/* 750 */               i8 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfchar1, i2, paramArrayOfbyte2, 0, i6);
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 755 */               i8 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar1, i2, paramArrayOfbyte2, 0, i6);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 761 */             this.meg.marshalCLR(paramArrayOfbyte2, i8);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 766 */             int i6 = i5;
/*     */ 
/*     */             
/* 769 */             if (paramArrayOfInputStream != null) {
/*     */               
/* 771 */               InputStream inputStream = paramArrayOfInputStream[i6];
/*     */               
/* 773 */               if (inputStream != null) {
/*     */ 
/*     */ 
/*     */                 
/* 777 */                 byte b = 64;
/*     */                 
/* 779 */                 if (this.buffer == null) {
/* 780 */                   this.buffer = new byte[b];
/*     */                 }
/* 782 */                 int i7 = 0;
/*     */ 
/*     */                 
/* 785 */                 this.meg.marshalUB1((short)254);
/*     */                 
/* 787 */                 boolean bool = false;
/*     */                 
/* 789 */                 while (!bool && !this.connection.sentCancel) {
/*     */                   
/*     */                   try {
/* 792 */                     i7 = inputStream.read(this.buffer, 0, b);
/* 793 */                   } catch (IOException iOException) {
/* 794 */                     i7 = -1;
/* 795 */                     if (vector == null)
/* 796 */                       vector = new Vector(); 
/* 797 */                     vector.add(iOException);
/*     */                   } 
/*     */                   
/* 800 */                   if (i7 == -1) {
/* 801 */                     bool = true;
/*     */                   }
/* 803 */                   if (i7 > 0) {
/*     */ 
/*     */ 
/*     */                     
/* 807 */                     this.meg.marshalUB1((short)(i7 & 0xFF));
/*     */ 
/*     */                     
/* 810 */                     this.meg.marshalB1Array(this.buffer, 0, i7);
/*     */                   } 
/*     */                 } 
/*     */ 
/*     */                 
/* 815 */                 this.meg.marshalUB1((short)0);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 832 */       paramArrayOfint3[0] = j;
/* 833 */       paramArrayOfint[0] = arrayOfInt;
/*     */     }
/* 835 */     catch (SQLException sQLException) {
/*     */       
/* 837 */       IOException iOException = new IOException();
/* 838 */       iOException.initCause(sQLException);
/* 839 */       throw iOException;
/*     */     } 
/*     */     
/* 842 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt) throws SQLException, IOException {
/* 853 */     return unmarshal(paramArrayOfAccessor, 0, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 870 */     if (paramInt1 == 0) {
/* 871 */       this.isFirstCol = true;
/*     */     }
/* 873 */     for (int i = paramInt1; i < paramInt2 && i < paramArrayOfAccessor.length; i++) {
/*     */       
/* 875 */       if (paramArrayOfAccessor[i] != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 892 */         if ((paramArrayOfAccessor[i]).physicalColumnIndex < 0) {
/*     */ 
/*     */ 
/*     */           
/* 896 */           byte b1 = 0;
/*     */           
/* 898 */           for (byte b2 = 0; b2 < paramInt2 && b2 < paramArrayOfAccessor.length; b2++) {
/*     */             
/* 900 */             if (paramArrayOfAccessor[b2] != null) {
/*     */               
/* 902 */               (paramArrayOfAccessor[b2]).physicalColumnIndex = b1;
/*     */               
/* 904 */               if (!(paramArrayOfAccessor[b2]).isUseLess) {
/* 905 */                 b1++;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/* 910 */         if (this.bvcFound && !(paramArrayOfAccessor[i]).isUseLess && !this.bvcColSent.get((paramArrayOfAccessor[i]).physicalColumnIndex)) {
/*     */ 
/*     */ 
/*     */           
/* 914 */           paramArrayOfAccessor[i].copyRow();
/*     */         }
/*     */         else {
/*     */           
/* 918 */           byte b = 0;
/*     */ 
/*     */ 
/*     */           
/* 922 */           if ((paramArrayOfAccessor[i]).statement.statementType != 2 && !(paramArrayOfAccessor[i]).statement.sqlKind.isPlsqlOrCall()) {
/*     */ 
/*     */             
/* 925 */             int j = (paramArrayOfAccessor[i]).metaDataIndex + (paramArrayOfAccessor[i]).lastRowProcessed * 1;
/*     */             
/* 927 */             if ((paramArrayOfAccessor[i]).securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) {
/* 928 */               b = (byte)this.meg.unmarshalUB1();
/*     */             }
/* 930 */             (paramArrayOfAccessor[i]).rowSpaceMetaData[j] = b;
/*     */           } 
/*     */           
/* 933 */           if (paramArrayOfAccessor[i].unmarshalOneRow()) {
/* 934 */             return true;
/*     */           }
/* 936 */           this.isFirstCol = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 941 */     this.bvcFound = false;
/*     */     
/* 943 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2, int paramInt3) throws SQLException, IOException {
/* 952 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 967 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 972 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CTTIrxd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */