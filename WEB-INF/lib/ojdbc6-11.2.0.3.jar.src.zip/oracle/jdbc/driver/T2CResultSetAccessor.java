/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class T2CResultSetAccessor
/*    */   extends ResultSetAccessor
/*    */ {
/*    */   T2CResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/* 20 */     super(paramOracleStatement, paramInt1 * 2, paramShort, paramInt2, paramBoolean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   T2CResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/* 27 */     super(paramOracleStatement, paramInt1 * 2, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getBytes(int paramInt) throws SQLException {
/* 41 */     byte[] arrayOfByte = null;
/*    */     
/* 43 */     if (this.rowSpaceIndicator == null) {
/*    */ 
/*    */ 
/*    */       
/* 47 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 48 */       sQLException.fillInStackTrace();
/* 49 */       throw sQLException;
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 54 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*    */       
/* 56 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 57 */       byte b = ((T2CConnection)this.statement.connection).byteAlign;
/* 58 */       int i = this.columnIndex + b - 1 & (b - 1 ^ 0xFFFFFFFF);
/*    */       
/* 60 */       int j = i + s * paramInt;
/*    */       
/* 62 */       arrayOfByte = new byte[s];
/* 63 */       System.arraycopy(this.rowSpaceByte, j, arrayOfByte, 0, s);
/*    */     } 
/*    */     
/* 66 */     return arrayOfByte;
/*    */   }
/*    */ 
/*    */   
/* 70 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T2CResultSetAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */