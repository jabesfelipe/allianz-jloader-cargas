/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.OracleResultSetCache;
/*      */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleStatement
/*      */   implements OracleStatement, ScrollRsetStatement
/*      */ {
/*      */   static final int PLAIN_STMT = 0;
/*      */   static final int PREP_STMT = 1;
/*      */   static final int CALL_STMT = 2;
/*      */   int cursorId;
/*      */   int numberOfDefinePositions;
/*      */   int definesBatchSize;
/*      */   Accessor[] accessors;
/*      */   int defineByteSubRange;
/*      */   int defineCharSubRange;
/*      */   int defineIndicatorSubRange;
/*      */   int defineLengthSubRange;
/*      */   byte[] defineBytes;
/*      */   char[] defineChars;
/*      */   short[] defineIndicators;
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*  292 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "continueReadRow is only implemented by the T4C statements.");
/*  293 */     sQLException.fillInStackTrace();
/*  294 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int cursorIfRefCursor() throws SQLException {
/*  330 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "cursorIfRefCursor not implemented");
/*  331 */     sQLException.fillInStackTrace();
/*  332 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean described = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean describedWithNames = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] defineMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int defineMetaDataSubRange;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int METADATALENGTH = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int rowsProcessed;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  373 */   int cachedDefineByteSize = 0;
/*  374 */   int cachedDefineCharSize = 0;
/*  375 */   int cachedDefineIndicatorSize = 0;
/*  376 */   int cachedDefineMetaDataSize = 0;
/*      */ 
/*      */   
/*  379 */   OracleStatement children = null;
/*  380 */   OracleStatement parent = null;
/*      */ 
/*      */   
/*  383 */   OracleStatement nextChild = null;
/*      */ 
/*      */   
/*      */   OracleStatement next;
/*      */ 
/*      */   
/*      */   OracleStatement prev;
/*      */ 
/*      */   
/*      */   long c_state;
/*      */ 
/*      */   
/*      */   int numberOfBindPositions;
/*      */ 
/*      */   
/*      */   byte[] bindBytes;
/*      */ 
/*      */   
/*      */   char[] bindChars;
/*      */ 
/*      */   
/*      */   short[] bindIndicators;
/*      */ 
/*      */   
/*      */   int bindByteOffset;
/*      */ 
/*      */   
/*      */   int bindCharOffset;
/*      */ 
/*      */   
/*      */   int bindIndicatorOffset;
/*      */ 
/*      */   
/*      */   int bindByteSubRange;
/*      */ 
/*      */   
/*      */   int bindCharSubRange;
/*      */ 
/*      */   
/*      */   int bindIndicatorSubRange;
/*      */ 
/*      */   
/*      */   Accessor[] outBindAccessors;
/*      */   
/*      */   InputStream[][] parameterStream;
/*      */   
/*      */   Object[][] userStream;
/*      */   
/*      */   int firstRowInBatch;
/*      */   
/*      */   boolean hasIbtBind = false;
/*      */   
/*      */   byte[] ibtBindBytes;
/*      */   
/*      */   char[] ibtBindChars;
/*      */   
/*      */   short[] ibtBindIndicators;
/*      */   
/*      */   int ibtBindByteOffset;
/*      */   
/*      */   int ibtBindCharOffset;
/*      */   
/*      */   int ibtBindIndicatorOffset;
/*      */   
/*      */   int ibtBindIndicatorSize;
/*      */   
/*  449 */   ByteBuffer[] nioBuffers = null;
/*  450 */   Object[] lobPrefetchMetaData = null;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean hasStream;
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] tmpByteArray;
/*      */ 
/*      */   
/*  461 */   int sizeTmpByteArray = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] tmpBindsByteArray;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean needToSendOalToFetch = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  476 */   int[] definedColumnType = null;
/*  477 */   int[] definedColumnSize = null;
/*  478 */   int[] definedColumnFormOfUse = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  484 */   T4CTTIoac[] oacdefSent = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  491 */   int[] nbPostPonedColumns = null;
/*  492 */   int[][] indexOfPostPonedColumn = (int[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean aFetchWasDoneDuringDescribe = false;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean implicitDefineForLobPrefetchDone = false;
/*      */ 
/*      */ 
/*      */   
/*  505 */   long checkSum = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean checkSumComputationFailure = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  528 */   int accessorByteOffset = 0;
/*  529 */   int accessorCharOffset = 0;
/*  530 */   int accessorShortOffset = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int VALID_ROWS_UNINIT = -999;
/*      */ 
/*      */ 
/*      */   
/*      */   PhysicalConnection connection;
/*      */ 
/*      */   
/*      */   OracleInputStream streamList;
/*      */ 
/*      */   
/*      */   OracleInputStream nextStream;
/*      */ 
/*      */   
/*      */   OracleResultSetImpl currentResultSet;
/*      */ 
/*      */   
/*      */   boolean processEscapes;
/*      */ 
/*      */   
/*      */   boolean convertNcharLiterals;
/*      */ 
/*      */   
/*      */   int queryTimeout;
/*      */ 
/*      */   
/*      */   int batch;
/*      */ 
/*      */   
/*  562 */   int numberOfExecutedElementsInBatch = -1;
/*      */   
/*      */   int currentRank;
/*      */   
/*      */   int currentRow;
/*      */   
/*      */   int validRows;
/*      */   
/*      */   int maxFieldSize;
/*      */   
/*      */   int maxRows;
/*      */   
/*      */   int totalRowsVisited;
/*      */   
/*      */   int rowPrefetch;
/*      */   
/*  578 */   int rowPrefetchInLastFetch = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int defaultRowPrefetch;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean rowPrefetchChanged;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int defaultLobPrefetchSize;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean gotLastBatch;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean clearParameters;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean closed;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean sqlStringChanged;
/*      */ 
/*      */ 
/*      */   
/*      */   OracleSql sqlObject;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean needToParse;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean needToPrepareDefineBuffer;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean columnsDefinedByUser;
/*      */ 
/*      */ 
/*      */   
/*  629 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.SELECT;
/*  630 */   byte sqlKindByte = 1;
/*      */ 
/*      */   
/*      */   int autoRollback;
/*      */ 
/*      */   
/*      */   int defaultFetchDirection;
/*      */ 
/*      */   
/*      */   boolean serverCursor;
/*      */ 
/*      */   
/*      */   boolean fixedString = false;
/*      */ 
/*      */   
/*      */   boolean noMoreUpdateCounts = false;
/*      */ 
/*      */   
/*      */   boolean isExecuting = false;
/*      */ 
/*      */   
/*      */   OracleStatementWrapper wrapper;
/*      */ 
/*      */   
/*      */   static final byte EXECUTE_NONE = -1;
/*      */ 
/*      */   
/*      */   static final byte EXECUTE_QUERY = 1;
/*      */   
/*      */   static final byte EXECUTE_UPDATE = 2;
/*      */   
/*      */   static final byte EXECUTE_NORMAL = 3;
/*      */   
/*  663 */   byte executionType = -1;
/*      */ 
/*      */   
/*      */   OracleResultSet scrollRset;
/*      */ 
/*      */   
/*      */   OracleResultSetCache rsetCache;
/*      */   
/*      */   int userRsetType;
/*      */   
/*      */   int realRsetType;
/*      */   
/*      */   boolean needToAddIdentifier;
/*      */   
/*      */   SQLWarning sqlWarning;
/*      */   
/*  679 */   int cacheState = 3;
/*      */ 
/*      */   
/*  682 */   int creationState = 0;
/*      */ 
/*      */   
/*      */   boolean isOpen = false;
/*      */ 
/*      */   
/*  688 */   int statementType = 0;
/*      */   
/*      */   boolean columnSetNull = false;
/*      */   
/*      */   int[] returnParamMeta;
/*      */   
/*      */   static final int DMLR_METADATA_PREFIX_SIZE = 3;
/*      */   
/*      */   static final int DMLR_METADATA_NUM_OF_RETURN_PARAMS = 0;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_BYTES = 1;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_CHARS = 2;
/*      */   
/*      */   static final int DMLR_METADATA_TYPE_OFFSET = 0;
/*      */   
/*      */   static final int DMLR_METADATA_IS_CHAR_TYPE_OFFSET = 1;
/*      */   
/*      */   static final int DMLR_METADATA_BIND_SIZE_OFFSET = 2;
/*      */   
/*      */   static final int DMLR_METADATA_FORM_OF_USE_OFFSET = 3;
/*      */   
/*      */   static final int DMLR_METADATA_PER_POSITION_SIZE = 4;
/*      */   
/*      */   Accessor[] returnParamAccessors;
/*      */   
/*      */   boolean returnParamsFetched;
/*      */   
/*      */   int rowsDmlReturned;
/*      */   
/*      */   int numReturnParams;
/*      */   
/*      */   byte[] returnParamBytes;
/*      */   
/*      */   char[] returnParamChars;
/*      */   
/*      */   short[] returnParamIndicators;
/*      */   
/*      */   int returnParamRowBytes;
/*      */   
/*      */   int returnParamRowChars;
/*      */   OracleReturnResultSet returnResultSet;
/*      */   boolean isAutoGeneratedKey;
/*      */   AutoKeyInfo autoKeyInfo;
/*  732 */   TimeZone defaultTimeZone = null;
/*  733 */   String defaultTimeZoneName = null;
/*      */   
/*  735 */   Calendar defaultCalendar = null;
/*  736 */   Calendar gmtCalendar = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  748 */   long inScn = 0L; int lastIndex; Vector m_batchItems; ArrayList tempClobsToFree; ArrayList tempBlobsToFree; ArrayList oldTempClobsToFree; ArrayList oldTempBlobsToFree; NTFDCNRegistration registration; String[] dcnTableName; long dcnQueryId; static final byte IS_UNINITIALIZED = 0; static final byte IS_SELECT = 1; static final byte IS_DELETE = 2; static final byte IS_INSERT = 4; static final byte IS_MERGE = 8; static final byte IS_UPDATE = 16; static final byte IS_PLSQL_BLOCK = 32; static final byte IS_CALL_BLOCK = 64; static final byte IS_OTHER = -128; static final byte IS_DML = 30;
/*      */   static final byte IS_PLSQL = 96;
/*      */   
/*      */   public void setSnapshotSCN(long paramLong) throws SQLException {
/*  752 */     doSetSnapshotSCN(paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  758 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  759 */     sQLException.fillInStackTrace();
/*  760 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2) throws SQLException {
/*  782 */     this(paramPhysicalConnection, paramInt1, paramInt2, -1, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initializeDefineSubRanges() {
/*  882 */     this.defineByteSubRange = 0;
/*  883 */     this.defineCharSubRange = 0;
/*  884 */     this.defineIndicatorSubRange = 0;
/*  885 */     this.defineMetaDataSubRange = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareDefinePreambles() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareAccessors() throws SQLException {
/*  918 */     byte[] arrayOfByte1 = null;
/*  919 */     char[] arrayOfChar = null;
/*  920 */     short[] arrayOfShort = null;
/*  921 */     boolean bool = false;
/*  922 */     byte[] arrayOfByte2 = null;
/*      */     
/*  924 */     if (this.accessors == null) {
/*      */       
/*  926 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  927 */       sQLException.fillInStackTrace();
/*  928 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  934 */     int i = 0;
/*  935 */     int j = 0;
/*  936 */     int k = 0; int m;
/*  937 */     for (m = 0; m < this.numberOfDefinePositions; m++) {
/*      */       
/*  939 */       Accessor accessor = this.accessors[m];
/*      */       
/*  941 */       if (accessor == null) {
/*      */         
/*  943 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  944 */         sQLException.fillInStackTrace();
/*  945 */         throw sQLException;
/*      */       } 
/*  947 */       switch (accessor.internalType) {
/*      */         
/*      */         case 8:
/*      */         case 24:
/*  951 */           this.hasStream = true;
/*      */           break;
/*      */       } 
/*      */       
/*  955 */       i += accessor.byteLength;
/*  956 */       j += accessor.charLength;
/*  957 */       k++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  962 */     if (this.streamList != null && !this.connection.useFetchSizeWithLongColumn) {
/*  963 */       this.rowPrefetch = 1;
/*      */     }
/*  965 */     m = this.rowPrefetch;
/*      */     
/*  967 */     this.definesBatchSize = m;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  975 */     initializeDefineSubRanges();
/*      */ 
/*      */     
/*  978 */     int n = k * m;
/*  979 */     if (this.defineMetaData == null || this.defineMetaData.length < n) {
/*      */       
/*  981 */       if (this.defineMetaData != null)
/*  982 */         arrayOfByte2 = this.defineMetaData; 
/*  983 */       this.defineMetaData = new byte[n];
/*      */     } 
/*      */ 
/*      */     
/*  987 */     this.cachedDefineByteSize = this.defineByteSubRange + i * m;
/*      */     
/*  989 */     if (this.defineBytes == null || this.defineBytes.length < this.cachedDefineByteSize) {
/*      */       
/*  991 */       if (this.defineBytes != null) arrayOfByte1 = this.defineBytes; 
/*  992 */       this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
/*      */     } 
/*      */     
/*  995 */     this.defineByteSubRange += this.accessorByteOffset;
/*      */ 
/*      */     
/*  998 */     this.cachedDefineCharSize = this.defineCharSubRange + j * m;
/*      */     
/* 1000 */     if ((this.defineChars == null || this.defineChars.length < this.cachedDefineCharSize) && this.cachedDefineCharSize > 0) {
/*      */ 
/*      */       
/* 1003 */       if (this.defineChars != null) arrayOfChar = this.defineChars;
/*      */       
/* 1005 */       this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
/*      */     } 
/*      */     
/* 1008 */     this.defineCharSubRange += this.accessorCharOffset;
/*      */ 
/*      */ 
/*      */     
/* 1012 */     int i1 = this.numberOfDefinePositions * m;
/* 1013 */     int i2 = this.defineIndicatorSubRange + i1 + i1;
/*      */ 
/*      */     
/* 1016 */     if (this.defineIndicators == null || this.defineIndicators.length < i2) {
/*      */ 
/*      */       
/* 1019 */       if (this.defineIndicators != null) arrayOfShort = this.defineIndicators; 
/* 1020 */       this.defineIndicators = new short[i2];
/* 1021 */     } else if (this.defineIndicators.length >= i2) {
/*      */       
/* 1023 */       bool = true;
/* 1024 */       arrayOfShort = this.defineIndicators;
/*      */     } 
/*      */     
/* 1027 */     this.defineIndicatorSubRange += this.accessorShortOffset;
/*      */     
/* 1029 */     int i3 = this.defineIndicatorSubRange + i1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1035 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */       
/* 1037 */       Accessor accessor = this.accessors[b];
/*      */       
/* 1039 */       accessor.lengthIndexLastRow = accessor.lengthIndex;
/* 1040 */       accessor.indicatorIndexLastRow = accessor.indicatorIndex;
/* 1041 */       accessor.columnIndexLastRow = accessor.columnIndex;
/*      */       
/* 1043 */       accessor.setOffsets(m);
/*      */       
/* 1045 */       accessor.lengthIndex = i3;
/* 1046 */       accessor.indicatorIndex = this.defineIndicatorSubRange;
/* 1047 */       accessor.metaDataIndex = this.defineMetaDataSubRange;
/* 1048 */       accessor.rowSpaceByte = this.defineBytes;
/* 1049 */       accessor.rowSpaceChar = this.defineChars;
/* 1050 */       accessor.rowSpaceIndicator = this.defineIndicators;
/* 1051 */       accessor.rowSpaceMetaData = this.defineMetaData;
/* 1052 */       this.defineIndicatorSubRange += m;
/* 1053 */       i3 += m;
/* 1054 */       this.defineMetaDataSubRange += m * 1;
/*      */     } 
/*      */     
/* 1057 */     prepareDefinePreambles();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1065 */     if (this.rowPrefetchInLastFetch != -1 && this.rowPrefetch != this.rowPrefetchInLastFetch) {
/*      */       
/* 1067 */       if (arrayOfChar == null) arrayOfChar = this.defineChars; 
/* 1068 */       if (arrayOfByte1 == null) arrayOfByte1 = this.defineBytes; 
/* 1069 */       if (arrayOfShort == null) arrayOfShort = this.defineIndicators; 
/* 1070 */       saveDefineBuffersIfRequired(arrayOfChar, arrayOfByte1, arrayOfShort, bool);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean checkAccessorsUsable() throws SQLException {
/* 1086 */     int i = this.accessors.length;
/*      */     
/* 1088 */     if (i < this.numberOfDefinePositions) {
/* 1089 */       return false;
/*      */     }
/* 1091 */     boolean bool1 = true;
/* 1092 */     boolean bool2 = false;
/* 1093 */     boolean bool3 = false;
/*      */     
/* 1095 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */       
/* 1097 */       Accessor accessor = this.accessors[b];
/*      */       
/* 1099 */       if (accessor == null || accessor.externalType == 0) {
/* 1100 */         bool1 = false;
/*      */       } else {
/* 1102 */         bool2 = true;
/*      */       } 
/*      */     } 
/* 1105 */     if (bool1)
/*      */     
/*      */     { 
/* 1108 */       bool3 = true; }
/* 1109 */     else { if (bool2) {
/*      */ 
/*      */ 
/*      */         
/* 1113 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1114 */         sQLException.fillInStackTrace();
/* 1115 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1121 */       this.columnsDefinedByUser = false; }
/*      */     
/* 1123 */     return bool3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeMaybeDescribe() throws SQLException {
/* 1132 */     boolean bool1 = true;
/*      */     
/* 1134 */     if (this.rowPrefetchChanged) {
/*      */       
/* 1136 */       if (this.streamList == null && this.rowPrefetch != this.definesBatchSize) {
/* 1137 */         this.needToPrepareDefineBuffer = true;
/*      */       }
/* 1139 */       this.rowPrefetchChanged = false;
/*      */     } 
/*      */     
/* 1142 */     if (!this.needToPrepareDefineBuffer)
/*      */     {
/*      */ 
/*      */       
/* 1146 */       if (this.accessors == null) {
/*      */ 
/*      */ 
/*      */         
/* 1150 */         this.needToPrepareDefineBuffer = true;
/* 1151 */       } else if (this.columnsDefinedByUser) {
/* 1152 */         this.needToPrepareDefineBuffer = !checkAccessorsUsable();
/*      */       } 
/*      */     }
/* 1155 */     boolean bool2 = false;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1160 */       this.isExecuting = true;
/*      */       
/* 1162 */       if (this.needToPrepareDefineBuffer) {
/*      */ 
/*      */         
/* 1165 */         if (!this.columnsDefinedByUser) {
/*      */           
/* 1167 */           executeForDescribe();
/*      */           
/* 1169 */           bool2 = true;
/*      */ 
/*      */ 
/*      */           
/* 1173 */           if (this.aFetchWasDoneDuringDescribe) {
/* 1174 */             bool1 = false;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1180 */         if (this.needToPrepareDefineBuffer)
/*      */         {
/*      */ 
/*      */           
/* 1184 */           prepareAccessors();
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1189 */       int i = this.accessors.length;
/*      */       
/* 1191 */       for (int j = this.numberOfDefinePositions; j < i; j++) {
/*      */         
/* 1193 */         Accessor accessor = this.accessors[j];
/*      */         
/* 1195 */         if (accessor != null)
/* 1196 */           accessor.rowSpaceIndicator = null; 
/*      */       } 
/* 1198 */       if (bool1) {
/* 1199 */         executeForRows(bool2);
/*      */       }
/*      */     }
/* 1202 */     catch (SQLException sQLException) {
/*      */       
/* 1204 */       this.needToParse = true;
/* 1205 */       throw sQLException;
/*      */     }
/*      */     finally {
/*      */       
/* 1209 */       this.isExecuting = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void adjustGotLastBatch() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doExecuteWithTimeout() throws SQLException {
/*      */     try {
/* 1246 */       cleanOldTempLobs();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1253 */       this.connection.registerHeartbeat();
/*      */ 
/*      */       
/* 1256 */       this.rowsProcessed = 0;
/*      */       
/* 1258 */       if (this.sqlKind.isSELECT()) {
/*      */         
/* 1260 */         if (this.connection.j2ee13Compliant && this.executionType == 2) {
/*      */           
/* 1262 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 129);
/* 1263 */           sQLException.fillInStackTrace();
/* 1264 */           throw sQLException;
/*      */         } 
/*      */         
/* 1267 */         this.connection.needLine();
/*      */         
/* 1269 */         if (!this.isOpen) {
/*      */           
/* 1271 */           this.connection.open(this);
/*      */           
/* 1273 */           this.isOpen = true;
/*      */         } 
/*      */         
/* 1276 */         if (this.queryTimeout != 0) {
/*      */ 
/*      */           
/*      */           try {
/* 1280 */             this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
/* 1281 */             executeMaybeDescribe();
/*      */           }
/*      */           finally {
/*      */             
/* 1285 */             this.connection.getTimeout().cancelTimeout();
/*      */           } 
/*      */         } else {
/*      */           
/* 1289 */           executeMaybeDescribe();
/*      */         } 
/* 1291 */         checkValidRowsStatus();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1296 */         if (this.serverCursor) {
/* 1297 */           adjustGotLastBatch();
/*      */         }
/*      */       } else {
/*      */         
/* 1301 */         if (this.connection.j2ee13Compliant && !this.sqlKind.isPlsqlOrCall() && this.executionType == 1) {
/*      */ 
/*      */           
/* 1304 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 128);
/* 1305 */           sQLException.fillInStackTrace();
/* 1306 */           throw sQLException;
/*      */         } 
/*      */         
/* 1309 */         this.currentRank++;
/*      */         
/* 1311 */         if (this.currentRank >= this.batch) {
/*      */           try
/*      */           {
/*      */             
/* 1315 */             this.connection.needLine();
/*      */             
/* 1317 */             if (!this.isOpen) {
/*      */               
/* 1319 */               this.connection.open(this);
/*      */               
/* 1321 */               this.isOpen = true;
/*      */             } 
/*      */             
/* 1324 */             if (this.queryTimeout != 0) {
/* 1325 */               this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
/*      */             }
/* 1327 */             this.isExecuting = true;
/*      */             
/* 1329 */             executeForRows(false);
/*      */           }
/* 1331 */           catch (SQLException sQLException)
/*      */           {
/* 1333 */             this.needToParse = true;
/* 1334 */             if (this.batch > 1) {
/*      */               int[] arrayOfInt;
/* 1336 */               clearBatch();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1342 */               if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch < this.batch) {
/*      */ 
/*      */                 
/* 1345 */                 arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 1346 */                 for (byte b = 0; b < arrayOfInt.length; b++) {
/* 1347 */                   arrayOfInt[b] = -2;
/*      */                 }
/*      */               } else {
/*      */                 
/* 1351 */                 arrayOfInt = new int[this.batch];
/* 1352 */                 for (byte b = 0; b < arrayOfInt.length; b++) {
/* 1353 */                   arrayOfInt[b] = -3;
/*      */                 }
/*      */               } 
/* 1356 */               BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(sQLException, arrayOfInt.length, arrayOfInt);
/* 1357 */               batchUpdateException.fillInStackTrace();
/* 1358 */               throw batchUpdateException;
/*      */             } 
/*      */             
/* 1361 */             resetCurrentRowBinders();
/*      */             
/* 1363 */             throw sQLException;
/*      */           }
/*      */           finally
/*      */           {
/* 1367 */             if (this.queryTimeout != 0) {
/* 1368 */               this.connection.getTimeout().cancelTimeout();
/*      */             }
/* 1370 */             this.currentRank = 0;
/* 1371 */             this.isExecuting = false;
/*      */             
/* 1373 */             checkValidRowsStatus();
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1386 */     catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1391 */       resetOnExceptionDuringExecute();
/* 1392 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1402 */     this.connection.registerHeartbeat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetOnExceptionDuringExecute() {
/* 1411 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetCurrentRowBinders() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void open() throws SQLException {
/* 1433 */     if (!this.isOpen) {
/*      */       
/* 1435 */       this.connection.needLine();
/* 1436 */       this.connection.open(this);
/*      */       
/* 1438 */       this.isOpen = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery(String paramString) throws SQLException {
/* 1457 */     synchronized (this.connection) {
/*      */       
/* 1459 */       OracleResultSet oracleResultSet = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1467 */         this.executionType = 1;
/*      */ 
/*      */ 
/*      */         
/* 1471 */         this.noMoreUpdateCounts = false;
/*      */         
/* 1473 */         ensureOpen();
/* 1474 */         checkIfJdbcBatchExists();
/*      */         
/* 1476 */         sendBatch();
/*      */ 
/*      */         
/* 1479 */         this.hasStream = false;
/*      */ 
/*      */         
/* 1482 */         this.sqlObject.initialize(paramString);
/*      */         
/* 1484 */         this.sqlKind = this.sqlObject.getSqlKind();
/* 1485 */         this.needToParse = true;
/*      */         
/* 1487 */         prepareForNewResults(true, true);
/*      */         
/* 1489 */         if (this.userRsetType == 1) {
/*      */           
/* 1491 */           doExecuteWithTimeout();
/*      */           
/* 1493 */           this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1494 */           oracleResultSet = this.currentResultSet;
/*      */         }
/*      */         else {
/*      */           
/* 1498 */           oracleResultSet = doScrollStmtExecuteQuery();
/*      */           
/* 1500 */           if (oracleResultSet == null)
/*      */           {
/* 1502 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1503 */             oracleResultSet = this.currentResultSet;
/*      */           }
/*      */         
/*      */         } 
/*      */       } finally {
/*      */         
/* 1509 */         this.executionType = -1;
/*      */       } 
/*      */       
/* 1512 */       return (ResultSet)oracleResultSet;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeWithKey(String paramString) throws SQLException {
/* 1525 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 1526 */     sQLException.fillInStackTrace();
/* 1527 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/* 1559 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1563 */       closeOrCache(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closeOrCache(String paramString) throws SQLException {
/* 1571 */     if (this.closed) {
/*      */       return;
/*      */     }
/*      */     
/* 1575 */     if (this.connection.lifecycle == 2) {
/* 1576 */       this.connection.needLineUnchecked();
/*      */     } else {
/* 1578 */       this.connection.needLine();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1587 */     if (this.statementType != 0 && this.cacheState != 0 && this.cacheState != 3 && this.connection.isStatementCacheInitialized()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1598 */       if (paramString == null)
/*      */       {
/* 1600 */         if (this.connection.getImplicitCachingEnabled())
/*      */         {
/* 1602 */           this.connection.cacheImplicitStatement((OraclePreparedStatement)this, this.sqlObject.getOriginalSql(), this.statementType, this.userRsetType);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */           
/* 1611 */           this.cacheState = 0;
/*      */           
/* 1613 */           hardClose();
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 1619 */       else if (this.connection.getExplicitCachingEnabled())
/*      */       {
/* 1621 */         this.connection.cacheExplicitStatement((OraclePreparedStatement)this, paramString);
/*      */ 
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */         
/* 1629 */         this.cacheState = 0;
/*      */         
/* 1631 */         hardClose();
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1640 */       hardClose();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void hardClose() throws SQLException {
/* 1650 */     hardClose(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void hardClose(boolean paramBoolean) throws SQLException {
/* 1661 */     alwaysOnClose();
/*      */     
/* 1663 */     this.describedWithNames = false;
/* 1664 */     this.described = false;
/*      */ 
/*      */     
/* 1667 */     this.connection.removeStatement(this);
/*      */     
/* 1669 */     cleanupDefines();
/*      */     
/* 1671 */     if (this.isOpen && paramBoolean && (this.connection.lifecycle == 1 || this.connection.lifecycle == 16 || this.connection.lifecycle == 2)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1680 */       this.connection.registerHeartbeat();
/*      */ 
/*      */       
/* 1683 */       doClose();
/*      */       
/* 1685 */       this.isOpen = false;
/*      */     } 
/*      */     
/* 1688 */     this.sqlObject = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void alwaysOnClose() throws SQLException {
/* 1705 */     OracleStatement oracleStatement = this.children;
/*      */     
/* 1707 */     while (oracleStatement != null) {
/*      */       
/* 1709 */       OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*      */       
/* 1711 */       oracleStatement.close();
/*      */       
/* 1713 */       oracleStatement = oracleStatement1;
/*      */     } 
/*      */     
/* 1716 */     if (this.parent != null)
/*      */     {
/* 1718 */       this.parent.removeChild(this);
/*      */     }
/*      */     
/* 1721 */     this.closed = true;
/*      */ 
/*      */     
/* 1724 */     if (this.connection.lifecycle == 1 || this.connection.lifecycle == 2) {
/*      */ 
/*      */ 
/*      */       
/* 1728 */       if (this.currentResultSet != null) {
/*      */         
/* 1730 */         this.currentResultSet.internal_close(false);
/*      */         
/* 1732 */         this.currentResultSet = null;
/*      */       } 
/*      */       
/* 1735 */       if (this.scrollRset != null) {
/*      */         
/* 1737 */         this.scrollRset.close();
/*      */         
/* 1739 */         this.scrollRset = null;
/*      */       } 
/*      */       
/* 1742 */       if (this.returnResultSet != null) {
/*      */         
/* 1744 */         this.returnResultSet.close();
/* 1745 */         this.returnResultSet = null;
/*      */       } 
/*      */     } 
/*      */     
/* 1749 */     clearWarnings();
/*      */     
/* 1751 */     this.m_batchItems = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeLeaveCursorOpen() throws SQLException {
/* 1767 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1773 */       if (this.closed) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1778 */       hardClose(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString) throws SQLException {
/* 1797 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1802 */       setNonAutoKey();
/* 1803 */       return executeUpdateInternal(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int executeUpdateInternal(String paramString) throws SQLException {
/*      */     try {
/* 1814 */       if (this.executionType == -1) {
/* 1815 */         this.executionType = 2;
/*      */       }
/*      */       
/* 1818 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1820 */       ensureOpen();
/* 1821 */       checkIfJdbcBatchExists();
/*      */       
/* 1823 */       sendBatch();
/*      */ 
/*      */       
/* 1826 */       this.hasStream = false;
/*      */ 
/*      */       
/* 1829 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1831 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1832 */       this.needToParse = true;
/*      */       
/* 1834 */       prepareForNewResults(true, true);
/*      */       
/* 1836 */       if (this.userRsetType == 1) {
/*      */         
/* 1838 */         doExecuteWithTimeout();
/*      */       }
/*      */       else {
/*      */         
/* 1842 */         doScrollStmtExecuteQuery();
/*      */       } 
/*      */       
/* 1845 */       return this.validRows;
/*      */     }
/*      */     finally {
/*      */       
/* 1849 */       this.executionType = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString) throws SQLException {
/* 1865 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1870 */       setNonAutoKey();
/* 1871 */       return executeInternal(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean executeInternal(String paramString) throws SQLException {
/*      */     try {
/* 1882 */       this.executionType = 3;
/*      */       
/* 1884 */       this.checkSum = 0L;
/* 1885 */       this.checkSumComputationFailure = false;
/*      */ 
/*      */       
/* 1888 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1890 */       ensureOpen();
/* 1891 */       checkIfJdbcBatchExists();
/*      */       
/* 1893 */       sendBatch();
/*      */ 
/*      */ 
/*      */       
/* 1897 */       this.hasStream = false;
/*      */ 
/*      */       
/* 1900 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1902 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1903 */       this.needToParse = true;
/*      */       
/* 1905 */       prepareForNewResults(true, true);
/*      */       
/* 1907 */       if (this.userRsetType == 1) {
/*      */         
/* 1909 */         doExecuteWithTimeout();
/*      */       }
/*      */       else {
/*      */         
/* 1913 */         doScrollStmtExecuteQuery();
/*      */       } 
/*      */       
/* 1916 */       return this.sqlKind.isSELECT();
/*      */     }
/*      */     finally {
/*      */       
/* 1920 */       this.executionType = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getNumberOfColumns() throws SQLException {
/* 1928 */     ensureOpen();
/* 1929 */     if (!this.described)
/*      */     {
/* 1931 */       synchronized (this.connection) {
/* 1932 */         doDescribe(false);
/*      */         
/* 1934 */         this.described = true;
/*      */       } 
/*      */     }
/*      */     
/* 1938 */     return this.numberOfDefinePositions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor[] getDescription() throws SQLException {
/* 1945 */     ensureOpen();
/* 1946 */     if (!this.described)
/*      */     {
/* 1948 */       synchronized (this.connection) {
/* 1949 */         doDescribe(false);
/*      */         
/* 1951 */         this.described = true;
/*      */       } 
/*      */     }
/*      */     
/* 1955 */     return this.accessors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor[] getDescriptionWithNames() throws SQLException {
/* 1962 */     ensureOpen();
/* 1963 */     if (!this.describedWithNames)
/*      */     {
/* 1965 */       synchronized (this.connection) {
/* 1966 */         doDescribe(true);
/*      */         
/* 1968 */         this.described = true;
/* 1969 */         this.describedWithNames = true;
/*      */       } 
/*      */     }
/*      */     
/* 1973 */     return this.accessors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleStatement.SqlKind getSqlKind() throws SQLException {
/* 1986 */     return this.sqlObject.getSqlKind();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/* 2006 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2009 */       freeLine();
/*      */       
/* 2011 */       this.streamList = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2018 */       this.columnsDefinedByUser = false;
/* 2019 */       this.needToPrepareDefineBuffer = true;
/*      */ 
/*      */       
/* 2022 */       this.numberOfDefinePositions = 0;
/* 2023 */       this.definesBatchSize = 0;
/*      */       
/* 2025 */       this.described = false;
/* 2026 */       this.describedWithNames = false;
/*      */       
/* 2028 */       cleanupDefines();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, String paramString) throws SQLException {
/* 2050 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, (short)1, paramBoolean, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/* 2061 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 2066 */     if (paramInt1 < 1) {
/*      */       
/* 2068 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2069 */       sQLException.fillInStackTrace();
/* 2070 */       throw sQLException;
/*      */     } 
/*      */     
/* 2073 */     if (paramInt2 == 0) {
/*      */       
/* 2075 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2076 */       sQLException.fillInStackTrace();
/* 2077 */       throw sQLException;
/*      */     } 
/*      */     
/* 2080 */     int i = paramInt1 - 1;
/* 2081 */     int j = (this.maxFieldSize > 0) ? this.maxFieldSize : -1;
/*      */     
/* 2083 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/* 2087 */       if (paramInt2 == 1 || paramInt2 == 12 || paramInt2 == -15 || paramInt2 == -9)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2094 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2101 */       if (paramInt3 < 0) {
/*      */         
/* 2103 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/* 2104 */         sQLException.fillInStackTrace();
/* 2105 */         throw sQLException;
/*      */       } 
/*      */       
/* 2108 */       if ((j == -1 && paramInt3 > 0) || (j && paramInt3 < j))
/*      */       {
/* 2110 */         j = paramInt3;
/*      */       }
/*      */     } 
/* 2113 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/* 2115 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/* 2116 */       sQLException.fillInStackTrace();
/* 2117 */       throw sQLException;
/*      */     } 
/*      */     
/* 2120 */     if (!this.columnsDefinedByUser) {
/*      */ 
/*      */ 
/*      */       
/* 2124 */       clearDefines();
/*      */       
/* 2126 */       this.columnsDefinedByUser = true;
/*      */     } 
/*      */     
/* 2129 */     if (this.numberOfDefinePositions < paramInt1) {
/*      */       
/* 2131 */       if (this.accessors == null || this.accessors.length < paramInt1) {
/*      */         
/* 2133 */         Accessor[] arrayOfAccessor = new Accessor[paramInt1 << 1];
/*      */         
/* 2135 */         if (this.accessors != null) {
/* 2136 */           System.arraycopy(this.accessors, 0, arrayOfAccessor, 0, this.numberOfDefinePositions);
/*      */         }
/* 2138 */         this.accessors = arrayOfAccessor;
/*      */       } 
/*      */       
/* 2141 */       this.numberOfDefinePositions = paramInt1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2148 */     switch (paramInt2) {
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/*      */       case 2011:
/* 2153 */         paramShort = 2;
/*      */         break;
/*      */       case 2009:
/* 2156 */         paramString = "SYS.XMLTYPE";
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2164 */     int k = getInternalType(paramInt2);
/*      */     
/* 2166 */     if ((k == 109 || k == 111) && (paramString == null || paramString.equals(""))) {
/*      */ 
/*      */       
/* 2169 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
/* 2170 */       sQLException.fillInStackTrace();
/* 2171 */       throw sQLException;
/*      */     } 
/*      */     
/* 2174 */     Accessor accessor = this.accessors[i];
/* 2175 */     boolean bool = true;
/*      */     
/* 2177 */     if (accessor != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2182 */       int m = accessor.useForDataAccessIfPossible(k, paramInt2, j, paramString);
/*      */ 
/*      */       
/* 2185 */       if (m == 0) {
/*      */         
/* 2187 */         paramShort = accessor.formOfUse;
/* 2188 */         accessor = null;
/*      */         
/* 2190 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 2192 */       else if (m == 1) {
/*      */         
/* 2194 */         accessor = null;
/*      */         
/* 2196 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 2198 */       else if (m == 2) {
/* 2199 */         bool = false;
/*      */       } 
/*      */     } 
/* 2202 */     if (bool) {
/* 2203 */       this.needToPrepareDefineBuffer = true;
/*      */     }
/* 2205 */     if (accessor == null) {
/*      */       
/* 2207 */       this.accessors[i] = allocateAccessor(k, paramInt2, paramInt1, j, paramShort, paramString, false);
/*      */       
/* 2209 */       this.described = false;
/* 2210 */       this.describedWithNames = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException {
/*      */     BlobAccessor blobAccessor;
/*      */     ClobAccessor clobAccessor;
/*      */     BfileAccessor bfileAccessor;
/*      */     NamedTypeAccessor namedTypeAccessor;
/*      */     RefTypeAccessor refTypeAccessor;
/* 2252 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/* 2256 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2258 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2259 */           sQLException1.fillInStackTrace();
/* 2260 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2263 */         return new CharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 8:
/* 2266 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2268 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2269 */           sQLException1.fillInStackTrace();
/* 2270 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2273 */         if (!paramBoolean) {
/* 2274 */           return new LongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */         }
/*      */ 
/*      */       
/*      */       case 1:
/* 2279 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2281 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2282 */           sQLException1.fillInStackTrace();
/* 2283 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2286 */         return new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 2:
/* 2289 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2291 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2292 */           sQLException1.fillInStackTrace();
/* 2293 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2296 */         return new NumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 6:
/* 2299 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2301 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2302 */           sQLException1.fillInStackTrace();
/* 2303 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2306 */         return new VarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 24:
/* 2309 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2311 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2312 */           sQLException1.fillInStackTrace();
/* 2313 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2316 */         if (!paramBoolean) {
/* 2317 */           return new LongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/* 2323 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2325 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2326 */           sQLException1.fillInStackTrace();
/* 2327 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2330 */         if (paramBoolean) {
/* 2331 */           return new OutRawAccessor(this, paramInt4, paramShort, paramInt2);
/*      */         }
/* 2333 */         return new RawAccessor(this, paramInt4, paramShort, paramInt2, false);
/*      */       
/*      */       case 100:
/* 2336 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2338 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2339 */           sQLException1.fillInStackTrace();
/* 2340 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2343 */         return new BinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 101:
/* 2347 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2349 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2350 */           sQLException1.fillInStackTrace();
/* 2351 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2354 */         return new BinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 104:
/* 2358 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2360 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2361 */           sQLException1.fillInStackTrace();
/* 2362 */           throw sQLException1;
/*      */         } 
/* 2364 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */           
/* 2366 */           paramInt4 = 18;
/* 2367 */           VarcharAccessor varcharAccessor = new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/* 2368 */           varcharAccessor.definedColumnType = -8;
/* 2369 */           return varcharAccessor;
/*      */         } 
/* 2371 */         return new RowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 102:
/* 2374 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2376 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2377 */           sQLException1.fillInStackTrace();
/* 2378 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2381 */         return new ResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 12:
/* 2384 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2386 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2387 */           sQLException1.fillInStackTrace();
/* 2388 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2391 */         return new DateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 113:
/* 2394 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2396 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2397 */           sQLException1.fillInStackTrace();
/* 2398 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2401 */         blobAccessor = new BlobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/* 2402 */         if (!paramBoolean)
/* 2403 */           blobAccessor.lobPrefetchSizeForThisColumn = paramInt4; 
/* 2404 */         return blobAccessor;
/*      */       
/*      */       case 112:
/* 2407 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2409 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2410 */           sQLException1.fillInStackTrace();
/* 2411 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2414 */         clobAccessor = new ClobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/* 2415 */         if (!paramBoolean)
/* 2416 */           clobAccessor.lobPrefetchSizeForThisColumn = paramInt4; 
/* 2417 */         return clobAccessor;
/*      */       
/*      */       case 114:
/* 2420 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2422 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2423 */           sQLException1.fillInStackTrace();
/* 2424 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2427 */         return new BfileAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/* 2434 */         if (paramString == null) {
/* 2435 */           if (paramBoolean) {
/*      */             
/* 2437 */             SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2438 */             sQLException2.fillInStackTrace();
/* 2439 */             throw sQLException2;
/*      */           } 
/*      */ 
/*      */           
/* 2443 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
/* 2444 */           sQLException1.fillInStackTrace();
/* 2445 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2448 */         namedTypeAccessor = new NamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */         
/* 2451 */         namedTypeAccessor.initMetadata();
/*      */         
/* 2453 */         return namedTypeAccessor;
/*      */       
/*      */       case 111:
/* 2456 */         if (paramString == null) {
/* 2457 */           if (paramBoolean) {
/*      */             
/* 2459 */             SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2460 */             sQLException2.fillInStackTrace();
/* 2461 */             throw sQLException2;
/*      */           } 
/*      */ 
/*      */           
/* 2465 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
/* 2466 */           sQLException1.fillInStackTrace();
/* 2467 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2470 */         refTypeAccessor = new RefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */         
/* 2473 */         refTypeAccessor.initMetadata();
/*      */         
/* 2475 */         return refTypeAccessor;
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/* 2480 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2482 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2483 */           sQLException1.fillInStackTrace();
/* 2484 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2487 */         return new TimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 181:
/* 2491 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2493 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2494 */           sQLException1.fillInStackTrace();
/* 2495 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2498 */         return new TimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 231:
/* 2502 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2504 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2505 */           sQLException1.fillInStackTrace();
/* 2506 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2509 */         return new TimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 182:
/* 2513 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2515 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2516 */           sQLException1.fillInStackTrace();
/* 2517 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2520 */         return new IntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 183:
/* 2524 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2526 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2527 */           sQLException1.fillInStackTrace();
/* 2528 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2531 */         return new IntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/* 2550 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 2551 */         sQLException.fillInStackTrace();
/* 2552 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2557 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2558 */     sQLException.fillInStackTrace();
/* 2559 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2) throws SQLException {
/* 2611 */     synchronized (this.connection) {
/*      */       
/* 2613 */       defineColumnTypeInternal(paramInt1, paramInt2, -1, true, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2629 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3, short paramShort) throws SQLException {
/* 2648 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, paramShort, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2719 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2722 */       defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2793 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 2833 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2839 */       defineColumnTypeInternal(paramInt1, paramInt2, -1, true, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setCursorId(int paramInt) throws SQLException {
/* 2855 */     this.cursorId = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setPrefetchInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
/* 2870 */     if (paramBoolean1) {
/*      */       
/* 2872 */       if (paramInt <= 0)
/*      */       {
/* 2874 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/* 2875 */         sQLException.fillInStackTrace();
/* 2876 */         throw sQLException;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 2881 */       if (paramInt < 0) {
/*      */         
/* 2883 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchSize");
/* 2884 */         sQLException.fillInStackTrace();
/* 2885 */         throw sQLException;
/*      */       } 
/* 2887 */       if (paramInt == 0) {
/* 2888 */         paramInt = this.connection.getDefaultRowPrefetch();
/*      */       }
/*      */     } 
/*      */     
/* 2892 */     if (paramBoolean2) {
/*      */       
/* 2894 */       if (paramInt != this.defaultRowPrefetch)
/*      */       {
/* 2896 */         this.defaultRowPrefetch = paramInt;
/*      */ 
/*      */ 
/*      */         
/* 2900 */         if (this.currentResultSet == null || this.currentResultSet.closed) {
/* 2901 */           this.rowPrefetchChanged = true;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 2908 */     else if (paramInt != this.rowPrefetch && this.streamList == null) {
/*      */ 
/*      */       
/* 2911 */       this.rowPrefetch = paramInt;
/* 2912 */       this.rowPrefetchChanged = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowPrefetch(int paramInt) throws SQLException {
/* 2939 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 2943 */       setPrefetchInternal(paramInt, true, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLobPrefetchSize(int paramInt) throws SQLException {
/* 2956 */     synchronized (this.connection) {
/*      */       
/* 2958 */       if (paramInt < -1) {
/*      */         
/* 2960 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/* 2961 */         sQLException.fillInStackTrace();
/* 2962 */         throw sQLException;
/*      */       } 
/* 2964 */       this.defaultLobPrefetchSize = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLobPrefetchSize() {
/* 2972 */     return this.defaultLobPrefetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getPrefetchInternal(boolean paramBoolean) {
/* 2989 */     return paramBoolean ? this.defaultRowPrefetch : this.rowPrefetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowPrefetch() {
/* 3006 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3009 */       return getPrefetchInternal(true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedString(boolean paramBoolean) {
/* 3036 */     this.fixedString = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFixedString() {
/* 3061 */     return this.fixedString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void check_row_prefetch_changed() throws SQLException {
/* 3076 */     if (this.rowPrefetchChanged) {
/*      */       
/* 3078 */       if (this.streamList == null) {
/*      */         
/* 3080 */         prepareAccessors();
/*      */         
/* 3082 */         this.needToPrepareDefineBuffer = true;
/*      */       } 
/*      */       
/* 3085 */       this.rowPrefetchChanged = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setDefinesInitialized(boolean paramBoolean) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printState(String paramString) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void checkValidRowsStatus() throws SQLException {
/* 3122 */     if (this.validRows == -2) {
/*      */ 
/*      */ 
/*      */       
/* 3126 */       this.validRows = 1;
/* 3127 */       this.connection.holdLine(this);
/*      */ 
/*      */       
/* 3130 */       OracleInputStream oracleInputStream = this.streamList;
/*      */       
/* 3132 */       while (oracleInputStream != null) {
/*      */         
/* 3134 */         if (oracleInputStream.hasBeenOpen) {
/* 3135 */           oracleInputStream = oracleInputStream.accessor.initForNewRow();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3142 */         oracleInputStream.closed = false;
/* 3143 */         oracleInputStream.hasBeenOpen = true;
/*      */ 
/*      */ 
/*      */         
/* 3147 */         oracleInputStream = oracleInputStream.nextStream;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3152 */       this.nextStream = this.streamList;
/*      */     
/*      */     }
/* 3155 */     else if (this.sqlKind.isSELECT()) {
/*      */       
/* 3157 */       if (this.validRows < this.rowPrefetch) {
/* 3158 */         this.gotLastBatch = true;
/*      */       }
/* 3160 */     } else if (!this.sqlKind.isPlsqlOrCall()) {
/*      */       
/* 3162 */       this.rowsProcessed = this.validRows;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cleanupDefines() {
/* 3170 */     if (this.accessors != null)
/* 3171 */       for (byte b = 0; b < this.accessors.length; b++) {
/* 3172 */         this.accessors[b] = null;
/*      */       } 
/* 3174 */     this.accessors = null;
/*      */ 
/*      */     
/* 3177 */     this.connection.cacheBuffer(this.defineBytes);
/* 3178 */     this.defineBytes = null;
/* 3179 */     this.connection.cacheBuffer(this.defineChars);
/* 3180 */     this.defineChars = null;
/* 3181 */     this.defineIndicators = null;
/* 3182 */     this.defineMetaData = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxFieldSize() throws SQLException {
/* 3189 */     synchronized (this.connection) {
/*      */       
/* 3191 */       return this.maxFieldSize;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxFieldSize(int paramInt) throws SQLException {
/* 3198 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3201 */       if (paramInt < 0) {
/*      */         
/* 3203 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3204 */         sQLException.fillInStackTrace();
/* 3205 */         throw sQLException;
/*      */       } 
/*      */       
/* 3208 */       this.maxFieldSize = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxRows() throws SQLException {
/* 3216 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxRows(int paramInt) throws SQLException {
/* 3222 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3225 */       if (paramInt < 0) {
/*      */         
/* 3227 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3228 */         sQLException.fillInStackTrace();
/* 3229 */         throw sQLException;
/*      */       } 
/*      */       
/* 3232 */       this.maxRows = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEscapeProcessing(boolean paramBoolean) throws SQLException {
/* 3240 */     synchronized (this.connection) {
/*      */       
/* 3242 */       this.processEscapes = paramBoolean;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getQueryTimeout() throws SQLException {
/* 3256 */     synchronized (this.connection) {
/*      */       
/* 3258 */       return this.queryTimeout;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQueryTimeout(int paramInt) throws SQLException {
/* 3273 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3276 */       if (paramInt < 0) {
/*      */         
/* 3278 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3279 */         sQLException.fillInStackTrace();
/* 3280 */         throw sQLException;
/*      */       } 
/*      */       
/* 3283 */       this.queryTimeout = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancel() throws SQLException {
/* 3296 */     doCancel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean doCancel() throws SQLException {
/* 3303 */     boolean bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3308 */     if (this.closed) {
/* 3309 */       return bool;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3321 */     if (this.connection.statementHoldingLine != null) {
/* 3322 */       freeLine();
/* 3323 */     } else if (this.isExecuting) {
/*      */       
/* 3325 */       bool = true;
/* 3326 */       this.connection.cancelOperationOnServer();
/*      */     } 
/*      */     
/* 3329 */     OracleStatement oracleStatement = this.children;
/* 3330 */     while (oracleStatement != null) {
/* 3331 */       bool = (bool || oracleStatement.doCancel()) ? true : false;
/* 3332 */       oracleStatement = oracleStatement.nextChild;
/*      */     } 
/*      */     
/* 3335 */     this.connection.releaseLineForCancel();
/* 3336 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 3353 */     return this.sqlWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/* 3363 */     this.sqlWarning = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void foundPlsqlCompilerWarning() throws SQLException {
/* 3371 */     SQLWarning sQLWarning = DatabaseError.addSqlWarning(this.sqlWarning, "Found Plsql compiler warnings.", 24439);
/*      */     
/* 3373 */     if (this.sqlWarning != null) {
/*      */       
/* 3375 */       this.sqlWarning.setNextWarning(sQLWarning);
/*      */     }
/*      */     else {
/*      */       
/* 3379 */       this.sqlWarning = sQLWarning;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursorName(String paramString) throws SQLException {
/* 3391 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 3392 */     sQLException.fillInStackTrace();
/* 3393 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getResultSet() throws SQLException {
/* 3406 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3409 */       if (this.userRsetType == 1) {
/*      */         
/* 3411 */         if (this.sqlKind.isSELECT())
/*      */         {
/* 3413 */           if (this.currentResultSet == null) {
/* 3414 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*      */           }
/* 3416 */           return (ResultSet)this.currentResultSet;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 3421 */         return (ResultSet)this.scrollRset;
/*      */       } 
/*      */       
/* 3424 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/* 3441 */     synchronized (this.connection) {
/*      */       
/* 3443 */       int i = -1;
/*      */       
/* 3445 */       switch (this.sqlKind) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case ALTER_SESSION:
/*      */         case OTHER:
/* 3456 */           if (!this.noMoreUpdateCounts) {
/* 3457 */             i = this.rowsProcessed;
/*      */           }
/* 3459 */           this.noMoreUpdateCounts = true;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case PLSQL_BLOCK:
/*      */         case CALL_BLOCK:
/* 3467 */           this.noMoreUpdateCounts = true;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case DELETE:
/*      */         case INSERT:
/*      */         case MERGE:
/*      */         case UPDATE:
/* 3477 */           if (!this.noMoreUpdateCounts) {
/* 3478 */             i = this.rowsProcessed;
/*      */           }
/* 3480 */           this.noMoreUpdateCounts = true;
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 3485 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMoreResults() throws SQLException {
/* 3497 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/* 3508 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareForNewResults(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
/* 3519 */     clearWarnings();
/*      */     
/* 3521 */     if (this.streamList != null) {
/*      */ 
/*      */ 
/*      */       
/* 3525 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 3529 */           this.nextStream.close();
/*      */         }
/* 3531 */         catch (IOException iOException) {
/*      */ 
/*      */           
/* 3534 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3535 */           sQLException.fillInStackTrace();
/* 3536 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 3540 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */       
/* 3543 */       if (paramBoolean2) {
/*      */ 
/*      */         
/* 3546 */         OracleInputStream oracleInputStream1 = this.streamList;
/* 3547 */         OracleInputStream oracleInputStream2 = null;
/*      */         
/* 3549 */         this.streamList = null;
/*      */         
/* 3551 */         while (oracleInputStream1 != null) {
/*      */           
/* 3553 */           if (!oracleInputStream1.hasBeenOpen) {
/*      */             
/* 3555 */             if (oracleInputStream2 == null) {
/* 3556 */               this.streamList = oracleInputStream1;
/*      */             } else {
/* 3558 */               oracleInputStream2.nextStream = oracleInputStream1;
/*      */             } 
/* 3560 */             oracleInputStream2 = oracleInputStream1;
/*      */           } 
/*      */           
/* 3563 */           oracleInputStream1 = oracleInputStream1.nextStream;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3568 */     if (this.currentResultSet != null) {
/*      */       
/* 3570 */       this.currentResultSet.internal_close(true);
/*      */       
/* 3572 */       this.currentResultSet = null;
/*      */     } 
/*      */     
/* 3575 */     this.currentRow = -1;
/* 3576 */     this.checkSum = 0L;
/* 3577 */     this.checkSumComputationFailure = false;
/* 3578 */     this.validRows = 0;
/* 3579 */     if (paramBoolean1)
/* 3580 */       this.totalRowsVisited = 0; 
/* 3581 */     this.gotLastBatch = false;
/*      */     
/* 3583 */     if (this.needToParse && !this.columnsDefinedByUser) {
/*      */       
/* 3585 */       if (paramBoolean2 && this.numberOfDefinePositions != 0) {
/* 3586 */         this.numberOfDefinePositions = 0;
/*      */       }
/* 3588 */       this.needToPrepareDefineBuffer = true;
/*      */     } 
/*      */ 
/*      */     
/* 3592 */     if (paramBoolean1 && this.rowPrefetch != this.defaultRowPrefetch && this.streamList == null) {
/*      */ 
/*      */ 
/*      */       
/* 3596 */       this.rowPrefetch = this.defaultRowPrefetch;
/* 3597 */       this.rowPrefetchChanged = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reopenStreams() throws SQLException {
/* 3611 */     OracleInputStream oracleInputStream = this.streamList;
/*      */     
/* 3613 */     while (oracleInputStream != null) {
/*      */       
/* 3615 */       if (oracleInputStream.hasBeenOpen) {
/* 3616 */         oracleInputStream = oracleInputStream.accessor.initForNewRow();
/*      */       }
/* 3618 */       oracleInputStream.closed = false;
/* 3619 */       oracleInputStream.hasBeenOpen = true;
/* 3620 */       oracleInputStream = oracleInputStream.nextStream;
/*      */     } 
/*      */     
/* 3623 */     this.nextStream = this.streamList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void endOfResultSet(boolean paramBoolean) throws SQLException {
/* 3635 */     if (!paramBoolean)
/*      */     {
/*      */ 
/*      */       
/* 3639 */       prepareForNewResults(false, false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3644 */     clearDefines();
/* 3645 */     this.rowPrefetchInLastFetch = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean wasNullValue() throws SQLException {
/* 3670 */     if (this.lastIndex == 0) {
/*      */       
/* 3672 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/* 3673 */       sQLException.fillInStackTrace();
/* 3674 */       throw sQLException;
/*      */     } 
/*      */     
/* 3677 */     if (this.sqlKind.isSELECT()) {
/* 3678 */       return this.accessors[this.lastIndex - 1].isNull(this.currentRow);
/*      */     }
/* 3680 */     return this.outBindAccessors[this.lastIndex - 1].isNull(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getColumnIndex(String paramString) throws SQLException {
/* 3694 */     ensureOpen();
/* 3695 */     if (!this.describedWithNames)
/*      */     {
/* 3697 */       synchronized (this.connection) {
/* 3698 */         doDescribe(true);
/*      */         
/* 3700 */         this.described = true;
/* 3701 */         this.describedWithNames = true;
/*      */       } 
/*      */     }
/*      */     
/* 3705 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/* 3706 */       if ((this.accessors[b]).columnName.equalsIgnoreCase(paramString)) {
/* 3707 */         return b + 1;
/*      */       }
/*      */     } 
/* 3710 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3711 */     sQLException.fillInStackTrace();
/* 3712 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getJDBCType(int paramInt) throws SQLException {
/* 3720 */     int i = 0;
/* 3721 */     switch (paramInt)
/*      */     
/*      */     { case 6:
/* 3724 */         i = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3799 */         return i;case 100: i = 100; return i;case 101: i = 101; return i;case 999: i = 999; return i;case 96: i = 1; return i;case 1: i = 12; return i;case 8: i = -1; return i;case 12: i = 91; return i;case 180: i = 93; return i;case 181: i = -101; return i;case 231: i = -102; return i;case 182: i = -103; return i;case 183: i = -104; return i;case 23: i = -2; return i;case 24: i = -4; return i;case 104: i = -8; return i;case 113: i = 2004; return i;case 112: i = 2005; return i;case 114: i = -13; return i;case 102: i = -10; return i;case 109: i = 2002; return i;case 111: i = 2006; return i;case 998: i = -14; return i;case 995: i = 0; return i; }  i = paramInt; return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getInternalType(int paramInt) throws SQLException {
/* 3806 */     char c = Character.MIN_VALUE;
/*      */     
/* 3808 */     switch (paramInt) {
/*      */       
/*      */       case -7:
/*      */       case -6:
/*      */       case -5:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/* 3820 */         c = '\006';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3955 */         return c;case 100: c = 'd'; return c;case 101: c = 'e'; return c;case 999: c = 'ϧ'; return c;case 1: c = '`'; return c;case -15: case -9: case 12: c = '\001'; return c;case -16: case -1: c = '\b'; return c;case 91: case 92: c = '\f'; return c;case -100: case 93: c = '´'; return c;case -101: c = 'µ'; return c;case -102: c = 'ç'; return c;case -103: c = '¶'; return c;case -104: c = '·'; return c;case -3: case -2: c = '\027'; return c;case -4: c = '\030'; return c;case -8: c = 'h'; return c;case 2004: c = 'q'; return c;case 2005: case 2011: c = 'p'; return c;case -13: c = 'r'; return c;case -10: c = 'f'; return c;case 2002: case 2003: case 2007: case 2008: case 2009: c = 'm'; return c;case 2006: c = 'o'; return c;case -14: c = 'Ϧ'; return c;case 70: c = '\001'; return c;case 0: c = 'ϣ'; return c;
/*      */     } 
/*      */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.toString(paramInt));
/*      */     sQLException.fillInStackTrace();
/*      */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void describe() throws SQLException {
/* 3973 */     synchronized (this.connection) {
/*      */       
/* 3975 */       ensureOpen();
/* 3976 */       if (!this.described)
/*      */       {
/* 3978 */         doDescribe(false);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void freeLine() throws SQLException {
/* 3987 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 3991 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 3995 */           this.nextStream.close();
/*      */         }
/* 3997 */         catch (IOException iOException) {
/*      */ 
/*      */           
/* 4000 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4001 */           sQLException.fillInStackTrace();
/* 4002 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 4006 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeUsedStreams(int paramInt) throws SQLException {
/* 4019 */     while (this.nextStream != null && this.nextStream.columnIndex < paramInt) {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 4025 */         this.nextStream.close();
/*      */       }
/* 4027 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 4030 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4031 */         sQLException.fillInStackTrace();
/* 4032 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4036 */       this.nextStream = this.nextStream.nextStream;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void ensureOpen() throws SQLException {
/* 4048 */     if (this.connection.lifecycle != 1) {
/*      */       
/* 4050 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4051 */       sQLException.fillInStackTrace();
/* 4052 */       throw sQLException;
/*      */     } 
/* 4054 */     if (this.closed) {
/*      */       
/* 4056 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4057 */       sQLException.fillInStackTrace();
/* 4058 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/* 4092 */     synchronized (this.connection) {
/*      */       
/* 4094 */       if (paramInt == 1000) {
/*      */ 
/*      */         
/* 4097 */         this.defaultFetchDirection = paramInt;
/*      */       }
/* 4099 */       else if (paramInt == 1001 || paramInt == 1002) {
/*      */ 
/*      */         
/* 4102 */         this.defaultFetchDirection = 1000;
/* 4103 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 4109 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/* 4110 */         sQLException.fillInStackTrace();
/* 4111 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 4134 */     return this.defaultFetchDirection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 4153 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 4156 */       setPrefetchInternal(paramInt, false, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 4179 */     return getPrefetchInternal(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetConcurrency() throws SQLException {
/* 4191 */     return ResultSetUtil.getUpdateConcurrency(this.userRsetType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetType() throws SQLException {
/* 4203 */     return ResultSetUtil.getScrollType(this.userRsetType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLException {
/* 4218 */     return (Connection)this.connection.getWrapper();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache) throws SQLException {
/* 4231 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*      */       try {
/* 4235 */         if (paramOracleResultSetCache == null) {
/*      */           
/* 4237 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4238 */           sQLException.fillInStackTrace();
/* 4239 */           throw sQLException;
/*      */         } 
/*      */         
/* 4242 */         if (this.rsetCache != null) {
/* 4243 */           this.rsetCache.close();
/*      */         }
/* 4245 */         this.rsetCache = paramOracleResultSetCache;
/*      */       }
/* 4247 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 4250 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4251 */         sQLException.fillInStackTrace();
/* 4252 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache) throws SQLException {
/* 4269 */     synchronized (this.connection) {
/*      */       
/* 4271 */       setResultSetCache((OracleResultSetCache)paramOracleResultSetCache);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSetCache getResultSetCache() throws SQLException {
/* 4282 */     synchronized (this.connection) {
/*      */       
/* 4284 */       return (OracleResultSetCache)this.rsetCache;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isOracleBatchStyle() {
/* 4293 */     return false;
/*      */   } void initBatch() {} int getBatchSize() { return this.m_batchItems.size(); } void addBatchItem(String paramString) { this.m_batchItems.addElement(paramString); }
/*      */   String getBatchItem(int paramInt) { return this.m_batchItems.elementAt(paramInt); }
/*      */   void clearBatchItems() { this.m_batchItems.removeAllElements(); }
/*      */   void checkIfJdbcBatchExists() throws SQLException { if (getBatchSize() > 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared"); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public void addBatch(String paramString) throws SQLException { synchronized (this.connection) { addBatchItem(paramString); }  }
/*      */   public void clearBatch() throws SQLException { synchronized (this.connection) { clearBatchItems(); }  }
/*      */   public int[] executeBatch() throws SQLException { synchronized (this.connection) { cleanOldTempLobs(); byte b = 0; int i = getBatchSize(); this.checkSum = 0L; this.checkSumComputationFailure = false; if (i <= 0) return new int[0];  int[] arrayOfInt = new int[i]; ensureOpen(); prepareForNewResults(true, true); int j = this.numberOfDefinePositions; String str = this.sqlObject.getOriginalSql(); OracleStatement.SqlKind sqlKind = this.sqlKind; this.noMoreUpdateCounts = false; int k = 0; try { this.connection.registerHeartbeat(); this.connection.needLine(); for (b = 0; b < i; b++) { this.sqlObject.initialize(getBatchItem(b)); this.sqlKind = this.sqlObject.getSqlKind(); this.needToParse = true; this.numberOfDefinePositions = 0; this.rowsProcessed = 0; this.currentRank = 1; if (this.sqlKind.isSELECT()) { BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, "invalid SELECT batch command " + b, b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; }  if (!this.isOpen) { this.connection.open(this); this.isOpen = true; }  int m = -1; try { if (this.queryTimeout != 0) this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);  this.isExecuting = true; executeForRows(false); if (this.validRows > 0) k += this.validRows;  m = this.validRows; } catch (SQLException sQLException) { this.needToParse = true; resetCurrentRowBinders(); throw sQLException; } finally { if (this.queryTimeout != 0)
/*      */               this.connection.getTimeout().cancelTimeout();  this.validRows = k; checkValidRowsStatus(); this.isExecuting = false; }  arrayOfInt[b] = m; if (arrayOfInt[b] < 0) { BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, "command return value " + arrayOfInt[b], b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; }  }  } catch (SQLException sQLException) { if (sQLException instanceof BatchUpdateException)
/*      */           throw sQLException;  BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, sQLException.getMessage(), b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; } finally { clearBatchItems(); this.numberOfDefinePositions = j; if (str != null) { this.sqlObject.initialize(str); this.sqlKind = sqlKind; }  this.currentRank = 0; }  this.connection.registerHeartbeat(); return arrayOfInt; }  }
/*      */   public int copyBinds(Statement paramStatement, int paramInt) throws SQLException { return 0; }
/*      */   public void notifyCloseRset() throws SQLException { this.scrollRset = null; endOfResultSet(false); }
/*      */   public String getOriginalSql() throws SQLException { return this.sqlObject.getOriginalSql(); }
/*      */   void doScrollExecuteCommon() throws SQLException { if (this.scrollRset != null) { this.scrollRset.close(); this.scrollRset = null; }  if (!this.sqlKind.isSELECT()) { doExecuteWithTimeout(); return; }  if (!this.needToAddIdentifier) { doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.realRsetType = this.userRsetType; } else { try { this.sqlObject.setIncludeRowid(true); this.needToParse = true; prepareForNewResults(true, false); if (this.columnsDefinedByUser) { Accessor[] arrayOfAccessor = this.accessors; if (this.accessors == null || this.accessors.length <= this.numberOfDefinePositions)
/*      */             this.accessors = new Accessor[this.numberOfDefinePositions + 1];  if (arrayOfAccessor != null)
/*      */             for (int i = this.numberOfDefinePositions; i > 0; i--) { Accessor accessor = arrayOfAccessor[i - 1]; this.accessors[i] = accessor; if (accessor.isColumnNumberAware)
/*      */                 accessor.updateColumnNumber(i);  }   allocateRowidAccessor(); this.numberOfDefinePositions++; }  doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.realRsetType = this.userRsetType; } catch (SQLException sQLException) { if (this.userRsetType > 3) { this.realRsetType = 3; } else { this.realRsetType = 1; }  this.sqlObject.setIncludeRowid(false); this.needToParse = true; prepareForNewResults(true, false); if (this.columnsDefinedByUser) { this.needToPrepareDefineBuffer = true; this.numberOfDefinePositions--; System.arraycopy(this.accessors, 1, this.accessors, 0, this.numberOfDefinePositions); this.accessors[this.numberOfDefinePositions] = null; for (byte b = 0; b < this.numberOfDefinePositions; b++) { Accessor accessor = this.accessors[b]; if (accessor.isColumnNumberAware)
/*      */               accessor.updateColumnNumber(b);  }  }  moveAllTempLobsToFree(); doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 91, sQLException.getMessage()); }  }  this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType); }
/*      */   void allocateRowidAccessor() throws SQLException { this.accessors[0] = new RowidAccessor(this, 128, (short)1, -8, false); }
/* 4312 */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { this.m_batchItems = new Vector();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5814 */     this.tempClobsToFree = null;
/* 5815 */     this.tempBlobsToFree = null;
/*      */     
/* 5817 */     this.oldTempClobsToFree = null;
/* 5818 */     this.oldTempBlobsToFree = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6019 */     this.registration = null;
/* 6020 */     this.dcnTableName = null;
/* 6021 */     this.dcnQueryId = -1L; this.connection = paramPhysicalConnection; this.connection.needLine(); this.connection.registerHeartbeat(); this.connection.addStatement(this); this.sqlObject = new OracleSql(this.connection.conversion); this.processEscapes = this.connection.processEscapes; this.convertNcharLiterals = this.connection.convertNcharLiterals; this.autoRollback = 2; this.gotLastBatch = false; this.closed = false; this.clearParameters = true; this.serverCursor = false; this.needToAddIdentifier = false; this.defaultFetchDirection = 1000; this.fixedString = this.connection.getDefaultFixedString(); this.rowPrefetchChanged = false; this.rowPrefetch = paramInt2; this.defaultRowPrefetch = paramInt2; if (this.connection.getVersionNumber() >= 11000) { this.defaultLobPrefetchSize = this.connection.defaultLobPrefetchSize; } else { this.defaultLobPrefetchSize = -1; }  this.batch = paramInt1; this.sqlStringChanged = true; this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; if (paramInt3 != -1 || paramInt4 != -1) { this.realRsetType = 0; this.userRsetType = ResultSetUtil.getRsetTypeCode(paramInt3, paramInt4); this.needToAddIdentifier = ResultSetUtil.needIdentifier(this.userRsetType); } else { this.userRsetType = 1; this.realRsetType = 1; }  } OracleResultSet doScrollStmtExecuteQuery() throws SQLException { doScrollExecuteCommon(); return this.scrollRset; } void processDmlReturningBind() throws SQLException { if (this.returnResultSet != null) this.returnResultSet.close();  this.returnParamsFetched = false; this.returnParamRowBytes = 0; this.returnParamRowChars = 0; byte b1 = 0; for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { Accessor accessor = this.returnParamAccessors[b2]; if (accessor != null) { b1++; if (accessor.charLength > 0) { this.returnParamRowChars += accessor.charLength; } else { this.returnParamRowBytes += accessor.byteLength; }  }  }  if (this.isAutoGeneratedKey) { this.numReturnParams = b1; } else { if (this.numReturnParams <= 0) this.numReturnParams = this.sqlObject.getReturnParameterCount();  if (this.numReturnParams != b1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173); sQLException.fillInStackTrace(); throw sQLException; }  }  this.returnParamMeta[0] = this.numReturnParams; this.returnParamMeta[1] = this.returnParamRowBytes; this.returnParamMeta[2] = this.returnParamRowChars; } void allocateDmlReturnStorage() { if (this.rowsDmlReturned == 0) return;  int i = this.returnParamRowBytes * this.rowsDmlReturned; int j = this.returnParamRowChars * this.rowsDmlReturned; int k = 2 * this.numReturnParams * this.rowsDmlReturned; this.returnParamBytes = new byte[i]; this.returnParamChars = new char[j]; this.returnParamIndicators = new short[k]; for (byte b = 0; b < this.numberOfBindPositions; b++) { Accessor accessor = this.returnParamAccessors[b]; if (accessor != null && (accessor.internalType == 111 || accessor.internalType == 109)) { TypeAccessor typeAccessor = (TypeAccessor)accessor; if (typeAccessor.pickledBytes == null || typeAccessor.pickledBytes.length < this.rowsDmlReturned) typeAccessor.pickledBytes = new byte[this.rowsDmlReturned][];  }  }  } void fetchDmlReturnParams() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void setupReturnParamAccessors() { if (this.rowsDmlReturned == 0) return;  int i = 0; int j = 0; int k = 0; int m = this.numReturnParams * this.rowsDmlReturned; for (byte b = 0; b < this.numberOfBindPositions; b++) { Accessor accessor = this.returnParamAccessors[b]; if (accessor != null) { if (accessor.charLength > 0) { accessor.rowSpaceChar = this.returnParamChars; accessor.columnIndex = j; j += this.rowsDmlReturned * accessor.charLength; } else { accessor.rowSpaceByte = this.returnParamBytes; accessor.columnIndex = i; i += this.rowsDmlReturned * accessor.byteLength; }  accessor.rowSpaceIndicator = this.returnParamIndicators; accessor.indicatorIndex = k; k += this.rowsDmlReturned; accessor.lengthIndex = m; m += this.rowsDmlReturned; }  }  } void registerReturnParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString) throws SQLException { if (this.returnParamAccessors == null) this.returnParamAccessors = new Accessor[this.numberOfBindPositions];  if (this.returnParamMeta == null) this.returnParamMeta = new int[3 + this.numberOfBindPositions * 4];  switch (paramInt3) { case -16: case -15: case -9: case 2011: paramShort = 2; break;case 2009: paramString = "SYS.XMLTYPE"; break; }  Accessor accessor = allocateAccessor(paramInt2, paramInt3, paramInt1 + 1, paramInt4, paramShort, paramString, true); accessor.isDMLReturnedParam = true; this.returnParamAccessors[paramInt1] = accessor; boolean bool = (accessor.charLength > 0) ? true : false; this.returnParamMeta[3 + paramInt1 * 4 + 0] = accessor.defineType; this.returnParamMeta[3 + paramInt1 * 4 + 1] = bool ? 1 : 0; this.returnParamMeta[3 + paramInt1 * 4 + 2] = bool ? accessor.charLength : accessor.byteLength; this.returnParamMeta[3 + paramInt1 * 4 + 3] = paramShort; } public int creationState() { synchronized (this.connection) { return this.creationState; }  } public boolean isColumnSetNull(int paramInt) { return this.columnSetNull; } public boolean isNCHAR(int paramInt) throws SQLException { if (!this.described) describe();  int i = paramInt - 1; if (i < 0 || i >= this.numberOfDefinePositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  return ((this.accessors[i]).formOfUse == 2); }
/*      */   void addChild(OracleStatement paramOracleStatement) { paramOracleStatement.nextChild = this.children; this.children = paramOracleStatement; paramOracleStatement.parent = this; }
/*      */   void removeChild(OracleStatement paramOracleStatement) { if (paramOracleStatement == this.children) { this.children = paramOracleStatement.nextChild; } else { OracleStatement oracleStatement = this.children; while (oracleStatement.nextChild != paramOracleStatement) oracleStatement = oracleStatement.nextChild;  oracleStatement.nextChild = paramOracleStatement.nextChild; }  paramOracleStatement.parent = null; paramOracleStatement.nextChild = null; }
/*      */   public boolean getMoreResults(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*      */   public ResultSet getGeneratedKeys() throws SQLException { if (this.closed) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.isAutoGeneratedKey) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90); sQLException.fillInStackTrace(); throw sQLException; }  if (this.returnParamAccessors == null || this.numReturnParams == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144); sQLException.fillInStackTrace(); throw sQLException; }  if (this.returnResultSet == null) this.returnResultSet = new OracleReturnResultSet(this);  return (ResultSet)this.returnResultSet; }
/* 6026 */   public void setDatabaseChangeRegistration(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException { this.registration = (NTFDCNRegistration)paramDatabaseChangeRegistration; }
/*      */   public int executeUpdate(String paramString, int paramInt) throws SQLException { this.autoKeyInfo = new AutoKeyInfo(paramString); if (paramInt == 2 || !this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  if (paramInt != 1) { this.autoKeyInfo = null; SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { this.isAutoGeneratedKey = true; String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = 1; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  }
/*      */   public int executeUpdate(String paramString, int[] paramArrayOfint) throws SQLException { if (paramArrayOfint == null || paramArrayOfint.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfint.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  }
/*      */   public int executeUpdate(String paramString, String[] paramArrayOfString) throws SQLException { if (paramArrayOfString == null || paramArrayOfString.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfString.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  }
/*      */   public boolean execute(String paramString, int paramInt) throws SQLException { this.autoKeyInfo = new AutoKeyInfo(paramString); if (paramInt == 2 || !this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  if (paramInt != 1) { this.autoKeyInfo = null; SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { this.isAutoGeneratedKey = true; String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = 1; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  }
/* 6031 */   public boolean execute(String paramString, int[] paramArrayOfint) throws SQLException { if (paramArrayOfint == null || paramArrayOfint.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfint.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  } public boolean execute(String paramString, String[] paramArrayOfString) throws SQLException { if (paramArrayOfString == null || paramArrayOfString.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfString.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  } public int getResultSetHoldability() throws SQLException { return 1; } public int getcacheState() { return this.cacheState; } public int getstatementType() { return this.statementType; } public boolean getserverCursor() { return this.serverCursor; } void initializeIndicatorSubRange() { this.bindIndicatorSubRange = 0; } private void autoKeyRegisterReturnParams() throws SQLException { initializeIndicatorSubRange(); int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10; int j = i + 2 * this.numberOfBindPositions; this.bindIndicators = new short[j]; int k = this.bindIndicatorSubRange; this.bindIndicators[k + 0] = (short)this.numberOfBindPositions; this.bindIndicators[k + 1] = 0; this.bindIndicators[k + 2] = 1; this.bindIndicators[k + 3] = 0; this.bindIndicators[k + 4] = 1; k += 5; short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses; int[] arrayOfInt = this.autoKeyInfo.columnIndexes; for (byte b = 0; b < this.numberOfBindPositions; b++) { this.bindIndicators[k + 0] = 994; byte b1 = this.connection.defaultnchar ? 2 : 1; if (arrayOfShort != null && arrayOfInt != null) if (arrayOfShort[arrayOfInt[b] - 1] == 2) { b1 = 2; this.bindIndicators[k + 9] = b1; }   k += 10; checkTypeForAutoKey(this.autoKeyInfo.returnTypes[b]); String str = null; if (this.autoKeyInfo.returnTypes[b] == 111) str = this.autoKeyInfo.tableTypeNames[arrayOfInt[b] - 1];  registerReturnParameterInternal(b, this.autoKeyInfo.returnTypes[b], this.autoKeyInfo.returnTypes[b], -1, b1, str); }  } private final void setNonAutoKey() { this.isAutoGeneratedKey = false; this.numberOfBindPositions = 0; this.bindIndicators = null; this.returnParamMeta = null; } void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException { if (paramArrayOfchar != this.defineChars) this.connection.cacheBuffer(paramArrayOfchar);  if (paramArrayOfbyte != this.defineBytes) this.connection.cacheBuffer(paramArrayOfbyte);  } public String[] getRegisteredTableNames() throws SQLException { return this.dcnTableName; }
/*      */   final void checkTypeForAutoKey(int paramInt) throws SQLException { if (paramInt == 109) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 5); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   void moveAllTempLobsToFree() { if (this.oldTempClobsToFree != null) { if (this.tempClobsToFree == null) { this.tempClobsToFree = this.oldTempClobsToFree; } else { this.tempClobsToFree.add(this.oldTempClobsToFree); }  this.oldTempClobsToFree = null; }  if (this.oldTempBlobsToFree != null) { if (this.tempBlobsToFree == null) { this.tempBlobsToFree = this.oldTempBlobsToFree; } else { this.tempBlobsToFree.add(this.oldTempBlobsToFree); }  this.oldTempBlobsToFree = null; }  }
/*      */   void moveTempLobsToFree(CLOB paramCLOB) { int i; if (this.oldTempClobsToFree != null && (i = this.oldTempClobsToFree.indexOf(paramCLOB)) != -1) { addToTempLobsToFree(paramCLOB); this.oldTempClobsToFree.remove(i); }  }
/* 6035 */   void moveTempLobsToFree(BLOB paramBLOB) { int i; if (this.oldTempBlobsToFree != null && (i = this.oldTempBlobsToFree.indexOf(paramBLOB)) != -1) { addToTempLobsToFree(paramBLOB); this.oldTempBlobsToFree.remove(i); }  } void addToTempLobsToFree(CLOB paramCLOB) { if (this.tempClobsToFree == null) this.tempClobsToFree = new ArrayList();  this.tempClobsToFree.add(paramCLOB); } void addToTempLobsToFree(BLOB paramBLOB) { if (this.tempBlobsToFree == null) this.tempBlobsToFree = new ArrayList();  this.tempBlobsToFree.add(paramBLOB); } void addToOldTempLobsToFree(CLOB paramCLOB) { if (this.oldTempClobsToFree == null) this.oldTempClobsToFree = new ArrayList();  this.oldTempClobsToFree.add(paramCLOB); } void addToOldTempLobsToFree(BLOB paramBLOB) { if (this.oldTempBlobsToFree == null) this.oldTempBlobsToFree = new ArrayList();  this.oldTempBlobsToFree.add(paramBLOB); } void cleanAllTempLobs() { cleanTempClobs(this.tempClobsToFree); this.tempClobsToFree = null; cleanTempBlobs(this.tempBlobsToFree); this.tempBlobsToFree = null; cleanTempClobs(this.oldTempClobsToFree); this.oldTempClobsToFree = null; cleanTempBlobs(this.oldTempBlobsToFree); this.oldTempBlobsToFree = null; } void cleanOldTempLobs() { cleanTempClobs(this.oldTempClobsToFree); cleanTempBlobs(this.oldTempBlobsToFree); this.oldTempClobsToFree = this.tempClobsToFree; this.tempClobsToFree = null; this.oldTempBlobsToFree = this.tempBlobsToFree; this.tempBlobsToFree = null; } void cleanTempClobs(ArrayList paramArrayList) { if (paramArrayList != null) { Iterator<CLOB> iterator = paramArrayList.iterator(); while (iterator.hasNext()) { try { ((CLOB)iterator.next()).freeTemporary(); } catch (SQLException sQLException) {} }  }  } void cleanTempBlobs(ArrayList paramArrayList) { if (paramArrayList != null) { Iterator<BLOB> iterator = paramArrayList.iterator(); while (iterator.hasNext()) { try { ((BLOB)iterator.next()).freeTemporary(); } catch (SQLException sQLException) {} }  }  } TimeZone getDefaultTimeZone() throws SQLException { return getDefaultTimeZone(false); } TimeZone getDefaultTimeZone(boolean paramBoolean) throws SQLException { if (this.defaultTimeZone == null) { try { this.defaultTimeZone = this.connection.getDefaultTimeZone(); } catch (SQLException sQLException) {} if (this.defaultTimeZone == null) this.defaultTimeZone = TimeZone.getDefault();  }  return this.defaultTimeZone; } public long getRegisteredQueryId() throws SQLException { return this.dcnQueryId; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Calendar getDefaultCalendar() throws SQLException {
/* 6043 */     if (this.defaultCalendar == null)
/*      */     {
/* 6045 */       this.defaultCalendar = Calendar.getInstance(getDefaultTimeZone());
/*      */     }
/*      */     
/* 6048 */     return this.defaultCalendar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/* 6054 */     this.cachedDefineIndicatorSize = (this.defineIndicators != null) ? this.defineIndicators.length : 0;
/* 6055 */     this.cachedDefineMetaDataSize = (this.defineMetaData != null) ? this.defineMetaData.length : 0;
/* 6056 */     this.connection.cacheBuffer(this.defineChars);
/* 6057 */     this.defineChars = null;
/* 6058 */     this.connection.cacheBuffer(this.defineBytes);
/* 6059 */     this.defineBytes = null;
/* 6060 */     this.defineIndicators = null;
/* 6061 */     this.defineMetaData = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/* 6069 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPoolable() throws SQLException {
/* 6081 */     if (this.closed) {
/*      */       
/* 6083 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6084 */       sQLException.fillInStackTrace();
/* 6085 */       throw sQLException;
/*      */     } 
/*      */     
/* 6088 */     return (this.cacheState != 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPoolable(boolean paramBoolean) throws SQLException {
/* 6104 */     if (this.closed) {
/*      */       
/* 6106 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6107 */       sQLException.fillInStackTrace();
/* 6108 */       throw sQLException;
/*      */     } 
/*      */     
/* 6111 */     if (paramBoolean) {
/* 6112 */       this.cacheState = 1;
/*      */     } else {
/*      */       
/* 6115 */       this.cacheState = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 6131 */     if (paramClass.isInterface()) return paramClass.isInstance(this);
/*      */     
/* 6133 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 6134 */     sQLException.fillInStackTrace();
/* 6135 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 6152 */     if (paramClass.isInterface() && paramClass.isInstance(this)) return (T)this;
/*      */     
/* 6154 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
/* 6155 */     sQLException.fillInStackTrace();
/* 6156 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 6173 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Calendar getGMTCalendar() {
/* 6184 */     if (this.gmtCalendar == null)
/*      */     {
/* 6186 */       this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);
/*      */     }
/*      */ 
/*      */     
/* 6190 */     return this.gmtCalendar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void extractNioDefineBuffers(int paramInt) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processLobPrefetchMetaData(Object[] paramArrayOfObject) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internalClose() throws SQLException {
/* 6215 */     this.closed = true;
/* 6216 */     if (this.currentResultSet != null) {
/* 6217 */       this.currentResultSet.closed = true;
/*      */     }
/* 6219 */     cleanupDefines();
/* 6220 */     this.bindBytes = null;
/* 6221 */     this.bindChars = null;
/* 6222 */     this.bindIndicators = null;
/*      */     
/* 6224 */     this.outBindAccessors = null;
/* 6225 */     this.parameterStream = (InputStream[][])null;
/* 6226 */     this.userStream = (Object[][])null;
/*      */     
/* 6228 */     this.ibtBindBytes = null;
/* 6229 */     this.ibtBindChars = null;
/* 6230 */     this.ibtBindIndicators = null;
/*      */     
/* 6232 */     this.lobPrefetchMetaData = null;
/* 6233 */     this.tmpByteArray = null;
/*      */     
/* 6235 */     this.definedColumnType = null;
/* 6236 */     this.definedColumnSize = null;
/* 6237 */     this.definedColumnFormOfUse = null;
/*      */ 
/*      */ 
/*      */     
/* 6241 */     if (this.wrapper != null) {
/* 6242 */       this.wrapper.close();
/*      */     }
/*      */   }
/*      */   
/*      */   void calculateCheckSum() throws SQLException {
/* 6247 */     if (!this.connection.calculateChecksum) {
/*      */       return;
/*      */     }
/* 6250 */     if (this.accessors != null) {
/* 6251 */       accessorChecksum(this.accessors);
/*      */     }
/* 6253 */     if (this.outBindAccessors != null) {
/* 6254 */       accessorChecksum(this.outBindAccessors);
/*      */     }
/* 6256 */     if (this.returnParamAccessors != null && this.returnParamsFetched) {
/* 6257 */       accessorChecksum(this.returnParamAccessors);
/*      */     }
/* 6259 */     long l = CRC64.updateChecksum(this.checkSum, this.validRows);
/* 6260 */     this.checkSum = l;
/*      */   }
/*      */ 
/*      */   
/*      */   void accessorChecksum(Accessor[] paramArrayOfAccessor) throws SQLException {
/* 6265 */     long l = this.checkSum;
/* 6266 */     byte b = 0;
/* 6267 */     boolean bool = false;
/*      */ 
/*      */     
/* 6270 */     for (Accessor accessor : paramArrayOfAccessor) {
/*      */       
/* 6272 */       if (accessor != null) {
/*      */         byte b1;
/* 6274 */         switch (accessor.internalType) {
/*      */           
/*      */           case 112:
/*      */           case 113:
/*      */           case 114:
/* 6279 */             if (!b) {
/* 6280 */               bool = true;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 24:
/* 6287 */             bool = false;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 6292 */             bool = false;
/*      */ 
/*      */ 
/*      */             
/* 6296 */             b++;
/* 6297 */             for (b1 = 0; b1 < this.validRows; b1++) {
/*      */               
/* 6299 */               if (accessor.rowSpaceIndicator != null)
/* 6300 */                 l = accessor.updateChecksum(l, b1); 
/*      */             }  break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 6305 */     if (bool) {
/* 6306 */       this.checkSumComputationFailure = true;
/*      */     }
/* 6308 */     this.checkSum = l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getChecksum() throws SQLException {
/* 6316 */     if (this.checkSumComputationFailure) {
/*      */       
/* 6318 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 6319 */       sQLException.fillInStackTrace();
/* 6320 */       throw sQLException;
/*      */     } 
/*      */     
/* 6323 */     return this.checkSum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte convertSqlKindEnumToByte(OracleStatement.SqlKind paramSqlKind) {
/* 6340 */     switch (paramSqlKind) {
/*      */       
/*      */       case DELETE:
/* 6343 */         return 2;
/*      */       
/*      */       case INSERT:
/* 6346 */         return 4;
/*      */       
/*      */       case MERGE:
/* 6349 */         return 8;
/*      */       
/*      */       case UPDATE:
/* 6352 */         return 16;
/*      */       
/*      */       case ALTER_SESSION:
/*      */       case OTHER:
/* 6356 */         return Byte.MIN_VALUE;
/*      */       
/*      */       case PLSQL_BLOCK:
/* 6359 */         return 32;
/*      */       
/*      */       case CALL_BLOCK:
/* 6362 */         return 64;
/*      */       
/*      */       case SELECT_FOR_UPDATE:
/*      */       case SELECT:
/* 6366 */         return 1;
/*      */     } 
/*      */     
/* 6369 */     if (paramSqlKind.isPlsqlOrCall())
/* 6370 */       return 96; 
/* 6371 */     if (paramSqlKind.isDML()) {
/* 6372 */       return 30;
/*      */     }
/* 6374 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   static final OracleStatement.SqlKind convertSqlKindByteToEnum(byte paramByte) {
/* 6379 */     switch (paramByte) {
/*      */       
/*      */       case 2:
/* 6382 */         return OracleStatement.SqlKind.DELETE;
/*      */       
/*      */       case 4:
/* 6385 */         return OracleStatement.SqlKind.INSERT;
/*      */       
/*      */       case 8:
/* 6388 */         return OracleStatement.SqlKind.MERGE;
/*      */       
/*      */       case 16:
/* 6391 */         return OracleStatement.SqlKind.UPDATE;
/*      */       
/*      */       case -128:
/* 6394 */         return OracleStatement.SqlKind.OTHER;
/*      */       
/*      */       case 32:
/* 6397 */         return OracleStatement.SqlKind.PLSQL_BLOCK;
/*      */       
/*      */       case 64:
/* 6400 */         return OracleStatement.SqlKind.CALL_BLOCK;
/*      */       
/*      */       case 1:
/* 6403 */         return OracleStatement.SqlKind.SELECT;
/*      */     } 
/*      */ 
/*      */     
/* 6407 */     return OracleStatement.SqlKind.UNINITIALIZED;
/*      */   }
/*      */ 
/*      */   
/* 6411 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   abstract void doDescribe(boolean paramBoolean) throws SQLException;
/*      */   
/*      */   abstract void executeForDescribe() throws SQLException;
/*      */   
/*      */   abstract void executeForRows(boolean paramBoolean) throws SQLException;
/*      */   
/*      */   abstract void fetch() throws SQLException;
/*      */   
/*      */   abstract void doClose() throws SQLException;
/*      */   
/*      */   abstract void closeQuery() throws SQLException;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */