/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.EventListener;
/*     */ import java.util.concurrent.Executor;
/*     */ import oracle.jdbc.aq.AQNotificationListener;
/*     */ import oracle.jdbc.dcn.DatabaseChangeListener;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.internal.XSEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFEventListener
/*     */ {
/*     */   private final AQNotificationListener aqlistener;
/*     */   private final DatabaseChangeListener dcnlistener;
/*     */   private final XSEventListener xslistener;
/*  52 */   private Executor executor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NTFEventListener(DatabaseChangeListener paramDatabaseChangeListener) throws SQLException {
/*  58 */     if (paramDatabaseChangeListener == null) {
/*     */ 
/*     */ 
/*     */       
/*  62 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
/*  63 */       sQLException.fillInStackTrace();
/*  64 */       throw sQLException;
/*     */     } 
/*     */     
/*  67 */     this.dcnlistener = paramDatabaseChangeListener;
/*  68 */     this.aqlistener = null;
/*  69 */     this.xslistener = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NTFEventListener(AQNotificationListener paramAQNotificationListener) throws SQLException {
/*  77 */     if (paramAQNotificationListener == null) {
/*     */ 
/*     */ 
/*     */       
/*  81 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
/*  82 */       sQLException.fillInStackTrace();
/*  83 */       throw sQLException;
/*     */     } 
/*     */     
/*  86 */     this.aqlistener = paramAQNotificationListener;
/*  87 */     this.dcnlistener = null;
/*  88 */     this.xslistener = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NTFEventListener(XSEventListener paramXSEventListener) throws SQLException {
/*  96 */     if (paramXSEventListener == null) {
/*     */ 
/*     */ 
/*     */       
/* 100 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
/* 101 */       sQLException.fillInStackTrace();
/* 102 */       throw sQLException;
/*     */     } 
/*     */     
/* 105 */     this.aqlistener = null;
/* 106 */     this.dcnlistener = null;
/* 107 */     this.xslistener = paramXSEventListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setExecutor(Executor paramExecutor) {
/* 114 */     this.executor = paramExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Executor getExecutor() {
/* 120 */     return this.executor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   EventListener getListener() {
/*     */     AQNotificationListener aQNotificationListener;
/* 127 */     DatabaseChangeListener databaseChangeListener = this.dcnlistener;
/* 128 */     if (databaseChangeListener == null)
/* 129 */       aQNotificationListener = this.aqlistener; 
/* 130 */     return (EventListener)aQNotificationListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AQNotificationListener getAQListener() {
/* 137 */     return this.aqlistener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DatabaseChangeListener getDCNListener() {
/* 144 */     return this.dcnlistener;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XSEventListener getXSEventListener() {
/* 150 */     return this.xslistener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 172 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NTFEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */