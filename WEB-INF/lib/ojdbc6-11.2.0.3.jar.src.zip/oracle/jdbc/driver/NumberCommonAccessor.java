/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Map;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.NUMBER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class NumberCommonAccessor
/*      */   extends Accessor
/*      */ {
/*      */   static final boolean GET_XXX_ROUNDS = false;
/*      */   
/*      */   void init(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*   27 */     init(paramOracleStatement, 6, 6, paramShort, paramBoolean);
/*   28 */     initForDataAccess(paramInt2, paramInt1, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
/*   37 */     init(paramOracleStatement, 6, 6, paramShort, false);
/*   38 */     initForDescribe(paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, null);
/*      */     
/*   40 */     initForDataAccess(0, paramInt2, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*   48 */     if (paramInt1 != 0) {
/*   49 */       this.externalType = paramInt1;
/*      */     }
/*   51 */     this.internalTypeMaxLength = 21;
/*      */     
/*   53 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*   54 */       this.internalTypeMaxLength = paramInt2;
/*      */     }
/*   56 */     this.byteLength = this.internalTypeMaxLength + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getInt(int paramInt) throws SQLException {
/*   74 */     int i = 0;
/*      */     
/*   76 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*   78 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*   79 */       sQLException.fillInStackTrace();
/*   80 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*   85 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*   87 */       byte[] arrayOfByte = this.rowSpaceByte;
/*   88 */       int j = this.columnIndex + this.byteLength * paramInt + 1;
/*   89 */       byte b1 = arrayOfByte[j - 1];
/*   90 */       byte b2 = arrayOfByte[j];
/*      */       
/*   92 */       int k = 0;
/*      */ 
/*      */ 
/*      */       
/*   96 */       if ((b2 & Byte.MIN_VALUE) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  101 */         byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
/*  102 */         byte b4 = (byte)(b1 - 1);
/*      */         
/*  104 */         int m = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
/*  105 */         int n = m + j;
/*      */         
/*  107 */         if (b3 >= 4)
/*      */         {
/*  109 */           if (b3 > 4)
/*      */           {
/*      */             
/*  112 */             throwOverflow();
/*      */           }
/*  114 */           long l = 0L;
/*      */           
/*  116 */           if (m > 1) {
/*      */             
/*  118 */             l = (arrayOfByte[j + 1] - 1);
/*      */             
/*  120 */             for (int i2 = 2 + j; i2 < n; i2++) {
/*  121 */               l = l * 100L + (arrayOfByte[i2] - 1);
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  128 */           for (int i1 = b3 - b4; i1 >= 0; i1--) {
/*  129 */             l *= 100L;
/*      */           }
/*  131 */           if (l > 2147483647L) {
/*  132 */             throwOverflow();
/*      */           }
/*  134 */           k = (int)l;
/*      */         }
/*      */         else
/*      */         {
/*  138 */           if (m > 1) {
/*      */             
/*  140 */             k = arrayOfByte[j + 1] - 1;
/*      */             
/*  142 */             for (int i2 = 2 + j; i2 < n; i2++) {
/*  143 */               k = k * 100 + arrayOfByte[i2] - 1;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  150 */           for (int i1 = b3 - b4; i1 >= 0; i1--) {
/*  151 */             k *= 100;
/*      */           
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  159 */         byte b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
/*  160 */         byte b4 = (byte)(b1 - 1);
/*      */         
/*  162 */         if (b4 != 20 || arrayOfByte[j + b4] == 102) {
/*  163 */           b4 = (byte)(b4 - 1);
/*      */         }
/*  165 */         int m = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
/*  166 */         int n = m + j;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  176 */         if (b3 >= 4) {
/*      */           
/*  178 */           if (b3 > 4)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  192 */             throwOverflow();
/*      */           }
/*      */           
/*  195 */           long l = 0L;
/*      */           
/*  197 */           if (m > 1) {
/*      */             
/*  199 */             l = (101 - arrayOfByte[j + 1]);
/*      */             
/*  201 */             for (int i2 = 2 + j; i2 < n; i2++) {
/*  202 */               l = l * 100L + (101 - arrayOfByte[i2]);
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  209 */           for (int i1 = b3 - b4; i1 >= 0; i1--) {
/*  210 */             l *= 100L;
/*      */           }
/*  212 */           l = -l;
/*      */           
/*  214 */           if (l < -2147483648L) {
/*  215 */             throwOverflow();
/*      */           }
/*  217 */           k = (int)l;
/*      */         }
/*      */         else {
/*      */           
/*  221 */           if (m > 1) {
/*      */             
/*  223 */             k = 101 - arrayOfByte[j + 1];
/*      */             
/*  225 */             for (int i2 = 2 + j; i2 < n; i2++) {
/*  226 */               k = k * 100 + 101 - arrayOfByte[i2];
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  233 */           for (int i1 = b3 - b4; i1 >= 0; i1--) {
/*  234 */             k *= 100;
/*      */           }
/*  236 */           k = -k;
/*      */         } 
/*      */       } 
/*      */       
/*  240 */       i = k;
/*      */     } 
/*      */     
/*  243 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getBoolean(int paramInt) throws SQLException {
/*  259 */     boolean bool = false;
/*      */     
/*  261 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  263 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  264 */       sQLException.fillInStackTrace();
/*  265 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  270 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*  272 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  273 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  274 */       byte b = arrayOfByte[i - 1];
/*      */       
/*  276 */       bool = (b != 1 || arrayOfByte[i] != Byte.MIN_VALUE) ? true : false;
/*      */     } 
/*      */     
/*  279 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   short getShort(int paramInt) throws SQLException {
/*  295 */     short s = 0;
/*      */     
/*  297 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  299 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  300 */       sQLException.fillInStackTrace();
/*  301 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  306 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */ 
/*      */       
/*  309 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  310 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  311 */       byte b1 = arrayOfByte[i - 1];
/*      */       
/*  313 */       byte b2 = arrayOfByte[i];
/*      */       
/*  315 */       int j = 0;
/*      */ 
/*      */ 
/*      */       
/*  319 */       if ((b2 & Byte.MIN_VALUE) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  324 */         byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
/*      */         
/*  326 */         if (b3 > 2)
/*      */         {
/*      */           
/*  329 */           throwOverflow();
/*      */         }
/*  331 */         byte b4 = (byte)(b1 - 1);
/*      */         
/*  333 */         int k = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
/*  334 */         int m = k + i;
/*      */         
/*  336 */         if (k > 1) {
/*      */           
/*  338 */           j = arrayOfByte[i + 1] - 1;
/*      */           
/*  340 */           for (int i1 = 2 + i; i1 < m; i1++) {
/*  341 */             j = j * 100 + arrayOfByte[i1] - 1;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  348 */         for (int n = b3 - b4; n >= 0; n--) {
/*  349 */           j *= 100;
/*      */         }
/*  351 */         if (b3 == 2 && 
/*  352 */           j > 32767) {
/*  353 */           throwOverflow();
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  360 */         byte b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
/*      */         
/*  362 */         if (b3 > 2)
/*      */         {
/*      */           
/*  365 */           throwOverflow();
/*      */         }
/*  367 */         byte b4 = (byte)(b1 - 1);
/*      */         
/*  369 */         if (b4 != 20 || arrayOfByte[i + b4] == 102) {
/*  370 */           b4 = (byte)(b4 - 1);
/*      */         }
/*  372 */         int k = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
/*  373 */         int m = k + i;
/*      */         
/*  375 */         if (k > 1) {
/*      */           
/*  377 */           j = 101 - arrayOfByte[i + 1];
/*      */           
/*  379 */           for (int i1 = 2 + i; i1 < m; i1++) {
/*  380 */             j = j * 100 + 101 - arrayOfByte[i1];
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  387 */         for (int n = b3 - b4; n >= 0; n--) {
/*  388 */           j *= 100;
/*      */         }
/*  390 */         j = -j;
/*      */         
/*  392 */         if (b3 == 2 && 
/*  393 */           j < -32768) {
/*  394 */           throwOverflow();
/*      */         }
/*      */       } 
/*  397 */       s = (short)j;
/*      */     } 
/*      */     
/*  400 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte getByte(int paramInt) throws SQLException {
/*  416 */     byte b = 0;
/*      */     
/*  418 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  420 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  421 */       sQLException.fillInStackTrace();
/*  422 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  427 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */ 
/*      */       
/*  430 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  431 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  432 */       byte b1 = arrayOfByte[i - 1];
/*      */       
/*  434 */       byte b2 = arrayOfByte[i];
/*      */       
/*  436 */       int j = 0;
/*      */ 
/*      */ 
/*      */       
/*  440 */       if ((b2 & Byte.MIN_VALUE) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  445 */         byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
/*      */         
/*  447 */         if (b3 > 1)
/*      */         {
/*      */           
/*  450 */           throwOverflow();
/*      */         }
/*  452 */         byte b4 = (byte)(b1 - 1);
/*      */         
/*  454 */         if (b4 > b3 + 1) {
/*      */           
/*  456 */           switch (b3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 0:
/*  469 */               j = arrayOfByte[i + 1] - 1;
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 1:
/*  477 */               j = (arrayOfByte[i + 1] - 1) * 100 + arrayOfByte[i + 2] - 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  483 */               if (j > 127) {
/*  484 */                 throwOverflow();
/*      */               }
/*      */               break;
/*      */           } 
/*      */         
/*  489 */         } else if (b4 == 1) {
/*      */           
/*  491 */           if (b3 == 1) {
/*      */             
/*  493 */             j = (arrayOfByte[i + 1] - 1) * 100;
/*      */             
/*  495 */             if (j > 127) {
/*  496 */               throwOverflow();
/*      */             }
/*      */           } else {
/*  499 */             j = arrayOfByte[i + 1] - 1;
/*      */           } 
/*  501 */         } else if (b4 == 2) {
/*      */           
/*  503 */           j = (arrayOfByte[i + 1] - 1) * 100 + arrayOfByte[i + 2] - 1;
/*      */ 
/*      */           
/*  506 */           if (j > 127) {
/*  507 */             throwOverflow();
/*      */           
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  515 */         byte b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
/*      */         
/*  517 */         if (b3 > 1)
/*      */         {
/*      */           
/*  520 */           throwOverflow();
/*      */         }
/*  522 */         byte b4 = (byte)(b1 - 1);
/*      */         
/*  524 */         if (b4 != 20 || arrayOfByte[i + b4] == 102) {
/*  525 */           b4 = (byte)(b4 - 1);
/*      */         }
/*  527 */         if (b4 > b3 + 1) {
/*      */           
/*  529 */           switch (b3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 0:
/*  542 */               j = -(101 - arrayOfByte[i + 1]);
/*      */               break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 1:
/*  550 */               j = -((101 - arrayOfByte[i + 1]) * 100 + 101 - arrayOfByte[i + 2]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  556 */               if (j < -128) {
/*  557 */                 throwOverflow();
/*      */               }
/*      */               break;
/*      */           } 
/*      */         
/*  562 */         } else if (b4 == 1) {
/*      */           
/*  564 */           if (b3 == 1) {
/*      */             
/*  566 */             j = -(101 - arrayOfByte[i + 1]) * 100;
/*      */             
/*  568 */             if (j < -128) {
/*  569 */               throwOverflow();
/*      */             }
/*      */           } else {
/*  572 */             j = -(101 - arrayOfByte[i + 1]);
/*      */           } 
/*  574 */         } else if (b4 == 2) {
/*      */           
/*  576 */           j = -((101 - arrayOfByte[i + 1]) * 100 + 101 - arrayOfByte[i + 2]);
/*      */ 
/*      */           
/*  579 */           if (j < -128) {
/*  580 */             throwOverflow();
/*      */           }
/*      */         } 
/*      */       } 
/*  584 */       b = (byte)j;
/*      */     } 
/*      */     
/*  587 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getLong(int paramInt) throws SQLException {
/*  603 */     long l = 0L;
/*      */     
/*  605 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  607 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  608 */       sQLException.fillInStackTrace();
/*  609 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  614 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */ 
/*      */       
/*  617 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  618 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  619 */       byte b1 = arrayOfByte[i - 1];
/*      */       
/*  621 */       byte b2 = arrayOfByte[i];
/*  622 */       long l1 = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  630 */       if ((b2 & Byte.MIN_VALUE) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  635 */         if (b2 == Byte.MIN_VALUE && b1 == 1) {
/*  636 */           return 0L;
/*      */         }
/*  638 */         byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  643 */         if (b3 > 9)
/*      */         {
/*      */           
/*  646 */           throwOverflow();
/*      */         }
/*  648 */         if (b3 == 9) {
/*      */           
/*  650 */           byte b = 1;
/*  651 */           byte b5 = b1;
/*      */           
/*  653 */           if (b1 > 11) {
/*  654 */             b5 = 11;
/*      */           }
/*  656 */           while (b < b5) {
/*      */ 
/*      */ 
/*      */             
/*  660 */             int n = arrayOfByte[i + b] & 0xFF;
/*  661 */             int i1 = MAX_LONG[b];
/*      */             
/*  663 */             if (n != i1) {
/*      */               
/*  665 */               if (n < i1) {
/*      */                 break;
/*      */               }
/*  668 */               throwOverflow();
/*      */             } 
/*      */             
/*  671 */             b++;
/*      */           } 
/*      */           
/*  674 */           if (b == b5 && b1 > 11) {
/*  675 */             throwOverflow();
/*      */           }
/*      */         } 
/*  678 */         byte b4 = (byte)(b1 - 1);
/*      */         
/*  680 */         int j = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
/*  681 */         int k = j + i;
/*      */         
/*  683 */         if (j > 1) {
/*      */           
/*  685 */           l1 = (arrayOfByte[i + 1] - 1);
/*      */           
/*  687 */           for (int n = 2 + i; n < k; n++) {
/*  688 */             l1 = l1 * 100L + (arrayOfByte[n] - 1);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  695 */         for (int m = b3 - b4; m >= 0; m--) {
/*  696 */           l1 *= 100L;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  703 */         byte b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  708 */         if (b3 > 9)
/*      */         {
/*      */           
/*  711 */           throwOverflow();
/*      */         }
/*  713 */         if (b3 == 9) {
/*      */           
/*  715 */           byte b = 1;
/*  716 */           byte b5 = b1;
/*      */           
/*  718 */           if (b1 > 12) {
/*  719 */             b5 = 12;
/*      */           }
/*  721 */           while (b < b5) {
/*      */ 
/*      */ 
/*      */             
/*  725 */             int n = arrayOfByte[i + b] & 0xFF;
/*  726 */             int i1 = MIN_LONG[b];
/*      */             
/*  728 */             if (n != i1) {
/*      */               
/*  730 */               if (n > i1) {
/*      */                 break;
/*      */               }
/*  733 */               throwOverflow();
/*      */             } 
/*      */             
/*  736 */             b++;
/*      */           } 
/*      */           
/*  739 */           if (b == b5 && b1 < 12) {
/*  740 */             throwOverflow();
/*      */           }
/*      */         } 
/*  743 */         byte b4 = (byte)(b1 - 1);
/*      */         
/*  745 */         if (b4 != 20 || arrayOfByte[i + b4] == 102) {
/*  746 */           b4 = (byte)(b4 - 1);
/*      */         }
/*  748 */         int j = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
/*  749 */         int k = j + i;
/*      */         
/*  751 */         if (j > 1) {
/*      */           
/*  753 */           l1 = (101 - arrayOfByte[i + 1]);
/*      */           
/*  755 */           for (int n = 2 + i; n < k; n++) {
/*  756 */             l1 = l1 * 100L + (101 - arrayOfByte[n]);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  763 */         for (int m = b3 - b4; m >= 0; m--) {
/*  764 */           l1 *= 100L;
/*      */         }
/*  766 */         l1 = -l1;
/*      */       } 
/*      */       
/*  769 */       l = l1;
/*      */     } 
/*      */     
/*  772 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float getFloat(int paramInt) throws SQLException {
/*  788 */     float f = 0.0F;
/*      */     
/*  790 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  792 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  793 */       sQLException.fillInStackTrace();
/*  794 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  799 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */ 
/*      */       
/*  802 */       byte[] arrayOfByte = this.rowSpaceByte;
/*  803 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/*  804 */       byte b1 = arrayOfByte[i - 1];
/*      */       
/*  806 */       byte b2 = arrayOfByte[i];
/*      */ 
/*      */       
/*  809 */       double d = 0.0D;
/*      */       
/*  811 */       int j = i + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  822 */       if ((b2 & Byte.MIN_VALUE) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  827 */         if (b2 == Byte.MIN_VALUE && b1 == 1) {
/*  828 */           return 0.0F;
/*      */         }
/*  830 */         if (b1 == 2 && b2 == -1 && arrayOfByte[i + 1] == 101)
/*      */         {
/*  832 */           return Float.POSITIVE_INFINITY;
/*      */         }
/*  834 */         byte b = (byte)((b2 & 0xFFFFFF7F) - 65);
/*      */         
/*  836 */         int m = b1 - 1;
/*      */         
/*  838 */         while (arrayOfByte[j] == 1 && m > 0) {
/*      */           
/*  840 */           j++;
/*  841 */           m--;
/*  842 */           b = (byte)(b - 1);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  850 */         int k = (int)(127.0D - b);
/*      */         
/*  852 */         switch (m) {
/*      */ 
/*      */           
/*      */           case 1:
/*  856 */             d = (arrayOfByte[j] - 1) * factorTable[k];
/*      */             break;
/*      */ 
/*      */           
/*      */           case 2:
/*  861 */             d = ((arrayOfByte[j] - 1) * 100 + arrayOfByte[j + 1] - 1) * factorTable[k + 1];
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 3:
/*  867 */             d = ((arrayOfByte[j] - 1) * 10000 + (arrayOfByte[j + 1] - 1) * 100 + arrayOfByte[j + 2] - 1) * factorTable[k + 2];
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 4:
/*  874 */             d = ((arrayOfByte[j] - 1) * 1000000 + (arrayOfByte[j + 1] - 1) * 10000 + (arrayOfByte[j + 2] - 1) * 100 + arrayOfByte[j + 3] - 1) * factorTable[k + 3];
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 5:
/*  881 */             d = ((arrayOfByte[j + 1] - 1) * 1000000 + (arrayOfByte[j + 2] - 1) * 10000 + (arrayOfByte[j + 3] - 1) * 100 + arrayOfByte[j + 4] - 1) * factorTable[k + 4] + (arrayOfByte[j] - 1) * factorTable[k];
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 6:
/*  890 */             d = ((arrayOfByte[j + 2] - 1) * 1000000 + (arrayOfByte[j + 3] - 1) * 10000 + (arrayOfByte[j + 4] - 1) * 100 + arrayOfByte[j + 5] - 1) * factorTable[k + 5] + ((arrayOfByte[j] - 1) * 100 + arrayOfByte[j + 1] - 1) * factorTable[k + 1];
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  899 */             d = ((arrayOfByte[j + 3] - 1) * 1000000 + (arrayOfByte[j + 4] - 1) * 10000 + (arrayOfByte[j + 5] - 1) * 100 + arrayOfByte[j + 6] - 1) * factorTable[k + 6] + ((arrayOfByte[j] - 1) * 10000 + (arrayOfByte[j + 1] - 1) * 100 + arrayOfByte[j + 2] - 1) * factorTable[k + 2];
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       } else {
/*  913 */         if (b2 == 0 && b1 == 1) {
/*  914 */           return Float.NEGATIVE_INFINITY;
/*      */         }
/*  916 */         byte b = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
/*      */         
/*  918 */         int m = b1 - 1;
/*      */         
/*  920 */         if (m != 20 || arrayOfByte[i + m] == 102) {
/*  921 */           m--;
/*      */         }
/*  923 */         while (arrayOfByte[j] == 1 && m > 0) {
/*      */           
/*  925 */           j++;
/*  926 */           m--;
/*  927 */           b = (byte)(b - 1);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  935 */         int k = (int)(127.0D - b);
/*      */         
/*  937 */         switch (m) {
/*      */ 
/*      */           
/*      */           case 1:
/*  941 */             d = -(101 - arrayOfByte[j]) * factorTable[k];
/*      */             break;
/*      */ 
/*      */           
/*      */           case 2:
/*  946 */             d = -((101 - arrayOfByte[j]) * 100 + 101 - arrayOfByte[j + 1]) * factorTable[k + 1];
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 3:
/*  952 */             d = -((101 - arrayOfByte[j]) * 10000 + (101 - arrayOfByte[j + 1]) * 100 + 101 - arrayOfByte[j + 2]) * factorTable[k + 2];
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 4:
/*  959 */             d = -((101 - arrayOfByte[j]) * 1000000 + (101 - arrayOfByte[j + 1]) * 10000 + (101 - arrayOfByte[j + 2]) * 100 + 101 - arrayOfByte[j + 3]) * factorTable[k + 3];
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 5:
/*  966 */             d = -(((101 - arrayOfByte[j + 1]) * 1000000 + (101 - arrayOfByte[j + 2]) * 10000 + (101 - arrayOfByte[j + 3]) * 100 + 101 - arrayOfByte[j + 4]) * factorTable[k + 4] + (101 - arrayOfByte[j]) * factorTable[k]);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 6:
/*  975 */             d = -(((101 - arrayOfByte[j + 2]) * 1000000 + (101 - arrayOfByte[j + 3]) * 10000 + (101 - arrayOfByte[j + 4]) * 100 + 101 - arrayOfByte[j + 5]) * factorTable[k + 5] + ((101 - arrayOfByte[j]) * 100 + 101 - arrayOfByte[j + 1]) * factorTable[k + 1]);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  984 */             d = -(((101 - arrayOfByte[j + 3]) * 1000000 + (101 - arrayOfByte[j + 4]) * 10000 + (101 - arrayOfByte[j + 5]) * 100 + 101 - arrayOfByte[j + 6]) * factorTable[k + 6] + ((101 - arrayOfByte[j]) * 10000 + (101 - arrayOfByte[j + 1]) * 100 + 101 - arrayOfByte[j + 2]) * factorTable[k + 2]);
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/*  995 */       f = (float)d;
/*      */     } 
/*      */     
/*  998 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double getDouble(int paramInt) throws SQLException {
/* 1014 */     double d = 0.0D;
/*      */     
/* 1016 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 1018 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1019 */       sQLException.fillInStackTrace();
/* 1020 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1025 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       double d1; byte b3; int m;
/*      */       boolean bool1;
/* 1028 */       byte[] arrayOfByte = this.rowSpaceByte;
/* 1029 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 1030 */       byte b1 = arrayOfByte[i - 1];
/*      */ 
/*      */       
/* 1033 */       byte b2 = arrayOfByte[i];
/*      */       
/* 1035 */       int j = i + 1;
/* 1036 */       int k = b1 - 1;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1041 */       boolean bool2 = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1051 */       if ((b2 & Byte.MIN_VALUE) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1056 */         if (b2 == Byte.MIN_VALUE && b1 == 1) {
/* 1057 */           return 0.0D;
/*      */         }
/* 1059 */         if (b1 == 2 && b2 == -1 && arrayOfByte[i + 1] == 101)
/*      */         {
/* 1061 */           return Double.POSITIVE_INFINITY;
/*      */         }
/* 1063 */         b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
/*      */         
/* 1065 */         bool1 = ((arrayOfByte[j + k - 1] - 1) % 10 == 0) ? true : false;
/*      */         
/* 1067 */         m = arrayOfByte[j] - 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1080 */         bool2 = false;
/*      */         
/* 1082 */         if (b2 == 0 && b1 == 1) {
/* 1083 */           return Double.NEGATIVE_INFINITY;
/*      */         }
/* 1085 */         b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
/*      */         
/* 1087 */         if (k != 20 || arrayOfByte[i + k] == 102) {
/* 1088 */           k--;
/*      */         }
/* 1090 */         bool1 = ((101 - arrayOfByte[j + k - 1]) % 10 == 0) ? true : false;
/*      */         
/* 1092 */         m = 101 - arrayOfByte[j];
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1101 */       int n = k << 1;
/*      */       
/* 1103 */       if (bool1) {
/* 1104 */         n--;
/*      */       }
/* 1106 */       int i1 = (b3 + 1 << 1) - n;
/*      */       
/* 1108 */       if (m < 10) {
/* 1109 */         n--;
/*      */       }
/* 1111 */       if (n <= 15 && ((i1 >= 0 && i1 <= 37 - n) || (i1 < 0 && i1 >= -22))) {
/*      */         double d2;
/*      */ 
/*      */ 
/*      */         
/* 1116 */         int i2 = 0;
/* 1117 */         int i3 = 0;
/* 1118 */         int i4 = 0;
/* 1119 */         int i5 = 0;
/* 1120 */         int i6 = 0;
/* 1121 */         int i7 = 0;
/* 1122 */         int i8 = 0;
/*      */         
/* 1124 */         if (bool2) {
/* 1125 */           switch (k) {
/*      */ 
/*      */             
/*      */             default:
/* 1129 */               i8 = arrayOfByte[j + 7] - 1;
/*      */             
/*      */             case 7:
/* 1132 */               i7 = arrayOfByte[j + 6] - 1;
/*      */             
/*      */             case 6:
/* 1135 */               i6 = arrayOfByte[j + 5] - 1;
/*      */             
/*      */             case 5:
/* 1138 */               i5 = arrayOfByte[j + 4] - 1;
/*      */             
/*      */             case 4:
/* 1141 */               i4 = arrayOfByte[j + 3] - 1;
/*      */             
/*      */             case 3:
/* 1144 */               i3 = arrayOfByte[j + 2] - 1;
/*      */             
/*      */             case 2:
/* 1147 */               i2 = arrayOfByte[j + 1] - 1;
/*      */               break;
/*      */             case 1:
/*      */               break;
/*      */           } 
/*      */         } else {
/* 1153 */           switch (k) {
/*      */ 
/*      */             
/*      */             default:
/* 1157 */               i8 = 101 - arrayOfByte[j + 7];
/*      */             
/*      */             case 7:
/* 1160 */               i7 = 101 - arrayOfByte[j + 6];
/*      */             
/*      */             case 6:
/* 1163 */               i6 = 101 - arrayOfByte[j + 5];
/*      */             
/*      */             case 5:
/* 1166 */               i5 = 101 - arrayOfByte[j + 4];
/*      */             
/*      */             case 4:
/* 1169 */               i4 = 101 - arrayOfByte[j + 3];
/*      */             
/*      */             case 3:
/* 1172 */               i3 = 101 - arrayOfByte[j + 2];
/*      */             
/*      */             case 2:
/* 1175 */               i2 = 101 - arrayOfByte[j + 1];
/*      */               break;
/*      */ 
/*      */             
/*      */             case 1:
/*      */               break;
/*      */           } 
/*      */         
/*      */         } 
/* 1184 */         if (bool1) {
/* 1185 */           int i9; int i10; switch (k) {
/*      */ 
/*      */             
/*      */             default:
/* 1189 */               d2 = (m / 10);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 2:
/* 1194 */               d2 = (m * 10 + i2 / 10);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/* 1199 */               d2 = (m * 1000 + i2 * 10 + i3 / 10);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 4:
/* 1204 */               d2 = (m * 100000 + i2 * 1000 + i3 * 10 + i4 / 10);
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 5:
/* 1210 */               d2 = (m * 10000000 + i2 * 100000 + i3 * 1000 + i4 * 10 + i5 / 10);
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 6:
/* 1216 */               i9 = i2 * 10000000 + i3 * 100000 + i4 * 1000 + i5 * 10 + i6 / 10;
/*      */               
/* 1218 */               d2 = (m * 1000000000L + i9);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 7:
/* 1223 */               i9 = i3 * 10000000 + i4 * 100000 + i5 * 1000 + i6 * 10 + i7 / 10;
/*      */               
/* 1225 */               i10 = m * 100 + i2;
/* 1226 */               d2 = (i10 * 1000000000L + i9);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 8:
/* 1231 */               i9 = i4 * 10000000 + i5 * 100000 + i6 * 1000 + i7 * 10 + i8 / 10;
/*      */               
/* 1233 */               i10 = m * 10000 + i2 * 100 + i3;
/* 1234 */               d2 = (i10 * 1000000000L + i9); break;
/*      */           } 
/*      */         } else {
/*      */           int i9;
/*      */           int i10;
/* 1239 */           switch (k) {
/*      */ 
/*      */             
/*      */             default:
/* 1243 */               d2 = m;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 2:
/* 1248 */               d2 = (m * 100 + i2);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/* 1253 */               d2 = (m * 10000 + i2 * 100 + i3);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 4:
/* 1258 */               d2 = (m * 1000000 + i2 * 10000 + i3 * 100 + i4);
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case 5:
/* 1264 */               i9 = i2 * 1000000 + i3 * 10000 + i4 * 100 + i5;
/* 1265 */               d2 = (m * 100000000L + i9);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 6:
/* 1270 */               i9 = i3 * 1000000 + i4 * 10000 + i5 * 100 + i6;
/* 1271 */               i10 = m * 100 + i2;
/* 1272 */               d2 = (i10 * 100000000L + i9);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 7:
/* 1277 */               i9 = i4 * 1000000 + i5 * 10000 + i6 * 100 + i7;
/* 1278 */               i10 = m * 10000 + i2 * 100 + i3;
/* 1279 */               d2 = (i10 * 100000000L + i9);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 8:
/* 1284 */               i9 = i5 * 1000000 + i6 * 10000 + i7 * 100 + i8;
/* 1285 */               i10 = m * 1000000 + i2 * 10000 + i3 * 100 + i4;
/* 1286 */               d2 = (i10 * 100000000L + i9);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         } 
/* 1294 */         if (i1 == 0 || d2 == 0.0D) {
/* 1295 */           d1 = d2;
/* 1296 */         } else if (i1 >= 0) {
/*      */           
/* 1298 */           if (i1 <= 22)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1305 */             d1 = d2 * small10pow[i1];
/*      */           }
/*      */           else
/*      */           {
/* 1309 */             int i9 = 15 - n;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1317 */             d2 *= small10pow[i9];
/* 1318 */             d1 = d2 * small10pow[i1 - i9];
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */           
/* 1331 */           d1 = d2 / small10pow[-i1];
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1336 */         int i23, i2 = 0;
/* 1337 */         int i3 = 0;
/* 1338 */         int i4 = 0;
/* 1339 */         int i5 = 0;
/* 1340 */         int i6 = 0;
/* 1341 */         int i7 = 0;
/* 1342 */         int i8 = 0;
/* 1343 */         int i9 = 0;
/* 1344 */         int i10 = 0;
/* 1345 */         byte b4 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1352 */         int i14 = 0;
/* 1353 */         int i15 = 0;
/* 1354 */         int i16 = 0;
/* 1355 */         int i17 = 0;
/* 1356 */         int i18 = 0;
/*      */ 
/*      */ 
/*      */         
/* 1360 */         boolean bool = false;
/* 1361 */         int i21 = 0;
/*      */         
/* 1363 */         if (bool2) {
/*      */           byte b;
/* 1365 */           if ((k & 0x1) != 0) {
/*      */             
/* 1367 */             b = 2;
/* 1368 */             i2 = m;
/*      */           }
/*      */           else {
/*      */             
/* 1372 */             b = 3;
/* 1373 */             i2 = m * 100 + arrayOfByte[j + 1] - 1;
/*      */           } 
/*      */           
/* 1376 */           for (; b < k; b += 2) {
/*      */             
/* 1378 */             int i27 = (arrayOfByte[j + b - 1] - 1) * 100 + arrayOfByte[j + b] - 1 + i2 * 10000;
/*      */ 
/*      */             
/* 1381 */             switch (b4) {
/*      */ 
/*      */               
/*      */               default:
/* 1385 */                 i2 = i27 & 0xFFFF;
/* 1386 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1387 */                 i3 = i27 & 0xFFFF;
/* 1388 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1389 */                 i4 = i27 & 0xFFFF;
/* 1390 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1391 */                 i5 = i27 & 0xFFFF;
/* 1392 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1393 */                 i6 = i27 & 0xFFFF;
/* 1394 */                 i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
/* 1395 */                 i7 = i27 & 0xFFFF;
/* 1396 */                 i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
/* 1397 */                 i8 = i27 & 0xFFFF;
/* 1398 */                 i27 = (i27 >> 16 & 0xFFFF) + i9 * 10000;
/* 1399 */                 i9 = i27 & 0xFFFF;
/* 1400 */                 i27 = (i27 >> 16 & 0xFFFF) + i10 * 10000;
/* 1401 */                 i10 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case true:
/* 1406 */                 i2 = i27 & 0xFFFF;
/* 1407 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1408 */                 i3 = i27 & 0xFFFF;
/* 1409 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1410 */                 i4 = i27 & 0xFFFF;
/* 1411 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1412 */                 i5 = i27 & 0xFFFF;
/* 1413 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1414 */                 i6 = i27 & 0xFFFF;
/* 1415 */                 i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
/* 1416 */                 i7 = i27 & 0xFFFF;
/* 1417 */                 i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
/* 1418 */                 i8 = i27 & 0xFFFF;
/* 1419 */                 i27 = (i27 >> 16 & 0xFFFF) + i9 * 10000;
/* 1420 */                 i9 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case true:
/* 1425 */                 i2 = i27 & 0xFFFF;
/* 1426 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1427 */                 i3 = i27 & 0xFFFF;
/* 1428 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1429 */                 i4 = i27 & 0xFFFF;
/* 1430 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1431 */                 i5 = i27 & 0xFFFF;
/* 1432 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1433 */                 i6 = i27 & 0xFFFF;
/* 1434 */                 i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
/* 1435 */                 i7 = i27 & 0xFFFF;
/* 1436 */                 i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
/* 1437 */                 i8 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case true:
/* 1442 */                 i2 = i27 & 0xFFFF;
/* 1443 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1444 */                 i3 = i27 & 0xFFFF;
/* 1445 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1446 */                 i4 = i27 & 0xFFFF;
/* 1447 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1448 */                 i5 = i27 & 0xFFFF;
/* 1449 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1450 */                 i6 = i27 & 0xFFFF;
/* 1451 */                 i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
/* 1452 */                 i7 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case true:
/* 1457 */                 i2 = i27 & 0xFFFF;
/* 1458 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1459 */                 i3 = i27 & 0xFFFF;
/* 1460 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1461 */                 i4 = i27 & 0xFFFF;
/* 1462 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1463 */                 i5 = i27 & 0xFFFF;
/* 1464 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1465 */                 i6 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case true:
/* 1470 */                 i2 = i27 & 0xFFFF;
/* 1471 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1472 */                 i3 = i27 & 0xFFFF;
/* 1473 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1474 */                 i4 = i27 & 0xFFFF;
/* 1475 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1476 */                 i5 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case true:
/* 1481 */                 i2 = i27 & 0xFFFF;
/* 1482 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1483 */                 i3 = i27 & 0xFFFF;
/* 1484 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1485 */                 i4 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case true:
/* 1490 */                 i2 = i27 & 0xFFFF;
/* 1491 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1492 */                 i3 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case false:
/* 1497 */                 i2 = i27 & 0xFFFF;
/*      */                 break;
/*      */             } 
/*      */ 
/*      */             
/* 1502 */             i27 = i27 >> 16 & 0xFFFF;
/*      */             
/* 1504 */             if (i27 != 0) {
/*      */               
/* 1506 */               b4++;
/*      */               
/* 1508 */               switch (b4) {
/*      */ 
/*      */                 
/*      */                 case 8:
/* 1512 */                   i10 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 7:
/* 1517 */                   i9 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 6:
/* 1522 */                   i8 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 5:
/* 1527 */                   i7 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 4:
/* 1532 */                   i6 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 3:
/* 1537 */                   i5 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 2:
/* 1542 */                   i4 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 1:
/* 1547 */                   i3 = i27;
/*      */                   break;
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           byte b;
/* 1559 */           if ((k & 0x1) != 0) {
/*      */             
/* 1561 */             b = 2;
/* 1562 */             i2 = m;
/*      */           }
/*      */           else {
/*      */             
/* 1566 */             b = 3;
/* 1567 */             i2 = m * 100 + 101 - arrayOfByte[j + 1];
/*      */           } 
/*      */           
/* 1570 */           for (; b < k; b += 2) {
/*      */             
/* 1572 */             int i27 = (101 - arrayOfByte[j + b - 1]) * 100 + 101 - arrayOfByte[j + b] + i2 * 10000;
/*      */ 
/*      */             
/* 1575 */             switch (b4) {
/*      */ 
/*      */               
/*      */               default:
/* 1579 */                 i2 = i27 & 0xFFFF;
/* 1580 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1581 */                 i3 = i27 & 0xFFFF;
/* 1582 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1583 */                 i4 = i27 & 0xFFFF;
/* 1584 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1585 */                 i5 = i27 & 0xFFFF;
/* 1586 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1587 */                 i6 = i27 & 0xFFFF;
/* 1588 */                 i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
/* 1589 */                 i7 = i27 & 0xFFFF;
/* 1590 */                 i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
/* 1591 */                 i8 = i27 & 0xFFFF;
/* 1592 */                 i27 = (i27 >> 16 & 0xFFFF) + i9 * 10000;
/* 1593 */                 i9 = i27 & 0xFFFF;
/* 1594 */                 i27 = (i27 >> 16 & 0xFFFF) + i10 * 10000;
/* 1595 */                 i10 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 7:
/* 1600 */                 i2 = i27 & 0xFFFF;
/* 1601 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1602 */                 i3 = i27 & 0xFFFF;
/* 1603 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1604 */                 i4 = i27 & 0xFFFF;
/* 1605 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1606 */                 i5 = i27 & 0xFFFF;
/* 1607 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1608 */                 i6 = i27 & 0xFFFF;
/* 1609 */                 i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
/* 1610 */                 i7 = i27 & 0xFFFF;
/* 1611 */                 i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
/* 1612 */                 i8 = i27 & 0xFFFF;
/* 1613 */                 i27 = (i27 >> 16 & 0xFFFF) + i9 * 10000;
/* 1614 */                 i9 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 6:
/* 1619 */                 i2 = i27 & 0xFFFF;
/* 1620 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1621 */                 i3 = i27 & 0xFFFF;
/* 1622 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1623 */                 i4 = i27 & 0xFFFF;
/* 1624 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1625 */                 i5 = i27 & 0xFFFF;
/* 1626 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1627 */                 i6 = i27 & 0xFFFF;
/* 1628 */                 i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
/* 1629 */                 i7 = i27 & 0xFFFF;
/* 1630 */                 i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
/* 1631 */                 i8 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 5:
/* 1636 */                 i2 = i27 & 0xFFFF;
/* 1637 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1638 */                 i3 = i27 & 0xFFFF;
/* 1639 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1640 */                 i4 = i27 & 0xFFFF;
/* 1641 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1642 */                 i5 = i27 & 0xFFFF;
/* 1643 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1644 */                 i6 = i27 & 0xFFFF;
/* 1645 */                 i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
/* 1646 */                 i7 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 4:
/* 1651 */                 i2 = i27 & 0xFFFF;
/* 1652 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1653 */                 i3 = i27 & 0xFFFF;
/* 1654 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1655 */                 i4 = i27 & 0xFFFF;
/* 1656 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1657 */                 i5 = i27 & 0xFFFF;
/* 1658 */                 i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
/* 1659 */                 i6 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 3:
/* 1664 */                 i2 = i27 & 0xFFFF;
/* 1665 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1666 */                 i3 = i27 & 0xFFFF;
/* 1667 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1668 */                 i4 = i27 & 0xFFFF;
/* 1669 */                 i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
/* 1670 */                 i5 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 2:
/* 1675 */                 i2 = i27 & 0xFFFF;
/* 1676 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1677 */                 i3 = i27 & 0xFFFF;
/* 1678 */                 i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
/* 1679 */                 i4 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 1:
/* 1684 */                 i2 = i27 & 0xFFFF;
/* 1685 */                 i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
/* 1686 */                 i3 = i27 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 0:
/* 1691 */                 i2 = i27 & 0xFFFF;
/*      */                 break;
/*      */             } 
/*      */ 
/*      */             
/* 1696 */             i27 = i27 >> 16 & 0xFFFF;
/*      */             
/* 1698 */             if (i27 != 0) {
/*      */               
/* 1700 */               b4++;
/*      */               
/* 1702 */               switch (b4) {
/*      */ 
/*      */                 
/*      */                 case 8:
/* 1706 */                   i10 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 7:
/* 1711 */                   i9 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 6:
/* 1716 */                   i8 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 5:
/* 1721 */                   i7 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 4:
/* 1726 */                   i6 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 3:
/* 1731 */                   i5 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 2:
/* 1736 */                   i4 = i27;
/*      */                   break;
/*      */ 
/*      */                 
/*      */                 case 1:
/* 1741 */                   i3 = i27;
/*      */                   break;
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             } 
/*      */           } 
/*      */         } 
/* 1785 */         byte b7 = b4;
/*      */         
/* 1787 */         b4++;
/*      */         
/* 1789 */         int i11 = 62 - b3 + k;
/*      */         
/* 1791 */         int i12 = nexpdigstable[i11];
/* 1792 */         int[] arrayOfInt = expdigstable[i11];
/* 1793 */         i21 = b4 + 5;
/*      */         
/* 1795 */         int i22 = 0;
/*      */         
/* 1797 */         if (i12 > i21) {
/*      */           
/* 1799 */           i22 = i12 - i21;
/* 1800 */           i12 = i21;
/*      */         } 
/*      */         
/* 1803 */         byte b6 = 0;
/* 1804 */         int i13 = 0;
/* 1805 */         int i19 = i12 - 1 + b4 - 1 - 4;
/*      */         byte b5;
/* 1807 */         for (b5 = 0; b5 < i19; b5++) {
/*      */           
/* 1809 */           int i27 = i13 & 0xFFFF;
/*      */           
/* 1811 */           i13 = i13 >> 16 & 0xFFFF;
/*      */           
/* 1813 */           byte b9 = (b4 < b5 + 1) ? b4 : (b5 + 1);
/*      */           
/* 1815 */           for (byte b8 = (b5 - i12 + 1 > 0) ? (b5 - i12 + 1) : 0; b8 < b9; 
/* 1816 */             b8++) {
/*      */             
/* 1818 */             int i29, i28 = i22 + b5 - b8;
/*      */ 
/*      */             
/* 1821 */             switch (b8) {
/*      */ 
/*      */               
/*      */               case 8:
/* 1825 */                 i29 = i10 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 7:
/* 1830 */                 i29 = i9 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 6:
/* 1835 */                 i29 = i8 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 5:
/* 1840 */                 i29 = i7 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 4:
/* 1845 */                 i29 = i6 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 3:
/* 1850 */                 i29 = i5 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 2:
/* 1855 */                 i29 = i4 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 1:
/* 1860 */                 i29 = i3 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1865 */                 i29 = i2 * arrayOfInt[i28];
/*      */                 break;
/*      */             } 
/*      */ 
/*      */             
/* 1870 */             i27 += i29 & 0xFFFF;
/* 1871 */             i13 += i29 >> 16 & 0xFFFF;
/*      */           } 
/*      */           
/* 1874 */           bool = (bool || (i27 & 0xFFFF) != 0) ? true : false;
/* 1875 */           i13 += i27 >> 16 & 0xFFFF;
/*      */         } 
/*      */         
/* 1878 */         i19 += 5;
/*      */         
/* 1880 */         for (; b5 < i19; b5++) {
/*      */           
/* 1882 */           int i27 = i13 & 0xFFFF;
/*      */           
/* 1884 */           i13 = i13 >> 16 & 0xFFFF;
/*      */           
/* 1886 */           byte b9 = (b4 < b5 + 1) ? b4 : (b5 + 1);
/*      */           
/* 1888 */           for (byte b8 = (b5 - i12 + 1 > 0) ? (b5 - i12 + 1) : 0; b8 < b9; 
/* 1889 */             b8++) {
/*      */             
/* 1891 */             int i29, i28 = i22 + b5 - b8;
/*      */ 
/*      */             
/* 1894 */             switch (b8) {
/*      */ 
/*      */               
/*      */               case 8:
/* 1898 */                 i29 = i10 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 7:
/* 1906 */                 i29 = i9 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 6:
/* 1914 */                 i29 = i8 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 5:
/* 1922 */                 i29 = i7 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 4:
/* 1930 */                 i29 = i6 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 3:
/* 1938 */                 i29 = i5 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 2:
/* 1946 */                 i29 = i4 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 1:
/* 1954 */                 i29 = i3 * arrayOfInt[i28];
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               default:
/* 1962 */                 i29 = i2 * arrayOfInt[i28];
/*      */                 break;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1970 */             i27 += i29 & 0xFFFF;
/* 1971 */             i13 += i29 >> 16 & 0xFFFF;
/*      */           } 
/*      */           
/* 1974 */           switch (b6++) {
/*      */ 
/*      */             
/*      */             case 4:
/* 1978 */               i18 = i27 & 0xFFFF;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 3:
/* 1983 */               i17 = i27 & 0xFFFF;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 2:
/* 1988 */               i16 = i27 & 0xFFFF;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 1:
/* 1993 */               i15 = i27 & 0xFFFF;
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1998 */               i14 = i27 & 0xFFFF;
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/* 2003 */           i13 += i27 >> 16 & 0xFFFF;
/*      */         } 
/*      */         
/* 2006 */         while (i13 != 0) {
/*      */           
/* 2008 */           if (b6 < 5) {
/* 2009 */             switch (b6++) {
/*      */ 
/*      */               
/*      */               case 4:
/* 2013 */                 i18 = i13 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 3:
/* 2018 */                 i17 = i13 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 2:
/* 2023 */                 i16 = i13 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 1:
/* 2028 */                 i15 = i13 & 0xFFFF;
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 2033 */                 i14 = i13 & 0xFFFF;
/*      */                 break;
/*      */             } 
/*      */ 
/*      */           
/*      */           } else {
/* 2039 */             bool = (bool || i14 != 0) ? true : false;
/* 2040 */             i14 = i15;
/* 2041 */             i15 = i16;
/* 2042 */             i16 = i17;
/* 2043 */             i17 = i18;
/* 2044 */             i18 = i13 & 0xFFFF;
/*      */           } 
/*      */           
/* 2047 */           i13 = i13 >> 16 & 0xFFFF;
/* 2048 */           b7++;
/*      */         } 
/*      */         
/* 2051 */         int i20 = (binexpstable[i11] + b7) * 16 - 1;
/*      */ 
/*      */ 
/*      */         
/* 2055 */         switch (b6) {
/*      */ 
/*      */           
/*      */           case 5:
/* 2059 */             i23 = i18;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 4:
/* 2064 */             i23 = i17;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 3:
/* 2069 */             i23 = i16;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 2:
/* 2074 */             i23 = i15;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 2079 */             i23 = i14;
/*      */             break;
/*      */         } 
/*      */         
/*      */         int i24;
/* 2084 */         for (i24 = i23 >> 1; i24 != 0; i24 >>= 1) {
/* 2085 */           i20++;
/*      */         }
/*      */         
/* 2088 */         i24 = 5;
/* 2089 */         int i25 = i23 << 5;
/* 2090 */         int i26 = 0;
/*      */         
/* 2092 */         i13 = 0;
/*      */         
/* 2094 */         while ((i25 & 0x100000) == 0) {
/*      */           
/* 2096 */           i25 <<= 1;
/* 2097 */           i24++;
/*      */         } 
/*      */         
/* 2100 */         switch (b6) {
/*      */ 
/*      */           
/*      */           case 5:
/* 2104 */             if (i24 > 16) {
/*      */ 
/*      */               
/* 2107 */               i25 |= i17 << i24 - 16 | i16 >> 32 - i24;
/* 2108 */               i26 = i16 << i24 | i15 << i24 - 16 | i14 >> 32 - i24;
/*      */               
/* 2110 */               i13 = i14 & 1 << 31 - i24;
/* 2111 */               bool = (bool || i14 << i24 + 1 != 0) ? true : false;
/*      */               break;
/*      */             } 
/* 2114 */             if (i24 == 16) {
/*      */ 
/*      */               
/* 2117 */               i25 |= i17;
/* 2118 */               i26 = i16 << 16 | i15;
/* 2119 */               i13 = i14 & 0x8000;
/* 2120 */               bool = (bool || (i14 & 0x7FFF) != 0) ? true : false;
/*      */ 
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/* 2126 */             i25 |= i17 >> 16 - i24;
/* 2127 */             i26 = i17 << 16 + i24 | i16 << i24 | i15 >> 16 - i24;
/*      */             
/* 2129 */             i13 = i15 & 1 << 15 - i24;
/*      */             
/* 2131 */             if (i24 < 15) {
/* 2132 */               bool = (bool || i15 << i24 + 17 != 0) ? true : false;
/*      */             }
/* 2134 */             bool = (bool || i14 != 0) ? true : false;
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 4:
/* 2141 */             if (i24 > 16) {
/*      */ 
/*      */               
/* 2144 */               i25 |= i16 << i24 - 16 | i15 >> 32 - i24;
/* 2145 */               i26 = i15 << i24 | i14 << i24 - 16;
/*      */               break;
/*      */             } 
/* 2148 */             if (i24 == 16) {
/*      */ 
/*      */               
/* 2151 */               i25 |= i16;
/*      */               
/* 2153 */               i26 = i15 << 16 | i14;
/*      */ 
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/* 2159 */             i25 |= i16 >> 16 - i24;
/* 2160 */             i26 = i16 << 16 + i24 | i15 << i24 | i14 >> 16 - i24;
/*      */             
/* 2162 */             i13 = i14 & 1 << 15 - i24;
/*      */             
/* 2164 */             if (i24 < 15) {
/* 2165 */               bool = (bool || i14 << i24 + 17 != 0) ? true : false;
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 3:
/* 2172 */             if (i24 > 16) {
/*      */ 
/*      */               
/* 2175 */               i25 |= i15 << i24 - 16 | i14 >> 32 - i24;
/* 2176 */               i26 = i14 << i24;
/*      */               break;
/*      */             } 
/* 2179 */             if (i24 == 16) {
/*      */ 
/*      */               
/* 2182 */               i25 |= i15;
/*      */               
/* 2184 */               i26 = i14 << 16;
/*      */ 
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/* 2190 */             i25 |= i15 >> 16 - i24;
/* 2191 */             i26 = i15 << 16 + i24;
/*      */             
/* 2193 */             i26 |= i14 << i24;
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 2:
/* 2200 */             if (i24 > 16) {
/*      */ 
/*      */               
/* 2203 */               i25 |= i14 << i24 - 16;
/*      */               break;
/*      */             } 
/* 2206 */             if (i24 == 16) {
/*      */ 
/*      */               
/* 2209 */               i25 |= i14;
/*      */ 
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/* 2215 */             i25 |= i14 >> 16 - i24;
/* 2216 */             i26 = i14 << 16 + i24;
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2226 */         if (i13 != 0 && (bool || (i26 & 0x1) != 0))
/*      */         {
/* 2228 */           if (i26 == -1) {
/*      */             
/* 2230 */             i26 = 0;
/* 2231 */             i25++;
/*      */             
/* 2233 */             if ((i25 & 0x200000) != 0) {
/*      */               
/* 2235 */               i26 = i26 >> 1 | i25 << 31;
/* 2236 */               i25 >>= 1;
/* 2237 */               i20++;
/*      */             } 
/*      */           } else {
/*      */             
/* 2241 */             i26++;
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2254 */         long l = i20 << 52L | (i25 & 0xFFFFF) << 32L | i26 & 0xFFFFFFFFL;
/*      */ 
/*      */         
/* 2257 */         d1 = Double.longBitsToDouble(l);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2266 */       d = bool2 ? d1 : -d1;
/*      */     } 
/*      */     
/* 2269 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double getDoubleImprecise(int paramInt) throws SQLException {
/* 2286 */     double d = 0.0D;
/*      */     
/* 2288 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 2290 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 2291 */       sQLException.fillInStackTrace();
/* 2292 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2297 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */ 
/*      */       
/* 2300 */       byte[] arrayOfByte = this.rowSpaceByte;
/* 2301 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 2302 */       byte b1 = arrayOfByte[i - 1];
/*      */       
/* 2304 */       byte b2 = arrayOfByte[i];
/*      */ 
/*      */       
/* 2307 */       double d1 = 0.0D;
/*      */       
/* 2309 */       int j = i + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2320 */       if ((b2 & Byte.MIN_VALUE) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2325 */         if (b2 == Byte.MIN_VALUE && b1 == 1) {
/* 2326 */           return 0.0D;
/*      */         }
/* 2328 */         if (b1 == 2 && b2 == -1 && arrayOfByte[i + 1] == 101)
/*      */         {
/* 2330 */           return Double.POSITIVE_INFINITY;
/*      */         }
/* 2332 */         byte b = (byte)((b2 & 0xFFFFFF7F) - 65);
/*      */         
/* 2334 */         int n = b1 - 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2342 */         int k = (int)(127.0D - b);
/*      */         
/* 2344 */         int m = n % 4;
/*      */         
/* 2346 */         switch (m) {
/*      */ 
/*      */           
/*      */           case 1:
/* 2350 */             d1 = (arrayOfByte[j] - 1) * factorTable[k];
/*      */             break;
/*      */ 
/*      */           
/*      */           case 2:
/* 2355 */             d1 = ((arrayOfByte[j] - 1) * 100 + arrayOfByte[j + 1] - 1) * factorTable[k + 1];
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 3:
/* 2361 */             d1 = ((arrayOfByte[j] - 1) * 10000 + (arrayOfByte[j + 1] - 1) * 100 + arrayOfByte[j + 2] - 1) * factorTable[k + 2];
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2371 */         for (; m < n; m += 4) {
/* 2372 */           d1 += ((arrayOfByte[j + m] - 1) * 1000000 + (arrayOfByte[j + m + 1] - 1) * 10000 + (arrayOfByte[j + m + 2] - 1) * 100 + arrayOfByte[j + m + 3] - 1) * factorTable[k + m + 3];
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2382 */         if (b2 == 0 && b1 == 1) {
/* 2383 */           return Double.NEGATIVE_INFINITY;
/*      */         }
/* 2385 */         byte b = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
/*      */         
/* 2387 */         int n = b1 - 1;
/*      */         
/* 2389 */         if (n != 20 || arrayOfByte[i + n] == 102) {
/* 2390 */           n--;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2398 */         int k = (int)(127.0D - b);
/*      */         
/* 2400 */         int m = n % 4;
/*      */         
/* 2402 */         switch (m) {
/*      */ 
/*      */           
/*      */           case 1:
/* 2406 */             d1 = (101 - arrayOfByte[j]) * factorTable[k];
/*      */             break;
/*      */ 
/*      */           
/*      */           case 2:
/* 2411 */             d1 = ((101 - arrayOfByte[j]) * 100 + 101 - arrayOfByte[j + 1]) * factorTable[k + 1];
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 3:
/* 2417 */             d1 = ((101 - arrayOfByte[j]) * 10000 + (101 - arrayOfByte[j + 1]) * 100 + 101 - arrayOfByte[j + 2]) * factorTable[k + 2];
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2427 */         for (; m < n; m += 4) {
/* 2428 */           d1 += ((101 - arrayOfByte[j + m]) * 1000000 + (101 - arrayOfByte[j + m + 1]) * 10000 + (101 - arrayOfByte[j + m + 2]) * 100 + 101 - arrayOfByte[j + m + 3]) * factorTable[k + m + 3];
/*      */         }
/*      */ 
/*      */         
/* 2432 */         d1 = -d1;
/*      */       } 
/*      */ 
/*      */       
/* 2436 */       d = d1;
/*      */     } 
/*      */     
/* 2439 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2454 */   int[] digs = new int[27]; static final int LNXSGNBT = 128; static final byte LNXDIGS = 20;
/*      */   static final byte LNXEXPBS = 64;
/*      */   static final int LNXEXPMX = 127;
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 2459 */     BigDecimal bigDecimal = null;
/*      */     
/* 2461 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 2463 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 2464 */       sQLException.fillInStackTrace();
/* 2465 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2470 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       int k, n, i1; byte b5;
/*      */       int i2;
/* 2473 */       byte[] arrayOfByte2, arrayOfByte1 = this.rowSpaceByte;
/* 2474 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 2475 */       byte b1 = arrayOfByte1[i - 1];
/*      */       int j;
/* 2477 */       for (j = 0; j < 27; j++) {
/* 2478 */         this.digs[j] = 0;
/*      */       }
/* 2480 */       j = 0;
/* 2481 */       byte b2 = 1;
/*      */       
/* 2483 */       byte b3 = 26;
/* 2484 */       int m = 0;
/*      */ 
/*      */       
/* 2487 */       byte b4 = arrayOfByte1[i];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2492 */       boolean bool = false;
/*      */       
/* 2494 */       if ((b4 & Byte.MIN_VALUE) != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2502 */         if (b4 == Byte.MIN_VALUE && b1 == 1) {
/* 2503 */           return BIGDEC_ZERO;
/*      */         }
/* 2505 */         if (b1 == 2 && b4 == -1 && arrayOfByte1[i + 1] == 101)
/*      */         {
/*      */ 
/*      */           
/* 2509 */           throwOverflow();
/*      */         }
/* 2511 */         b5 = 1;
/* 2512 */         byte b = (byte)((b4 & 0xFFFFFF7F) - 65);
/*      */ 
/*      */         
/* 2515 */         i1 = b1 - 1;
/* 2516 */         k = i1 - 1;
/* 2517 */         i2 = b - i1 + 1 << 1;
/*      */         
/* 2519 */         if (i2 > 0) {
/*      */           
/* 2521 */           i2 = 0;
/* 2522 */           k = b;
/*      */         }
/* 2524 */         else if (i2 < 0) {
/* 2525 */           bool = ((arrayOfByte1[i + i1] - 1) % 10 == 0) ? true : false;
/*      */         } 
/* 2527 */         b2 = (byte)(b2 + 1); j = arrayOfByte1[i + b2] - 1;
/*      */         
/* 2529 */         while ((k & 0x1) != 0)
/*      */         {
/* 2531 */           if (b2 > i1) {
/* 2532 */             j *= 100;
/*      */           } else {
/* 2534 */             b2 = (byte)(b2 + 1); j = j * 100 + arrayOfByte1[i + b2] - 1;
/*      */           } 
/* 2536 */           k--;
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2547 */         if (b4 == 0 && b1 == 1)
/*      */         {
/*      */           
/* 2550 */           throwOverflow();
/*      */         }
/* 2552 */         b5 = -1;
/* 2553 */         byte b = (byte)(((b4 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
/*      */ 
/*      */         
/* 2556 */         i1 = b1 - 1;
/*      */         
/* 2558 */         if (i1 != 20 || arrayOfByte1[i + i1] == 102) {
/* 2559 */           i1--;
/*      */         }
/* 2561 */         k = i1 - 1;
/*      */         
/* 2563 */         i2 = b - i1 + 1 << 1;
/*      */         
/* 2565 */         if (i2 > 0) {
/*      */           
/* 2567 */           i2 = 0;
/* 2568 */           k = b;
/*      */         }
/* 2570 */         else if (i2 < 0) {
/* 2571 */           bool = ((101 - arrayOfByte1[i + i1]) % 10 == 0) ? true : false;
/*      */         } 
/* 2573 */         b2 = (byte)(b2 + 1); j = 101 - arrayOfByte1[i + b2];
/*      */         
/* 2575 */         while ((k & 0x1) != 0) {
/*      */           
/* 2577 */           if (b2 > i1) {
/* 2578 */             j *= 100;
/*      */           } else {
/* 2580 */             b2 = (byte)(b2 + 1); j = j * 100 + 101 - arrayOfByte1[i + b2];
/*      */           } 
/* 2582 */           k--;
/*      */         } 
/*      */       } 
/*      */       
/* 2586 */       if (bool) {
/*      */         
/* 2588 */         i2++;
/* 2589 */         j /= 10;
/*      */       } 
/*      */       
/* 2592 */       int i3 = i1 - 1;
/*      */       
/* 2594 */       while (k != 0) {
/*      */         
/* 2596 */         if (b5 == 1) {
/*      */           
/* 2598 */           if (bool)
/*      */           {
/* 2600 */             m = (arrayOfByte1[i + b2 - 1] - 1) % 10 * 1000 + (arrayOfByte1[i + b2] - 1) * 10 + (arrayOfByte1[i + b2 + 1] - 1) / 10 + j * 10000;
/*      */ 
/*      */             
/* 2603 */             b2 = (byte)(b2 + 2);
/*      */           }
/* 2605 */           else if (b2 < i3)
/*      */           {
/* 2607 */             m = (arrayOfByte1[i + b2] - 1) * 100 + arrayOfByte1[i + b2 + 1] - 1 + j * 10000;
/*      */ 
/*      */             
/* 2610 */             b2 = (byte)(b2 + 2);
/*      */           }
/*      */           else
/*      */           {
/* 2614 */             m = 0;
/*      */             
/* 2616 */             if (b2 <= i1) {
/*      */               
/* 2618 */               byte b7 = 0;
/*      */               
/* 2620 */               for (; b2 <= i1; b7++) {
/* 2621 */                 b2 = (byte)(b2 + 1); m = m * 100 + arrayOfByte1[i + b2] - 1;
/*      */               } 
/* 2623 */               for (; b7 < 2; b7++) {
/* 2624 */                 m *= 100;
/*      */               }
/*      */             } 
/* 2627 */             m += j * 10000;
/*      */           }
/*      */         
/* 2630 */         } else if (bool) {
/*      */           
/* 2632 */           m = (101 - arrayOfByte1[i + b2 - 1]) % 10 * 1000 + (101 - arrayOfByte1[i + b2]) * 10 + (101 - arrayOfByte1[i + b2 + 1]) / 10 + j * 10000;
/*      */ 
/*      */           
/* 2635 */           b2 = (byte)(b2 + 2);
/*      */         }
/* 2637 */         else if (b2 < i3) {
/*      */           
/* 2639 */           m = (101 - arrayOfByte1[i + b2]) * 100 + 101 - arrayOfByte1[i + b2 + 1] + j * 10000;
/*      */ 
/*      */           
/* 2642 */           b2 = (byte)(b2 + 2);
/*      */         }
/*      */         else {
/*      */           
/* 2646 */           m = 0;
/*      */           
/* 2648 */           if (b2 <= i1) {
/*      */             
/* 2650 */             byte b7 = 0;
/*      */             
/* 2652 */             for (; b2 <= i1; b7++) {
/* 2653 */               b2 = (byte)(b2 + 1); m = m * 100 + 101 - arrayOfByte1[i + b2];
/*      */             } 
/* 2655 */             for (; b7 < 2; b7++) {
/* 2656 */               m *= 100;
/*      */             }
/*      */           } 
/* 2659 */           m += j * 10000;
/*      */         } 
/*      */         
/* 2662 */         j = m & 0xFFFF;
/*      */         
/* 2664 */         for (byte b = 25; b >= b3; b--) {
/*      */           
/* 2666 */           m = (m >> 16) + this.digs[b] * 10000;
/* 2667 */           this.digs[b] = m & 0xFFFF;
/*      */         } 
/*      */         
/* 2670 */         if (b3 > 0) {
/*      */           
/* 2672 */           m >>= 16;
/* 2673 */           if (m != 0) {
/* 2674 */             b3 = (byte)(b3 - 1); this.digs[b3] = m;
/*      */           } 
/*      */         } 
/* 2677 */         k -= 2;
/*      */       } 
/*      */       
/* 2680 */       this.digs[26] = j;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2691 */       byte b6 = (byte)(this.digs[b3] >> 8 & 0xFF);
/*      */       
/* 2693 */       if (b6 == 0) {
/*      */         
/* 2695 */         n = 53 - (b3 << 1);
/* 2696 */         arrayOfByte2 = new byte[n];
/*      */         
/* 2698 */         for (byte b = 26; b > b3; b--) {
/*      */           
/* 2700 */           int i4 = b - b3 << 1;
/*      */           
/* 2702 */           arrayOfByte2[i4 - 1] = (byte)(this.digs[b] >> 8 & 0xFF);
/* 2703 */           arrayOfByte2[i4] = (byte)(this.digs[b] & 0xFF);
/*      */         } 
/*      */         
/* 2706 */         arrayOfByte2[0] = (byte)(this.digs[b3] & 0xFF);
/*      */       }
/*      */       else {
/*      */         
/* 2710 */         n = 54 - (b3 << 1);
/* 2711 */         arrayOfByte2 = new byte[n];
/*      */         
/* 2713 */         for (byte b = 26; b > b3; b--) {
/*      */           
/* 2715 */           int i4 = b - b3 << 1;
/*      */           
/* 2717 */           arrayOfByte2[i4] = (byte)(this.digs[b] >> 8 & 0xFF);
/* 2718 */           arrayOfByte2[i4 + 1] = (byte)(this.digs[b] & 0xFF);
/*      */         } 
/*      */         
/* 2721 */         arrayOfByte2[0] = b6;
/* 2722 */         arrayOfByte2[1] = (byte)(this.digs[b3] & 0xFF);
/*      */       } 
/*      */       
/* 2725 */       if (i2 == 0 && n < 8 && n > 0) {
/* 2726 */         long l = arrayOfByte2[0] & 0xFFL;
/* 2727 */         for (byte b = 1; b < n; ) { l = l << 8L | (arrayOfByte2[b] & 0xFF); b++; }
/* 2728 */          l *= b5;
/* 2729 */         bigDecimal = new BigDecimal(l);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2734 */         BigInteger bigInteger = new BigInteger(b5, arrayOfByte2);
/*      */         
/* 2736 */         bigDecimal = new BigDecimal(bigInteger, -i2);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2741 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 2749 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 2751 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 2752 */       sQLException.fillInStackTrace();
/* 2753 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2758 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt1] == -1)
/*      */     {
/* 2760 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 2764 */     return getBigDecimal(paramInt1).setScale(paramInt2, 6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getString(int paramInt) throws SQLException {
/* 2782 */     String str = null;
/*      */     
/* 2784 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 2786 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 2787 */       sQLException.fillInStackTrace();
/* 2788 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2793 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */ 
/*      */       
/* 2796 */       byte[] arrayOfByte1 = this.rowSpaceByte;
/* 2797 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 2798 */       byte b = arrayOfByte1[i - 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3079 */       byte[] arrayOfByte2 = new byte[b];
/*      */       
/* 3081 */       System.arraycopy(arrayOfByte1, i, arrayOfByte2, 0, b);
/*      */       
/* 3083 */       NUMBER nUMBER = new NUMBER(arrayOfByte2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3092 */       String str1 = NUMBER.toString(arrayOfByte2);
/* 3093 */       int j = str1.length();
/*      */       
/* 3095 */       if (str1.startsWith("0.") || str1.startsWith("-0.")) {
/* 3096 */         j--;
/*      */       }
/* 3098 */       if (j > 38) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3108 */         str1 = nUMBER.toText(-44, null);
/*      */ 
/*      */ 
/*      */         
/* 3112 */         int k = str1.indexOf('E');
/* 3113 */         int m = str1.indexOf('+');
/*      */         
/* 3115 */         if (k == -1)
/*      */         {
/* 3117 */           k = str1.indexOf('e');
/*      */         }
/*      */         
/* 3120 */         int n = k - 1;
/*      */         
/* 3122 */         while (str1.charAt(n) == '0')
/*      */         {
/* 3124 */           n--;
/*      */         }
/*      */         
/* 3127 */         String str2 = str1.substring(0, n + 1);
/* 3128 */         String str3 = null;
/*      */         
/* 3130 */         if (m > 0) {
/*      */           
/* 3132 */           str3 = str1.substring(m + 1);
/*      */         }
/*      */         else {
/*      */           
/* 3136 */           str3 = str1.substring(k + 1);
/*      */         } 
/*      */         
/* 3139 */         return (str2 + "E" + str3).trim();
/*      */       } 
/*      */       
/* 3142 */       return nUMBER.toText(38, null).trim();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3148 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NUMBER getNUMBER(int paramInt) throws SQLException {
/* 3164 */     NUMBER nUMBER = null;
/*      */     
/* 3166 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 3168 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 3169 */       sQLException.fillInStackTrace();
/* 3170 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3175 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/* 3177 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 3178 */       byte b = this.rowSpaceByte[i - 1];
/* 3179 */       byte[] arrayOfByte = new byte[b];
/*      */       
/* 3181 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, b);
/*      */       
/* 3183 */       nUMBER = new NUMBER(arrayOfByte);
/*      */     } 
/*      */     
/* 3186 */     return nUMBER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt) throws SQLException {
/*      */     BigDecimal bigDecimal;
/* 3202 */     Double double_ = null;
/*      */     
/* 3204 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 3206 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 3207 */       sQLException.fillInStackTrace();
/* 3208 */       throw sQLException;
/*      */     } 
/*      */     
/* 3211 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*      */     {
/* 3213 */       if (this.externalType == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3243 */         if (this.statement.connection.j2ee13Compliant && this.precision != 0 && this.scale == -127) {
/*      */           
/* 3245 */           double_ = new Double(getDouble(paramInt));
/*      */         } else {
/* 3247 */           bigDecimal = getBigDecimal(paramInt);
/*      */         } 
/*      */       } else {
/*      */         
/* 3251 */         switch (this.externalType) {
/*      */ 
/*      */           
/*      */           case -7:
/* 3255 */             return Boolean.valueOf(getBoolean(paramInt));
/*      */           
/*      */           case -6:
/* 3258 */             return Byte.valueOf(getByte(paramInt));
/*      */           
/*      */           case 5:
/* 3261 */             return Short.valueOf(getShort(paramInt));
/*      */           
/*      */           case 4:
/* 3264 */             return Integer.valueOf(getInt(paramInt));
/*      */           
/*      */           case -5:
/* 3267 */             return Long.valueOf(getLong(paramInt));
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 8:
/* 3272 */             return Double.valueOf(getDouble(paramInt));
/*      */           
/*      */           case 7:
/* 3275 */             return Float.valueOf(getFloat(paramInt));
/*      */ 
/*      */           
/*      */           case 2:
/*      */           case 3:
/* 3280 */             return getBigDecimal(paramInt);
/*      */         } 
/*      */ 
/*      */         
/* 3284 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3285 */         sQLException.fillInStackTrace();
/* 3286 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3293 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 3309 */     return getObject(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Datum getOracleObject(int paramInt) throws SQLException {
/* 3325 */     return (Datum)getNUMBER(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getBytes(int paramInt) throws SQLException {
/* 3345 */     byte[] arrayOfByte = null;
/*      */     
/* 3347 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 3349 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 3350 */       sQLException.fillInStackTrace();
/* 3351 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3356 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/* 3358 */       int i = this.columnIndex + this.byteLength * paramInt + 1;
/* 3359 */       byte b = this.rowSpaceByte[i - 1];
/*      */       
/* 3361 */       arrayOfByte = new byte[b];
/*      */       
/* 3363 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, b);
/*      */     } 
/*      */     
/* 3366 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3392 */   static final BigDecimal BIGDEC_ZERO = BigDecimal.valueOf(0L);
/*      */   
/*      */   static final byte MAX_LONG_EXPONENT = 9;
/*      */   
/*      */   static final byte MIN_LONG_EXPONENT = 9;
/*      */   static final byte MAX_INT_EXPONENT = 4;
/*      */   static final byte MIN_INT_EXPONENT = 4;
/*      */   static final byte MAX_SHORT_EXPONENT = 2;
/*      */   static final byte MIN_SHORT_EXPONENT = 2;
/*      */   static final byte MAX_BYTE_EXPONENT = 1;
/*      */   static final byte MIN_BYTE_EXPONENT = 1;
/* 3403 */   static final int[] MAX_LONG = new int[] { 202, 10, 23, 34, 73, 4, 69, 55, 78, 59, 8 };
/*      */ 
/*      */ 
/*      */   
/* 3407 */   static final int[] MIN_LONG = new int[] { 53, 92, 79, 68, 29, 98, 33, 47, 24, 43, 93, 102 };
/*      */ 
/*      */ 
/*      */   
/*      */   static final int MAX_LONG_length = 11;
/*      */ 
/*      */   
/*      */   static final int MIN_LONG_length = 12;
/*      */ 
/*      */   
/* 3417 */   static final double[] factorTable = new double[] { 1.0E254D, 1.0E252D, 1.0E250D, 1.0E248D, 1.0E246D, 1.0E244D, 1.0E242D, 1.0E240D, 1.0E238D, 1.0E236D, 1.0E234D, 1.0E232D, 1.0E230D, 1.0E228D, 1.0E226D, 1.0E224D, 1.0E222D, 1.0E220D, 1.0E218D, 1.0E216D, 1.0E214D, 1.0E212D, 1.0E210D, 1.0E208D, 1.0E206D, 1.0E204D, 1.0E202D, 1.0E200D, 1.0E198D, 1.0E196D, 1.0E194D, 1.0E192D, 1.0E190D, 1.0E188D, 1.0E186D, 1.0E184D, 1.0E182D, 1.0E180D, 1.0E178D, 1.0E176D, 1.0E174D, 1.0E172D, 1.0E170D, 1.0E168D, 1.0E166D, 1.0E164D, 1.0E162D, 1.0E160D, 1.0E158D, 1.0E156D, 1.0E154D, 1.0E152D, 1.0E150D, 1.0E148D, 1.0E146D, 1.0E144D, 1.0E142D, 1.0E140D, 1.0E138D, 1.0E136D, 1.0E134D, 1.0E132D, 1.0E130D, 1.0E128D, 1.0E126D, 1.0E124D, 1.0E122D, 1.0E120D, 1.0E118D, 1.0E116D, 1.0E114D, 1.0E112D, 1.0E110D, 1.0E108D, 1.0E106D, 1.0E104D, 1.0E102D, 1.0E100D, 1.0E98D, 1.0E96D, 1.0E94D, 1.0E92D, 1.0E90D, 1.0E88D, 1.0E86D, 1.0E84D, 1.0E82D, 1.0E80D, 1.0E78D, 1.0E76D, 1.0E74D, 1.0E72D, 1.0E70D, 1.0E68D, 1.0E66D, 1.0E64D, 1.0E62D, 1.0E60D, 1.0E58D, 1.0E56D, 1.0E54D, 1.0E52D, 1.0E50D, 1.0E48D, 1.0E46D, 1.0E44D, 1.0E42D, 1.0E40D, 1.0E38D, 1.0E36D, 1.0E34D, 1.0E32D, 1.0E30D, 1.0E28D, 1.0E26D, 1.0E24D, 1.0E22D, 1.0E20D, 1.0E18D, 1.0E16D, 1.0E14D, 1.0E12D, 1.0E10D, 1.0E8D, 1000000.0D, 10000.0D, 100.0D, 1.0D, 0.01D, 1.0E-4D, 1.0E-6D, 1.0E-8D, 1.0E-10D, 1.0E-12D, 1.0E-14D, 1.0E-16D, 1.0E-18D, 1.0E-20D, 1.0E-22D, 1.0E-24D, 1.0E-26D, 1.0E-28D, 1.0E-30D, 1.0E-32D, 1.0E-34D, 1.0E-36D, 1.0E-38D, 1.0E-40D, 1.0E-42D, 1.0E-44D, 1.0E-46D, 1.0E-48D, 1.0E-50D, 1.0E-52D, 1.0E-54D, 1.0E-56D, 1.0E-58D, 1.0E-60D, 1.0E-62D, 1.0E-64D, 1.0E-66D, 1.0E-68D, 1.0E-70D, 1.0E-72D, 1.0E-74D, 1.0E-76D, 1.0E-78D, 1.0E-80D, 1.0E-82D, 1.0E-84D, 1.0E-86D, 1.0E-88D, 1.0E-90D, 1.0E-92D, 1.0E-94D, 1.0E-96D, 1.0E-98D, 1.0E-100D, 1.0E-102D, 1.0E-104D, 1.0E-106D, 1.0E-108D, 1.0E-110D, 1.0E-112D, 1.0E-114D, 1.0E-116D, 1.0E-118D, 1.0E-120D, 1.0E-122D, 1.0E-124D, 1.0E-126D, 1.0E-128D, 1.0E-130D, 1.0E-132D, 1.0E-134D, 1.0E-136D, 1.0E-138D, 1.0E-140D, 1.0E-142D, 1.0E-144D, 1.0E-146D, 1.0E-148D, 1.0E-150D, 1.0E-152D, 1.0E-154D, 1.0E-156D, 1.0E-158D, 1.0E-160D, 1.0E-162D, 1.0E-164D, 1.0E-166D, 1.0E-168D, 1.0E-170D, 1.0E-172D, 1.0E-174D, 1.0E-176D, 1.0E-178D, 1.0E-180D, 1.0E-182D, 1.0E-184D, 1.0E-186D, 1.0E-188D, 1.0E-190D, 1.0E-192D, 1.0E-194D, 1.0E-196D, 1.0E-198D, 1.0E-200D, 1.0E-202D, 1.0E-204D, 1.0E-206D, 1.0E-208D, 1.0E-210D, 1.0E-212D, 1.0E-214D, 1.0E-216D, 1.0E-218D, 1.0E-220D, 1.0E-222D, 1.0E-224D, 1.0E-226D, 1.0E-228D, 1.0E-230D, 1.0E-232D, 1.0E-234D, 1.0E-236D, 1.0E-238D, 1.0E-240D, 1.0E-242D, 1.0E-244D, 1.0E-246D, 1.0E-248D, 1.0E-250D, 1.0E-252D, 1.0E-254D };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3454 */   static final double[] small10pow = new double[] { 1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D, 100000.0D, 1000000.0D, 1.0E7D, 1.0E8D, 1.0E9D, 1.0E10D, 1.0E11D, 1.0E12D, 1.0E13D, 1.0E14D, 1.0E15D, 1.0E16D, 1.0E17D, 1.0E18D, 1.0E19D, 1.0E20D, 1.0E21D, 1.0E22D };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3461 */   static final int tablemax = factorTable.length;
/*      */   static final double tablemaxexponent = 127.0D;
/* 3463 */   static final double tableminexponent = 127.0D - (tablemax - 20);
/*      */ 
/*      */   
/*      */   static final int MANTISSA_SIZE = 53;
/*      */   
/* 3468 */   static final int[] expdigs0 = new int[] { 25597, 55634, 18440, 18324, 42485, 50370, 56862, 11593, 45703, 57341, 10255, 12549, 59579, 5 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3474 */   static final int[] expdigs1 = new int[] { 50890, 19916, 24149, 23777, 11324, 41057, 14921, 56274, 30917, 19462, 54968, 47943, 38791, 3872 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3480 */   static final int[] expdigs2 = new int[] { 24101, 29690, 40218, 29073, 29604, 22037, 27674, 9082, 56670, 55244, 20865, 54874, 47573, 38 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3486 */   static final int[] expdigs3 = new int[] { 22191, 40873, 1607, 45622, 23883, 24544, 32988, 43530, 61694, 55616, 43150, 32976, 27418, 25379 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3492 */   static final int[] expdigs4 = new int[] { 55927, 44317, 6569, 54851, 238, 63160, 51447, 12231, 55667, 25459, 5674, 40962, 52047, 253 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3498 */   static final int[] expdigs5 = new int[] { 56264, 8962, 51839, 64773, 39323, 49783, 15587, 30924, 36601, 56615, 27581, 36454, 35254, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3504 */   static final int[] expdigs6 = new int[] { 21545, 25466, 59727, 37873, 13099, 7602, 15571, 49963, 37664, 46896, 14328, 59258, 17403, 1663 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3510 */   static final int[] expdigs7 = new int[] { 12011, 4842, 3874, 57395, 38141, 46606, 49307, 60792, 31833, 21440, 9318, 47123, 41461, 16 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3516 */   static final int[] expdigs8 = new int[] { 52383, 25023, 56409, 43947, 51036, 17420, 62725, 5735, 53692, 44882, 64439, 36137, 24719, 10900 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3522 */   static final int[] expdigs9 = new int[] { 65404, 27119, 57580, 26653, 42453, 19179, 26186, 42000, 1847, 62708, 14406, 12813, 247, 109 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3528 */   static final int[] expdigs10 = new int[] { 36698, 50078, 40552, 35000, 49576, 56552, 261, 49572, 31475, 59609, 45363, 46658, 5900, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3534 */   static final int[] expdigs11 = new int[] { 33321, 54106, 42443, 60698, 47535, 24088, 45785, 18352, 47026, 40291, 5183, 35843, 24059, 714 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3540 */   static final int[] expdigs12 = new int[] { 12129, 44450, 22706, 34030, 37175, 8760, 31915, 56544, 23407, 52176, 7260, 41646, 9415, 7 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3546 */   static final int[] expdigs13 = new int[] { 43054, 17160, 43698, 6780, 36385, 52800, 62346, 52747, 33988, 2855, 31979, 38083, 44325, 4681 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3552 */   static final int[] expdigs14 = new int[] { 60723, 40803, 16165, 19073, 2985, 9703, 41911, 37227, 41627, 1994, 38986, 27250, 53527, 46 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3558 */   static final int[] expdigs15 = new int[] { 36481, 57623, 45627, 58488, 53274, 7238, 2063, 31221, 62631, 25319, 35409, 25293, 54667, 30681 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3564 */   static final int[] expdigs16 = new int[] { 52138, 47106, 3077, 4517, 41165, 38738, 39997, 10142, 13078, 16637, 53438, 54647, 53630, 306 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3570 */   static final int[] expdigs17 = new int[] { 25425, 24719, 55736, 8564, 12208, 3664, 51518, 17140, 61079, 30312, 2500, 30693, 4468, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3576 */   static final int[] expdigs18 = new int[] { 58368, 65134, 52675, 3178, 26300, 7986, 11833, 515, 23109, 63525, 29138, 19030, 50114, 2010 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3582 */   static final int[] expdigs19 = new int[] { 41216, 15724, 12323, 26246, 59245, 58406, 46648, 13767, 11372, 15053, 61895, 48686, 7054, 20 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3588 */   static final int[] expdigs20 = new int[] { 0, 29248, 62416, 1433, 14025, 43846, 39905, 44375, 137, 47955, 62409, 33386, 48983, 13177 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3594 */   static final int[] expdigs21 = new int[] { 0, 21264, 53708, 60962, 25043, 64008, 31200, 50906, 9831, 56185, 43877, 36378, 50952, 131 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3600 */   static final int[] expdigs22 = new int[] { 0, 50020, 25440, 60247, 44814, 39961, 6865, 26068, 34832, 9081, 17478, 44928, 20825, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3606 */   static final int[] expdigs23 = new int[] { 0, 0, 52929, 10084, 25506, 6346, 61348, 31525, 52689, 61296, 27615, 15903, 40426, 863 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3612 */   static final int[] expdigs24 = new int[] { 0, 16384, 24122, 53840, 43508, 13170, 51076, 37670, 58198, 31414, 57292, 61762, 41691, 8 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3618 */   static final int[] expdigs25 = new int[] { 0, 0, 4096, 29077, 42481, 30581, 10617, 59493, 46251, 1892, 5557, 4505, 52391, 5659 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3624 */   static final int[] expdigs26 = new int[] { 0, 0, 58368, 11431, 1080, 29797, 47947, 36639, 42405, 50481, 29546, 9875, 39190, 56 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3630 */   static final int[] expdigs27 = new int[] { 0, 0, 0, 57600, 63028, 53094, 12749, 18174, 21993, 48265, 14922, 59933, 4030, 37092 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3636 */   static final int[] expdigs28 = new int[] { 0, 0, 0, 576, 1941, 35265, 9302, 42780, 50682, 28007, 29640, 28124, 60333, 370 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3642 */   static final int[] expdigs29 = new int[] { 0, 0, 0, 5904, 8539, 12149, 36793, 43681, 12958, 60573, 21267, 35015, 46478, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3648 */   static final int[] expdigs30 = new int[] { 0, 0, 0, 0, 7268, 50548, 47962, 3644, 22719, 26999, 41893, 7421, 56711, 2430 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3653 */   static final int[] expdigs31 = new int[] { 0, 0, 0, 0, 7937, 49002, 60772, 28216, 38893, 55975, 63988, 59711, 20227, 24 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3658 */   static final int[] expdigs32 = new int[] { 0, 0, 0, 16384, 38090, 63404, 55657, 8801, 62648, 13666, 57656, 60234, 15930 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3663 */   static final int[] expdigs33 = new int[] { 0, 0, 0, 4096, 37081, 37989, 16940, 55138, 17665, 39458, 9751, 20263, 159 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3668 */   static final int[] expdigs34 = new int[] { 0, 0, 0, 58368, 35104, 16108, 61773, 14313, 30323, 54789, 57113, 38868, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3673 */   static final int[] expdigs35 = new int[] { 0, 0, 0, 8448, 18701, 29652, 51080, 65023, 27172, 37903, 3192, 1044 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3678 */   static final int[] expdigs36 = new int[] { 0, 0, 0, 37440, 63101, 2917, 39177, 50457, 25830, 50186, 28867, 10 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3683 */   static final int[] expdigs37 = new int[] { 0, 0, 0, 56080, 45850, 37384, 3668, 12301, 38269, 18196, 6842 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3688 */   static final int[] expdigs38 = new int[] { 0, 0, 0, 46436, 13565, 50181, 34770, 37478, 5625, 27707, 68 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3693 */   static final int[] expdigs39 = new int[] { 0, 0, 0, 32577, 45355, 38512, 38358, 3651, 36101, 44841 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3698 */   static final int[] expdigs40 = new int[] { 0, 0, 16384, 28506, 5696, 56746, 15456, 50499, 27230, 448 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3703 */   static final int[] expdigs41 = new int[] { 0, 0, 4096, 285, 9232, 58239, 57170, 38515, 31729, 4 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3708 */   static final int[] expdigs42 = new int[] { 0, 0, 58368, 41945, 57108, 12378, 28752, 48226, 2938 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3713 */   static final int[] expdigs43 = new int[] { 0, 0, 24832, 47605, 49067, 23716, 61891, 25385, 29 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3718 */   static final int[] expdigs44 = new int[] { 0, 0, 8768, 2442, 50298, 23174, 19624, 19259 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3723 */   static final int[] expdigs45 = new int[] { 0, 0, 40720, 45899, 1813, 31689, 38862, 192 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3728 */   static final int[] expdigs46 = new int[] { 0, 0, 36452, 14221, 34752, 48813, 60681, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3733 */   static final int[] expdigs47 = new int[] { 0, 0, 61313, 34220, 16731, 11629, 1262 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3738 */   static final int[] expdigs48 = new int[] { 0, 16384, 60906, 18036, 40144, 40748, 12 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3743 */   static final int[] expdigs49 = new int[] { 0, 4096, 609, 15909, 52830, 8271 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3748 */   static final int[] expdigs50 = new int[] { 0, 58368, 3282, 56520, 47058, 82 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3753 */   static final int[] expdigs51 = new int[] { 0, 41216, 52461, 7118, 54210 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3758 */   static final int[] expdigs52 = new int[] { 0, 45632, 51642, 6624, 542 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3763 */   static final int[] expdigs53 = new int[] { 0, 25360, 24109, 27591, 5 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3768 */   static final int[] expdigs54 = new int[] { 0, 42852, 46771, 3552 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3773 */   static final int[] expdigs55 = new int[] { 0, 28609, 34546, 35 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3778 */   static final int[] expdigs56 = new int[] { 16384, 4218, 23283 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3783 */   static final int[] expdigs57 = new int[] { 4096, 54437, 232 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3788 */   static final int[] expdigs58 = new int[] { 58368, 21515, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3793 */   static final int[] expdigs59 = new int[] { 57600, 1525 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3798 */   static final int[] expdigs60 = new int[] { 16960, 15 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3803 */   static final int[] expdigs61 = new int[] { 10000 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3808 */   static final int[] expdigs62 = new int[] { 100 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3813 */   static final int[] expdigs63 = new int[] { 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3818 */   static final int[] expdigs64 = new int[] { 36700, 62914, 23592, 49807, 10485, 36700, 62914, 23592, 49807, 10485, 36700, 62914, 23592, 655 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3824 */   static final int[] expdigs65 = new int[] { 14784, 18979, 33659, 19503, 2726, 9542, 629, 2202, 40475, 10590, 4299, 47815, 36280, 6 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3830 */   static final int[] expdigs66 = new int[] { 16332, 9978, 33613, 31138, 35584, 64252, 13857, 14424, 62281, 46279, 36150, 46573, 63392, 4294 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3836 */   static final int[] expdigs67 = new int[] { 6716, 24348, 22618, 23904, 21327, 3919, 44703, 19149, 28803, 48959, 6259, 50273, 62237, 42 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3842 */   static final int[] expdigs68 = new int[] { 8471, 23660, 38254, 26440, 33662, 38879, 9869, 11588, 41479, 23225, 60127, 24310, 32615, 28147 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3848 */   static final int[] expdigs69 = new int[] { 13191, 6790, 63297, 30410, 12788, 42987, 23691, 28296, 32527, 38898, 41233, 4830, 31128, 281 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3854 */   static final int[] expdigs70 = new int[] { 4064, 53152, 62236, 29139, 46658, 12881, 31694, 4870, 19986, 24637, 9587, 28884, 53395, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3860 */   static final int[] expdigs71 = new int[] { 26266, 10526, 16260, 55017, 35680, 40443, 19789, 17356, 30195, 55905, 28426, 63010, 44197, 1844 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3866 */   static final int[] expdigs72 = new int[] { 38273, 7969, 37518, 26764, 23294, 63974, 18547, 17868, 24550, 41191, 17323, 53714, 29277, 18 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3872 */   static final int[] expdigs73 = new int[] { 16739, 37738, 38090, 26589, 43521, 1543, 15713, 10671, 11975, 41533, 18106, 9348, 16921, 12089 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3878 */   static final int[] expdigs74 = new int[] { 14585, 61981, 58707, 16649, 25994, 39992, 28337, 17801, 37475, 22697, 31638, 16477, 58496, 120 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3884 */   static final int[] expdigs75 = new int[] { 58472, 2585, 40564, 27691, 44824, 27269, 58610, 54572, 35108, 30373, 35050, 10650, 13692, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3890 */   static final int[] expdigs76 = new int[] { 50392, 58911, 41968, 49557, 29112, 29939, 43526, 63500, 55595, 27220, 25207, 38361, 18456, 792 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3896 */   static final int[] expdigs77 = new int[] { 26062, 32046, 3696, 45060, 46821, 40931, 50242, 60272, 24148, 20588, 6150, 44948, 60477, 7 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3902 */   static final int[] expdigs78 = new int[] { 12430, 30407, 320, 41980, 58777, 41755, 41041, 13609, 45167, 13348, 40838, 60354, 19454, 5192 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3908 */   static final int[] expdigs79 = new int[] { 30926, 26518, 13110, 43018, 54982, 48258, 24658, 15209, 63366, 11929, 20069, 43857, 60487, 51 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3914 */   static final int[] expdigs80 = new int[] { 51263, 54048, 48761, 48627, 30576, 49046, 4414, 61195, 61755, 48474, 19124, 55906, 15511, 34028 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3920 */   static final int[] expdigs81 = new int[] { 39834, 11681, 47018, 3107, 64531, 54229, 41331, 41899, 51735, 42427, 59173, 13010, 18505, 340 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3926 */   static final int[] expdigs82 = new int[] { 27268, 6670, 31272, 9861, 45865, 10372, 12865, 62678, 23454, 35158, 20252, 29621, 26399, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3932 */   static final int[] expdigs83 = new int[] { 57738, 46147, 66, 48154, 11239, 21430, 55809, 46003, 15044, 25138, 52780, 48043, 4883, 2230 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3938 */   static final int[] expdigs84 = new int[] { 20893, 62065, 64225, 52254, 59094, 55919, 60195, 5702, 48647, 50058, 7736, 41768, 19709, 22 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3944 */   static final int[] expdigs85 = new int[] { 37714, 32321, 45840, 36031, 33290, 47121, 5146, 28127, 9887, 25390, 52929, 2698, 1073, 14615 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3950 */   static final int[] expdigs86 = new int[] { 35111, 8187, 18153, 56721, 40309, 59453, 51824, 4868, 45974, 3530, 43783, 8546, 9841, 146 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3956 */   static final int[] expdigs87 = new int[] { 23288, 61030, 42779, 19572, 29894, 47780, 45082, 32816, 43713, 33458, 25341, 63655, 30244, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3962 */   static final int[] expdigs88 = new int[] { 58138, 33000, 62869, 37127, 61799, 298, 46353, 5693, 63898, 62040, 989, 23191, 53065, 957 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3968 */   static final int[] expdigs89 = new int[] { 42524, 32442, 36673, 15444, 22900, 658, 61412, 32824, 21610, 64190, 1975, 11373, 37886, 9 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3974 */   static final int[] expdigs90 = new int[] { 26492, 4357, 32437, 10852, 34233, 53968, 55056, 34692, 64553, 38226, 41929, 21646, 6667, 6277 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3980 */   static final int[] expdigs91 = new int[] { 61213, 698, 16053, 50571, 2963, 50347, 13657, 48188, 46520, 19387, 33187, 25775, 50529, 62 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3986 */   static final int[] expdigs92 = new int[] { 42864, 54351, 45226, 20476, 23443, 17724, 3780, 44701, 52910, 23402, 28374, 46862, 40234, 41137 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3992 */   static final int[] expdigs93 = new int[] { 23366, 62147, 58123, 44113, 55284, 39498, 3314, 9622, 9704, 27759, 25187, 43722, 24650, 411 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3998 */   static final int[] expdigs94 = new int[] { 38899, 44530, 19586, 37141, 1863, 9570, 32801, 31553, 51870, 62536, 51369, 30583, 7455, 4 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4004 */   static final int[] expdigs95 = new int[] { 10421, 4321, 43699, 3472, 65252, 17057, 13858, 29819, 14733, 21490, 40602, 31315, 65186, 2695 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4010 */   static final int[] expdigs96 = new int[] { 6002, 54438, 29272, 34113, 17036, 25074, 36183, 953, 25051, 12011, 20722, 4245, 62911, 26 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4016 */   static final int[] expdigs97 = new int[] { 14718, 45935, 8408, 42891, 21312, 56531, 44159, 45581, 20325, 36295, 35509, 24455, 30844, 17668 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4022 */   static final int[] expdigs98 = new int[] { 54542, 45023, 23021, 3050, 31015, 20881, 50904, 40432, 33626, 14125, 44264, 60537, 44872, 176 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4028 */   static final int[] expdigs99 = new int[] { 60183, 8969, 14648, 17725, 11451, 50016, 34587, 46279, 19341, 42084, 16826, 5848, 50256, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4034 */   static final int[] expdigs100 = new int[] { 64999, 53685, 60382, 19151, 25736, 5357, 31302, 23283, 14225, 52622, 56781, 39489, 60351, 1157 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4040 */   static final int[] expdigs101 = new int[] { 1305, 4469, 39270, 18541, 63827, 59035, 54707, 16616, 32910, 48367, 64137, 2360, 37959, 11 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4046 */   static final int[] expdigs102 = new int[] { 45449, 32125, 19705, 56098, 51958, 5225, 18285, 13654, 9341, 25888, 50946, 26855, 36068, 7588 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4052 */   static final int[] expdigs103 = new int[] { 27324, 53405, 43450, 25464, 3796, 3329, 46058, 53220, 26307, 53998, 33932, 23861, 58032, 75 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4058 */   static final int[] expdigs104 = new int[] { 63080, 50735, 1844, 21406, 57926, 63607, 24936, 52889, 23469, 64488, 539, 8859, 21210, 49732 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4064 */   static final int[] expdigs105 = new int[] { 62890, 39828, 3950, 32982, 39245, 21607, 40226, 50991, 18584, 10475, 59643, 40720, 21183, 497 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4070 */   static final int[] expdigs106 = new int[] { 37329, 64623, 11835, 985, 46923, 48712, 28582, 21481, 28366, 41392, 13703, 49559, 63781, 4 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4076 */   static final int[] expdigs107 = new int[] { 3316, 60011, 41933, 47959, 54404, 39790, 12283, 941, 46090, 42226, 18108, 38803, 16879, 3259 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4082 */   static final int[] expdigs108 = new int[] { 46563, 56305, 5006, 45044, 49040, 12849, 778, 6563, 46336, 3043, 7390, 2354, 38835, 32 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4088 */   static final int[] expdigs109 = new int[] { 28653, 3742, 33331, 2671, 39772, 29981, 56489, 1973, 26280, 26022, 56391, 56434, 57039, 21359 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4094 */   static final int[] expdigs110 = new int[] { 9461, 17732, 7542, 26241, 8917, 24548, 61513, 13126, 59245, 41547, 1874, 41852, 39236, 213 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4100 */   static final int[] expdigs111 = new int[] { 36794, 22459, 63645, 14024, 42032, 53329, 25518, 11272, 18287, 20076, 62933, 3039, 8912, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4106 */   static final int[] expdigs112 = new int[] { 14926, 15441, 32337, 42579, 26354, 35154, 22815, 36955, 12564, 8047, 856, 41917, 55080, 1399 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4112 */   static final int[] expdigs113 = new int[] { 8668, 50617, 10153, 17465, 1574, 28532, 15301, 58041, 38791, 60373, 663, 29255, 65431, 13 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4118 */   static final int[] expdigs114 = new int[] { 21589, 32199, 24754, 45321, 9349, 26230, 35019, 37508, 20896, 42986, 31405, 12458, 65173, 9173 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4124 */   static final int[] expdigs115 = new int[] { 46746, 1632, 61196, 50915, 64318, 41549, 2971, 23968, 59191, 58756, 61917, 779, 48493, 91 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4130 */   static final int[] expdigs116 = new int[] { 1609, 63382, 15744, 15685, 51627, 56348, 33838, 52458, 44148, 11077, 56293, 41906, 45227, 60122 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4136 */   static final int[] expdigs117 = new int[] { 19676, 45198, 6055, 38823, 8380, 49060, 17377, 58196, 43039, 21737, 59545, 12870, 14870, 601 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4142 */   static final int[] expdigs118 = new int[] { 4128, 2418, 28241, 13495, 26298, 3767, 31631, 5169, 8950, 27087, 56956, 4060, 804, 6 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4148 */   static final int[] expdigs119 = new int[] { 39930, 40673, 19029, 54677, 38145, 23200, 41325, 24564, 24955, 54484, 23863, 52998, 13147, 3940 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4154 */   static final int[] expdigs120 = new int[] { 3676, 24655, 34924, 27416, 23974, 887, 10899, 4833, 21221, 28725, 19899, 57546, 26345, 39 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4160 */   static final int[] expdigs121 = new int[] { 28904, 41324, 18596, 42292, 12070, 52013, 30810, 61057, 55753, 32324, 38953, 6752, 32688, 25822 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4166 */   static final int[] expdigs122 = new int[] { 42232, 26627, 2807, 27948, 50583, 49016, 32420, 64180, 3178, 3600, 21361, 52496, 14744, 258 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4172 */   static final int[] expdigs123 = new int[] { 2388, 59904, 28863, 7488, 31963, 8354, 47510, 15059, 2653, 58363, 31670, 21496, 38158, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4178 */   static final int[] expdigs124 = new int[] { 50070, 5266, 26158, 10774, 15148, 6873, 30230, 33898, 63720, 51799, 4515, 50124, 19875, 1692 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4184 */   static final int[] expdigs125 = new int[] { 54240, 3984, 12058, 2729, 13914, 11865, 38313, 39660, 10467, 20834, 36745, 57517, 60491, 16 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4190 */   static final int[] expdigs126 = new int[] { 5387, 58214, 9214, 13883, 14445, 34873, 21745, 13490, 23334, 25008, 58535, 19372, 44484, 11090 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4196 */   static final int[] expdigs127 = new int[] { 27578, 64807, 12543, 794, 13907, 61297, 12013, 64360, 15961, 20566, 24178, 15922, 59427, 110 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4202 */   static final int[] expdigs128 = new int[] { 49427, 41935, 46000, 59645, 45358, 51075, 15848, 32756, 38170, 14623, 35631, 57175, 7147, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4208 */   static final int[] expdigs129 = new int[] { 33941, 39160, 55469, 45679, 22878, 60091, 37210, 18508, 1638, 57398, 65026, 41643, 54966, 726 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4214 */   static final int[] expdigs130 = new int[] { 60632, 24639, 41842, 62060, 20544, 59583, 52800, 1495, 48513, 43827, 10480, 1727, 17589, 7 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4220 */   static final int[] expdigs131 = new int[] { 5590, 60244, 53985, 26632, 53049, 33628, 58267, 54922, 21641, 62744, 58109, 2070, 26887, 4763 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4226 */   static final int[] expdigs132 = new int[] { 62970, 37957, 34618, 29757, 24123, 2302, 17622, 58876, 44780, 6525, 33349, 36065, 41556, 47 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4232 */   static final int[] expdigs133 = new int[] { 1615, 24878, 20040, 11487, 23235, 27766, 59005, 57847, 60881, 11588, 63635, 61281, 31817, 31217 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4238 */   static final int[] expdigs134 = new int[] { 14434, 2870, 65081, 44023, 40864, 40254, 47120, 6476, 32066, 23053, 17020, 19618, 11459, 312 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4244 */   static final int[] expdigs135 = new int[] { 43398, 40005, 36695, 8304, 12205, 16131, 42414, 38075, 63890, 2851, 61774, 59833, 7978, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4250 */   static final int[] expdigs136 = new int[] { 56426, 22060, 15473, 31824, 19088, 38788, 64386, 12875, 35770, 65519, 11824, 19623, 56959, 2045 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4256 */   static final int[] expdigs137 = new int[] { 16292, 32333, 10640, 47504, 29026, 30534, 23581, 6682, 10188, 24248, 44027, 51969, 30060, 20 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4262 */   static final int[] expdigs138 = new int[] { 29432, 37518, 55373, 2727, 33243, 22572, 16689, 35625, 34145, 15830, 59880, 32552, 52948, 13407 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4268 */   static final int[] expdigs139 = new int[] { 61898, 27244, 41841, 33450, 18682, 13988, 24415, 11497, 1652, 34237, 34677, 325, 5117, 134 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4274 */   static final int[] expdigs140 = new int[] { 16347, 3549, 48915, 22616, 21158, 51913, 32356, 21086, 3293, 8862, 1002, 26873, 22333, 1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4280 */   static final int[] expdigs141 = new int[] { 25966, 63733, 28215, 31946, 40858, 58538, 11004, 6877, 6109, 3965, 35478, 37365, 45488, 878 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4286 */   static final int[] expdigs142 = new int[] { 45479, 34060, 17321, 19980, 1719, 16314, 29601, 8588, 58388, 22321, 14117, 63288, 51572, 8 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4292 */   static final int[] expdigs143 = new int[] { 46861, 47640, 11481, 23766, 46730, 53756, 8682, 60589, 42028, 27453, 29714, 31598, 39954, 5758 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4298 */   static final int[] expdigs144 = new int[] { 29304, 58803, 51232, 27762, 60760, 17576, 19092, 26820, 11561, 48771, 6850, 27841, 38410, 57 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4304 */   static final int[] expdigs145 = new int[] { 2916, 49445, 34666, 46387, 18627, 58279, 60468, 190, 3545, 51889, 51605, 47909, 40910, 37739 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4310 */   static final int[] expdigs146 = new int[] { 19034, 62098, 15419, 33887, 38852, 53011, 28129, 37357, 11176, 48360, 9035, 9654, 25968, 377 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4316 */   static final int[] expdigs147 = new int[] { 25094, 10451, 7363, 55389, 57404, 27399, 11422, 39695, 28947, 12935, 61694, 26310, 50722, 3 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4322 */   static final int[][] expdigstable = new int[][] { expdigs0, expdigs1, expdigs2, expdigs3, expdigs4, expdigs5, expdigs6, expdigs7, expdigs8, expdigs9, expdigs10, expdigs11, expdigs12, expdigs13, expdigs14, expdigs15, expdigs16, expdigs17, expdigs18, expdigs19, expdigs20, expdigs21, expdigs22, expdigs23, expdigs24, expdigs25, expdigs26, expdigs27, expdigs28, expdigs29, expdigs30, expdigs31, expdigs32, expdigs33, expdigs34, expdigs35, expdigs36, expdigs37, expdigs38, expdigs39, expdigs40, expdigs41, expdigs42, expdigs43, expdigs44, expdigs45, expdigs46, expdigs47, expdigs48, expdigs49, expdigs50, expdigs51, expdigs52, expdigs53, expdigs54, expdigs55, expdigs56, expdigs57, expdigs58, expdigs59, expdigs60, expdigs61, expdigs62, expdigs63, expdigs64, expdigs65, expdigs66, expdigs67, expdigs68, expdigs69, expdigs70, expdigs71, expdigs72, expdigs73, expdigs74, expdigs75, expdigs76, expdigs77, expdigs78, expdigs79, expdigs80, expdigs81, expdigs82, expdigs83, expdigs84, expdigs85, expdigs86, expdigs87, expdigs88, expdigs89, expdigs90, expdigs91, expdigs92, expdigs93, expdigs94, expdigs95, expdigs96, expdigs97, expdigs98, expdigs99, expdigs100, expdigs101, expdigs102, expdigs103, expdigs104, expdigs105, expdigs106, expdigs107, expdigs108, expdigs109, expdigs110, expdigs111, expdigs112, expdigs113, expdigs114, expdigs115, expdigs116, expdigs117, expdigs118, expdigs119, expdigs120, expdigs121, expdigs122, expdigs123, expdigs124, expdigs125, expdigs126, expdigs127, expdigs128, expdigs129, expdigs130, expdigs131, expdigs132, expdigs133, expdigs134, expdigs135, expdigs136, expdigs137, expdigs138, expdigs139, expdigs140, expdigs141, expdigs142, expdigs143, expdigs144, expdigs145, expdigs146, expdigs147 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4351 */   static final int[] nexpdigstable = new int[] { 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 13, 12, 12, 11, 11, 10, 10, 10, 9, 9, 8, 8, 8, 7, 7, 6, 6, 5, 5, 5, 4, 4, 3, 3, 3, 2, 2, 1, 1, 1, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4363 */   static final int[] binexpstable = new int[] { 90, 89, 89, 88, 88, 88, 87, 87, 86, 86, 86, 85, 85, 84, 84, 83, 83, 83, 82, 82, 81, 81, 81, 80, 80, 79, 79, 78, 78, 78, 77, 77, 76, 76, 76, 75, 75, 74, 74, 73, 73, 73, 72, 72, 71, 71, 71, 70, 70, 69, 69, 68, 68, 68, 67, 67, 66, 66, 66, 65, 65, 64, 64, 64, 63, 63, 62, 62, 61, 61, 61, 60, 60, 59, 59, 59, 58, 58, 57, 57, 56, 56, 56, 55, 55, 54, 54, 54, 53, 53, 52, 52, 51, 51, 51, 50, 50, 49, 49, 49, 48, 48, 47, 47, 46, 46, 46, 45, 45, 44, 44, 44, 43, 43, 42, 42, 41, 41, 41, 40, 40, 39, 39, 39, 38, 38, 37, 37, 37, 36, 36, 35, 35, 34, 34, 34, 33, 33, 32, 32, 32, 31, 31, 30, 30, 29, 29, 29 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void throwOverflow() throws SQLException {
/* 4380 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26);
/* 4381 */     sQLException.fillInStackTrace();
/* 4382 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long updateChecksum(long paramLong, int paramInt) throws SQLException {
/* 4390 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*      */       
/* 4392 */       paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 4398 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 4399 */       int i = this.columnIndex + this.byteLength * paramInt;
/*      */       
/* 4401 */       paramLong = CRC64.updateChecksum(paramLong, this.rowSpaceByte, i + 1, s);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4407 */     return paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 4412 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NumberCommonAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */