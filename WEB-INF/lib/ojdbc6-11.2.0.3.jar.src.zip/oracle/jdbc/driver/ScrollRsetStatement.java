package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

interface ScrollRsetStatement {
  Connection getConnection() throws SQLException;
  
  void notifyCloseRset() throws SQLException;
  
  int copyBinds(Statement paramStatement, int paramInt) throws SQLException;
  
  String getOriginalSql() throws SQLException;
  
  OracleResultSetCache getResultSetCache() throws SQLException;
  
  int getMaxFieldSize() throws SQLException;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\ScrollRsetStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */