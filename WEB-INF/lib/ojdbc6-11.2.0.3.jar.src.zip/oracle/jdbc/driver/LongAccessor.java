/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LongAccessor
/*     */   extends CharCommonAccessor
/*     */ {
/*     */   OracleInputStream stream;
/*  28 */   int columnPosition = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LongAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3) throws SQLException {
/*  34 */     init(paramOracleStatement, 8, 8, paramShort, false);
/*     */     
/*  36 */     this.columnPosition = paramInt1;
/*     */     
/*  38 */     initForDataAccess(paramInt3, paramInt2, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LongAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
/*  47 */     init(paramOracleStatement, 8, 8, paramShort, false);
/*     */     
/*  49 */     this.columnPosition = paramInt1;
/*     */     
/*  51 */     initForDescribe(8, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, null);
/*     */ 
/*     */     
/*  54 */     int i = paramOracleStatement.maxFieldSize;
/*     */     
/*  56 */     if (i > 0 && (paramInt2 == 0 || i < paramInt2)) {
/*  57 */       paramInt2 = i;
/*     */     }
/*  59 */     initForDataAccess(0, paramInt2, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  67 */     if (paramInt1 != 0) {
/*  68 */       this.externalType = paramInt1;
/*     */     }
/*  70 */     this.isStream = true;
/*  71 */     this.isColumnNumberAware = true;
/*  72 */     this.internalTypeMaxLength = Integer.MAX_VALUE;
/*     */     
/*  74 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*  75 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*     */     
/*  78 */     this.charLength = 0;
/*     */ 
/*     */     
/*  81 */     this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleInputStream initForNewRow() throws SQLException {
/*  91 */     this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
/*     */ 
/*     */     
/*  94 */     return this.stream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateColumnNumber(int paramInt) {
/* 106 */     this.columnPosition = ++paramInt;
/*     */     
/* 108 */     if (this.stream != null) {
/* 109 */       this.stream.columnIndex = paramInt;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 126 */     return getBytesInternal(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytesInternal(int paramInt) throws SQLException {
/* 132 */     byte[] arrayOfByte = null;
/*     */     
/* 134 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 138 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 139 */       sQLException.fillInStackTrace();
/* 140 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*     */     {
/* 147 */       if (this.stream != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 153 */         if (this.stream.closed) {
/*     */           
/* 155 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 156 */           sQLException.fillInStackTrace();
/* 157 */           throw sQLException;
/*     */         } 
/*     */         
/* 160 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
/* 161 */         byte[] arrayOfByte1 = new byte[1024];
/*     */         
/*     */         try {
/*     */           int i;
/*     */           
/* 166 */           while ((i = this.stream.read(arrayOfByte1)) != -1)
/*     */           {
/* 168 */             byteArrayOutputStream.write(arrayOfByte1, 0, i);
/*     */           }
/*     */         }
/* 171 */         catch (IOException iOException) {
/*     */ 
/*     */           
/* 174 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 175 */           sQLException.fillInStackTrace();
/* 176 */           throw sQLException;
/*     */         } 
/*     */ 
/*     */         
/* 180 */         arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */       } 
/*     */     }
/*     */     
/* 184 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 199 */     String str = null;
/*     */     
/* 201 */     byte[] arrayOfByte = getBytes(paramInt);
/*     */     
/* 203 */     if (arrayOfByte != null) {
/*     */       
/* 205 */       int i = Math.min(arrayOfByte.length, this.internalTypeMaxLength);
/*     */ 
/*     */ 
/*     */       
/* 209 */       if (i == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 214 */         str = "";
/*     */       
/*     */       }
/* 217 */       else if (this.formOfUse == 2) {
/* 218 */         str = this.statement.connection.conversion.NCharBytesToString(arrayOfByte, i);
/*     */       } else {
/*     */         
/* 221 */         str = this.statement.connection.conversion.CharBytesToString(arrayOfByte, i);
/*     */       } 
/*     */     } 
/*     */     
/* 225 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 240 */     InputStream inputStream = null;
/*     */     
/* 242 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 246 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 247 */       sQLException.fillInStackTrace();
/* 248 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 253 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
/*     */       
/* 255 */       if (this.stream.closed) {
/*     */         
/* 257 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 258 */         sQLException.fillInStackTrace();
/* 259 */         throw sQLException;
/*     */       } 
/*     */       
/* 262 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 264 */       inputStream = physicalConnection.conversion.ConvertStream(this.stream, 0);
/*     */     } 
/*     */     
/* 267 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 282 */     InputStream inputStream = null;
/*     */     
/* 284 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 288 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 289 */       sQLException.fillInStackTrace();
/* 290 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 295 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
/*     */       
/* 297 */       if (this.stream.closed) {
/*     */         
/* 299 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 300 */         sQLException.fillInStackTrace();
/* 301 */         throw sQLException;
/*     */       } 
/*     */       
/* 304 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 306 */       inputStream = physicalConnection.conversion.ConvertStream(this.stream, 1);
/*     */     } 
/*     */     
/* 309 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 324 */     Reader reader = null;
/*     */     
/* 326 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 330 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 331 */       sQLException.fillInStackTrace();
/* 332 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 337 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
/*     */       
/* 339 */       if (this.stream.closed) {
/*     */         
/* 341 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 342 */         sQLException.fillInStackTrace();
/* 343 */         throw sQLException;
/*     */       } 
/*     */       
/* 346 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 348 */       reader = physicalConnection.conversion.ConvertCharacterStream(this.stream, 9, this.formOfUse);
/*     */     } 
/*     */ 
/*     */     
/* 352 */     return reader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 367 */     InputStream inputStream = null;
/*     */     
/* 369 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 373 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 374 */       sQLException.fillInStackTrace();
/* 375 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 380 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
/*     */       
/* 382 */       if (this.stream.closed) {
/*     */         
/* 384 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 385 */         sQLException.fillInStackTrace();
/* 386 */         throw sQLException;
/*     */       } 
/*     */       
/* 389 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 391 */       inputStream = physicalConnection.conversion.ConvertStream(this.stream, 6);
/*     */     } 
/*     */     
/* 394 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 402 */     return "LongAccessor@" + Integer.toHexString(hashCode()) + "{columnPosition = " + this.columnPosition + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 410 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\LongAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */