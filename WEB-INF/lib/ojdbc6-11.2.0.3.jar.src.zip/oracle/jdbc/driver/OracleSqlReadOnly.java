/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleSqlReadOnly
/*      */ {
/*      */   private static final int BASE = 0;
/*      */   private static final int BASE_1 = 1;
/*      */   private static final int BASE_2 = 2;
/*      */   private static final int B_STRING = 3;
/*      */   private static final int B_NAME = 4;
/*      */   private static final int B_C_COMMENT = 5;
/*      */   private static final int B_C_COMMENT_1 = 6;
/*      */   private static final int B_COMMENT = 7;
/*      */   private static final int PARAMETER = 8;
/*      */   private static final int TOKEN = 9;
/*      */   private static final int B_EGIN = 10;
/*      */   private static final int BE_GIN = 11;
/*      */   private static final int BEG_IN = 12;
/*      */   private static final int BEGI_N = 13;
/*      */   private static final int BEGIN_ = 14;
/*      */   private static final int C_ALL = 15;
/*      */   private static final int CA_LL = 16;
/*      */   private static final int CAL_L = 17;
/*      */   private static final int CALL_ = 18;
/*      */   private static final int D_Eetc = 19;
/*      */   private static final int DE_etc = 20;
/*      */   private static final int DEC_LARE = 21;
/*      */   private static final int DECL_ARE = 22;
/*      */   private static final int DECLA_RE = 23;
/*      */   private static final int DECLAR_E = 24;
/*      */   private static final int DECLARE_ = 25;
/*      */   private static final int DEL_ETE = 26;
/*      */   private static final int DELE_TE = 27;
/*      */   private static final int DELET_E = 28;
/*      */   private static final int DELETE_ = 29;
/*      */   private static final int I_NSERT = 30;
/*      */   private static final int IN_SERT = 31;
/*      */   private static final int INS_ERT = 32;
/*      */   private static final int INSE_RT = 33;
/*      */   private static final int INSER_T = 34;
/*      */   private static final int INSERT_ = 35;
/*      */   private static final int S_ELECT = 36;
/*      */   private static final int SE_LECT = 37;
/*      */   private static final int SEL_ECT = 38;
/*      */   private static final int SELE_CT = 39;
/*      */   private static final int SELEC_T = 40;
/*      */   private static final int SELECT_ = 41;
/*      */   private static final int U_PDATE = 42;
/*      */   private static final int UP_DATE = 43;
/*      */   private static final int UPD_ATE = 44;
/*      */   private static final int UPDA_TE = 45;
/*      */   private static final int UPDAT_E = 46;
/*      */   private static final int UPDATE_ = 47;
/*      */   private static final int M_ERGE = 48;
/*      */   private static final int ME_RGE = 49;
/*      */   private static final int MER_GE = 50;
/*      */   private static final int MERG_E = 51;
/*      */   private static final int MERGE_ = 52;
/*      */   private static final int W_ITH = 53;
/*      */   private static final int WI_TH = 54;
/*      */   private static final int WIT_H = 55;
/*      */   private static final int WITH_ = 56;
/*      */   private static final int KNOW_KIND = 57;
/*      */   private static final int KNOW_KIND_1 = 58;
/*      */   private static final int KNOW_KIND_2 = 59;
/*      */   private static final int K_STRING = 60;
/*      */   private static final int K_NAME = 61;
/*      */   private static final int K_C_COMMENT = 62;
/*      */   private static final int K_C_COMMENT_1 = 63;
/*      */   private static final int K_COMMENT = 64;
/*      */   private static final int K_PARAMETER = 65;
/*      */   private static final int TOKEN_KK = 66;
/*      */   private static final int W_HERE = 67;
/*      */   private static final int WH_ERE = 68;
/*      */   private static final int WHE_RE = 69;
/*      */   private static final int WHER_E = 70;
/*      */   private static final int WHERE_ = 71;
/*      */   private static final int O_RDER_BY = 72;
/*      */   private static final int OR_DER_BY = 73;
/*      */   private static final int ORD_ER_BY = 74;
/*      */   private static final int ORDE_R_BY = 75;
/*      */   private static final int ORDER__BY = 76;
/*      */   private static final int ORDER_xBY = 77;
/*      */   private static final int ORDER_B_Y = 78;
/*      */   private static final int ORDER_BY_ = 79;
/*      */   private static final int ORDER_xBY_CC_1 = 80;
/*      */   private static final int ORDER_xBY_CC_2 = 81;
/*      */   private static final int ORDER_xBY_CC_3 = 82;
/*      */   private static final int ORDER_xBY_C_1 = 83;
/*      */   private static final int ORDER_xBY_C_2 = 84;
/*      */   private static final int F_OR_UPDATE = 85;
/*      */   private static final int FO_R_UPDATE = 86;
/*      */   private static final int FOR__UPDATE = 87;
/*      */   private static final int FOR_xUPDATE = 88;
/*      */   private static final int FOR_U_PDATE = 89;
/*      */   private static final int FOR_UP_DATE = 90;
/*      */   private static final int FOR_UPD_ATE = 91;
/*      */   private static final int FOR_UPDA_TE = 92;
/*      */   private static final int FOR_UPDAT_E = 93;
/*      */   private static final int FOR_UPDATE_ = 94;
/*      */   private static final int FOR_xUPDATE_CC_1 = 95;
/*      */   private static final int FOR_xUPDATE_CC_2 = 96;
/*      */   private static final int FOR_xUPDATE_CC_3 = 97;
/*      */   private static final int FOR_xUPDATE_C_1 = 98;
/*      */   private static final int FOR_xUPDATE_C_2 = 99;
/*      */   private static final int B_N_tick = 100;
/*      */   private static final int B_NCHAR = 101;
/*      */   private static final int K_N_tick = 102;
/*      */   private static final int K_NCHAR = 103;
/*      */   private static final int K_NCHAR_tick = 104;
/*      */   private static final int B_Q_tickDelimiterCharDelimiterTick = 105;
/*      */   private static final int B_QTick_delimiterCharDelimiterTick = 106;
/*      */   private static final int B_QTickDelimiter_charDelimiterTick = 107;
/*      */   private static final int B_QTickDelimiterChar_delimiterTick = 108;
/*      */   private static final int B_QTickDelimiterCharDelimiter_tick = 109;
/*      */   private static final int K_Q_tickDelimiterCharDelimiterTick = 110;
/*      */   private static final int K_QTick_delimiterCharDelimiterTick = 111;
/*      */   private static final int K_QTickDelimiter_charDelimiterTick = 112;
/*      */   private static final int K_QTickDelimiterChar_delimiterTick = 113;
/*      */   private static final int K_QTickDelimiterCharDelimiter_tick = 114;
/*      */   private static final int K_EscEtc = 115;
/*      */   private static final int K_EscQuestion = 116;
/*      */   private static final int K_EscC_ALL = 117;
/*      */   private static final int K_EscCA_LL = 118;
/*      */   private static final int K_EscCAL_L = 119;
/*      */   private static final int K_EscCALL_ = 120;
/*      */   private static final int K_EscT = 121;
/*      */   private static final int K_EscTS_ = 122;
/*      */   private static final int K_EscD_ = 123;
/*      */   private static final int K_EscE_SCAPE = 124;
/*      */   private static final int K_EscES_CAPE = 125;
/*      */   private static final int K_EscESC_APE = 126;
/*      */   private static final int K_EscESCA_PE = 127;
/*      */   private static final int K_EscESCAP_E = 128;
/*      */   private static final int K_EscESCAPE_ = 129;
/*      */   private static final int K_EscF_N = 130;
/*      */   private static final int K_EscFN_ = 131;
/*      */   private static final int K_EscO_J = 132;
/*      */   private static final int K_EscOJ_ = 133;
/*      */   private static final int SKIP_PARAMETER_WHITESPACE = 134;
/*      */   private static final int A_LTER_SESSION = 135;
/*      */   private static final int AL_TER_SESSION = 136;
/*      */   private static final int ALT_ER_SESSION = 137;
/*      */   private static final int ALTE_R_SESSION = 138;
/*      */   private static final int ALTER__SESSION = 139;
/*      */   private static final int ALTER_xSESSION = 140;
/*      */   private static final int ALTER_S_ESSION = 141;
/*      */   private static final int ALTER_SE_SSION = 142;
/*      */   private static final int ALTER_SES_SION = 143;
/*      */   private static final int ALTER_SESS_ION = 144;
/*      */   private static final int ALTER_SESSI_ON = 145;
/*      */   private static final int ALTER_SESSIO_N = 146;
/*      */   private static final int ALTER_SESSION_ = 147;
/*      */   private static final int ALTER_xSESSION_CC_1 = 148;
/*      */   private static final int ALTER_xSESSION_CC_2 = 149;
/*      */   private static final int ALTER_xSESSION_CC_3 = 150;
/*      */   private static final int ALTER_xSESSION_C_1 = 151;
/*      */   private static final int ALTER_xSESSION_C_2 = 152;
/*      */   private static final int LAST_STATE = 153;
/*      */   private static final int EOKTSS_LAST_STATE = 153;
/* 2330 */   public static final String[] PARSER_STATE_NAME = new String[] { "BASE", "BASE_1", "BASE_2", "B_STRING", "B_NAME", "B_C_COMMENT", "B_C_COMMENT_1", "B_COMMENT", "PARAMETER", "TOKEN", "B_EGIN", "BE_GIN", "BEG_IN", "BEGI_N", "BEGIN_", "C_ALL", "CA_LL", "CAL_L", "CALL_", "D_Eetc", "DE_etc", "DEC_LARE", "DECL_ARE", "DECLA_RE", "DECLAR_E", "DECLARE_", "DEL_ETE", "DELE_TE", "DELET_E", "DELETE_", "I_NSERT", "IN_SERT", "INS_ERT", "INSE_RT", "INSER_T", "INSERT_", "S_ELECT", "SE_LECT", "SEL_ECT", "SELE_CT", "SELEC_T", "SELECT_", "U_PDATE", "UP_DATE", "UPD_ATE", "UPDA_TE", "UPDAT_E", "UPDATE_", "M_ERGE", "ME_RGE", "MER_GE", "MERG_E", "MERGE_", "W_ITH", "WI_TH", "WIT_H", "WITH_", "KNOW_KIND", "KNOW_KIND_1", "KNOW_KIND_2", "K_STRING", "K_NAME", "K_C_COMMENT", "K_C_COMMENT_1", "K_COMMENT", "K_PARAMETER", "TOKEN_KK", "W_HERE", "WH_ERE", "WHE_RE", "WHER_E", "WHERE_", "O_RDER_BY", "OR_DER_BY", "ORD_ER_BY", "ORDE_R_BY", "ORDER__BY", "ORDER_xBY", "ORDER_B_Y", "ORDER_BY_", "ORDER_xBY_CC_1", "ORDER_xBY_CC_2", "ORDER_xBY_CC_3", "ORDER_xBY_C_1 ", "ORDER_xBY_C_2 ", "F_OR_UPDATE", "FO_R_UPDATE", "FOR__UPDATE", "FOR_xUPDATE", "FOR_U_PDATE", "FOR_UP_DATE", "FOR_UPD_ATE", "FOR_UPDA_TE", "FOR_UPDAT_E", "FOR_UPDATE_", "FOR_xUPDATE_CC_1", "FOR_xUPDATE_CC_2", "FOR_xUPDATE_CC_3", "FOR_xUPDATE_C_1 ", "FOR_xUPDATE_C_2 ", "B_N_tick", "B_NCHAR", "K_N_tick", "K_NCHAR", "K_NCHAR_tick", "B_Q_tickDelimiterCharDelimiterTick", "B_QTick_delimiterCharDelimiterTick", "B_QTickDelimiter_charDelimiterTick", "B_QTickDelimiterChar_delimiterTick", "B_QTickDelimiterCharDelimiter_tick", "K_Q_tickDelimiterCharDelimiterTick", "K_QTick_delimiterCharDelimiterTick", "K_QTickDelimiter_charDelimiterTick", "K_QTickDelimiterChar_delimiterTick", "K_QTickDelimiterCharDelimiter_tick", "K_EscEtc", "K_EscQuestion", "K_EscC_ALL", "K_EscCA_LL", "K_EscCAL_L", "K_EscCALL_", "K_EscT", "K_EscTS_", "K_EscD_", "K_EscE_SCAPE", "K_EscES_CAPE", "K_EscESC_APE", "K_EscESCA_PE", "K_EscESCAP_E", "K_EscESCAPE_", "K_EscF_N", "K_EscFN_", "K_EscO_J", "K_EscOJ_", "SKIP_PARAMETER_WHITESPACE", "A_LTER_SESSION", "AL_TER_SESSION", "ALT_ER_SESSION", "ALTE_R_SESSION", "ALTER__SESSION", "ALTER_xSESSION", "ALTER_S_ESSION", "ALTER_SE_SSION", "ALTER_SES_SION", "ALTER_SESS_ION", "ALTER_SESSI_ON", "ALTER_SESSIO_N", "ALTER_SESSION_", "ALTER_xSESSION_CC_1", "ALTER_xSESSION_CC_2", "ALTER_xSESSION_CC_3", "ALTER_xSESSION_C_1 ", "ALTER_xSESSION_C_2 ", "LAST_STATE" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2507 */   static final int[][] TRANSITION = new int[153][];
/*      */   
/*      */   static final int NO_ACTION = 0;
/*      */   
/*      */   static final int DELETE_ACTION = 1;
/*      */   
/*      */   static final int INSERT_ACTION = 2;
/*      */   static final int MERGE_ACTION = 3;
/*      */   static final int UPDATE_ACTION = 4;
/*      */   static final int PLSQL_ACTION = 5;
/*      */   static final int CALL_ACTION = 6;
/*      */   static final int SELECT_ACTION = 7;
/*      */   static final int OTHER_ACTION = 8;
/*      */   static final int WHERE_ACTION = 9;
/*      */   static final int ORDER_ACTION = 10;
/*      */   static final int ORDER_BY_ACTION = 11;
/*      */   static final int FOR_ACTION = 12;
/*      */   static final int FOR_UPDATE_ACTION = 13;
/*      */   static final int QUESTION_ACTION = 14;
/*      */   static final int PARAMETER_ACTION = 15;
/*      */   static final int END_PARAMETER_ACTION = 16;
/*      */   static final int START_NCHAR_LITERAL_ACTION = 17;
/*      */   static final int END_NCHAR_LITERAL_ACTION = 18;
/*      */   static final int SAVE_DELIMITER_ACTION = 19;
/*      */   static final int LOOK_FOR_DELIMITER_ACTION = 20;
/*      */   static final int ALTER_SESSION_ACTION = 21;
/* 2533 */   public static final String[] CBI_ACTION_NAME = new String[] { "NO_ACTION", "DELETE_ACTION", "INSERT_ACTION", "MERGE_ACTION", "UPDATE_ACTION", "PLSQL_ACTION", "CALL_ACTION", "SELECT_ACTION", "OTHER_ACTION", "WHERE_ACTION", "ORDER_ACTION", "ORDER_BY_ACTION", "FOR_ACTION", "FOR_UPDATE_ACTION", "QUESTION_ACTION", "PARAMETER_ACTION", "END_PARAMETER_ACTION", "START_NCHAR_LITERAL_ACTION", "END_NCHAR_LITERAL_ACTION", "SAVE_DELIMITER_ACTION", "LOOK_FOR_DELIMITER_ACTION", "ALTER_SESSION_ACTION" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2563 */   static final int[][] ACTION = new int[153][];
/*      */ 
/*      */   
/*      */   static final int INITIAL_STATE = 0;
/*      */   
/*      */   static final int RESTART_STATE = 66;
/*      */ 
/*      */   
/*      */   enum ODBCAction
/*      */   {
/* 2573 */     NONE,
/* 2574 */     COPY,
/* 2575 */     QUESTION,
/* 2576 */     SAVE_DELIMITER,
/* 2577 */     LOOK_FOR_DELIMITER,
/* 2578 */     FUNCTION,
/* 2579 */     CALL,
/* 2580 */     TIME,
/* 2581 */     TIMESTAMP,
/* 2582 */     DATE,
/* 2583 */     ESCAPE,
/* 2584 */     SCALAR_FUNCTION,
/* 2585 */     OUTER_JOIN,
/* 2586 */     UNKNOWN_ESCAPE,
/* 2587 */     END_ODBC_ESCAPE,
/* 2588 */     COMMA,
/* 2589 */     OPEN_PAREN,
/* 2590 */     CLOSE_PAREN,
/* 2591 */     BEGIN;
/*      */   }
/*      */   
/* 2594 */   static final ODBCAction[][] ODBC_ACTION = new ODBCAction[153][];
/*      */   static final int cMax = 127;
/*      */   private static final int cMaxLength = 128;
/*      */   
/*      */   private static final int[] copy(int[] paramArrayOfint) {
/* 2599 */     int[] arrayOfInt = new int[paramArrayOfint.length];
/* 2600 */     System.arraycopy(paramArrayOfint, 0, arrayOfInt, 0, paramArrayOfint.length);
/* 2601 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final ODBCAction[] copy(ODBCAction[] paramArrayOfODBCAction) {
/* 2608 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramArrayOfODBCAction.length];
/* 2609 */     System.arraycopy(paramArrayOfODBCAction, 0, arrayOfODBCAction, 0, paramArrayOfODBCAction.length);
/* 2610 */     return arrayOfODBCAction;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int[] newArray(int paramInt1, int paramInt2) {
/* 2616 */     int[] arrayOfInt = new int[paramInt1];
/*      */     
/* 2618 */     for (byte b = 0; b < paramInt1; b++) {
/* 2619 */       arrayOfInt[b] = paramInt2;
/*      */     }
/* 2621 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final ODBCAction[] newArray(int paramInt, ODBCAction paramODBCAction) {
/* 2627 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramInt];
/*      */     
/* 2629 */     for (byte b = 0; b < paramInt; b++) {
/* 2630 */       arrayOfODBCAction[b] = paramODBCAction;
/*      */     }
/* 2632 */     return arrayOfODBCAction;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int[] copyReplacing(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 2637 */     int[] arrayOfInt = new int[paramArrayOfint.length];
/*      */     
/* 2639 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */       
/* 2641 */       int i = paramArrayOfint[b];
/*      */       
/* 2643 */       if (i == paramInt1) {
/* 2644 */         arrayOfInt[b] = paramInt2;
/*      */       } else {
/* 2646 */         arrayOfInt[b] = i;
/*      */       } 
/*      */     } 
/* 2649 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final ODBCAction[] copyReplacing(ODBCAction[] paramArrayOfODBCAction, ODBCAction paramODBCAction1, ODBCAction paramODBCAction2) {
/* 2654 */     ODBCAction[] arrayOfODBCAction = new ODBCAction[paramArrayOfODBCAction.length];
/*      */     
/* 2656 */     for (byte b = 0; b < arrayOfODBCAction.length; b++) {
/*      */       
/* 2658 */       ODBCAction oDBCAction = paramArrayOfODBCAction[b];
/*      */       
/* 2660 */       if (oDBCAction == paramODBCAction1) {
/* 2661 */         arrayOfODBCAction[b] = paramODBCAction2;
/*      */       } else {
/* 2663 */         arrayOfODBCAction[b] = oDBCAction;
/*      */       } 
/*      */     } 
/* 2666 */     return arrayOfODBCAction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*      */     try {
/* 2681 */       int[] arrayOfInt1 = { 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 9, 57, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 57, 57, 57 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2718 */       int[] arrayOfInt2 = copy(arrayOfInt1);
/* 2719 */       arrayOfInt2[34] = 4;
/* 2720 */       arrayOfInt2[39] = 3;
/* 2721 */       arrayOfInt2[45] = 2;
/* 2722 */       arrayOfInt2[47] = 1;
/* 2723 */       arrayOfInt2[58] = 8;
/* 2724 */       arrayOfInt2[123] = 115;
/*      */ 
/*      */ 
/*      */       
/* 2728 */       int[] arrayOfInt3 = copyReplacing(arrayOfInt2, 57, 0);
/* 2729 */       arrayOfInt3[65] = 135;
/* 2730 */       arrayOfInt3[97] = 135;
/* 2731 */       arrayOfInt3[66] = 10;
/* 2732 */       arrayOfInt3[98] = 10;
/* 2733 */       arrayOfInt3[67] = 15;
/* 2734 */       arrayOfInt3[99] = 15;
/* 2735 */       arrayOfInt3[68] = 19;
/* 2736 */       arrayOfInt3[100] = 19;
/* 2737 */       arrayOfInt3[73] = 30;
/* 2738 */       arrayOfInt3[105] = 30;
/* 2739 */       arrayOfInt3[109] = 48;
/* 2740 */       arrayOfInt3[77] = 48;
/* 2741 */       arrayOfInt3[78] = 100;
/* 2742 */       arrayOfInt3[110] = 100;
/* 2743 */       arrayOfInt3[81] = 105;
/* 2744 */       arrayOfInt3[113] = 105;
/* 2745 */       arrayOfInt3[83] = 36;
/* 2746 */       arrayOfInt3[115] = 36;
/* 2747 */       arrayOfInt3[85] = 42;
/* 2748 */       arrayOfInt3[117] = 42;
/* 2749 */       arrayOfInt3[87] = 53;
/* 2750 */       arrayOfInt3[119] = 53;
/*      */ 
/*      */       
/* 2753 */       int[] arrayOfInt4 = copyReplacing(arrayOfInt2, 9, 66);
/* 2754 */       arrayOfInt4[34] = 61;
/* 2755 */       arrayOfInt4[39] = 60;
/* 2756 */       arrayOfInt4[45] = 59;
/* 2757 */       arrayOfInt4[47] = 58;
/* 2758 */       arrayOfInt4[58] = 134;
/* 2759 */       arrayOfInt4[32] = 57;
/* 2760 */       arrayOfInt4[32] = 57;
/* 2761 */       arrayOfInt4[9] = 57;
/* 2762 */       arrayOfInt4[10] = 57;
/* 2763 */       arrayOfInt4[13] = 57;
/* 2764 */       arrayOfInt4[61] = 57;
/*      */ 
/*      */       
/* 2767 */       int[] arrayOfInt5 = copyReplacing(arrayOfInt4, 9, 66);
/* 2768 */       arrayOfInt5[78] = 102;
/* 2769 */       arrayOfInt5[110] = 102;
/* 2770 */       arrayOfInt5[81] = 110;
/* 2771 */       arrayOfInt5[113] = 110;
/* 2772 */       arrayOfInt5[87] = 67;
/* 2773 */       arrayOfInt5[119] = 67;
/* 2774 */       arrayOfInt5[79] = 72;
/* 2775 */       arrayOfInt5[111] = 72;
/* 2776 */       arrayOfInt5[70] = 85;
/* 2777 */       arrayOfInt5[102] = 85;
/*      */ 
/*      */ 
/*      */       
/* 2781 */       int[] arrayOfInt6 = copyReplacing(arrayOfInt5, 57, 115);
/*      */       
/* 2783 */       arrayOfInt6[63] = 116;
/* 2784 */       arrayOfInt6[99] = 117;
/* 2785 */       arrayOfInt6[67] = 117;
/* 2786 */       arrayOfInt6[116] = 121;
/* 2787 */       arrayOfInt6[84] = 121;
/* 2788 */       arrayOfInt6[100] = 123;
/* 2789 */       arrayOfInt6[68] = 123;
/* 2790 */       arrayOfInt6[101] = 124;
/* 2791 */       arrayOfInt6[69] = 124;
/* 2792 */       arrayOfInt6[102] = 130;
/* 2793 */       arrayOfInt6[70] = 130;
/* 2794 */       arrayOfInt6[111] = 132;
/* 2795 */       arrayOfInt6[79] = 132;
/*      */ 
/*      */ 
/*      */       
/* 2799 */       TRANSITION[0] = arrayOfInt3;
/* 2800 */       TRANSITION[1] = copy(arrayOfInt3);
/* 2801 */       TRANSITION[1][42] = 5;
/* 2802 */       TRANSITION[2] = copy(arrayOfInt3);
/* 2803 */       TRANSITION[2][45] = 7;
/* 2804 */       TRANSITION[3] = newArray(128, 3);
/* 2805 */       TRANSITION[3][39] = 0;
/* 2806 */       TRANSITION[100] = copy(arrayOfInt2);
/* 2807 */       TRANSITION[100][39] = 101;
/* 2808 */       TRANSITION[101] = newArray(128, 101);
/* 2809 */       TRANSITION[101][39] = 0;
/*      */       
/* 2811 */       TRANSITION[105] = copy(arrayOfInt2);
/* 2812 */       TRANSITION[105][39] = 106;
/* 2813 */       TRANSITION[106] = newArray(128, 107);
/* 2814 */       TRANSITION[107] = newArray(128, 107);
/*      */       
/* 2816 */       TRANSITION[108] = newArray(128, 109);
/* 2817 */       TRANSITION[109] = newArray(128, 107);
/* 2818 */       TRANSITION[109][39] = 0;
/*      */ 
/*      */       
/* 2821 */       TRANSITION[4] = newArray(128, 4);
/* 2822 */       TRANSITION[4][34] = 0;
/* 2823 */       TRANSITION[5] = newArray(128, 5);
/* 2824 */       TRANSITION[5][42] = 6;
/* 2825 */       TRANSITION[6] = newArray(128, 5);
/* 2826 */       TRANSITION[6][42] = 6;
/* 2827 */       TRANSITION[6][47] = 0;
/* 2828 */       TRANSITION[7] = newArray(128, 7);
/* 2829 */       TRANSITION[7][10] = 0;
/* 2830 */       TRANSITION[8] = copyReplacing(arrayOfInt2, 9, 8);
/* 2831 */       TRANSITION[9] = arrayOfInt2;
/* 2832 */       TRANSITION[10] = copy(arrayOfInt2);
/* 2833 */       TRANSITION[10][69] = 11;
/* 2834 */       TRANSITION[10][101] = 11;
/* 2835 */       TRANSITION[11] = copy(arrayOfInt2);
/* 2836 */       TRANSITION[11][71] = 12;
/* 2837 */       TRANSITION[11][103] = 12;
/* 2838 */       TRANSITION[12] = copy(arrayOfInt2);
/* 2839 */       TRANSITION[12][73] = 13;
/* 2840 */       TRANSITION[12][105] = 13;
/* 2841 */       TRANSITION[13] = copy(arrayOfInt2);
/* 2842 */       TRANSITION[13][78] = 14;
/* 2843 */       TRANSITION[13][110] = 14;
/* 2844 */       TRANSITION[14] = arrayOfInt5;
/* 2845 */       TRANSITION[15] = copy(arrayOfInt2);
/* 2846 */       TRANSITION[15][65] = 16;
/* 2847 */       TRANSITION[15][97] = 16;
/* 2848 */       TRANSITION[16] = copy(arrayOfInt2);
/* 2849 */       TRANSITION[16][76] = 17;
/* 2850 */       TRANSITION[16][108] = 17;
/* 2851 */       TRANSITION[17] = copy(arrayOfInt2);
/* 2852 */       TRANSITION[17][76] = 18;
/* 2853 */       TRANSITION[17][108] = 18;
/* 2854 */       TRANSITION[18] = arrayOfInt5;
/* 2855 */       TRANSITION[19] = copy(arrayOfInt2);
/* 2856 */       TRANSITION[19][69] = 20;
/* 2857 */       TRANSITION[19][101] = 20;
/* 2858 */       TRANSITION[20] = copy(arrayOfInt2);
/* 2859 */       TRANSITION[20][67] = 21;
/* 2860 */       TRANSITION[20][99] = 21;
/* 2861 */       TRANSITION[20][76] = 26;
/* 2862 */       TRANSITION[20][108] = 26;
/* 2863 */       TRANSITION[21] = copy(arrayOfInt2);
/* 2864 */       TRANSITION[21][76] = 22;
/* 2865 */       TRANSITION[21][108] = 22;
/* 2866 */       TRANSITION[22] = copy(arrayOfInt2);
/* 2867 */       TRANSITION[22][65] = 23;
/* 2868 */       TRANSITION[22][97] = 23;
/* 2869 */       TRANSITION[23] = copy(arrayOfInt2);
/* 2870 */       TRANSITION[23][82] = 24;
/* 2871 */       TRANSITION[23][114] = 24;
/* 2872 */       TRANSITION[24] = copy(arrayOfInt2);
/* 2873 */       TRANSITION[24][69] = 25;
/* 2874 */       TRANSITION[24][101] = 25;
/* 2875 */       TRANSITION[25] = arrayOfInt5;
/* 2876 */       TRANSITION[26] = copy(arrayOfInt2);
/* 2877 */       TRANSITION[26][69] = 27;
/* 2878 */       TRANSITION[26][101] = 27;
/* 2879 */       TRANSITION[27] = copy(arrayOfInt2);
/* 2880 */       TRANSITION[27][84] = 28;
/* 2881 */       TRANSITION[27][116] = 28;
/* 2882 */       TRANSITION[28] = copy(arrayOfInt2);
/* 2883 */       TRANSITION[28][69] = 29;
/* 2884 */       TRANSITION[28][101] = 29;
/* 2885 */       TRANSITION[29] = arrayOfInt5;
/* 2886 */       TRANSITION[30] = copy(arrayOfInt2);
/* 2887 */       TRANSITION[30][78] = 31;
/* 2888 */       TRANSITION[30][110] = 31;
/* 2889 */       TRANSITION[31] = copy(arrayOfInt2);
/* 2890 */       TRANSITION[31][83] = 32;
/* 2891 */       TRANSITION[31][115] = 32;
/* 2892 */       TRANSITION[32] = copy(arrayOfInt2);
/* 2893 */       TRANSITION[32][69] = 33;
/* 2894 */       TRANSITION[32][101] = 33;
/* 2895 */       TRANSITION[33] = copy(arrayOfInt2);
/* 2896 */       TRANSITION[33][82] = 34;
/* 2897 */       TRANSITION[33][114] = 34;
/* 2898 */       TRANSITION[34] = copy(arrayOfInt2);
/* 2899 */       TRANSITION[34][84] = 35;
/* 2900 */       TRANSITION[34][116] = 35;
/* 2901 */       TRANSITION[35] = arrayOfInt5;
/* 2902 */       TRANSITION[36] = copy(arrayOfInt2);
/* 2903 */       TRANSITION[36][69] = 37;
/* 2904 */       TRANSITION[36][101] = 37;
/* 2905 */       TRANSITION[37] = copy(arrayOfInt2);
/* 2906 */       TRANSITION[37][76] = 38;
/* 2907 */       TRANSITION[37][108] = 38;
/* 2908 */       TRANSITION[38] = copy(arrayOfInt2);
/* 2909 */       TRANSITION[38][69] = 39;
/* 2910 */       TRANSITION[38][101] = 39;
/* 2911 */       TRANSITION[39] = copy(arrayOfInt2);
/* 2912 */       TRANSITION[39][67] = 40;
/* 2913 */       TRANSITION[39][99] = 40;
/* 2914 */       TRANSITION[40] = copy(arrayOfInt2);
/* 2915 */       TRANSITION[40][84] = 41;
/* 2916 */       TRANSITION[40][116] = 41;
/* 2917 */       TRANSITION[41] = arrayOfInt5;
/* 2918 */       TRANSITION[42] = copy(arrayOfInt2);
/* 2919 */       TRANSITION[42][80] = 43;
/* 2920 */       TRANSITION[42][112] = 43;
/* 2921 */       TRANSITION[43] = copy(arrayOfInt2);
/* 2922 */       TRANSITION[43][68] = 44;
/* 2923 */       TRANSITION[43][100] = 44;
/* 2924 */       TRANSITION[44] = copy(arrayOfInt2);
/* 2925 */       TRANSITION[44][65] = 45;
/* 2926 */       TRANSITION[44][97] = 45;
/* 2927 */       TRANSITION[45] = copy(arrayOfInt2);
/* 2928 */       TRANSITION[45][84] = 46;
/* 2929 */       TRANSITION[45][116] = 46;
/* 2930 */       TRANSITION[46] = copy(arrayOfInt2);
/* 2931 */       TRANSITION[46][69] = 47;
/* 2932 */       TRANSITION[46][101] = 47;
/* 2933 */       TRANSITION[47] = arrayOfInt5;
/* 2934 */       TRANSITION[48] = copy(arrayOfInt2);
/* 2935 */       TRANSITION[48][69] = 49;
/* 2936 */       TRANSITION[48][101] = 49;
/* 2937 */       TRANSITION[49] = copy(arrayOfInt2);
/* 2938 */       TRANSITION[49][82] = 50;
/* 2939 */       TRANSITION[49][114] = 50;
/* 2940 */       TRANSITION[50] = copy(arrayOfInt2);
/* 2941 */       TRANSITION[50][71] = 51;
/* 2942 */       TRANSITION[50][103] = 51;
/* 2943 */       TRANSITION[51] = copy(arrayOfInt2);
/* 2944 */       TRANSITION[51][69] = 52;
/* 2945 */       TRANSITION[51][101] = 52;
/* 2946 */       TRANSITION[52] = arrayOfInt5;
/* 2947 */       TRANSITION[53] = copy(arrayOfInt2);
/* 2948 */       TRANSITION[53][73] = 54;
/* 2949 */       TRANSITION[53][105] = 54;
/* 2950 */       TRANSITION[54] = copy(arrayOfInt2);
/* 2951 */       TRANSITION[54][84] = 55;
/* 2952 */       TRANSITION[54][116] = 55;
/* 2953 */       TRANSITION[55] = copy(arrayOfInt2);
/* 2954 */       TRANSITION[55][72] = 56;
/* 2955 */       TRANSITION[55][104] = 56;
/* 2956 */       TRANSITION[56] = arrayOfInt5;
/* 2957 */       TRANSITION[66] = arrayOfInt4;
/* 2958 */       TRANSITION[58] = copy(arrayOfInt5);
/* 2959 */       TRANSITION[58][42] = 62;
/* 2960 */       TRANSITION[59] = copy(arrayOfInt5);
/* 2961 */       TRANSITION[59][45] = 64;
/* 2962 */       TRANSITION[62] = newArray(128, 62);
/* 2963 */       TRANSITION[62][42] = 63;
/* 2964 */       TRANSITION[63] = newArray(128, 62);
/* 2965 */       TRANSITION[63][42] = 63;
/* 2966 */       TRANSITION[63][47] = 57;
/* 2967 */       TRANSITION[64] = newArray(128, 64);
/* 2968 */       TRANSITION[64][10] = 57;
/* 2969 */       TRANSITION[61] = newArray(128, 61);
/* 2970 */       TRANSITION[61][34] = 57;
/* 2971 */       TRANSITION[60] = newArray(128, 60);
/* 2972 */       TRANSITION[60][39] = 57;
/* 2973 */       TRANSITION[65] = copyReplacing(arrayOfInt4, 66, 65);
/* 2974 */       TRANSITION[134] = copyReplacing(arrayOfInt4, 66, 65);
/* 2975 */       TRANSITION[134][32] = 134;
/* 2976 */       TRANSITION[134][10] = 134;
/* 2977 */       TRANSITION[134][13] = 134;
/* 2978 */       TRANSITION[134][9] = 134;
/*      */ 
/*      */       
/* 2981 */       TRANSITION[57] = arrayOfInt5;
/* 2982 */       TRANSITION[67] = copy(arrayOfInt4);
/* 2983 */       TRANSITION[67][72] = 68;
/* 2984 */       TRANSITION[67][104] = 68;
/* 2985 */       TRANSITION[68] = copy(arrayOfInt4);
/* 2986 */       TRANSITION[68][69] = 69;
/* 2987 */       TRANSITION[68][101] = 69;
/* 2988 */       TRANSITION[69] = copy(arrayOfInt4);
/* 2989 */       TRANSITION[69][82] = 70;
/* 2990 */       TRANSITION[69][114] = 70;
/* 2991 */       TRANSITION[70] = copy(arrayOfInt4);
/* 2992 */       TRANSITION[70][69] = 71;
/* 2993 */       TRANSITION[70][101] = 71;
/* 2994 */       TRANSITION[71] = arrayOfInt5;
/*      */       
/* 2996 */       TRANSITION[72] = copy(arrayOfInt4);
/* 2997 */       TRANSITION[72][82] = 73;
/* 2998 */       TRANSITION[72][114] = 73;
/* 2999 */       TRANSITION[73] = copy(arrayOfInt4);
/* 3000 */       TRANSITION[73][68] = 74;
/* 3001 */       TRANSITION[73][100] = 74;
/* 3002 */       TRANSITION[74] = copy(arrayOfInt4);
/* 3003 */       TRANSITION[74][69] = 75;
/* 3004 */       TRANSITION[74][101] = 75;
/* 3005 */       TRANSITION[75] = copy(arrayOfInt4);
/* 3006 */       TRANSITION[75][82] = 76;
/* 3007 */       TRANSITION[75][114] = 76;
/* 3008 */       TRANSITION[76] = copyReplacing(arrayOfInt5, 57, 77);
/* 3009 */       TRANSITION[76][47] = 80;
/* 3010 */       TRANSITION[76][45] = 83;
/*      */       
/* 3012 */       TRANSITION[77] = copyReplacing(arrayOfInt5, 57, 77);
/* 3013 */       TRANSITION[77][47] = 80;
/* 3014 */       TRANSITION[80] = copy(arrayOfInt5);
/* 3015 */       TRANSITION[80][42] = 81;
/* 3016 */       TRANSITION[81] = newArray(128, 81);
/* 3017 */       TRANSITION[81][42] = 82;
/* 3018 */       TRANSITION[82] = newArray(128, 81);
/* 3019 */       TRANSITION[82][47] = 77;
/*      */       
/* 3021 */       TRANSITION[77][45] = 83;
/* 3022 */       TRANSITION[83] = copy(arrayOfInt5);
/* 3023 */       TRANSITION[83][45] = 84;
/* 3024 */       TRANSITION[84] = newArray(128, 84);
/* 3025 */       TRANSITION[84][10] = 77;
/*      */ 
/*      */       
/* 3028 */       TRANSITION[77][66] = 78;
/* 3029 */       TRANSITION[77][98] = 78;
/* 3030 */       TRANSITION[78] = copy(arrayOfInt4);
/* 3031 */       TRANSITION[78][89] = 79;
/* 3032 */       TRANSITION[78][121] = 79;
/* 3033 */       TRANSITION[79] = arrayOfInt5;
/*      */       
/* 3035 */       TRANSITION[85] = copy(arrayOfInt5);
/* 3036 */       TRANSITION[85][79] = 86;
/* 3037 */       TRANSITION[85][111] = 86;
/* 3038 */       TRANSITION[86] = copy(arrayOfInt5);
/* 3039 */       TRANSITION[86][82] = 87;
/* 3040 */       TRANSITION[86][114] = 87;
/* 3041 */       TRANSITION[87] = copyReplacing(arrayOfInt4, 57, 88);
/* 3042 */       TRANSITION[87][47] = 95;
/* 3043 */       TRANSITION[87][45] = 98;
/*      */       
/* 3045 */       TRANSITION[88] = copyReplacing(arrayOfInt4, 57, 88);
/* 3046 */       TRANSITION[88][47] = 95;
/* 3047 */       TRANSITION[95] = copy(arrayOfInt5);
/* 3048 */       TRANSITION[95][42] = 96;
/* 3049 */       TRANSITION[96] = newArray(128, 96);
/* 3050 */       TRANSITION[96][42] = 97;
/* 3051 */       TRANSITION[97] = newArray(128, 96);
/* 3052 */       TRANSITION[97][47] = 88;
/*      */       
/* 3054 */       TRANSITION[88][45] = 98;
/* 3055 */       TRANSITION[98] = copy(arrayOfInt5);
/* 3056 */       TRANSITION[98][45] = 99;
/* 3057 */       TRANSITION[99] = newArray(128, 99);
/* 3058 */       TRANSITION[99][10] = 88;
/*      */ 
/*      */       
/* 3061 */       TRANSITION[88][85] = 89;
/* 3062 */       TRANSITION[88][117] = 89;
/* 3063 */       TRANSITION[89] = copy(arrayOfInt5);
/* 3064 */       TRANSITION[89][80] = 90;
/* 3065 */       TRANSITION[89][112] = 90;
/* 3066 */       TRANSITION[90] = copy(arrayOfInt5);
/* 3067 */       TRANSITION[90][68] = 91;
/* 3068 */       TRANSITION[90][100] = 91;
/* 3069 */       TRANSITION[91] = copy(arrayOfInt5);
/* 3070 */       TRANSITION[91][65] = 92;
/* 3071 */       TRANSITION[91][97] = 92;
/* 3072 */       TRANSITION[92] = copy(arrayOfInt5);
/* 3073 */       TRANSITION[92][84] = 93;
/* 3074 */       TRANSITION[92][116] = 93;
/* 3075 */       TRANSITION[93] = copy(arrayOfInt5);
/* 3076 */       TRANSITION[93][69] = 94;
/* 3077 */       TRANSITION[93][101] = 94;
/* 3078 */       TRANSITION[94] = arrayOfInt5;
/*      */       
/* 3080 */       TRANSITION[102] = copy(arrayOfInt4);
/* 3081 */       TRANSITION[102][39] = 103;
/* 3082 */       TRANSITION[103] = newArray(128, 103);
/* 3083 */       TRANSITION[103][39] = 104;
/*      */       
/* 3085 */       TRANSITION[104] = newArray(128, 57);
/* 3086 */       TRANSITION[104][39] = 103;
/*      */       
/* 3088 */       TRANSITION[110] = copy(arrayOfInt5);
/* 3089 */       TRANSITION[110][39] = 111;
/* 3090 */       TRANSITION[111] = newArray(128, 112);
/* 3091 */       TRANSITION[112] = newArray(128, 112);
/*      */       
/* 3093 */       TRANSITION[113] = newArray(128, 114);
/* 3094 */       TRANSITION[114] = newArray(128, 112);
/* 3095 */       TRANSITION[114][39] = 57;
/*      */ 
/*      */       
/* 3098 */       TRANSITION[115] = arrayOfInt6;
/* 3099 */       TRANSITION[116] = arrayOfInt5;
/* 3100 */       TRANSITION[117] = copy(arrayOfInt5);
/* 3101 */       TRANSITION[117][97] = 118;
/* 3102 */       TRANSITION[117][65] = 118;
/* 3103 */       TRANSITION[118] = copy(arrayOfInt5);
/* 3104 */       TRANSITION[118][108] = 119;
/* 3105 */       TRANSITION[118][76] = 119;
/* 3106 */       TRANSITION[119] = copy(arrayOfInt5);
/* 3107 */       TRANSITION[119][108] = 120;
/* 3108 */       TRANSITION[119][76] = 120;
/* 3109 */       TRANSITION[120] = arrayOfInt5;
/* 3110 */       TRANSITION[121] = copy(arrayOfInt5);
/* 3111 */       TRANSITION[121][115] = 122;
/* 3112 */       TRANSITION[121][83] = 122;
/* 3113 */       TRANSITION[122] = arrayOfInt5;
/* 3114 */       TRANSITION[123] = arrayOfInt5;
/* 3115 */       TRANSITION[124] = copy(arrayOfInt5);
/* 3116 */       TRANSITION[124][115] = 125;
/* 3117 */       TRANSITION[124][83] = 125;
/* 3118 */       TRANSITION[125] = copy(arrayOfInt5);
/* 3119 */       TRANSITION[125][99] = 126;
/* 3120 */       TRANSITION[125][67] = 126;
/* 3121 */       TRANSITION[126] = copy(arrayOfInt5);
/* 3122 */       TRANSITION[126][97] = 127;
/* 3123 */       TRANSITION[126][65] = 127;
/* 3124 */       TRANSITION[127] = copy(arrayOfInt5);
/* 3125 */       TRANSITION[127][112] = 128;
/* 3126 */       TRANSITION[127][80] = 128;
/* 3127 */       TRANSITION[128] = copy(arrayOfInt5);
/* 3128 */       TRANSITION[128][101] = 129;
/* 3129 */       TRANSITION[128][69] = 129;
/* 3130 */       TRANSITION[129] = arrayOfInt5;
/* 3131 */       TRANSITION[130] = copy(arrayOfInt5);
/* 3132 */       TRANSITION[130][110] = 131;
/* 3133 */       TRANSITION[130][78] = 131;
/* 3134 */       TRANSITION[131] = arrayOfInt5;
/* 3135 */       TRANSITION[132] = copy(arrayOfInt5);
/* 3136 */       TRANSITION[132][106] = 133;
/* 3137 */       TRANSITION[132][74] = 133;
/* 3138 */       TRANSITION[133] = arrayOfInt5;
/* 3139 */       TRANSITION[135] = copy(arrayOfInt2);
/* 3140 */       TRANSITION[135][76] = 136;
/* 3141 */       TRANSITION[135][108] = 136;
/* 3142 */       TRANSITION[136] = copy(arrayOfInt2);
/* 3143 */       TRANSITION[136][84] = 137;
/* 3144 */       TRANSITION[136][116] = 137;
/* 3145 */       TRANSITION[137] = copy(arrayOfInt2);
/* 3146 */       TRANSITION[137][69] = 138;
/* 3147 */       TRANSITION[137][101] = 138;
/* 3148 */       TRANSITION[138] = copy(arrayOfInt2);
/* 3149 */       TRANSITION[138][82] = 139;
/* 3150 */       TRANSITION[138][114] = 139;
/* 3151 */       TRANSITION[139] = copyReplacing(arrayOfInt4, 57, 140);
/* 3152 */       TRANSITION[139][47] = 148;
/* 3153 */       TRANSITION[139][45] = 151;
/*      */       
/* 3155 */       TRANSITION[140] = copyReplacing(arrayOfInt4, 57, 140);
/* 3156 */       TRANSITION[140][47] = 148;
/* 3157 */       TRANSITION[148] = copy(arrayOfInt5);
/* 3158 */       TRANSITION[148][42] = 149;
/* 3159 */       TRANSITION[149] = newArray(128, 149);
/* 3160 */       TRANSITION[149][42] = 150;
/* 3161 */       TRANSITION[150] = newArray(128, 149);
/* 3162 */       TRANSITION[150][47] = 140;
/*      */       
/* 3164 */       TRANSITION[140][45] = 151;
/* 3165 */       TRANSITION[151] = copy(arrayOfInt5);
/* 3166 */       TRANSITION[151][45] = 152;
/* 3167 */       TRANSITION[152] = newArray(128, 152);
/* 3168 */       TRANSITION[152][10] = 140;
/* 3169 */       TRANSITION[140][83] = 141;
/* 3170 */       TRANSITION[140][115] = 141;
/*      */       
/* 3172 */       TRANSITION[141] = copy(arrayOfInt2);
/* 3173 */       TRANSITION[141][69] = 142;
/* 3174 */       TRANSITION[141][101] = 142;
/* 3175 */       TRANSITION[142] = copy(arrayOfInt2);
/* 3176 */       TRANSITION[142][83] = 143;
/* 3177 */       TRANSITION[142][115] = 143;
/* 3178 */       TRANSITION[143] = copy(arrayOfInt2);
/* 3179 */       TRANSITION[143][83] = 144;
/* 3180 */       TRANSITION[143][115] = 144;
/* 3181 */       TRANSITION[144] = copy(arrayOfInt2);
/* 3182 */       TRANSITION[144][73] = 145;
/* 3183 */       TRANSITION[144][105] = 145;
/* 3184 */       TRANSITION[145] = copy(arrayOfInt2);
/* 3185 */       TRANSITION[145][79] = 146;
/* 3186 */       TRANSITION[145][111] = 146;
/* 3187 */       TRANSITION[146] = copy(arrayOfInt2);
/* 3188 */       TRANSITION[146][78] = 147;
/* 3189 */       TRANSITION[146][110] = 147;
/* 3190 */       TRANSITION[147] = arrayOfInt5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3197 */       int[] arrayOfInt7 = newArray(128, 0);
/*      */       
/* 3199 */       int[] arrayOfInt8 = copy(arrayOfInt7);
/* 3200 */       arrayOfInt8[63] = 14;
/*      */       
/* 3202 */       int[] arrayOfInt9 = copy(arrayOfInt8);
/* 3203 */       arrayOfInt9[123] = 5;
/*      */       
/* 3205 */       int[] arrayOfInt10 = new int[128];
/*      */       
/* 3207 */       for (byte b1 = 0; b1 < arrayOfInt10.length; b1++) {
/* 3208 */         if (TRANSITION[8][b1] == 8) {
/* 3209 */           arrayOfInt10[b1] = 15;
/*      */         } else {
/* 3211 */           arrayOfInt10[b1] = 16;
/*      */         } 
/* 3213 */       }  int[] arrayOfInt11 = new int[128];
/*      */       
/* 3215 */       for (byte b2 = 0; b2 < arrayOfInt11.length; b2++) {
/* 3216 */         if (TRANSITION[65][b2] == 65) {
/* 3217 */           arrayOfInt11[b2] = 15;
/*      */         } else {
/* 3219 */           arrayOfInt11[b2] = 16;
/*      */         } 
/* 3221 */       }  int[] arrayOfInt12 = copy(arrayOfInt11);
/* 3222 */       arrayOfInt12[32] = 0;
/* 3223 */       arrayOfInt12[10] = 0;
/* 3224 */       arrayOfInt12[9] = 0;
/* 3225 */       arrayOfInt12[13] = 0;
/*      */       
/* 3227 */       int[] arrayOfInt13 = copy(arrayOfInt7);
/*      */       
/* 3229 */       for (byte b3 = 0; b3 < arrayOfInt13.length; b3++) {
/* 3230 */         if (arrayOfInt4[b3] != 66)
/* 3231 */           arrayOfInt13[b3] = 5; 
/*      */       } 
/* 3233 */       int[] arrayOfInt14 = copyReplacing(arrayOfInt13, 5, 6);
/* 3234 */       int[] arrayOfInt15 = copyReplacing(arrayOfInt13, 5, 1);
/* 3235 */       int[] arrayOfInt16 = copyReplacing(arrayOfInt13, 5, 2);
/* 3236 */       int[] arrayOfInt17 = copyReplacing(arrayOfInt13, 5, 3);
/* 3237 */       int[] arrayOfInt18 = copyReplacing(arrayOfInt13, 5, 4);
/* 3238 */       int[] arrayOfInt19 = copyReplacing(arrayOfInt13, 5, 7);
/* 3239 */       int[] arrayOfInt20 = copyReplacing(arrayOfInt13, 5, 8);
/* 3240 */       arrayOfInt20[123] = 6;
/*      */       
/* 3242 */       int[] arrayOfInt21 = copyReplacing(arrayOfInt13, 5, 10);
/*      */       
/* 3244 */       for (byte b6 = 0; b6 < arrayOfInt21.length; b6++) {
/* 3245 */         if (arrayOfInt21[b6] == 8) {
/* 3246 */           arrayOfInt21[b6] = 0;
/*      */         }
/*      */       } 
/* 3249 */       int[] arrayOfInt22 = copyReplacing(arrayOfInt21, 10, 11);
/* 3250 */       int[] arrayOfInt23 = copyReplacing(arrayOfInt21, 10, 9);
/* 3251 */       int[] arrayOfInt24 = copyReplacing(arrayOfInt21, 10, 12);
/* 3252 */       int[] arrayOfInt25 = copyReplacing(arrayOfInt21, 10, 13);
/*      */       
/* 3254 */       int[] arrayOfInt26 = copyReplacing(arrayOfInt21, 10, 21);
/*      */ 
/*      */       
/* 3257 */       int[] arrayOfInt27 = copy(arrayOfInt7);
/* 3258 */       arrayOfInt27[39] = 17;
/*      */       
/* 3260 */       int[] arrayOfInt28 = copyReplacing(arrayOfInt7, 0, 18);
/* 3261 */       arrayOfInt28[39] = 0;
/*      */       
/* 3263 */       int[] arrayOfInt29 = copyReplacing(arrayOfInt7, 0, 19);
/*      */       
/* 3265 */       int[] arrayOfInt30 = copyReplacing(arrayOfInt7, 0, 20);
/*      */       
/* 3267 */       int[] arrayOfInt31 = copy(arrayOfInt30);
/* 3268 */       arrayOfInt31[39] = 0;
/*      */       
/* 3270 */       ACTION[0] = arrayOfInt9;
/* 3271 */       ACTION[1] = arrayOfInt9;
/* 3272 */       ACTION[2] = arrayOfInt9;
/* 3273 */       ACTION[3] = arrayOfInt7;
/* 3274 */       ACTION[4] = arrayOfInt7;
/* 3275 */       ACTION[5] = arrayOfInt7;
/* 3276 */       ACTION[6] = arrayOfInt7;
/* 3277 */       ACTION[7] = arrayOfInt7;
/* 3278 */       ACTION[8] = arrayOfInt10;
/* 3279 */       ACTION[134] = arrayOfInt12;
/* 3280 */       ACTION[100] = arrayOfInt27;
/* 3281 */       ACTION[101] = arrayOfInt28;
/* 3282 */       ACTION[105] = arrayOfInt7;
/* 3283 */       ACTION[106] = arrayOfInt29;
/* 3284 */       ACTION[107] = arrayOfInt30;
/* 3285 */       ACTION[108] = null;
/* 3286 */       ACTION[109] = arrayOfInt31;
/* 3287 */       ACTION[9] = arrayOfInt20;
/* 3288 */       ACTION[10] = arrayOfInt20;
/* 3289 */       ACTION[11] = arrayOfInt20;
/* 3290 */       ACTION[12] = arrayOfInt20;
/* 3291 */       ACTION[13] = arrayOfInt20;
/* 3292 */       ACTION[14] = arrayOfInt13;
/* 3293 */       ACTION[15] = arrayOfInt20;
/* 3294 */       ACTION[16] = arrayOfInt20;
/* 3295 */       ACTION[17] = arrayOfInt20;
/* 3296 */       ACTION[18] = arrayOfInt14;
/* 3297 */       ACTION[19] = arrayOfInt20;
/* 3298 */       ACTION[20] = arrayOfInt20;
/* 3299 */       ACTION[21] = arrayOfInt20;
/* 3300 */       ACTION[22] = arrayOfInt20;
/* 3301 */       ACTION[23] = arrayOfInt20;
/* 3302 */       ACTION[24] = arrayOfInt20;
/* 3303 */       ACTION[25] = arrayOfInt13;
/* 3304 */       ACTION[26] = arrayOfInt20;
/* 3305 */       ACTION[27] = arrayOfInt20;
/* 3306 */       ACTION[28] = arrayOfInt20;
/* 3307 */       ACTION[29] = arrayOfInt15;
/* 3308 */       ACTION[30] = arrayOfInt20;
/* 3309 */       ACTION[31] = arrayOfInt20;
/* 3310 */       ACTION[32] = arrayOfInt20;
/* 3311 */       ACTION[33] = arrayOfInt20;
/* 3312 */       ACTION[34] = arrayOfInt20;
/* 3313 */       ACTION[35] = arrayOfInt16;
/* 3314 */       ACTION[36] = arrayOfInt20;
/* 3315 */       ACTION[37] = arrayOfInt20;
/* 3316 */       ACTION[38] = arrayOfInt20;
/* 3317 */       ACTION[39] = arrayOfInt20;
/* 3318 */       ACTION[40] = arrayOfInt20;
/* 3319 */       ACTION[41] = arrayOfInt19;
/* 3320 */       ACTION[42] = arrayOfInt20;
/* 3321 */       ACTION[43] = arrayOfInt20;
/* 3322 */       ACTION[44] = arrayOfInt20;
/* 3323 */       ACTION[45] = arrayOfInt20;
/* 3324 */       ACTION[46] = arrayOfInt20;
/* 3325 */       ACTION[47] = arrayOfInt18;
/* 3326 */       ACTION[48] = arrayOfInt20;
/* 3327 */       ACTION[49] = arrayOfInt20;
/* 3328 */       ACTION[50] = arrayOfInt20;
/* 3329 */       ACTION[51] = arrayOfInt20;
/* 3330 */       ACTION[52] = arrayOfInt17;
/* 3331 */       ACTION[53] = arrayOfInt20;
/* 3332 */       ACTION[54] = arrayOfInt20;
/* 3333 */       ACTION[55] = arrayOfInt20;
/* 3334 */       ACTION[56] = arrayOfInt19;
/* 3335 */       ACTION[66] = arrayOfInt8;
/* 3336 */       ACTION[58] = arrayOfInt8;
/* 3337 */       ACTION[59] = arrayOfInt8;
/* 3338 */       ACTION[60] = arrayOfInt7;
/* 3339 */       ACTION[61] = arrayOfInt7;
/* 3340 */       ACTION[62] = arrayOfInt7;
/* 3341 */       ACTION[63] = arrayOfInt7;
/* 3342 */       ACTION[64] = arrayOfInt7;
/* 3343 */       ACTION[65] = arrayOfInt11;
/* 3344 */       ACTION[102] = arrayOfInt27;
/* 3345 */       ACTION[103] = arrayOfInt7;
/* 3346 */       ACTION[104] = arrayOfInt28;
/* 3347 */       ACTION[110] = arrayOfInt7;
/* 3348 */       ACTION[111] = arrayOfInt29;
/* 3349 */       ACTION[112] = arrayOfInt30;
/* 3350 */       ACTION[113] = null;
/* 3351 */       ACTION[114] = arrayOfInt31;
/*      */       
/* 3353 */       ACTION[57] = arrayOfInt8;
/*      */       
/* 3355 */       ACTION[67] = arrayOfInt7;
/* 3356 */       ACTION[68] = arrayOfInt7;
/* 3357 */       ACTION[69] = arrayOfInt7;
/* 3358 */       ACTION[70] = arrayOfInt7;
/* 3359 */       ACTION[71] = arrayOfInt23;
/*      */       
/* 3361 */       ACTION[72] = arrayOfInt7;
/* 3362 */       ACTION[73] = arrayOfInt7;
/* 3363 */       ACTION[74] = arrayOfInt7;
/* 3364 */       ACTION[75] = arrayOfInt7;
/* 3365 */       ACTION[76] = arrayOfInt21;
/*      */       
/* 3367 */       ACTION[77] = arrayOfInt7;
/* 3368 */       ACTION[78] = arrayOfInt7;
/* 3369 */       ACTION[79] = arrayOfInt22;
/*      */       
/* 3371 */       ACTION[80] = arrayOfInt7;
/* 3372 */       ACTION[81] = arrayOfInt7;
/* 3373 */       ACTION[82] = arrayOfInt7;
/* 3374 */       ACTION[83] = arrayOfInt7;
/* 3375 */       ACTION[84] = arrayOfInt7;
/*      */       
/* 3377 */       ACTION[85] = arrayOfInt7;
/* 3378 */       ACTION[86] = arrayOfInt7;
/* 3379 */       ACTION[87] = arrayOfInt24;
/*      */       
/* 3381 */       ACTION[88] = arrayOfInt8;
/* 3382 */       ACTION[89] = arrayOfInt7;
/* 3383 */       ACTION[90] = arrayOfInt7;
/* 3384 */       ACTION[91] = arrayOfInt7;
/* 3385 */       ACTION[92] = arrayOfInt7;
/* 3386 */       ACTION[93] = arrayOfInt7;
/* 3387 */       ACTION[94] = arrayOfInt25;
/*      */       
/* 3389 */       ACTION[95] = arrayOfInt7;
/* 3390 */       ACTION[96] = arrayOfInt7;
/* 3391 */       ACTION[97] = arrayOfInt7;
/* 3392 */       ACTION[98] = arrayOfInt7;
/* 3393 */       ACTION[99] = arrayOfInt7;
/*      */       
/* 3395 */       ACTION[115] = copy(arrayOfInt7);
/* 3396 */       ACTION[115][63] = 14;
/* 3397 */       ACTION[116] = arrayOfInt7;
/* 3398 */       ACTION[117] = arrayOfInt7;
/* 3399 */       ACTION[118] = arrayOfInt7;
/* 3400 */       ACTION[119] = arrayOfInt7;
/* 3401 */       ACTION[120] = arrayOfInt7;
/* 3402 */       ACTION[121] = arrayOfInt7;
/* 3403 */       ACTION[122] = arrayOfInt7;
/* 3404 */       ACTION[123] = arrayOfInt7;
/* 3405 */       ACTION[124] = arrayOfInt7;
/* 3406 */       ACTION[125] = arrayOfInt7;
/* 3407 */       ACTION[126] = arrayOfInt7;
/* 3408 */       ACTION[127] = arrayOfInt7;
/* 3409 */       ACTION[128] = arrayOfInt7;
/* 3410 */       ACTION[129] = arrayOfInt7;
/* 3411 */       ACTION[130] = arrayOfInt7;
/* 3412 */       ACTION[131] = arrayOfInt7;
/* 3413 */       ACTION[132] = arrayOfInt7;
/* 3414 */       ACTION[133] = arrayOfInt7;
/*      */       
/* 3416 */       ACTION[135] = arrayOfInt7;
/* 3417 */       ACTION[136] = arrayOfInt7;
/* 3418 */       ACTION[137] = arrayOfInt7;
/* 3419 */       ACTION[138] = arrayOfInt7;
/* 3420 */       ACTION[139] = arrayOfInt20;
/*      */       
/* 3422 */       ACTION[140] = arrayOfInt8;
/* 3423 */       ACTION[141] = arrayOfInt7;
/* 3424 */       ACTION[142] = arrayOfInt7;
/* 3425 */       ACTION[143] = arrayOfInt7;
/* 3426 */       ACTION[144] = arrayOfInt7;
/* 3427 */       ACTION[145] = arrayOfInt7;
/* 3428 */       ACTION[146] = arrayOfInt7;
/* 3429 */       ACTION[147] = arrayOfInt26;
/*      */       
/* 3431 */       ACTION[148] = arrayOfInt7;
/* 3432 */       ACTION[149] = arrayOfInt7;
/* 3433 */       ACTION[150] = arrayOfInt7;
/* 3434 */       ACTION[151] = arrayOfInt7;
/* 3435 */       ACTION[152] = arrayOfInt7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3443 */       ODBCAction[] arrayOfODBCAction1 = newArray(128, ODBCAction.NONE);
/*      */       
/* 3445 */       ODBCAction[] arrayOfODBCAction2 = newArray(128, ODBCAction.COPY);
/*      */       
/* 3447 */       ODBCAction[] arrayOfODBCAction3 = copy(arrayOfODBCAction2);
/* 3448 */       arrayOfODBCAction3[123] = ODBCAction.NONE;
/* 3449 */       arrayOfODBCAction3[63] = ODBCAction.QUESTION;
/* 3450 */       arrayOfODBCAction3[125] = ODBCAction.END_ODBC_ESCAPE;
/* 3451 */       arrayOfODBCAction3[44] = ODBCAction.COMMA;
/* 3452 */       arrayOfODBCAction3[40] = ODBCAction.OPEN_PAREN;
/* 3453 */       arrayOfODBCAction3[41] = ODBCAction.CLOSE_PAREN;
/*      */       
/* 3455 */       ODBCAction[] arrayOfODBCAction4 = copyReplacing(arrayOfODBCAction2, ODBCAction.COPY, ODBCAction.SAVE_DELIMITER);
/*      */       
/* 3457 */       ODBCAction[] arrayOfODBCAction5 = copyReplacing(arrayOfODBCAction2, ODBCAction.COPY, ODBCAction.LOOK_FOR_DELIMITER);
/*      */       
/* 3459 */       ODBCAction[] arrayOfODBCAction6 = copy(arrayOfODBCAction5);
/* 3460 */       arrayOfODBCAction6[39] = ODBCAction.COPY;
/*      */       
/* 3462 */       ODBCAction[] arrayOfODBCAction7 = newArray(128, ODBCAction.UNKNOWN_ESCAPE);
/*      */       
/* 3464 */       ODBCAction[] arrayOfODBCAction8 = copy(arrayOfODBCAction1);
/* 3465 */       for (byte b4 = 0; b4 < arrayOfInt1.length; b4++) {
/* 3466 */         if (arrayOfInt1[b4] == 9) arrayOfODBCAction7[b4] = ODBCAction.UNKNOWN_ESCAPE;
/*      */       
/*      */       } 
/* 3469 */       ODBCAction[] arrayOfODBCAction9 = copy(arrayOfODBCAction3);
/* 3470 */       for (byte b5 = 0; b5 < arrayOfInt1.length; b5++) {
/* 3471 */         if (arrayOfInt1[b5] != 9) arrayOfODBCAction9[b5] = ODBCAction.BEGIN;
/*      */       
/*      */       } 
/* 3474 */       ODBC_ACTION[0] = arrayOfODBCAction3;
/* 3475 */       ODBC_ACTION[1] = arrayOfODBCAction3;
/* 3476 */       ODBC_ACTION[2] = arrayOfODBCAction3;
/* 3477 */       ODBC_ACTION[3] = arrayOfODBCAction2;
/* 3478 */       ODBC_ACTION[4] = arrayOfODBCAction3;
/* 3479 */       ODBC_ACTION[5] = arrayOfODBCAction2;
/* 3480 */       ODBC_ACTION[6] = arrayOfODBCAction2;
/* 3481 */       ODBC_ACTION[7] = arrayOfODBCAction2;
/* 3482 */       ODBC_ACTION[8] = arrayOfODBCAction3;
/* 3483 */       ODBC_ACTION[134] = arrayOfODBCAction3;
/* 3484 */       ODBC_ACTION[100] = arrayOfODBCAction2;
/* 3485 */       ODBC_ACTION[101] = arrayOfODBCAction2;
/* 3486 */       ODBC_ACTION[105] = arrayOfODBCAction2;
/* 3487 */       ODBC_ACTION[106] = arrayOfODBCAction4;
/* 3488 */       ODBC_ACTION[107] = arrayOfODBCAction5;
/* 3489 */       ODBC_ACTION[108] = null;
/* 3490 */       ODBC_ACTION[109] = arrayOfODBCAction6;
/* 3491 */       ODBC_ACTION[9] = arrayOfODBCAction3;
/* 3492 */       ODBC_ACTION[10] = arrayOfODBCAction3;
/* 3493 */       ODBC_ACTION[11] = arrayOfODBCAction3;
/* 3494 */       ODBC_ACTION[12] = arrayOfODBCAction3;
/* 3495 */       ODBC_ACTION[13] = arrayOfODBCAction3;
/* 3496 */       ODBC_ACTION[14] = arrayOfODBCAction9;
/* 3497 */       ODBC_ACTION[15] = arrayOfODBCAction3;
/* 3498 */       ODBC_ACTION[16] = arrayOfODBCAction3;
/* 3499 */       ODBC_ACTION[17] = arrayOfODBCAction3;
/* 3500 */       ODBC_ACTION[18] = arrayOfODBCAction3;
/* 3501 */       ODBC_ACTION[19] = arrayOfODBCAction3;
/* 3502 */       ODBC_ACTION[20] = arrayOfODBCAction3;
/* 3503 */       ODBC_ACTION[21] = arrayOfODBCAction3;
/* 3504 */       ODBC_ACTION[22] = arrayOfODBCAction3;
/* 3505 */       ODBC_ACTION[23] = arrayOfODBCAction3;
/* 3506 */       ODBC_ACTION[24] = arrayOfODBCAction3;
/* 3507 */       ODBC_ACTION[25] = arrayOfODBCAction3;
/* 3508 */       ODBC_ACTION[26] = arrayOfODBCAction3;
/* 3509 */       ODBC_ACTION[27] = arrayOfODBCAction3;
/* 3510 */       ODBC_ACTION[28] = arrayOfODBCAction3;
/* 3511 */       ODBC_ACTION[29] = arrayOfODBCAction3;
/* 3512 */       ODBC_ACTION[30] = arrayOfODBCAction3;
/* 3513 */       ODBC_ACTION[31] = arrayOfODBCAction3;
/* 3514 */       ODBC_ACTION[32] = arrayOfODBCAction3;
/* 3515 */       ODBC_ACTION[33] = arrayOfODBCAction3;
/* 3516 */       ODBC_ACTION[34] = arrayOfODBCAction3;
/* 3517 */       ODBC_ACTION[35] = arrayOfODBCAction3;
/* 3518 */       ODBC_ACTION[36] = arrayOfODBCAction3;
/* 3519 */       ODBC_ACTION[37] = arrayOfODBCAction3;
/* 3520 */       ODBC_ACTION[38] = arrayOfODBCAction3;
/* 3521 */       ODBC_ACTION[39] = arrayOfODBCAction3;
/* 3522 */       ODBC_ACTION[40] = arrayOfODBCAction3;
/* 3523 */       ODBC_ACTION[41] = arrayOfODBCAction3;
/* 3524 */       ODBC_ACTION[42] = arrayOfODBCAction3;
/* 3525 */       ODBC_ACTION[43] = arrayOfODBCAction3;
/* 3526 */       ODBC_ACTION[44] = arrayOfODBCAction3;
/* 3527 */       ODBC_ACTION[45] = arrayOfODBCAction3;
/* 3528 */       ODBC_ACTION[46] = arrayOfODBCAction3;
/* 3529 */       ODBC_ACTION[47] = arrayOfODBCAction3;
/* 3530 */       ODBC_ACTION[48] = arrayOfODBCAction3;
/* 3531 */       ODBC_ACTION[49] = arrayOfODBCAction3;
/* 3532 */       ODBC_ACTION[50] = arrayOfODBCAction3;
/* 3533 */       ODBC_ACTION[51] = arrayOfODBCAction3;
/* 3534 */       ODBC_ACTION[52] = arrayOfODBCAction3;
/* 3535 */       ODBC_ACTION[53] = arrayOfODBCAction3;
/* 3536 */       ODBC_ACTION[54] = arrayOfODBCAction3;
/* 3537 */       ODBC_ACTION[55] = arrayOfODBCAction3;
/* 3538 */       ODBC_ACTION[56] = arrayOfODBCAction3;
/* 3539 */       ODBC_ACTION[66] = arrayOfODBCAction3;
/* 3540 */       ODBC_ACTION[58] = arrayOfODBCAction3;
/* 3541 */       ODBC_ACTION[59] = arrayOfODBCAction3;
/* 3542 */       ODBC_ACTION[60] = arrayOfODBCAction2;
/* 3543 */       ODBC_ACTION[61] = arrayOfODBCAction2;
/* 3544 */       ODBC_ACTION[62] = arrayOfODBCAction2;
/* 3545 */       ODBC_ACTION[63] = arrayOfODBCAction2;
/* 3546 */       ODBC_ACTION[64] = arrayOfODBCAction2;
/* 3547 */       ODBC_ACTION[65] = arrayOfODBCAction3;
/* 3548 */       ODBC_ACTION[102] = arrayOfODBCAction2;
/* 3549 */       ODBC_ACTION[103] = arrayOfODBCAction2;
/* 3550 */       ODBC_ACTION[104] = arrayOfODBCAction2;
/* 3551 */       ODBC_ACTION[110] = arrayOfODBCAction2;
/* 3552 */       ODBC_ACTION[111] = arrayOfODBCAction4;
/* 3553 */       ODBC_ACTION[112] = arrayOfODBCAction5;
/* 3554 */       ODBC_ACTION[113] = null;
/* 3555 */       ODBC_ACTION[114] = arrayOfODBCAction6;
/*      */       
/* 3557 */       ODBC_ACTION[57] = arrayOfODBCAction3;
/*      */       
/* 3559 */       ODBC_ACTION[67] = arrayOfODBCAction3;
/* 3560 */       ODBC_ACTION[68] = arrayOfODBCAction3;
/* 3561 */       ODBC_ACTION[69] = arrayOfODBCAction3;
/* 3562 */       ODBC_ACTION[70] = arrayOfODBCAction3;
/* 3563 */       ODBC_ACTION[71] = arrayOfODBCAction3;
/*      */       
/* 3565 */       ODBC_ACTION[72] = arrayOfODBCAction3;
/* 3566 */       ODBC_ACTION[73] = arrayOfODBCAction3;
/* 3567 */       ODBC_ACTION[74] = arrayOfODBCAction3;
/* 3568 */       ODBC_ACTION[75] = arrayOfODBCAction3;
/* 3569 */       ODBC_ACTION[76] = arrayOfODBCAction3;
/*      */       
/* 3571 */       ODBC_ACTION[77] = arrayOfODBCAction3;
/* 3572 */       ODBC_ACTION[78] = arrayOfODBCAction3;
/* 3573 */       ODBC_ACTION[79] = arrayOfODBCAction3;
/*      */       
/* 3575 */       ODBC_ACTION[80] = arrayOfODBCAction3;
/* 3576 */       ODBC_ACTION[81] = arrayOfODBCAction3;
/* 3577 */       ODBC_ACTION[82] = arrayOfODBCAction3;
/* 3578 */       ODBC_ACTION[83] = arrayOfODBCAction3;
/* 3579 */       ODBC_ACTION[84] = arrayOfODBCAction3;
/*      */       
/* 3581 */       ODBC_ACTION[85] = arrayOfODBCAction3;
/* 3582 */       ODBC_ACTION[86] = arrayOfODBCAction3;
/* 3583 */       ODBC_ACTION[87] = arrayOfODBCAction3;
/*      */       
/* 3585 */       ODBC_ACTION[88] = arrayOfODBCAction3;
/* 3586 */       ODBC_ACTION[89] = arrayOfODBCAction3;
/* 3587 */       ODBC_ACTION[90] = arrayOfODBCAction3;
/* 3588 */       ODBC_ACTION[91] = arrayOfODBCAction3;
/* 3589 */       ODBC_ACTION[92] = arrayOfODBCAction3;
/* 3590 */       ODBC_ACTION[93] = arrayOfODBCAction3;
/* 3591 */       ODBC_ACTION[94] = arrayOfODBCAction3;
/*      */       
/* 3593 */       ODBC_ACTION[95] = arrayOfODBCAction3;
/* 3594 */       ODBC_ACTION[96] = arrayOfODBCAction3;
/* 3595 */       ODBC_ACTION[97] = arrayOfODBCAction3;
/* 3596 */       ODBC_ACTION[98] = arrayOfODBCAction3;
/* 3597 */       ODBC_ACTION[99] = arrayOfODBCAction3;
/*      */       
/* 3599 */       ODBC_ACTION[115] = copy(arrayOfODBCAction8);
/* 3600 */       ODBC_ACTION[115][63] = ODBCAction.NONE;
/* 3601 */       ODBC_ACTION[115][99] = ODBCAction.NONE;
/* 3602 */       ODBC_ACTION[115][67] = ODBCAction.NONE;
/* 3603 */       ODBC_ACTION[115][116] = ODBCAction.NONE;
/* 3604 */       ODBC_ACTION[115][84] = ODBCAction.NONE;
/* 3605 */       ODBC_ACTION[115][100] = ODBCAction.NONE;
/* 3606 */       ODBC_ACTION[115][68] = ODBCAction.NONE;
/* 3607 */       ODBC_ACTION[115][101] = ODBCAction.NONE;
/* 3608 */       ODBC_ACTION[115][69] = ODBCAction.NONE;
/* 3609 */       ODBC_ACTION[115][102] = ODBCAction.NONE;
/* 3610 */       ODBC_ACTION[115][70] = ODBCAction.NONE;
/* 3611 */       ODBC_ACTION[115][111] = ODBCAction.NONE;
/* 3612 */       ODBC_ACTION[115][79] = ODBCAction.NONE;
/* 3613 */       ODBC_ACTION[116] = newArray(128, ODBCAction.FUNCTION);
/* 3614 */       ODBC_ACTION[117] = copy(arrayOfODBCAction7);
/* 3615 */       ODBC_ACTION[117][97] = ODBCAction.NONE;
/* 3616 */       ODBC_ACTION[117][65] = ODBCAction.NONE;
/* 3617 */       ODBC_ACTION[118] = copy(arrayOfODBCAction7);
/* 3618 */       ODBC_ACTION[118][108] = ODBCAction.NONE;
/* 3619 */       ODBC_ACTION[118][76] = ODBCAction.NONE;
/* 3620 */       ODBC_ACTION[119] = copy(arrayOfODBCAction7);
/* 3621 */       ODBC_ACTION[119][108] = ODBCAction.NONE;
/* 3622 */       ODBC_ACTION[119][76] = ODBCAction.NONE;
/* 3623 */       ODBC_ACTION[120] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.CALL);
/* 3624 */       ODBC_ACTION[121] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.TIME);
/* 3625 */       ODBC_ACTION[121][115] = ODBCAction.NONE;
/* 3626 */       ODBC_ACTION[121][83] = ODBCAction.NONE;
/* 3627 */       ODBC_ACTION[122] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.TIMESTAMP);
/* 3628 */       ODBC_ACTION[123] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.DATE);
/* 3629 */       ODBC_ACTION[124] = copy(arrayOfODBCAction7);
/* 3630 */       ODBC_ACTION[124][115] = ODBCAction.NONE;
/* 3631 */       ODBC_ACTION[124][83] = ODBCAction.NONE;
/* 3632 */       ODBC_ACTION[125] = copy(arrayOfODBCAction7);
/* 3633 */       ODBC_ACTION[125][99] = ODBCAction.NONE;
/* 3634 */       ODBC_ACTION[125][67] = ODBCAction.NONE;
/* 3635 */       ODBC_ACTION[126] = copy(arrayOfODBCAction7);
/* 3636 */       ODBC_ACTION[126][97] = ODBCAction.NONE;
/* 3637 */       ODBC_ACTION[126][65] = ODBCAction.NONE;
/* 3638 */       ODBC_ACTION[127] = copy(arrayOfODBCAction7);
/* 3639 */       ODBC_ACTION[127][112] = ODBCAction.NONE;
/* 3640 */       ODBC_ACTION[127][80] = ODBCAction.NONE;
/* 3641 */       ODBC_ACTION[128] = copy(arrayOfODBCAction7);
/* 3642 */       ODBC_ACTION[128][101] = ODBCAction.NONE;
/* 3643 */       ODBC_ACTION[128][69] = ODBCAction.NONE;
/* 3644 */       ODBC_ACTION[129] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.ESCAPE);
/* 3645 */       ODBC_ACTION[130] = copy(arrayOfODBCAction7);
/* 3646 */       ODBC_ACTION[130][110] = ODBCAction.NONE;
/* 3647 */       ODBC_ACTION[130][78] = ODBCAction.NONE;
/* 3648 */       ODBC_ACTION[131] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.SCALAR_FUNCTION);
/* 3649 */       ODBC_ACTION[132] = copy(arrayOfODBCAction7);
/* 3650 */       ODBC_ACTION[132][106] = ODBCAction.NONE;
/* 3651 */       ODBC_ACTION[132][74] = ODBCAction.NONE;
/* 3652 */       ODBC_ACTION[133] = copyReplacing(arrayOfODBCAction8, ODBCAction.NONE, ODBCAction.OUTER_JOIN);
/*      */       
/* 3654 */       ODBC_ACTION[135] = arrayOfODBCAction3;
/* 3655 */       ODBC_ACTION[136] = arrayOfODBCAction3;
/* 3656 */       ODBC_ACTION[137] = arrayOfODBCAction3;
/* 3657 */       ODBC_ACTION[138] = arrayOfODBCAction3;
/* 3658 */       ODBC_ACTION[139] = arrayOfODBCAction3;
/*      */       
/* 3660 */       ODBC_ACTION[140] = arrayOfODBCAction3;
/* 3661 */       ODBC_ACTION[141] = arrayOfODBCAction3;
/* 3662 */       ODBC_ACTION[142] = arrayOfODBCAction3;
/* 3663 */       ODBC_ACTION[143] = arrayOfODBCAction3;
/* 3664 */       ODBC_ACTION[144] = arrayOfODBCAction3;
/* 3665 */       ODBC_ACTION[145] = arrayOfODBCAction3;
/* 3666 */       ODBC_ACTION[146] = arrayOfODBCAction3;
/* 3667 */       ODBC_ACTION[147] = arrayOfODBCAction3;
/*      */       
/* 3669 */       ODBC_ACTION[148] = arrayOfODBCAction3;
/* 3670 */       ODBC_ACTION[149] = arrayOfODBCAction3;
/* 3671 */       ODBC_ACTION[150] = arrayOfODBCAction3;
/* 3672 */       ODBC_ACTION[151] = arrayOfODBCAction3;
/* 3673 */       ODBC_ACTION[152] = arrayOfODBCAction3;
/*      */     } catch (Throwable throwable) {
/* 3675 */       throwable.printStackTrace();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleSqlReadOnly.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */