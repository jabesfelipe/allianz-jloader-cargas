/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.BFILE;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleBlobInputStream
/*     */   extends OracleBufferedStream
/*     */ {
/*     */   long lobOffset;
/*     */   Datum lob;
/*     */   long markedByte;
/*     */   boolean endOfStream = false;
/*  34 */   long maxPosition = Long.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobInputStream(BLOB paramBLOB) throws SQLException {
/*  43 */     this(paramBLOB, ((PhysicalConnection)paramBLOB.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/*  59 */     this(paramBLOB, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/*  75 */     super(paramInt);
/*     */ 
/*     */     
/*  78 */     if (paramBLOB == null || paramInt <= 0 || paramLong < 1L)
/*     */     {
/*  80 */       throw new IllegalArgumentException("Illegal Arguments");
/*     */     }
/*     */     
/*  83 */     this.lob = (Datum)paramBLOB;
/*  84 */     this.markedByte = -1L;
/*  85 */     this.lobOffset = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 100 */     this(paramBLOB, paramInt, paramLong1);
/* 101 */     this.maxPosition = paramLong1 + paramLong2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobInputStream(BFILE paramBFILE) throws SQLException {
/* 111 */     this(paramBFILE, ((PhysicalConnection)paramBFILE.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobInputStream(BFILE paramBFILE, int paramInt) throws SQLException {
/* 126 */     this(paramBFILE, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException {
/* 141 */     super(paramInt);
/*     */ 
/*     */     
/* 144 */     if (paramBFILE == null || paramInt <= 0 || paramLong < 1L)
/*     */     {
/* 146 */       throw new IllegalArgumentException("Illegal Arguments");
/*     */     }
/*     */     
/* 149 */     this.lob = (Datum)paramBFILE;
/* 150 */     this.markedByte = -1L;
/* 151 */     this.lobOffset = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytes(int paramInt) throws IOException {
/* 162 */     ensureOpen();
/*     */     
/* 164 */     if (this.pos >= this.count) {
/*     */       
/* 166 */       if (!this.endOfStream) {
/*     */         
/* 168 */         if (paramInt > this.currentBufferSize) {
/*     */           
/* 170 */           this.currentBufferSize = Math.max(paramInt, this.initialBufferSize);
/* 171 */           this.resizableBuffer = new byte[this.currentBufferSize];
/*     */         } 
/*     */         
/*     */         try {
/*     */           int i;
/* 176 */           if (this.currentBufferSize < this.maxPosition - this.lobOffset) { i = this.currentBufferSize; }
/* 177 */           else { i = (int)(this.maxPosition - this.lobOffset); }
/*     */ 
/*     */           
/* 180 */           if (this.lob instanceof BLOB) {
/* 181 */             this.count = ((BLOB)this.lob).getBytes(this.lobOffset, i, this.resizableBuffer);
/*     */           } else {
/* 183 */             this.count = ((BFILE)this.lob).getBytes(this.lobOffset, i, this.resizableBuffer);
/*     */           } 
/*     */           
/* 186 */           if (this.count < this.currentBufferSize) {
/* 187 */             this.endOfStream = true;
/*     */           }
/* 189 */           if (this.count > 0)
/*     */           {
/*     */ 
/*     */             
/* 193 */             this.pos = 0;
/* 194 */             this.lobOffset += this.count;
/* 195 */             if (this.lobOffset > this.maxPosition) this.endOfStream = true;
/*     */             
/* 197 */             return true;
/*     */           }
/*     */         
/* 200 */         } catch (SQLException sQLException) {
/*     */ 
/*     */           
/* 203 */           IOException iOException = DatabaseError.createIOException(sQLException);
/* 204 */           iOException.fillInStackTrace();
/* 205 */           throw iOException;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 210 */       return false;
/*     */     } 
/*     */     
/* 213 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureOpen() throws IOException {
/*     */     try {
/* 228 */       if (this.closed)
/*     */       {
/* 230 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 231 */         sQLException.fillInStackTrace();
/* 232 */         throw sQLException;
/*     */       }
/*     */     
/* 235 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 238 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 239 */       iOException.fillInStackTrace();
/* 240 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 256 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int paramInt) {
/* 274 */     if (paramInt < 0) {
/* 275 */       throw new IllegalArgumentException("Read-ahead limit < 0");
/*     */     }
/* 277 */     this.markedByte = this.lobOffset - this.count + this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markInternal(int paramInt) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 295 */     ensureOpen();
/*     */     
/* 297 */     if (this.markedByte < 0L) {
/* 298 */       throw new IOException("Mark invalid or stream not marked.");
/*     */     }
/* 300 */     this.lobOffset = this.markedByte;
/* 301 */     this.pos = this.count;
/* 302 */     this.endOfStream = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long paramLong) throws IOException {
/* 321 */     ensureOpen();
/*     */     
/* 323 */     long l = 0L;
/*     */     
/* 325 */     if ((this.count - this.pos) >= paramLong) {
/*     */       
/* 327 */       this.pos = (int)(this.pos + paramLong);
/* 328 */       l += paramLong;
/*     */     }
/*     */     else {
/*     */       
/* 332 */       l += (this.count - this.pos);
/* 333 */       this.pos = this.count;
/*     */ 
/*     */       
/*     */       try {
/* 337 */         long l1 = 0L;
/*     */         
/* 339 */         if (this.lob instanceof BLOB) {
/* 340 */           l1 = ((BLOB)this.lob).length() - this.lobOffset + 1L;
/*     */         } else {
/* 342 */           l1 = ((BFILE)this.lob).length() - this.lobOffset + 1L;
/*     */         } 
/* 344 */         if (l1 >= paramLong - l)
/*     */         {
/* 346 */           this.lobOffset += paramLong - l;
/* 347 */           l += paramLong - l;
/*     */         }
/*     */         else
/*     */         {
/* 351 */           this.lobOffset += l1;
/* 352 */           l += l1;
/*     */         }
/*     */       
/* 355 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 358 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 359 */         iOException.fillInStackTrace();
/* 360 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 365 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 381 */     OracleConnection oracleConnection = null;
/*     */     
/* 383 */     if (this.lob != null) {
/*     */       
/*     */       try {
/*     */         
/* 387 */         if (this.lob instanceof BLOB) {
/* 388 */           oracleConnection = ((BLOB)this.lob).getInternalConnection();
/*     */         } else {
/* 390 */           oracleConnection = ((BFILE)this.lob).getInternalConnection();
/*     */         } 
/* 392 */       } catch (Exception exception) {
/*     */         
/* 394 */         oracleConnection = null;
/*     */       } 
/*     */     }
/*     */     
/* 398 */     return oracleConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 403 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleBlobInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */