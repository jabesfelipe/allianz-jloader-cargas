/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.util.LinkedList;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class T4CTTIfun
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   static final short OOPEN = 2;
/*     */   static final short OEXEC = 4;
/*     */   static final short OFETCH = 5;
/*     */   static final short OCLOSE = 8;
/*     */   static final short OLOGOFF = 9;
/*     */   static final short OCOMON = 12;
/*     */   static final short OCOMOFF = 13;
/*     */   static final short OCOMMIT = 14;
/*     */   static final short OROLLBACK = 15;
/*     */   static final short OCANCEL = 20;
/*     */   static final short ODSCRARR = 43;
/*     */   static final short OVERSION = 59;
/*     */   static final short OK2RPC = 67;
/*     */   static final short OALL7 = 71;
/*     */   static final short OSQL7 = 74;
/*     */   static final short O3LOGON = 81;
/*     */   static final short O3LOGA = 82;
/*     */   static final short OKOD = 92;
/*     */   static final short OALL8 = 94;
/*     */   static final short OLOBOPS = 96;
/*     */   static final short ODNY = 98;
/*     */   static final short OTXSE = 103;
/*     */   static final short OTXEN = 104;
/*     */   static final short OCCA = 105;
/*     */   static final short O80SES = 107;
/*     */   static final short OAUTH = 115;
/*     */   static final short OSESSKEY = 118;
/*     */   static final short OCANA = 120;
/*     */   static final short OKPN = 125;
/*     */   static final short OOTCM = 127;
/*     */   static final short OSCID = 135;
/*     */   static final short OSPFPPUT = 138;
/*     */   static final short OKPFC = 139;
/*     */   static final short OPING = 147;
/*     */   static final short OKEYVAL = 154;
/*     */   static final short OXSSCS = 155;
/*     */   static final short OXSSRO = 156;
/*     */   static final short OXSSPO = 157;
/*     */   static final short OAQEQ = 121;
/*     */   static final short OAQDQ = 122;
/*     */   static final short OAQGPS = 132;
/*     */   static final short OAQLS = 126;
/*     */   static final short OAQXQ = 145;
/*     */   static final short OXSNS = 172;
/*     */   private short funCode;
/* 121 */   private final byte seqNumber = 0; protected final T4CTTIoer oer; int receiveState; static final int IDLE_RECEIVE_STATE = 0; static final int ACTIVE_RECEIVE_STATE = 1;
/*     */   static final int READROW_RECEIVE_STATE = 2;
/*     */   static final int STREAM_RECEIVE_STATE = 3;
/*     */   boolean rpaProcessed;
/*     */   boolean rxhProcessed;
/*     */   boolean iovProcessed;
/*     */   private LinkedList<Short> ttilist;
/*     */   
/* 129 */   T4CTTIfun(T4CConnection paramT4CConnection, byte paramByte) { super(paramT4CConnection, paramByte);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     this.receiveState = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 238 */     this.rpaProcessed = false;
/* 239 */     this.rxhProcessed = false;
/* 240 */     this.iovProcessed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     this.ttilist = new LinkedList<Short>();
/*     */     this.oer = paramT4CConnection.getT4CTTIoer(); }
/*     */    final void setFunCode(short paramShort) {
/*     */     this.funCode = paramShort;
/*     */   } final short getFunCode() {
/*     */     return this.funCode;
/*     */   } private final void marshalFunHeader() throws IOException {
/*     */     marshalTTCcode();
/*     */     this.meg.marshalUB1(this.funCode);
/*     */     this.meg.marshalUB1((short)0);
/*     */   }
/*     */   abstract void marshal() throws IOException;
/* 281 */   private void receive() throws SQLException, IOException { this.receiveState = 1;
/*     */     
/* 283 */     SQLException sQLException = null;
/*     */     while (true) {
/*     */       
/*     */       try { byte b1;
/*     */         int i;
/*     */         byte b2;
/*     */         SQLException sQLException1;
/* 290 */         short s = this.meg.unmarshalUB1();
/* 291 */         this.ttilist.add(new Short(s));
/*     */         
/* 293 */         switch (s)
/*     */         
/*     */         { 
/*     */           
/*     */           case 8:
/* 298 */             if (this.rpaProcessed) {
/*     */               
/* 300 */               SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 301 */               sQLException2.fillInStackTrace();
/* 302 */               throw sQLException2;
/*     */             } 
/* 304 */             readRPA();
/*     */             
/*     */             try {
/* 307 */               processRPA();
/*     */             }
/* 309 */             catch (SQLException sQLException2) {
/*     */ 
/*     */ 
/*     */               
/* 313 */               sQLException = sQLException2;
/*     */             } 
/* 315 */             this.rpaProcessed = true;
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 21:
/* 321 */             readBVC();
/*     */             break;
/*     */           
/*     */           case 11:
/* 325 */             readIOV();
/* 326 */             this.iovProcessed = true;
/*     */             break;
/*     */ 
/*     */           
/*     */           case 6:
/* 331 */             readRXH();
/* 332 */             this.rxhProcessed = true;
/*     */             break;
/*     */ 
/*     */           
/*     */           case 7:
/* 337 */             this.receiveState = 2;
/*     */ 
/*     */             
/* 340 */             if (readRXD()) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 345 */               this.receiveState = 3;
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */ 
/*     */             
/* 352 */             this.receiveState = 1;
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 16:
/* 358 */             readDCB();
/*     */             break;
/*     */           case 14:
/* 361 */             readLOBD();
/*     */             break;
/*     */ 
/*     */           
/*     */           case 23:
/* 366 */             b1 = (byte)this.meg.unmarshalUB1();
/* 367 */             i = this.meg.unmarshalUB2();
/* 368 */             b2 = (byte)this.meg.unmarshalUB1();
/*     */             
/* 370 */             if (b1 == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 382 */               for (byte b = 0; b < i; b++) {
/*     */                 
/* 384 */                 T4CTTIidc t4CTTIidc = new T4CTTIidc(this.connection);
/* 385 */                 t4CTTIidc.unmarshal();
/*     */               }  break;
/*     */             } 
/* 388 */             if (b1 == 2) {
/*     */ 
/*     */               
/* 391 */               for (byte b = 0; b < i; b++)
/*     */               {
/* 393 */                 short s1 = this.meg.unmarshalUB1(); } 
/*     */               break;
/*     */             } 
/* 396 */             if (b1 == 3)
/*     */               break; 
/* 398 */             if (b1 == 4)
/*     */               break; 
/* 400 */             if (b1 == 5) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 407 */               T4CTTIkvarr t4CTTIkvarr = new T4CTTIkvarr(this.connection);
/* 408 */               t4CTTIkvarr.unmarshal(); break;
/* 409 */             }  if (b1 == 6)
/*     */             {
/* 411 */               for (byte b = 0; b < i; b++) {
/*     */                 
/* 413 */                 NTFXSEvent nTFXSEvent = new NTFXSEvent(this.connection);
/* 414 */                 this.connection.notify(nTFXSEvent);
/*     */               } 
/*     */             }
/*     */             break;
/*     */           case 19:
/* 419 */             this.meg.marshalUB1((short)19);
/*     */             break;
/*     */ 
/*     */           
/*     */           case 15:
/* 424 */             this.oer.init();
/* 425 */             this.oer.unmarshalWarning();
/*     */ 
/*     */             
/*     */             try {
/* 429 */               this.oer.processWarning();
/*     */             }
/* 431 */             catch (SQLWarning sQLWarning) {
/*     */               
/* 433 */               this.connection.setWarnings(DatabaseError.addSqlWarning(this.connection.getWarnings(), sQLWarning));
/*     */             } 
/*     */             break;
/*     */           case 9:
/* 437 */             processEOCS();
/* 438 */             if (this.connection.getTTCVersion() >= 3) {
/*     */               
/* 440 */               short s1 = (short)this.meg.unmarshalUB2();
/* 441 */               this.connection.endToEndECIDSequenceNumber = s1;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 473 */             this.connection.sentCancel = false; break;case 4: processEOCS(); this.oer.init(); this.oer.unmarshal(); try { processError(); } catch (SQLException sQLException2) { sQLException = sQLException2; }  this.connection.sentCancel = false; break;default: sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401, this.ttilist.toString()); sQLException1.fillInStackTrace(); throw sQLException1; }  } catch (BreakNetException breakNetException) {  } finally { this.connection.sentCancel = false; }
/*     */     
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 479 */     this.receiveState = 0;
/*     */     
/* 481 */     if (sQLException != null)
/* 482 */       throw sQLException;  }
/*     */   final void doRPC() throws IOException, SQLException { if (getTTCCode() == 17) {
/*     */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401); sQLException.fillInStackTrace(); throw sQLException;
/*     */     }  init();
/*     */     marshalFunHeader();
/*     */     try {
/*     */       this.connection.pipeState = 1;
/*     */       marshal();
/*     */       this.connection.pipeState = 2;
/*     */       receive();
/*     */     } finally {
/*     */       this.connection.pipeState = -1;
/* 494 */     }  } private final void processEOCS() throws SQLException, IOException { if (this.connection.hasServerCompileTimeCapability(15, 1)) {
/*     */       
/* 496 */       int i = (int)this.meg.unmarshalUB4();
/* 497 */       this.connection.eocs = i;
/* 498 */       if ((i & 0x8) != 0)
/*     */       {
/*     */ 
/*     */         
/* 502 */         long l = this.meg.unmarshalSB8();
/*     */       }
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   final void doPigRPC() throws IOException {
/*     */     init();
/*     */     marshalFunHeader();
/*     */     marshal();
/*     */   }
/*     */ 
/*     */   
/*     */   private void init() {
/*     */     this.rpaProcessed = false;
/*     */     this.rxhProcessed = false;
/*     */     this.iovProcessed = false;
/*     */     this.ttilist.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   void resumeReceive() throws SQLException, IOException {
/*     */     receive();
/*     */   }
/*     */ 
/*     */   
/*     */   void processRPA() throws SQLException {}
/*     */ 
/*     */   
/*     */   void readRPA() throws IOException, SQLException {}
/*     */   
/*     */   void readBVC() throws IOException, SQLException {
/* 534 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 535 */     sQLException.fillInStackTrace();
/* 536 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readLOBD() throws IOException, SQLException {
/* 545 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 546 */     sQLException.fillInStackTrace();
/* 547 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readIOV() throws IOException, SQLException {
/* 556 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 557 */     sQLException.fillInStackTrace();
/* 558 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRXH() throws IOException, SQLException {
/* 567 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 568 */     sQLException.fillInStackTrace();
/* 569 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readRXD() throws IOException, SQLException {
/* 578 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 579 */     sQLException.fillInStackTrace();
/* 580 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readDCB() throws IOException, SQLException {
/* 589 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 590 */     sQLException.fillInStackTrace();
/* 591 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processError() throws SQLException {
/* 600 */     this.oer.processError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getErrorCode() throws SQLException {
/* 607 */     return this.oer.retCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 622 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 627 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CTTIfun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */