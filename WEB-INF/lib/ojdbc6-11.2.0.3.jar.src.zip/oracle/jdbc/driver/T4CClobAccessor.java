/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.ListIterator;
/*     */ import oracle.sql.CLOB;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CClobAccessor
/*     */   extends ClobAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*  28 */   short[] prefetchedClobCharset = null;
/*     */ 
/*     */   
/*  31 */   boolean[] prefetchedClobDBVary = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int[] meta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayList<LinkedList<CLOB>> registeredCLOBs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CClobAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException
/*     */   {
/*  54 */     super(paramOracleStatement, 4000, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.meta = new int[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 581 */     this.registeredCLOBs = new ArrayList<LinkedList<CLOB>>(10); this.mare = paramT4CMAREngine; } void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) { this.mare.unmarshalUB2(); this.mare.unmarshalUB2(); } else if (this.statement.connection.versionNumber < 9200) { this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall()) this.mare.unmarshalSB2();  } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) { this.mare.processIndicator((paramInt <= 0), paramInt); }  } boolean unmarshalOneRow() throws SQLException, IOException { if (this.isUseLess) { this.lastRowProcessed++; return false; }  if (this.rowSpaceIndicator == null) { int n = (int)this.mare.unmarshalUB4(); if (n == 0) { this.meta[0] = -1; processIndicator(0); this.lastRowProcessed++; return false; }  byte[] arrayOfByte = new byte[16000]; this.mare.unmarshalCLR(arrayOfByte, 0, this.meta); processIndicator(this.meta[0]); this.lastRowProcessed++; return false; }  int i = this.columnIndex + this.lastRowProcessed * this.byteLength; int j = this.indicatorIndex + this.lastRowProcessed; int k = this.lengthIndex + this.lastRowProcessed; if (this.isNullByDescribe) { this.rowSpaceIndicator[j] = -1; this.rowSpaceIndicator[k] = 0; this.lastRowProcessed++; if (this.statement.connection.versionNumber < 9200) processIndicator(0);  return false; }  int m = (int)this.mare.unmarshalUB4(); if (m == 0) { this.meta[0] = -1; processIndicator(0); this.rowSpaceIndicator[j] = -1; this.rowSpaceIndicator[k] = 0; this.lastRowProcessed++; return false; }  if (this.lobPrefetchSizeForThisColumn != -1) handlePrefetch();  this.mare.unmarshalCLR(this.rowSpaceByte, i, this.meta, this.byteLength); processIndicator(this.meta[0]); if (this.meta[0] == 0) { this.rowSpaceIndicator[j] = -1; this.rowSpaceIndicator[k] = 0; } else { this.rowSpaceIndicator[k] = (short)this.meta[0]; this.rowSpaceIndicator[j] = 0; }  this.lastRowProcessed++; return false; } void copyRow() throws SQLException, IOException { int i; if (this.lastRowProcessed == 0) { i = this.statement.rowPrefetchInLastFetch - 1; } else { i = this.lastRowProcessed - 1; }  int j = this.columnIndex + this.lastRowProcessed * this.byteLength; int k = this.columnIndex + i * this.byteLength; int m = this.indicatorIndex + this.lastRowProcessed; int n = this.indicatorIndex + i; int i1 = this.lengthIndex + this.lastRowProcessed; int i2 = this.lengthIndex + i; short s = this.rowSpaceIndicator[i2]; int i3 = this.metaDataIndex + this.lastRowProcessed * 1; int i4 = this.metaDataIndex + i * 1; this.rowSpaceIndicator[i1] = (short)s; this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n]; if (!this.isNullByDescribe) System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);  System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1); this.lastRowProcessed++; } T4CClobAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, 4000, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1]; this.registeredCLOBs = new ArrayList<LinkedList<CLOB>>(10); this.mare = paramT4CMAREngine; this.definedColumnType = paramInt7; this.definedColumnSize = paramInt8; }
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException { int i = this.columnIndex + (paramInt2 - 1) * this.byteLength; int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength; int k = this.indicatorIndex + paramInt2 - 1; int m = this.indicatorIndexLastRow + paramInt1 - 1; int n = this.lengthIndex + paramInt2 - 1; int i1 = this.lengthIndexLastRow + paramInt1 - 1; short s = paramArrayOfshort[i1]; this.rowSpaceIndicator[n] = (short)s; this.rowSpaceIndicator[k] = paramArrayOfshort[m]; if (s != 0)
/*     */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);  }
/*     */   byte[][] checkAndAllocateLobPrefetchMemory(byte[][] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) { byte[][] arrayOfByte = paramArrayOfbyte; if (arrayOfByte == null) { arrayOfByte = new byte[Math.max(paramInt1, paramInt2 + 1)][]; arrayOfByte[paramInt2] = new byte[paramInt3]; } else { if (arrayOfByte.length < paramInt2 + 1) { byte[][] arrayOfByte1 = new byte[(paramInt2 + 1) * 2][]; System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, arrayOfByte.length); arrayOfByte = arrayOfByte1; }  if (arrayOfByte[paramInt2] == null || (arrayOfByte[paramInt2]).length < paramInt3)
/*     */         arrayOfByte[paramInt2] = new byte[paramInt3];  }  return arrayOfByte; }
/*     */   char[][] checkAndAllocateLobPrefetchMemory(char[][] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3) { char[][] arrayOfChar = paramArrayOfchar; if (arrayOfChar == null) { arrayOfChar = new char[Math.max(paramInt1, paramInt2 + 1)][]; arrayOfChar[paramInt2] = new char[paramInt3]; }
/*     */     else { if (arrayOfChar.length < paramInt2 + 1) { char[][] arrayOfChar1 = new char[(paramInt2 + 1) * 2][]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, arrayOfChar.length); arrayOfChar = arrayOfChar1; }
/*     */        if (arrayOfChar[paramInt2] == null || (arrayOfChar[paramInt2]).length < paramInt3)
/*     */         arrayOfChar[paramInt2] = new char[paramInt3];  }
/* 590 */      return arrayOfChar; } private void saveCLOBReference(int paramInt, CLOB paramCLOB) { LinkedList<CLOB> linkedList = null;
/* 591 */     if (this.registeredCLOBs.size() > paramInt) {
/*     */       
/* 593 */       linkedList = this.registeredCLOBs.get(paramInt);
/*     */     }
/*     */     else {
/*     */       
/* 597 */       linkedList = new LinkedList();
/* 598 */       while (this.registeredCLOBs.size() < paramInt)
/* 599 */         this.registeredCLOBs.add(new LinkedList<CLOB>()); 
/* 600 */       this.registeredCLOBs.add(paramInt, linkedList);
/*     */     } 
/*     */     
/* 603 */     if (linkedList == null) linkedList = new LinkedList<CLOB>(); 
/* 604 */     linkedList.add(paramCLOB); } long[] checkAndAllocateLobPrefetchMemory(long[] paramArrayOflong, int paramInt1, int paramInt2) { long[] arrayOfLong = paramArrayOflong; if (arrayOfLong == null) { arrayOfLong = new long[Math.max(paramInt1, paramInt2 + 1)]; } else if (arrayOfLong.length < paramInt2 + 1) { long[] arrayOfLong1 = new long[(paramInt2 + 1) * 2]; System.arraycopy(arrayOfLong, 0, arrayOfLong1, 0, arrayOfLong.length); arrayOfLong = arrayOfLong1; }  return arrayOfLong; }
/*     */   int[] checkAndAllocateLobPrefetchMemory(int[] paramArrayOfint, int paramInt1, int paramInt2) { int[] arrayOfInt = paramArrayOfint; if (arrayOfInt == null) { arrayOfInt = new int[Math.max(paramInt1, paramInt2 + 1)]; } else if (arrayOfInt.length < paramInt2 + 1) { int[] arrayOfInt1 = new int[(paramInt2 + 1) * 2]; System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length); arrayOfInt = arrayOfInt1; }  return arrayOfInt; }
/*     */   short[] checkAndAllocateLobPrefetchMemory(short[] paramArrayOfshort, int paramInt1, int paramInt2) { short[] arrayOfShort = paramArrayOfshort; if (arrayOfShort == null) { arrayOfShort = new short[Math.max(paramInt1, paramInt2 + 1)]; } else if (arrayOfShort.length < paramInt2 + 1) { short[] arrayOfShort1 = new short[(paramInt2 + 1) * 2]; System.arraycopy(arrayOfShort, 0, arrayOfShort1, 0, arrayOfShort.length); arrayOfShort = arrayOfShort1; }  return arrayOfShort; }
/*     */   byte[] checkAndAllocateLobPrefetchMemory(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) { byte[] arrayOfByte = paramArrayOfbyte; if (arrayOfByte == null) { arrayOfByte = new byte[Math.max(paramInt1, paramInt2 + 1)]; } else if (arrayOfByte.length < paramInt2 + 1) { byte[] arrayOfByte1 = new byte[(paramInt2 + 1) * 2]; System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, arrayOfByte.length); arrayOfByte = arrayOfByte1; }  return arrayOfByte; }
/*     */   boolean[] checkAndAllocateLobPrefetchMemory(boolean[] paramArrayOfboolean, int paramInt1, int paramInt2) { boolean[] arrayOfBoolean = paramArrayOfboolean; if (arrayOfBoolean == null) { arrayOfBoolean = new boolean[Math.max(paramInt1, paramInt2 + 1)]; } else if (arrayOfBoolean.length < paramInt2 + 1) { boolean[] arrayOfBoolean1 = new boolean[(paramInt2 + 1) * 2]; System.arraycopy(arrayOfBoolean, 0, arrayOfBoolean1, 0, arrayOfBoolean.length); arrayOfBoolean = arrayOfBoolean1; }  return arrayOfBoolean; }
/*     */   String getString(int paramInt) throws SQLException { if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1)
/*     */       return null;  if (this.lobPrefetchSizeForThisColumn != -1 && this.prefetchedLobSize != null) { if (this.prefetchedLobSize[paramInt] > 2147483647L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151); sQLException.fillInStackTrace(); throw sQLException; }  if (this.prefetchedLobCharData != null && this.lobPrefetchSizeForThisColumn >= this.prefetchedLobSize[paramInt])
/*     */         return new String(this.prefetchedLobCharData[paramInt], 0, this.prefetchedLobDataL[paramInt]);  CLOB cLOB = getCLOB(paramInt); if (cLOB == null)
/*     */         return null;  return cLOB.getSubString(1L, (int)this.prefetchedLobSize[paramInt]); }  return super.getString(paramInt); }
/*     */   void handlePrefetch() throws SQLException, IOException { this.prefetchedLobSize = checkAndAllocateLobPrefetchMemory(this.prefetchedLobSize, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed); this.prefetchedLobSize[this.lastRowProcessed] = this.mare.unmarshalSB8(); this.prefetchedLobChunkSize = checkAndAllocateLobPrefetchMemory(this.prefetchedLobChunkSize, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed); this.prefetchedLobChunkSize[this.lastRowProcessed] = (int)this.mare.unmarshalUB4(); if (this.lobPrefetchSizeForThisColumn > 0) { this.prefetchedClobDBVary = checkAndAllocateLobPrefetchMemory(this.prefetchedClobDBVary, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed); byte b = (byte)this.mare.unmarshalUB1(); if (b == 1) { this.prefetchedClobDBVary[this.lastRowProcessed] = true; } else { this.prefetchedClobDBVary[this.lastRowProcessed] = false; }  this.prefetchedClobCharset = checkAndAllocateLobPrefetchMemory(this.prefetchedClobCharset, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed); if (this.prefetchedClobDBVary[this.lastRowProcessed]) { this.prefetchedClobCharset[this.lastRowProcessed] = (short)this.mare.unmarshalUB2(); } else { this.prefetchedClobCharset[this.lastRowProcessed] = 0; }  this.prefetchedClobFormOfUse = checkAndAllocateLobPrefetchMemory(this.prefetchedClobFormOfUse, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed); this.prefetchedClobFormOfUse[this.lastRowProcessed] = (byte)this.mare.unmarshalUB1(); this.prefetchedLobDataL = checkAndAllocateLobPrefetchMemory(this.prefetchedLobDataL, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed); int i = this.lobPrefetchSizeForThisColumn; int j = -1; if (this.prefetchedClobDBVary[this.lastRowProcessed]) { j = i * 2; } else { j = i * 3; }  this.prefetchedLobData = checkAndAllocateLobPrefetchMemory(this.prefetchedLobData, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed, j); this.mare.unmarshalCLR(this.prefetchedLobData[this.lastRowProcessed], 0, this.meta); int k = this.meta[0]; disablePrefetchBufferForPreviousCLOBs(this.lastRowProcessed); this.prefetchedLobCharData = checkAndAllocateLobPrefetchMemory(this.prefetchedLobCharData, this.statement.rowPrefetchInLastFetch, this.lastRowProcessed, i); char[] arrayOfChar = this.prefetchedLobCharData[this.lastRowProcessed]; byte[] arrayOfByte = this.prefetchedLobData[this.lastRowProcessed]; int m = -1; if (b == 1) { if (this.prefetchedClobCharset[this.lastRowProcessed] == 2000) { m = CharacterSet.convertAL16UTF16BytesToJavaChars(arrayOfByte, 0, arrayOfChar, 0, k, true); } else { m = CharacterSet.convertAL16UTF16LEBytesToJavaChars(arrayOfByte, 0, arrayOfChar, 0, k, true); }  } else { int[] arrayOfInt = { k }; if (this.formOfUse == 1) { m = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte, 0, arrayOfChar, 0, arrayOfInt, arrayOfChar.length); } else { m = this.statement.connection.conversion.NCHARBytesToJavaChars(arrayOfByte, 0, arrayOfChar, 0, arrayOfInt, arrayOfChar.length); }  }
/*     */        this.prefetchedLobDataL[this.lastRowProcessed] = m; }
/*     */      }
/* 616 */   private void disablePrefetchBufferForPreviousCLOBs(int paramInt) { if (this.registeredCLOBs.size() > paramInt) {
/*     */       
/* 618 */       LinkedList linkedList = this.registeredCLOBs.get(paramInt);
/* 619 */       if (linkedList != null && !linkedList.isEmpty()) {
/*     */         
/* 621 */         ListIterator<CLOB> listIterator = linkedList.listIterator();
/* 622 */         for (; listIterator.hasNext(); ((CLOB)listIterator.next()).setPrefetchedData(null));
/* 623 */         linkedList.clear();
/*     */       } 
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 631 */     if (this.definedColumnType == 0) {
/* 632 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 635 */     Object object = null;
/*     */     
/* 637 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 639 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 640 */       sQLException.fillInStackTrace();
/* 641 */       throw sQLException;
/*     */     } 
/*     */     
/* 644 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 646 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2011:
/* 653 */           return getNCLOB(paramInt);
/*     */         
/*     */         case 2005:
/* 656 */           return getCLOB(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 663 */           return getString(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 670 */           return getBytes(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 674 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 675 */       sQLException.fillInStackTrace();
/* 676 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 682 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initializeClobForPrefetch(int paramInt, CLOB paramCLOB) throws SQLException {
/* 695 */     if (paramInt >= 0) {
/*     */       
/* 697 */       saveCLOBReference(paramInt, paramCLOB);
/* 698 */       paramCLOB.setPrefetchedData(this.prefetchedLobCharData[paramInt], this.prefetchedLobDataL[paramInt]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 704 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CClobAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */