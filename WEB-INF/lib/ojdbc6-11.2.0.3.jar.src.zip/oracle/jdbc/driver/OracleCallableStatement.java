/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.internal.OracleCallableStatement;
/*      */ import oracle.sql.ANYDATA;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleCallableStatement
/*      */   extends OraclePreparedStatement
/*      */   implements OracleCallableStatement
/*      */ {
/*      */   boolean atLeastOneOrdinalParameter = false;
/*      */   boolean atLeastOneNamedParameter = false;
/*   60 */   String[] namedParameters = new String[8];
/*      */ 
/*      */   
/*   63 */   int parameterCount = 0;
/*      */ 
/*      */   
/*   66 */   final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   87 */     this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  105 */     super(paramPhysicalConnection, paramString, 1, paramInt2, paramInt3, paramInt4);
/*      */ 
/*      */     
/*  108 */     this.statementType = 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws SQLException {
/*  121 */     int i = paramInt1 - 1;
/*  122 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*      */       
/*  124 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  125 */       sQLException.fillInStackTrace();
/*  126 */       throw sQLException;
/*      */     } 
/*      */     
/*  129 */     if (paramInt2 == 0) {
/*      */       
/*  131 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  132 */       sQLException.fillInStackTrace();
/*  133 */       throw sQLException;
/*      */     } 
/*  135 */     int j = getInternalType(paramInt2);
/*      */     
/*  137 */     resetBatch();
/*  138 */     this.currentRowNeedToPrepareBinds = true;
/*      */     
/*  140 */     if (this.currentRowBindAccessors == null) {
/*  141 */       this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/*      */     
/*  144 */     switch (paramInt2) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*      */       case 70:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/*  160 */         this.currentRowFormOfUse[i] = 2;
/*      */         break;
/*      */       case 2011:
/*  163 */         paramInt4 = 0;
/*  164 */         this.currentRowFormOfUse[i] = 2;
/*      */         break;
/*      */       case 2009:
/*  167 */         paramInt4 = 0;
/*  168 */         paramString = "SYS.XMLTYPE";
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  174 */         paramInt4 = 0;
/*      */         break;
/*      */     } 
/*      */     
/*  178 */     this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, i + 1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  212 */     if (paramString == null || paramString.length() == 0) {
/*      */       
/*  214 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
/*  215 */       sQLException.fillInStackTrace();
/*  216 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  222 */     synchronized (this.connection) {
/*  223 */       registerOutParameterInternal(paramInt1, paramInt2, 0, 0, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  252 */     synchronized (this.connection) {
/*      */       
/*  254 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  283 */     synchronized (this.connection) {
/*      */       
/*  285 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  302 */     synchronized (this.connection) {
/*      */       
/*  304 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  321 */     synchronized (this.connection) {
/*      */       
/*  323 */       registerOutParameterInternal(paramString, paramInt1, paramInt2, paramInt3, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isOracleBatchStyle() {
/*  332 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetBatch() {
/*  342 */     this.batch = 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExecuteBatch(int paramInt) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/*  371 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  374 */       return this.validRows;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/*  393 */     registerOutParameter(paramInt1, paramInt2, 0, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  405 */     registerOutParameter(paramInt1, paramInt2, paramInt3, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  413 */     return wasNullValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  423 */     if (this.closed) {
/*      */       
/*  425 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  426 */       sQLException.fillInStackTrace();
/*  427 */       throw sQLException;
/*      */     } 
/*      */     
/*  430 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  433 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  434 */       sQLException.fillInStackTrace();
/*  435 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  439 */     Accessor accessor = null;
/*  440 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  445 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  446 */       sQLException.fillInStackTrace();
/*  447 */       throw sQLException;
/*      */     } 
/*      */     
/*  450 */     this.lastIndex = paramInt;
/*      */     
/*  452 */     if (this.streamList != null) {
/*  453 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  456 */     return accessor.getString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  466 */     if (this.closed) {
/*      */       
/*  468 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  469 */       sQLException.fillInStackTrace();
/*  470 */       throw sQLException;
/*      */     } 
/*      */     
/*  473 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  476 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  477 */       sQLException.fillInStackTrace();
/*  478 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  482 */     Accessor accessor = null;
/*  483 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  488 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  489 */       sQLException.fillInStackTrace();
/*  490 */       throw sQLException;
/*      */     } 
/*      */     
/*  493 */     this.lastIndex = paramInt;
/*      */     
/*  495 */     if (this.streamList != null) {
/*  496 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  499 */     return accessor.getOracleObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/*  509 */     if (this.closed) {
/*      */       
/*  511 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  512 */       sQLException.fillInStackTrace();
/*  513 */       throw sQLException;
/*      */     } 
/*      */     
/*  516 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  519 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  520 */       sQLException.fillInStackTrace();
/*  521 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  525 */     Accessor accessor = null;
/*  526 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  531 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  532 */       sQLException.fillInStackTrace();
/*  533 */       throw sQLException;
/*      */     } 
/*      */     
/*  536 */     this.lastIndex = paramInt;
/*      */     
/*  538 */     if (this.streamList != null) {
/*  539 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  542 */     return accessor.getROWID(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/*  552 */     if (this.closed) {
/*      */       
/*  554 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  555 */       sQLException.fillInStackTrace();
/*  556 */       throw sQLException;
/*      */     } 
/*      */     
/*  559 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  562 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  563 */       sQLException.fillInStackTrace();
/*  564 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  568 */     Accessor accessor = null;
/*  569 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  574 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  575 */       sQLException.fillInStackTrace();
/*  576 */       throw sQLException;
/*      */     } 
/*      */     
/*  579 */     this.lastIndex = paramInt;
/*      */     
/*  581 */     if (this.streamList != null) {
/*  582 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  585 */     return accessor.getNUMBER(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/*  595 */     if (this.closed) {
/*      */       
/*  597 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  598 */       sQLException.fillInStackTrace();
/*  599 */       throw sQLException;
/*      */     } 
/*      */     
/*  602 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  605 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  606 */       sQLException.fillInStackTrace();
/*  607 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  611 */     Accessor accessor = null;
/*  612 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  617 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  618 */       sQLException.fillInStackTrace();
/*  619 */       throw sQLException;
/*      */     } 
/*      */     
/*  622 */     this.lastIndex = paramInt;
/*      */     
/*  624 */     if (this.streamList != null) {
/*  625 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  628 */     return accessor.getDATE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/*  638 */     if (this.closed) {
/*      */       
/*  640 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  641 */       sQLException.fillInStackTrace();
/*  642 */       throw sQLException;
/*      */     } 
/*      */     
/*  645 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  648 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  649 */       sQLException.fillInStackTrace();
/*  650 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  654 */     Accessor accessor = null;
/*  655 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  660 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  661 */       sQLException.fillInStackTrace();
/*  662 */       throw sQLException;
/*      */     } 
/*      */     
/*  665 */     this.lastIndex = paramInt;
/*      */     
/*  667 */     if (this.streamList != null) {
/*  668 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  671 */     return accessor.getINTERVALYM(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/*  681 */     if (this.closed) {
/*      */       
/*  683 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  684 */       sQLException.fillInStackTrace();
/*  685 */       throw sQLException;
/*      */     } 
/*      */     
/*  688 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  691 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  692 */       sQLException.fillInStackTrace();
/*  693 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  697 */     Accessor accessor = null;
/*  698 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  703 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  704 */       sQLException.fillInStackTrace();
/*  705 */       throw sQLException;
/*      */     } 
/*      */     
/*  708 */     this.lastIndex = paramInt;
/*      */     
/*  710 */     if (this.streamList != null) {
/*  711 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  714 */     return accessor.getINTERVALDS(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/*  724 */     if (this.closed) {
/*      */       
/*  726 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  727 */       sQLException.fillInStackTrace();
/*  728 */       throw sQLException;
/*      */     } 
/*      */     
/*  731 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  734 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  735 */       sQLException.fillInStackTrace();
/*  736 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  740 */     Accessor accessor = null;
/*  741 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  746 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  747 */       sQLException.fillInStackTrace();
/*  748 */       throw sQLException;
/*      */     } 
/*      */     
/*  751 */     this.lastIndex = paramInt;
/*      */     
/*  753 */     if (this.streamList != null) {
/*  754 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  757 */     return accessor.getTIMESTAMP(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/*  767 */     if (this.closed) {
/*      */       
/*  769 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  770 */       sQLException.fillInStackTrace();
/*  771 */       throw sQLException;
/*      */     } 
/*      */     
/*  774 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  777 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  778 */       sQLException.fillInStackTrace();
/*  779 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  783 */     Accessor accessor = null;
/*  784 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  789 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  790 */       sQLException.fillInStackTrace();
/*  791 */       throw sQLException;
/*      */     } 
/*      */     
/*  794 */     this.lastIndex = paramInt;
/*      */     
/*  796 */     if (this.streamList != null) {
/*  797 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  800 */     return accessor.getTIMESTAMPTZ(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/*  810 */     if (this.closed) {
/*      */       
/*  812 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  813 */       sQLException.fillInStackTrace();
/*  814 */       throw sQLException;
/*      */     } 
/*      */     
/*  817 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  820 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  821 */       sQLException.fillInStackTrace();
/*  822 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  826 */     Accessor accessor = null;
/*  827 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  832 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  833 */       sQLException.fillInStackTrace();
/*  834 */       throw sQLException;
/*      */     } 
/*      */     
/*  837 */     this.lastIndex = paramInt;
/*      */     
/*  839 */     if (this.streamList != null) {
/*  840 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  843 */     return accessor.getTIMESTAMPLTZ(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/*  853 */     if (this.closed) {
/*      */       
/*  855 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  856 */       sQLException.fillInStackTrace();
/*  857 */       throw sQLException;
/*      */     } 
/*      */     
/*  860 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  863 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  864 */       sQLException.fillInStackTrace();
/*  865 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  869 */     Accessor accessor = null;
/*  870 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  875 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  876 */       sQLException.fillInStackTrace();
/*  877 */       throw sQLException;
/*      */     } 
/*      */     
/*  880 */     this.lastIndex = paramInt;
/*      */     
/*  882 */     if (this.streamList != null) {
/*  883 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  886 */     return accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  896 */     if (this.closed) {
/*      */       
/*  898 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  899 */       sQLException.fillInStackTrace();
/*  900 */       throw sQLException;
/*      */     } 
/*      */     
/*  903 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  906 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  907 */       sQLException.fillInStackTrace();
/*  908 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  912 */     Accessor accessor = null;
/*  913 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  918 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  919 */       sQLException.fillInStackTrace();
/*  920 */       throw sQLException;
/*      */     } 
/*      */     
/*  923 */     this.lastIndex = paramInt;
/*      */     
/*  925 */     if (this.streamList != null) {
/*  926 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  929 */     return accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/*  939 */     if (this.closed) {
/*      */       
/*  941 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  942 */       sQLException.fillInStackTrace();
/*  943 */       throw sQLException;
/*      */     } 
/*      */     
/*  946 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  949 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  950 */       sQLException.fillInStackTrace();
/*  951 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  955 */     Accessor accessor = null;
/*  956 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  961 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  962 */       sQLException.fillInStackTrace();
/*  963 */       throw sQLException;
/*      */     } 
/*      */     
/*  966 */     this.lastIndex = paramInt;
/*      */     
/*  968 */     if (this.streamList != null) {
/*  969 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  972 */     return accessor.getSTRUCT(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/*  982 */     if (this.closed) {
/*      */       
/*  984 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  985 */       sQLException.fillInStackTrace();
/*  986 */       throw sQLException;
/*      */     } 
/*      */     
/*  989 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  992 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  993 */       sQLException.fillInStackTrace();
/*  994 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  998 */     Accessor accessor = null;
/*  999 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1004 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1005 */       sQLException.fillInStackTrace();
/* 1006 */       throw sQLException;
/*      */     } 
/*      */     
/* 1009 */     this.lastIndex = paramInt;
/*      */     
/* 1011 */     if (this.streamList != null) {
/* 1012 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1015 */     return accessor.getOPAQUE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1025 */     if (this.closed) {
/*      */       
/* 1027 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1028 */       sQLException.fillInStackTrace();
/* 1029 */       throw sQLException;
/*      */     } 
/*      */     
/* 1032 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1035 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1036 */       sQLException.fillInStackTrace();
/* 1037 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1041 */     Accessor accessor = null;
/* 1042 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1047 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1048 */       sQLException.fillInStackTrace();
/* 1049 */       throw sQLException;
/*      */     } 
/*      */     
/* 1052 */     this.lastIndex = paramInt;
/*      */     
/* 1054 */     if (this.streamList != null) {
/* 1055 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1058 */     return accessor.getCHAR(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1069 */     if (this.closed) {
/*      */       
/* 1071 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1072 */       sQLException.fillInStackTrace();
/* 1073 */       throw sQLException;
/*      */     } 
/*      */     
/* 1076 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1079 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1080 */       sQLException.fillInStackTrace();
/* 1081 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1085 */     Accessor accessor = null;
/* 1086 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1091 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1092 */       sQLException.fillInStackTrace();
/* 1093 */       throw sQLException;
/*      */     } 
/*      */     
/* 1096 */     this.lastIndex = paramInt;
/*      */     
/* 1098 */     if (this.streamList != null) {
/* 1099 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1102 */     return accessor.getCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 1112 */     if (this.closed) {
/*      */       
/* 1114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1115 */       sQLException.fillInStackTrace();
/* 1116 */       throw sQLException;
/*      */     } 
/*      */     
/* 1119 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1122 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1123 */       sQLException.fillInStackTrace();
/* 1124 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1128 */     Accessor accessor = null;
/* 1129 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1134 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1135 */       sQLException.fillInStackTrace();
/* 1136 */       throw sQLException;
/*      */     } 
/*      */     
/* 1139 */     this.lastIndex = paramInt;
/*      */     
/* 1141 */     if (this.streamList != null) {
/* 1142 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1145 */     return accessor.getRAW(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1156 */     if (this.closed) {
/*      */       
/* 1158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1159 */       sQLException.fillInStackTrace();
/* 1160 */       throw sQLException;
/*      */     } 
/*      */     
/* 1163 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1166 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1167 */       sQLException.fillInStackTrace();
/* 1168 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1172 */     Accessor accessor = null;
/* 1173 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1178 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1179 */       sQLException.fillInStackTrace();
/* 1180 */       throw sQLException;
/*      */     } 
/*      */     
/* 1183 */     this.lastIndex = paramInt;
/*      */     
/* 1185 */     if (this.streamList != null) {
/* 1186 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1189 */     return accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1199 */     if (this.closed) {
/*      */       
/* 1201 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1202 */       sQLException.fillInStackTrace();
/* 1203 */       throw sQLException;
/*      */     } 
/*      */     
/* 1206 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1209 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1210 */       sQLException.fillInStackTrace();
/* 1211 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1215 */     Accessor accessor = null;
/* 1216 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1221 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1222 */       sQLException.fillInStackTrace();
/* 1223 */       throw sQLException;
/*      */     } 
/*      */     
/* 1226 */     this.lastIndex = paramInt;
/*      */     
/* 1228 */     if (this.streamList != null) {
/* 1229 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1232 */     return accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1242 */     if (this.closed) {
/*      */       
/* 1244 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1245 */       sQLException.fillInStackTrace();
/* 1246 */       throw sQLException;
/*      */     } 
/*      */     
/* 1249 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1252 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1253 */       sQLException.fillInStackTrace();
/* 1254 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1258 */     Accessor accessor = null;
/* 1259 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1264 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1265 */       sQLException.fillInStackTrace();
/* 1266 */       throw sQLException;
/*      */     } 
/*      */     
/* 1269 */     this.lastIndex = paramInt;
/*      */     
/* 1271 */     if (this.streamList != null) {
/* 1272 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1275 */     return accessor.getBFILE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1285 */     if (this.closed) {
/*      */       
/* 1287 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1288 */       sQLException.fillInStackTrace();
/* 1289 */       throw sQLException;
/*      */     } 
/*      */     
/* 1292 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1295 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1296 */       sQLException.fillInStackTrace();
/* 1297 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1301 */     Accessor accessor = null;
/* 1302 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1307 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1308 */       sQLException.fillInStackTrace();
/* 1309 */       throw sQLException;
/*      */     } 
/*      */     
/* 1312 */     this.lastIndex = paramInt;
/*      */     
/* 1314 */     if (this.streamList != null) {
/* 1315 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1318 */     return accessor.getBFILE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/* 1328 */     if (this.closed) {
/*      */       
/* 1330 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1331 */       sQLException.fillInStackTrace();
/* 1332 */       throw sQLException;
/*      */     } 
/*      */     
/* 1335 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1338 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1339 */       sQLException.fillInStackTrace();
/* 1340 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1344 */     Accessor accessor = null;
/* 1345 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1350 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1351 */       sQLException.fillInStackTrace();
/* 1352 */       throw sQLException;
/*      */     } 
/*      */     
/* 1355 */     this.lastIndex = paramInt;
/*      */     
/* 1357 */     if (this.streamList != null) {
/* 1358 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1361 */     return accessor.getBoolean(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/* 1371 */     if (this.closed) {
/*      */       
/* 1373 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1374 */       sQLException.fillInStackTrace();
/* 1375 */       throw sQLException;
/*      */     } 
/*      */     
/* 1378 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1381 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1382 */       sQLException.fillInStackTrace();
/* 1383 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1387 */     Accessor accessor = null;
/* 1388 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1393 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1394 */       sQLException.fillInStackTrace();
/* 1395 */       throw sQLException;
/*      */     } 
/*      */     
/* 1398 */     this.lastIndex = paramInt;
/*      */     
/* 1400 */     if (this.streamList != null) {
/* 1401 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1404 */     return accessor.getByte(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 1414 */     if (this.closed) {
/*      */       
/* 1416 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1417 */       sQLException.fillInStackTrace();
/* 1418 */       throw sQLException;
/*      */     } 
/*      */     
/* 1421 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1424 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1425 */       sQLException.fillInStackTrace();
/* 1426 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1430 */     Accessor accessor = null;
/* 1431 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1436 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1437 */       sQLException.fillInStackTrace();
/* 1438 */       throw sQLException;
/*      */     } 
/*      */     
/* 1441 */     this.lastIndex = paramInt;
/*      */     
/* 1443 */     if (this.streamList != null) {
/* 1444 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1447 */     return accessor.getShort(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/* 1457 */     if (this.closed) {
/*      */       
/* 1459 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1460 */       sQLException.fillInStackTrace();
/* 1461 */       throw sQLException;
/*      */     } 
/*      */     
/* 1464 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1467 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1468 */       sQLException.fillInStackTrace();
/* 1469 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1473 */     Accessor accessor = null;
/* 1474 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1479 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1480 */       sQLException.fillInStackTrace();
/* 1481 */       throw sQLException;
/*      */     } 
/*      */     
/* 1484 */     this.lastIndex = paramInt;
/*      */     
/* 1486 */     if (this.streamList != null) {
/* 1487 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1490 */     return accessor.getInt(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/* 1500 */     if (this.closed) {
/*      */       
/* 1502 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1503 */       sQLException.fillInStackTrace();
/* 1504 */       throw sQLException;
/*      */     } 
/*      */     
/* 1507 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1510 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1511 */       sQLException.fillInStackTrace();
/* 1512 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1516 */     Accessor accessor = null;
/* 1517 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1522 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1523 */       sQLException.fillInStackTrace();
/* 1524 */       throw sQLException;
/*      */     } 
/*      */     
/* 1527 */     this.lastIndex = paramInt;
/*      */     
/* 1529 */     if (this.streamList != null) {
/* 1530 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1533 */     return accessor.getLong(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/* 1543 */     if (this.closed) {
/*      */       
/* 1545 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1546 */       sQLException.fillInStackTrace();
/* 1547 */       throw sQLException;
/*      */     } 
/*      */     
/* 1550 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1553 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1554 */       sQLException.fillInStackTrace();
/* 1555 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1559 */     Accessor accessor = null;
/* 1560 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1565 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1566 */       sQLException.fillInStackTrace();
/* 1567 */       throw sQLException;
/*      */     } 
/*      */     
/* 1570 */     this.lastIndex = paramInt;
/*      */     
/* 1572 */     if (this.streamList != null) {
/* 1573 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1576 */     return accessor.getFloat(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/* 1586 */     if (this.closed) {
/*      */       
/* 1588 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1589 */       sQLException.fillInStackTrace();
/* 1590 */       throw sQLException;
/*      */     } 
/*      */     
/* 1593 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1596 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1597 */       sQLException.fillInStackTrace();
/* 1598 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1602 */     Accessor accessor = null;
/* 1603 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1608 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1609 */       sQLException.fillInStackTrace();
/* 1610 */       throw sQLException;
/*      */     } 
/*      */     
/* 1613 */     this.lastIndex = paramInt;
/*      */     
/* 1615 */     if (this.streamList != null) {
/* 1616 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1619 */     return accessor.getDouble(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 1629 */     if (this.closed) {
/*      */       
/* 1631 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1632 */       sQLException.fillInStackTrace();
/* 1633 */       throw sQLException;
/*      */     } 
/*      */     
/* 1636 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1639 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1640 */       sQLException.fillInStackTrace();
/* 1641 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1645 */     Accessor accessor = null;
/* 1646 */     if (paramInt1 <= 0 || paramInt1 > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt1 - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1651 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1652 */       sQLException.fillInStackTrace();
/* 1653 */       throw sQLException;
/*      */     } 
/*      */     
/* 1656 */     this.lastIndex = paramInt1;
/*      */     
/* 1658 */     if (this.streamList != null) {
/* 1659 */       closeUsedStreams(paramInt1);
/*      */     }
/*      */     
/* 1662 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/* 1672 */     if (this.closed) {
/*      */       
/* 1674 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1675 */       sQLException.fillInStackTrace();
/* 1676 */       throw sQLException;
/*      */     } 
/*      */     
/* 1679 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1682 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1683 */       sQLException.fillInStackTrace();
/* 1684 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1688 */     Accessor accessor = null;
/* 1689 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1694 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1695 */       sQLException.fillInStackTrace();
/* 1696 */       throw sQLException;
/*      */     } 
/*      */     
/* 1699 */     this.lastIndex = paramInt;
/*      */     
/* 1701 */     if (this.streamList != null) {
/* 1702 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1705 */     return accessor.getBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] privateGetBytes(int paramInt) throws SQLException {
/* 1715 */     if (this.closed) {
/*      */       
/* 1717 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1718 */       sQLException.fillInStackTrace();
/* 1719 */       throw sQLException;
/*      */     } 
/*      */     
/* 1722 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1725 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1726 */       sQLException.fillInStackTrace();
/* 1727 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1731 */     Accessor accessor = null;
/* 1732 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1737 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1738 */       sQLException.fillInStackTrace();
/* 1739 */       throw sQLException;
/*      */     } 
/*      */     
/* 1742 */     this.lastIndex = paramInt;
/*      */     
/* 1744 */     if (this.streamList != null) {
/* 1745 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1748 */     return accessor.privateGetBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/* 1758 */     if (this.closed) {
/*      */       
/* 1760 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1761 */       sQLException.fillInStackTrace();
/* 1762 */       throw sQLException;
/*      */     } 
/*      */     
/* 1765 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1768 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1769 */       sQLException.fillInStackTrace();
/* 1770 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1774 */     Accessor accessor = null;
/* 1775 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1780 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1781 */       sQLException.fillInStackTrace();
/* 1782 */       throw sQLException;
/*      */     } 
/*      */     
/* 1785 */     this.lastIndex = paramInt;
/*      */     
/* 1787 */     if (this.streamList != null) {
/* 1788 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1791 */     return accessor.getDate(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 1801 */     if (this.closed) {
/*      */       
/* 1803 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1804 */       sQLException.fillInStackTrace();
/* 1805 */       throw sQLException;
/*      */     } 
/*      */     
/* 1808 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1811 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1812 */       sQLException.fillInStackTrace();
/* 1813 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1817 */     Accessor accessor = null;
/* 1818 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1823 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1824 */       sQLException.fillInStackTrace();
/* 1825 */       throw sQLException;
/*      */     } 
/*      */     
/* 1828 */     this.lastIndex = paramInt;
/*      */     
/* 1830 */     if (this.streamList != null) {
/* 1831 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1834 */     return accessor.getTime(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 1844 */     if (this.closed) {
/*      */       
/* 1846 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1847 */       sQLException.fillInStackTrace();
/* 1848 */       throw sQLException;
/*      */     } 
/*      */     
/* 1851 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1854 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1855 */       sQLException.fillInStackTrace();
/* 1856 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1860 */     Accessor accessor = null;
/* 1861 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1866 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1867 */       sQLException.fillInStackTrace();
/* 1868 */       throw sQLException;
/*      */     } 
/*      */     
/* 1871 */     this.lastIndex = paramInt;
/*      */     
/* 1873 */     if (this.streamList != null) {
/* 1874 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1877 */     return accessor.getTimestamp(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 1887 */     if (this.closed) {
/*      */       
/* 1889 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1890 */       sQLException.fillInStackTrace();
/* 1891 */       throw sQLException;
/*      */     } 
/*      */     
/* 1894 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1897 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1898 */       sQLException.fillInStackTrace();
/* 1899 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1903 */     Accessor accessor = null;
/* 1904 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1909 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1910 */       sQLException.fillInStackTrace();
/* 1911 */       throw sQLException;
/*      */     } 
/*      */     
/* 1914 */     this.lastIndex = paramInt;
/*      */     
/* 1916 */     if (this.streamList != null) {
/* 1917 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1920 */     return accessor.getAsciiStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 1930 */     if (this.closed) {
/*      */       
/* 1932 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1933 */       sQLException.fillInStackTrace();
/* 1934 */       throw sQLException;
/*      */     } 
/*      */     
/* 1937 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1940 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1941 */       sQLException.fillInStackTrace();
/* 1942 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1946 */     Accessor accessor = null;
/* 1947 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1952 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1953 */       sQLException.fillInStackTrace();
/* 1954 */       throw sQLException;
/*      */     } 
/*      */     
/* 1957 */     this.lastIndex = paramInt;
/*      */     
/* 1959 */     if (this.streamList != null) {
/* 1960 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1963 */     return accessor.getUnicodeStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 1973 */     if (this.closed) {
/*      */       
/* 1975 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1976 */       sQLException.fillInStackTrace();
/* 1977 */       throw sQLException;
/*      */     } 
/*      */     
/* 1980 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1983 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1984 */       sQLException.fillInStackTrace();
/* 1985 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1989 */     Accessor accessor = null;
/* 1990 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1995 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1996 */       sQLException.fillInStackTrace();
/* 1997 */       throw sQLException;
/*      */     } 
/*      */     
/* 2000 */     this.lastIndex = paramInt;
/*      */     
/* 2002 */     if (this.streamList != null) {
/* 2003 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2006 */     return accessor.getBinaryStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 2016 */     if (this.closed) {
/*      */       
/* 2018 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2019 */       sQLException.fillInStackTrace();
/* 2020 */       throw sQLException;
/*      */     } 
/*      */     
/* 2023 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2026 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2027 */       sQLException.fillInStackTrace();
/* 2028 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2032 */     Accessor accessor = null;
/* 2033 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2038 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2039 */       sQLException.fillInStackTrace();
/* 2040 */       throw sQLException;
/*      */     } 
/*      */     
/* 2043 */     this.lastIndex = paramInt;
/*      */     
/* 2045 */     if (this.streamList != null) {
/* 2046 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2049 */     return accessor.getObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
/* 2058 */     Object object1 = null;
/* 2059 */     Object object2 = getObject(paramInt);
/* 2060 */     if (object2 instanceof ANYDATA) {
/*      */       
/* 2062 */       Datum datum = ((ANYDATA)object2).accessDatum();
/* 2063 */       if (datum != null) object1 = datum.toJdbc(); 
/*      */     } 
/* 2065 */     return object1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 2075 */     if (this.closed) {
/*      */       
/* 2077 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2078 */       sQLException.fillInStackTrace();
/* 2079 */       throw sQLException;
/*      */     } 
/*      */     
/* 2082 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2085 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2086 */       sQLException.fillInStackTrace();
/* 2087 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2091 */     Accessor accessor = null;
/* 2092 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2097 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2098 */       sQLException.fillInStackTrace();
/* 2099 */       throw sQLException;
/*      */     } 
/*      */     
/* 2102 */     this.lastIndex = paramInt;
/*      */     
/* 2104 */     if (this.streamList != null) {
/* 2105 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2108 */     return accessor.getCustomDatum(this.currentRank, paramCustomDatumFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 2118 */     if (this.closed) {
/*      */       
/* 2120 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2121 */       sQLException.fillInStackTrace();
/* 2122 */       throw sQLException;
/*      */     } 
/*      */     
/* 2125 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2128 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2129 */       sQLException.fillInStackTrace();
/* 2130 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2134 */     Accessor accessor = null;
/* 2135 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2140 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2141 */       sQLException.fillInStackTrace();
/* 2142 */       throw sQLException;
/*      */     } 
/*      */     
/* 2145 */     this.lastIndex = paramInt;
/*      */     
/* 2147 */     if (this.streamList != null) {
/* 2148 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2151 */     return accessor.getORAData(this.currentRank, paramORADataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 2161 */     if (this.closed) {
/*      */       
/* 2163 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2164 */       sQLException.fillInStackTrace();
/* 2165 */       throw sQLException;
/*      */     } 
/*      */     
/* 2168 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2171 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2172 */       sQLException.fillInStackTrace();
/* 2173 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2177 */     Accessor accessor = null;
/* 2178 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2183 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2184 */       sQLException.fillInStackTrace();
/* 2185 */       throw sQLException;
/*      */     } 
/*      */     
/* 2188 */     this.lastIndex = paramInt;
/*      */     
/* 2190 */     if (this.streamList != null) {
/* 2191 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2194 */     return accessor.getCursor(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParameters() throws SQLException {
/* 2201 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2204 */       super.clearParameters();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 2225 */     if (this.closed) {
/*      */       
/* 2227 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2228 */       sQLException.fillInStackTrace();
/* 2229 */       throw sQLException;
/*      */     } 
/*      */     
/* 2232 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2235 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2236 */       sQLException.fillInStackTrace();
/* 2237 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2241 */     Accessor accessor = null;
/* 2242 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2247 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2248 */       sQLException.fillInStackTrace();
/* 2249 */       throw sQLException;
/*      */     } 
/*      */     
/* 2252 */     this.lastIndex = paramInt;
/*      */     
/* 2254 */     if (this.streamList != null) {
/* 2255 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2258 */     return accessor.getObject(this.currentRank, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 2268 */     if (this.closed) {
/*      */       
/* 2270 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2271 */       sQLException.fillInStackTrace();
/* 2272 */       throw sQLException;
/*      */     } 
/*      */     
/* 2275 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2278 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2279 */       sQLException.fillInStackTrace();
/* 2280 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2284 */     Accessor accessor = null;
/* 2285 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2290 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2291 */       sQLException.fillInStackTrace();
/* 2292 */       throw sQLException;
/*      */     } 
/*      */     
/* 2295 */     this.lastIndex = paramInt;
/*      */     
/* 2297 */     if (this.streamList != null) {
/* 2298 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2301 */     return (Ref)accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 2311 */     if (this.closed) {
/*      */       
/* 2313 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2314 */       sQLException.fillInStackTrace();
/* 2315 */       throw sQLException;
/*      */     } 
/*      */     
/* 2318 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2321 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2322 */       sQLException.fillInStackTrace();
/* 2323 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2327 */     Accessor accessor = null;
/* 2328 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2333 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2334 */       sQLException.fillInStackTrace();
/* 2335 */       throw sQLException;
/*      */     } 
/*      */     
/* 2338 */     this.lastIndex = paramInt;
/*      */     
/* 2340 */     if (this.streamList != null) {
/* 2341 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2344 */     return (Blob)accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 2354 */     if (this.closed) {
/*      */       
/* 2356 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2357 */       sQLException.fillInStackTrace();
/* 2358 */       throw sQLException;
/*      */     } 
/*      */     
/* 2361 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2364 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2365 */       sQLException.fillInStackTrace();
/* 2366 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2370 */     Accessor accessor = null;
/* 2371 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2376 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2377 */       sQLException.fillInStackTrace();
/* 2378 */       throw sQLException;
/*      */     } 
/*      */     
/* 2381 */     this.lastIndex = paramInt;
/*      */     
/* 2383 */     if (this.streamList != null) {
/* 2384 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2387 */     return (Clob)accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 2397 */     if (this.closed) {
/*      */       
/* 2399 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2400 */       sQLException.fillInStackTrace();
/* 2401 */       throw sQLException;
/*      */     } 
/*      */     
/* 2404 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2407 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2408 */       sQLException.fillInStackTrace();
/* 2409 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2413 */     Accessor accessor = null;
/* 2414 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2419 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2420 */       sQLException.fillInStackTrace();
/* 2421 */       throw sQLException;
/*      */     } 
/*      */     
/* 2424 */     this.lastIndex = paramInt;
/*      */     
/* 2426 */     if (this.streamList != null) {
/* 2427 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2430 */     return (Array)accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 2440 */     if (this.closed) {
/*      */       
/* 2442 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2443 */       sQLException.fillInStackTrace();
/* 2444 */       throw sQLException;
/*      */     } 
/*      */     
/* 2447 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2450 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2451 */       sQLException.fillInStackTrace();
/* 2452 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2456 */     Accessor accessor = null;
/* 2457 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2462 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2463 */       sQLException.fillInStackTrace();
/* 2464 */       throw sQLException;
/*      */     } 
/*      */     
/* 2467 */     this.lastIndex = paramInt;
/*      */     
/* 2469 */     if (this.streamList != null) {
/* 2470 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2473 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2483 */     if (this.closed) {
/*      */       
/* 2485 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2486 */       sQLException.fillInStackTrace();
/* 2487 */       throw sQLException;
/*      */     } 
/*      */     
/* 2490 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2493 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2494 */       sQLException.fillInStackTrace();
/* 2495 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2499 */     Accessor accessor = null;
/* 2500 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2505 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2506 */       sQLException.fillInStackTrace();
/* 2507 */       throw sQLException;
/*      */     } 
/*      */     
/* 2510 */     this.lastIndex = paramInt;
/*      */     
/* 2512 */     if (this.streamList != null) {
/* 2513 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2516 */     return accessor.getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2526 */     if (this.closed) {
/*      */       
/* 2528 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2529 */       sQLException.fillInStackTrace();
/* 2530 */       throw sQLException;
/*      */     } 
/*      */     
/* 2533 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2536 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2537 */       sQLException.fillInStackTrace();
/* 2538 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2542 */     Accessor accessor = null;
/* 2543 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2548 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2549 */       sQLException.fillInStackTrace();
/* 2550 */       throw sQLException;
/*      */     } 
/*      */     
/* 2553 */     this.lastIndex = paramInt;
/*      */     
/* 2555 */     if (this.streamList != null) {
/* 2556 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2559 */     return accessor.getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2569 */     if (this.closed) {
/*      */       
/* 2571 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2572 */       sQLException.fillInStackTrace();
/* 2573 */       throw sQLException;
/*      */     } 
/*      */     
/* 2576 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2579 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2580 */       sQLException.fillInStackTrace();
/* 2581 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2585 */     Accessor accessor = null;
/* 2586 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2591 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2592 */       sQLException.fillInStackTrace();
/* 2593 */       throw sQLException;
/*      */     } 
/*      */     
/* 2596 */     this.lastIndex = paramInt;
/*      */     
/* 2598 */     if (this.streamList != null) {
/* 2599 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2602 */     return accessor.getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch() throws SQLException {
/* 2648 */     if (this.currentRowBindAccessors != null) {
/*      */ 
/*      */       
/* 2651 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
/* 2652 */       sQLException.fillInStackTrace();
/* 2653 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2657 */     super.addBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void alwaysOnClose() throws SQLException {
/* 2667 */     this.sqlObject.resetNamedParameters();
/*      */ 
/*      */     
/* 2670 */     this.namedParameters = new String[8];
/* 2671 */     this.parameterCount = 0;
/* 2672 */     this.atLeastOneOrdinalParameter = false;
/* 2673 */     this.atLeastOneNamedParameter = false;
/*      */     
/* 2675 */     super.alwaysOnClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLException {
/* 2712 */     registerOutParameterInternal(paramString, paramInt, 0, -1, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 2745 */     registerOutParameterInternal(paramString, paramInt1, paramInt2, -1, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 2790 */     registerOutParameterInternal(paramString1, paramInt, 0, -1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerOutParameterInternal(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2) throws SQLException {
/* 2798 */     int i = addNamedPara(paramString1);
/* 2799 */     registerOutParameterInternal(i, paramInt1, paramInt2, paramInt3, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 2824 */     if (this.closed) {
/*      */       
/* 2826 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2827 */       sQLException.fillInStackTrace();
/* 2828 */       throw sQLException;
/*      */     } 
/*      */     
/* 2831 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2834 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2835 */       sQLException.fillInStackTrace();
/* 2836 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2840 */     Accessor accessor = null;
/* 2841 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2846 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2847 */       sQLException.fillInStackTrace();
/* 2848 */       throw sQLException;
/*      */     } 
/*      */     
/* 2851 */     this.lastIndex = paramInt;
/*      */     
/* 2853 */     if (this.streamList != null) {
/* 2854 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2857 */     return accessor.getURL(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(String paramString1, String paramString2) throws SQLException {
/* 2884 */     int i = addNamedPara(paramString1);
/* 2885 */     if (paramString2 == null || paramString2.length() == 0) {
/*      */       
/* 2887 */       setNull(i, 2005);
/*      */       return;
/*      */     } 
/* 2890 */     setStringForClob(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(int paramInt, String paramString) throws SQLException {
/* 2909 */     if (paramString == null || paramString.length() == 0) {
/*      */       
/* 2911 */       setNull(paramInt, 2005);
/*      */       return;
/*      */     } 
/* 2914 */     synchronized (this.connection) {
/* 2915 */       setStringForClobCritical(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 2940 */     int i = addNamedPara(paramString);
/* 2941 */     setBytesForBlob(i, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 2959 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/*      */       
/* 2961 */       setNull(paramInt, 2004);
/*      */       return;
/*      */     } 
/* 2964 */     synchronized (this.connection) {
/* 2965 */       setBytesForBlobCritical(paramInt, paramArrayOfbyte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/* 2994 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2997 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2998 */       sQLException.fillInStackTrace();
/* 2999 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3003 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3006 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3008 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3011 */     b++;
/*      */     
/* 3013 */     Accessor accessor = null;
/* 3014 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3019 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3020 */       sQLException.fillInStackTrace();
/* 3021 */       throw sQLException;
/*      */     } 
/*      */     
/* 3024 */     this.lastIndex = b;
/*      */     
/* 3026 */     if (this.streamList != null) {
/* 3027 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3030 */     return accessor.getString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/* 3051 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3054 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3055 */       sQLException.fillInStackTrace();
/* 3056 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3060 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3063 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3065 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3068 */     b++;
/*      */     
/* 3070 */     Accessor accessor = null;
/* 3071 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3076 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3077 */       sQLException.fillInStackTrace();
/* 3078 */       throw sQLException;
/*      */     } 
/*      */     
/* 3081 */     this.lastIndex = b;
/*      */     
/* 3083 */     if (this.streamList != null) {
/* 3084 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3087 */     return accessor.getBoolean(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/* 3108 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3111 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3112 */       sQLException.fillInStackTrace();
/* 3113 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3117 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3120 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3122 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3125 */     b++;
/*      */     
/* 3127 */     Accessor accessor = null;
/* 3128 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3133 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3134 */       sQLException.fillInStackTrace();
/* 3135 */       throw sQLException;
/*      */     } 
/*      */     
/* 3138 */     this.lastIndex = b;
/*      */     
/* 3140 */     if (this.streamList != null) {
/* 3141 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3144 */     return accessor.getByte(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/* 3165 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3168 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3169 */       sQLException.fillInStackTrace();
/* 3170 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3174 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3177 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3179 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3182 */     b++;
/*      */     
/* 3184 */     Accessor accessor = null;
/* 3185 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3190 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3191 */       sQLException.fillInStackTrace();
/* 3192 */       throw sQLException;
/*      */     } 
/*      */     
/* 3195 */     this.lastIndex = b;
/*      */     
/* 3197 */     if (this.streamList != null) {
/* 3198 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3201 */     return accessor.getShort(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/* 3223 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3226 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3227 */       sQLException.fillInStackTrace();
/* 3228 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3232 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3235 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3237 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3240 */     b++;
/*      */     
/* 3242 */     Accessor accessor = null;
/* 3243 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3248 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3249 */       sQLException.fillInStackTrace();
/* 3250 */       throw sQLException;
/*      */     } 
/*      */     
/* 3253 */     this.lastIndex = b;
/*      */     
/* 3255 */     if (this.streamList != null) {
/* 3256 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3259 */     return accessor.getInt(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/* 3281 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3284 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3285 */       sQLException.fillInStackTrace();
/* 3286 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3290 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3293 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3295 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3298 */     b++;
/*      */     
/* 3300 */     Accessor accessor = null;
/* 3301 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3306 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3307 */       sQLException.fillInStackTrace();
/* 3308 */       throw sQLException;
/*      */     } 
/*      */     
/* 3311 */     this.lastIndex = b;
/*      */     
/* 3313 */     if (this.streamList != null) {
/* 3314 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3317 */     return accessor.getLong(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/* 3338 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3341 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3342 */       sQLException.fillInStackTrace();
/* 3343 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3347 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3350 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3352 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3355 */     b++;
/*      */     
/* 3357 */     Accessor accessor = null;
/* 3358 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3363 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3364 */       sQLException.fillInStackTrace();
/* 3365 */       throw sQLException;
/*      */     } 
/*      */     
/* 3368 */     this.lastIndex = b;
/*      */     
/* 3370 */     if (this.streamList != null) {
/* 3371 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3374 */     return accessor.getFloat(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/* 3395 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3398 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3399 */       sQLException.fillInStackTrace();
/* 3400 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3404 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3407 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3409 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3412 */     b++;
/*      */     
/* 3414 */     Accessor accessor = null;
/* 3415 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3420 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3421 */       sQLException.fillInStackTrace();
/* 3422 */       throw sQLException;
/*      */     } 
/*      */     
/* 3425 */     this.lastIndex = b;
/*      */     
/* 3427 */     if (this.streamList != null) {
/* 3428 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3431 */     return accessor.getDouble(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/* 3453 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3456 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3457 */       sQLException.fillInStackTrace();
/* 3458 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3462 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3465 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3467 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3470 */     b++;
/*      */     
/* 3472 */     Accessor accessor = null;
/* 3473 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3478 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3479 */       sQLException.fillInStackTrace();
/* 3480 */       throw sQLException;
/*      */     } 
/*      */     
/* 3483 */     this.lastIndex = b;
/*      */     
/* 3485 */     if (this.streamList != null) {
/* 3486 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3489 */     return accessor.getBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/* 3510 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3513 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3514 */       sQLException.fillInStackTrace();
/* 3515 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3519 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3522 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3524 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3527 */     b++;
/*      */     
/* 3529 */     Accessor accessor = null;
/* 3530 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3535 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3536 */       sQLException.fillInStackTrace();
/* 3537 */       throw sQLException;
/*      */     } 
/*      */     
/* 3540 */     this.lastIndex = b;
/*      */     
/* 3542 */     if (this.streamList != null) {
/* 3543 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3546 */     return accessor.getDate(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/* 3567 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3570 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3571 */       sQLException.fillInStackTrace();
/* 3572 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3576 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3579 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3581 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3584 */     b++;
/*      */     
/* 3586 */     Accessor accessor = null;
/* 3587 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3592 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3593 */       sQLException.fillInStackTrace();
/* 3594 */       throw sQLException;
/*      */     } 
/*      */     
/* 3597 */     this.lastIndex = b;
/*      */     
/* 3599 */     if (this.streamList != null) {
/* 3600 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3603 */     return accessor.getTime(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/* 3624 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3627 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3628 */       sQLException.fillInStackTrace();
/* 3629 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3633 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3636 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3638 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3641 */     b++;
/*      */     
/* 3643 */     Accessor accessor = null;
/* 3644 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3649 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3650 */       sQLException.fillInStackTrace();
/* 3651 */       throw sQLException;
/*      */     } 
/*      */     
/* 3654 */     this.lastIndex = b;
/*      */     
/* 3656 */     if (this.streamList != null) {
/* 3657 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3660 */     return accessor.getTimestamp(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLException {
/* 3688 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3691 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3692 */       sQLException.fillInStackTrace();
/* 3693 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3697 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3700 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3702 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3705 */     b++;
/*      */     
/* 3707 */     Accessor accessor = null;
/* 3708 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3713 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3714 */       sQLException.fillInStackTrace();
/* 3715 */       throw sQLException;
/*      */     } 
/*      */     
/* 3718 */     this.lastIndex = b;
/*      */     
/* 3720 */     if (this.streamList != null) {
/* 3721 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3724 */     return accessor.getObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/* 3746 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3749 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3750 */       sQLException.fillInStackTrace();
/* 3751 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3755 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3758 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3760 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3763 */     b++;
/*      */     
/* 3765 */     Accessor accessor = null;
/* 3766 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3771 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3772 */       sQLException.fillInStackTrace();
/* 3773 */       throw sQLException;
/*      */     } 
/*      */     
/* 3776 */     this.lastIndex = b;
/*      */     
/* 3778 */     if (this.streamList != null) {
/* 3779 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3782 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/* 3791 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3794 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3795 */       sQLException.fillInStackTrace();
/* 3796 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3800 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3803 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3805 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3808 */     b++;
/*      */     
/* 3810 */     Accessor accessor = null;
/* 3811 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3816 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3817 */       sQLException.fillInStackTrace();
/* 3818 */       throw sQLException;
/*      */     } 
/*      */     
/* 3821 */     this.lastIndex = b;
/*      */     
/* 3823 */     if (this.streamList != null) {
/* 3824 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3827 */     return accessor.getBigDecimal(this.currentRank, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/* 3855 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3858 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3859 */       sQLException.fillInStackTrace();
/* 3860 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3864 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3867 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3869 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3872 */     b++;
/*      */     
/* 3874 */     Accessor accessor = null;
/* 3875 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3880 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3881 */       sQLException.fillInStackTrace();
/* 3882 */       throw sQLException;
/*      */     } 
/*      */     
/* 3885 */     this.lastIndex = b;
/*      */     
/* 3887 */     if (this.streamList != null) {
/* 3888 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3891 */     return accessor.getObject(this.currentRank, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/* 3913 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3916 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3917 */       sQLException.fillInStackTrace();
/* 3918 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3922 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3925 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3927 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3930 */     b++;
/*      */     
/* 3932 */     Accessor accessor = null;
/* 3933 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3938 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3939 */       sQLException.fillInStackTrace();
/* 3940 */       throw sQLException;
/*      */     } 
/*      */     
/* 3943 */     this.lastIndex = b;
/*      */     
/* 3945 */     if (this.streamList != null) {
/* 3946 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3949 */     return (Ref)accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/* 3971 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3974 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3975 */       sQLException.fillInStackTrace();
/* 3976 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3980 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3983 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3985 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3988 */     b++;
/*      */     
/* 3990 */     Accessor accessor = null;
/* 3991 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3996 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3997 */       sQLException.fillInStackTrace();
/* 3998 */       throw sQLException;
/*      */     } 
/*      */     
/* 4001 */     this.lastIndex = b;
/*      */     
/* 4003 */     if (this.streamList != null) {
/* 4004 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4007 */     return (Blob)accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/* 4028 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4031 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4032 */       sQLException.fillInStackTrace();
/* 4033 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4037 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4040 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4042 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4045 */     b++;
/*      */     
/* 4047 */     Accessor accessor = null;
/* 4048 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4053 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4054 */       sQLException.fillInStackTrace();
/* 4055 */       throw sQLException;
/*      */     } 
/*      */     
/* 4058 */     this.lastIndex = b;
/*      */     
/* 4060 */     if (this.streamList != null) {
/* 4061 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4064 */     return (Clob)accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/* 4086 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4089 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4090 */       sQLException.fillInStackTrace();
/* 4091 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4095 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4098 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4100 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4103 */     b++;
/*      */     
/* 4105 */     Accessor accessor = null;
/* 4106 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4111 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4112 */       sQLException.fillInStackTrace();
/* 4113 */       throw sQLException;
/*      */     } 
/*      */     
/* 4116 */     this.lastIndex = b;
/*      */     
/* 4118 */     if (this.streamList != null) {
/* 4119 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4122 */     return (Array)accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/* 4152 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4155 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4156 */       sQLException.fillInStackTrace();
/* 4157 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4161 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4164 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4166 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4169 */     b++;
/*      */     
/* 4171 */     Accessor accessor = null;
/* 4172 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4177 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4178 */       sQLException.fillInStackTrace();
/* 4179 */       throw sQLException;
/*      */     } 
/*      */     
/* 4182 */     this.lastIndex = b;
/*      */     
/* 4184 */     if (this.streamList != null) {
/* 4185 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4188 */     return accessor.getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/* 4218 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4221 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4222 */       sQLException.fillInStackTrace();
/* 4223 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4227 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4230 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4232 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4235 */     b++;
/*      */     
/* 4237 */     Accessor accessor = null;
/* 4238 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4243 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4244 */       sQLException.fillInStackTrace();
/* 4245 */       throw sQLException;
/*      */     } 
/*      */     
/* 4248 */     this.lastIndex = b;
/*      */     
/* 4250 */     if (this.streamList != null) {
/* 4251 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4254 */     return accessor.getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/* 4285 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4288 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4289 */       sQLException.fillInStackTrace();
/* 4290 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4294 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4297 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4299 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4302 */     b++;
/*      */     
/* 4304 */     Accessor accessor = null;
/* 4305 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4310 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4311 */       sQLException.fillInStackTrace();
/* 4312 */       throw sQLException;
/*      */     } 
/*      */     
/* 4315 */     this.lastIndex = b;
/*      */     
/* 4317 */     if (this.streamList != null) {
/* 4318 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4321 */     return accessor.getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/* 4345 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4348 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4349 */       sQLException.fillInStackTrace();
/* 4350 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4354 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4357 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4359 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4362 */     b++;
/*      */     
/* 4364 */     Accessor accessor = null;
/* 4365 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4370 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4371 */       sQLException.fillInStackTrace();
/* 4372 */       throw sQLException;
/*      */     } 
/*      */     
/* 4375 */     this.lastIndex = b;
/*      */     
/* 4377 */     if (this.streamList != null) {
/* 4378 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4381 */     return accessor.getURL(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/* 4391 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 4392 */     sQLException.fillInStackTrace();
/* 4393 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 4432 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 4435 */       int i = paramInt1 - 1;
/* 4436 */       if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*      */         
/* 4438 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4439 */         sQLException.fillInStackTrace();
/* 4440 */         throw sQLException;
/*      */       } 
/*      */       
/* 4443 */       int j = getInternalType(paramInt3);
/*      */       
/* 4445 */       resetBatch();
/* 4446 */       this.currentRowNeedToPrepareBinds = true;
/*      */       
/* 4448 */       if (this.currentRowBindAccessors == null) {
/* 4449 */         this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */       }
/* 4451 */       this.currentRowBindAccessors[i] = allocateIndexTableAccessor(paramInt3, j, paramInt4, paramInt2, this.currentRowFormOfUse[i], true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4459 */       this.hasIbtBind = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean) throws SQLException {
/* 4476 */     return new PlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt) throws SQLException {
/* 4500 */     synchronized (this.connection) {
/*      */       BigDecimal[] arrayOfBigDecimal;
/*      */       SQLException sQLException;
/* 4503 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4505 */       PlsqlIndexTableAccessor plsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[paramInt - 1];
/*      */ 
/*      */       
/* 4508 */       int i = plsqlIndexTableAccessor.elementInternalType;
/*      */       
/* 4510 */       String[] arrayOfString = null;
/*      */       
/* 4512 */       switch (i) {
/*      */         
/*      */         case 9:
/* 4515 */           arrayOfString = new String[arrayOfDatum.length];
/*      */           break;
/*      */         case 6:
/* 4518 */           arrayOfBigDecimal = new BigDecimal[arrayOfDatum.length];
/*      */           break;
/*      */         
/*      */         default:
/* 4522 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid column type");
/* 4523 */           sQLException.fillInStackTrace();
/* 4524 */           throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4528 */       for (byte b = 0; b < arrayOfBigDecimal.length; b++) {
/* 4529 */         arrayOfBigDecimal[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (BigDecimal)arrayOfDatum[b].toJdbc() : null;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 4534 */       return arrayOfBigDecimal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
/* 4554 */     synchronized (this.connection) {
/*      */       
/* 4556 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4558 */       if (paramClass == null || !paramClass.isPrimitive()) {
/*      */         
/* 4560 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4561 */         sQLException1.fillInStackTrace();
/* 4562 */         throw sQLException1;
/*      */       } 
/*      */       
/* 4565 */       String str = paramClass.getName();
/*      */       
/* 4567 */       if (str.equals("byte")) {
/*      */         
/* 4569 */         byte[] arrayOfByte = new byte[arrayOfDatum.length];
/* 4570 */         for (byte b = 0; b < arrayOfDatum.length; b++)
/* 4571 */           arrayOfByte[b] = (arrayOfDatum[b] != null) ? arrayOfDatum[b].byteValue() : 0; 
/* 4572 */         return arrayOfByte;
/*      */       } 
/* 4574 */       if (str.equals("char")) {
/*      */         
/* 4576 */         char[] arrayOfChar = new char[arrayOfDatum.length];
/* 4577 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4578 */           arrayOfChar[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (char)arrayOfDatum[b].intValue() : Character.MIN_VALUE;
/*      */         }
/* 4580 */         return arrayOfChar;
/*      */       } 
/* 4582 */       if (str.equals("double")) {
/*      */         
/* 4584 */         double[] arrayOfDouble = new double[arrayOfDatum.length];
/* 4585 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4586 */           arrayOfDouble[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].doubleValue() : 0.0D;
/*      */         }
/* 4588 */         return arrayOfDouble;
/*      */       } 
/* 4590 */       if (str.equals("float")) {
/*      */         
/* 4592 */         float[] arrayOfFloat = new float[arrayOfDatum.length];
/* 4593 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4594 */           arrayOfFloat[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].floatValue() : 0.0F;
/*      */         }
/* 4596 */         return arrayOfFloat;
/*      */       } 
/* 4598 */       if (str.equals("int")) {
/*      */         
/* 4600 */         int[] arrayOfInt = new int[arrayOfDatum.length];
/* 4601 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4602 */           arrayOfInt[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].intValue() : 0;
/*      */         }
/* 4604 */         return arrayOfInt;
/*      */       } 
/* 4606 */       if (str.equals("long")) {
/*      */         
/* 4608 */         long[] arrayOfLong = new long[arrayOfDatum.length];
/* 4609 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4610 */           arrayOfLong[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].longValue() : 0L;
/*      */         }
/* 4612 */         return arrayOfLong;
/*      */       } 
/* 4614 */       if (str.equals("short")) {
/*      */         
/* 4616 */         short[] arrayOfShort = new short[arrayOfDatum.length];
/* 4617 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4618 */           arrayOfShort[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (short)arrayOfDatum[b].intValue() : 0;
/*      */         }
/* 4620 */         return arrayOfShort;
/*      */       } 
/* 4622 */       if (str.equals("boolean")) {
/*      */         
/* 4624 */         boolean[] arrayOfBoolean = new boolean[arrayOfDatum.length];
/* 4625 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4626 */           arrayOfBoolean[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].booleanValue() : false;
/*      */         }
/* 4628 */         return arrayOfBoolean;
/*      */       } 
/*      */ 
/*      */       
/* 4632 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4633 */       sQLException.fillInStackTrace();
/* 4634 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 4652 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4656 */       if (this.closed) {
/*      */         
/* 4658 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4659 */         sQLException.fillInStackTrace();
/* 4660 */         throw sQLException;
/*      */       } 
/*      */       
/* 4663 */       if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */         
/* 4666 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4667 */         sQLException.fillInStackTrace();
/* 4668 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4672 */       Accessor accessor = null;
/* 4673 */       if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4678 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4679 */         sQLException.fillInStackTrace();
/* 4680 */         throw sQLException;
/*      */       } 
/*      */       
/* 4683 */       this.lastIndex = paramInt;
/*      */       
/* 4685 */       if (this.streamList != null) {
/* 4686 */         closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 4689 */       return accessor.getOraclePlsqlIndexTable(this.currentRank);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLException {
/* 4704 */     synchronized (this.connection) {
/* 4705 */       ensureOpen();
/* 4706 */       if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
/*      */         
/* 4708 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4709 */         sQLException.fillInStackTrace();
/* 4710 */         throw sQLException;
/*      */       } 
/* 4712 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4713 */         this.needToParse = true; 
/* 4714 */       return super.execute();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLException {
/* 4728 */     synchronized (this.connection) {
/*      */       
/* 4730 */       ensureOpen();
/* 4731 */       if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
/*      */         
/* 4733 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4734 */         sQLException.fillInStackTrace();
/* 4735 */         throw sQLException;
/*      */       } 
/* 4737 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4738 */         this.needToParse = true; 
/* 4739 */       return super.executeUpdate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/* 4746 */     if (this.outBindAccessors != null) {
/*      */       
/* 4748 */       int i = this.outBindAccessors.length;
/*      */       
/* 4750 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 4752 */         if (this.outBindAccessors[b] != null) {
/*      */           
/* 4754 */           (this.outBindAccessors[b]).rowSpaceByte = null;
/* 4755 */           (this.outBindAccessors[b]).rowSpaceChar = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 4760 */     super.releaseBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doLocalInitialization() {
/* 4767 */     if (this.outBindAccessors != null) {
/*      */       
/* 4769 */       int i = this.outBindAccessors.length;
/*      */       
/* 4771 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 4773 */         if (this.outBindAccessors[b] != null) {
/*      */           
/* 4775 */           (this.outBindAccessors[b]).rowSpaceByte = this.bindBytes;
/* 4776 */           (this.outBindAccessors[b]).rowSpaceChar = this.bindChars;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(int paramInt, Array paramArray) throws SQLException {
/* 4791 */     this.atLeastOneOrdinalParameter = true;
/* 4792 */     setArrayInternal(paramInt, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/* 4799 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4803 */       this.atLeastOneOrdinalParameter = true;
/* 4804 */       setBigDecimalInternal(paramInt, paramBigDecimal);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 4812 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4816 */       this.atLeastOneOrdinalParameter = true;
/* 4817 */       setBlobInternal(paramInt, paramBlob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/* 4825 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4829 */       this.atLeastOneOrdinalParameter = true;
/* 4830 */       setBooleanInternal(paramInt, paramBoolean);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int paramInt, byte paramByte) throws SQLException {
/* 4838 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4842 */       this.atLeastOneOrdinalParameter = true;
/* 4843 */       setByteInternal(paramInt, paramByte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 4851 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4855 */       this.atLeastOneOrdinalParameter = true;
/* 4856 */       setBytesInternal(paramInt, paramArrayOfbyte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Clob paramClob) throws SQLException {
/* 4864 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4868 */       this.atLeastOneOrdinalParameter = true;
/* 4869 */       setClobInternal(paramInt, paramClob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate) throws SQLException {
/* 4877 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4881 */       this.atLeastOneOrdinalParameter = true;
/* 4882 */       setDateInternal(paramInt, paramDate);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 4890 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4894 */       this.atLeastOneOrdinalParameter = true;
/* 4895 */       setDateInternal(paramInt, paramDate, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int paramInt, double paramDouble) throws SQLException {
/* 4903 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4907 */       this.atLeastOneOrdinalParameter = true;
/* 4908 */       setDoubleInternal(paramInt, paramDouble);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int paramInt, float paramFloat) throws SQLException {
/* 4916 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4920 */       this.atLeastOneOrdinalParameter = true;
/* 4921 */       setFloatInternal(paramInt, paramFloat);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int paramInt1, int paramInt2) throws SQLException {
/* 4929 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4933 */       this.atLeastOneOrdinalParameter = true;
/* 4934 */       setIntInternal(paramInt1, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int paramInt, long paramLong) throws SQLException {
/* 4942 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4946 */       this.atLeastOneOrdinalParameter = true;
/* 4947 */       setLongInternal(paramInt, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, NClob paramNClob) throws SQLException {
/* 4955 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4959 */       this.atLeastOneOrdinalParameter = true;
/* 4960 */       setNClobInternal(paramInt, paramNClob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(int paramInt, String paramString) throws SQLException {
/* 4968 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4972 */       this.atLeastOneOrdinalParameter = true;
/* 4973 */       setNStringInternal(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt, Object paramObject) throws SQLException {
/* 4982 */     this.atLeastOneOrdinalParameter = true;
/* 4983 */     setObjectInternal(paramInt, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/* 4991 */     this.atLeastOneOrdinalParameter = true;
/* 4992 */     setObjectInternal(paramInt1, paramObject, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(int paramInt, Ref paramRef) throws SQLException {
/* 5000 */     this.atLeastOneOrdinalParameter = true;
/* 5001 */     setRefInternal(paramInt, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowId(int paramInt, RowId paramRowId) throws SQLException {
/* 5008 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5012 */       this.atLeastOneOrdinalParameter = true;
/* 5013 */       setRowIdInternal(paramInt, paramRowId);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int paramInt, short paramShort) throws SQLException {
/* 5021 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5025 */       this.atLeastOneOrdinalParameter = true;
/* 5026 */       setShortInternal(paramInt, paramShort);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/* 5034 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5038 */       this.atLeastOneOrdinalParameter = true;
/* 5039 */       setSQLXMLInternal(paramInt, paramSQLXML);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int paramInt, String paramString) throws SQLException {
/* 5047 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5051 */       this.atLeastOneOrdinalParameter = true;
/* 5052 */       setStringInternal(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime) throws SQLException {
/* 5060 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5064 */       this.atLeastOneOrdinalParameter = true;
/* 5065 */       setTimeInternal(paramInt, paramTime);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 5073 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5077 */       this.atLeastOneOrdinalParameter = true;
/* 5078 */       setTimeInternal(paramInt, paramTime, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/* 5086 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5090 */       this.atLeastOneOrdinalParameter = true;
/* 5091 */       setTimestampInternal(paramInt, paramTimestamp);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 5099 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5103 */       this.atLeastOneOrdinalParameter = true;
/* 5104 */       setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/* 5112 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5116 */       this.atLeastOneOrdinalParameter = true;
/* 5117 */       setURLInternal(paramInt, paramURL);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/* 5126 */     this.atLeastOneOrdinalParameter = true;
/* 5127 */     setARRAYInternal(paramInt, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/* 5134 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5138 */       this.atLeastOneOrdinalParameter = true;
/* 5139 */       setBFILEInternal(paramInt, paramBFILE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/* 5147 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5151 */       this.atLeastOneOrdinalParameter = true;
/* 5152 */       setBfileInternal(paramInt, paramBFILE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/* 5160 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5164 */       this.atLeastOneOrdinalParameter = true;
/* 5165 */       setBinaryFloatInternal(paramInt, paramFloat);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 5173 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5177 */       this.atLeastOneOrdinalParameter = true;
/* 5178 */       setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/* 5186 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5190 */       this.atLeastOneOrdinalParameter = true;
/* 5191 */       setBinaryDoubleInternal(paramInt, paramDouble);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 5199 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5203 */       this.atLeastOneOrdinalParameter = true;
/* 5204 */       setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/* 5212 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5216 */       this.atLeastOneOrdinalParameter = true;
/* 5217 */       setBLOBInternal(paramInt, paramBLOB);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/* 5225 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5229 */       this.atLeastOneOrdinalParameter = true;
/* 5230 */       setCHARInternal(paramInt, paramCHAR);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/* 5238 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5242 */       this.atLeastOneOrdinalParameter = true;
/* 5243 */       setCLOBInternal(paramInt, paramCLOB);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/* 5251 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5255 */       this.atLeastOneOrdinalParameter = true;
/* 5256 */       setCursorInternal(paramInt, paramResultSet);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/* 5265 */     this.atLeastOneOrdinalParameter = true;
/* 5266 */     setCustomDatumInternal(paramInt, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(int paramInt, DATE paramDATE) throws SQLException {
/* 5273 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5277 */       this.atLeastOneOrdinalParameter = true;
/* 5278 */       setDATEInternal(paramInt, paramDATE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException {
/* 5286 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5290 */       this.atLeastOneOrdinalParameter = true;
/* 5291 */       setFixedCHARInternal(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/* 5299 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5303 */       this.atLeastOneOrdinalParameter = true;
/* 5304 */       setINTERVALDSInternal(paramInt, paramINTERVALDS);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/* 5312 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5316 */       this.atLeastOneOrdinalParameter = true;
/* 5317 */       setINTERVALYMInternal(paramInt, paramINTERVALYM);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/* 5325 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5329 */       this.atLeastOneOrdinalParameter = true;
/* 5330 */       setNUMBERInternal(paramInt, paramNUMBER);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/* 5339 */     this.atLeastOneOrdinalParameter = true;
/* 5340 */     setOPAQUEInternal(paramInt, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/* 5348 */     this.atLeastOneOrdinalParameter = true;
/* 5349 */     setOracleObjectInternal(paramInt, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(int paramInt, ORAData paramORAData) throws SQLException {
/* 5357 */     this.atLeastOneOrdinalParameter = true;
/* 5358 */     setORADataInternal(paramInt, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(int paramInt, RAW paramRAW) throws SQLException {
/* 5365 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5369 */       this.atLeastOneOrdinalParameter = true;
/* 5370 */       setRAWInternal(paramInt, paramRAW);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(int paramInt, REF paramREF) throws SQLException {
/* 5379 */     this.atLeastOneOrdinalParameter = true;
/* 5380 */     setREFInternal(paramInt, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(int paramInt, REF paramREF) throws SQLException {
/* 5388 */     this.atLeastOneOrdinalParameter = true;
/* 5389 */     setRefTypeInternal(paramInt, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException {
/* 5396 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5400 */       this.atLeastOneOrdinalParameter = true;
/* 5401 */       setROWIDInternal(paramInt, paramROWID);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/* 5410 */     this.atLeastOneOrdinalParameter = true;
/* 5411 */     setSTRUCTInternal(paramInt, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 5418 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5422 */       this.atLeastOneOrdinalParameter = true;
/* 5423 */       setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 5431 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5435 */       this.atLeastOneOrdinalParameter = true;
/* 5436 */       setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 5444 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5448 */       this.atLeastOneOrdinalParameter = true;
/* 5449 */       setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 5457 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5461 */       this.atLeastOneOrdinalParameter = true;
/* 5462 */       setBlobInternal(paramInt, paramInputStream);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 5470 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 5473 */       if (paramLong < 0L) {
/*      */         
/* 5475 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 5476 */         sQLException.fillInStackTrace();
/* 5477 */         throw sQLException;
/*      */       } 
/*      */       
/* 5480 */       this.atLeastOneOrdinalParameter = true;
/* 5481 */       setBlobInternal(paramInt, paramInputStream, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Reader paramReader) throws SQLException {
/* 5489 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5493 */       this.atLeastOneOrdinalParameter = true;
/* 5494 */       setClobInternal(paramInt, paramReader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5502 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5506 */       if (paramLong < 0L) {
/*      */         
/* 5508 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 5509 */         sQLException.fillInStackTrace();
/* 5510 */         throw sQLException;
/*      */       } 
/* 5512 */       this.atLeastOneOrdinalParameter = true;
/* 5513 */       setClobInternal(paramInt, paramReader, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, Reader paramReader) throws SQLException {
/* 5521 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5525 */       this.atLeastOneOrdinalParameter = true;
/* 5526 */       setNClobInternal(paramInt, paramReader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5534 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5538 */       this.atLeastOneOrdinalParameter = true;
/* 5539 */       setNClobInternal(paramInt, paramReader, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 5547 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5551 */       this.atLeastOneOrdinalParameter = true;
/* 5552 */       setAsciiStreamInternal(paramInt, paramInputStream);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5560 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5564 */       this.atLeastOneOrdinalParameter = true;
/* 5565 */       setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 5573 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5577 */       this.atLeastOneOrdinalParameter = true;
/* 5578 */       setAsciiStreamInternal(paramInt, paramInputStream, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 5586 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5590 */       this.atLeastOneOrdinalParameter = true;
/* 5591 */       setBinaryStreamInternal(paramInt, paramInputStream);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5599 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5603 */       this.atLeastOneOrdinalParameter = true;
/* 5604 */       setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 5612 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5616 */       this.atLeastOneOrdinalParameter = true;
/* 5617 */       setBinaryStreamInternal(paramInt, paramInputStream, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 5625 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5629 */       this.atLeastOneOrdinalParameter = true;
/* 5630 */       setCharacterStreamInternal(paramInt, paramReader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 5638 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5642 */       this.atLeastOneOrdinalParameter = true;
/* 5643 */       setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5651 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5655 */       this.atLeastOneOrdinalParameter = true;
/* 5656 */       setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 5664 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5668 */       this.atLeastOneOrdinalParameter = true;
/* 5669 */       setNCharacterStreamInternal(paramInt, paramReader);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5677 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5681 */       this.atLeastOneOrdinalParameter = true;
/* 5682 */       setNCharacterStreamInternal(paramInt, paramReader, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5690 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5694 */       this.atLeastOneOrdinalParameter = true;
/* 5695 */       setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(String paramString, Array paramArray) throws SQLException {
/* 5707 */     int i = addNamedPara(paramString);
/* 5708 */     setArrayInternal(i, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/* 5718 */     int i = addNamedPara(paramString);
/* 5719 */     setBigDecimalInternal(i, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, Blob paramBlob) throws SQLException {
/* 5729 */     int i = addNamedPara(paramString);
/* 5730 */     setBlobInternal(i, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
/* 5740 */     int i = addNamedPara(paramString);
/* 5741 */     setBooleanInternal(i, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte) throws SQLException {
/* 5751 */     int i = addNamedPara(paramString);
/* 5752 */     setByteInternal(i, paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 5762 */     int i = addNamedPara(paramString);
/* 5763 */     setBytesInternal(i, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Clob paramClob) throws SQLException {
/* 5773 */     int i = addNamedPara(paramString);
/* 5774 */     setClobInternal(i, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate) throws SQLException {
/* 5784 */     int i = addNamedPara(paramString);
/* 5785 */     setDateInternal(i, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 5795 */     int i = addNamedPara(paramString);
/* 5796 */     setDateInternal(i, paramDate, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLException {
/* 5806 */     int i = addNamedPara(paramString);
/* 5807 */     setDoubleInternal(i, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLException {
/* 5817 */     int i = addNamedPara(paramString);
/* 5818 */     setFloatInternal(i, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt) throws SQLException {
/* 5828 */     int i = addNamedPara(paramString);
/* 5829 */     setIntInternal(i, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong) throws SQLException {
/* 5839 */     int i = addNamedPara(paramString);
/* 5840 */     setLongInternal(i, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, NClob paramNClob) throws SQLException {
/* 5850 */     int i = addNamedPara(paramString);
/* 5851 */     setNClobInternal(i, paramNClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(String paramString1, String paramString2) throws SQLException {
/* 5861 */     int i = addNamedPara(paramString1);
/* 5862 */     setNStringInternal(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject) throws SQLException {
/* 5872 */     int i = addNamedPara(paramString);
/* 5873 */     setObjectInternal(i, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/* 5883 */     int i = addNamedPara(paramString);
/* 5884 */     setObjectInternal(i, paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(String paramString, Ref paramRef) throws SQLException {
/* 5894 */     int i = addNamedPara(paramString);
/* 5895 */     setRefInternal(i, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowId(String paramString, RowId paramRowId) throws SQLException {
/* 5905 */     int i = addNamedPara(paramString);
/* 5906 */     setRowIdInternal(i, paramRowId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort) throws SQLException {
/* 5916 */     int i = addNamedPara(paramString);
/* 5917 */     setShortInternal(i, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
/* 5927 */     int i = addNamedPara(paramString);
/* 5928 */     setSQLXMLInternal(i, paramSQLXML);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) throws SQLException {
/* 5938 */     int i = addNamedPara(paramString1);
/* 5939 */     setStringInternal(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime) throws SQLException {
/* 5949 */     int i = addNamedPara(paramString);
/* 5950 */     setTimeInternal(i, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 5960 */     int i = addNamedPara(paramString);
/* 5961 */     setTimeInternal(i, paramTime, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/* 5971 */     int i = addNamedPara(paramString);
/* 5972 */     setTimestampInternal(i, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 5982 */     int i = addNamedPara(paramString);
/* 5983 */     setTimestampInternal(i, paramTimestamp, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String paramString, URL paramURL) throws SQLException {
/* 5993 */     int i = addNamedPara(paramString);
/* 5994 */     setURLInternal(i, paramURL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/* 6004 */     int i = addNamedPara(paramString);
/* 6005 */     setARRAYInternal(i, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/* 6015 */     int i = addNamedPara(paramString);
/* 6016 */     setBFILEInternal(i, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
/* 6026 */     int i = addNamedPara(paramString);
/* 6027 */     setBfileInternal(i, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
/* 6037 */     int i = addNamedPara(paramString);
/* 6038 */     setBinaryFloatInternal(i, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 6048 */     int i = addNamedPara(paramString);
/* 6049 */     setBinaryFloatInternal(i, paramBINARY_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
/* 6059 */     int i = addNamedPara(paramString);
/* 6060 */     setBinaryDoubleInternal(i, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 6070 */     int i = addNamedPara(paramString);
/* 6071 */     setBinaryDoubleInternal(i, paramBINARY_DOUBLE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/* 6081 */     int i = addNamedPara(paramString);
/* 6082 */     setBLOBInternal(i, paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/* 6092 */     int i = addNamedPara(paramString);
/* 6093 */     setCHARInternal(i, paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/* 6103 */     int i = addNamedPara(paramString);
/* 6104 */     setCLOBInternal(i, paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/* 6114 */     int i = addNamedPara(paramString);
/* 6115 */     setCursorInternal(i, paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 6125 */     int i = addNamedPara(paramString);
/* 6126 */     setCustomDatumInternal(i, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(String paramString, DATE paramDATE) throws SQLException {
/* 6136 */     int i = addNamedPara(paramString);
/* 6137 */     setDATEInternal(i, paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
/* 6147 */     int i = addNamedPara(paramString1);
/* 6148 */     setFixedCHARInternal(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 6158 */     int i = addNamedPara(paramString);
/* 6159 */     setINTERVALDSInternal(i, paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 6169 */     int i = addNamedPara(paramString);
/* 6170 */     setINTERVALYMInternal(i, paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 6180 */     int i = addNamedPara(paramString);
/* 6181 */     setNUMBERInternal(i, paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 6191 */     int i = addNamedPara(paramString);
/* 6192 */     setOPAQUEInternal(i, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
/* 6202 */     int i = addNamedPara(paramString);
/* 6203 */     setOracleObjectInternal(i, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
/* 6213 */     int i = addNamedPara(paramString);
/* 6214 */     setORADataInternal(i, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(String paramString, RAW paramRAW) throws SQLException {
/* 6224 */     int i = addNamedPara(paramString);
/* 6225 */     setRAWInternal(i, paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(String paramString, REF paramREF) throws SQLException {
/* 6235 */     int i = addNamedPara(paramString);
/* 6236 */     setREFInternal(i, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(String paramString, REF paramREF) throws SQLException {
/* 6246 */     int i = addNamedPara(paramString);
/* 6247 */     setRefTypeInternal(i, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
/* 6257 */     int i = addNamedPara(paramString);
/* 6258 */     setROWIDInternal(i, paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 6268 */     int i = addNamedPara(paramString);
/* 6269 */     setSTRUCTInternal(i, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 6279 */     int i = addNamedPara(paramString);
/* 6280 */     setTIMESTAMPLTZInternal(i, paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 6290 */     int i = addNamedPara(paramString);
/* 6291 */     setTIMESTAMPTZInternal(i, paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 6301 */     int i = addNamedPara(paramString);
/* 6302 */     setTIMESTAMPInternal(i, paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, InputStream paramInputStream) throws SQLException {
/* 6312 */     int i = addNamedPara(paramString);
/* 6313 */     setBlobInternal(i, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 6322 */     if (paramLong < 0L) {
/*      */       
/* 6324 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 6325 */       sQLException.fillInStackTrace();
/* 6326 */       throw sQLException;
/*      */     } 
/*      */     
/* 6329 */     int i = addNamedPara(paramString);
/* 6330 */     setBlobInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Reader paramReader) throws SQLException {
/* 6340 */     int i = addNamedPara(paramString);
/* 6341 */     setClobInternal(i, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6351 */     if (paramLong < 0L) {
/*      */       
/* 6353 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 6354 */       sQLException.fillInStackTrace();
/* 6355 */       throw sQLException;
/*      */     } 
/* 6357 */     int i = addNamedPara(paramString);
/* 6358 */     setClobInternal(i, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, Reader paramReader) throws SQLException {
/* 6368 */     int i = addNamedPara(paramString);
/* 6369 */     setNClobInternal(i, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6379 */     int i = addNamedPara(paramString);
/* 6380 */     setNClobInternal(i, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 6390 */     int i = addNamedPara(paramString);
/* 6391 */     setAsciiStreamInternal(i, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6401 */     int i = addNamedPara(paramString);
/* 6402 */     setAsciiStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 6412 */     int i = addNamedPara(paramString);
/* 6413 */     setAsciiStreamInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 6423 */     int i = addNamedPara(paramString);
/* 6424 */     setBinaryStreamInternal(i, paramInputStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6434 */     int i = addNamedPara(paramString);
/* 6435 */     setBinaryStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 6445 */     int i = addNamedPara(paramString);
/* 6446 */     setBinaryStreamInternal(i, paramInputStream, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 6456 */     int i = addNamedPara(paramString);
/* 6457 */     setCharacterStreamInternal(i, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 6467 */     int i = addNamedPara(paramString);
/* 6468 */     setCharacterStreamInternal(i, paramReader, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6478 */     int i = addNamedPara(paramString);
/* 6479 */     setCharacterStreamInternal(i, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 6489 */     int i = addNamedPara(paramString);
/* 6490 */     setNCharacterStreamInternal(i, paramReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6500 */     int i = addNamedPara(paramString);
/* 6501 */     setNCharacterStreamInternal(i, paramReader, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6511 */     int i = addNamedPara(paramString);
/* 6512 */     setUnicodeStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 6523 */     int i = addNamedPara(paramString1);
/* 6524 */     setNullInternal(i, paramInt, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString, int paramInt) throws SQLException {
/* 6535 */     int i = addNamedPara(paramString);
/* 6536 */     setNullInternal(i, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 6545 */     int i = addNamedPara(paramString);
/* 6546 */     setStructDescriptorInternal(i, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 6557 */     int i = addNamedPara(paramString);
/* 6558 */     setObjectInternal(i, paramObject, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException {
/* 6570 */     synchronized (this.connection) {
/*      */       
/* 6572 */       this.atLeastOneOrdinalParameter = true;
/* 6573 */       setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int addNamedPara(String paramString) throws SQLException {
/* 6591 */     if (this.closed) {
/*      */       
/* 6593 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6594 */       sQLException.fillInStackTrace();
/* 6595 */       throw sQLException;
/*      */     } 
/*      */     
/* 6598 */     String str = paramString.toUpperCase().intern();
/*      */     
/* 6600 */     for (byte b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6602 */       if (str == this.namedParameters[b]) {
/* 6603 */         return b + 1;
/*      */       }
/*      */     } 
/* 6606 */     if (this.parameterCount >= this.namedParameters.length) {
/*      */       
/* 6608 */       String[] arrayOfString = new String[this.namedParameters.length * 2];
/* 6609 */       System.arraycopy(this.namedParameters, 0, arrayOfString, 0, this.namedParameters.length);
/* 6610 */       this.namedParameters = arrayOfString;
/*      */     } 
/*      */     
/* 6613 */     this.namedParameters[this.parameterCount++] = str;
/*      */     
/* 6615 */     this.atLeastOneNamedParameter = true;
/* 6616 */     return this.parameterCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/* 6626 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6629 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6630 */       sQLException.fillInStackTrace();
/* 6631 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6635 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6638 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6640 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6643 */     b++;
/*      */     
/* 6645 */     Accessor accessor = null;
/* 6646 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6651 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6652 */       sQLException.fillInStackTrace();
/* 6653 */       throw sQLException;
/*      */     } 
/*      */     
/* 6656 */     this.lastIndex = b;
/*      */     
/* 6658 */     if (this.streamList != null) {
/* 6659 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6662 */     return accessor.getCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/* 6670 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6673 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6674 */       sQLException.fillInStackTrace();
/* 6675 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6679 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6682 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6684 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6687 */     b++;
/*      */     
/* 6689 */     Accessor accessor = null;
/* 6690 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6695 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6696 */       sQLException.fillInStackTrace();
/* 6697 */       throw sQLException;
/*      */     } 
/*      */     
/* 6700 */     this.lastIndex = b;
/*      */     
/* 6702 */     if (this.streamList != null) {
/* 6703 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6706 */     return accessor.getUnicodeStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/* 6714 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6717 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6718 */       sQLException.fillInStackTrace();
/* 6719 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6723 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6726 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6728 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6731 */     b++;
/*      */     
/* 6733 */     Accessor accessor = null;
/* 6734 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6739 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6740 */       sQLException.fillInStackTrace();
/* 6741 */       throw sQLException;
/*      */     } 
/*      */     
/* 6744 */     this.lastIndex = b;
/*      */     
/* 6746 */     if (this.streamList != null) {
/* 6747 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6750 */     return accessor.getBinaryStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 6763 */     if (this.closed) {
/*      */       
/* 6765 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6766 */       sQLException.fillInStackTrace();
/* 6767 */       throw sQLException;
/*      */     } 
/*      */     
/* 6770 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6773 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6774 */       sQLException.fillInStackTrace();
/* 6775 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6779 */     Accessor accessor = null;
/* 6780 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6785 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6786 */       sQLException.fillInStackTrace();
/* 6787 */       throw sQLException;
/*      */     } 
/*      */     
/* 6790 */     this.lastIndex = paramInt;
/*      */     
/* 6792 */     if (this.streamList != null) {
/* 6793 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 6796 */     return (RowId)accessor.getROWID(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(String paramString) throws SQLException {
/* 6804 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6807 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6808 */       sQLException.fillInStackTrace();
/* 6809 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6813 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6816 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6818 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6821 */     b++;
/*      */     
/* 6823 */     Accessor accessor = null;
/* 6824 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6829 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6830 */       sQLException.fillInStackTrace();
/* 6831 */       throw sQLException;
/*      */     } 
/*      */     
/* 6834 */     this.lastIndex = b;
/*      */     
/* 6836 */     if (this.streamList != null) {
/* 6837 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6840 */     return (RowId)accessor.getROWID(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 6849 */     if (this.closed) {
/*      */       
/* 6851 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6852 */       sQLException.fillInStackTrace();
/* 6853 */       throw sQLException;
/*      */     } 
/*      */     
/* 6856 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6859 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6860 */       sQLException.fillInStackTrace();
/* 6861 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6865 */     Accessor accessor = null;
/* 6866 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6871 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6872 */       sQLException.fillInStackTrace();
/* 6873 */       throw sQLException;
/*      */     } 
/*      */     
/* 6876 */     this.lastIndex = paramInt;
/*      */     
/* 6878 */     if (this.streamList != null) {
/* 6879 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 6882 */     return accessor.getNClob(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(String paramString) throws SQLException {
/* 6890 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6893 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6894 */       sQLException.fillInStackTrace();
/* 6895 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6899 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6902 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6904 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6907 */     b++;
/*      */     
/* 6909 */     Accessor accessor = null;
/* 6910 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6915 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6916 */       sQLException.fillInStackTrace();
/* 6917 */       throw sQLException;
/*      */     } 
/*      */     
/* 6920 */     this.lastIndex = b;
/*      */     
/* 6922 */     if (this.streamList != null) {
/* 6923 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6926 */     return accessor.getNClob(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 6934 */     if (this.closed) {
/*      */       
/* 6936 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6937 */       sQLException.fillInStackTrace();
/* 6938 */       throw sQLException;
/*      */     } 
/*      */     
/* 6941 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6944 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6945 */       sQLException.fillInStackTrace();
/* 6946 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6950 */     Accessor accessor = null;
/* 6951 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6956 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 6957 */       sQLException.fillInStackTrace();
/* 6958 */       throw sQLException;
/*      */     } 
/*      */     
/* 6961 */     this.lastIndex = paramInt;
/*      */     
/* 6963 */     if (this.streamList != null) {
/* 6964 */       closeUsedStreams(paramInt);
/*      */     }
/* 6966 */     return accessor.getSQLXML(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(String paramString) throws SQLException {
/* 6974 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6977 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6978 */       sQLException.fillInStackTrace();
/* 6979 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6983 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6986 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6988 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6991 */     b++;
/*      */     
/* 6993 */     Accessor accessor = null;
/* 6994 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6999 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7000 */       sQLException.fillInStackTrace();
/* 7001 */       throw sQLException;
/*      */     } 
/*      */     
/* 7004 */     this.lastIndex = b;
/*      */     
/* 7006 */     if (this.streamList != null) {
/* 7007 */       closeUsedStreams(b);
/*      */     }
/* 7009 */     return accessor.getSQLXML(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 7018 */     if (this.closed) {
/*      */       
/* 7020 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 7021 */       sQLException.fillInStackTrace();
/* 7022 */       throw sQLException;
/*      */     } 
/*      */     
/* 7025 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7028 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7029 */       sQLException.fillInStackTrace();
/* 7030 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7034 */     Accessor accessor = null;
/* 7035 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7040 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 7041 */       sQLException.fillInStackTrace();
/* 7042 */       throw sQLException;
/*      */     } 
/*      */     
/* 7045 */     this.lastIndex = paramInt;
/*      */     
/* 7047 */     if (this.streamList != null) {
/* 7048 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 7051 */     return accessor.getNString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(String paramString) throws SQLException {
/* 7059 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7062 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7063 */       sQLException.fillInStackTrace();
/* 7064 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7068 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 7071 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 7073 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 7076 */     b++;
/*      */     
/* 7078 */     Accessor accessor = null;
/* 7079 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7084 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7085 */       sQLException.fillInStackTrace();
/* 7086 */       throw sQLException;
/*      */     } 
/*      */     
/* 7089 */     this.lastIndex = b;
/*      */     
/* 7091 */     if (this.streamList != null) {
/* 7092 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 7095 */     return accessor.getNString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 7104 */     if (this.closed) {
/*      */       
/* 7106 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 7107 */       sQLException.fillInStackTrace();
/* 7108 */       throw sQLException;
/*      */     } 
/*      */     
/* 7111 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7115 */       sQLException.fillInStackTrace();
/* 7116 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7120 */     Accessor accessor = null;
/* 7121 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7126 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 7127 */       sQLException.fillInStackTrace();
/* 7128 */       throw sQLException;
/*      */     } 
/*      */     
/* 7131 */     this.lastIndex = paramInt;
/*      */     
/* 7133 */     if (this.streamList != null) {
/* 7134 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 7137 */     return accessor.getNCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(String paramString) throws SQLException {
/* 7145 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 7148 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 7149 */       sQLException.fillInStackTrace();
/* 7150 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 7154 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 7157 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 7159 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 7162 */     b++;
/*      */     
/* 7164 */     Accessor accessor = null;
/* 7165 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7170 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 7171 */       sQLException.fillInStackTrace();
/* 7172 */       throw sQLException;
/*      */     } 
/*      */     
/* 7175 */     this.lastIndex = b;
/*      */     
/* 7177 */     if (this.streamList != null) {
/* 7178 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 7181 */     return accessor.getNCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7188 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleCallableStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */