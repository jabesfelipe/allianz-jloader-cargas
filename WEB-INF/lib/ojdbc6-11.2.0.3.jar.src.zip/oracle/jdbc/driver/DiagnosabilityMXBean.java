package oracle.jdbc.driver;

public interface DiagnosabilityMXBean {
  boolean stateManageable();
  
  boolean statisticsProvider();
  
  boolean getLoggingEnabled();
  
  void setLoggingEnabled(boolean paramBoolean);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\DiagnosabilityMXBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */