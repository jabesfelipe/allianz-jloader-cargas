/*      */ package oracle.jdbc.driver;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigInteger;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.OracleOCIFailover;
/*      */ import oracle.jdbc.OracleSavepoint;
/*      */ import oracle.jdbc.aq.AQDequeueOptions;
/*      */ import oracle.jdbc.aq.AQMessage;
/*      */ import oracle.jdbc.aq.AQNotificationRegistration;
/*      */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*      */ import oracle.jdbc.internal.KeywordValueLong;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.internal.XSEventListener;
/*      */ import oracle.jdbc.internal.XSNamespace;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ import oracle.jdbc.oracore.OracleTypeCLOB;
/*      */ import oracle.jdbc.pool.OracleConnectionCacheCallback;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.NCLOB;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ public class T2CConnection extends PhysicalConnection implements BfileDBAccess, BlobDBAccess, ClobDBAccess {
/*   60 */   static final long JDBC_OCI_LIBRARY_VERSION = Long.parseLong("11.2.0.3.0".replaceAll("\\.", ""));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   66 */   short[] queryMetaData1 = null;
/*   67 */   byte[] queryMetaData2 = null;
/*   68 */   int queryMetaData1Offset = 0;
/*   69 */   int queryMetaData2Offset = 0;
/*      */   private String password;
/*   71 */   int fatalErrorNumber = 0;
/*   72 */   String fatalErrorMessage = null;
/*      */   
/*      */   static final int QMD_dbtype = 0;
/*      */   
/*      */   static final int QMD_dbsize = 1;
/*      */   
/*      */   static final int QMD_nullok = 2;
/*      */   
/*      */   static final int QMD_precision = 3;
/*      */   
/*      */   static final int QMD_scale = 4;
/*      */   
/*      */   static final int QMD_formOfUse = 5;
/*      */   
/*      */   static final int QMD_columnNameLength = 6;
/*      */   
/*      */   static final int QMD_tdo0 = 7;
/*      */   
/*      */   static final int QMD_tdo1 = 8;
/*      */   
/*      */   static final int QMD_tdo2 = 9;
/*      */   
/*      */   static final int QMD_tdo3 = 10;
/*      */   
/*      */   static final int QMD_charLength = 11;
/*      */   
/*      */   static final int QMD_typeNameLength = 12;
/*      */   
/*      */   static final int T2C_LOCATOR_MAX_LEN = 16;
/*      */   static final int T2C_LINEARIZED_LOCATOR_MAX_LEN = 4000;
/*      */   static final int T2C_LINEARIZED_BFILE_LOCATOR_MAX_LEN = 530;
/*      */   static final int METADATA1_INDICES_PER_COLUMN = 13;
/*      */   protected static final int SIZEOF_QUERYMETADATA2 = 8;
/*      */   static final String defaultDriverNameAttribute = "jdbcoci";
/*  106 */   int queryMetaData1Size = 100;
/*  107 */   int queryMetaData2Size = 800;
/*      */   
/*      */   long m_nativeState;
/*      */   
/*      */   short m_clientCharacterSet;
/*      */   
/*      */   byte byteAlign;
/*      */   
/*      */   private static final int EOJ_SUCCESS = 0;
/*      */   
/*      */   private static final int EOJ_ERROR = -1;
/*      */   
/*      */   private static final int EOJ_WARNING = 1;
/*      */   
/*      */   private static final int EOJ_GET_STORAGE_ERROR = -4;
/*      */   
/*      */   private static final int EOJ_ORA3113_SERVER_NORMAL = -6;
/*      */   
/*      */   private static final String OCILIBRARY = "ocijdbc11";
/*  126 */   private int logon_mode = 0;
/*      */   
/*      */   static final int LOGON_MODE_DEFAULT = 0;
/*      */   
/*      */   static final int LOGON_MODE_SYSDBA = 2;
/*      */   
/*      */   static final int LOGON_MODE_SYSOPER = 4;
/*      */   
/*      */   static final int LOGON_MODE_SYSASM = 32768;
/*      */   
/*      */   static final int LOGON_MODE_CONNECTION_POOL = 5;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_CONNECTION = 6;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_PROXY_CONNECTION = 7;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_ALIASED_CONNECTION = 8;
/*      */   
/*      */   static final int T2C_PROXYTYPE_NONE = 0;
/*      */   
/*      */   static final int T2C_PROXYTYPE_USER_NAME = 1;
/*      */   
/*      */   static final int T2C_PROXYTYPE_DISTINGUISHED_NAME = 2;
/*      */   static final int T2C_PROXYTYPE_CERTIFICATE = 3;
/*      */   static final int T2C_CONNECTION_FLAG_DEFAULT_LOB_PREFETCH = 0;
/*      */   static final int T2C_CONNECTION_FLAG_PRELIM_AUTH = 1;
/*      */   private static boolean isLibraryLoaded;
/*  153 */   OracleOCIFailover appCallback = null;
/*  154 */   Object appCallbackObject = null;
/*      */   
/*      */   private Properties nativeInfo;
/*      */   
/*      */   ByteBuffer nioBufferForLob;
/*      */ 
/*      */   
/*      */   protected T2CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException {
/*  162 */     super(paramString, paramProperties, paramOracleDriverExtension);
/*      */ 
/*      */     
/*  165 */     initialize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initializePassword(String paramString) throws SQLException {
/*  172 */     this.password = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initialize() {
/*  179 */     allocQueryMetaDataBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void allocQueryMetaDataBuffers() {
/*  211 */     this.queryMetaData1Offset = 0;
/*  212 */     this.queryMetaData1 = new short[this.queryMetaData1Size * 13];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  217 */     this.queryMetaData2Offset = 0;
/*  218 */     this.queryMetaData2 = new byte[this.queryMetaData2Size];
/*      */     
/*  220 */     this.namedTypeAccessorByteLen = 0;
/*  221 */     this.refTypeAccessorByteLen = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reallocateQueryMetaData(int paramInt1, int paramInt2) {
/*  228 */     this.queryMetaData1 = null;
/*  229 */     this.queryMetaData2 = null;
/*      */     
/*  231 */     this.queryMetaData1Size = Math.max(paramInt1, this.queryMetaData1Size);
/*  232 */     this.queryMetaData2Size = Math.max(paramInt2, this.queryMetaData2Size);
/*      */     
/*  234 */     allocQueryMetaDataBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logon() throws SQLException {
/*  258 */     if (this.database == null) {
/*      */       
/*  260 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 64);
/*  261 */       sQLException.fillInStackTrace();
/*  262 */       throw sQLException;
/*      */     } 
/*      */     
/*  265 */     if (!isLibraryLoaded) {
/*  266 */       loadNativeLibrary(this.ocidll);
/*      */     }
/*      */ 
/*      */     
/*  270 */     if (this.ociConnectionPoolIsPooling) {
/*      */       
/*  272 */       processOCIConnectionPooling();
/*      */     }
/*      */     else {
/*      */       
/*  276 */       long l1 = this.ociSvcCtxHandle;
/*  277 */       long l2 = this.ociEnvHandle;
/*  278 */       long l3 = this.ociErrHandle;
/*      */ 
/*      */       
/*  281 */       if (l1 != 0L && l2 != 0L) {
/*      */ 
/*      */         
/*  284 */         if (this.ociDriverCharset != null) {
/*  285 */           this.m_clientCharacterSet = (new Integer(this.ociDriverCharset)).shortValue();
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  290 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  291 */           sQLException.fillInStackTrace();
/*  292 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  298 */         this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */         
/*  301 */         short[] arrayOfShort1 = new short[5];
/*  302 */         long[] arrayOfLong1 = { this.defaultLobPrefetchSize };
/*      */         
/*  304 */         this.sqlWarning = checkError(t2cUseConnection(this.m_nativeState, l2, l1, l3, arrayOfShort1, arrayOfLong1), this.sqlWarning);
/*      */ 
/*      */ 
/*      */         
/*  308 */         this.conversion = new DBConversion(arrayOfShort1[0], this.m_clientCharacterSet, arrayOfShort1[1]);
/*  309 */         this.byteAlign = (byte)(arrayOfShort1[2] & 0xFF);
/*  310 */         this.timeZoneVersionNumber = (arrayOfShort1[3] << 16) + (arrayOfShort1[4] & 0xFFFF);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/*  317 */       if (this.internalLogon == null) {
/*  318 */         this.logon_mode = 0;
/*  319 */       } else if (this.internalLogon.equalsIgnoreCase("SYSDBA")) {
/*  320 */         this.logon_mode = 2;
/*  321 */       } else if (this.internalLogon.equalsIgnoreCase("SYSOPER")) {
/*  322 */         this.logon_mode = 4;
/*  323 */       } else if (this.internalLogon.equalsIgnoreCase("SYSASM")) {
/*  324 */         this.logon_mode = 32768;
/*      */       } 
/*  326 */       byte[] arrayOfByte1 = null;
/*  327 */       byte[] arrayOfByte2 = null;
/*  328 */       byte[] arrayOfByte3 = null;
/*  329 */       String str1 = this.setNewPassword;
/*  330 */       byte[] arrayOfByte4 = new byte[0];
/*  331 */       byte[] arrayOfByte5 = new byte[0];
/*  332 */       byte[] arrayOfByte6 = new byte[0];
/*      */       
/*  334 */       if (this.nlsLangBackdoor) {
/*      */ 
/*      */         
/*  337 */         this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG(this.ocidll);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  342 */         this.m_clientCharacterSet = getClientCharSetId();
/*      */       } 
/*      */       
/*  345 */       if (str1 != null) {
/*  346 */         arrayOfByte4 = DBConversion.stringToDriverCharBytes(str1, this.m_clientCharacterSet);
/*      */       }
/*  348 */       if (this.editionName != null) {
/*  349 */         arrayOfByte5 = DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
/*      */       }
/*  351 */       if (this.driverNameAttribute == null) {
/*  352 */         arrayOfByte6 = DBConversion.stringToDriverCharBytes("jdbcoci", this.m_clientCharacterSet);
/*      */       } else {
/*  354 */         arrayOfByte6 = DBConversion.stringToDriverCharBytes(this.driverNameAttribute, this.m_clientCharacterSet);
/*      */       } 
/*  356 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  359 */       arrayOfByte2 = (this.proxyClientName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.proxyClientName, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  362 */       arrayOfByte3 = (this.password == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  365 */       byte[] arrayOfByte7 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
/*      */       
/*  367 */       short[] arrayOfShort = new short[5];
/*  368 */       String str2 = null;
/*  369 */       byte[] arrayOfByte8 = ((str2 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault())) != null) ? str2.getBytes() : null;
/*      */       
/*  371 */       byte[] arrayOfByte9 = ((str2 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault())) != null) ? str2.getBytes() : null;
/*      */ 
/*      */       
/*  374 */       if (arrayOfByte8 == null || arrayOfByte9 == null) {
/*      */         
/*  376 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/*  377 */         sQLException.fillInStackTrace();
/*  378 */         throw sQLException;
/*      */       } 
/*      */       
/*  381 */       TimeZone timeZone = TimeZone.getDefault();
/*  382 */       String str3 = timeZone.getID();
/*      */       
/*  384 */       if (!ZONEIDMAP.isValidRegion(str3) || !this.timezoneAsRegion) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  393 */         int i = timeZone.getOffset(System.currentTimeMillis());
/*  394 */         int j = i / 3600000;
/*  395 */         int k = i / 60000 % 60;
/*      */         
/*  397 */         str3 = ((j < 0) ? ("" + j) : ("+" + j)) + ((k < 10) ? (":0" + k) : (":" + k));
/*      */       } 
/*      */ 
/*      */       
/*  401 */       doSetSessionTimeZone(str3);
/*      */ 
/*      */       
/*  404 */       this.sessionTimeZone = str3;
/*      */ 
/*      */       
/*  407 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  410 */       long[] arrayOfLong = { this.defaultLobPrefetchSize, (this.prelimAuth ? 1L : 0L) };
/*      */       
/*  412 */       if (this.m_nativeState == 0L) {
/*      */         
/*  414 */         this.sqlWarning = checkError(t2cCreateState(arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, arrayOfByte6, arrayOfByte6.length, arrayOfByte7, arrayOfByte7.length, this.m_clientCharacterSet, this.logon_mode, arrayOfShort, arrayOfByte8, arrayOfByte9, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  429 */         this.sqlWarning = checkError(t2cLogon(this.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, arrayOfByte6, arrayOfByte6.length, arrayOfByte7, arrayOfByte7.length, this.logon_mode, arrayOfShort, arrayOfByte8, arrayOfByte9, arrayOfLong), this.sqlWarning);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  443 */       this.conversion = new DBConversion(arrayOfShort[0], this.m_clientCharacterSet, arrayOfShort[1]);
/*  444 */       this.byteAlign = (byte)(arrayOfShort[2] & 0xFF);
/*  445 */       this.timeZoneVersionNumber = (arrayOfShort[3] << 16) + (arrayOfShort[4] & 0xFFFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logoff() throws SQLException {
/*      */     try {
/*  464 */       if (this.lifecycle == 2)
/*      */       {
/*  466 */         checkError(t2cLogoff(this.m_nativeState));
/*      */       }
/*  468 */     } catch (NullPointerException nullPointerException) {}
/*      */ 
/*      */     
/*  471 */     this.m_nativeState = 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void open(OracleStatement paramOracleStatement) throws SQLException {
/*  489 */     byte[] arrayOfByte = paramOracleStatement.sqlObject.getSql(paramOracleStatement.processEscapes, paramOracleStatement.convertNcharLiterals).getBytes();
/*      */ 
/*      */     
/*  492 */     checkError(t2cCreateStatement(this.m_nativeState, 0L, arrayOfByte, arrayOfByte.length, paramOracleStatement, false, paramOracleStatement.rowPrefetch));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cancelOperationOnServer() throws SQLException {
/*  508 */     checkError(t2cCancel(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAbort() throws SQLException {
/*  517 */     checkError(t2cAbort(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSetAutoCommit(boolean paramBoolean) throws SQLException {
/*  534 */     checkError(t2cSetAutoCommit(this.m_nativeState, paramBoolean));
/*  535 */     this.autocommit = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doCommit(int paramInt) throws SQLException {
/*  551 */     checkError(t2cCommit(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRollback() throws SQLException {
/*  567 */     checkError(t2cRollback(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int doPingDatabase() throws SQLException {
/*  574 */     if (t2cPingDatabase(this.m_nativeState) == 0) {
/*  575 */       return 0;
/*      */     }
/*  577 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String doGetDatabaseProductVersion() throws SQLException {
/*  584 */     byte[] arrayOfByte = t2cGetProductionVersion(this.m_nativeState);
/*      */     
/*  586 */     return this.conversion.CharBytesToString(arrayOfByte, arrayOfByte.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected short doGetVersionNumber() throws SQLException {
/*  593 */     short s = 0;
/*      */ 
/*      */     
/*      */     try {
/*  597 */       String str1 = doGetDatabaseProductVersion();
/*      */       
/*  599 */       StringTokenizer stringTokenizer = new StringTokenizer(str1.trim(), " .", false);
/*  600 */       String str2 = null;
/*  601 */       byte b = 0;
/*  602 */       short s1 = 0;
/*      */       
/*  604 */       while (stringTokenizer.hasMoreTokens())
/*      */       {
/*  606 */         str2 = stringTokenizer.nextToken();
/*      */ 
/*      */         
/*      */         try {
/*  610 */           s1 = Integer.decode(str2).shortValue();
/*  611 */           s = (short)(s * 10 + s1);
/*  612 */           b++;
/*      */ 
/*      */           
/*  615 */           if (b == 4) {
/*      */             break;
/*      */           }
/*  618 */         } catch (NumberFormatException numberFormatException) {}
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  624 */     catch (NoSuchElementException noSuchElementException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  630 */     if (s == -1) {
/*  631 */       s = 0;
/*      */     }
/*      */     
/*  634 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClobDBAccess createClobDBAccess() {
/*  641 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BlobDBAccess createBlobDBAccess() {
/*  648 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BfileDBAccess createBfileDBAccess() {
/*  655 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SQLWarning checkError(int paramInt) throws SQLException {
/*  662 */     return checkError(paramInt, (SQLWarning)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected SQLWarning checkError(int paramInt, SQLWarning paramSQLWarning) throws SQLException {
/*      */     T2CError t2CError;
/*      */     SQLException sQLException;
/*      */     int i;
/*      */     String str;
/*  672 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 1:
/*  680 */         t2CError = new T2CError();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  686 */         i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  691 */         if (this.lifecycle == 1 || this.lifecycle == 16) {
/*      */           
/*  693 */           i = t2cDescribeError(this.m_nativeState, t2CError, t2CError.m_errorMessage);
/*      */         } else {
/*      */           
/*  696 */           if (this.fatalErrorNumber != 0) {
/*      */ 
/*      */             
/*  699 */             SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 269);
/*  700 */             sQLException2.fillInStackTrace();
/*  701 */             throw sQLException2;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  706 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  707 */           sQLException1.fillInStackTrace();
/*  708 */           throw sQLException1;
/*      */         } 
/*      */         
/*  711 */         str = null;
/*  712 */         if (i != -1) {
/*      */ 
/*      */ 
/*      */           
/*  716 */           byte b = 0;
/*      */           
/*  718 */           while (b < t2CError.m_errorMessage.length && t2CError.m_errorMessage[b] != 0) {
/*  719 */             b++;
/*      */           }
/*  721 */           if (this.conversion == null) throw new Error("conversion == null"); 
/*  722 */           if (t2CError == null) throw new Error("l_error == null"); 
/*  723 */           str = this.conversion.CharBytesToString(t2CError.m_errorMessage, b, true);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  730 */         switch (t2CError.m_errorNumber) {
/*      */           
/*      */           case 28:
/*      */           case 600:
/*      */           case 1012:
/*      */           case 1041:
/*  736 */             internalClose();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 902:
/*  741 */             removeAllDescriptor();
/*      */             break;
/*      */           
/*      */           case 3113:
/*      */           case 3114:
/*  746 */             close();
/*      */             break;
/*      */           case -6:
/*  749 */             t2CError.m_errorNumber = 3113;
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/*  754 */         if (i == -1) {
/*      */           
/*  756 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Fetch error message failed!");
/*  757 */           sQLException1.fillInStackTrace();
/*  758 */           throw sQLException1;
/*      */         } 
/*      */         
/*  761 */         if (paramInt == -1) {
/*      */ 
/*      */           
/*  764 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), str, t2CError.m_errorNumber);
/*  765 */           sQLException1.fillInStackTrace();
/*  766 */           throw sQLException1;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  771 */         paramSQLWarning = DatabaseError.addSqlWarning(paramSQLWarning, str, t2CError.m_errorNumber);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -4:
/*  778 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 254);
/*  779 */         sQLException.fillInStackTrace();
/*  780 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  787 */     return paramSQLWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException {
/*  795 */     T2CStatement t2CStatement = new T2CStatement(this, 1, this.defaultRowPrefetch, -1, -1);
/*      */     
/*  797 */     t2CStatement.needToParse = false;
/*  798 */     t2CStatement.serverCursor = true;
/*  799 */     t2CStatement.isOpen = true;
/*  800 */     t2CStatement.processEscapes = false;
/*      */     
/*  802 */     t2CStatement.prepareForNewResults(true, false);
/*  803 */     t2CStatement.sqlObject.initialize("select unknown as ref cursor from whatever");
/*      */     
/*  805 */     t2CStatement.sqlKind = OracleStatement.SqlKind.SELECT;
/*      */     
/*  807 */     checkError(t2cCreateStatement(this.m_nativeState, paramOracleStatement.c_state, paramArrayOfbyte, paramArrayOfbyte.length, t2CStatement, true, this.defaultRowPrefetch));
/*      */ 
/*      */ 
/*      */     
/*  811 */     paramOracleStatement.addChild(t2CStatement);
/*  812 */     return t2CStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {
/*  821 */     boolean bool = false;
/*      */     
/*  823 */     if (paramOracleTypeCLOB != null) {
/*      */       
/*  825 */       String[] arrayOfString1 = new String[1];
/*  826 */       String[] arrayOfString2 = new String[1];
/*      */       
/*  828 */       SQLName.parse(paramOracleTypeADT.getFullName(), arrayOfString1, arrayOfString2, true);
/*      */       
/*  830 */       String str = "\"" + arrayOfString1[0] + "\".\"" + arrayOfString2[0] + "\"";
/*      */ 
/*      */       
/*  833 */       byte[] arrayOfByte = this.conversion.StringToCharBytes(str);
/*      */       
/*  835 */       int i = t2cGetFormOfUse(this.m_nativeState, paramOracleTypeCLOB, arrayOfByte, arrayOfByte.length, paramInt);
/*      */ 
/*      */ 
/*      */       
/*  839 */       if (i < 0) {
/*  840 */         checkError(i);
/*      */       }
/*      */       
/*  843 */       paramOracleTypeCLOB.setForm(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTdoCState(String paramString1, String paramString2) throws SQLException {
/*  858 */     String str = "\"" + paramString1 + "\".\"" + paramString2 + "\"";
/*  859 */     byte[] arrayOfByte = this.conversion.StringToCharBytes(str);
/*  860 */     int[] arrayOfInt = new int[1];
/*  861 */     long l = t2cGetTDO(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfInt);
/*  862 */     if (l == 0L)
/*      */     {
/*  864 */       checkError(arrayOfInt[0]);
/*      */     }
/*  866 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getDBAccessProperties() throws SQLException {
/*  882 */     return getOCIHandles();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Properties getOCIHandles() throws SQLException {
/*  889 */     if (this.lifecycle != 1) {
/*      */       
/*  891 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  892 */       sQLException.fillInStackTrace();
/*  893 */       throw sQLException;
/*      */     } 
/*      */     
/*  896 */     if (this.nativeInfo == null) {
/*      */       
/*  898 */       long[] arrayOfLong = new long[3];
/*      */ 
/*      */       
/*  901 */       checkError(t2cGetHandles(this.m_nativeState, arrayOfLong));
/*      */ 
/*      */       
/*  904 */       this.nativeInfo = new Properties();
/*      */       
/*  906 */       this.nativeInfo.put("OCIEnvHandle", String.valueOf(arrayOfLong[0]));
/*  907 */       this.nativeInfo.put("OCISvcCtxHandle", String.valueOf(arrayOfLong[1]));
/*  908 */       this.nativeInfo.put("OCIErrHandle", String.valueOf(arrayOfLong[2]));
/*  909 */       this.nativeInfo.put("ClientCharSet", String.valueOf(this.m_clientCharacterSet));
/*      */     } 
/*      */     
/*  912 */     return this.nativeInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getServerSessionInfo() throws SQLException {
/*  919 */     if (this.lifecycle != 1) {
/*      */       
/*  921 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  922 */       sQLException.fillInStackTrace();
/*  923 */       throw sQLException;
/*      */     } 
/*      */     
/*  926 */     if (this.sessionProperties == null) {
/*  927 */       this.sessionProperties = new Properties();
/*      */     }
/*      */ 
/*      */     
/*  931 */     if (getVersionNumber() < 10200) {
/*  932 */       queryFCFProperties(this.sessionProperties);
/*      */     } else {
/*  934 */       checkError(t2cGetServerSessionInfo(this.m_nativeState, this.sessionProperties));
/*      */     } 
/*  936 */     return this.sessionProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException {
/*  942 */     byte b = 0;
/*  943 */     if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED) {
/*      */       
/*  945 */       b = t2cGetAsmVolProperty(this.m_nativeState);
/*      */     }
/*  947 */     else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE) {
/*      */       
/*  949 */       b = t2cGetInstanceType(this.m_nativeState);
/*      */     } 
/*  951 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getConnectionPoolInfo() throws SQLException {
/*  961 */     if (this.lifecycle != 1) {
/*      */       
/*  963 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  964 */       sQLException.fillInStackTrace();
/*  965 */       throw sQLException;
/*      */     } 
/*  967 */     Properties properties = new Properties();
/*      */     
/*  969 */     checkError(t2cGetConnPoolInfo(this.m_nativeState, properties));
/*      */     
/*  971 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionPoolInfo(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) throws SQLException {
/*  981 */     checkError(t2cSetConnPoolInfo(this.m_nativeState, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ociPasswordChange(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  991 */     if (this.lifecycle != 1) {
/*      */       
/*  993 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  994 */       sQLException.fillInStackTrace();
/*  995 */       throw sQLException;
/*      */     } 
/*  997 */     byte[] arrayOfByte1 = (paramString1 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString1, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */     
/* 1001 */     byte[] arrayOfByte2 = (paramString2 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString2, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1004 */     byte[] arrayOfByte3 = (paramString3 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString3, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1007 */     this.sqlWarning = checkError(t2cPasswordChange(this.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length), this.sqlWarning);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processOCIConnectionPooling() throws SQLException {
/* 1018 */     if (this.lifecycle != 1) {
/*      */       
/* 1020 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1021 */       sQLException.fillInStackTrace();
/* 1022 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1026 */     T2CConnection t2CConnection = null;
/*      */     
/* 1028 */     if (this.ociConnectionPoolLogonMode == "connection_pool") {
/*      */       
/* 1030 */       if (this.nlsLangBackdoor) {
/*      */ 
/*      */         
/* 1033 */         this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG(this.ocidll);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1038 */         this.m_clientCharacterSet = getClientCharSetId();
/*      */       } 
/*      */     } else {
/*      */       
/* 1042 */       t2CConnection = (T2CConnection)this.ociConnectionPoolObject;
/* 1043 */       this.m_clientCharacterSet = t2CConnection.m_clientCharacterSet;
/*      */     } 
/*      */     
/* 1046 */     byte[] arrayOfByte1 = null;
/*      */     
/* 1048 */     byte[] arrayOfByte2 = (this.password == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1051 */     byte[] arrayOfByte3 = (this.editionName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1054 */     byte[] arrayOfByte4 = DBConversion.stringToDriverCharBytes((this.driverNameAttribute == null) ? "jdbcoci" : this.driverNameAttribute, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */     
/* 1058 */     byte[] arrayOfByte5 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
/*      */     
/* 1060 */     byte[] arrayOfByte6 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault()).getBytes();
/*      */     
/* 1062 */     byte[] arrayOfByte7 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault()).getBytes();
/*      */ 
/*      */ 
/*      */     
/* 1066 */     if (arrayOfByte6 == null || arrayOfByte7 == null) {
/*      */       
/* 1068 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/* 1069 */       sQLException.fillInStackTrace();
/* 1070 */       throw sQLException;
/*      */     } 
/*      */     
/* 1073 */     short[] arrayOfShort = new short[5];
/* 1074 */     long[] arrayOfLong = { this.defaultLobPrefetchSize };
/*      */     
/* 1076 */     if (this.ociConnectionPoolLogonMode == "connection_pool") {
/*      */       
/* 1078 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1084 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1087 */       this.logon_mode = 5;
/*      */       
/* 1089 */       if (this.lifecycle == 1)
/*      */       {
/* 1091 */         int[] arrayOfInt = new int[6];
/*      */         
/* 1093 */         OracleOCIConnectionPool.readPoolConfig(this.ociConnectionPoolMinLimit, this.ociConnectionPoolMaxLimit, this.ociConnectionPoolIncrement, this.ociConnectionPoolTimeout, this.ociConnectionPoolNoWait, this.ociConnectionPoolTransactionDistributed, arrayOfInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1101 */         this.sqlWarning = checkError(t2cCreateConnPool(arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte5, arrayOfByte5.length, this.m_clientCharacterSet, this.logon_mode, arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3], arrayOfInt[4], arrayOfInt[5]), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1112 */         this.versionNumber = 10000;
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */         
/* 1118 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 0, "Internal Error: ");
/* 1119 */         sQLException.fillInStackTrace();
/* 1120 */         throw sQLException;
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1125 */     else if (this.ociConnectionPoolLogonMode == "connpool_connection") {
/*      */       
/* 1127 */       this.logon_mode = 6;
/*      */       
/* 1129 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1135 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1138 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, 0, 0, (String[])null, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, arrayOfShort, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1171 */     else if (this.ociConnectionPoolLogonMode == "connpool_alias_connection") {
/*      */       
/* 1173 */       this.logon_mode = 8;
/*      */ 
/*      */       
/* 1176 */       byte[] arrayOfByte = null;
/*      */       
/* 1178 */       arrayOfByte = (byte[])this.ociConnectionPoolConnID;
/*      */ 
/*      */       
/* 1181 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1187 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1190 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, 0, 0, (String[])null, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, arrayOfByte, (arrayOfByte == null) ? 0 : arrayOfByte.length, arrayOfShort, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1223 */     else if (this.ociConnectionPoolLogonMode == "connpool_proxy_connection") {
/*      */       
/* 1225 */       this.logon_mode = 7;
/*      */ 
/*      */       
/* 1228 */       String str = this.ociConnectionPoolProxyType;
/*      */ 
/*      */       
/* 1231 */       int i = this.ociConnectionPoolProxyNumRoles.intValue();
/*      */       
/* 1233 */       String[] arrayOfString = null;
/*      */       
/* 1235 */       if (i > 0)
/*      */       {
/* 1237 */         arrayOfString = (String[])this.ociConnectionPoolProxyRoles;
/*      */       }
/*      */ 
/*      */       
/* 1241 */       byte[] arrayOfByte8 = null;
/* 1242 */       byte[] arrayOfByte9 = null;
/* 1243 */       byte[] arrayOfByte10 = null;
/* 1244 */       byte[] arrayOfByte11 = null;
/*      */ 
/*      */       
/* 1247 */       byte b = 0;
/*      */ 
/*      */       
/* 1250 */       if (str == "proxytype_user_name") {
/*      */         
/* 1252 */         b = 1;
/*      */         
/* 1254 */         String str1 = this.ociConnectionPoolProxyUserName;
/*      */         
/* 1256 */         if (str1 != null) {
/* 1257 */           arrayOfByte8 = str1.getBytes();
/*      */         }
/* 1259 */         str1 = this.ociConnectionPoolProxyPassword;
/*      */         
/* 1261 */         if (str1 != null) {
/* 1262 */           arrayOfByte9 = str1.getBytes();
/*      */         }
/* 1264 */       } else if (str == "proxytype_distinguished_name") {
/*      */ 
/*      */         
/* 1267 */         b = 2;
/*      */         
/* 1269 */         String str1 = this.ociConnectionPoolProxyDistinguishedName;
/*      */         
/* 1271 */         if (str1 != null) {
/* 1272 */           arrayOfByte10 = str1.getBytes();
/*      */         }
/* 1274 */       } else if (str == "proxytype_certificate") {
/*      */         
/* 1276 */         b = 3;
/*      */         
/* 1278 */         arrayOfByte11 = (byte[])this.ociConnectionPoolProxyCertificate;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1284 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 107);
/* 1285 */         sQLException.fillInStackTrace();
/* 1286 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1291 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1297 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1300 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, b, i, arrayOfString, arrayOfByte8, (arrayOfByte8 == null) ? 0 : arrayOfByte8.length, arrayOfByte9, (arrayOfByte9 == null) ? 0 : arrayOfByte9.length, arrayOfByte10, (arrayOfByte10 == null) ? 0 : arrayOfByte10.length, arrayOfByte11, (arrayOfByte11 == null) ? 0 : arrayOfByte11.length, (byte[])null, 0, arrayOfShort, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1327 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "connection-pool-logon");
/* 1328 */       sQLException.fillInStackTrace();
/* 1329 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1333 */     this.conversion = new DBConversion(arrayOfShort[0], this.m_clientCharacterSet, arrayOfShort[1]);
/* 1334 */     this.byteAlign = (byte)(arrayOfShort[2] & 0xFF);
/* 1335 */     this.timeZoneVersionNumber = (arrayOfShort[3] << 16) + (arrayOfShort[4] & 0xFFFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException {
/* 1351 */     T2CConnection t2CConnection = this;
/* 1352 */     PhysicalConnection physicalConnection = (PhysicalConnection)paramOracleConnection.getPhysicalConnection();
/*      */     
/* 1354 */     return (t2CConnection == physicalConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long lobLength(byte[] paramArrayOfbyte) throws SQLException {
/* 1431 */     long l = 0L;
/* 1432 */     l = t2cLobGetLength(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length);
/*      */     
/* 1434 */     checkError((int)l);
/*      */     
/* 1436 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int blobRead(byte[] paramArrayOfbyte1, long paramLong, int paramInt, byte[] paramArrayOfbyte2, boolean paramBoolean, ByteBuffer paramByteBuffer) throws SQLException {
/* 1451 */     int i = 0;
/*      */     
/* 1453 */     i = t2cBlobRead(this.m_nativeState, paramArrayOfbyte1, paramArrayOfbyte1.length, paramLong, paramInt, paramArrayOfbyte2, paramArrayOfbyte2.length, paramBoolean, paramByteBuffer);
/*      */ 
/*      */     
/* 1456 */     checkError(i);
/*      */     
/* 1458 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int blobWrite(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 1473 */     int i = 0;
/*      */     
/* 1475 */     i = t2cBlobWrite(this.m_nativeState, paramArrayOfbyte1, paramArrayOfbyte1.length, paramLong, paramInt2, paramArrayOfbyte2, paramInt1, paramArrayOfbyte);
/*      */ 
/*      */     
/* 1478 */     checkError(i);
/*      */     
/* 1480 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int clobWrite(byte[] paramArrayOfbyte, long paramLong, char[] paramArrayOfchar, byte[][] paramArrayOfbyte1, boolean paramBoolean, int paramInt1, int paramInt2) throws SQLException {
/* 1496 */     int i = 0;
/*      */     
/* 1498 */     i = t2cClobWrite(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length, paramLong, paramInt2, paramArrayOfchar, paramInt1, paramArrayOfbyte1, paramBoolean);
/*      */ 
/*      */     
/* 1501 */     checkError(i);
/*      */     
/* 1503 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lobGetChunkSize(byte[] paramArrayOfbyte) throws SQLException {
/* 1511 */     int i = 0;
/* 1512 */     i = t2cLobGetChunkSize(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length);
/*      */     
/* 1514 */     checkError(i);
/*      */     
/* 1516 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(BFILE paramBFILE) throws SQLException {
/* 1529 */     byte[] arrayOfByte = null;
/*      */     
/* 1531 */     checkTrue((this.lifecycle == 1), 8);
/* 1532 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1535 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 1553 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 1556 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1557 */       sQLException.fillInStackTrace();
/* 1558 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1562 */     long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfbyte, paramLong);
/*      */     
/* 1564 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 1566 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong) throws SQLException {
/* 1584 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 1587 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1588 */       sQLException.fillInStackTrace();
/* 1589 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1593 */     long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong);
/*      */     
/* 1595 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 1597 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1613 */     byte[] arrayOfByte = null;
/*      */     
/* 1615 */     checkTrue((this.lifecycle == 1), 8);
/* 1616 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1619 */     if (paramInt <= 0 || paramArrayOfbyte == null) {
/* 1620 */       return 0;
/*      */     }
/* 1622 */     if (paramInt > paramArrayOfbyte.length) {
/* 1623 */       paramInt = paramArrayOfbyte.length;
/*      */     }
/* 1625 */     if (this.useNio) {
/*      */       
/* 1627 */       int j = paramArrayOfbyte.length;
/* 1628 */       if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < j) {
/* 1629 */         this.nioBufferForLob = ByteBuffer.allocateDirect(j);
/*      */       } else {
/* 1631 */         this.nioBufferForLob.rewind();
/*      */       } 
/*      */     } 
/* 1634 */     int i = blobRead(arrayOfByte, paramLong, paramInt, paramArrayOfbyte, this.useNio, this.nioBufferForLob);
/* 1635 */     if (this.useNio)
/*      */     {
/* 1637 */       this.nioBufferForLob.get(paramArrayOfbyte);
/*      */     }
/*      */     
/* 1640 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getName(BFILE paramBFILE) throws SQLException {
/* 1654 */     byte[] arrayOfByte = null;
/* 1655 */     String str = null;
/*      */     
/* 1657 */     checkTrue((this.lifecycle == 1), 8);
/* 1658 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1661 */     str = t2cBfileGetName(this.m_nativeState, arrayOfByte, arrayOfByte.length);
/*      */     
/* 1663 */     checkError(str.length());
/*      */     
/* 1665 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getDirAlias(BFILE paramBFILE) throws SQLException {
/* 1679 */     byte[] arrayOfByte = null;
/* 1680 */     String str = null;
/*      */     
/* 1682 */     checkTrue((this.lifecycle == 1), 8);
/* 1683 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1686 */     str = t2cBfileGetDirAlias(this.m_nativeState, arrayOfByte, arrayOfByte.length);
/*      */     
/* 1688 */     checkError(str.length());
/*      */     
/* 1690 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void openFile(BFILE paramBFILE) throws SQLException {
/* 1703 */     byte[] arrayOfByte = null;
/*      */     
/* 1705 */     checkTrue((this.lifecycle == 1), 8);
/* 1706 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1709 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1711 */     checkError(t2cBfileOpen(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 1714 */     paramBFILE.setLocator(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isFileOpen(BFILE paramBFILE) throws SQLException {
/* 1731 */     byte[] arrayOfByte = null;
/*      */     
/* 1733 */     checkTrue((this.lifecycle == 1), 8);
/* 1734 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1737 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1739 */     checkError(t2cBfileIsOpen(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/* 1741 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean fileExists(BFILE paramBFILE) throws SQLException {
/* 1757 */     byte[] arrayOfByte = null;
/*      */     
/* 1759 */     checkTrue((this.lifecycle == 1), 8);
/* 1760 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1763 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1765 */     checkError(t2cBfileExists(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/* 1767 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void closeFile(BFILE paramBFILE) throws SQLException {
/* 1780 */     byte[] arrayOfByte = null;
/*      */     
/* 1782 */     checkTrue((this.lifecycle == 1), 8);
/* 1783 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1786 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1788 */     checkError(t2cBfileClose(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 1791 */     paramBFILE.setLocator(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BFILE paramBFILE, int paramInt) throws SQLException {
/* 1806 */     byte[] arrayOfByte = null;
/*      */     
/* 1808 */     checkTrue((this.lifecycle == 1), 8);
/* 1809 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 1812 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1814 */     checkError(t2cLobOpen(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 1817 */     paramBFILE.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BFILE paramBFILE) throws SQLException {
/* 1830 */     byte[] arrayOfByte = null;
/*      */     
/* 1832 */     checkTrue((this.lifecycle == 1), 8);
/* 1833 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 1836 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1838 */     checkError(t2cLobClose(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 1841 */     paramBFILE.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BFILE paramBFILE) throws SQLException {
/* 1855 */     byte[] arrayOfByte = null;
/*      */     
/* 1857 */     checkTrue((this.lifecycle == 1), 8);
/* 1858 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 1861 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1863 */     checkError(t2cLobIsOpen(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 1866 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException {
/* 1886 */     if (paramLong == 0L)
/*      */     {
/* 1888 */       return new OracleBlobInputStream(paramBFILE, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 1892 */     return new OracleBlobInputStream(paramBFILE, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt) throws SQLException {
/* 1912 */     checkTrue((paramBFILE != null && paramBFILE.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 1915 */     return new OracleConversionInputStream(this.conversion, paramBFILE.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BFILE paramBFILE, int paramInt) throws SQLException {
/* 1937 */     checkTrue((paramBFILE != null && paramBFILE.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 1940 */     return new OracleConversionReader(this.conversion, paramBFILE.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(BLOB paramBLOB) throws SQLException {
/* 1956 */     byte[] arrayOfByte = null;
/*      */     
/* 1958 */     checkTrue((this.lifecycle == 1), 8);
/* 1959 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1962 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BLOB paramBLOB, byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 1981 */     checkTrue((this.lifecycle == 1), 8);
/* 1982 */     checkTrue((paramBLOB != null && paramBLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 1985 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 1988 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1989 */       sQLException.fillInStackTrace();
/* 1990 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1994 */     long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfbyte, paramLong);
/*      */     
/* 1996 */     l = (l == 0L) ? -1L : l;
/* 1997 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong) throws SQLException {
/* 2014 */     checkTrue((this.lifecycle == 1), 8);
/* 2015 */     checkTrue((paramBLOB1 != null && paramBLOB1.shareBytes() != null), 54);
/*      */     
/* 2017 */     checkTrue((paramBLOB2 != null && paramBLOB2.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2020 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2023 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2024 */       sQLException.fillInStackTrace();
/* 2025 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2029 */     long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong);
/*      */     
/* 2031 */     l = (l == 0L) ? -1L : l;
/* 2032 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 2049 */     byte[] arrayOfByte = null;
/* 2050 */     int i = 0;
/*      */     
/* 2052 */     checkTrue((this.lifecycle == 1), 8);
/* 2053 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2056 */     if (paramInt <= 0 || paramArrayOfbyte == null) {
/* 2057 */       return 0;
/*      */     }
/* 2059 */     if (paramInt > paramArrayOfbyte.length) {
/* 2060 */       paramInt = paramArrayOfbyte.length;
/*      */     }
/* 2062 */     long l = -1L;
/*      */     
/* 2064 */     if (paramBLOB.isActivePrefetch()) {
/*      */       
/* 2066 */       byte[] arrayOfByte1 = paramBLOB.getPrefetchedData();
/* 2067 */       l = paramBLOB.length();
/* 2068 */       if (arrayOfByte1 != null && arrayOfByte1 != null && paramLong <= arrayOfByte1.length) {
/*      */ 
/*      */         
/* 2071 */         int j = Math.min(arrayOfByte1.length - (int)paramLong + 1, paramInt);
/*      */         
/* 2073 */         System.arraycopy(arrayOfByte1, (int)paramLong - 1, paramArrayOfbyte, 0, j);
/*      */         
/* 2075 */         i += j;
/*      */       } 
/*      */     } 
/*      */     
/* 2079 */     if (i < paramInt && (l == -1L || paramLong - 1L + i < l)) {
/*      */ 
/*      */ 
/*      */       
/* 2083 */       byte[] arrayOfByte1 = paramArrayOfbyte;
/* 2084 */       int j = i;
/* 2085 */       int k = ((l > 0L && l < paramInt) ? (int)l : paramInt) - i;
/*      */       
/* 2087 */       if (i > 0)
/*      */       {
/* 2089 */         arrayOfByte1 = new byte[k];
/*      */       }
/*      */       
/* 2092 */       if (this.useNio) {
/*      */         
/* 2094 */         int m = paramArrayOfbyte.length;
/* 2095 */         if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < m) {
/*      */           
/* 2097 */           this.nioBufferForLob = ByteBuffer.allocateDirect(m);
/*      */         } else {
/* 2099 */           this.nioBufferForLob.rewind();
/*      */         } 
/*      */       } 
/* 2102 */       i += blobRead(arrayOfByte, paramLong + i, k, arrayOfByte1, this.useNio, this.nioBufferForLob);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2108 */       if (this.useNio)
/*      */       {
/* 2110 */         this.nioBufferForLob.get(arrayOfByte1);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2115 */       if (j > 0)
/*      */       {
/* 2117 */         System.arraycopy(arrayOfByte1, 0, paramArrayOfbyte, j, arrayOfByte1.length);
/*      */       }
/*      */     } 
/*      */     
/* 2121 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 2143 */     checkTrue((paramLong != 0L || paramInt2 > 0), 68);
/*      */     
/* 2145 */     checkTrue((paramLong >= 0L), 68);
/* 2146 */     if (paramArrayOfbyte == null || paramInt2 <= 0) {
/* 2147 */       return 0;
/*      */     }
/* 2149 */     int i = 0;
/*      */     
/* 2151 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0 || paramInt2 <= 0) {
/* 2152 */       i = 0;
/*      */     } else {
/*      */       
/* 2155 */       byte[] arrayOfByte = null;
/*      */       
/* 2157 */       checkTrue((this.lifecycle == 1), 8);
/* 2158 */       checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */       
/* 2161 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2163 */       paramBLOB.setActivePrefetch(false);
/* 2164 */       paramBLOB.clearCachedData();
/* 2165 */       i = blobWrite(arrayOfByte, paramLong, paramArrayOfbyte, arrayOfByte1, paramInt1, paramInt2);
/*      */ 
/*      */       
/* 2168 */       paramBLOB.setLocator(arrayOfByte1[0]);
/*      */     } 
/*      */     
/* 2171 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(BLOB paramBLOB) throws SQLException {
/* 2183 */     byte[] arrayOfByte = null;
/*      */     
/* 2185 */     checkTrue((this.lifecycle == 1), 8);
/* 2186 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2189 */     return lobGetChunkSize(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(BLOB paramBLOB, long paramLong) throws SQLException {
/* 2203 */     byte[] arrayOfByte = null;
/*      */     
/* 2205 */     checkTrue((this.lifecycle == 1), 8);
/* 2206 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2209 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2211 */     paramBLOB.setActivePrefetch(false);
/* 2212 */     paramBLOB.clearCachedData();
/* 2213 */     checkError(t2cLobTrim(this.m_nativeState, 113, paramLong, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2216 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException {
/* 2235 */     BLOB bLOB = null;
/*      */     
/* 2237 */     checkTrue((this.lifecycle == 1), 8);
/*      */     
/* 2239 */     bLOB = new BLOB((OracleConnection)paramConnection);
/*      */     
/* 2241 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/* 2243 */     checkError(t2cLobCreateTemporary(this.m_nativeState, 113, paramBoolean, paramInt, (short)0, arrayOfByte));
/*      */ 
/*      */     
/* 2246 */     bLOB.setShareBytes(arrayOfByte[0]);
/*      */     
/* 2248 */     return bLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 2264 */       byte[] arrayOfByte = null;
/*      */       
/* 2266 */       checkTrue((this.lifecycle == 1), 8);
/* 2267 */       checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */       
/* 2270 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2272 */       checkError(t2cLobFreeTemporary(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */       
/* 2275 */       paramBLOB.setShareBytes(arrayOfByte1[0]);
/* 2276 */     } catch (SQLException sQLException) {
/*      */       
/* 2278 */       if ((paramBoolean & ((sQLException.getErrorCode() == 64201) ? 1 : 0)) != 0) {
/* 2279 */         LobPlsqlUtil.freeTemporaryLob((Connection)this, (Datum)paramBLOB, 2004);
/*      */       } else {
/* 2281 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isTemporary(BLOB paramBLOB) throws SQLException {
/* 2297 */     byte[] arrayOfByte = null;
/*      */     
/* 2299 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2302 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2304 */     checkError(t2cLobIsTemporary(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2307 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2320 */     byte[] arrayOfByte = null;
/*      */     
/* 2322 */     checkTrue((this.lifecycle == 1), 8);
/* 2323 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2326 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2328 */     checkError(t2cLobOpen(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 2331 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BLOB paramBLOB) throws SQLException {
/* 2344 */     byte[] arrayOfByte = null;
/*      */     
/* 2346 */     checkTrue((this.lifecycle == 1), 8);
/* 2347 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2350 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2352 */     checkError(t2cLobClose(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2355 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BLOB paramBLOB) throws SQLException {
/* 2369 */     byte[] arrayOfByte = null;
/*      */     
/* 2371 */     checkTrue((this.lifecycle == 1), 8);
/* 2372 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2375 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2377 */     checkError(t2cLobIsOpen(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2380 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/* 2399 */     if (paramLong == 0L)
/*      */     {
/* 2401 */       return new OracleBlobInputStream(paramBLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 2405 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 2428 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 2449 */     if (paramLong == 0L) {
/*      */       
/* 2451 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 2454 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2455 */         sQLException.fillInStackTrace();
/* 2456 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2461 */       return new OracleBlobOutputStream(paramBLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2466 */     return new OracleBlobOutputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2487 */     checkTrue((paramBLOB != null && paramBLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2490 */     return new OracleConversionInputStream(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2511 */     checkTrue((paramBLOB != null && paramBLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2514 */     return new OracleConversionReader(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(CLOB paramCLOB) throws SQLException {
/* 2534 */     byte[] arrayOfByte = null;
/*      */     
/* 2536 */     checkTrue((this.lifecycle == 1), 8);
/* 2537 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2540 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(CLOB paramCLOB, String paramString, long paramLong) throws SQLException {
/* 2558 */     if (paramString == null) {
/*      */       
/* 2560 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2561 */       sQLException.fillInStackTrace();
/* 2562 */       throw sQLException;
/*      */     } 
/*      */     
/* 2565 */     checkTrue((this.lifecycle == 1), 8);
/* 2566 */     checkTrue((paramCLOB != null && paramCLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2569 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2572 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2573 */       sQLException.fillInStackTrace();
/* 2574 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2578 */     char[] arrayOfChar = new char[paramString.length()];
/*      */     
/* 2580 */     paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
/*      */     
/* 2582 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, arrayOfChar, paramLong);
/*      */     
/* 2584 */     l = (l == 0L) ? -1L : l;
/* 2585 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong) throws SQLException {
/* 2602 */     checkTrue((this.lifecycle == 1), 8);
/* 2603 */     checkTrue((paramCLOB1 != null && paramCLOB1.shareBytes() != null), 54);
/*      */     
/* 2605 */     checkTrue((paramCLOB2 != null && paramCLOB2.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2608 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2611 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2612 */       sQLException.fillInStackTrace();
/* 2613 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2617 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 2619 */     l = (l == 0L) ? -1L : l;
/* 2620 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 2637 */     byte[] arrayOfByte = null;
/*      */     
/* 2639 */     checkTrue((this.lifecycle == 1), 8);
/* 2640 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2643 */     if (paramInt <= 0 || paramArrayOfchar == null) {
/* 2644 */       return 0;
/*      */     }
/* 2646 */     if (paramInt > paramArrayOfchar.length) {
/* 2647 */       paramInt = paramArrayOfchar.length;
/*      */     }
/* 2649 */     int i = 0;
/*      */ 
/*      */     
/* 2652 */     long l = -1L;
/*      */ 
/*      */     
/* 2655 */     if (paramCLOB.isActivePrefetch()) {
/*      */       
/* 2657 */       l = paramCLOB.length();
/* 2658 */       char[] arrayOfChar = paramCLOB.getPrefetchedData();
/* 2659 */       if (arrayOfChar != null && paramLong <= arrayOfChar.length) {
/*      */ 
/*      */         
/* 2662 */         int j = Math.min(arrayOfChar.length - (int)paramLong + 1, paramInt);
/*      */ 
/*      */         
/* 2665 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfchar, 0, j);
/*      */         
/* 2667 */         i += j;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2672 */     if (i < paramInt && (l == -1L || paramLong - 1L + i < l)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2677 */       char[] arrayOfChar = paramArrayOfchar;
/* 2678 */       int j = i;
/* 2679 */       int k = ((l > 0L && l < paramInt) ? (int)l : paramInt) - i;
/*      */       
/* 2681 */       if (i > 0)
/*      */       {
/* 2683 */         arrayOfChar = new char[k];
/*      */       }
/*      */       
/* 2686 */       if (this.useNio) {
/*      */ 
/*      */ 
/*      */         
/* 2690 */         int m = paramArrayOfchar.length * 2;
/* 2691 */         if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < m) {
/* 2692 */           this.nioBufferForLob = ByteBuffer.allocateDirect(m);
/*      */         } else {
/* 2694 */           this.nioBufferForLob.rewind();
/*      */         } 
/*      */       } 
/* 2697 */       i += t2cClobRead(this.m_nativeState, arrayOfByte, arrayOfByte.length, paramLong + i, k, arrayOfChar, arrayOfChar.length, paramCLOB.isNCLOB(), this.useNio, this.nioBufferForLob);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2709 */       if (this.useNio) {
/*      */         
/* 2711 */         ByteBuffer byteBuffer = this.nioBufferForLob.order(ByteOrder.LITTLE_ENDIAN);
/* 2712 */         CharBuffer charBuffer = byteBuffer.asCharBuffer();
/* 2713 */         charBuffer.get(arrayOfChar);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2718 */       if (j > 0)
/*      */       {
/* 2720 */         System.arraycopy(arrayOfChar, 0, paramArrayOfchar, j, arrayOfChar.length);
/*      */       }
/*      */       
/* 2723 */       checkError(i);
/*      */     } 
/*      */     
/* 2726 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 2747 */     byte[] arrayOfByte = null;
/*      */     
/* 2749 */     checkTrue((this.lifecycle == 1), 8);
/* 2750 */     checkTrue((paramLong >= 0L), 68);
/*      */     
/* 2752 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2755 */     if (paramArrayOfchar == null) {
/* 2756 */       return 0;
/*      */     }
/* 2758 */     byte[][] arrayOfByte1 = new byte[1][];
/* 2759 */     paramCLOB.setActivePrefetch(false);
/* 2760 */     paramCLOB.clearCachedData();
/* 2761 */     int i = clobWrite(arrayOfByte, paramLong, paramArrayOfchar, arrayOfByte1, paramCLOB.isNCLOB(), paramInt1, paramInt2);
/*      */ 
/*      */     
/* 2764 */     paramCLOB.setLocator(arrayOfByte1[0]);
/*      */     
/* 2766 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(CLOB paramCLOB) throws SQLException {
/* 2778 */     byte[] arrayOfByte = null;
/*      */     
/* 2780 */     checkTrue((this.lifecycle == 1), 8);
/* 2781 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2784 */     return lobGetChunkSize(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong) throws SQLException {
/* 2798 */     byte[] arrayOfByte = null;
/*      */     
/* 2800 */     checkTrue((this.lifecycle == 1), 8);
/* 2801 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2804 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2806 */     paramCLOB.setActivePrefetch(false);
/* 2807 */     paramCLOB.clearCachedData();
/* 2808 */     checkError(t2cLobTrim(this.m_nativeState, 112, paramLong, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2811 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/*      */     NCLOB nCLOB;
/* 2831 */     CLOB cLOB = null;
/*      */     
/* 2833 */     checkTrue((this.lifecycle == 1), 8);
/*      */     
/* 2835 */     if (paramShort == 1) {
/* 2836 */       cLOB = new CLOB((OracleConnection)paramConnection);
/*      */     } else {
/*      */       
/* 2839 */       nCLOB = new NCLOB((OracleConnection)paramConnection);
/*      */     } 
/*      */     
/* 2842 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/* 2844 */     checkError(t2cLobCreateTemporary(this.m_nativeState, 112, paramBoolean, paramInt, paramShort, arrayOfByte));
/*      */ 
/*      */     
/* 2847 */     nCLOB.setShareBytes(arrayOfByte[0]);
/*      */     
/* 2849 */     return (CLOB)nCLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 2864 */       byte[] arrayOfByte = null;
/*      */       
/* 2866 */       checkTrue((this.lifecycle == 1), 8);
/* 2867 */       checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */       
/* 2870 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2872 */       checkError(t2cLobFreeTemporary(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */       
/* 2875 */       paramCLOB.setShareBytes(arrayOfByte1[0]);
/* 2876 */     } catch (SQLException sQLException) {
/*      */       
/* 2878 */       if ((paramBoolean & ((sQLException.getErrorCode() == 64201) ? 1 : 0)) != 0) {
/* 2879 */         LobPlsqlUtil.freeTemporaryLob((Connection)this, (Datum)paramCLOB, 2005);
/*      */       } else {
/* 2881 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isTemporary(CLOB paramCLOB) throws SQLException {
/* 2898 */     byte[] arrayOfByte = null;
/*      */     
/* 2900 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2903 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2905 */     checkError(t2cLobIsTemporary(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2908 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt) throws SQLException {
/* 2921 */     byte[] arrayOfByte = null;
/*      */     
/* 2923 */     checkTrue((this.lifecycle == 1), 8);
/* 2924 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2927 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2929 */     checkError(t2cLobOpen(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 2932 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(CLOB paramCLOB) throws SQLException {
/* 2945 */     byte[] arrayOfByte = null;
/*      */     
/* 2947 */     checkTrue((this.lifecycle == 1), 8);
/* 2948 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2951 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2953 */     checkError(t2cLobClose(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2956 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(CLOB paramCLOB) throws SQLException {
/* 2970 */     byte[] arrayOfByte = null;
/*      */     
/* 2972 */     checkTrue((this.lifecycle == 1), 8);
/* 2973 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2976 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2978 */     checkError(t2cLobIsOpen(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2981 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3001 */     if (paramLong == 0L)
/*      */     {
/* 3003 */       return new OracleClobInputStream(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3007 */     return new OracleClobInputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3028 */     if (paramLong == 0L) {
/*      */       
/* 3030 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3033 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3034 */         sQLException.fillInStackTrace();
/* 3035 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3040 */       return new OracleClobOutputStream(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3045 */     return new OracleClobOutputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3065 */     if (paramLong == 0L)
/*      */     {
/* 3067 */       return new OracleClobReader(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3071 */     return new OracleClobReader(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3092 */     return new OracleClobReader(paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3112 */     if (paramLong == 0L) {
/*      */       
/* 3114 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3117 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3118 */         sQLException.fillInStackTrace();
/* 3119 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3124 */       return new OracleClobWriter(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3129 */     return new OracleClobWriter(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject) throws SQLException {
/* 3156 */     this.appCallback = paramOracleOCIFailover;
/* 3157 */     this.appCallbackObject = paramObject;
/*      */     
/* 3159 */     checkError(t2cRegisterTAFCallback(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int callTAFCallbackMethod(int paramInt1, int paramInt2) {
/* 3169 */     int i = 0;
/*      */ 
/*      */     
/* 3172 */     if (this.appCallback != null) {
/* 3173 */       i = this.appCallback.callbackFn((Connection)this, this.appCallbackObject, paramInt1, paramInt2);
/*      */     }
/* 3175 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHeapAllocSize() throws SQLException {
/* 3189 */     if (this.lifecycle != 1) {
/*      */       
/* 3191 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 3192 */       sQLException.fillInStackTrace();
/* 3193 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3198 */     int i = t2cGetHeapAllocSize(this.m_nativeState);
/*      */     
/* 3200 */     if (i < 0) {
/*      */       
/* 3202 */       if (i == -999) {
/*      */         
/* 3204 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 3205 */         sQLException1.fillInStackTrace();
/* 3206 */         throw sQLException1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3212 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 3213 */       sQLException.fillInStackTrace();
/* 3214 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3218 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOCIEnvHeapAllocSize() throws SQLException {
/* 3231 */     if (this.lifecycle != 1) {
/*      */       
/* 3233 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 3234 */       sQLException.fillInStackTrace();
/* 3235 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3240 */     int i = t2cGetOciEnvHeapAllocSize(this.m_nativeState);
/*      */     
/* 3242 */     if (i < 0) {
/*      */       
/* 3244 */       if (i == -999) {
/*      */         
/* 3246 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 3247 */         sQLException1.fillInStackTrace();
/* 3248 */         throw sQLException1;
/*      */       } 
/*      */       
/* 3251 */       checkError(i);
/*      */ 
/*      */ 
/*      */       
/* 3255 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 3256 */       sQLException.fillInStackTrace();
/* 3257 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3261 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final short getClientCharSetId() {
/* 3270 */     return 871;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short getDriverCharSetIdFromNLS_LANG(String paramString) throws SQLException {
/* 3286 */     if (!isLibraryLoaded) {
/* 3287 */       loadNativeLibrary(paramString);
/*      */     }
/*      */     
/* 3290 */     short s = t2cGetDriverCharSetFromNlsLang();
/*      */ 
/*      */     
/* 3293 */     if (s < 0) {
/*      */       
/* 3295 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 8);
/* 3296 */       sQLException.fillInStackTrace();
/* 3297 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3301 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*      */     String str1, str2;
/*      */     Object object;
/* 3314 */     byte[][] arrayOfByte = (byte[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3320 */     int i = 0;
/*      */     
/* 3322 */     this.savedUser = this.userName;
/* 3323 */     this.userName = null;
/*      */     
/* 3325 */     byte[] arrayOfByte4 = new byte[0], arrayOfByte3 = arrayOfByte4, arrayOfByte2 = arrayOfByte3, arrayOfByte1 = arrayOfByte2;
/*      */     
/* 3327 */     switch (paramInt) {
/*      */       
/*      */       case 1:
/* 3330 */         this.userName = paramProperties.getProperty("PROXY_USER_NAME");
/* 3331 */         str1 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/* 3332 */         if (this.userName != null) {
/* 3333 */           arrayOfByte1 = DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */         }
/* 3335 */         if (str1 != null)
/* 3336 */           arrayOfByte2 = DBConversion.stringToDriverCharBytes(str1, this.m_clientCharacterSet); 
/*      */         break;
/*      */       case 2:
/* 3339 */         str2 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/* 3340 */         if (str2 != null) {
/* 3341 */           arrayOfByte3 = DBConversion.stringToDriverCharBytes(str2, this.m_clientCharacterSet);
/*      */         }
/*      */         break;
/*      */       case 3:
/* 3345 */         object = paramProperties.get("PROXY_CERTIFICATE");
/* 3346 */         arrayOfByte4 = (byte[])object;
/*      */         break;
/*      */     } 
/* 3349 */     String[] arrayOfString = (String[])paramProperties.get("PROXY_ROLES");
/*      */     
/* 3351 */     if (arrayOfString != null) {
/*      */       
/* 3353 */       i = arrayOfString.length;
/* 3354 */       arrayOfByte = new byte[i][];
/* 3355 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 3357 */         if (arrayOfString[b] == null) {
/*      */           
/* 3359 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/* 3360 */           sQLException.fillInStackTrace();
/* 3361 */           throw sQLException;
/*      */         } 
/*      */         
/* 3364 */         arrayOfByte[b] = DBConversion.stringToDriverCharBytes(arrayOfString[b], this.m_clientCharacterSet);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3369 */     this.sqlWarning = checkError(t2cDoProxySession(this.m_nativeState, paramInt, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, i, arrayOfByte), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3383 */     this.isProxy = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeProxySession() throws SQLException {
/* 3390 */     checkError(t2cCloseProxySession(this.m_nativeState));
/* 3391 */     this.userName = this.savedUser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/*      */     boolean bool;
/*      */     int i;
/* 3399 */     String str = paramAutoKeyInfo.getTableName();
/*      */     
/* 3401 */     byte[] arrayOfByte = DBConversion.stringToDriverCharBytes(str, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 3409 */       bool = false;
/* 3410 */       i = t2cDescribeTable(this.m_nativeState, arrayOfByte, arrayOfByte.length, this.queryMetaData1, this.queryMetaData2, this.queryMetaData1Offset, this.queryMetaData2Offset, this.queryMetaData1Size, this.queryMetaData2Size);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3420 */       if (i == -1)
/*      */       {
/* 3422 */         checkError(i);
/*      */       }
/*      */ 
/*      */       
/* 3426 */       if (i != T2CStatement.T2C_EXTEND_BUFFER)
/*      */         continue; 
/* 3428 */       bool = true;
/*      */       
/* 3430 */       reallocateQueryMetaData(this.queryMetaData1Size * 2, this.queryMetaData2Size * 2);
/*      */     
/*      */     }
/* 3433 */     while (bool);
/*      */     
/* 3435 */     processDescribeTableData(i, paramAutoKeyInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processDescribeTableData(int paramInt, AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/* 3444 */     short[] arrayOfShort = this.queryMetaData1;
/* 3445 */     byte[] arrayOfByte = this.queryMetaData2;
/* 3446 */     int i = this.queryMetaData1Offset;
/* 3447 */     int j = this.queryMetaData2Offset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3461 */     paramAutoKeyInfo.allocateSpaceForDescribedData(paramInt);
/*      */     
/* 3463 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/* 3465 */       short s2 = arrayOfShort[i + 0];
/* 3466 */       short s1 = arrayOfShort[i + 6];
/* 3467 */       String str1 = bytes2String(arrayOfByte, j, s1, this.conversion);
/*      */ 
/*      */       
/* 3470 */       short s3 = arrayOfShort[i + 1];
/* 3471 */       short s4 = arrayOfShort[i + 11];
/* 3472 */       boolean bool = (arrayOfShort[i + 2] != 0) ? true : false;
/* 3473 */       short s5 = arrayOfShort[i + 5];
/* 3474 */       short s6 = arrayOfShort[i + 3];
/* 3475 */       short s7 = arrayOfShort[i + 4];
/* 3476 */       short s8 = arrayOfShort[i + 12];
/*      */       
/* 3478 */       j += s1;
/* 3479 */       i += 13;
/*      */       
/* 3481 */       String str2 = null;
/* 3482 */       if (s8 > 0) {
/*      */         
/* 3484 */         str2 = bytes2String(arrayOfByte, j, s8, this.conversion);
/*      */         
/* 3486 */         j += s8;
/*      */       } 
/*      */ 
/*      */       
/* 3490 */       paramAutoKeyInfo.fillDescribedData(b, str1, s2, (s4 > 0) ? s4 : s3, bool, s5, s6, s7, str2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 3504 */     checkError(t2cSetApplicationContext(this.m_nativeState, paramString1, paramString2, paramString3));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClearAllApplicationContext(String paramString) throws SQLException {
/* 3513 */     checkError(t2cClearAllApplicationContext(this.m_nativeState, paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doStartup(int paramInt) throws SQLException {
/* 3521 */     checkError(t2cStartupDatabase(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doShutdown(int paramInt) throws SQLException {
/* 3529 */     checkError(t2cShutdownDatabase(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void loadNativeLibrary(String paramString) throws SQLException {
/* 3541 */     if (paramString == null || paramString.equals("ocijdbc11")) {
/*      */       
/* 3543 */       synchronized (T2CConnection.class)
/*      */       {
/* 3545 */         if (!isLibraryLoaded)
/*      */         {
/* 3547 */           AccessController.doPrivileged(new PrivilegedAction()
/*      */               {
/*      */                 public Object run()
/*      */                 {
/* 3551 */                   System.loadLibrary("ocijdbc11");
/* 3552 */                   int i = T2CConnection.getLibraryVersionNumber();
/* 3553 */                   if (i != T2CConnection.JDBC_OCI_LIBRARY_VERSION) {
/* 3554 */                     throw new Error("Incompatible version of libocijdbc[Jdbc:" + T2CConnection.JDBC_OCI_LIBRARY_VERSION + ", Jdbc-OCI:" + i);
/*      */                   }
/*      */                   
/* 3557 */                   return null;
/*      */                 }
/*      */               });
/* 3560 */           isLibraryLoaded = true;
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 3567 */       synchronized (T2CConnection.class) {
/*      */ 
/*      */         
/*      */         try {
/* 3571 */           System.loadLibrary(paramString);
/* 3572 */           isLibraryLoaded = true;
/*      */         }
/* 3574 */         catch (SecurityException securityException) {
/*      */           
/* 3576 */           if (!isLibraryLoaded) {
/*      */             
/* 3578 */             System.loadLibrary(paramString);
/* 3579 */             isLibraryLoaded = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void checkTrue(boolean paramBoolean, int paramInt) throws SQLException {
/* 3592 */     if (!paramBoolean) {
/*      */       
/* 3594 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/* 3595 */       sQLException.fillInStackTrace();
/* 3596 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useLittleEndianSetCHARBinder() throws SQLException {
/* 3604 */     return t2cPlatformIsLittleEndian(this.m_nativeState);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 3612 */     getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final char[] getCharArray(String paramString) {
/* 3619 */     char[] arrayOfChar = null;
/*      */     
/* 3621 */     if (paramString == null) {
/*      */       
/* 3623 */       arrayOfChar = new char[0];
/*      */     }
/*      */     else {
/*      */       
/* 3627 */       arrayOfChar = new char[paramString.length()];
/*      */       
/* 3629 */       paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*      */     } 
/*      */     
/* 3632 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String bytes2String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, DBConversion paramDBConversion) throws SQLException {
/* 3642 */     byte[] arrayOfByte = new byte[paramInt2];
/* 3643 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*      */     
/* 3645 */     return paramDBConversion.CharBytesToString(arrayOfByte, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void disableNio() {
/* 3653 */     this.useNio = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static synchronized void doSetSessionTimeZone(String paramString) throws SQLException {
/* 3661 */     t2cSetSessionTimeZone(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void incrementTempLobReferenceCount(byte[] paramArrayOfbyte) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int decrementTempLobReferenceCount(byte[] paramArrayOfbyte) throws SQLException {
/* 3830 */     return 0;
/*      */   }
/* 3832 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   native int t2cAbort(long paramLong);
/*      */   
/*      */   native int t2cBlobRead(long paramLong1, byte[] paramArrayOfbyte1, int paramInt1, long paramLong2, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, boolean paramBoolean, ByteBuffer paramByteBuffer);
/*      */   
/*      */   native int t2cClobRead(long paramLong1, byte[] paramArrayOfbyte, int paramInt1, long paramLong2, int paramInt2, char[] paramArrayOfchar, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, ByteBuffer paramByteBuffer);
/*      */   
/*      */   native int t2cBlobWrite(long paramLong1, byte[] paramArrayOfbyte1, int paramInt1, long paramLong2, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, byte[][] paramArrayOfbyte);
/*      */   
/*      */   native int t2cClobWrite(long paramLong1, byte[] paramArrayOfbyte, int paramInt1, long paramLong2, int paramInt2, char[] paramArrayOfchar, int paramInt3, byte[][] paramArrayOfbyte1, boolean paramBoolean);
/*      */   
/*      */   native long t2cLobGetLength(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */   
/*      */   native int t2cBfileOpen(long paramLong, byte[] paramArrayOfbyte, int paramInt, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cBfileIsOpen(long paramLong, byte[] paramArrayOfbyte, int paramInt, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native int t2cBfileExists(long paramLong, byte[] paramArrayOfbyte, int paramInt, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native String t2cBfileGetName(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */   
/*      */   native String t2cBfileGetDirAlias(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */   
/*      */   native int t2cBfileClose(long paramLong, byte[] paramArrayOfbyte, int paramInt, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cLobGetChunkSize(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */   
/*      */   native int t2cLobTrim(long paramLong1, int paramInt1, long paramLong2, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cLobCreateTemporary(long paramLong, int paramInt1, boolean paramBoolean, int paramInt2, short paramShort, byte[][] paramArrayOfbyte);
/*      */   
/*      */   native int t2cLobFreeTemporary(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cLobIsTemporary(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native int t2cLobOpen(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   native int t2cLobIsOpen(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, boolean[] paramArrayOfboolean);
/*      */   
/*      */   native int t2cLobClose(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */   
/*      */   static native int getLibraryVersionNumber();
/*      */   
/*      */   static native short t2cGetServerSessionInfo(long paramLong, Properties paramProperties);
/*      */   
/*      */   static native short t2cGetDriverCharSetFromNlsLang();
/*      */   
/*      */   native int t2cDescribeError(long paramLong, T2CError paramT2CError, byte[] paramArrayOfbyte);
/*      */   
/*      */   native int t2cCreateState(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, byte[] paramArrayOfbyte6, int paramInt6, byte[] paramArrayOfbyte7, int paramInt7, short paramShort, int paramInt8, short[] paramArrayOfshort, byte[] paramArrayOfbyte8, byte[] paramArrayOfbyte9, long[] paramArrayOflong);
/*      */   
/*      */   native int t2cLogon(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, byte[] paramArrayOfbyte6, int paramInt6, byte[] paramArrayOfbyte7, int paramInt7, int paramInt8, short[] paramArrayOfshort, byte[] paramArrayOfbyte8, byte[] paramArrayOfbyte9, long[] paramArrayOflong);
/*      */   
/*      */   private native int t2cLogoff(long paramLong);
/*      */   
/*      */   private native int t2cCancel(long paramLong);
/*      */   
/*      */   private native byte t2cGetAsmVolProperty(long paramLong);
/*      */   
/*      */   private native byte t2cGetInstanceType(long paramLong);
/*      */   
/*      */   private native int t2cCreateStatement(long paramLong1, long paramLong2, byte[] paramArrayOfbyte, int paramInt1, OracleStatement paramOracleStatement, boolean paramBoolean, int paramInt2);
/*      */   
/*      */   private native int t2cSetAutoCommit(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native int t2cCommit(long paramLong, int paramInt);
/*      */   
/*      */   private native int t2cRollback(long paramLong);
/*      */   
/*      */   private native int t2cPingDatabase(long paramLong);
/*      */   
/*      */   private native byte[] t2cGetProductionVersion(long paramLong);
/*      */   
/*      */   private native int t2cGetVersionNumber(long paramLong);
/*      */   
/*      */   private native int t2cGetDefaultStreamChunkSize(long paramLong);
/*      */   
/*      */   native int t2cGetFormOfUse(long paramLong, OracleTypeCLOB paramOracleTypeCLOB, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*      */   
/*      */   native long t2cGetTDO(long paramLong, byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint);
/*      */   
/*      */   native int t2cCreateConnPool(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, short paramShort, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
/*      */   
/*      */   native int t2cConnPoolLogon(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, int paramInt6, int paramInt7, int paramInt8, String[] paramArrayOfString, byte[] paramArrayOfbyte6, int paramInt9, byte[] paramArrayOfbyte7, int paramInt10, byte[] paramArrayOfbyte8, int paramInt11, byte[] paramArrayOfbyte9, int paramInt12, byte[] paramArrayOfbyte10, int paramInt13, short[] paramArrayOfshort, byte[] paramArrayOfbyte11, byte[] paramArrayOfbyte12, long[] paramArrayOflong);
/*      */   
/*      */   native int t2cGetConnPoolInfo(long paramLong, Properties paramProperties);
/*      */   
/*      */   native int t2cSetConnPoolInfo(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */   
/*      */   native int t2cPasswordChange(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3);
/*      */   
/*      */   protected native byte[] t2cGetConnectionId(long paramLong);
/*      */   
/*      */   native int t2cGetHandles(long paramLong, long[] paramArrayOflong);
/*      */   
/*      */   native int t2cUseConnection(long paramLong1, long paramLong2, long paramLong3, long paramLong4, short[] paramArrayOfshort, long[] paramArrayOflong);
/*      */   
/*      */   native boolean t2cPlatformIsLittleEndian(long paramLong);
/*      */   
/*      */   native int t2cRegisterTAFCallback(long paramLong);
/*      */   
/*      */   native int t2cGetHeapAllocSize(long paramLong);
/*      */   
/*      */   native int t2cGetOciEnvHeapAllocSize(long paramLong);
/*      */   
/*      */   native int t2cDoProxySession(long paramLong, int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, byte[] paramArrayOfbyte3, int paramInt4, byte[] paramArrayOfbyte4, int paramInt5, int paramInt6, byte[][] paramArrayOfbyte);
/*      */   
/*      */   native int t2cCloseProxySession(long paramLong);
/*      */   
/*      */   static native int t2cDescribeTable(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, short[] paramArrayOfshort, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */   
/*      */   native int t2cSetApplicationContext(long paramLong, String paramString1, String paramString2, String paramString3);
/*      */   
/*      */   native int t2cClearAllApplicationContext(long paramLong, String paramString);
/*      */   
/*      */   native int t2cStartupDatabase(long paramLong, int paramInt);
/*      */   
/*      */   native int t2cShutdownDatabase(long paramLong, int paramInt);
/*      */   
/*      */   static native void t2cSetSessionTimeZone(String paramString);
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T2CConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */