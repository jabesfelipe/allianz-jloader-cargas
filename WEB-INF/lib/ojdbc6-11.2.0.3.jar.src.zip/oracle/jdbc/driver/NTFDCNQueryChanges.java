/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import oracle.jdbc.dcn.QueryChangeDescription;
/*     */ import oracle.jdbc.dcn.TableChangeDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFDCNQueryChanges
/*     */   implements QueryChangeDescription
/*     */ {
/*     */   private final long queryId;
/*     */   private final QueryChangeDescription.QueryChangeEventType queryopflags;
/*     */   private final int numberOfTables;
/*     */   private final NTFDCNTableChanges[] tcdesc;
/*     */   
/*     */   NTFDCNQueryChanges(ByteBuffer paramByteBuffer, int paramInt) {
/*  53 */     long l1 = (paramByteBuffer.getInt() & 0xFFFFFFFF);
/*  54 */     long l2 = (paramByteBuffer.getInt() & 0xFFFFFFFF);
/*  55 */     this.queryId = l1 | l2 << 32L;
/*  56 */     this.queryopflags = QueryChangeDescription.QueryChangeEventType.getQueryChangeEventType(paramByteBuffer.getInt());
/*  57 */     this.numberOfTables = paramByteBuffer.getShort();
/*  58 */     this.tcdesc = new NTFDCNTableChanges[this.numberOfTables];
/*  59 */     for (byte b = 0; b < this.tcdesc.length; b++) {
/*  60 */       this.tcdesc[b] = new NTFDCNTableChanges(paramByteBuffer, paramInt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getQueryId() {
/*  67 */     return this.queryId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryChangeDescription.QueryChangeEventType getQueryChangeEventType() {
/*  74 */     return this.queryopflags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableChangeDescription[] getTableChangeDescription() {
/*  81 */     return (TableChangeDescription[])this.tcdesc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  88 */     StringBuffer stringBuffer = new StringBuffer();
/*  89 */     stringBuffer.append("  query ID=" + this.queryId + ", query change event type=" + this.queryopflags + "\n");
/*  90 */     TableChangeDescription[] arrayOfTableChangeDescription = getTableChangeDescription();
/*  91 */     if (arrayOfTableChangeDescription != null) {
/*     */       
/*  93 */       stringBuffer.append("  Table Change Description (length=" + arrayOfTableChangeDescription.length + "):");
/*  94 */       for (byte b = 0; b < arrayOfTableChangeDescription.length; b++)
/*  95 */         stringBuffer.append(arrayOfTableChangeDescription[b].toString()); 
/*     */     } 
/*  97 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 102 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NTFDCNQueryChanges.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */