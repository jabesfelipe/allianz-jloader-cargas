/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ class ArrayDataResultSet extends BaseResultSet {
/*      */   Datum[] data;
/*      */   Map map;
/*      */   
/*      */   public ArrayDataResultSet(OracleConnection paramOracleConnection, Datum[] paramArrayOfDatum, Map paramMap) throws SQLException {
/*   54 */     this.connection = (PhysicalConnection)paramOracleConnection;
/*   55 */     this.data = paramArrayOfDatum;
/*   56 */     this.map = paramMap;
/*   57 */     this.currentIndex = 0;
/*   58 */     this.lastIndex = (this.data == null) ? 0 : this.data.length;
/*   59 */     this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
/*      */   }
/*      */ 
/*      */   
/*      */   private int currentIndex;
/*      */   
/*      */   private int lastIndex;
/*      */   
/*      */   PhysicalConnection connection;
/*      */   
/*      */   private Boolean wasNull;
/*      */   
/*      */   private int fetchSize;
/*      */   
/*      */   ARRAY array;
/*      */ 
/*      */   
/*      */   public ArrayDataResultSet(OracleConnection paramOracleConnection, Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException {
/*   77 */     this.connection = (PhysicalConnection)paramOracleConnection;
/*   78 */     this.data = paramArrayOfDatum;
/*   79 */     this.map = paramMap;
/*   80 */     this.currentIndex = (int)paramLong - 1;
/*      */     
/*   82 */     byte b = (this.data == null) ? 0 : this.data.length;
/*      */     
/*   84 */     this.lastIndex = this.currentIndex + Math.min(b - this.currentIndex, paramInt);
/*      */     
/*   86 */     this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayDataResultSet(OracleConnection paramOracleConnection, ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException {
/*   95 */     this.connection = (PhysicalConnection)paramOracleConnection;
/*   96 */     this.array = paramARRAY;
/*   97 */     this.map = paramMap;
/*   98 */     this.currentIndex = (int)paramLong - 1;
/*      */     
/*  100 */     byte b = (this.array == null) ? 0 : paramARRAY.length();
/*      */     
/*  102 */     this.lastIndex = this.currentIndex + ((paramInt == -1) ? (b - this.currentIndex) : Math.min(b - this.currentIndex, paramInt));
/*      */ 
/*      */     
/*  105 */     this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/*  113 */     if (this.closed) {
/*      */       
/*  115 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
/*  116 */       sQLException.fillInStackTrace();
/*  117 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  122 */     this.currentIndex++;
/*      */     
/*  124 */     return (this.currentIndex <= this.lastIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  130 */     synchronized (this.connection) {
/*      */       
/*  132 */       super.close();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  139 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  142 */       if (this.wasNull == null) {
/*      */         
/*  144 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24, (Object)null);
/*  145 */         sQLException.fillInStackTrace();
/*  146 */         throw sQLException;
/*      */       } 
/*      */       
/*  149 */       return this.wasNull.booleanValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  156 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  159 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  161 */       if (datum != null) {
/*  162 */         return datum.stringValue();
/*      */       }
/*  164 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/*  171 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/*  175 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
/*  176 */       sQLException.fillInStackTrace();
/*  177 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  188 */     if (this.currentIndex <= 0) {
/*      */       
/*  190 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14, (Object)null);
/*  191 */       sQLException1.fillInStackTrace();
/*  192 */       throw sQLException1;
/*      */     } 
/*      */     
/*  195 */     if (paramInt == 1) {
/*      */       
/*  197 */       this.wasNull = Boolean.FALSE;
/*      */       
/*  199 */       return (Datum)new NUMBER(this.currentIndex);
/*      */     } 
/*  201 */     if (paramInt == 2) {
/*      */       
/*  203 */       if (this.data != null) {
/*      */         
/*  205 */         this.wasNull = (this.data[this.currentIndex - 1] == null) ? Boolean.TRUE : Boolean.FALSE;
/*      */ 
/*      */         
/*  208 */         return this.data[this.currentIndex - 1];
/*      */       } 
/*  210 */       if (this.array != null) {
/*      */ 
/*      */ 
/*      */         
/*  214 */         Datum[] arrayOfDatum = this.array.getOracleArray(this.currentIndex, 1);
/*      */         
/*  216 */         if (arrayOfDatum != null && arrayOfDatum.length >= 1) {
/*      */           
/*  218 */           this.wasNull = (arrayOfDatum[0] == null) ? Boolean.TRUE : Boolean.FALSE;
/*      */           
/*  220 */           return arrayOfDatum[0];
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  225 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Out of sync");
/*  226 */       sQLException1.fillInStackTrace();
/*  227 */       throw sQLException1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  232 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, (Object)null);
/*  233 */     sQLException.fillInStackTrace();
/*  234 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/*  242 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  245 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  247 */       if (datum != null) {
/*      */         
/*  249 */         if (datum instanceof ROWID) {
/*  250 */           return (ROWID)datum;
/*      */         }
/*      */         
/*  253 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
/*  254 */         sQLException.fillInStackTrace();
/*  255 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  259 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/*  266 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  269 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  271 */       if (datum != null) {
/*      */         
/*  273 */         if (datum instanceof NUMBER) {
/*  274 */           return (NUMBER)datum;
/*      */         }
/*      */         
/*  277 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
/*  278 */         sQLException.fillInStackTrace();
/*  279 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  283 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/*  290 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  293 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  295 */       if (datum != null) {
/*      */         
/*  297 */         if (datum instanceof DATE) {
/*  298 */           return (DATE)datum;
/*      */         }
/*      */         
/*  301 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
/*  302 */         sQLException.fillInStackTrace();
/*  303 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  307 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  314 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  317 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  319 */       if (datum != null) {
/*      */         
/*  321 */         if (datum instanceof ARRAY) {
/*  322 */           return (ARRAY)datum;
/*      */         }
/*      */         
/*  325 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
/*  326 */         sQLException.fillInStackTrace();
/*  327 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  331 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/*  338 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  341 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  343 */       if (datum != null) {
/*      */         
/*  345 */         if (datum instanceof STRUCT) {
/*  346 */           return (STRUCT)datum;
/*      */         }
/*      */         
/*  349 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
/*  350 */         sQLException.fillInStackTrace();
/*  351 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  355 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/*  362 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  365 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  367 */       if (datum != null) {
/*      */         
/*  369 */         if (datum instanceof OPAQUE) {
/*  370 */           return (OPAQUE)datum;
/*      */         }
/*      */         
/*  373 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
/*  374 */         sQLException.fillInStackTrace();
/*  375 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  379 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/*  386 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  389 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  391 */       if (datum != null) {
/*      */         
/*  393 */         if (datum instanceof REF) {
/*  394 */           return (REF)datum;
/*      */         }
/*      */         
/*  397 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
/*  398 */         sQLException.fillInStackTrace();
/*  399 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  403 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/*  410 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  413 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  415 */       if (datum != null) {
/*      */         
/*  417 */         if (datum instanceof CHAR) {
/*  418 */           return (CHAR)datum;
/*      */         }
/*      */         
/*  421 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
/*  422 */         sQLException.fillInStackTrace();
/*  423 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  427 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/*  434 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  437 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  439 */       if (datum != null) {
/*      */         
/*  441 */         if (datum instanceof RAW) {
/*  442 */           return (RAW)datum;
/*      */         }
/*      */         
/*  445 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
/*  446 */         sQLException.fillInStackTrace();
/*  447 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  451 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/*  458 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  461 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  463 */       if (datum != null) {
/*      */         
/*  465 */         if (datum instanceof BLOB) {
/*  466 */           return (BLOB)datum;
/*      */         }
/*      */         
/*  469 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
/*  470 */         sQLException.fillInStackTrace();
/*  471 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  475 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/*  482 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  485 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  487 */       if (datum != null) {
/*      */         
/*  489 */         if (datum instanceof CLOB) {
/*  490 */           return (CLOB)datum;
/*      */         }
/*      */         
/*  493 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/*  494 */         sQLException.fillInStackTrace();
/*  495 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  499 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/*  506 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  509 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  511 */       if (datum != null) {
/*      */         
/*  513 */         if (datum instanceof BFILE) {
/*  514 */           return (BFILE)datum;
/*      */         }
/*      */         
/*  517 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
/*  518 */         sQLException.fillInStackTrace();
/*  519 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  523 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/*  530 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  533 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  535 */       if (datum != null) {
/*      */         
/*  537 */         if (datum instanceof INTERVALDS) {
/*  538 */           return (INTERVALDS)datum;
/*      */         }
/*      */         
/*  541 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  542 */         sQLException.fillInStackTrace();
/*  543 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  547 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/*  554 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  557 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  559 */       if (datum != null) {
/*      */         
/*  561 */         if (datum instanceof INTERVALYM) {
/*  562 */           return (INTERVALYM)datum;
/*      */         }
/*      */         
/*  565 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  566 */         sQLException.fillInStackTrace();
/*  567 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  571 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/*  579 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  582 */       return getBFILE(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/*  589 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  592 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  594 */       if (datum != null) {
/*      */         
/*  596 */         if (datum instanceof TIMESTAMP) {
/*  597 */           return (TIMESTAMP)datum;
/*      */         }
/*      */         
/*  600 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
/*  601 */         sQLException.fillInStackTrace();
/*  602 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  606 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/*  613 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  616 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  618 */       if (datum != null) {
/*      */         
/*  620 */         if (datum instanceof TIMESTAMPTZ) {
/*  621 */           return (TIMESTAMPTZ)datum;
/*      */         }
/*      */         
/*  624 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
/*  625 */         sQLException.fillInStackTrace();
/*  626 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  630 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/*  637 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  640 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  642 */       if (datum != null) {
/*      */         
/*  644 */         if (datum instanceof TIMESTAMPLTZ) {
/*  645 */           return (TIMESTAMPLTZ)datum;
/*      */         }
/*      */         
/*  648 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
/*  649 */         sQLException.fillInStackTrace();
/*  650 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  654 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  661 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  664 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  666 */       if (datum != null) {
/*  667 */         return datum.booleanValue();
/*      */       }
/*  669 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/*  678 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  684 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  687 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  689 */       if (datum != null) {
/*  690 */         return datum.byteValue();
/*      */       }
/*  692 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/*  699 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  702 */       long l = getLong(paramInt);
/*      */       
/*  704 */       if (l > 65537L || l < -65538L) {
/*      */         
/*  706 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
/*  707 */         sQLException.fillInStackTrace();
/*  708 */         throw sQLException;
/*      */       } 
/*      */       
/*  711 */       return (short)(int)l;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  718 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  721 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  723 */       if (datum != null)
/*      */       {
/*  725 */         return datum.intValue();
/*      */       }
/*      */       
/*  728 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  735 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  738 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  740 */       if (datum != null)
/*      */       {
/*  742 */         return datum.longValue();
/*      */       }
/*      */       
/*  745 */       return 0L;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  752 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  755 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  757 */       if (datum != null)
/*      */       {
/*  759 */         return datum.floatValue();
/*      */       }
/*      */       
/*  762 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  769 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  772 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  774 */       if (datum != null)
/*      */       {
/*  776 */         return datum.doubleValue();
/*      */       }
/*      */       
/*  779 */       return 0.0D;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  787 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  790 */       Datum datum = getOracleObject(paramInt1);
/*      */       
/*  792 */       if (datum != null)
/*      */       {
/*  794 */         return datum.bigDecimalValue();
/*      */       }
/*      */       
/*  797 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  804 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  807 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  809 */       if (datum != null) {
/*      */         
/*  811 */         if (datum instanceof RAW) {
/*  812 */           return ((RAW)datum).shareBytes();
/*      */         }
/*      */         
/*  815 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBytes");
/*  816 */         sQLException.fillInStackTrace();
/*  817 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  821 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  828 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  831 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  833 */       if (datum != null)
/*      */       {
/*  835 */         return datum.dateValue();
/*      */       }
/*      */       
/*  838 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/*  845 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  848 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  850 */       if (datum != null)
/*      */       {
/*  852 */         return datum.timeValue();
/*      */       }
/*      */       
/*  855 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  863 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  866 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  868 */       if (datum != null)
/*      */       {
/*  870 */         return datum.timestampValue();
/*      */       }
/*      */       
/*  873 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/*  881 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  884 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  886 */       if (datum != null)
/*      */       {
/*  888 */         datum.asciiStreamValue();
/*      */       }
/*      */       
/*  891 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/*  899 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  902 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  904 */       if (datum != null) {
/*      */         
/*  906 */         DBConversion dBConversion = this.connection.conversion;
/*  907 */         byte[] arrayOfByte = datum.shareBytes();
/*      */         
/*  909 */         if (datum instanceof RAW)
/*      */         {
/*  911 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
/*      */         }
/*  913 */         if (datum instanceof CHAR)
/*      */         {
/*  915 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
/*      */         }
/*      */ 
/*      */         
/*  919 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
/*  920 */         sQLException.fillInStackTrace();
/*  921 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  925 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/*  933 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  936 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  938 */       if (datum != null)
/*      */       {
/*  940 */         return datum.binaryStreamValue();
/*      */       }
/*      */       
/*  943 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/*  950 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/*  954 */       return getObject(paramInt, this.map);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/*  965 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  968 */       Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  973 */       return paramCustomDatumFactory.create(datum, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/*  981 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  984 */       Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  989 */       return paramORADataFactory.create(datum, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*  999 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1002 */       if (this.closed) {
/*      */         
/* 1004 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
/* 1005 */         sQLException1.fillInStackTrace();
/* 1006 */         throw sQLException1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1012 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getMetaData");
/* 1013 */       sQLException.fillInStackTrace();
/* 1014 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 1023 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1026 */       if (paramString.equalsIgnoreCase("index"))
/* 1027 */         return 1; 
/* 1028 */       if (paramString.equalsIgnoreCase("value")) {
/* 1029 */         return 2;
/*      */       }
/*      */       
/* 1032 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, "get_column_index");
/* 1033 */       sQLException.fillInStackTrace();
/* 1034 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/* 1049 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1056 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1059 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1061 */       if (datum != null) {
/*      */         
/* 1063 */         if (datum instanceof STRUCT) {
/* 1064 */           return ((STRUCT)datum).toJdbc(paramMap);
/*      */         }
/* 1066 */         return datum.toJdbc();
/*      */       } 
/*      */       
/* 1069 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 1076 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1079 */       return (Ref)getREF(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 1086 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1089 */       return (Blob)getBLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 1096 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1099 */       return (Clob)getCLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 1107 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1110 */       return (Array)getARRAY(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1125 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1128 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1130 */       if (datum != null)
/*      */       {
/* 1132 */         return datum.characterStreamValue();
/*      */       }
/*      */       
/* 1135 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 1143 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1146 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1148 */       if (datum != null)
/*      */       {
/* 1150 */         return datum.bigDecimalValue();
/*      */       }
/*      */       
/* 1153 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1161 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1164 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1166 */       if (datum != null) {
/*      */         
/* 1168 */         DATE dATE = null;
/*      */         
/* 1170 */         if (datum instanceof DATE) {
/* 1171 */           dATE = (DATE)datum;
/*      */         } else {
/* 1173 */           dATE = new DATE(datum.stringValue());
/*      */         } 
/* 1175 */         if (dATE != null) {
/* 1176 */           return dATE.dateValue(paramCalendar);
/*      */         }
/*      */       } 
/* 1179 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1187 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1190 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1192 */       if (datum != null) {
/*      */         
/* 1194 */         DATE dATE = null;
/*      */         
/* 1196 */         if (datum instanceof DATE) {
/* 1197 */           dATE = (DATE)datum;
/*      */         } else {
/* 1199 */           dATE = new DATE(datum.stringValue());
/*      */         } 
/* 1201 */         if (dATE != null) {
/* 1202 */           return dATE.timeValue(paramCalendar);
/*      */         }
/*      */       } 
/* 1205 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1213 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1216 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1218 */       if (datum != null) {
/*      */         
/* 1220 */         DATE dATE = null;
/*      */         
/* 1222 */         if (datum instanceof DATE) {
/* 1223 */           dATE = (DATE)datum;
/*      */         } else {
/* 1225 */           dATE = new DATE(datum.stringValue());
/*      */         } 
/* 1227 */         if (dATE != null) {
/* 1228 */           return dATE.timestampValue(paramCalendar);
/*      */         }
/*      */       } 
/* 1231 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1240 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1277 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 1278 */       sQLException.fillInStackTrace();
/* 1279 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 1287 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1290 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 1291 */       sQLException.fillInStackTrace();
/* 1292 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 1306 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 1308 */     if (datum != null) {
/*      */       
/* 1310 */       if (datum instanceof oracle.sql.NCLOB) {
/* 1311 */         return (NClob)datum;
/*      */       }
/*      */       
/* 1314 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1315 */       sQLException.fillInStackTrace();
/* 1316 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1320 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 1327 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 1329 */     if (datum != null)
/*      */     {
/* 1331 */       return datum.stringValue();
/*      */     }
/*      */     
/* 1334 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 1342 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 1344 */     if (datum != null)
/*      */     {
/* 1346 */       return datum.characterStreamValue();
/*      */     }
/*      */     
/* 1349 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 1356 */     return (RowId)getROWID(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 1364 */     Datum datum = getOracleObject(paramInt);
/*      */     
/* 1366 */     if (datum != null) {
/*      */       
/* 1368 */       if (datum instanceof SQLXML) {
/* 1369 */         return (SQLXML)datum;
/*      */       }
/*      */       
/* 1372 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1373 */       sQLException.fillInStackTrace();
/* 1374 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1378 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/* 1392 */     if (this.closed) {
/*      */       
/* 1394 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1395 */       sQLException.fillInStackTrace();
/* 1396 */       throw sQLException;
/*      */     } 
/* 1398 */     return (this.currentIndex < 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/* 1406 */     if (this.closed) {
/*      */       
/* 1408 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1409 */       sQLException.fillInStackTrace();
/* 1410 */       throw sQLException;
/*      */     } 
/* 1412 */     return (this.currentIndex > this.lastIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/* 1420 */     if (this.closed) {
/*      */       
/* 1422 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1423 */       sQLException.fillInStackTrace();
/* 1424 */       throw sQLException;
/*      */     } 
/* 1426 */     return (this.currentIndex == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/* 1434 */     if (this.closed) {
/*      */       
/* 1436 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1437 */       sQLException.fillInStackTrace();
/* 1438 */       throw sQLException;
/*      */     } 
/* 1440 */     return (this.currentIndex == this.lastIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/* 1448 */     if (this.closed) {
/*      */       
/* 1450 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1451 */       sQLException.fillInStackTrace();
/* 1452 */       throw sQLException;
/*      */     } 
/* 1454 */     return this.currentIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 1466 */     if (paramInt < 0) {
/*      */       
/* 1468 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 1469 */       sQLException.fillInStackTrace();
/* 1470 */       throw sQLException;
/*      */     } 
/* 1472 */     if (paramInt == 0) {
/* 1473 */       this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
/*      */     } else {
/* 1475 */       this.fetchSize = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 1482 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1497 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1502 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\ArrayDataResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */