/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CPreparedStatement
/*      */   extends OraclePreparedStatement
/*      */ {
/*      */   T4CPreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   29 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */ 
/*      */     
/*   32 */     this.nbPostPonedColumns = new int[1];
/*   33 */     this.nbPostPonedColumns[0] = 0;
/*   34 */     this.indexOfPostPonedColumn = new int[1][3];
/*   35 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*      */     
/*   37 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   38 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   39 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   40 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   47 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   67 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   68 */       this.oacdefSent = null;
/*      */     }
/*   70 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.doOall8");
/*      */     
/*   72 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   76 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   77 */       sQLException.fillInStackTrace();
/*   78 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   82 */     if (paramBoolean3) {
/*   83 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   85 */     int i = this.numberOfDefinePositions;
/*      */     
/*   87 */     if (this.sqlKind.isDML()) {
/*   88 */       i = 0;
/*      */     }
/*      */     
/*   91 */     if (this.accessors != null)
/*   92 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   93 */         if (this.accessors[b] != null)
/*   94 */           (this.accessors[b]).lastRowProcessed = 0; 
/*   95 */       }   if (this.outBindAccessors != null)
/*   96 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   97 */         if (this.outBindAccessors[b] != null)
/*   98 */           (this.outBindAccessors[b]).lastRowProcessed = 0; 
/*   99 */       }   if (this.returnParamAccessors != null) {
/*  100 */       for (byte b = 0; b < this.returnParamAccessors.length; b++) {
/*  101 */         if (this.returnParamAccessors[b] != null) {
/*  102 */           (this.returnParamAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  109 */     if (this.bindIndicators != null) {
/*      */       
/*  111 */       int j = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  114 */       int k = 0;
/*      */       
/*  116 */       if (this.ibtBindChars != null) {
/*  117 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  119 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  121 */         int m = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  125 */         int n = this.bindIndicators[m + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  129 */         if (n != 0) {
/*      */ 
/*      */           
/*  132 */           int i1 = this.bindIndicators[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  136 */           if (i1 == 2) {
/*      */             
/*  138 */             k = Math.max(n * this.connection.conversion.maxNCharSize, k);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  143 */             k = Math.max(n * this.connection.conversion.cMaxCharSize, k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  149 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  151 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  153 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  155 */         this.tmpBindsByteArray = null;
/*  156 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  168 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  173 */     int[] arrayOfInt1 = this.definedColumnType;
/*  174 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  175 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  181 */     if (paramBoolean5 && paramBoolean4 && this.sqlObject.includeRowid) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  186 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  187 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  188 */       arrayOfInt1[0] = -8;
/*  189 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  190 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  191 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  192 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  198 */     allocateTmpByteArray();
/*      */     
/*  200 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */     
/*  202 */     this.t4Connection.sendPiggyBackedMessages();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  207 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  219 */       int j = t4C8Oall.getCursorId();
/*  220 */       if (j != 0) {
/*  221 */         this.cursorId = j;
/*      */       }
/*  223 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*      */     }
/*  225 */     catch (SQLException sQLException) {
/*      */       
/*  227 */       int j = t4C8Oall.getCursorId();
/*  228 */       if (j != 0) {
/*  229 */         this.cursorId = j;
/*      */       }
/*  231 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  234 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  239 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  249 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  252 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  254 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  258 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  270 */     super.releaseBuffers();
/*  271 */     this.tmpByteArray = null;
/*  272 */     this.tmpBindsByteArray = null;
/*      */     
/*  274 */     this.t4Connection.all8.bindChars = null;
/*  275 */     this.t4Connection.all8.bindBytes = null;
/*  276 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  283 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  296 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  307 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  315 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  317 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  323 */     if (paramInt1 < 1) {
/*      */       
/*  325 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  326 */       sQLException.fillInStackTrace();
/*  327 */       throw sQLException;
/*      */     } 
/*  329 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/*  333 */       if (paramInt2 == 1 || paramInt2 == 12 || paramInt2 == -15 || paramInt2 == -9)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  339 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  345 */     else if (paramInt3 < 0) {
/*      */       
/*  347 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  348 */       sQLException.fillInStackTrace();
/*  349 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  353 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  355 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  356 */       sQLException.fillInStackTrace();
/*  357 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  364 */     int i = paramInt1 - 1;
/*      */     
/*  366 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  368 */       if (this.definedColumnType == null) {
/*      */         
/*  370 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  382 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  384 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  387 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  393 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  395 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  397 */       if (this.definedColumnSize == null) {
/*  398 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  401 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  403 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  406 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  410 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  412 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  414 */       if (this.definedColumnFormOfUse == null) {
/*  415 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  418 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  420 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  423 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  427 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  429 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  431 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  436 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  440 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  446 */           this.needToPrepareDefineBuffer = true;
/*  447 */           this.columnsDefinedByUser = true;
/*      */           
/*  449 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  450 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  459 */     synchronized (this.connection) {
/*      */       
/*  461 */       super.clearDefines();
/*  462 */       this.definedColumnType = null;
/*  463 */       this.definedColumnSize = null;
/*  464 */       this.definedColumnFormOfUse = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException {
/*  482 */     boolean bool = (this.rowPrefetchInLastFetch < this.rowPrefetch) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  511 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  520 */       paramArrayOfshort = new short[this.defineIndicators.length];
/*  521 */       int j = (this.accessors[0]).lengthIndexLastRow;
/*  522 */       int k = (this.accessors[0]).indicatorIndexLastRow;
/*      */       
/*  524 */       int m = bool ? this.accessors.length : 1;
/*  525 */       for (; bool ? (m >= 1) : (m <= this.accessors.length); 
/*  526 */         m += bool ? -1 : 1) {
/*      */         
/*  528 */         int n = j + this.rowPrefetchInLastFetch * m - 1;
/*  529 */         int i1 = k + this.rowPrefetchInLastFetch * m - 1;
/*  530 */         paramArrayOfshort[i1] = this.defineIndicators[i1];
/*  531 */         paramArrayOfshort[n] = this.defineIndicators[n];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  538 */     int i = bool ? (this.accessors.length - 1) : 0;
/*  539 */     for (; bool ? (i > -1) : (i < this.accessors.length); 
/*  540 */       i += bool ? -1 : 1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  547 */       this.accessors[i].saveDataFromOldDefineBuffers(paramArrayOfbyte, paramArrayOfchar, paramArrayOfshort, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  554 */     super.saveDefineBuffersIfRequired(paramArrayOfchar, paramArrayOfbyte, paramArrayOfshort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  564 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  584 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  586 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  590 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  596 */         if (!paramBoolean) {
/*      */           
/*  598 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  606 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  612 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  618 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  624 */         if (!paramBoolean) {
/*      */           
/*  626 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  634 */         if (paramBoolean && paramString != null) {
/*      */           
/*  636 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  637 */           sQLException1.fillInStackTrace();
/*  638 */           throw sQLException1;
/*      */         } 
/*      */         
/*  641 */         if (paramBoolean) {
/*  642 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  645 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  651 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  657 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  663 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  669 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  673 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  676 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  683 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  689 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  695 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  701 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  707 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  713 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  716 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  721 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  724 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  731 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  737 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  743 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  749 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  755 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  771 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  772 */         sQLException.fillInStackTrace();
/*  773 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  777 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  804 */     if (!this.isOpen) {
/*      */ 
/*      */       
/*  807 */       this.connection.open(this);
/*  808 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  814 */       this.t4Connection.needLine();
/*  815 */       this.t4Connection.sendPiggyBackedMessages();
/*  816 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  817 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  819 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  821 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  822 */         this.accessors[b].initMetadata();
/*      */       }
/*  824 */     } catch (IOException iOException) {
/*      */       
/*  826 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  829 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  830 */       sQLException.fillInStackTrace();
/*  831 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  835 */     this.describedWithNames = true;
/*  836 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  871 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.execute_for_describe");
/*      */     
/*      */     try {
/*  874 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  880 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  884 */         doOall8(true, true, false, true, (this.definedColumnType != null));
/*      */       }
/*      */     
/*  887 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  890 */       throw sQLException;
/*      */     }
/*  892 */     catch (IOException iOException) {
/*      */       
/*  894 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  896 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  897 */       sQLException.fillInStackTrace();
/*  898 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  903 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  904 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     } 
/*      */     
/*  907 */     this.needToParse = false;
/*      */ 
/*      */     
/*  910 */     if (this.connection.calculateChecksum) {
/*  911 */       if (this.validRows > 0) {
/*  912 */         calculateCheckSum();
/*  913 */       } else if (this.rowsProcessed > 0) {
/*  914 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  916 */         this.checkSum = l;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  926 */     if (this.definedColumnType == null) {
/*  927 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  929 */     this.aFetchWasDoneDuringDescribe = false;
/*  930 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  932 */       this.aFetchWasDoneDuringDescribe = true;
/*  933 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  937 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  938 */       this.accessors[b].initMetadata();
/*      */     }
/*  940 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  982 */         boolean bool = false;
/*  983 */         if (this.columnsDefinedByUser) {
/*  984 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1004 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1012 */           boolean bool1 = false;
/* 1013 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1014 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1016 */           for (byte b = 0; b < this.accessors.length; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1021 */             arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/* 1022 */             if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1028 */               bool1 = true;
/* 1029 */               (this.accessors[b]).lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1030 */               arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */             } 
/*      */           } 
/*      */           
/* 1034 */           if (bool1) {
/*      */             
/* 1036 */             this.definedColumnType = arrayOfInt1;
/* 1037 */             this.definedColumnSize = arrayOfInt2;
/* 1038 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1044 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1046 */         this.needToParse = false;
/* 1047 */         if (bool) {
/* 1048 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/* 1052 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     
/* 1055 */     } catch (SQLException sQLException) {
/*      */       
/* 1057 */       throw sQLException;
/*      */     }
/* 1059 */     catch (IOException iOException) {
/*      */       
/* 1061 */       ((T4CConnection)this.connection).handleIOException(iOException);
/* 1062 */       calculateCheckSum();
/*      */       
/* 1064 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1065 */       sQLException.fillInStackTrace();
/* 1066 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1093 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1097 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1101 */           this.nextStream.close();
/*      */         }
/* 1103 */         catch (IOException iOException) {
/*      */           
/* 1105 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1107 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1108 */           sQLException.fillInStackTrace();
/* 1109 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1113 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1119 */       doOall8(false, false, true, false, false);
/*      */       
/* 1121 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/* 1123 */     catch (IOException iOException) {
/*      */       
/* 1125 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1127 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1128 */       sQLException.fillInStackTrace();
/* 1129 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1135 */     calculateCheckSum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1150 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1152 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1154 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1157 */     } catch (IOException iOException) {
/*      */       
/* 1159 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1161 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1162 */       sQLException.fillInStackTrace();
/* 1163 */       throw sQLException;
/*      */     
/*      */     }
/* 1166 */     catch (SQLException sQLException) {
/*      */       
/* 1168 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1171 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1176 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1200 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.do_close");
/*      */ 
/*      */     
/*      */     try {
/* 1204 */       if (this.cursorId != 0)
/*      */       {
/* 1206 */         this.t4Connection.cursorToClose[this.t4Connection.cursorToCloseOffset++] = this.cursorId;
/*      */ 
/*      */         
/* 1209 */         if (this.t4Connection.cursorToCloseOffset >= this.t4Connection.cursorToClose.length)
/*      */         {
/*      */           
/* 1212 */           this.t4Connection.sendPiggyBackedMessages();
/*      */         }
/*      */       }
/*      */     
/* 1216 */     } catch (IOException iOException) {
/*      */       
/* 1218 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1220 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1221 */       sQLException.fillInStackTrace();
/* 1222 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1226 */     this.tmpByteArray = null;
/* 1227 */     this.tmpBindsByteArray = null;
/* 1228 */     this.definedColumnType = null;
/* 1229 */     this.definedColumnSize = null;
/* 1230 */     this.definedColumnFormOfUse = null;
/* 1231 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1251 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.closeQuery");
/*      */ 
/*      */     
/* 1254 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1258 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1262 */           this.nextStream.close();
/*      */         }
/* 1264 */         catch (IOException iOException) {
/*      */           
/* 1266 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1268 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1269 */           sQLException.fillInStackTrace();
/* 1270 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1274 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Binder getRowidNullBinder(int paramInt) {
/* 1323 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */       
/* 1326 */       this.currentRowCharLens[paramInt] = 1;
/* 1327 */       return this.theVarcharNullBinder;
/*      */     } 
/*      */     
/* 1330 */     return this.theRowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doLocalInitialization() {
/* 1339 */     super.doLocalInitialization();
/*      */     
/* 1341 */     this.t4Connection.all8.bindChars = this.bindChars;
/* 1342 */     this.t4Connection.all8.bindBytes = this.bindBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1348 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CPreparedStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */