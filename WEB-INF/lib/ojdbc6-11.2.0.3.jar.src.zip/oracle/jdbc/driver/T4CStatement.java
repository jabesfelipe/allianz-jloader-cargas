/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CStatement
/*      */   extends OracleStatement
/*      */ {
/*   23 */   static final byte[][][] parameterDatum = (byte[][][])null;
/*   24 */   static final OracleTypeADT[][] parameterOtype = (OracleTypeADT[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   33 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   53 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   54 */       this.oacdefSent = null;
/*      */     }
/*   56 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.doOall8");
/*      */     
/*   58 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   62 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   63 */       sQLException.fillInStackTrace();
/*   64 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   68 */     if (paramBoolean3) {
/*   69 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   71 */     int i = this.numberOfDefinePositions;
/*      */     
/*   73 */     if (this.sqlKind.isDML()) {
/*   74 */       i = 0;
/*      */     }
/*      */     
/*   77 */     if (this.accessors != null)
/*   78 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   79 */         if (this.accessors[b] != null)
/*   80 */           (this.accessors[b]).lastRowProcessed = 0; 
/*   81 */       }   if (this.outBindAccessors != null)
/*   82 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   83 */         if (this.outBindAccessors[b] != null)
/*   84 */           (this.outBindAccessors[b]).lastRowProcessed = 0; 
/*   85 */       }   if (this.returnParamAccessors != null) {
/*   86 */       for (byte b = 0; b < this.returnParamAccessors.length; b++) {
/*   87 */         if (this.returnParamAccessors[b] != null) {
/*   88 */           (this.returnParamAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*   95 */     if (this.bindIndicators != null) {
/*      */       
/*   97 */       int j = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  100 */       int k = 0;
/*      */       
/*  102 */       if (this.ibtBindChars != null) {
/*  103 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  105 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  107 */         int m = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  111 */         int n = this.bindIndicators[m + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  115 */         if (n != 0) {
/*      */ 
/*      */           
/*  118 */           int i1 = this.bindIndicators[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  122 */           if (i1 == 2) {
/*      */             
/*  124 */             k = Math.max(n * this.connection.conversion.maxNCharSize, k);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  129 */             k = Math.max(n * this.connection.conversion.cMaxCharSize, k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  135 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  137 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  139 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  141 */         this.tmpBindsByteArray = null;
/*  142 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  154 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  159 */     int[] arrayOfInt1 = this.definedColumnType;
/*  160 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  161 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  167 */     if (paramBoolean5 && paramBoolean4 && this.sqlObject.includeRowid) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  172 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  173 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  174 */       arrayOfInt1[0] = -8;
/*  175 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  176 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  177 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  178 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  184 */     allocateTmpByteArray();
/*      */     
/*  186 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */     
/*  188 */     this.t4Connection.sendPiggyBackedMessages();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  193 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, parameterDatum, parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  205 */       int j = t4C8Oall.getCursorId();
/*  206 */       if (j != 0) {
/*  207 */         this.cursorId = j;
/*      */       }
/*  209 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*      */     }
/*  211 */     catch (SQLException sQLException) {
/*      */       
/*  213 */       int j = t4C8Oall.getCursorId();
/*  214 */       if (j != 0) {
/*  215 */         this.cursorId = j;
/*      */       }
/*  217 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  220 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  225 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  235 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  238 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  240 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  244 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  256 */     super.releaseBuffers();
/*  257 */     this.tmpByteArray = null;
/*  258 */     this.tmpBindsByteArray = null;
/*      */     
/*  260 */     this.t4Connection.all8.bindChars = null;
/*  261 */     this.t4Connection.all8.bindBytes = null;
/*  262 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  269 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  282 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  293 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  301 */     if (paramInt2 == -15 || paramInt2 == -9 || paramInt2 == -16)
/*      */     {
/*  303 */       paramShort = 2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  309 */     if (paramInt1 < 1) {
/*      */       
/*  311 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  312 */       sQLException.fillInStackTrace();
/*  313 */       throw sQLException;
/*      */     } 
/*  315 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/*  319 */       if (paramInt2 == 1 || paramInt2 == 12 || paramInt2 == -15 || paramInt2 == -9)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  325 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  331 */     else if (paramInt3 < 0) {
/*      */       
/*  333 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  334 */       sQLException.fillInStackTrace();
/*  335 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  339 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  341 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  342 */       sQLException.fillInStackTrace();
/*  343 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  350 */     int i = paramInt1 - 1;
/*      */     
/*  352 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  354 */       if (this.definedColumnType == null) {
/*      */         
/*  356 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  368 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  370 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  373 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  379 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  381 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  383 */       if (this.definedColumnSize == null) {
/*  384 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  387 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  389 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  392 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  396 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  398 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  400 */       if (this.definedColumnFormOfUse == null) {
/*  401 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  404 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  406 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  409 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  413 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  415 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  417 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  422 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  426 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  432 */           this.needToPrepareDefineBuffer = true;
/*  433 */           this.columnsDefinedByUser = true;
/*      */           
/*  435 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  436 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  445 */     synchronized (this.connection) {
/*      */       
/*  447 */       super.clearDefines();
/*  448 */       this.definedColumnType = null;
/*  449 */       this.definedColumnSize = null;
/*  450 */       this.definedColumnFormOfUse = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException {
/*  468 */     boolean bool = (this.rowPrefetchInLastFetch < this.rowPrefetch) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  497 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  506 */       paramArrayOfshort = new short[this.defineIndicators.length];
/*  507 */       int j = (this.accessors[0]).lengthIndexLastRow;
/*  508 */       int k = (this.accessors[0]).indicatorIndexLastRow;
/*      */       
/*  510 */       int m = bool ? this.accessors.length : 1;
/*  511 */       for (; bool ? (m >= 1) : (m <= this.accessors.length); 
/*  512 */         m += bool ? -1 : 1) {
/*      */         
/*  514 */         int n = j + this.rowPrefetchInLastFetch * m - 1;
/*  515 */         int i1 = k + this.rowPrefetchInLastFetch * m - 1;
/*  516 */         paramArrayOfshort[i1] = this.defineIndicators[i1];
/*  517 */         paramArrayOfshort[n] = this.defineIndicators[n];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  524 */     int i = bool ? (this.accessors.length - 1) : 0;
/*  525 */     for (; bool ? (i > -1) : (i < this.accessors.length); 
/*  526 */       i += bool ? -1 : 1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  533 */       this.accessors[i].saveDataFromOldDefineBuffers(paramArrayOfbyte, paramArrayOfchar, paramArrayOfshort, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  540 */     super.saveDefineBuffersIfRequired(paramArrayOfchar, paramArrayOfbyte, paramArrayOfshort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  550 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  570 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  572 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  576 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  582 */         if (!paramBoolean) {
/*      */           
/*  584 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  592 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  598 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  604 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  610 */         if (!paramBoolean) {
/*      */           
/*  612 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  620 */         if (paramBoolean && paramString != null) {
/*      */           
/*  622 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  623 */           sQLException1.fillInStackTrace();
/*  624 */           throw sQLException1;
/*      */         } 
/*      */         
/*  627 */         if (paramBoolean) {
/*  628 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  631 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  637 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  643 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  649 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  655 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  659 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  662 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  669 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  675 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  681 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  687 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  693 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  699 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  702 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  707 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  710 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  717 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  723 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  729 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  735 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  741 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  757 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  758 */         sQLException.fillInStackTrace();
/*  759 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  763 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  790 */     if (!this.isOpen) {
/*      */ 
/*      */ 
/*      */       
/*  794 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/*  795 */       sQLException.fillInStackTrace();
/*  796 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  803 */       this.t4Connection.needLine();
/*  804 */       this.t4Connection.sendPiggyBackedMessages();
/*  805 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  806 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  808 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  810 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  811 */         this.accessors[b].initMetadata();
/*      */       }
/*  813 */     } catch (IOException iOException) {
/*      */       
/*  815 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  818 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  819 */       sQLException.fillInStackTrace();
/*  820 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  824 */     this.describedWithNames = true;
/*  825 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  860 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.execute_for_describe");
/*      */     
/*      */     try {
/*  863 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  869 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  873 */         doOall8(true, true, false, true, (this.definedColumnType != null));
/*      */       }
/*      */     
/*  876 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  879 */       throw sQLException;
/*      */     }
/*  881 */     catch (IOException iOException) {
/*      */       
/*  883 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  885 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  886 */       sQLException.fillInStackTrace();
/*  887 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  892 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  893 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     } 
/*      */     
/*  896 */     this.needToParse = false;
/*      */ 
/*      */     
/*  899 */     if (this.connection.calculateChecksum) {
/*  900 */       if (this.validRows > 0) {
/*  901 */         calculateCheckSum();
/*  902 */       } else if (this.rowsProcessed > 0) {
/*  903 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  905 */         this.checkSum = l;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  915 */     if (this.definedColumnType == null) {
/*  916 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  918 */     this.aFetchWasDoneDuringDescribe = false;
/*  919 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  921 */       this.aFetchWasDoneDuringDescribe = true;
/*  922 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  926 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  927 */       this.accessors[b].initMetadata();
/*      */     }
/*  929 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  971 */         boolean bool = false;
/*  972 */         if (this.columnsDefinedByUser) {
/*  973 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  993 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1001 */           boolean bool1 = false;
/* 1002 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1003 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1005 */           for (byte b = 0; b < this.accessors.length; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1010 */             arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/* 1011 */             if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1017 */               bool1 = true;
/* 1018 */               (this.accessors[b]).lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1019 */               arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */             } 
/*      */           } 
/*      */           
/* 1023 */           if (bool1) {
/*      */             
/* 1025 */             this.definedColumnType = arrayOfInt1;
/* 1026 */             this.definedColumnSize = arrayOfInt2;
/* 1027 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1033 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1035 */         this.needToParse = false;
/* 1036 */         if (bool) {
/* 1037 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/* 1041 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     
/* 1044 */     } catch (SQLException sQLException) {
/*      */       
/* 1046 */       throw sQLException;
/*      */     }
/* 1048 */     catch (IOException iOException) {
/*      */       
/* 1050 */       ((T4CConnection)this.connection).handleIOException(iOException);
/* 1051 */       calculateCheckSum();
/*      */       
/* 1053 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1054 */       sQLException.fillInStackTrace();
/* 1055 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1082 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1086 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1090 */           this.nextStream.close();
/*      */         }
/* 1092 */         catch (IOException iOException) {
/*      */           
/* 1094 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1096 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1097 */           sQLException.fillInStackTrace();
/* 1098 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1102 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1108 */       doOall8(false, false, true, false, false);
/*      */       
/* 1110 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/* 1112 */     catch (IOException iOException) {
/*      */       
/* 1114 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1116 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1117 */       sQLException.fillInStackTrace();
/* 1118 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1124 */     calculateCheckSum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1139 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1141 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1143 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1146 */     } catch (IOException iOException) {
/*      */       
/* 1148 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1150 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1151 */       sQLException.fillInStackTrace();
/* 1152 */       throw sQLException;
/*      */     
/*      */     }
/* 1155 */     catch (SQLException sQLException) {
/*      */       
/* 1157 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1160 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1165 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1189 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.do_close");
/*      */ 
/*      */     
/*      */     try {
/* 1193 */       if (this.cursorId != 0)
/*      */       {
/* 1195 */         this.t4Connection.cursorToClose[this.t4Connection.cursorToCloseOffset++] = this.cursorId;
/*      */ 
/*      */         
/* 1198 */         if (this.t4Connection.cursorToCloseOffset >= this.t4Connection.cursorToClose.length)
/*      */         {
/*      */           
/* 1201 */           this.t4Connection.sendPiggyBackedMessages();
/*      */         }
/*      */       }
/*      */     
/* 1205 */     } catch (IOException iOException) {
/*      */       
/* 1207 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1209 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1210 */       sQLException.fillInStackTrace();
/* 1211 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1215 */     this.tmpByteArray = null;
/* 1216 */     this.tmpBindsByteArray = null;
/* 1217 */     this.definedColumnType = null;
/* 1218 */     this.definedColumnSize = null;
/* 1219 */     this.definedColumnFormOfUse = null;
/* 1220 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1240 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.closeQuery");
/*      */ 
/*      */     
/* 1243 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1247 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1251 */           this.nextStream.close();
/*      */         }
/* 1253 */         catch (IOException iOException) {
/*      */           
/* 1255 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1257 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1258 */           sQLException.fillInStackTrace();
/* 1259 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1263 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2) throws SQLException {
/* 1314 */     super(paramPhysicalConnection, 1, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/* 1316 */     this.nbPostPonedColumns = new int[1];
/* 1317 */     this.nbPostPonedColumns[0] = 0;
/* 1318 */     this.indexOfPostPonedColumn = new int[1][3];
/* 1319 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1324 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */