/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import oracle.jdbc.dcn.RowChangeDescription;
/*    */ import oracle.sql.ROWID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NTFDCNRowChanges
/*    */   implements RowChangeDescription
/*    */ {
/*    */   RowChangeDescription.RowOperation opcode;
/*    */   int rowidLength;
/*    */   byte[] rowid;
/*    */   ROWID rowidObj;
/*    */   
/*    */   NTFDCNRowChanges(RowChangeDescription.RowOperation paramRowOperation, int paramInt, byte[] paramArrayOfbyte) {
/* 40 */     this.opcode = paramRowOperation;
/* 41 */     this.rowidLength = paramInt;
/* 42 */     this.rowid = paramArrayOfbyte;
/* 43 */     this.rowidObj = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ROWID getRowid() {
/* 50 */     if (this.rowidObj == null)
/* 51 */       this.rowidObj = new ROWID(this.rowid); 
/* 52 */     return this.rowidObj;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RowChangeDescription.RowOperation getRowOperation() {
/* 58 */     return this.opcode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     StringBuffer stringBuffer = new StringBuffer();
/* 66 */     stringBuffer.append("      ROW:  operation=" + getRowOperation() + ", ROWID=" + new String(this.rowid) + "\n");
/* 67 */     return stringBuffer.toString();
/*    */   }
/*    */ 
/*    */   
/* 71 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NTFDCNRowChanges.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */