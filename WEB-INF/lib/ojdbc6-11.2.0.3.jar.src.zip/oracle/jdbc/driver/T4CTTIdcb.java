/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.OracleResultSetMetaData;
/*      */ import oracle.jdbc.oracore.OracleType;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CTTIdcb
/*      */   extends T4CTTIMsg
/*      */ {
/*      */   static final int DCBRXFR = 1;
/*      */   static final int DCBFIOT = 2;
/*      */   static final int DCBFHAVECOOKIE = 4;
/*      */   static final int DCBFNEWCOOKIE = 8;
/*      */   static final int DCBFREM = 16;
/*      */   int numuds;
/*      */   int colOffset;
/*      */   byte[] ignoreBuff;
/*  112 */   OracleStatement statement = null;
/*      */ 
/*      */ 
/*      */   
/*      */   T4CTTIdcb(T4CConnection paramT4CConnection) {
/*  117 */     super(paramT4CConnection, (byte)16);
/*      */     
/*  119 */     this.ignoreBuff = new byte[40];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void init(OracleStatement paramOracleStatement, int paramInt) {
/*  126 */     this.statement = paramOracleStatement;
/*  127 */     this.colOffset = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor[] receive(Accessor[] paramArrayOfAccessor) throws SQLException, IOException {
/*  137 */     short s = this.meg.unmarshalUB1();
/*      */     
/*  139 */     if (this.ignoreBuff.length < s) {
/*  140 */       this.ignoreBuff = new byte[s];
/*      */     }
/*  142 */     this.meg.unmarshalNBytes(this.ignoreBuff, 0, s);
/*      */     
/*  144 */     int i = (int)this.meg.unmarshalUB4();
/*      */     
/*  146 */     paramArrayOfAccessor = receiveCommon(paramArrayOfAccessor, false);
/*      */     
/*  148 */     return paramArrayOfAccessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor[] receiveFromRefCursor(Accessor[] paramArrayOfAccessor) throws SQLException, IOException {
/*  156 */     short s = this.meg.unmarshalUB1();
/*  157 */     int i = (int)this.meg.unmarshalUB4();
/*      */     
/*  159 */     paramArrayOfAccessor = receiveCommon(paramArrayOfAccessor, false);
/*      */     
/*  161 */     return paramArrayOfAccessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor[] receiveCommon(Accessor[] paramArrayOfAccessor, boolean paramBoolean) throws SQLException, IOException {
/*  170 */     if (paramBoolean) {
/*  171 */       this.numuds = this.meg.unmarshalUB2();
/*      */     } else {
/*      */       
/*  174 */       this.numuds = (int)this.meg.unmarshalUB4();
/*  175 */       if (this.numuds > 0)
/*      */       {
/*      */ 
/*      */         
/*  179 */         short s = this.meg.unmarshalUB1();
/*      */       }
/*      */     } 
/*      */     
/*  183 */     if (this.statement.needToPrepareDefineBuffer)
/*      */     {
/*      */ 
/*      */       
/*  187 */       if (paramArrayOfAccessor == null || paramArrayOfAccessor.length != this.numuds + this.colOffset) {
/*      */         
/*  189 */         Accessor[] arrayOfAccessor = new Accessor[this.numuds + this.colOffset];
/*  190 */         if (paramArrayOfAccessor != null && paramArrayOfAccessor.length == this.colOffset)
/*      */         {
/*  192 */           System.arraycopy(paramArrayOfAccessor, 0, arrayOfAccessor, 0, this.colOffset);
/*      */         }
/*  194 */         paramArrayOfAccessor = arrayOfAccessor;
/*      */       } 
/*      */     }
/*      */     
/*  198 */     T4C8TTIuds t4C8TTIuds = new T4C8TTIuds((T4CConnection)this.statement.connection);
/*      */     
/*  200 */     long l = this.statement.checkSum;
/*  201 */     for (byte b = 0; b < this.numuds; b++) {
/*      */       
/*  203 */       t4C8TTIuds.unmarshal();
/*  204 */       String str = this.meg.conv.CharBytesToString(t4C8TTIuds.getColumName(), t4C8TTIuds.getColumNameByteLength());
/*      */ 
/*      */       
/*  207 */       if (this.statement.needToPrepareDefineBuffer)
/*  208 */         l = fillupAccessors(paramArrayOfAccessor, this.colOffset + b, t4C8TTIuds, str, l); 
/*  209 */       this.statement.checkSum = l;
/*      */     } 
/*      */     
/*  212 */     if (!paramBoolean) {
/*      */ 
/*      */       
/*  215 */       byte[] arrayOfByte = this.meg.unmarshalDALC();
/*      */ 
/*      */       
/*  218 */       if (this.connection.getTTCVersion() >= 3) {
/*      */         
/*  220 */         int i = (int)this.meg.unmarshalUB4();
/*  221 */         int j = (int)this.meg.unmarshalUB4();
/*      */ 
/*      */         
/*  224 */         if (this.connection.getTTCVersion() >= 4) {
/*      */           
/*  226 */           int k = (int)this.meg.unmarshalUB4();
/*  227 */           int m = (int)this.meg.unmarshalUB4();
/*      */           
/*  229 */           if (this.connection.getTTCVersion() >= 5)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  235 */             byte[] arrayOfByte1 = this.meg.unmarshalDALC();
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  260 */     if (this.statement.needToPrepareDefineBuffer)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  266 */       if (!paramBoolean) {
/*      */         
/*  268 */         this.statement.rowPrefetchInLastFetch = -1;
/*  269 */         this.statement.describedWithNames = true;
/*  270 */         this.statement.described = true;
/*  271 */         this.statement.numberOfDefinePositions = this.numuds;
/*  272 */         this.statement.accessors = paramArrayOfAccessor;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  277 */         this.statement.prepareAccessors();
/*      */ 
/*      */         
/*  280 */         this.statement.allocateTmpByteArray();
/*      */       } 
/*      */     }
/*      */     
/*  284 */     return paramArrayOfAccessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long fillupAccessors(Accessor[] paramArrayOfAccessor, int paramInt, T4C8TTIuds paramT4C8TTIuds, String paramString, long paramLong) throws SQLException {
/*      */     int j;
/*      */     short s;
/*  296 */     int[] arrayOfInt1 = this.statement.definedColumnType;
/*  297 */     int[] arrayOfInt2 = this.statement.definedColumnSize;
/*  298 */     int[] arrayOfInt3 = this.statement.definedColumnFormOfUse;
/*  299 */     byte b = this.statement.sqlObject.includeRowid ? 1 : 0;
/*      */ 
/*      */     
/*  302 */     String str1 = null;
/*  303 */     String str2 = null;
/*  304 */     String str3 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  311 */     int k = 0;
/*  312 */     int m = 0;
/*  313 */     int n = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  318 */     if (paramInt >= b) {
/*      */       
/*  320 */       int i1 = paramInt - b;
/*  321 */       if (arrayOfInt1 != null && arrayOfInt1.length > i1 && arrayOfInt1[i1] != 0)
/*      */       {
/*      */         
/*  324 */         k = arrayOfInt1[i1];
/*      */       }
/*  326 */       if (arrayOfInt2 != null && arrayOfInt2.length > i1 && arrayOfInt2[i1] > 0)
/*      */       {
/*      */         
/*  329 */         m = arrayOfInt2[i1];
/*      */       }
/*  331 */       if (arrayOfInt3 != null && arrayOfInt3.length > i1 && arrayOfInt3[i1] > 0)
/*      */       {
/*      */         
/*  334 */         n = arrayOfInt3[i1];
/*      */       }
/*      */     } 
/*  337 */     int i = paramT4C8TTIuds.udsoac.oacmxl;
/*      */     
/*  339 */     switch (paramT4C8TTIuds.udsoac.oacdty) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 96:
/*  353 */         if (paramT4C8TTIuds.udsoac.oacmxlc != 0 && paramT4C8TTIuds.udsoac.oacmxlc < i)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  359 */           i = 2 * paramT4C8TTIuds.udsoac.oacmxlc;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  364 */         j = i;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  369 */         if ((k == 1 || k == 12) && m > 0 && m < i)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  374 */           j = m;
/*      */         }
/*  376 */         paramArrayOfAccessor[paramInt] = new T4CCharAccessor(this.statement, j, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, i, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  391 */         if ((paramT4C8TTIuds.udsoac.oacfl2 & 0x1000) == 4096 || paramT4C8TTIuds.udsoac.oacmxlc != 0)
/*      */         {
/*  393 */           paramArrayOfAccessor[paramInt].setDisplaySize(paramT4C8TTIuds.udsoac.oacmxlc);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  399 */         paramArrayOfAccessor[paramInt] = new T4CNumberAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  418 */         if (paramT4C8TTIuds.udsoac.oacmxlc != 0 && paramT4C8TTIuds.udsoac.oacmxlc < i) {
/*  419 */           i = 2 * paramT4C8TTIuds.udsoac.oacmxlc;
/*      */         }
/*  421 */         j = i;
/*      */         
/*  423 */         if ((k == 1 || k == 12) && m > 0 && m < i)
/*      */         {
/*      */ 
/*      */           
/*  427 */           j = m;
/*      */         }
/*  429 */         paramArrayOfAccessor[paramInt] = new T4CVarcharAccessor(this.statement, j, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, i, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  444 */         if ((paramT4C8TTIuds.udsoac.oacfl2 & 0x1000) == 4096 || paramT4C8TTIuds.udsoac.oacmxlc != 0)
/*      */         {
/*  446 */           paramArrayOfAccessor[paramInt].setDisplaySize(paramT4C8TTIuds.udsoac.oacmxlc);
/*      */         }
/*      */         break;
/*      */       
/*      */       case 8:
/*  451 */         if ((k == 1 || k == 12) && this.connection.versionNumber >= 9000 && m < 4001) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  465 */           if (m > 0) {
/*  466 */             j = m;
/*      */           }
/*      */           else {
/*      */             
/*  470 */             j = 4000;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  476 */           i = -1;
/*  477 */           paramArrayOfAccessor[paramInt] = new T4CVarcharAccessor(this.statement, j, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, i, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  491 */           (paramArrayOfAccessor[paramInt]).describeType = 8;
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */ 
/*      */         
/*  498 */         i = 0;
/*      */         
/*  500 */         paramArrayOfAccessor[paramInt] = new T4CLongAccessor(this.statement, paramInt + 1, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  519 */         paramArrayOfAccessor[paramInt] = new T4CVarnumAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  536 */         paramArrayOfAccessor[paramInt] = new T4CBinaryFloatAccessor(this.statement, 4, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  558 */         paramArrayOfAccessor[paramInt] = new T4CBinaryDoubleAccessor(this.statement, 8, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  576 */         paramArrayOfAccessor[paramInt] = new T4CRawAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  594 */         if (k == -2 && m < 2001 && this.connection.versionNumber >= 9000) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  601 */           i = -1;
/*  602 */           paramArrayOfAccessor[paramInt] = new T4CRawAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  615 */           (paramArrayOfAccessor[paramInt]).describeType = 24;
/*      */           break;
/*      */         } 
/*  618 */         paramArrayOfAccessor[paramInt] = new T4CLongRawAccessor(this.statement, paramInt + 1, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 11:
/*      */       case 104:
/*      */       case 208:
/*  638 */         paramArrayOfAccessor[paramInt] = new T4CRowidAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  652 */         if (paramT4C8TTIuds.udsoac.oacdty == 208) {
/*  653 */           (paramArrayOfAccessor[paramInt]).describeType = 208;
/*      */         }
/*      */         break;
/*      */       
/*      */       case 102:
/*  658 */         paramArrayOfAccessor[paramInt] = new T4CResultSetAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  675 */         paramArrayOfAccessor[paramInt] = new T4CDateAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  692 */         if (k == -4 && this.connection.versionNumber >= 9000) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  697 */           paramArrayOfAccessor[paramInt] = new T4CLongRawAccessor(this.statement, paramInt + 1, 2147483647, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  712 */           (paramArrayOfAccessor[paramInt]).describeType = 113; break;
/*      */         } 
/*  714 */         if (k == -3 && this.connection.versionNumber >= 9000) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  719 */           paramArrayOfAccessor[paramInt] = new T4CRawAccessor(this.statement, 4000, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  732 */           (paramArrayOfAccessor[paramInt]).describeType = 113;
/*      */           
/*      */           break;
/*      */         } 
/*  736 */         paramArrayOfAccessor[paramInt] = new T4CBlobAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  750 */         if (this.connection.useLobPrefetch && k == 2004) {
/*      */           
/*  752 */           (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = m;
/*      */           
/*      */           break;
/*      */         } 
/*  756 */         (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = -1;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 112:
/*  761 */         s = 1;
/*  762 */         if (n != 0) {
/*  763 */           s = (short)n;
/*      */         }
/*  765 */         if ((k == -1 || k == -16) && this.connection.versionNumber >= 9000) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  774 */           i = 0;
/*  775 */           paramArrayOfAccessor[paramInt] = new T4CLongAccessor(this.statement, paramInt + 1, 2147483647, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, s, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  791 */           (paramArrayOfAccessor[paramInt]).describeType = 112; break;
/*      */         } 
/*  793 */         if ((k == 12 || k == 1 || k == -15 || k == -9) && this.connection.versionNumber >= 9000) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  804 */           j = 4000;
/*  805 */           if (m > 0 && m < j)
/*      */           {
/*  807 */             j = m;
/*      */           }
/*  809 */           paramArrayOfAccessor[paramInt] = new T4CVarcharAccessor(this.statement, j, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, s, 4000, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  824 */           (paramArrayOfAccessor[paramInt]).describeType = 112;
/*      */           break;
/*      */         } 
/*  827 */         paramArrayOfAccessor[paramInt] = new T4CClobAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  840 */         if (this.connection.useLobPrefetch && (k == 2005 || k == 2011)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  849 */           (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = m; break;
/*      */         } 
/*  851 */         (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = -1;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 114:
/*  856 */         paramArrayOfAccessor[paramInt] = new T4CBfileAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  869 */         if (this.connection.useLobPrefetch && k == -13) {
/*      */ 
/*      */           
/*  872 */           (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = m; break;
/*      */         } 
/*  874 */         (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = -1;
/*      */         break;
/*      */       
/*      */       case 109:
/*  878 */         str1 = this.meg.conv.CharBytesToString(paramT4C8TTIuds.getTypeName(), paramT4C8TTIuds.getTypeCharLength());
/*      */ 
/*      */ 
/*      */         
/*  882 */         str2 = this.meg.conv.CharBytesToString(paramT4C8TTIuds.getSchemaName(), paramT4C8TTIuds.getSchemaCharLength());
/*      */ 
/*      */         
/*  885 */         str3 = str2 + "." + str1;
/*      */         
/*  887 */         paramArrayOfAccessor[paramInt] = new T4CNamedTypeAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, str3, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 111:
/*  905 */         str1 = this.meg.conv.CharBytesToString(paramT4C8TTIuds.getTypeName(), paramT4C8TTIuds.getTypeCharLength());
/*      */ 
/*      */ 
/*      */         
/*  909 */         str2 = this.meg.conv.CharBytesToString(paramT4C8TTIuds.getSchemaName(), paramT4C8TTIuds.getSchemaCharLength());
/*      */ 
/*      */         
/*  912 */         str3 = str2 + "." + str1;
/*      */         
/*  914 */         paramArrayOfAccessor[paramInt] = new T4CRefTypeAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, str3, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  932 */         paramArrayOfAccessor[paramInt] = new T4CTimestampAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  949 */         paramArrayOfAccessor[paramInt] = new T4CTimestamptzAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  966 */         paramArrayOfAccessor[paramInt] = new T4CTimestampltzAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  983 */         paramArrayOfAccessor[paramInt] = new T4CIntervalymAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/* 1000 */         paramArrayOfAccessor[paramInt] = new T4CIntervaldsAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1019 */         paramArrayOfAccessor[paramInt] = null;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1025 */     if (paramT4C8TTIuds.udsoac.oactoid.length > 0) {
/*      */       
/* 1027 */       (paramArrayOfAccessor[paramInt]).internalOtype = (OracleType)new OracleTypeADT(paramT4C8TTIuds.udsoac.oactoid, paramT4C8TTIuds.udsoac.oacvsn, paramT4C8TTIuds.udsoac.oaccsi, paramT4C8TTIuds.udsoac.oaccsfrm, str2 + "." + str1);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1032 */       (paramArrayOfAccessor[paramInt]).internalOtype = null;
/*      */     } 
/*      */     
/* 1035 */     (paramArrayOfAccessor[paramInt]).columnName = paramString;
/*      */ 
/*      */     
/* 1038 */     (paramArrayOfAccessor[paramInt]).securityAttribute = OracleResultSetMetaData.SecurityAttribute.NONE;
/*      */     
/* 1040 */     if ((paramT4C8TTIuds.udsflg & 0x1) != 0) {
/* 1041 */       (paramArrayOfAccessor[paramInt]).securityAttribute = OracleResultSetMetaData.SecurityAttribute.ENABLED;
/*      */     }
/* 1043 */     else if ((paramT4C8TTIuds.udsflg & 0x2) != 0) {
/* 1044 */       (paramArrayOfAccessor[paramInt]).securityAttribute = OracleResultSetMetaData.SecurityAttribute.UNKNOWN;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1049 */     if (paramT4C8TTIuds.udsoac.oacmxl == 0) {
/* 1050 */       (paramArrayOfAccessor[paramInt]).isNullByDescribe = true;
/*      */     }
/* 1052 */     (paramArrayOfAccessor[paramInt]).udskpos = paramT4C8TTIuds.getKernelPosition();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1069 */     if (this.connection.calculateChecksum) {
/*      */       
/* 1071 */       paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oacdty);
/*      */       
/* 1073 */       paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oacmxl);
/*      */       
/* 1075 */       paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oacpre);
/*      */       
/* 1077 */       paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oacscl);
/*      */       
/* 1079 */       paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oaccsfrm);
/*      */       
/* 1081 */       if (str1 != null)
/*      */       {
/* 1083 */         paramLong = CRC64.updateChecksum(paramLong, str2 + "." + str1);
/*      */       }
/*      */ 
/*      */       
/* 1087 */       paramLong = CRC64.updateChecksum(paramLong, paramString);
/*      */     } 
/*      */     
/* 1090 */     return paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1097 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CTTIdcb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */