/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.aq.AQMessageProperties;
/*     */ import oracle.jdbc.aq.AQNotificationEvent;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFAQEvent
/*     */   extends AQNotificationEvent
/*     */ {
/*     */   private String registrationString;
/*     */   private int namespace;
/*     */   private byte[] payload;
/*  49 */   private String queueName = null;
/*  50 */   private byte[] messageId = null;
/*  51 */   private String consumerName = null;
/*     */   private NTFConnection conn;
/*     */   private AQMessagePropertiesI msgProp;
/*  54 */   private AQNotificationEvent.EventType eventType = AQNotificationEvent.EventType.REGULAR;
/*  55 */   private AQNotificationEvent.AdditionalEventType additionalEventType = AQNotificationEvent.AdditionalEventType.NONE;
/*     */   
/*     */   private ByteBuffer dataBuffer;
/*     */   
/*     */   private boolean isReady = false;
/*     */   private short databaseVersion;
/*     */   
/*     */   NTFAQEvent(NTFConnection paramNTFConnection, short paramShort) throws IOException {
/*  63 */     super(paramNTFConnection);
/*     */     
/*  65 */     this.conn = paramNTFConnection;
/*  66 */     int i = this.conn.readInt();
/*  67 */     byte[] arrayOfByte = new byte[i];
/*  68 */     this.conn.readBuffer(arrayOfByte, 0, i);
/*  69 */     this.dataBuffer = ByteBuffer.wrap(arrayOfByte);
/*  70 */     this.databaseVersion = paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initEvent() throws SQLException {
/*  77 */     byte b1 = this.dataBuffer.get();
/*  78 */     int i = this.dataBuffer.getInt();
/*  79 */     byte[] arrayOfByte1 = new byte[i];
/*  80 */     this.dataBuffer.get(arrayOfByte1, 0, i);
/*  81 */     this.registrationString = this.conn.charset.toString(arrayOfByte1, 0, i);
/*     */ 
/*     */ 
/*     */     
/*  85 */     byte b2 = this.dataBuffer.get();
/*  86 */     int j = this.dataBuffer.getInt();
/*  87 */     byte[] arrayOfByte2 = new byte[j];
/*  88 */     this.dataBuffer.get(arrayOfByte2, 0, j);
/*  89 */     this.namespace = arrayOfByte2[0];
/*     */ 
/*     */     
/*  92 */     byte b3 = this.dataBuffer.get();
/*  93 */     int k = this.dataBuffer.getInt();
/*  94 */     if (k > 0) {
/*     */       
/*  96 */       this.payload = new byte[k];
/*  97 */       this.dataBuffer.get(this.payload, 0, k);
/*     */     } else {
/*     */       
/* 100 */       this.payload = null;
/*     */     } 
/* 102 */     if (this.dataBuffer.hasRemaining()) {
/*     */       
/* 104 */       int m = 0;
/* 105 */       if (this.databaseVersion >= 10200) {
/*     */ 
/*     */         
/* 108 */         byte b = this.dataBuffer.get();
/* 109 */         int i23 = this.dataBuffer.getInt();
/* 110 */         m = this.dataBuffer.getInt();
/*     */       } 
/*     */ 
/*     */       
/* 114 */       byte b4 = this.dataBuffer.get();
/* 115 */       int n = this.dataBuffer.getInt();
/* 116 */       byte[] arrayOfByte3 = new byte[n];
/* 117 */       this.dataBuffer.get(arrayOfByte3, 0, n);
/* 118 */       this.queueName = this.conn.charset.toString(arrayOfByte3, 0, n);
/*     */ 
/*     */ 
/*     */       
/* 122 */       byte b5 = this.dataBuffer.get();
/* 123 */       int i1 = this.dataBuffer.getInt();
/* 124 */       this.messageId = new byte[i1];
/* 125 */       this.dataBuffer.get(this.messageId, 0, i1);
/*     */ 
/*     */       
/* 128 */       byte b6 = this.dataBuffer.get();
/* 129 */       int i2 = this.dataBuffer.getInt();
/* 130 */       byte[] arrayOfByte4 = new byte[i2];
/* 131 */       this.dataBuffer.get(arrayOfByte4, 0, i2);
/* 132 */       this.consumerName = this.conn.charset.toString(arrayOfByte4, 0, i2);
/*     */ 
/*     */ 
/*     */       
/* 136 */       byte b7 = this.dataBuffer.get();
/* 137 */       int i3 = this.dataBuffer.getInt();
/* 138 */       byte[] arrayOfByte5 = new byte[i3];
/* 139 */       this.dataBuffer.get(arrayOfByte5, 0, i3);
/*     */ 
/*     */       
/* 142 */       byte b8 = this.dataBuffer.get();
/* 143 */       int i4 = this.dataBuffer.getInt();
/* 144 */       int i5 = this.dataBuffer.getInt();
/* 145 */       if (arrayOfByte5[0] == 1)
/* 146 */         i5 = -i5; 
/* 147 */       int i6 = i5;
/*     */ 
/*     */       
/* 150 */       byte b9 = this.dataBuffer.get();
/* 151 */       int i7 = this.dataBuffer.getInt();
/* 152 */       int i8 = this.dataBuffer.getInt();
/*     */ 
/*     */       
/* 155 */       byte b10 = this.dataBuffer.get();
/* 156 */       int i9 = this.dataBuffer.getInt();
/* 157 */       byte[] arrayOfByte6 = new byte[i9];
/* 158 */       this.dataBuffer.get(arrayOfByte6, 0, i9);
/*     */ 
/*     */       
/* 161 */       byte b11 = this.dataBuffer.get();
/* 162 */       int i10 = this.dataBuffer.getInt();
/* 163 */       int i11 = this.dataBuffer.getInt();
/* 164 */       if (arrayOfByte6[0] == 1)
/* 165 */         i11 = -i11; 
/* 166 */       int i12 = i11;
/*     */ 
/*     */       
/* 169 */       byte b12 = this.dataBuffer.get();
/* 170 */       int i13 = this.dataBuffer.getInt();
/* 171 */       int i14 = this.dataBuffer.getInt();
/*     */ 
/*     */       
/* 174 */       byte b13 = this.dataBuffer.get();
/* 175 */       int i15 = this.dataBuffer.getInt();
/* 176 */       byte[] arrayOfByte7 = new byte[i15];
/* 177 */       this.dataBuffer.get(arrayOfByte7, 0, i15);
/* 178 */       TIMESTAMP tIMESTAMP = new TIMESTAMP(arrayOfByte7);
/*     */ 
/*     */       
/* 181 */       byte b14 = this.dataBuffer.get();
/* 182 */       int i16 = this.dataBuffer.getInt();
/* 183 */       byte[] arrayOfByte8 = new byte[i16];
/* 184 */       this.dataBuffer.get(arrayOfByte8, 0, i16);
/* 185 */       byte b15 = arrayOfByte8[0];
/*     */ 
/*     */       
/* 188 */       byte b16 = this.dataBuffer.get();
/* 189 */       int i17 = this.dataBuffer.getInt();
/* 190 */       byte[] arrayOfByte9 = new byte[i17];
/* 191 */       this.dataBuffer.get(arrayOfByte9, 0, i17);
/* 192 */       String str1 = this.conn.charset.toString(arrayOfByte9, 0, i17);
/*     */ 
/*     */ 
/*     */       
/* 196 */       byte b17 = this.dataBuffer.get();
/* 197 */       int i18 = this.dataBuffer.getInt();
/* 198 */       byte[] arrayOfByte10 = new byte[i18];
/* 199 */       this.dataBuffer.get(arrayOfByte10, 0, i18);
/* 200 */       String str2 = this.conn.charset.toString(arrayOfByte10, 0, i18);
/*     */ 
/*     */ 
/*     */       
/* 204 */       byte b18 = this.dataBuffer.get();
/* 205 */       int i19 = this.dataBuffer.getInt();
/* 206 */       byte[] arrayOfByte11 = null;
/* 207 */       if (i19 > 0) {
/*     */         
/* 209 */         arrayOfByte11 = new byte[i19];
/* 210 */         this.dataBuffer.get(arrayOfByte11, 0, i19);
/*     */       } 
/*     */ 
/*     */       
/* 214 */       byte b19 = this.dataBuffer.get();
/* 215 */       int i20 = this.dataBuffer.getInt();
/* 216 */       byte[] arrayOfByte12 = new byte[i20];
/* 217 */       this.dataBuffer.get(arrayOfByte12, 0, i20);
/* 218 */       String str3 = this.conn.charset.toString(arrayOfByte12, 0, i20);
/*     */ 
/*     */ 
/*     */       
/* 222 */       byte b20 = this.dataBuffer.get();
/* 223 */       int i21 = this.dataBuffer.getInt();
/* 224 */       byte[] arrayOfByte13 = new byte[i21];
/* 225 */       this.dataBuffer.get(arrayOfByte13, 0, i21);
/* 226 */       String str4 = this.conn.charset.toString(arrayOfByte13, 0, i21);
/*     */ 
/*     */ 
/*     */       
/* 230 */       byte b21 = this.dataBuffer.get();
/* 231 */       int i22 = this.dataBuffer.getInt();
/* 232 */       byte b22 = this.dataBuffer.get();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       this.msgProp = new AQMessagePropertiesI();
/* 238 */       this.msgProp.setAttempts(i14);
/* 239 */       this.msgProp.setCorrelation(str2);
/* 240 */       this.msgProp.setDelay(i8);
/* 241 */       this.msgProp.setEnqueueTime(tIMESTAMP.timestampValue());
/* 242 */       this.msgProp.setMessageState(AQMessageProperties.MessageState.getMessageState(b15));
/* 243 */       if (this.databaseVersion >= 10200)
/* 244 */         this.msgProp.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(m)); 
/* 245 */       this.msgProp.setPreviousQueueMessageId(arrayOfByte11);
/* 246 */       AQAgentI aQAgentI = new AQAgentI();
/* 247 */       aQAgentI.setAddress(str4);
/* 248 */       aQAgentI.setName(str3);
/* 249 */       aQAgentI.setProtocol(b22);
/* 250 */       this.msgProp.setSender(aQAgentI);
/*     */       
/* 252 */       this.msgProp.setPriority(i6);
/* 253 */       this.msgProp.setExpiration(i12);
/* 254 */       this.msgProp.setExceptionQueue(str1);
/*     */     } 
/* 256 */     this.isReady = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQMessageProperties getMessageProperties() throws SQLException {
/* 263 */     if (!this.isReady)
/* 264 */       initEvent(); 
/* 265 */     return this.msgProp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegistration() throws SQLException {
/* 272 */     if (!this.isReady)
/* 273 */       initEvent(); 
/* 274 */     return this.registrationString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQNotificationEvent.EventType getEventType() {
/* 281 */     return this.eventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AQNotificationEvent.AdditionalEventType getAdditionalEventType() {
/* 288 */     return this.additionalEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEventType(AQNotificationEvent.EventType paramEventType) throws IOException {
/* 295 */     this.eventType = paramEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAdditionalEventType(AQNotificationEvent.AdditionalEventType paramAdditionalEventType) {
/* 302 */     this.additionalEventType = paramAdditionalEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPayload() throws SQLException {
/* 309 */     if (!this.isReady)
/* 310 */       initEvent(); 
/* 311 */     return this.payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueueName() throws SQLException {
/* 318 */     if (!this.isReady)
/* 319 */       initEvent(); 
/* 320 */     return this.queueName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getMessageId() throws SQLException {
/* 327 */     if (!this.isReady)
/* 328 */       initEvent(); 
/* 329 */     return this.messageId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConsumerName() throws SQLException {
/* 336 */     if (!this.isReady)
/* 337 */       initEvent(); 
/* 338 */     return this.consumerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConnectionInformation() {
/* 345 */     return this.conn.connectionDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 353 */     if (!this.isReady) {
/*     */       
/*     */       try {
/*     */         
/* 357 */         initEvent();
/*     */       }
/* 359 */       catch (SQLException sQLException) {
/*     */         
/* 361 */         return sQLException.getMessage();
/*     */       } 
/*     */     }
/* 364 */     StringBuffer stringBuffer = new StringBuffer();
/* 365 */     stringBuffer.append("Connection information  : " + this.conn.connectionDescription + "\n");
/* 366 */     stringBuffer.append("Event type              : " + this.eventType + "\n");
/* 367 */     if (this.additionalEventType != AQNotificationEvent.AdditionalEventType.NONE)
/* 368 */       stringBuffer.append("Additional event type   : " + this.additionalEventType + "\n"); 
/* 369 */     stringBuffer.append("Namespace               : " + this.namespace + "\n");
/* 370 */     stringBuffer.append("Registration            : " + this.registrationString + "\n");
/* 371 */     stringBuffer.append("Queue name              : " + this.queueName + "\n");
/* 372 */     stringBuffer.append("Consumer name           : " + this.consumerName + "\n");
/* 373 */     if (this.payload != null) {
/*     */       
/* 375 */       stringBuffer.append("Payload length          : " + this.payload.length + "\n");
/* 376 */       stringBuffer.append("Payload (first 50 bytes): " + byteBufferToHexString(this.payload, 50) + "\n");
/*     */     } else {
/*     */       
/* 379 */       stringBuffer.append("Payload                 : null\n");
/* 380 */     }  stringBuffer.append("Message ID              : " + byteBufferToHexString(this.messageId, 50) + "\n");
/* 381 */     if (this.msgProp != null)
/* 382 */       stringBuffer.append(this.msgProp.toString()); 
/* 383 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final String byteBufferToHexString(byte[] paramArrayOfbyte, int paramInt) {
/* 389 */     if (paramArrayOfbyte == null) {
/* 390 */       return null;
/*     */     }
/* 392 */     byte b = 0;
/* 393 */     boolean bool = true;
/* 394 */     StringBuffer stringBuffer = new StringBuffer();
/* 395 */     while (b < paramArrayOfbyte.length && b < paramInt) {
/*     */       
/* 397 */       if (!bool) {
/* 398 */         stringBuffer.append(' ');
/*     */       } else {
/* 400 */         bool = false;
/* 401 */       }  String str = Integer.toHexString(paramArrayOfbyte[b] & 0xFF);
/* 402 */       if (str.length() == 1)
/* 403 */         str = "0" + str; 
/* 404 */       stringBuffer.append(str);
/* 405 */       b++;
/*     */     } 
/* 407 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 413 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NTFAQEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */