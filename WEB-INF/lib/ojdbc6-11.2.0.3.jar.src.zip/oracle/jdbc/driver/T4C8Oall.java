/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.internal.KeywordValue;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class T4C8Oall
/*      */   extends T4CTTIfun
/*      */ {
/*  124 */   Vector<IOException> nonFatalIOExceptions = null;
/*      */   
/*  126 */   static final byte[] EMPTY_BYTES = new byte[0];
/*      */ 
/*      */   
/*      */   static final int UOPF_PRS = 1;
/*      */ 
/*      */   
/*      */   static final int UOPF_BND = 8;
/*      */   
/*      */   static final int UOPF_EXE = 32;
/*      */   
/*      */   static final int UOPF_FEX = 512;
/*      */   
/*      */   static final int UOPF_FCH = 64;
/*      */   
/*      */   static final int UOPF_CAN = 128;
/*      */   
/*      */   static final int UOPF_COM = 256;
/*      */   
/*      */   static final int UOPF_DSY = 8192;
/*      */   
/*      */   static final int UOPF_SIO = 1024;
/*      */   
/*      */   static final int UOPF_NPL = 32768;
/*      */   
/*      */   static final int UOPF_DFN = 16;
/*      */   
/*      */   static final int EXE_COMMIT_ON_SUCCESS = 1;
/*      */   
/*      */   static final int EXE_LEAVE_CUR_MAPPED = 2;
/*      */   
/*      */   static final int EXE_BATCH_DML_ERRORS = 4;
/*      */   
/*      */   static final int EXE_SCROL_READ_ONLY = 8;
/*      */   
/*      */   static final int AL8KW_MAXLANG = 63;
/*      */   
/*      */   static final int AL8KW_TIMEZONE = 163;
/*      */   
/*      */   static final int AL8KW_ERR_OVLAP = 164;
/*      */   
/*      */   static final int AL8KW_SESSION_ID = 165;
/*      */   
/*      */   static final int AL8KW_SERIAL_NUM = 166;
/*      */   
/*      */   static final int AL8KW_TAG_FOUND = 167;
/*      */   
/*      */   static final int AL8KW_SCHEMA_NAME = 168;
/*      */   
/*      */   static final int AL8KW_SCHEMA_ID = 169;
/*      */   
/*      */   static final int AL8KW_ENABLED_ROLES = 170;
/*      */   
/*      */   static final int AL8KW_AUX_SESSSTATE = 171;
/*      */   
/*  180 */   static final String[] NLS_KEYS = new String[] { "AUTH_NLS_LXCCURRENCY", "AUTH_NLS_LXCISOCURR", "AUTH_NLS_LXCNUMERICS", null, null, null, null, "AUTH_NLS_LXCDATEFM", "AUTH_NLS_LXCDATELANG", "AUTH_NLS_LXCTERRITORY", "SESSION_NLS_LXCCHARSET", "AUTH_NLS_LXCSORT", "AUTH_NLS_LXCCALENDAR", null, null, null, "AUTH_NLS_LXLAN", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "AUTH_NLS_LXCSORT", null, "AUTH_NLS_LXCUNIONCUR", null, null, null, null, "AUTH_NLS_LXCTIMEFM", "AUTH_NLS_LXCSTMPFM", "AUTH_NLS_LXCTTZNFM", "AUTH_NLS_LXCSTZNFM", "SESSION_NLS_LXCNLSLENSEM", "SESSION_NLS_LXCNCHAREXCP", "SESSION_NLS_LXCNCHARIMP" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int LDIREGIDFLAG = 120;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int LDIREGIDSET = 181;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int LDIMAXTIMEFIELD = 60;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int rowsProcessed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int numberOfDefinePositions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long options;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int cursor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  267 */   byte[] sqlStmt = new byte[0];
/*  268 */   final long[] al8i4 = new long[13];
/*      */ 
/*      */   
/*      */   boolean plsql = false;
/*      */ 
/*      */   
/*      */   Accessor[] definesAccessors;
/*      */ 
/*      */   
/*      */   int definesLength;
/*      */ 
/*      */   
/*      */   Accessor[] outBindAccessors;
/*      */ 
/*      */   
/*      */   int numberOfBindPositions;
/*      */   
/*      */   InputStream[][] parameterStream;
/*      */   
/*      */   byte[][][] parameterDatum;
/*      */   
/*      */   OracleTypeADT[][] parameterOtype;
/*      */   
/*      */   short[] bindIndicators;
/*      */   
/*      */   byte[] bindBytes;
/*      */   
/*      */   char[] bindChars;
/*      */   
/*      */   int bindIndicatorSubRange;
/*      */   
/*      */   byte[] tmpBindsByteArray;
/*      */   
/*      */   DBConversion conversion;
/*      */   
/*      */   byte[] ibtBindBytes;
/*      */   
/*      */   char[] ibtBindChars;
/*      */   
/*      */   short[] ibtBindIndicators;
/*      */   
/*      */   boolean sendBindsDefinition = false;
/*      */   
/*      */   OracleStatement oracleStatement;
/*      */   
/*      */   short dbCharSet;
/*      */   
/*      */   short NCharSet;
/*      */   
/*      */   T4CTTIrxd rxd;
/*      */   
/*      */   T4C8TTIrxh rxh;
/*      */   
/*      */   T4CTTIdcb dcb;
/*      */   
/*      */   OracleStatement.SqlKind typeOfStatement;
/*      */   
/*  325 */   int defCols = 0;
/*      */ 
/*      */   
/*      */   int rowsToFetch;
/*      */   
/*      */   boolean aFetchWasDone = false;
/*      */   
/*      */   T4CTTIoac[] oacdefBindsSent;
/*      */   
/*      */   T4CTTIoac[] oacdefDefines;
/*      */   
/*      */   int[] definedColumnSize;
/*      */   
/*      */   int[] definedColumnType;
/*      */   
/*      */   int[] definedColumnFormOfUse;
/*      */   
/*  342 */   NTFDCNRegistration registration = null;
/*      */   
/*      */   static final int AL8TXCUR = 1;
/*      */   
/*      */   static final int AL8TXDON = 2;
/*      */   
/*      */   static final int AL8TXRON = 4;
/*      */   
/*      */   T4C8Oall(T4CConnection paramT4CConnection) {
/*  351 */     super(paramT4CConnection, (byte)3);
/*      */     
/*  353 */     setFunCode((short)94);
/*  354 */     this.rxh = new T4C8TTIrxh(paramT4CConnection);
/*  355 */     this.rxd = new T4CTTIrxd(paramT4CConnection);
/*  356 */     this.dcb = new T4CTTIdcb(paramT4CConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOALL(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, OracleStatement.SqlKind paramSqlKind, int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, Accessor[] paramArrayOfAccessor1, int paramInt3, Accessor[] paramArrayOfAccessor2, int paramInt4, byte[] paramArrayOfbyte2, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt5, DBConversion paramDBConversion, byte[] paramArrayOfbyte3, InputStream[][] paramArrayOfInputStream, byte[][][] paramArrayOfbyte, OracleTypeADT[][] paramArrayOfOracleTypeADT, OracleStatement paramOracleStatement, byte[] paramArrayOfbyte4, char[] paramArrayOfchar2, short[] paramArrayOfshort2, T4CTTIoac[] paramArrayOfT4CTTIoac, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, NTFDCNRegistration paramNTFDCNRegistration) throws SQLException, IOException {
/*  381 */     this.typeOfStatement = paramSqlKind;
/*  382 */     this.cursor = paramInt1;
/*  383 */     this.sqlStmt = paramBoolean1 ? paramArrayOfbyte1 : EMPTY_BYTES;
/*  384 */     this.rowsToFetch = paramInt2;
/*  385 */     this.outBindAccessors = paramArrayOfAccessor1;
/*  386 */     this.numberOfBindPositions = paramInt3;
/*  387 */     this.definesAccessors = paramArrayOfAccessor2;
/*  388 */     this.definesLength = paramInt4;
/*  389 */     this.bindBytes = paramArrayOfbyte2;
/*  390 */     this.bindChars = paramArrayOfchar1;
/*  391 */     this.bindIndicators = paramArrayOfshort1;
/*  392 */     this.bindIndicatorSubRange = paramInt5;
/*  393 */     this.conversion = paramDBConversion;
/*  394 */     this.tmpBindsByteArray = paramArrayOfbyte3;
/*  395 */     this.parameterStream = paramArrayOfInputStream;
/*  396 */     this.parameterDatum = paramArrayOfbyte;
/*  397 */     this.parameterOtype = paramArrayOfOracleTypeADT;
/*  398 */     this.oracleStatement = paramOracleStatement;
/*  399 */     this.ibtBindBytes = paramArrayOfbyte4;
/*  400 */     this.ibtBindChars = paramArrayOfchar2;
/*  401 */     this.ibtBindIndicators = paramArrayOfshort2;
/*  402 */     this.oacdefBindsSent = paramArrayOfT4CTTIoac;
/*  403 */     this.definedColumnType = paramArrayOfint1;
/*  404 */     this.definedColumnSize = paramArrayOfint2;
/*  405 */     this.definedColumnFormOfUse = paramArrayOfint3;
/*  406 */     this.registration = paramNTFDCNRegistration;
/*      */ 
/*      */     
/*  409 */     this.dbCharSet = paramDBConversion.getServerCharSetId();
/*  410 */     this.NCharSet = paramDBConversion.getNCharSetId();
/*      */ 
/*      */     
/*  413 */     int i = 0;
/*  414 */     if (this.bindIndicators != null) {
/*  415 */       i = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */     }
/*      */ 
/*      */     
/*  419 */     if (paramArrayOfbyte1 == null) {
/*      */ 
/*      */       
/*  422 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 431);
/*  423 */       sQLException.fillInStackTrace();
/*  424 */       throw sQLException;
/*      */     } 
/*      */     
/*  427 */     if (!this.typeOfStatement.isDML() && i > 1) {
/*      */ 
/*      */ 
/*      */       
/*  431 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
/*  432 */       sQLException.fillInStackTrace();
/*  433 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  438 */     this.rowsProcessed = 0;
/*  439 */     this.options = 0L;
/*  440 */     this.plsql = this.typeOfStatement.isPlsqlOrCall();
/*  441 */     this.sendBindsDefinition = false;
/*      */ 
/*      */     
/*  444 */     if (this.receiveState != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  449 */       this.receiveState = 0;
/*      */     }
/*      */     
/*  452 */     this.rxh.init();
/*  453 */     this.rxd.init();
/*  454 */     this.oer.init();
/*      */ 
/*      */     
/*  457 */     if (paramBoolean5) {
/*  458 */       initDefinesDefinition();
/*      */     }
/*  460 */     if (this.numberOfBindPositions > 0 && this.bindIndicators != null) {
/*      */       
/*  462 */       if (this.oacdefBindsSent == null)
/*  463 */         this.oacdefBindsSent = new T4CTTIoac[this.numberOfBindPositions]; 
/*  464 */       this.sendBindsDefinition = initBindsDefinition(this.oacdefBindsSent);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  474 */     this.options = setOptions(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean5);
/*      */     
/*  476 */     if ((this.options & 0x1L) > 0L) {
/*  477 */       this.al8i4[0] = 1L;
/*      */     } else {
/*  479 */       this.al8i4[0] = 0L;
/*      */     } 
/*      */     
/*  482 */     if (this.plsql || this.typeOfStatement.isOTHER()) {
/*  483 */       this.al8i4[1] = 1L;
/*  484 */     } else if (paramBoolean4) {
/*      */       
/*  486 */       if (paramBoolean3 && this.oracleStatement.connection.useFetchSizeWithLongColumn) {
/*  487 */         this.al8i4[1] = this.rowsToFetch;
/*      */       } else {
/*  489 */         this.al8i4[1] = 0L;
/*      */       } 
/*  491 */     } else if (this.typeOfStatement.isDML()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  497 */       this.al8i4[1] = (i == 0) ? this.oracleStatement.batch : i;
/*      */     }
/*  499 */     else if (paramBoolean3 && !paramBoolean4) {
/*      */       
/*  501 */       this.al8i4[1] = this.rowsToFetch;
/*      */     } else {
/*  503 */       this.al8i4[1] = 0L;
/*      */     } 
/*      */     
/*  506 */     if (this.typeOfStatement.isSELECT()) {
/*  507 */       this.al8i4[7] = 1L;
/*      */     } else {
/*  509 */       this.al8i4[7] = 0L;
/*      */     } 
/*  511 */     long l = this.oracleStatement.inScn;
/*  512 */     int j = (int)l;
/*  513 */     int k = (int)(l >> 32L);
/*  514 */     this.al8i4[5] = j;
/*  515 */     this.al8i4[6] = k;
/*      */     
/*  517 */     this.rowsProcessed = 0;
/*  518 */     this.aFetchWasDone = false;
/*      */ 
/*      */     
/*  521 */     this.rxd.setNumberOfColumns(this.definesLength);
/*      */     
/*  523 */     if ((this.options & 0x40L) != 0L && (this.options & 0x20L) == 0L && (this.options & 0x1L) == 0L && (this.options & 0x8L) == 0L && (this.options & 0x10L) == 0L && !this.oracleStatement.needToSendOalToFetch) {
/*      */ 
/*      */       
/*  526 */       setFunCode((short)5);
/*      */     } else {
/*  528 */       setFunCode((short)94);
/*      */     } 
/*  530 */     this.nonFatalIOExceptions = null;
/*  531 */     doRPC();
/*      */ 
/*      */ 
/*      */     
/*  535 */     if ((this.options & 0x20L) != 0L) {
/*  536 */       this.oracleStatement.inScn = 0L;
/*      */     }
/*      */     
/*  539 */     this.ibtBindIndicators = null;
/*  540 */     this.ibtBindChars = null;
/*  541 */     this.ibtBindBytes = null;
/*  542 */     this.tmpBindsByteArray = null;
/*  543 */     this.outBindAccessors = null;
/*  544 */     this.bindBytes = null;
/*  545 */     this.bindChars = null;
/*  546 */     this.bindIndicators = null;
/*  547 */     this.oracleStatement = null;
/*      */     
/*  549 */     if (this.nonFatalIOExceptions != null) {
/*      */       
/*  551 */       IOException iOException = this.nonFatalIOExceptions.get(0);
/*      */       
/*      */       try {
/*  554 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
/*  555 */         sQLException.fillInStackTrace();
/*  556 */         throw sQLException;
/*      */       
/*      */       }
/*  559 */       catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  564 */         sQLException.initCause(iOException);
/*  565 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readBVC() throws IOException, SQLException {
/*  579 */     int i = this.meg.unmarshalUB2();
/*      */ 
/*      */     
/*  582 */     this.rxd.unmarshalBVC(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readIOV() throws IOException, SQLException {
/*  589 */     T4CTTIiov t4CTTIiov = new T4CTTIiov(this.connection, this.rxh, this.rxd);
/*      */     
/*  591 */     t4CTTIiov.init();
/*  592 */     t4CTTIiov.unmarshalV10();
/*      */ 
/*      */     
/*  595 */     if (this.oracleStatement.returnParamAccessors == null && !t4CTTIiov.isIOVectorEmpty()) {
/*      */ 
/*      */       
/*  598 */       byte[] arrayOfByte = t4CTTIiov.getIOVector();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  603 */       this.outBindAccessors = t4CTTIiov.processRXD(this.outBindAccessors, this.numberOfBindPositions, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.conversion, this.tmpBindsByteArray, arrayOfByte, this.parameterStream, this.parameterDatum, this.parameterOtype, this.oracleStatement, null, null, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readRXH() throws IOException, SQLException {
/*  619 */     this.rxh.init();
/*  620 */     this.rxh.unmarshalV10(this.rxd);
/*      */     
/*  622 */     if (this.rxh.uacBufLength > 0) {
/*      */ 
/*      */       
/*  625 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 405);
/*  626 */       sQLException.fillInStackTrace();
/*  627 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  631 */     if ((this.rxh.rxhflg & 0x8) == 8) {
/*      */ 
/*      */ 
/*      */       
/*  635 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 449);
/*  636 */       sQLException.fillInStackTrace();
/*  637 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  641 */     if ((this.rxh.rxhflg & 0x10) == 16)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  647 */       for (byte b = 0; b < this.definesAccessors.length; b++) {
/*      */         
/*  649 */         if ((this.definesAccessors[b]).udskpos >= 0 && (this.definesAccessors[b]).udskpos != b) {
/*      */ 
/*      */           
/*  652 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 450);
/*  653 */           sQLException.fillInStackTrace();
/*  654 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean readRXD() throws IOException, SQLException {
/*  670 */     this.aFetchWasDone = true;
/*      */ 
/*      */     
/*  673 */     if (this.oracleStatement.returnParamAccessors != null && this.numberOfBindPositions > 0) {
/*      */ 
/*      */       
/*  676 */       boolean bool = false;
/*  677 */       for (byte b = 0; b < this.oracleStatement.numberOfBindPositions; b++) {
/*      */         
/*  679 */         Accessor accessor = this.oracleStatement.returnParamAccessors[b];
/*  680 */         if (accessor != null) {
/*      */           
/*  682 */           int i = (int)this.meg.unmarshalUB4();
/*  683 */           if (!bool) {
/*      */             
/*  685 */             this.oracleStatement.rowsDmlReturned = i;
/*  686 */             this.oracleStatement.allocateDmlReturnStorage();
/*  687 */             this.oracleStatement.setupReturnParamAccessors();
/*  688 */             bool = true;
/*      */           } 
/*      */           
/*  691 */           for (byte b1 = 0; b1 < i; b1++)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  696 */             accessor.unmarshalOneRow(); } 
/*      */         } 
/*      */       } 
/*  699 */       this.oracleStatement.returnParamsFetched = true;
/*      */     
/*      */     }
/*  702 */     else if (this.iovProcessed || (this.outBindAccessors != null && this.definesAccessors == null)) {
/*      */ 
/*      */ 
/*      */       
/*  706 */       if (this.rxd.unmarshal(this.outBindAccessors, this.numberOfBindPositions))
/*      */       {
/*  708 */         return true;
/*      */       
/*      */       }
/*      */     }
/*  712 */     else if (this.rxd.unmarshal(this.definesAccessors, this.definesLength)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  718 */       return true;
/*      */     } 
/*      */     
/*  721 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readRPA() throws IOException, SQLException {
/*  747 */     int i = this.meg.unmarshalUB2();
/*  748 */     int[] arrayOfInt = new int[i];
/*      */     int j;
/*  750 */     for (j = 0; j < i; j++) {
/*  751 */       arrayOfInt[j] = (int)this.meg.unmarshalUB4();
/*      */     }
/*  753 */     j = arrayOfInt[0];
/*  754 */     int k = arrayOfInt[1];
/*  755 */     long l = j & 0xFFFFFFFFL | (k & 0xFFFFFFFFL) << 32L;
/*      */ 
/*      */     
/*  758 */     if (l != 0L) {
/*  759 */       this.oracleStatement.connection.outScn = l;
/*      */     }
/*      */ 
/*      */     
/*  763 */     this.cursor = arrayOfInt[2];
/*      */ 
/*      */     
/*  766 */     int m = this.meg.unmarshalUB2();
/*      */     
/*  768 */     byte[] arrayOfByte = null;
/*  769 */     if (m > 0) {
/*  770 */       arrayOfByte = this.meg.unmarshalNBytes(m);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  779 */     int n = this.meg.unmarshalUB2();
/*      */     
/*  781 */     KeywordValue[] arrayOfKeywordValue = new KeywordValue[n]; int i1;
/*  782 */     for (i1 = 0; i1 < n; i1++) {
/*  783 */       arrayOfKeywordValue[i1] = KeywordValueI.unmarshal(this.meg);
/*      */     }
/*  785 */     this.connection.updateSessionProperties(arrayOfKeywordValue);
/*      */ 
/*      */     
/*  788 */     this.oracleStatement.dcnQueryId = -1L;
/*  789 */     this.oracleStatement.dcnTableName = null;
/*  790 */     if (this.connection.getTTCVersion() >= 4) {
/*      */       
/*  792 */       i1 = (int)this.meg.unmarshalUB4();
/*  793 */       byte[] arrayOfByte1 = this.meg.unmarshalNBytes(i1);
/*  794 */       if (i1 > 0 && this.registration != null) {
/*      */         
/*  796 */         boolean bool = false;
/*  797 */         Properties properties = this.registration.getRegistrationOptions();
/*  798 */         if (properties != null) {
/*      */           
/*  800 */           String str1 = properties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION");
/*  801 */           if (str1 != null && str1.compareToIgnoreCase("true") == 0)
/*  802 */             bool = true; 
/*      */         } 
/*  804 */         int i2 = i1;
/*  805 */         if (bool) {
/*  806 */           i2 = i1 - 8;
/*      */         }
/*  808 */         String str = new String(arrayOfByte1, 0, i2);
/*  809 */         char[] arrayOfChar = { Character.MIN_VALUE };
/*  810 */         String[] arrayOfString = str.split(new String(arrayOfChar));
/*  811 */         this.registration.addTablesName(arrayOfString, arrayOfString.length);
/*      */         
/*  813 */         this.oracleStatement.dcnTableName = arrayOfString;
/*      */         
/*  815 */         if (bool) {
/*      */ 
/*      */           
/*  818 */           int i3 = arrayOfByte1[i1 - 1] & 0xFF | (arrayOfByte1[i1 - 2] & 0xFF) << 8 | (arrayOfByte1[i1 - 3] & 0xFF) << 16 | (arrayOfByte1[i1 - 4] & 0xFF) << 24;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  823 */           int i4 = arrayOfByte1[i1 - 5] & 0xFF | (arrayOfByte1[i1 - 6] & 0xFF) << 8 | (arrayOfByte1[i1 - 7] & 0xFF) << 16 | (arrayOfByte1[i1 - 8] & 0xFF) << 24;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  828 */           long l1 = i4 & 0xFFFFFFFFL | (i3 & 0xFFFFFFFFL) << 32L;
/*  829 */           this.oracleStatement.dcnQueryId = l1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void readDCB() throws IOException, SQLException {
/*  842 */     this.dcb.init(this.oracleStatement, 0);
/*      */     
/*  844 */     this.definesAccessors = this.dcb.receive(this.definesAccessors);
/*  845 */     this.numberOfDefinePositions = this.dcb.numuds;
/*  846 */     this.definesLength = this.numberOfDefinePositions;
/*      */     
/*  848 */     this.rxd.setNumberOfColumns(this.numberOfDefinePositions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processError() throws SQLException {
/*  860 */     this.cursor = this.oer.currCursorID;
/*      */ 
/*      */ 
/*      */     
/*  864 */     this.rowsProcessed = this.oer.getCurRowNumber();
/*      */ 
/*      */     
/*  867 */     if (this.typeOfStatement.isSELECT() && this.oer.retCode == 1403)
/*      */     {
/*  869 */       this.aFetchWasDone = true;
/*      */     }
/*  871 */     if (!this.typeOfStatement.isSELECT() || (this.typeOfStatement.isSELECT() && this.oer.retCode != 1403)) {
/*      */ 
/*      */       
/*  874 */       if (this.oracleStatement.connection.calculateChecksum && this.oer.retCode != 0) {
/*      */         
/*  876 */         long l = this.oer.updateChecksum(this.oracleStatement.checkSum);
/*  877 */         this.oracleStatement.checkSum = l;
/*      */       } 
/*  879 */       this.oer.processError(this.oracleStatement);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getCursorId() {
/*  892 */     return this.cursor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt, OracleStatement paramOracleStatement) throws SQLException, IOException {
/*      */     try {
/*  909 */       this.oracleStatement = paramOracleStatement;
/*      */ 
/*      */ 
/*      */       
/*  913 */       this.receiveState = 2;
/*      */       
/*  915 */       if (this.rxd.unmarshal(this.definesAccessors, paramInt, this.definesLength)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  921 */         this.receiveState = 3;
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  927 */       resumeReceive();
/*      */     }
/*      */     finally {
/*      */       
/*  931 */       this.oracleStatement = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getNumRows() {
/*  945 */     int i = 0;
/*      */     
/*  947 */     if (this.typeOfStatement == null)
/*  948 */       return i; 
/*  949 */     if (this.receiveState == 3) {
/*  950 */       i = -2;
/*      */     } else {
/*      */       
/*  953 */       switch (this.typeOfStatement) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case DELETE:
/*      */         case INSERT:
/*      */         case MERGE:
/*      */         case UPDATE:
/*      */         case ALTER_SESSION:
/*      */         case OTHER:
/*      */         case PLSQL_BLOCK:
/*      */         case CALL_BLOCK:
/*  967 */           i = this.rowsProcessed;
/*      */           break;
/*      */ 
/*      */         
/*      */         case SELECT_FOR_UPDATE:
/*      */         case SELECT:
/*  973 */           i = (this.definesAccessors != null && this.definesLength > 0) ? (this.definesAccessors[0]).lastRowProcessed : 0;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/*  980 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void marshal() throws IOException {
/*  994 */     if (getFunCode() == 5) {
/*      */       
/*  996 */       this.meg.marshalSWORD(this.cursor);
/*  997 */       this.meg.marshalSWORD((int)this.al8i4[1]);
/*      */     }
/*      */     else {
/*      */       
/* 1001 */       if (this.oracleStatement.needToSendOalToFetch) {
/* 1002 */         this.oracleStatement.needToSendOalToFetch = false;
/*      */       }
/* 1004 */       marshalPisdef();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1010 */       this.meg.marshalCHR(this.sqlStmt);
/*      */ 
/*      */       
/* 1013 */       this.meg.marshalUB4Array(this.al8i4);
/*      */ 
/*      */       
/* 1016 */       int[] arrayOfInt = new int[this.numberOfBindPositions];
/*      */       byte b;
/* 1018 */       for (b = 0; b < this.numberOfBindPositions; b++)
/*      */       {
/* 1020 */         arrayOfInt[b] = (this.oacdefBindsSent[b]).oacmxl;
/*      */       }
/*      */ 
/*      */       
/* 1024 */       if ((this.options & 0x8L) != 0L && this.numberOfBindPositions > 0 && this.bindIndicators != null && this.sendBindsDefinition)
/*      */       {
/* 1026 */         marshalBindsTypes(this.oacdefBindsSent);
/*      */       }
/*      */ 
/*      */       
/* 1030 */       if (this.connection.getTTCVersion() >= 2 && (this.options & 0x10L) != 0L)
/*      */       {
/* 1032 */         for (b = 0; b < this.defCols; b++) {
/* 1033 */           this.oacdefDefines[b].marshal();
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1039 */       if ((this.options & 0x20L) != 0L && this.numberOfBindPositions > 0 && this.bindIndicators != null)
/*      */       {
/* 1041 */         this.nonFatalIOExceptions = marshalBinds(arrayOfInt);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void marshalPisdef() throws IOException {
/* 1061 */     this.meg.marshalUB4(this.options);
/*      */ 
/*      */     
/* 1064 */     this.meg.marshalSWORD(this.cursor);
/*      */ 
/*      */ 
/*      */     
/* 1068 */     if (this.sqlStmt.length == 0) {
/* 1069 */       this.meg.marshalNULLPTR();
/*      */     } else {
/* 1071 */       this.meg.marshalPTR();
/*      */     } 
/*      */     
/* 1074 */     this.meg.marshalSWORD(this.sqlStmt.length);
/*      */ 
/*      */ 
/*      */     
/* 1078 */     if (this.al8i4.length == 0) {
/* 1079 */       this.meg.marshalNULLPTR();
/*      */     } else {
/* 1081 */       this.meg.marshalPTR();
/*      */     } 
/*      */     
/* 1084 */     this.meg.marshalSWORD(this.al8i4.length);
/*      */ 
/*      */ 
/*      */     
/* 1088 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1091 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1094 */     if ((this.options & 0x40L) == 0L && (this.options & 0x20L) != 0L && (this.options & 0x1L) != 0L && this.typeOfStatement.isSELECT()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1100 */       this.meg.marshalUB4(Long.MAX_VALUE);
/* 1101 */       this.meg.marshalUB4(this.rowsToFetch);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1106 */       this.meg.marshalUB4(0L);
/*      */       
/* 1108 */       this.meg.marshalUB4(0L);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1113 */     if (!this.typeOfStatement.isPlsqlOrCall()) {
/* 1114 */       this.meg.marshalUB4(2147483647L);
/*      */     } else {
/* 1116 */       this.meg.marshalUB4(32760L);
/*      */     } 
/*      */     
/* 1119 */     if ((this.options & 0x8L) != 0L && this.numberOfBindPositions > 0 && this.sendBindsDefinition) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1124 */       this.meg.marshalPTR();
/*      */ 
/*      */       
/* 1127 */       this.meg.marshalSWORD(this.numberOfBindPositions);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1133 */       this.meg.marshalNULLPTR();
/*      */ 
/*      */       
/* 1136 */       this.meg.marshalSWORD(0);
/*      */     } 
/*      */ 
/*      */     
/* 1140 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1143 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1146 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1149 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */     
/* 1152 */     this.meg.marshalNULLPTR();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1157 */     if (this.connection.getTTCVersion() >= 2)
/*      */     {
/* 1159 */       if (this.defCols > 0 && (this.options & 0x10L) != 0L) {
/*      */ 
/*      */ 
/*      */         
/* 1163 */         this.meg.marshalPTR();
/*      */ 
/*      */         
/* 1166 */         this.meg.marshalSWORD(this.defCols);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1172 */         this.meg.marshalNULLPTR();
/*      */ 
/*      */         
/* 1175 */         this.meg.marshalSWORD(0);
/*      */       } 
/*      */     }
/*      */     
/* 1179 */     if (this.connection.getTTCVersion() >= 4) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1188 */       int i = 0;
/* 1189 */       int j = 0;
/* 1190 */       if (this.registration != null) {
/*      */         
/* 1192 */         long l = this.registration.getRegId();
/* 1193 */         i = (int)(l & 0xFFFFFFFFFFFFFFFFL);
/* 1194 */         j = (int)((l & 0xFFFFFFFF00000000L) >> 32L);
/*      */       } 
/*      */ 
/*      */       
/* 1198 */       this.meg.marshalUB4(i);
/*      */       
/* 1200 */       this.meg.marshalNULLPTR();
/* 1201 */       this.meg.marshalPTR();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1222 */       if (this.connection.getTTCVersion() >= 5) {
/*      */         
/* 1224 */         this.meg.marshalNULLPTR();
/* 1225 */         this.meg.marshalUB4(0L);
/* 1226 */         this.meg.marshalNULLPTR();
/* 1227 */         this.meg.marshalUB4(0L);
/*      */         
/* 1229 */         this.meg.marshalUB4(j);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean initBindsDefinition(T4CTTIoac[] paramArrayOfT4CTTIoac) throws SQLException, IOException {
/* 1244 */     boolean bool = false;
/*      */     
/* 1246 */     if (paramArrayOfT4CTTIoac.length != this.numberOfBindPositions) {
/*      */       
/* 1248 */       bool = true;
/* 1249 */       paramArrayOfT4CTTIoac = new T4CTTIoac[this.numberOfBindPositions];
/*      */     } 
/*      */ 
/*      */     
/* 1253 */     short[] arrayOfShort = this.bindIndicators;
/*      */ 
/*      */     
/* 1256 */     int i = 0;
/*      */ 
/*      */     
/* 1259 */     byte b1 = 0;
/*      */ 
/*      */     
/* 1262 */     for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) {
/*      */       SQLException sQLException; int arrayOfInt[], m;
/* 1264 */       T4CTTIoac t4CTTIoac = new T4CTTIoac(this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1269 */       int j = this.bindIndicatorSubRange + 5 + 10 * b2;
/*      */ 
/*      */ 
/*      */       
/* 1273 */       short s = arrayOfShort[j + 9];
/*      */ 
/*      */       
/* 1276 */       int k = arrayOfShort[j + 0] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1281 */       switch (k) {
/*      */ 
/*      */         
/*      */         case 8:
/*      */         case 24:
/* 1286 */           if (this.plsql) {
/* 1287 */             i = 32760;
/*      */           } else {
/* 1289 */             i = Integer.MAX_VALUE;
/*      */           } 
/* 1291 */           t4CTTIoac.init((short)k, i);
/* 1292 */           t4CTTIoac.setFormOfUse(s);
/* 1293 */           t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 998:
/* 1300 */           if (this.outBindAccessors != null && this.outBindAccessors[b2] != null) {
/*      */             
/* 1302 */             PlsqlIndexTableAccessor plsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[b2];
/* 1303 */             t4CTTIoac.init((short)plsqlIndexTableAccessor.elementInternalType, plsqlIndexTableAccessor.elementMaxLen);
/* 1304 */             t4CTTIoac.setMal(plsqlIndexTableAccessor.maxNumberOfElements);
/* 1305 */             t4CTTIoac.addFlg((short)64);
/* 1306 */             b1++; break;
/*      */           } 
/* 1308 */           if (this.ibtBindIndicators[6 + b1 * 8] != 0) {
/*      */             
/* 1310 */             short s1 = this.ibtBindIndicators[6 + b1 * 8];
/* 1311 */             int n = (this.ibtBindIndicators[6 + b1 * 8 + 2] & 0xFFFF) << 16 | this.ibtBindIndicators[6 + b1 * 8 + 3] & 0xFFFF;
/*      */ 
/*      */ 
/*      */             
/* 1315 */             i = this.ibtBindIndicators[6 + b1 * 8 + 1] * this.conversion.sMaxCharSize;
/*      */             
/* 1317 */             t4CTTIoac.init((short)s1, i);
/* 1318 */             t4CTTIoac.setMal(n);
/* 1319 */             t4CTTIoac.addFlg((short)64);
/* 1320 */             b1++;
/*      */             
/*      */             break;
/*      */           } 
/* 1324 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding PLSQL index-by table but no type defined", -1);
/* 1325 */           sQLException.fillInStackTrace();
/* 1326 */           throw sQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 109:
/*      */         case 111:
/* 1334 */           if (this.outBindAccessors != null && this.outBindAccessors[b2] != null) {
/*      */             
/* 1336 */             if ((this.outBindAccessors[b2]).internalOtype != null) {
/*      */               
/* 1338 */               t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
/*      */               
/* 1340 */               t4CTTIoac.setADT((OracleTypeADT)((TypeAccessor)this.outBindAccessors[b2]).internalOtype);
/*      */             } 
/*      */             break;
/*      */           } 
/* 1344 */           if (this.parameterOtype != null && this.parameterOtype[this.oracleStatement.firstRowInBatch] != null) {
/*      */ 
/*      */             
/* 1347 */             t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
/* 1348 */             t4CTTIoac.setADT(this.parameterOtype[this.oracleStatement.firstRowInBatch][b2]);
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/* 1354 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding NAMED_TYPE but no type defined", -1);
/* 1355 */           sQLException.fillInStackTrace();
/* 1356 */           throw sQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 994:
/* 1364 */           arrayOfInt = this.oracleStatement.returnParamMeta;
/* 1365 */           k = arrayOfInt[3 + b2 * 4 + 0];
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1370 */           i = arrayOfInt[3 + b2 * 4 + 2];
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1375 */           s = (short)arrayOfInt[3 + b2 * 4 + 3];
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1380 */           if (k == 109 || k == 111) {
/*      */             
/* 1382 */             TypeAccessor typeAccessor = (TypeAccessor)this.oracleStatement.returnParamAccessors[b2];
/*      */ 
/*      */             
/* 1385 */             t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
/*      */             
/* 1387 */             t4CTTIoac.setADT((OracleTypeADT)typeAccessor.internalOtype);
/*      */             
/*      */             break;
/*      */           } 
/* 1391 */           t4CTTIoac.init((short)k, i);
/* 1392 */           t4CTTIoac.setFormOfUse(s);
/* 1393 */           t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 180:
/* 1400 */           i = arrayOfShort[j + 1] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/* 1404 */           t4CTTIoac.init((short)k, i);
/* 1405 */           t4CTTIoac.addFlg2(134217728);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1413 */           t4CTTIoac.setTimestampFractionalSecondsPrecision((short)9);
/*      */           
/* 1415 */           m = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1420 */           if (m == 1) {
/*      */             
/* 1422 */             int n = ((arrayOfShort[j + 7] & 0xFFFF) << 16) + (arrayOfShort[j + 8] & 0xFFFF);
/*      */ 
/*      */             
/* 1425 */             short s1 = arrayOfShort[n];
/*      */             
/* 1427 */             if (s1 == 7)
/*      */             {
/* 1429 */               t4CTTIoac.setTimestampFractionalSecondsPrecision((short)0);
/*      */             }
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1440 */           i = arrayOfShort[j + 1] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1447 */           if (i == 0) {
/*      */             
/* 1449 */             i = arrayOfShort[j + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */             
/* 1453 */             if (k == 996) {
/* 1454 */               i *= 2;
/*      */             }
/* 1456 */             else if (i > 1) {
/* 1457 */               i--;
/*      */             } 
/*      */             
/* 1460 */             if (s == 2) {
/* 1461 */               i *= this.conversion.maxNCharSize;
/*      */             }
/*      */ 
/*      */             
/* 1465 */             if (this.typeOfStatement == OracleStatement.SqlKind.PLSQL_BLOCK || (this.connection.versionNumber >= 10200 && this.typeOfStatement == OracleStatement.SqlKind.CALL_BLOCK)) {
/*      */ 
/*      */ 
/*      */               
/* 1469 */               if (i == 0) {
/* 1470 */                 i = 32766;
/*      */               } else {
/* 1472 */                 i *= this.conversion.sMaxCharSize;
/*      */               } 
/* 1474 */             } else if (this.typeOfStatement == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1481 */               if (i < 4001) {
/* 1482 */                 i = 4001;
/*      */               
/*      */               }
/*      */             
/*      */             }
/* 1487 */             else if (s != 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1498 */               if (((T4CConnection)this.oracleStatement.connection).retainV9BindBehavior && i <= 4000) {
/*      */ 
/*      */ 
/*      */                 
/* 1502 */                 i = Math.min(i * this.conversion.sMaxCharSize, 4000);
/*      */               
/*      */               }
/*      */               else {
/*      */                 
/* 1507 */                 i *= this.conversion.sMaxCharSize;
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 1513 */             if (i == 0) {
/* 1514 */               i = 32;
/*      */             }
/*      */           } 
/* 1517 */           t4CTTIoac.init((short)k, i);
/* 1518 */           t4CTTIoac.setFormOfUse(s);
/* 1519 */           t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 1524 */       if (paramArrayOfT4CTTIoac[b2] == null || !t4CTTIoac.isOldSufficient(paramArrayOfT4CTTIoac[b2])) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1531 */         paramArrayOfT4CTTIoac[b2] = t4CTTIoac;
/* 1532 */         bool = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1538 */     if (bool) {
/* 1539 */       this.oracleStatement.nbPostPonedColumns[0] = 0;
/*      */     }
/* 1541 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initDefinesDefinition() throws SQLException, IOException {
/* 1555 */     this.defCols = 0;
/*      */     int i;
/* 1557 */     for (i = 0; i < this.definedColumnType.length; i++) {
/*      */       
/* 1559 */       if (this.definedColumnType[i] == 0)
/*      */         break; 
/* 1561 */       this.defCols++;
/*      */     } 
/* 1563 */     this.oacdefDefines = new T4CTTIoac[this.defCols];
/* 1564 */     i = 0;
/* 1565 */     int j = 0;
/* 1566 */     int k = 0;
/* 1567 */     short s = 0;
/* 1568 */     for (byte b = 0; b < this.oacdefDefines.length; b++) {
/*      */       
/* 1570 */       this.oacdefDefines[b] = new T4CTTIoac(this.connection);
/* 1571 */       s = (short)this.oracleStatement.getInternalType(this.definedColumnType[b]);
/* 1572 */       j = Integer.MAX_VALUE;
/* 1573 */       i = 0;
/* 1574 */       k = 0;
/* 1575 */       byte b1 = 1;
/* 1576 */       if (this.definedColumnFormOfUse != null && this.definedColumnFormOfUse.length > b && this.definedColumnFormOfUse[b] == 2)
/*      */       {
/*      */ 
/*      */         
/* 1580 */         b1 = 2;
/*      */       }
/* 1582 */       if (s == 8) {
/* 1583 */         s = 1;
/* 1584 */       } else if (s == 24) {
/* 1585 */         s = 23;
/* 1586 */       } else if (s == 1 || s == 96) {
/*      */ 
/*      */         
/* 1589 */         s = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1595 */         j = 4000 * this.conversion.sMaxCharSize;
/*      */         
/* 1597 */         if (this.definedColumnSize != null && this.definedColumnSize.length > b && this.definedColumnSize[b] > 0)
/*      */         {
/*      */ 
/*      */           
/* 1601 */           j = this.definedColumnSize[b] * this.conversion.sMaxCharSize;
/*      */         }
/* 1603 */       } else if (this.connection.useLobPrefetch && (s == 113 || s == 112 || s == 114)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1608 */         j = 0;
/* 1609 */         i = 33554432;
/* 1610 */         if (this.definedColumnSize != null && this.definedColumnSize.length > b && this.definedColumnSize[b] > 0)
/*      */         {
/*      */ 
/*      */           
/* 1614 */           k = this.definedColumnSize[b];
/*      */         }
/* 1616 */       } else if (s == 23) {
/* 1617 */         j = 4000;
/*      */       } 
/* 1619 */       this.oacdefDefines[b].init(s, j);
/* 1620 */       this.oacdefDefines[b].addFlg2(i);
/* 1621 */       this.oacdefDefines[b].setMxlc(k);
/* 1622 */       this.oacdefDefines[b].setFormOfUse(b1);
/* 1623 */       this.oacdefDefines[b].setCharset((b1 == 2) ? this.NCharSet : this.dbCharSet);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void marshalBindsTypes(T4CTTIoac[] paramArrayOfT4CTTIoac) throws IOException {
/* 1633 */     if (paramArrayOfT4CTTIoac == null) {
/*      */       return;
/*      */     }
/* 1636 */     for (byte b = 0; b < paramArrayOfT4CTTIoac.length; b++)
/*      */     {
/* 1638 */       paramArrayOfT4CTTIoac[b].marshal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Vector<IOException> marshalBinds(int[] paramArrayOfint) throws IOException {
/* 1655 */     Vector<IOException> vector = null;
/* 1656 */     int i = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1664 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 1666 */       int j = this.oracleStatement.firstRowInBatch + b;
/* 1667 */       InputStream[] arrayOfInputStream = null;
/* 1668 */       if (this.parameterStream != null)
/* 1669 */         arrayOfInputStream = this.parameterStream[j]; 
/* 1670 */       byte[][] arrayOfByte = (byte[][])null;
/* 1671 */       if (this.parameterDatum != null)
/* 1672 */         arrayOfByte = this.parameterDatum[j]; 
/* 1673 */       OracleTypeADT[] arrayOfOracleTypeADT = null;
/* 1674 */       if (this.parameterOtype != null) {
/* 1675 */         arrayOfOracleTypeADT = this.parameterOtype[j];
/*      */       }
/*      */       
/* 1678 */       Vector<IOException> vector1 = this.rxd.marshal(this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.tmpBindsByteArray, this.conversion, arrayOfInputStream, arrayOfByte, arrayOfOracleTypeADT, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, null, b, paramArrayOfint, this.plsql, this.oracleStatement.returnParamMeta, this.oracleStatement.nbPostPonedColumns, this.oracleStatement.indexOfPostPonedColumn);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1687 */       if (vector1 != null) {
/*      */         
/* 1689 */         if (vector == null)
/* 1690 */           vector = new Vector(); 
/* 1691 */         vector.addAll(vector1);
/*      */       } 
/*      */     } 
/* 1694 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long setOptions(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws SQLException {
/* 1703 */     long l = 0L;
/*      */ 
/*      */     
/* 1706 */     if (paramBoolean1 && !paramBoolean2 && !paramBoolean3) {
/* 1707 */       l |= 0x1L;
/* 1708 */     } else if (paramBoolean1 && paramBoolean2 && !paramBoolean3) {
/* 1709 */       l = 32801L;
/* 1710 */     } else if (paramBoolean2 && paramBoolean3) {
/*      */       SQLException sQLException;
/* 1712 */       if (paramBoolean1) {
/* 1713 */         l |= 0x1L;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1718 */       switch (this.typeOfStatement) {
/*      */ 
/*      */         
/*      */         case SELECT_FOR_UPDATE:
/*      */         case SELECT:
/* 1723 */           l |= 0x8060L;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case PLSQL_BLOCK:
/*      */         case CALL_BLOCK:
/* 1730 */           if (this.numberOfBindPositions > 0) {
/*      */ 
/*      */             
/* 1733 */             l |= 0x420L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
/*      */ 
/*      */             
/* 1736 */             if (this.sendBindsDefinition)
/* 1737 */               l |= 0x8L; 
/*      */             break;
/*      */           } 
/* 1740 */           l |= 0x20L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case DELETE:
/*      */         case INSERT:
/*      */         case MERGE:
/*      */         case UPDATE:
/*      */         case ALTER_SESSION:
/*      */         case OTHER:
/* 1755 */           if (this.oracleStatement.returnParamAccessors != null) {
/* 1756 */             l |= 0x420L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
/*      */             break;
/*      */           } 
/* 1759 */           l |= 0x8020L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1767 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
/* 1768 */           sQLException.fillInStackTrace();
/* 1769 */           throw sQLException;
/*      */       } 
/*      */ 
/*      */     
/* 1773 */     } else if (!paramBoolean1 && !paramBoolean2 && paramBoolean3) {
/* 1774 */       l = 32832L;
/*      */     }
/*      */     else {
/*      */       
/* 1778 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
/* 1779 */       sQLException.fillInStackTrace();
/* 1780 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1785 */     if (!this.typeOfStatement.isPlsqlOrCall()) {
/*      */ 
/*      */ 
/*      */       
/* 1789 */       if (paramBoolean1 || paramBoolean2 || !paramBoolean3)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1796 */         if (this.numberOfBindPositions > 0 && this.sendBindsDefinition) {
/* 1797 */           l |= 0x8L;
/*      */         }
/*      */       }
/* 1800 */       if (this.connection.versionNumber >= 9000 && paramBoolean4)
/*      */       {
/* 1802 */         l |= 0x10L;
/*      */       }
/*      */     } 
/*      */     
/* 1806 */     l &= 0xFFFFFFFFFFFFFFFFL;
/*      */ 
/*      */     
/* 1809 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1824 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1829 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4C8Oall.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */