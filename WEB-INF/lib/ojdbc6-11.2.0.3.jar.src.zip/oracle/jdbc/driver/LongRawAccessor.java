/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LongRawAccessor
/*     */   extends RawCommonAccessor
/*     */ {
/*     */   OracleInputStream stream;
/*  29 */   int columnPosition = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3) throws SQLException {
/*  36 */     init(paramOracleStatement, 24, 24, paramShort, false);
/*     */     
/*  38 */     this.columnPosition = paramInt1;
/*     */     
/*  40 */     initForDataAccess(paramInt3, paramInt2, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
/*  49 */     init(paramOracleStatement, 24, 24, paramShort, false);
/*     */     
/*  51 */     this.columnPosition = paramInt1;
/*     */     
/*  53 */     initForDescribe(24, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, null);
/*     */ 
/*     */     
/*  56 */     int i = paramOracleStatement.maxFieldSize;
/*     */     
/*  58 */     if (i > 0 && (paramInt2 == 0 || i < paramInt2)) {
/*  59 */       paramInt2 = i;
/*     */     }
/*  61 */     initForDataAccess(0, paramInt2, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  69 */     if (paramInt1 != 0) {
/*  70 */       this.externalType = paramInt1;
/*     */     }
/*  72 */     this.isStream = true;
/*  73 */     this.isColumnNumberAware = true;
/*  74 */     this.internalTypeMaxLength = Integer.MAX_VALUE;
/*     */     
/*  76 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*  77 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  79 */     this.byteLength = 0;
/*     */ 
/*     */     
/*  82 */     this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleInputStream initForNewRow() throws SQLException {
/*  97 */     this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     return this.stream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateColumnNumber(int paramInt) {
/* 114 */     this.columnPosition = ++paramInt;
/*     */     
/* 116 */     if (this.stream != null) {
/* 117 */       this.stream.columnIndex = paramInt;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 138 */     byte[] arrayOfByte = null;
/*     */     
/* 140 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 144 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 145 */       sQLException.fillInStackTrace();
/* 146 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 151 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*     */     {
/* 153 */       if (this.stream != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 159 */         if (this.stream.closed) {
/*     */           
/* 161 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 162 */           sQLException.fillInStackTrace();
/* 163 */           throw sQLException;
/*     */         } 
/*     */         
/* 166 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
/* 167 */         byte[] arrayOfByte1 = new byte[1024];
/*     */         
/*     */         try {
/*     */           int i;
/*     */           
/* 172 */           while ((i = this.stream.read(arrayOfByte1)) != -1)
/*     */           {
/* 174 */             byteArrayOutputStream.write(arrayOfByte1, 0, i);
/*     */           }
/*     */         }
/* 177 */         catch (IOException iOException) {
/*     */ 
/*     */           
/* 180 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 181 */           sQLException.fillInStackTrace();
/* 182 */           throw sQLException;
/*     */         } 
/*     */ 
/*     */         
/* 186 */         arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 192 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 211 */     InputStream inputStream = null;
/*     */     
/* 213 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 217 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 218 */       sQLException.fillInStackTrace();
/* 219 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
/*     */       
/* 226 */       if (this.stream.closed) {
/*     */         
/* 228 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 229 */         sQLException.fillInStackTrace();
/* 230 */         throw sQLException;
/*     */       } 
/*     */       
/* 233 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 235 */       inputStream = physicalConnection.conversion.ConvertStream(this.stream, 2);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 240 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 257 */     InputStream inputStream = null;
/*     */     
/* 259 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 263 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 264 */       sQLException.fillInStackTrace();
/* 265 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 270 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
/*     */       
/* 272 */       if (this.stream.closed) {
/*     */         
/* 274 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 275 */         sQLException.fillInStackTrace();
/* 276 */         throw sQLException;
/*     */       } 
/*     */       
/* 279 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 281 */       inputStream = physicalConnection.conversion.ConvertStream(this.stream, 3);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 286 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 303 */     Reader reader = null;
/*     */     
/* 305 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 309 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 310 */       sQLException.fillInStackTrace();
/* 311 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 316 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
/*     */       
/* 318 */       if (this.stream.closed) {
/*     */         
/* 320 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 321 */         sQLException.fillInStackTrace();
/* 322 */         throw sQLException;
/*     */       } 
/*     */       
/* 325 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 327 */       reader = physicalConnection.conversion.ConvertCharacterStream(this.stream, 8);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 333 */     return reader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 350 */     InputStream inputStream = null;
/*     */     
/* 352 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 356 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 357 */       sQLException.fillInStackTrace();
/* 358 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 363 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
/*     */       
/* 365 */       if (this.stream.closed) {
/*     */         
/* 367 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
/* 368 */         sQLException.fillInStackTrace();
/* 369 */         throw sQLException;
/*     */       } 
/*     */       
/* 372 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 374 */       inputStream = physicalConnection.conversion.ConvertStream(this.stream, 6);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 379 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 387 */     return "LongRawAccessor@" + Integer.toHexString(hashCode()) + "{columnPosition = " + this.columnPosition + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 394 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\LongRawAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */