/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormatSymbols;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CVarcharAccessor
/*      */   extends VarcharAccessor
/*      */ {
/*      */   T4CMAREngine mare;
/*      */   static final int t4MaxLength = 4000;
/*      */   static final int t4CallMaxLength = 4001;
/*      */   static final int t4PlsqlMaxLength = 32766;
/*      */   static final int t4SqlMinLength = 32;
/*      */   boolean underlyingLong = false;
/*      */   final int[] meta;
/*      */   final int[] tmp;
/*      */   final int[] escapeSequenceArr;
/*      */   final boolean[] readHeaderArr;
/*      */   final boolean[] readAsNonStreamArr;
/*      */   static final int NONE = -1;
/*      */   static final int DAY = 1;
/*      */   static final int MM_MONTH = 2;
/*      */   static final int FULL_MONTH = 3;
/*      */   static final int MON_MONTH = 4;
/*      */   static final int YY_YEAR = 5;
/*      */   static final int RR_YEAR = 6;
/*      */   static final int HH_HOUR = 7;
/*      */   static final int HH24_HOUR = 8;
/*      */   static final int MINUTE = 9;
/*      */   static final int SECOND = 10;
/*      */   static final int NSECOND = 11;
/*      */   static final int AM = 12;
/*      */   static final int TZR = 13;
/*      */   static final int TZH = 14;
/*      */   static final int TZM = 15;
/*      */   
/*      */   T4CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*   70 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  141 */     this.meta = new int[1];
/*  142 */     this.tmp = new int[1];
/*  143 */     this.escapeSequenceArr = new int[1];
/*  144 */     this.readHeaderArr = new boolean[1];
/*  145 */     this.readAsNonStreamArr = new boolean[1]; this.mare = paramT4CMAREngine; calculateSizeTmpByteArray(); } T4CVarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1]; this.tmp = new int[1]; this.escapeSequenceArr = new int[1]; this.readHeaderArr = new boolean[1]; this.readAsNonStreamArr = new boolean[1];
/*      */     this.mare = paramT4CMAREngine;
/*      */     this.definedColumnType = paramInt8;
/*      */     this.definedColumnSize = paramInt9;
/*      */     calculateSizeTmpByteArray();
/*      */     this.oacmxl = paramInt7;
/*      */     if (this.oacmxl == -1) {
/*      */       this.underlyingLong = true;
/*      */       this.oacmxl = 4000;
/*  154 */     }  } boolean unmarshalOneRow() throws SQLException, IOException { if (this.isUseLess) {
/*      */       
/*  156 */       this.lastRowProcessed++;
/*      */       
/*  158 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  162 */     int i = this.indicatorIndex + this.lastRowProcessed;
/*  163 */     int j = this.lengthIndex + this.lastRowProcessed;
/*      */ 
/*      */ 
/*      */     
/*  167 */     byte[] arrayOfByte = this.statement.tmpByteArray;
/*  168 */     int k = this.columnIndex + this.lastRowProcessed * this.charLength;
/*      */     
/*  170 */     if (!this.underlyingLong) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  175 */       if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */         
/*  179 */         byte[] arrayOfByte1 = new byte[16000];
/*      */         
/*  181 */         this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
/*  182 */         processIndicator(this.meta[0]);
/*      */         
/*  184 */         this.lastRowProcessed++;
/*      */         
/*  186 */         return false;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  191 */       if (this.isNullByDescribe) {
/*      */         
/*  193 */         this.rowSpaceIndicator[i] = -1;
/*  194 */         this.rowSpaceIndicator[j] = 0;
/*  195 */         this.lastRowProcessed++;
/*      */         
/*  197 */         if (this.statement.connection.versionNumber < 9200) {
/*  198 */           processIndicator(0);
/*      */         }
/*  200 */         return false;
/*      */       } 
/*      */       
/*  203 */       if (this.statement.maxFieldSize > 0) {
/*  204 */         this.mare.unmarshalCLR(arrayOfByte, 0, this.meta, this.statement.maxFieldSize);
/*      */       } else {
/*  206 */         this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  212 */       this.escapeSequenceArr[0] = this.mare.unmarshalUB1();
/*      */ 
/*      */       
/*  215 */       if (this.mare.escapeSequenceNull(this.escapeSequenceArr[0])) {
/*      */ 
/*      */ 
/*      */         
/*  219 */         this.meta[0] = 0;
/*      */         
/*  221 */         this.mare.processIndicator(false, 0);
/*      */         
/*  223 */         int n = this.mare.unmarshalUB2();
/*      */       }
/*      */       else {
/*      */         
/*  227 */         int n = 0;
/*  228 */         int i1 = 0;
/*  229 */         byte[] arrayOfByte1 = arrayOfByte;
/*  230 */         int i2 = 0;
/*      */         
/*  232 */         this.readHeaderArr[0] = true;
/*  233 */         this.readAsNonStreamArr[0] = false;
/*      */         
/*  235 */         while (n != -1) {
/*      */           
/*  237 */           if (arrayOfByte1 == arrayOfByte && i1 + 255 > arrayOfByte.length)
/*      */           {
/*      */ 
/*      */             
/*  241 */             arrayOfByte1 = new byte[255];
/*      */           }
/*  243 */           if (arrayOfByte1 == arrayOfByte) {
/*  244 */             i2 = i1;
/*      */           } else {
/*  246 */             i2 = 0;
/*      */           } 
/*  248 */           n = T4CLongAccessor.readStreamFromWire(arrayOfByte1, i2, 255, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);
/*      */ 
/*      */ 
/*      */           
/*  252 */           if (this.statement.connection.calculateChecksum && n != -1) {
/*      */ 
/*      */             
/*  255 */             long l = CRC64.updateChecksum(this.statement.checkSum, arrayOfByte1, i2, n);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  260 */             this.statement.checkSum = l;
/*      */           } 
/*      */ 
/*      */           
/*  264 */           if (n != -1) {
/*      */             
/*  266 */             if (arrayOfByte1 == arrayOfByte) {
/*  267 */               i1 += n; continue;
/*  268 */             }  if (arrayOfByte.length - i1 > 0) {
/*      */ 
/*      */ 
/*      */               
/*  272 */               int i3 = arrayOfByte.length - i1;
/*      */               
/*  274 */               System.arraycopy(arrayOfByte1, 0, arrayOfByte, i1, i3);
/*      */ 
/*      */               
/*  277 */               i1 += i3;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  282 */         if (arrayOfByte1 != arrayOfByte) {
/*  283 */           arrayOfByte1 = null;
/*      */         }
/*  285 */         this.meta[0] = i1;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  290 */     this.tmp[0] = this.meta[0];
/*      */     
/*  292 */     int m = 0;
/*      */     
/*  294 */     if (this.formOfUse == 2) {
/*  295 */       m = this.statement.connection.conversion.NCHARBytesToJavaChars(arrayOfByte, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  308 */       m = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*      */     } 
/*      */ 
/*      */     
/*  312 */     this.rowSpaceChar[k] = (char)(m * 2);
/*      */ 
/*      */ 
/*      */     
/*  316 */     if (!this.underlyingLong) {
/*  317 */       processIndicator(this.meta[0]);
/*      */     }
/*  319 */     if (this.meta[0] == 0) {
/*      */ 
/*      */ 
/*      */       
/*  323 */       this.rowSpaceIndicator[i] = -1;
/*  324 */       this.rowSpaceIndicator[j] = 0;
/*      */     }
/*      */     else {
/*      */       
/*  328 */       this.rowSpaceIndicator[j] = (short)(this.meta[0] * 2);
/*      */ 
/*      */ 
/*      */       
/*  332 */       this.rowSpaceIndicator[i] = 0;
/*      */     } 
/*      */     
/*  335 */     this.lastRowProcessed++;
/*      */     
/*  337 */     return false; }
/*      */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*      */       this.mare.unmarshalUB2();
/*      */       this.mare.unmarshalUB2();
/*      */     } else if (this.statement.connection.versionNumber < 9200) {
/*      */       this.mare.unmarshalSB2();
/*      */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*      */         this.mare.unmarshalSB2(); 
/*      */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*      */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*      */     }  } void copyRow() throws SQLException, IOException { int i;
/*  348 */     if (this.lastRowProcessed == 0) {
/*  349 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*      */     } else {
/*  351 */       i = this.lastRowProcessed - 1;
/*      */     } 
/*      */     
/*  354 */     int j = this.columnIndex + this.lastRowProcessed * this.charLength;
/*  355 */     int k = this.columnIndex + i * this.charLength;
/*  356 */     int m = this.indicatorIndex + this.lastRowProcessed;
/*  357 */     int n = this.indicatorIndex + i;
/*  358 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/*  359 */     int i2 = this.lengthIndex + i;
/*  360 */     short s = this.rowSpaceIndicator[i2];
/*  361 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*      */     
/*  363 */     int i4 = this.metaDataIndex + i * 1;
/*      */ 
/*      */ 
/*      */     
/*  367 */     this.rowSpaceIndicator[i1] = (short)s;
/*  368 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*      */ 
/*      */     
/*  371 */     if (!this.isNullByDescribe)
/*      */     {
/*  373 */       System.arraycopy(this.rowSpaceChar, k, this.rowSpaceChar, j, this.rowSpaceChar[k] / 2 + 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  378 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*      */ 
/*      */ 
/*      */     
/*  382 */     this.lastRowProcessed++; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/*  395 */     int i = this.columnIndex + (paramInt2 - 1) * this.charLength;
/*      */     
/*  397 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.charLength;
/*      */     
/*  399 */     int k = this.indicatorIndex + paramInt2 - 1;
/*  400 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/*  401 */     int n = this.lengthIndex + paramInt2 - 1;
/*  402 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/*  403 */     short s = paramArrayOfshort[i1];
/*      */     
/*  405 */     this.rowSpaceIndicator[n] = (short)s;
/*  406 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*      */ 
/*      */     
/*  409 */     if (s != 0) {
/*      */       
/*  411 */       System.arraycopy(paramArrayOfchar, j, this.rowSpaceChar, i, paramArrayOfchar[j] / 2 + 1);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  416 */       this.rowSpaceChar[i] = Character.MIN_VALUE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void calculateSizeTmpByteArray() {
/*      */     int i;
/*  439 */     if (this.formOfUse == 2) {
/*      */ 
/*      */ 
/*      */       
/*  443 */       i = (this.charLength - 1) * this.statement.connection.conversion.maxNCharSize;
/*      */     }
/*      */     else {
/*      */       
/*  447 */       i = (this.charLength - 1) * this.statement.connection.conversion.cMaxCharSize;
/*      */     } 
/*      */     
/*  450 */     if (this.statement.sizeTmpByteArray < i) {
/*  451 */       this.statement.sizeTmpByteArray = i;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getString(int paramInt) throws SQLException {
/*  464 */     String str = super.getString(paramInt);
/*      */     
/*  466 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*      */     {
/*  468 */       str = str.substring(0, this.definedColumnSize);
/*      */     }
/*  470 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NUMBER getNUMBER(int paramInt) throws SQLException {
/*  480 */     NUMBER nUMBER = null;
/*      */     
/*  482 */     if (this.definedColumnType == 0) {
/*  483 */       nUMBER = super.getNUMBER(paramInt);
/*      */     } else {
/*      */       
/*  486 */       String str = getString(paramInt);
/*  487 */       if (str != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  496 */         return StringToNUMBER(str);
/*      */       }
/*      */     } 
/*      */     
/*  500 */     return nUMBER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DATE getDATE(int paramInt) throws SQLException {
/*  507 */     DATE dATE = null;
/*      */     
/*  509 */     if (this.definedColumnType == 0) {
/*  510 */       dATE = super.getDATE(paramInt);
/*      */     } else {
/*      */       
/*  513 */       Date date = getDate(paramInt);
/*  514 */       if (date != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  523 */         dATE = new DATE(date);
/*      */       }
/*      */     } 
/*      */     
/*  527 */     return dATE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/*  535 */     TIMESTAMP tIMESTAMP = null;
/*      */     
/*  537 */     if (this.definedColumnType == 0) {
/*  538 */       tIMESTAMP = super.getTIMESTAMP(paramInt);
/*      */     } else {
/*      */       
/*  541 */       String str = getString(paramInt);
/*  542 */       if (str != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  552 */         int[] arrayOfInt = new int[1];
/*  553 */         Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*      */ 
/*      */         
/*  556 */         Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
/*  557 */         timestamp.setNanos(arrayOfInt[0]);
/*  558 */         tIMESTAMP = new TIMESTAMP(timestamp);
/*      */       } 
/*      */     } 
/*      */     
/*  562 */     return tIMESTAMP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/*  569 */     TIMESTAMPTZ tIMESTAMPTZ = null;
/*      */     
/*  571 */     if (this.definedColumnType == 0) {
/*  572 */       tIMESTAMPTZ = super.getTIMESTAMPTZ(paramInt);
/*      */     } else {
/*      */       
/*  575 */       String str = getString(paramInt);
/*  576 */       if (str != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  587 */         int[] arrayOfInt = new int[1];
/*  588 */         Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */ 
/*      */         
/*  591 */         Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
/*  592 */         timestamp.setNanos(arrayOfInt[0]);
/*  593 */         tIMESTAMPTZ = new TIMESTAMPTZ((Connection)this.statement.connection, timestamp, calendar);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  599 */     return tIMESTAMPTZ;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/*  606 */     TIMESTAMPLTZ tIMESTAMPLTZ = null;
/*      */     
/*  608 */     if (this.definedColumnType == 0) {
/*  609 */       tIMESTAMPLTZ = super.getTIMESTAMPLTZ(paramInt);
/*      */     } else {
/*      */       
/*  612 */       String str = getString(paramInt);
/*  613 */       if (str != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  624 */         int[] arrayOfInt = new int[1];
/*  625 */         Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */ 
/*      */         
/*  628 */         Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
/*  629 */         timestamp.setNanos(arrayOfInt[0]);
/*  630 */         tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)this.statement.connection, timestamp, calendar);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  636 */     return tIMESTAMPLTZ;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RAW getRAW(int paramInt) throws SQLException {
/*  643 */     RAW rAW = null;
/*      */     
/*  645 */     if (this.definedColumnType == 0) {
/*  646 */       rAW = super.getRAW(paramInt);
/*      */     } else {
/*      */       
/*  649 */       if (this.rowSpaceIndicator == null) {
/*      */ 
/*      */ 
/*      */         
/*  653 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  654 */         sQLException.fillInStackTrace();
/*  655 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  661 */       if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*      */       {
/*  663 */         if (this.definedColumnType == -2 || this.definedColumnType == -3 || this.definedColumnType == -4) {
/*      */ 
/*      */           
/*  666 */           rAW = new RAW(getBytesFromHexChars(paramInt));
/*      */         } else {
/*  668 */           rAW = new RAW(super.getBytes(paramInt));
/*      */         } 
/*      */       }
/*      */     } 
/*  672 */     return rAW;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Datum getOracleObject(int paramInt) throws SQLException {
/*  679 */     if (this.definedColumnType == 0) {
/*  680 */       return super.getOracleObject(paramInt);
/*      */     }
/*      */     
/*  683 */     Datum datum = null;
/*      */     
/*  685 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  687 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  688 */       sQLException.fillInStackTrace();
/*  689 */       throw sQLException;
/*      */     } 
/*      */     
/*  692 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*  694 */       switch (this.definedColumnType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -16:
/*      */         case -15:
/*      */         case -9:
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/*  707 */           return super.getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -7:
/*      */         case -6:
/*      */         case -5:
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*      */         case 8:
/*      */         case 16:
/*  730 */           return (Datum)getNUMBER(paramInt);
/*      */         
/*      */         case 91:
/*  733 */           return (Datum)getDATE(paramInt);
/*      */         
/*      */         case 92:
/*  736 */           return (Datum)getDATE(paramInt);
/*      */         
/*      */         case 93:
/*  739 */           return (Datum)getTIMESTAMP(paramInt);
/*      */         
/*      */         case -101:
/*  742 */           return (Datum)getTIMESTAMPTZ(paramInt);
/*      */         
/*      */         case -102:
/*  745 */           return (Datum)getTIMESTAMPLTZ(paramInt);
/*      */ 
/*      */ 
/*      */         
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/*  752 */           return (Datum)getRAW(paramInt);
/*      */         
/*      */         case -8:
/*  755 */           return (Datum)getROWID(paramInt);
/*      */       } 
/*      */ 
/*      */       
/*  759 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  760 */       sQLException.fillInStackTrace();
/*  761 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  767 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getBytes(int paramInt) throws SQLException {
/*  776 */     if (this.definedColumnType == 0) {
/*  777 */       return super.getBytes(paramInt);
/*      */     }
/*  779 */     Datum datum = getOracleObject(paramInt);
/*  780 */     if (datum != null) {
/*  781 */       return datum.shareBytes();
/*      */     }
/*  783 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getBoolean(int paramInt) throws SQLException {
/*  791 */     boolean bool = false;
/*      */     
/*  793 */     if (this.definedColumnType == 0) {
/*  794 */       bool = super.getBoolean(paramInt);
/*      */     } else {
/*      */       
/*  797 */       bool = getNUMBER(paramInt).booleanValue();
/*      */     } 
/*      */     
/*  800 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte getByte(int paramInt) throws SQLException {
/*  808 */     byte b = 0;
/*      */     
/*  810 */     if (this.definedColumnType == 0) {
/*  811 */       b = super.getByte(paramInt);
/*      */     } else {
/*      */       
/*  814 */       b = getNUMBER(paramInt).byteValue();
/*      */     } 
/*      */     
/*  817 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getInt(int paramInt) throws SQLException {
/*  825 */     int i = 0;
/*      */     
/*  827 */     if (this.definedColumnType == 0) {
/*  828 */       i = super.getInt(paramInt);
/*      */     } else {
/*      */       
/*  831 */       i = getNUMBER(paramInt).intValue();
/*      */     } 
/*      */     
/*  834 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   short getShort(int paramInt) throws SQLException {
/*  842 */     short s = 0;
/*      */     
/*  844 */     if (this.definedColumnType == 0) {
/*  845 */       s = super.getShort(paramInt);
/*      */     } else {
/*      */       
/*  848 */       s = getNUMBER(paramInt).shortValue();
/*      */     } 
/*      */     
/*  851 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getLong(int paramInt) throws SQLException {
/*  859 */     long l = 0L;
/*      */     
/*  861 */     if (this.definedColumnType == 0) {
/*  862 */       l = super.getLong(paramInt);
/*      */     } else {
/*      */       
/*  865 */       l = getNUMBER(paramInt).longValue();
/*      */     } 
/*      */     
/*  868 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float getFloat(int paramInt) throws SQLException {
/*  876 */     float f = 0.0F;
/*      */     
/*  878 */     if (this.definedColumnType == 0) {
/*  879 */       f = super.getFloat(paramInt);
/*      */     } else {
/*      */       
/*  882 */       f = getNUMBER(paramInt).floatValue();
/*      */     } 
/*      */     
/*  885 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double getDouble(int paramInt) throws SQLException {
/*  893 */     double d = 0.0D;
/*      */     
/*  895 */     if (this.definedColumnType == 0) {
/*  896 */       d = super.getDouble(paramInt);
/*      */     } else {
/*      */       
/*  899 */       d = getNUMBER(paramInt).doubleValue();
/*      */     } 
/*      */     
/*  902 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Date getDate(int paramInt) throws SQLException {
/*  912 */     Date date = null;
/*      */     
/*  914 */     if (this.definedColumnType == 0) {
/*  915 */       date = super.getDate(paramInt);
/*      */     } else {
/*      */       
/*  918 */       String str = getString(paramInt);
/*  919 */       if (str != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  928 */         int[] arrayOfInt = new int[1];
/*      */         
/*  930 */         date = new Date(DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), arrayOfInt).getTimeInMillis());
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  936 */     return date;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Timestamp getTimestamp(int paramInt) throws SQLException {
/*  944 */     Timestamp timestamp = null;
/*      */     
/*  946 */     if (this.definedColumnType == 0) {
/*  947 */       timestamp = super.getTimestamp(paramInt);
/*      */     } else {
/*      */       
/*  950 */       String str = getString(paramInt);
/*  951 */       if (str != null) {
/*      */         
/*  953 */         int[] arrayOfInt = new int[1];
/*  954 */         Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*      */ 
/*      */         
/*  957 */         timestamp = new Timestamp(calendar.getTimeInMillis());
/*  958 */         timestamp.setNanos(arrayOfInt[0]);
/*      */       } 
/*      */     } 
/*      */     
/*  962 */     return timestamp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Time getTime(int paramInt) throws SQLException {
/*  970 */     Time time = null;
/*      */     
/*  972 */     if (this.definedColumnType == 0) {
/*  973 */       time = super.getTime(paramInt);
/*      */     } else {
/*      */       
/*  976 */       String str = getString(paramInt);
/*  977 */       if (str != null) {
/*      */         
/*  979 */         int[] arrayOfInt = new int[1];
/*  980 */         Calendar calendar = DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*      */ 
/*      */         
/*  983 */         time = new Time(calendar.getTimeInMillis());
/*      */       } 
/*      */     } 
/*      */     
/*  987 */     return time;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt) throws SQLException {
/*  996 */     if (this.definedColumnType == 0) {
/*  997 */       return super.getObject(paramInt);
/*      */     }
/*      */     
/* 1000 */     Object object = null;
/*      */     
/* 1002 */     if (this.rowSpaceIndicator == null) {
/*      */       
/* 1004 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1005 */       sQLException.fillInStackTrace();
/* 1006 */       throw sQLException;
/*      */     } 
/*      */     
/* 1009 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/* 1011 */       switch (this.definedColumnType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -16:
/*      */         case -15:
/*      */         case -9:
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/* 1024 */           return getString(paramInt);
/*      */ 
/*      */         
/*      */         case 2:
/*      */         case 3:
/* 1029 */           return getBigDecimal(paramInt);
/*      */         
/*      */         case 4:
/* 1032 */           return Integer.valueOf(getInt(paramInt));
/*      */         
/*      */         case -6:
/* 1035 */           return Byte.valueOf(getByte(paramInt));
/*      */         
/*      */         case 5:
/* 1038 */           return Short.valueOf(getShort(paramInt));
/*      */ 
/*      */         
/*      */         case -7:
/*      */         case 16:
/* 1043 */           return Boolean.valueOf(getBoolean(paramInt));
/*      */         
/*      */         case -5:
/* 1046 */           return Long.valueOf(getLong(paramInt));
/*      */         
/*      */         case 7:
/* 1049 */           return Float.valueOf(getFloat(paramInt));
/*      */ 
/*      */         
/*      */         case 6:
/*      */         case 8:
/* 1054 */           return Double.valueOf(getDouble(paramInt));
/*      */         
/*      */         case 91:
/* 1057 */           return getDate(paramInt);
/*      */         
/*      */         case 92:
/* 1060 */           return getTime(paramInt);
/*      */         
/*      */         case 93:
/* 1063 */           return getTimestamp(paramInt);
/*      */         
/*      */         case -101:
/* 1066 */           return getTIMESTAMPTZ(paramInt);
/*      */         
/*      */         case -102:
/* 1069 */           return getTIMESTAMPLTZ(paramInt);
/*      */ 
/*      */ 
/*      */         
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/* 1076 */           return getBytesFromHexChars(paramInt);
/*      */         
/*      */         case -8:
/* 1079 */           return getROWID(paramInt);
/*      */       } 
/*      */ 
/*      */       
/* 1083 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 1084 */       sQLException.fillInStackTrace();
/* 1085 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1091 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final NUMBER StringToNUMBER(String paramString) throws SQLException {
/* 1100 */     return new NUMBER(new BigDecimal(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Calendar DATEStringToCalendar(String paramString1, String paramString2, int[] paramArrayOfint) throws SQLException {
/* 1129 */     char[] arrayOfChar = (paramString2 + " ").toCharArray();
/* 1130 */     paramString1 = paramString1 + " ";
/*      */ 
/*      */     
/* 1133 */     int i = Math.min(paramString1.length(), arrayOfChar.length);
/*      */     
/* 1135 */     byte b1 = -1;
/* 1136 */     byte b2 = -1;
/*      */     
/* 1138 */     byte b3 = 0;
/* 1139 */     byte b4 = 0;
/*      */     
/* 1141 */     int j = 0;
/* 1142 */     int k = 0;
/*      */     
/* 1144 */     int m = 0;
/* 1145 */     int n = 0;
/* 1146 */     int i1 = 0;
/*      */     
/* 1148 */     int i2 = 0;
/* 1149 */     int i3 = 0;
/* 1150 */     int i4 = 0;
/* 1151 */     int i5 = 0;
/*      */     
/* 1153 */     String str1 = null;
/* 1154 */     String str2 = null;
/*      */     
/* 1156 */     boolean bool = false;
/*      */ 
/*      */     
/* 1159 */     String[] arrayOfString1 = null;
/* 1160 */     String[] arrayOfString2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1178 */     for (byte b5 = 0; b5 < i; b5++) {
/*      */       
/* 1180 */       switch (arrayOfChar[b5]) {
/*      */         
/*      */         case 'R':
/*      */         case 'r':
/* 1184 */           if (b1 != 6) {
/*      */             
/* 1186 */             b1 = 6;
/* 1187 */             b3 = b5;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'Y':
/*      */         case 'y':
/* 1193 */           if (b1 != 5) {
/*      */             
/* 1195 */             b1 = 5;
/* 1196 */             b3 = b5;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'D':
/*      */         case 'd':
/* 1202 */           if (b1 != 1) {
/*      */             
/* 1204 */             b1 = 1;
/* 1205 */             b3 = b5;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'M':
/*      */         case 'm':
/* 1211 */           if (b1 != 2 || b1 != 4 || b1 != 3 || b1 != 9) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1217 */             b3 = b5;
/*      */             
/* 1219 */             if (b5 + 4 < i && (arrayOfChar[b5 + 1] == 'O' || arrayOfChar[b5 + 1] == 'o') && (arrayOfChar[b5 + 2] == 'N' || arrayOfChar[b5 + 2] == 'n') && (arrayOfChar[b5 + 3] == 'T' || arrayOfChar[b5 + 3] == 't') && (arrayOfChar[b5 + 4] == 'H' || arrayOfChar[b5 + 4] == 'h')) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1225 */               b1 = 3;
/* 1226 */               b5 += 4; break;
/* 1227 */             }  if (b5 + 2 < i && (arrayOfChar[b5 + 1] == 'O' || arrayOfChar[b5 + 1] == 'o') && (arrayOfChar[b5 + 2] == 'N' || arrayOfChar[b5 + 2] == 'n')) {
/*      */ 
/*      */ 
/*      */               
/* 1231 */               b1 = 4;
/* 1232 */               b5 += 2; break;
/* 1233 */             }  if (b5 + 1 < i && (arrayOfChar[b5 + 1] == 'M' || arrayOfChar[b5 + 1] == 'm')) {
/*      */ 
/*      */               
/* 1236 */               b1 = 2;
/* 1237 */               b5++; break;
/* 1238 */             }  if (b5 + 1 < i && (arrayOfChar[b5 + 1] == 'I' || arrayOfChar[b5 + 1] == 'i')) {
/*      */ 
/*      */               
/* 1241 */               b1 = 9;
/* 1242 */               b5++;
/*      */             } 
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 'H':
/*      */         case 'h':
/* 1251 */           if (b1 != 7) {
/*      */             
/* 1253 */             b1 = 7;
/* 1254 */             b3 = b5; break;
/* 1255 */           }  if (b5 + 2 < i && (arrayOfChar[b5 + 1] == '2' || arrayOfChar[b5 + 4] == '4')) {
/*      */ 
/*      */             
/* 1258 */             b1 = 8;
/* 1259 */             b5 += 2;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'S':
/*      */         case 's':
/* 1265 */           if (b5 + 1 < i && (arrayOfChar[b5 + 1] == 'S' || arrayOfChar[b5 + 1] == 's')) {
/*      */ 
/*      */             
/* 1268 */             b1 = 10;
/* 1269 */             b3 = b5;
/* 1270 */             b5++;
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 'F':
/*      */         case 'f':
/* 1277 */           if (b1 != 11) {
/*      */             
/* 1279 */             b1 = 11;
/* 1280 */             b3 = b5;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'A':
/*      */         case 'a':
/* 1286 */           if (b5 + 1 < i && (arrayOfChar[b5 + 1] == 'M' || arrayOfChar[b5 + 1] == 'm')) {
/*      */ 
/*      */             
/* 1289 */             b1 = 12;
/* 1290 */             b3 = b5;
/* 1291 */             b5++;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 'T':
/*      */         case 't':
/* 1297 */           if (b5 + 2 < i && (arrayOfChar[b5 + 1] == 'Z' || arrayOfChar[b5 + 1] == 'z') && (arrayOfChar[b5 + 2] == 'R' || arrayOfChar[b5 + 2] == 'r')) {
/*      */ 
/*      */ 
/*      */             
/* 1301 */             b1 = 13;
/* 1302 */             b3 = b5;
/* 1303 */             b5 += 2;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 1310 */           bool = true;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1321 */       if (bool && b1 != -1) {
/*      */         int i8, i10; String str3; int i9; String str4;
/* 1323 */         int i6 = b5 - b3;
/* 1324 */         int i7 = b3 - b4;
/* 1325 */         j = k + i7;
/*      */         
/* 1327 */         k = j + i6;
/* 1328 */         switch (b1) {
/*      */           
/*      */           case 1:
/* 1331 */             m = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */           
/*      */           case 2:
/* 1335 */             n = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 3:
/* 1341 */             i10 = j;
/* 1342 */             k = j;
/* 1343 */             for (i10 = j; i10 < paramString1.length() && 
/* 1344 */               paramString1.charAt(i10) != arrayOfChar[b5]; i10++);
/*      */             
/* 1346 */             k = i10;
/*      */             
/* 1348 */             str4 = null;
/* 1349 */             if (k != j) {
/* 1350 */               str4 = paramString1.substring(j, k);
/*      */ 
/*      */ 
/*      */               
/* 1354 */               str4 = str4.trim();
/*      */               
/* 1356 */               if (arrayOfString2 == null)
/* 1357 */                 arrayOfString2 = (new DateFormatSymbols()).getMonths(); 
/* 1358 */               for (n = 0; n < arrayOfString2.length && 
/* 1359 */                 !str4.equalsIgnoreCase(arrayOfString2[n]); n++);
/*      */ 
/*      */               
/* 1362 */               if (n >= 12) {
/*      */                 
/* 1364 */                 SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 59);
/* 1365 */                 sQLException.fillInStackTrace();
/* 1366 */                 throw sQLException;
/*      */               } 
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 4:
/* 1378 */             i8 = j;
/* 1379 */             k = j;
/* 1380 */             for (i8 = j; i8 < paramString1.length() && 
/* 1381 */               paramString1.charAt(i8) != arrayOfChar[b5]; i8++);
/*      */             
/* 1383 */             k = i8;
/*      */             
/* 1385 */             str3 = null;
/* 1386 */             if (k != j) {
/* 1387 */               str3 = paramString1.substring(j, k);
/*      */ 
/*      */ 
/*      */               
/* 1391 */               str3 = str3.trim();
/*      */               
/* 1393 */               if (arrayOfString1 == null)
/* 1394 */                 arrayOfString1 = (new DateFormatSymbols()).getShortMonths(); 
/* 1395 */               for (n = 0; n < arrayOfString1.length && 
/* 1396 */                 !str3.equalsIgnoreCase(arrayOfString1[n]); n++);
/*      */ 
/*      */               
/* 1399 */               if (n >= 12) {
/*      */                 
/* 1401 */                 SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 59);
/* 1402 */                 sQLException.fillInStackTrace();
/* 1403 */                 throw sQLException;
/*      */               } 
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 5:
/* 1415 */             i1 = Integer.parseInt(paramString1.substring(j, k));
/*      */ 
/*      */ 
/*      */             
/* 1419 */             if (i6 == 2) {
/* 1420 */               i1 += 2000;
/*      */             }
/*      */             break;
/*      */           case 6:
/* 1424 */             i1 = Integer.parseInt(paramString1.substring(j, k));
/*      */ 
/*      */ 
/*      */             
/* 1428 */             if (i6 == 2 && i1 < 50) {
/* 1429 */               i1 += 2000; break;
/*      */             } 
/* 1431 */             i1 += 1900;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 7:
/*      */           case 8:
/* 1438 */             k = j + 2;
/* 1439 */             i2 = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */           
/*      */           case 9:
/* 1443 */             i3 = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */           
/*      */           case 10:
/* 1447 */             i4 = Integer.parseInt(paramString1.substring(j, k));
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 11:
/* 1457 */             i9 = j;
/* 1458 */             k = j;
/* 1459 */             for (i9 = j; i9 < paramString1.length() && (
/* 1460 */               i8 = paramString1.charAt(i9)) >= 48 && i8 <= 57; i9++);
/*      */             
/* 1462 */             k += i9 - j;
/*      */             
/* 1464 */             if (k != j) {
/* 1465 */               i5 = Integer.parseInt(paramString1.substring(j, k));
/*      */             }
/*      */             break;
/*      */           case 12:
/* 1469 */             if (k > 0) {
/* 1470 */               str1 = paramString1.substring(j, k);
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 13:
/* 1480 */             i9 = j;
/* 1481 */             k = j;
/* 1482 */             for (i9 = j; i9 < paramString1.length() && (((
/* 1483 */               i8 = paramString1.charAt(i9)) >= 48 && i8 <= 57) || (i8 >= 97 && i8 <= 122) || (i8 >= 65 && i8 <= 90)); i9++)
/*      */             {
/*      */ 
/*      */ 
/*      */               
/* 1488 */               k = i9;
/*      */             }
/* 1490 */             if (k != j) {
/* 1491 */               str2 = paramString1.substring(j, k);
/*      */             }
/*      */             break;
/*      */           
/*      */           default:
/* 1496 */             System.out.println("\n\n\n             ***** ERROR(1) ****\n");
/*      */             break;
/*      */         } 
/*      */         
/* 1500 */         b4 = b5;
/* 1501 */         b1 = -1;
/* 1502 */         bool = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1509 */     GregorianCalendar gregorianCalendar = new GregorianCalendar(i1, n, m, i2, i3, i4);
/* 1510 */     if (str1 != null) {
/* 1511 */       gregorianCalendar.set(9, str1.equalsIgnoreCase("AM") ? 0 : 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1516 */     if (str2 != null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1522 */     if (i5 != 0) {
/* 1523 */       paramArrayOfint[0] = i5;
/*      */     }
/* 1525 */     return gregorianCalendar;
/*      */   }
/*      */ 
/*      */   
/* 1529 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CVarcharAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */