/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.EnumSet;
/*     */ import oracle.jdbc.dcn.RowChangeDescription;
/*     */ import oracle.jdbc.dcn.TableChangeDescription;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFDCNTableChanges
/*     */   implements TableChangeDescription
/*     */ {
/*     */   final EnumSet<TableChangeDescription.TableOperation> opcode;
/*     */   String tableName;
/*     */   final int objectNumber;
/*     */   final int numberOfRows;
/*     */   final RowChangeDescription.RowOperation[] rowOpcode;
/*     */   final int[] rowIdLength;
/*     */   final byte[][] rowid;
/*     */   final CharacterSet charset;
/*  46 */   NTFDCNRowChanges[] rowsDescription = null;
/*     */   
/*     */   private static final byte OPERATION_ANY = 0;
/*     */   
/*     */   private static final byte OPERATION_UNKNOWN = 64;
/*     */ 
/*     */   
/*     */   NTFDCNTableChanges(ByteBuffer paramByteBuffer, int paramInt) {
/*  54 */     this.charset = CharacterSet.make(paramInt);
/*  55 */     this.opcode = TableChangeDescription.TableOperation.getTableOperations(paramByteBuffer.getInt());
/*  56 */     short s = paramByteBuffer.getShort();
/*  57 */     byte[] arrayOfByte = new byte[s];
/*  58 */     paramByteBuffer.get(arrayOfByte, 0, s);
/*  59 */     this.tableName = this.charset.toStringWithReplacement(arrayOfByte, 0, s);
/*     */ 
/*     */     
/*  62 */     this.objectNumber = paramByteBuffer.getInt();
/*  63 */     if (!this.opcode.contains(TableChangeDescription.TableOperation.ALL_ROWS)) {
/*     */       
/*  65 */       this.numberOfRows = paramByteBuffer.getShort();
/*  66 */       this.rowOpcode = new RowChangeDescription.RowOperation[this.numberOfRows];
/*  67 */       this.rowIdLength = new int[this.numberOfRows];
/*  68 */       this.rowid = new byte[this.numberOfRows][];
/*  69 */       for (byte b = 0; b < this.numberOfRows; b++)
/*     */       {
/*  71 */         this.rowOpcode[b] = RowChangeDescription.RowOperation.getRowOperation(paramByteBuffer.getInt());
/*  72 */         this.rowIdLength[b] = paramByteBuffer.getShort();
/*  73 */         this.rowid[b] = new byte[this.rowIdLength[b]];
/*  74 */         paramByteBuffer.get(this.rowid[b], 0, this.rowIdLength[b]);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  79 */       this.numberOfRows = 0;
/*  80 */       this.rowid = (byte[][])null;
/*  81 */       this.rowOpcode = null;
/*  82 */       this.rowIdLength = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTableName() {
/*  90 */     return this.tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getObjectNumber() {
/*  96 */     return this.objectNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RowChangeDescription[] getRowChangeDescription() {
/* 102 */     if (this.rowsDescription == null)
/*     */     {
/* 104 */       synchronized (this) {
/*     */         
/* 106 */         if (this.rowsDescription == null) {
/*     */           
/* 108 */           this.rowsDescription = new NTFDCNRowChanges[this.numberOfRows];
/* 109 */           for (byte b = 0; b < this.rowsDescription.length; b++)
/* 110 */             this.rowsDescription[b] = new NTFDCNRowChanges(this.rowOpcode[b], this.rowIdLength[b], this.rowid[b]); 
/*     */         } 
/*     */       } 
/*     */     }
/* 114 */     return (RowChangeDescription[])this.rowsDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<TableChangeDescription.TableOperation> getTableOperations() {
/* 120 */     return this.opcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 131 */     StringBuffer stringBuffer = new StringBuffer();
/* 132 */     stringBuffer.append("    operation=" + getTableOperations() + ", tableName=" + this.tableName + ", objectNumber=" + this.objectNumber + "\n");
/* 133 */     RowChangeDescription[] arrayOfRowChangeDescription = getRowChangeDescription();
/* 134 */     if (arrayOfRowChangeDescription != null && arrayOfRowChangeDescription.length > 0) {
/*     */       
/* 136 */       stringBuffer.append("    Row Change Description (length=" + arrayOfRowChangeDescription.length + "):\n");
/* 137 */       for (byte b = 0; b < arrayOfRowChangeDescription.length; b++)
/* 138 */         stringBuffer.append(arrayOfRowChangeDescription[b].toString()); 
/*     */     } 
/* 140 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 144 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NTFDCNTableChanges.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */