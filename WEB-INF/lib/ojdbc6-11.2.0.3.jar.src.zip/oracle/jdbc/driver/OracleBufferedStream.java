/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class OracleBufferedStream
/*     */   extends InputStream
/*     */ {
/*     */   byte[] resizableBuffer;
/*     */   int initialBufferSize;
/*     */   int currentBufferSize;
/*     */   int pos;
/*     */   int count;
/*  30 */   long maxPosition = 2147483647L;
/*     */   
/*     */   boolean closed;
/*     */   
/*     */   OracleStatement statement;
/*     */   
/*     */   public OracleBufferedStream(int paramInt) {
/*  37 */     this.pos = 0;
/*  38 */     this.count = 0;
/*  39 */     this.closed = false;
/*  40 */     this.initialBufferSize = paramInt;
/*  41 */     this.currentBufferSize = 0;
/*  42 */     this.resizableBuffer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBufferedStream(OracleStatement paramOracleStatement, int paramInt) {
/*  48 */     this(paramInt);
/*     */ 
/*     */     
/*  51 */     this.statement = paramOracleStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  60 */     this.closed = true;
/*  61 */     this.resizableBuffer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needBytes() throws IOException {
/*  68 */     return needBytes(Math.max(this.initialBufferSize, this.currentBufferSize));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean needBytes(int paramInt) throws IOException;
/*     */ 
/*     */   
/*     */   public int flushBytes(int paramInt) {
/*  77 */     int i = (paramInt > this.count - this.pos) ? (this.count - this.pos) : paramInt;
/*     */     
/*  79 */     this.pos += i;
/*     */     
/*  81 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  88 */     int i = (paramInt2 > this.count - this.pos) ? (this.count - this.pos) : paramInt2;
/*     */     
/*  90 */     System.arraycopy(this.resizableBuffer, this.pos, paramArrayOfbyte, paramInt1, i);
/*     */     
/*  92 */     this.pos += i;
/*     */     
/*  94 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 101 */     if (this.statement == null)
/*     */     {
/* 103 */       synchronized (this) {
/* 104 */         return readInternal();
/*     */       } 
/*     */     }
/*     */     
/* 108 */     synchronized (this.statement.connection) {
/* 109 */       return readInternal();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int readInternal() throws IOException {
/* 119 */     if (this.closed || isNull()) {
/* 120 */       return -1;
/*     */     }
/* 122 */     if (needBytes()) {
/* 123 */       return this.resizableBuffer[this.pos++] & 0xFF;
/*     */     }
/* 125 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfbyte) throws IOException {
/* 132 */     return read(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 140 */     if (this.statement == null)
/*     */     {
/* 142 */       synchronized (this) {
/* 143 */         return readInternal(paramArrayOfbyte, paramInt1, paramInt2);
/*     */       } 
/*     */     }
/*     */     
/* 147 */     synchronized (this.statement.connection) {
/* 148 */       return readInternal(paramArrayOfbyte, paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int readInternal(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 159 */     int i, j = paramInt1;
/*     */     
/* 161 */     if (this.closed || isNull()) {
/* 162 */       return -1;
/*     */     }
/* 164 */     if (paramInt2 > paramArrayOfbyte.length) {
/* 165 */       i = j + paramArrayOfbyte.length;
/*     */     } else {
/* 167 */       i = j + paramInt2;
/*     */     } 
/* 169 */     if (!needBytes(paramInt2)) {
/* 170 */       return -1;
/*     */     }
/* 172 */     j += writeBytes(paramArrayOfbyte, j, i - j);
/*     */     
/* 174 */     while (j < i && needBytes(i - j))
/*     */     {
/* 176 */       j += writeBytes(paramArrayOfbyte, j, i - j);
/*     */     }
/*     */     
/* 179 */     return j - paramInt1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 186 */     if (this.closed || isNull()) {
/* 187 */       return 0;
/*     */     }
/* 189 */     return this.count - this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNull() throws IOException {
/* 196 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 207 */     synchronized (this.statement.connection) {
/*     */       
/* 209 */       throw new IOException(DatabaseError.findMessage(194, null));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 217 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(int paramInt) throws IOException {
/* 230 */     if (this.statement == null)
/*     */     {
/* 232 */       synchronized (this) {
/* 233 */         return skipInternal(paramInt);
/*     */       } 
/*     */     }
/*     */     
/* 237 */     synchronized (this.statement.connection) {
/* 238 */       return skipInternal(paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int skipInternal(int paramInt) throws IOException {
/* 247 */     int i = 0;
/* 248 */     int j = paramInt;
/*     */     
/* 250 */     if (this.closed || isNull()) {
/* 251 */       return -1;
/*     */     }
/* 253 */     if (!needBytes()) {
/* 254 */       return -1;
/*     */     }
/* 256 */     while (i < j && needBytes())
/*     */     {
/* 258 */       i += flushBytes(j - i);
/*     */     }
/*     */     
/* 261 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 276 */     return this.statement.getConnectionDuringExceptionHandling();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleBufferedStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */