/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.text.DateFormatSymbols;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTimestampltzAccessor
/*     */   extends TimestampltzAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   final int[] meta;
/*     */   
/*     */   T4CTimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  46 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CTimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       this.definedColumnType = 0;
/*     */       this.definedColumnSize = 0;
/*     */     } else {
/*     */       this.definedColumnType = paramInt7;
/*     */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     if (paramInt1 == -1) {
/*     */       this.underlyingLongRaw = true;
/*     */     } }
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 125 */     if (this.isUseLess) {
/*     */       
/* 127 */       this.lastRowProcessed++;
/*     */       
/* 129 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 138 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 140 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 141 */       processIndicator(this.meta[0]);
/*     */       
/* 143 */       this.lastRowProcessed++;
/*     */       
/* 145 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 150 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 154 */     if (this.isNullByDescribe) {
/*     */       
/* 156 */       this.rowSpaceIndicator[i] = -1;
/* 157 */       this.rowSpaceIndicator[j] = 0;
/* 158 */       this.lastRowProcessed++;
/*     */       
/* 160 */       if (this.statement.connection.versionNumber < 9200) {
/* 161 */         processIndicator(0);
/*     */       }
/* 163 */       return false;
/*     */     } 
/*     */     
/* 166 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */ 
/*     */ 
/*     */     
/* 170 */     this.mare.unmarshalCLR(this.rowSpaceByte, k, this.meta, this.byteLength);
/*     */     
/* 172 */     processIndicator(this.meta[0]);
/*     */     
/* 174 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 178 */       this.rowSpaceIndicator[i] = -1;
/* 179 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 183 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/* 184 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 187 */     this.lastRowProcessed++;
/*     */     
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/*     */     int i;
/* 199 */     if (this.lastRowProcessed == 0) {
/* 200 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 202 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 205 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 206 */     int k = this.columnIndex + i * this.byteLength;
/* 207 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 208 */     int n = this.indicatorIndex + i;
/* 209 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 210 */     int i2 = this.lengthIndex + i;
/* 211 */     short s = this.rowSpaceIndicator[i2];
/* 212 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 214 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 218 */     this.rowSpaceIndicator[i1] = (short)s;
/* 219 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 222 */     if (!this.isNullByDescribe)
/*     */     {
/* 224 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 229 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 232 */     this.lastRowProcessed++; } void processIndicator(int paramInt) throws IOException, SQLException {
/*     */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   } void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 244 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 246 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 248 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 249 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 250 */     int n = this.lengthIndex + paramInt2 - 1;
/* 251 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 252 */     short s = paramArrayOfshort[i1];
/*     */     
/* 254 */     this.rowSpaceIndicator[n] = (short)s;
/* 255 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 258 */     if (s != 0)
/*     */     {
/* 260 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 278 */     String str = super.getString(paramInt);
/*     */     
/* 280 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */     {
/* 282 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 284 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString) throws SQLException {
/* 308 */     if (this.definedColumnType == 0 || this.definedColumnType == -102)
/*     */     {
/*     */       
/* 311 */       return super.toText(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramString);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     String str = (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM");
/* 320 */     return nlsFormatToText(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramString, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String nlsFormatToText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString1, String paramString2) throws SQLException {
/* 346 */     char[] arrayOfChar = (paramString2 + "      ").toCharArray();
/* 347 */     int i = paramString2.length();
/*     */     
/* 349 */     StringBuffer stringBuffer = new StringBuffer(i + 25);
/* 350 */     String[] arrayOfString1 = null;
/* 351 */     String[] arrayOfString2 = null;
/* 352 */     TimeZone timeZone = null;
/*     */ 
/*     */     
/* 355 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 357 */       switch (arrayOfChar[b]) {
/*     */         
/*     */         case 'R':
/*     */         case 'r':
/* 361 */           if (arrayOfChar[b + 1] == 'R' || arrayOfChar[b + 1] == 'r') {
/*     */             
/* 363 */             if ((arrayOfChar[b + 2] == 'R' || arrayOfChar[b + 2] == 'r') && (arrayOfChar[b + 3] == 'R' || arrayOfChar[b + 3] == 'r')) {
/*     */ 
/*     */               
/* 366 */               if (paramInt1 < 1000) {
/* 367 */                 stringBuffer.append("0" + paramInt1);
/* 368 */               } else if (paramInt1 < 100) {
/* 369 */                 stringBuffer.append("00" + paramInt1);
/* 370 */               } else if (paramInt1 < 10) {
/* 371 */                 stringBuffer.append("000" + paramInt1);
/*     */               } else {
/* 373 */                 stringBuffer.append(paramInt1);
/*     */               } 
/* 375 */               b += 3;
/*     */               
/*     */               break;
/*     */             } 
/* 379 */             if (paramInt1 >= 100) {
/* 380 */               paramInt1 %= 100;
/*     */             }
/* 382 */             if (paramInt1 < 10) {
/* 383 */               stringBuffer.append("0" + paramInt1);
/*     */             } else {
/* 385 */               stringBuffer.append(paramInt1);
/*     */             } 
/* 387 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'Y':
/*     */         case 'y':
/* 394 */           if (arrayOfChar[b + 1] == 'Y' || arrayOfChar[b + 1] == 'y') {
/*     */             
/* 396 */             if ((arrayOfChar[b + 2] == 'Y' || arrayOfChar[b + 2] == 'y') && (arrayOfChar[b + 3] == 'Y' || arrayOfChar[b + 3] == 'y')) {
/*     */ 
/*     */               
/* 399 */               if (paramInt1 < 1000) {
/* 400 */                 stringBuffer.append("0" + paramInt1);
/* 401 */               } else if (paramInt1 < 100) {
/* 402 */                 stringBuffer.append("00" + paramInt1);
/* 403 */               } else if (paramInt1 < 10) {
/* 404 */                 stringBuffer.append("000" + paramInt1);
/*     */               } else {
/* 406 */                 stringBuffer.append(paramInt1);
/*     */               } 
/* 408 */               b += 3;
/*     */               
/*     */               break;
/*     */             } 
/* 412 */             if (paramInt1 >= 100) {
/* 413 */               paramInt1 %= 100;
/*     */             }
/* 415 */             if (paramInt1 < 10) {
/* 416 */               stringBuffer.append("0" + paramInt1);
/*     */             } else {
/* 418 */               stringBuffer.append(paramInt1);
/*     */             } 
/* 420 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'D':
/*     */         case 'd':
/* 427 */           if (arrayOfChar[b + 1] == 'D' || arrayOfChar[b + 1] == 'd') {
/*     */             
/* 429 */             stringBuffer.append(((paramInt3 < 10) ? "0" : "") + paramInt3);
/* 430 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'M':
/*     */         case 'm':
/* 436 */           if (arrayOfChar[b + 1] == 'M' || arrayOfChar[b + 1] == 'm') {
/*     */             
/* 438 */             stringBuffer.append(((paramInt2 < 10) ? "0" : "") + paramInt2);
/* 439 */             b++; break;
/*     */           } 
/* 441 */           if (arrayOfChar[b + 1] == 'I' || arrayOfChar[b + 1] == 'i') {
/*     */             
/* 443 */             stringBuffer.append(((paramInt5 < 10) ? "0" : "") + paramInt5);
/* 444 */             b++; break;
/*     */           } 
/* 446 */           if ((arrayOfChar[b + 1] == 'O' || arrayOfChar[b + 1] == 'o') && (arrayOfChar[b + 2] == 'N' || arrayOfChar[b + 2] == 'n')) {
/*     */ 
/*     */             
/* 449 */             if ((arrayOfChar[b + 3] == 'T' || arrayOfChar[b + 3] == 't') && (arrayOfChar[b + 4] == 'H' || arrayOfChar[b + 4] == 'h')) {
/*     */ 
/*     */ 
/*     */               
/* 453 */               if (arrayOfString2 == null) {
/* 454 */                 arrayOfString2 = (new DateFormatSymbols()).getMonths();
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 461 */               if (arrayOfChar[b] == 'm') {
/*     */ 
/*     */                 
/* 464 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1].toLowerCase());
/*     */               }
/* 466 */               else if (arrayOfChar[b + 1] == 'O') {
/*     */ 
/*     */                 
/* 469 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1].toUpperCase());
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 474 */                 stringBuffer.append(arrayOfString2[paramInt2 - 1]);
/*     */               } 
/* 476 */               b += 4;
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/* 481 */             if (arrayOfString1 == null) {
/* 482 */               arrayOfString1 = (new DateFormatSymbols()).getShortMonths();
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 489 */             if (arrayOfChar[b] == 'm') {
/*     */ 
/*     */               
/* 492 */               stringBuffer.append(arrayOfString1[paramInt2 - 1].toLowerCase());
/*     */             }
/* 494 */             else if (arrayOfChar[b + 1] == 'O') {
/*     */ 
/*     */               
/* 497 */               stringBuffer.append(arrayOfString1[paramInt2 - 1].toUpperCase());
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 502 */               stringBuffer.append(arrayOfString1[paramInt2 - 1]);
/*     */             } 
/* 504 */             b += 2;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'H':
/*     */         case 'h':
/* 511 */           if (arrayOfChar[b + 1] == 'H' || arrayOfChar[b + 1] == 'h') {
/*     */             
/* 513 */             if (arrayOfChar[b + 2] == '2' || arrayOfChar[b + 3] == '4') {
/*     */               
/* 515 */               stringBuffer.append(((paramInt4 < 10) ? "0" : "") + paramInt4);
/* 516 */               b += 3;
/*     */               break;
/*     */             } 
/* 519 */             if (paramInt4 > 12)
/* 520 */               paramInt4 -= 12; 
/* 521 */             stringBuffer.append(((paramInt4 < 10) ? "0" : "") + paramInt4);
/* 522 */             b++;
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'S':
/*     */         case 's':
/* 529 */           if (arrayOfChar[b + 1] == 'S' || arrayOfChar[b + 1] == 's') {
/*     */             
/* 531 */             stringBuffer.append(((paramInt6 < 10) ? "0" : "") + paramInt6);
/* 532 */             b++;
/* 533 */             if ((arrayOfChar[b + 1] == 'X' || arrayOfChar[b + 1] == 'x') && (arrayOfChar[b + 2] == 'F' || arrayOfChar[b + 2] == 'f') && (arrayOfChar[b + 3] == 'F' || arrayOfChar[b + 3] == 'f')) {
/*     */ 
/*     */ 
/*     */               
/* 537 */               stringBuffer.append(".");
/* 538 */               b++;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */ 
/*     */         
/*     */         case 'F':
/*     */         case 'f':
/* 546 */           if (arrayOfChar[b + 1] == 'F' || arrayOfChar[b + 1] == 'f') {
/*     */             
/* 548 */             if (paramInt7 >= 0) {
/*     */               
/* 550 */               stringBuffer.append(paramInt7);
/*     */             }
/*     */             else {
/*     */               
/* 554 */               stringBuffer.append(0);
/*     */             } 
/* 556 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'T':
/*     */         case 't':
/* 562 */           if (arrayOfChar[b + 1] == 'Z' || arrayOfChar[b + 1] == 'z') {
/*     */             
/* 564 */             if (arrayOfChar[b + 2] == 'R' || arrayOfChar[b + 2] == 'r') {
/*     */               
/* 566 */               if (paramString1.length() > 3 && paramString1.startsWith("GMT")) {
/*     */                 
/* 568 */                 stringBuffer.append(paramString1.substring(3));
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 573 */                 stringBuffer.append(paramString1.toUpperCase());
/*     */               } 
/* 575 */               b += 2; break;
/* 576 */             }  if (arrayOfChar[b + 2] == 'H' || arrayOfChar[b + 2] == 'h') {
/*     */               
/* 578 */               if (timeZone == null)
/* 579 */                 timeZone = TimeZone.getTimeZone(paramString1); 
/* 580 */               long l = (timeZone.getRawOffset() / 3600000);
/* 581 */               stringBuffer.append(l);
/* 582 */               b += 2; break;
/* 583 */             }  if (arrayOfChar[b + 2] == 'M' || arrayOfChar[b + 2] == 'm') {
/*     */               
/* 585 */               if (timeZone == null)
/* 586 */                 timeZone = TimeZone.getTimeZone(paramString1); 
/* 587 */               long l = (Math.abs(timeZone.getRawOffset()) % 3600000 / 60000);
/* 588 */               stringBuffer.append(((l < 10L) ? "0" : "") + l);
/* 589 */               b += 2;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 'A':
/*     */         case 'P':
/*     */         case 'a':
/*     */         case 'p':
/* 598 */           if (arrayOfChar[b + 1] == 'M' || arrayOfChar[b + 1] == 'm') {
/*     */             
/* 600 */             stringBuffer.append(paramBoolean ? "AM" : "PM");
/* 601 */             b++;
/*     */           } 
/*     */           break;
/*     */         
/*     */         default:
/* 606 */           stringBuffer.append(arrayOfChar[b]);
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 612 */     return stringBuffer.substring(0, stringBuffer.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 622 */     if (this.definedColumnType == 0) {
/* 623 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 626 */     Object object = null;
/*     */     
/* 628 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 630 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 631 */       sQLException.fillInStackTrace();
/* 632 */       throw sQLException;
/*     */     } 
/*     */     
/* 635 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 637 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -15:
/*     */         case -9:
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 651 */           return getString(paramInt);
/*     */         
/*     */         case 93:
/* 654 */           return getTimestamp(paramInt);
/*     */         
/*     */         case -102:
/* 657 */           return getTIMESTAMPLTZ(paramInt);
/*     */         
/*     */         case 91:
/* 660 */           return getDate(paramInt);
/*     */         
/*     */         case 92:
/* 663 */           return getTime(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 670 */           return getBytes(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 674 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 675 */       sQLException.fillInStackTrace();
/* 676 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 682 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 688 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CTimestampltzAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */