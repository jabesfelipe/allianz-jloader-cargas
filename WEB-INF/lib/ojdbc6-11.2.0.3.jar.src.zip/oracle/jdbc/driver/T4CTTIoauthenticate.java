/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetAddress;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Locale;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.util.RepConversion;
/*      */ import oracle.net.ano.AuthenticationService;
/*      */ import oracle.security.o3logon.O3LoginClientHelper;
/*      */ import oracle.security.o5logon.O5Logon;
/*      */ import oracle.sql.ZONEIDMAP;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class T4CTTIoauthenticate
/*      */   extends T4CTTIfun
/*      */ {
/*      */   byte[] terminal;
/*      */   byte[] enableTempLobRefCnt;
/*      */   byte[] machine;
/*      */   byte[] sysUserName;
/*      */   byte[] processID;
/*      */   byte[] programName;
/*      */   byte[] encryptedSK;
/*      */   byte[] internalName;
/*      */   byte[] externalName;
/*      */   byte[] alterSession;
/*      */   byte[] aclValue;
/*      */   byte[] clientname;
/*   86 */   byte[] editionName = null;
/*      */   
/*      */   byte[] driverName;
/*      */   
/*      */   String ressourceManagerId;
/*      */   
/*      */   boolean bUseO5Logon;
/*      */   
/*      */   int verifierType;
/*      */   
/*      */   static final int ZTVT_ORCL_7 = 2361;
/*      */   
/*      */   static final int ZTVT_SSH1 = 6949;
/*      */   
/*      */   static final int ZTVT_NTV = 7809;
/*      */   
/*      */   static final int ZTVT_SMD5 = 59694;
/*      */   
/*      */   static final int ZTVT_MD5 = 40674;
/*      */   
/*      */   static final int ZTVT_SH1 = 45394;
/*      */   
/*      */   byte[] salt;
/*      */   
/*      */   byte[] encryptedKB;
/*      */   
/*      */   boolean isSessionTZ = true;
/*      */   
/*      */   static final int SERVER_VERSION_81 = 8100;
/*      */   
/*      */   static final int KPZ_LOGON = 1;
/*      */   
/*      */   static final int KPZ_CPW = 2;
/*      */   
/*      */   static final int KPZ_SRVAUTH = 4;
/*      */   
/*      */   static final int KPZ_ENCRYPTED_PASSWD = 256;
/*      */   
/*      */   static final int KPZ_LOGON_MIGRATE = 16;
/*      */   
/*      */   static final int KPZ_LOGON_SYSDBA = 32;
/*      */   
/*      */   static final int KPZ_LOGON_SYSOPER = 64;
/*      */   
/*      */   static final int KPZ_LOGON_SYSASM = 4194304;
/*      */   
/*      */   static final int KPZ_LOGON_PRELIMAUTH = 128;
/*      */   
/*      */   static final int KPZ_PASSWD_ENCRYPTED = 256;
/*      */   
/*      */   static final int KPZ_LOGON_DBCONC = 512;
/*      */   
/*      */   static final int KPZ_PROXY_AUTH = 1024;
/*      */   
/*      */   static final int KPZ_SESSION_CACHE = 2048;
/*      */   
/*      */   static final int KPZ_PASSWD_IS_VFR = 4096;
/*      */   
/*      */   static final int KPZ_SESSION_QCACHE = 8388608;
/*      */   
/*      */   static final String AUTH_TERMINAL = "AUTH_TERMINAL";
/*      */   
/*      */   static final String AUTH_PROGRAM_NM = "AUTH_PROGRAM_NM";
/*      */   
/*      */   static final String AUTH_MACHINE = "AUTH_MACHINE";
/*      */   
/*      */   static final String AUTH_PID = "AUTH_PID";
/*      */   
/*      */   static final String AUTH_SID = "AUTH_SID";
/*      */   
/*      */   static final String AUTH_SESSKEY = "AUTH_SESSKEY";
/*      */   
/*      */   static final String AUTH_VFR_DATA = "AUTH_VFR_DATA";
/*      */   
/*      */   static final String AUTH_PASSWORD = "AUTH_PASSWORD";
/*      */   
/*      */   static final String AUTH_INTERNALNAME = "AUTH_INTERNALNAME_";
/*      */   
/*      */   static final String AUTH_EXTERNALNAME = "AUTH_EXTERNALNAME_";
/*      */   
/*      */   static final String AUTH_ACL = "AUTH_ACL";
/*      */   
/*      */   static final String AUTH_ALTER_SESSION = "AUTH_ALTER_SESSION";
/*      */   static final String AUTH_INITIAL_CLIENT_ROLE = "INITIAL_CLIENT_ROLE";
/*      */   static final String AUTH_VERSION_SQL = "AUTH_VERSION_SQL";
/*      */   static final String AUTH_VERSION_NO = "AUTH_VERSION_NO";
/*      */   static final String AUTH_XACTION_TRAITS = "AUTH_XACTION_TRAITS";
/*      */   static final String AUTH_VERSION_STATUS = "AUTH_VERSION_STATUS";
/*      */   static final String AUTH_SERIAL_NUM = "AUTH_SERIAL_NUM";
/*      */   static final String AUTH_SESSION_ID = "AUTH_SESSION_ID";
/*      */   static final String AUTH_CLIENT_CERTIFICATE = "AUTH_CLIENT_CERTIFICATE";
/*      */   static final String AUTH_PROXY_CLIENT_NAME = "PROXY_CLIENT_NAME";
/*      */   static final String AUTH_CLIENT_DN = "AUTH_CLIENT_DISTINGUISHED_NAME";
/*      */   static final String AUTH_INSTANCENAME = "AUTH_INSTANCENAME";
/*      */   static final String AUTH_DBNAME = "AUTH_DBNAME";
/*      */   static final String AUTH_INSTANCE_NO = "AUTH_INSTANCE_NO";
/*      */   static final String AUTH_SC_SERVER_HOST = "AUTH_SC_SERVER_HOST";
/*      */   static final String AUTH_SC_INSTANCE_NAME = "AUTH_SC_INSTANCE_NAME";
/*      */   static final String AUTH_SC_INSTANCE_ID = "AUTH_SC_INSTANCE_ID";
/*      */   static final String AUTH_SC_INSTANCE_START_TIME = "AUTH_SC_INSTANCE_START_TIME";
/*      */   static final String AUTH_SC_DBUNIQUE_NAME = "AUTH_SC_DBUNIQUE_NAME";
/*      */   static final String AUTH_SC_SERVICE_NAME = "AUTH_SC_SERVICE_NAME";
/*      */   static final String AUTH_SC_SVC_FLAGS = "AUTH_SC_SVC_FLAGS";
/*      */   static final String AUTH_SESSION_CLIENT_CSET = "SESSION_CLIENT_CHARSET";
/*      */   static final String AUTH_SESSION_CLIENT_LTYPE = "SESSION_CLIENT_LIB_TYPE";
/*      */   static final String AUTH_SESSION_CLIENT_DRVNM = "SESSION_CLIENT_DRIVER_NAME";
/*      */   static final String AUTH_SESSION_CLIENT_VSN = "SESSION_CLIENT_VERSION";
/*      */   static final String AUTH_NLS_LXLAN = "AUTH_NLS_LXLAN";
/*      */   static final String AUTH_NLS_LXCTERRITORY = "AUTH_NLS_LXCTERRITORY";
/*      */   static final String AUTH_NLS_LXCCURRENCY = "AUTH_NLS_LXCCURRENCY";
/*      */   static final String AUTH_NLS_LXCISOCURR = "AUTH_NLS_LXCISOCURR";
/*      */   static final String AUTH_NLS_LXCNUMERICS = "AUTH_NLS_LXCNUMERICS";
/*      */   static final String AUTH_NLS_LXCDATEFM = "AUTH_NLS_LXCDATEFM";
/*      */   static final String AUTH_NLS_LXCDATELANG = "AUTH_NLS_LXCDATELANG";
/*      */   static final String AUTH_NLS_LXCSORT = "AUTH_NLS_LXCSORT";
/*      */   static final String AUTH_NLS_LXCCALENDAR = "AUTH_NLS_LXCCALENDAR";
/*      */   static final String AUTH_NLS_LXCUNIONCUR = "AUTH_NLS_LXCUNIONCUR";
/*      */   static final String AUTH_NLS_LXCTIMEFM = "AUTH_NLS_LXCTIMEFM";
/*      */   static final String AUTH_NLS_LXCSTMPFM = "AUTH_NLS_LXCSTMPFM";
/*      */   static final String AUTH_NLS_LXCTTZNFM = "AUTH_NLS_LXCTTZNFM";
/*      */   static final String AUTH_NLS_LXCSTZNFM = "AUTH_NLS_LXCSTZNFM";
/*      */   static final String SESSION_CLIENT_LOBATTR = "SESSION_CLIENT_LOBATTR";
/*      */   static final String DRIVER_NAME_DEFAULT = "jdbcthin";
/*      */   static final int KPU_LIB_UNKN = 0;
/*      */   static final int KPU_LIB_DEF = 1;
/*      */   static final int KPU_LIB_EI = 2;
/*      */   static final int KPU_LIB_XE = 3;
/*      */   static final int KPU_LIB_ICUS = 4;
/*      */   static final int KPU_LIB_OCI = 5;
/*      */   static final int KPU_LIB_THIN = 10;
/*      */   static final String AUTH_ORA_EDITION = "AUTH_ORA_EDITION";
/*      */   static final String AUTH_COPYRIGHT = "AUTH_COPYRIGHT";
/*      */   static final String COPYRIGHT_STR = "\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.";
/*      */   static final String SESSION_TIME_ZONE = "SESSION_TIME_ZONE";
/*      */   static final String SESSION_NLS_LXCCHARSET = "SESSION_NLS_LXCCHARSET";
/*      */   static final String SESSION_NLS_LXCNLSLENSEM = "SESSION_NLS_LXCNLSLENSEM";
/*      */   static final String SESSION_NLS_LXCNCHAREXCP = "SESSION_NLS_LXCNCHAREXCP";
/*      */   static final String SESSION_NLS_LXCNCHARIMP = "SESSION_NLS_LXCNCHARIMP";
/*  224 */   String sessionTimeZone = null;
/*  225 */   byte[] serverCompileTimeCapabilities = null;
/*      */   private T4CKvaldfList keyValList;
/*      */   private byte[] user; private long logonMode; private byte[][] outKeys; private byte[][] outValues; private int[] outFlags; private int outNbPairs; O5Logon o5logonHelper; void marshal() throws IOException { if (this.user != null && this.user.length > 0) { this.meg.marshalPTR(); this.meg.marshalSB4(this.user.length); } else { this.meg.marshalNULLPTR(); this.meg.marshalSB4(0); }  this.meg.marshalUB4(this.logonMode); this.meg.marshalPTR(); this.meg.marshalUB4(this.keyValList.size()); this.meg.marshalPTR(); this.meg.marshalPTR(); if (this.user != null && this.user.length > 0) this.meg.marshalCHR(this.user);  this.meg.marshalKEYVAL(this.keyValList.getKeys(), this.keyValList.getValues(), this.keyValList.getFlags(), this.keyValList.size()); } private void doOAUTH(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong, String paramString, boolean paramBoolean, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4, byte[][] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, SQLException { setFunCode((short)115); this.user = paramArrayOfbyte1; this.logonMode = paramLong | 0x1L; if (paramBoolean) this.logonMode |= 0x400L;  if (paramArrayOfbyte1 != null && paramArrayOfbyte1.length != 0 && paramArrayOfbyte2 != null && paramString != "RADIUS") this.logonMode |= 0x100L;  this.keyValList = new T4CKvaldfList(this.meg.conv); if (paramArrayOfbyte2 != null) this.keyValList.add("AUTH_PASSWORD", paramArrayOfbyte2);  if (paramArrayOfbyte != null) for (byte b = 0; b < paramArrayOfbyte.length; b++) this.keyValList.add("INITIAL_CLIENT_ROLE", paramArrayOfbyte[b]);   if (paramArrayOfbyte3 != null) this.keyValList.add("AUTH_CLIENT_DISTINGUISHED_NAME", paramArrayOfbyte3);  if (paramArrayOfbyte4 != null) this.keyValList.add("AUTH_CLIENT_CERTIFICATE", paramArrayOfbyte4);  this.keyValList.add("AUTH_TERMINAL", this.terminal); if (this.bUseO5Logon && this.encryptedKB != null) this.keyValList.add("AUTH_SESSKEY", this.encryptedKB, (byte)1);  if (this.programName != null) this.keyValList.add("AUTH_PROGRAM_NM", this.programName);  if (this.clientname != null)
/*      */       this.keyValList.add("PROXY_CLIENT_NAME", this.clientname);  this.keyValList.add("AUTH_MACHINE", this.machine); this.keyValList.add("AUTH_PID", this.processID); if (!this.ressourceManagerId.equals("0000")) { byte[] arrayOfByte = this.meg.conv.StringToCharBytes("AUTH_INTERNALNAME_"); arrayOfByte[arrayOfByte.length - 1] = 0; this.keyValList.add(arrayOfByte, this.internalName); arrayOfByte = this.meg.conv.StringToCharBytes("AUTH_EXTERNALNAME_"); arrayOfByte[arrayOfByte.length - 1] = 0; this.keyValList.add(arrayOfByte, this.externalName); }  this.keyValList.add("AUTH_ACL", this.aclValue); this.keyValList.add("AUTH_ALTER_SESSION", this.alterSession, (byte)1); if (this.editionName != null)
/*      */       this.keyValList.add("AUTH_ORA_EDITION", this.editionName);  this.keyValList.add("SESSION_CLIENT_LOBATTR", this.enableTempLobRefCnt); this.keyValList.add("SESSION_CLIENT_DRIVER_NAME", this.driverName); this.keyValList.add("SESSION_CLIENT_VERSION", this.meg.conv.StringToCharBytes(Integer.toString(versionStringToInt(this.connection.getMetaData().getDriverVersion()), 10))); if (paramInt1 != -1)
/*      */       this.keyValList.add("AUTH_SESSION_ID", this.meg.conv.StringToCharBytes(Integer.toString(paramInt1)));  if (paramInt2 != -1)
/*  231 */       this.keyValList.add("AUTH_SERIAL_NUM", this.meg.conv.StringToCharBytes(Integer.toString(paramInt2)));  this.keyValList.add("AUTH_COPYRIGHT", this.meg.conv.StringToCharBytes("\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.")); this.outNbPairs = 0; this.outKeys = (byte[][])null; this.outValues = (byte[][])null; this.outFlags = new int[0]; doRPC(); } T4CTTIoauthenticate(T4CConnection paramT4CConnection, String paramString, byte[] paramArrayOfbyte) throws SQLException { super(paramT4CConnection, (byte)3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  245 */     this.keyValList = null;
/*  246 */     this.user = null;
/*      */ 
/*      */ 
/*      */     
/*  250 */     this.outKeys = (byte[][])null;
/*  251 */     this.outValues = (byte[][])null;
/*  252 */     this.outFlags = new int[0];
/*  253 */     this.outNbPairs = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  566 */     this.o5logonHelper = new O5Logon(); this.ressourceManagerId = paramString; this.serverCompileTimeCapabilities = paramArrayOfbyte; setSessionFields(paramT4CConnection); this.isSessionTZ = true; this.bUseO5Logon = false; }
/*      */   void doOSESSKEY(String paramString, long paramLong) throws IOException, SQLException { setFunCode((short)118); this.user = this.meg.conv.StringToCharBytes(paramString); this.logonMode = paramLong | 0x1L; this.keyValList = new T4CKvaldfList(this.meg.conv); this.keyValList.add("AUTH_TERMINAL", this.terminal); if (this.programName != null)
/*      */       this.keyValList.add("AUTH_PROGRAM_NM", this.programName);  this.keyValList.add("AUTH_MACHINE", this.machine); this.keyValList.add("AUTH_PID", this.processID); this.keyValList.add("AUTH_SID", this.sysUserName); this.outNbPairs = 0; this.outKeys = (byte[][])null; this.outValues = (byte[][])null;
/*      */     this.outFlags = new int[0];
/*  570 */     doRPC(); } void doOAUTH(String paramString1, String paramString2, long paramLong) throws IOException, SQLException { byte[] arrayOfByte1 = null;
/*  571 */     if (paramString1 != null && paramString1.length() > 0) {
/*  572 */       arrayOfByte1 = this.meg.conv.StringToCharBytes(paramString1);
/*      */     }
/*  574 */     byte[] arrayOfByte2 = null;
/*  575 */     byte[] arrayOfByte3 = null;
/*  576 */     byte[] arrayOfByte4 = null;
/*      */     
/*  578 */     String str = this.connection.net.getAuthenticationAdaptorName();
/*      */ 
/*      */ 
/*      */     
/*  582 */     if (paramString1 != null && paramString1.length() != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  587 */       if (str != "RADIUS" && this.encryptedSK.length > 16 && !this.bUseO5Logon) {
/*      */ 
/*      */ 
/*      */         
/*  591 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  592 */         sQLException.fillInStackTrace();
/*  593 */         throw sQLException;
/*      */       } 
/*      */       
/*  596 */       if (this.bUseO5Logon && (this.encryptedSK == null || (this.encryptedSK.length != 64 && this.encryptedSK.length != 96))) {
/*      */ 
/*      */         
/*  599 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  600 */         sQLException.fillInStackTrace();
/*  601 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  611 */       String str1 = paramString1.trim();
/*  612 */       String str2 = null;
/*  613 */       if (paramString2 != null)
/*      */       {
/*      */         
/*  616 */         str2 = paramString2.trim();
/*      */       }
/*  618 */       paramString2 = null;
/*      */       
/*  620 */       String str3 = str1;
/*  621 */       String str4 = str2;
/*      */       
/*  623 */       if (str1.startsWith("\"") || str1.endsWith("\"")) {
/*  624 */         str3 = removeQuotes(str1);
/*      */       }
/*  626 */       if (str2 != null && (str2.startsWith("\"") || str2.endsWith("\"")))
/*      */       {
/*  628 */         str4 = removeQuotes(str2);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  634 */       if (str4 != null) {
/*  635 */         arrayOfByte2 = this.meg.conv.StringToCharBytes(str4);
/*      */       }
/*  637 */       if (str != "RADIUS") {
/*      */         
/*  639 */         if (arrayOfByte2 == null) {
/*      */           
/*  641 */           arrayOfByte4 = null;
/*      */         }
/*  643 */         else if (this.bUseO5Logon) {
/*      */           
/*  645 */           this.encryptedKB = new byte[this.encryptedSK.length];
/*  646 */           for (byte b1 = 0; b1 < this.encryptedKB.length; ) { this.encryptedKB[b1] = 1; b1++; }
/*  647 */            int[] arrayOfInt = new int[1];
/*  648 */           byte[] arrayOfByte = new byte[256];
/*  649 */           for (byte b2 = 0; b2 < 'Ā'; ) { arrayOfByte[b2] = 0; b2++; }
/*      */           
/*      */           try {
/*  652 */             this.o5logonHelper.generateOAuthResponse(this.verifierType, this.salt, str3, str4, arrayOfByte2, this.encryptedSK, this.encryptedKB, arrayOfByte, arrayOfInt, this.meg.conv.isServerCSMultiByte, this.serverCompileTimeCapabilities[4]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  665 */           catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  674 */           arrayOfByte4 = new byte[arrayOfInt[0]];
/*  675 */           System.arraycopy(arrayOfByte, 0, arrayOfByte4, 0, arrayOfInt[0]);
/*      */         } else {
/*      */           byte b;
/*      */           
/*  679 */           O3LoginClientHelper o3LoginClientHelper = new O3LoginClientHelper(this.meg.conv.isServerCSMultiByte);
/*      */           
/*  681 */           byte[] arrayOfByte5 = o3LoginClientHelper.getSessionKey(str3, str4, this.encryptedSK);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  687 */           if (arrayOfByte2.length % 8 > 0) {
/*  688 */             b = (byte)(8 - arrayOfByte2.length % 8);
/*      */           } else {
/*  690 */             b = 0;
/*      */           } 
/*  692 */           arrayOfByte3 = new byte[arrayOfByte2.length + b];
/*      */           
/*  694 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, arrayOfByte2.length);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  699 */           byte[] arrayOfByte6 = o3LoginClientHelper.getEPasswd(arrayOfByte5, arrayOfByte3);
/*      */ 
/*      */           
/*  702 */           arrayOfByte4 = new byte[2 * arrayOfByte3.length + 1];
/*      */ 
/*      */           
/*  705 */           if (arrayOfByte4.length < 2 * arrayOfByte6.length) {
/*      */             
/*  707 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
/*  708 */             sQLException.fillInStackTrace();
/*  709 */             throw sQLException;
/*      */           } 
/*      */           
/*  712 */           RepConversion.bArray2Nibbles(arrayOfByte6, arrayOfByte4);
/*      */ 
/*      */           
/*  715 */           arrayOfByte4[arrayOfByte4.length - 1] = RepConversion.nibbleToHex(b);
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*  721 */       else if (arrayOfByte2 != null) {
/*      */         
/*  723 */         if (this.connection.net.getSessionAttributes().getNTAdapter() instanceof oracle.net.nt.TcpsNTAdapter) {
/*      */           
/*  725 */           arrayOfByte4 = arrayOfByte2;
/*      */         } else {
/*      */           byte b1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  733 */           if ((arrayOfByte2.length + 1) % 8 > 0) {
/*  734 */             b1 = (byte)(8 - (arrayOfByte2.length + 1) % 8);
/*      */           } else {
/*  736 */             b1 = 0;
/*      */           } 
/*  738 */           arrayOfByte3 = new byte[arrayOfByte2.length + 1 + b1];
/*      */           
/*  740 */           System.arraycopy(arrayOfByte2, 0, arrayOfByte3, 0, arrayOfByte2.length);
/*  741 */           byte[] arrayOfByte = AuthenticationService.obfuscatePasswordForRadius(arrayOfByte3);
/*      */ 
/*      */           
/*  744 */           arrayOfByte4 = new byte[arrayOfByte.length * 2];
/*      */           
/*  746 */           for (byte b2 = 0; b2 < arrayOfByte.length; b2++) {
/*      */             
/*  748 */             byte b3 = (byte)((arrayOfByte[b2] & 0xF0) >> 4);
/*  749 */             byte b4 = (byte)(arrayOfByte[b2] & 0xF);
/*  750 */             arrayOfByte4[b2 * 2] = (byte)((b3 < 10) ? (b3 + 48) : (b3 - 10 + 97));
/*      */             
/*  752 */             arrayOfByte4[b2 * 2 + 1] = (byte)((b4 < 10) ? (b4 + 48) : (b4 - 10 + 97));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  760 */     doOAUTH(arrayOfByte1, arrayOfByte4, paramLong, str, false, (byte[])null, (byte[])null, (byte[][])null, -1, -1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  771 */     if (str != "RADIUS" && this.bUseO5Logon)
/*      */     
/*  773 */     { String str1 = this.connection.sessionProperties.getProperty("AUTH_SVR_RESPONSE");
/*      */       
/*  775 */       try { if (!this.o5logonHelper.validateServerIdentity(str1))
/*      */         {
/*      */           
/*  778 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
/*  779 */           sQLException.fillInStackTrace();
/*  780 */           throw sQLException;
/*      */         }
/*      */          }
/*  783 */       catch (Exception exception)
/*      */       
/*  785 */       { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
/*  786 */         sQLException.fillInStackTrace();
/*  787 */         throw sQLException; }  }  } void readRPA() throws IOException, SQLException { this.outNbPairs = this.meg.unmarshalUB2(); this.outKeys = new byte[this.outNbPairs][]; this.outValues = new byte[this.outNbPairs][]; this.outFlags = this.meg.unmarshalKEYVAL(this.outKeys, this.outValues, this.outNbPairs); }
/*      */   void processError() throws SQLException { if (getFunCode() == 118) { if (this.oer.getRetCode() != 28035 || this.connection.net.getAuthenticationAdaptorName() != "RADIUS")
/*      */         this.oer.processError();  } else { super.processError(); }  }
/*      */   protected void processRPA() throws SQLException { if (getFunCode() == 115) { Properties properties = new Properties(); for (byte b = 0; b < this.outNbPairs; b++) { String str1 = this.meg.conv.CharBytesToString(this.outKeys[b], (this.outKeys[b]).length).trim(); String str2 = ""; if (this.outValues[b] != null)
/*      */           str2 = this.meg.conv.CharBytesToString(this.outValues[b], (this.outValues[b]).length).trim();  properties.setProperty(str1, str2); }  String str = properties.getProperty("AUTH_VERSION_NO"); if (str != null)
/*      */         try { int i = (new Integer(str)).intValue(); } catch (NumberFormatException numberFormatException) {}  properties.setProperty("SERVER_HOST", properties.getProperty("AUTH_SC_SERVER_HOST", "")); properties.setProperty("INSTANCE_NAME", properties.getProperty("AUTH_SC_INSTANCE_NAME", "")); properties.setProperty("DATABASE_NAME", properties.getProperty("AUTH_SC_DBUNIQUE_NAME", "")); properties.setProperty("SERVICE_NAME", properties.getProperty("AUTH_SC_SERVICE_NAME", "")); properties.setProperty("SESSION_TIME_ZONE", this.sessionTimeZone); this.connection.sessionProperties = properties; } else if (getFunCode() == 118) { if (this.connection.net.getAuthenticationAdaptorName() != "RADIUS") { if (this.outKeys == null || this.outKeys.length < 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }  byte b1 = -1; byte b2; for (b2 = 0; b2 < this.outKeys.length; b2++) { if ((new String(this.outKeys[b2])).equals("AUTH_SESSKEY")) { b1 = b2; break; }  }  if (b1 == -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }  this.encryptedSK = this.outValues[b1]; b2 = -1; for (byte b = 0; b < this.outKeys.length; b++) { if ((new String(this.outKeys[b])).equals("AUTH_VFR_DATA")) { b2 = b; break; }  }
/*      */          if (b2 != -1) { this.bUseO5Logon = true; this.salt = this.outValues[b2]; this.verifierType = this.outFlags[b2]; }
/*      */          if (!this.bUseO5Logon)
/*      */           if (this.encryptedSK == null || this.encryptedSK.length != 16) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438); sQLException.fillInStackTrace(); throw sQLException; }
/*      */             }
/*      */        }
/*      */      }
/*  799 */   void doOAUTH(int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws IOException, SQLException { byte[] arrayOfByte1 = null;
/*  800 */     byte[] arrayOfByte2 = null;
/*  801 */     String[] arrayOfString = null;
/*  802 */     byte[][] arrayOfByte = (byte[][])null;
/*  803 */     byte[] arrayOfByte3 = null;
/*      */     
/*  805 */     if (paramInt1 == 1) {
/*      */       
/*  807 */       String str1 = paramProperties.getProperty("PROXY_USER_NAME");
/*  808 */       String str2 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  809 */       if (str2 != null)
/*  810 */         str1 = str1 + "/" + str2; 
/*  811 */       arrayOfByte3 = this.meg.conv.StringToCharBytes(str1);
/*      */     }
/*  813 */     else if (paramInt1 == 2) {
/*      */       
/*  815 */       String str = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*      */ 
/*      */       
/*  818 */       arrayOfByte1 = this.meg.conv.StringToCharBytes(str);
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  824 */         arrayOfByte2 = (byte[])paramProperties.get("PROXY_CERTIFICATE");
/*      */         
/*  826 */         StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */ 
/*      */         
/*  830 */         for (byte b = 0; b < arrayOfByte2.length; b++) {
/*      */           
/*  832 */           String str = Integer.toHexString(0xFF & arrayOfByte2[b]);
/*  833 */           int i = str.length();
/*      */           
/*  835 */           if (i == 0) {
/*  836 */             stringBuffer.append("00");
/*  837 */           } else if (i == 1) {
/*      */             
/*  839 */             stringBuffer.append('0');
/*  840 */             stringBuffer.append(str);
/*      */           } else {
/*      */             
/*  843 */             stringBuffer.append(str);
/*      */           } 
/*      */         } 
/*  846 */         arrayOfByte2 = stringBuffer.toString().getBytes();
/*      */       }
/*  848 */       catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  854 */       arrayOfString = (String[])paramProperties.get("PROXY_ROLES");
/*      */     }
/*  856 */     catch (Exception exception) {}
/*      */     
/*  858 */     if (arrayOfString != null) {
/*      */       
/*  860 */       arrayOfByte = new byte[arrayOfString.length][];
/*      */       
/*  862 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*  863 */         arrayOfByte[b] = this.meg.conv.StringToCharBytes(arrayOfString[b]);
/*      */       }
/*      */     } 
/*  866 */     doOAUTH(arrayOfByte3, (byte[])null, 0L, (String)null, true, arrayOfByte1, arrayOfByte2, arrayOfByte, paramInt2, paramInt3); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setSessionFields(T4CConnection paramT4CConnection) throws SQLException {
/*  890 */     String str1 = this.connection.thinVsessionTerminal;
/*  891 */     String str2 = this.connection.thinVsessionMachine;
/*  892 */     String str3 = this.connection.thinVsessionOsuser;
/*  893 */     String str4 = this.connection.thinVsessionProgram;
/*  894 */     String str5 = this.connection.thinVsessionProcess;
/*  895 */     String str6 = this.connection.thinVsessionIname;
/*  896 */     String str7 = this.connection.thinVsessionEname;
/*  897 */     String str8 = this.connection.proxyClientName;
/*  898 */     String str9 = this.connection.driverNameAttribute;
/*  899 */     String str10 = this.connection.editionName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  912 */       if (this.connection.enableTempLobRefCnt) {
/*  913 */         this.enableTempLobRefCnt = (new String("1")).getBytes("US-ASCII");
/*      */       } else {
/*      */         
/*  916 */         this.enableTempLobRefCnt = (new String("0")).getBytes("US-ASCII");
/*      */       } 
/*  918 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  924 */     if (str2 == null) {
/*      */       
/*      */       try {
/*      */ 
/*      */         
/*  929 */         str2 = InetAddress.getLocalHost().getHostName();
/*      */       }
/*  931 */       catch (Exception exception) {
/*      */         
/*  933 */         str2 = "jdbcclient";
/*      */       } 
/*      */     }
/*      */     
/*  937 */     if (str7 == null) {
/*  938 */       str7 = "jdbc_" + this.ressourceManagerId;
/*      */     }
/*  940 */     if (str9 == null) {
/*  941 */       str9 = "jdbcthin";
/*      */     }
/*      */     
/*  944 */     this.terminal = this.meg.conv.StringToCharBytes(str1);
/*  945 */     this.machine = this.meg.conv.StringToCharBytes(str2);
/*  946 */     this.sysUserName = this.meg.conv.StringToCharBytes(str3);
/*  947 */     this.programName = this.meg.conv.StringToCharBytes(str4);
/*  948 */     this.processID = this.meg.conv.StringToCharBytes(str5);
/*  949 */     this.internalName = this.meg.conv.StringToCharBytes(str6);
/*  950 */     this.externalName = this.meg.conv.StringToCharBytes(str7);
/*  951 */     if (str8 != null)
/*  952 */       this.clientname = this.meg.conv.StringToCharBytes(str8); 
/*  953 */     if (str10 != null)
/*  954 */       this.editionName = this.meg.conv.StringToCharBytes(str10); 
/*  955 */     this.driverName = this.meg.conv.StringToCharBytes(str9);
/*      */     
/*  957 */     TimeZone timeZone = TimeZone.getDefault();
/*      */ 
/*      */     
/*  960 */     String str11 = timeZone.getID();
/*      */     
/*  962 */     if (!ZONEIDMAP.isValidRegion(str11) || !paramT4CConnection.timezoneAsRegion) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  971 */       int i = timeZone.getOffset(System.currentTimeMillis());
/*  972 */       int j = i / 3600000;
/*  973 */       int k = i / 60000 % 60;
/*      */       
/*  975 */       str11 = ((j < 0) ? ("" + j) : ("+" + j)) + ((k < 10) ? (":0" + k) : (":" + k));
/*      */     } 
/*      */ 
/*      */     
/*  979 */     this.sessionTimeZone = str11;
/*  980 */     paramT4CConnection.sessionTimeZone = str11;
/*      */     
/*  982 */     String str12 = CharacterSetMetaData.getNLSLanguage(Locale.getDefault());
/*      */     
/*  984 */     String str13 = CharacterSetMetaData.getNLSTerritory(Locale.getDefault());
/*      */ 
/*      */     
/*  987 */     if (str12 == null || str13 == null) {
/*      */       
/*  989 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/*  990 */       sQLException.fillInStackTrace();
/*  991 */       throw sQLException;
/*      */     } 
/*      */     
/*  994 */     this.alterSession = this.meg.conv.StringToCharBytes("ALTER SESSION SET " + (this.isSessionTZ ? ("TIME_ZONE='" + this.sessionTimeZone + "'") : "") + " NLS_LANGUAGE='" + str12 + "' NLS_TERRITORY='" + str13 + "' ");
/*      */ 
/*      */ 
/*      */     
/*  998 */     this.aclValue = this.meg.conv.StringToCharBytes("4400");
/*  999 */     this.alterSession[this.alterSession.length - 1] = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String removeQuotes(String paramString) {
/* 1013 */     int i = 0, j = paramString.length() - 1;
/*      */     int k;
/* 1015 */     for (k = 0; k < paramString.length(); k++) {
/*      */       
/* 1017 */       if (paramString.charAt(k) != '"') {
/*      */         
/* 1019 */         i = k;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 1025 */     for (k = paramString.length() - 1; k >= 0; k--) {
/*      */       
/* 1027 */       if (paramString.charAt(k) != '"') {
/*      */         
/* 1029 */         j = k;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 1035 */     return paramString.substring(i, j + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int versionStringToInt(String paramString) throws SQLException {
/* 1064 */     String[] arrayOfString = paramString.split("\\.");
/* 1065 */     int i = Integer.parseInt(arrayOfString[0].replaceAll("\\D", ""));
/* 1066 */     int j = Integer.parseInt(arrayOfString[1].replaceAll("\\D", ""));
/* 1067 */     int k = Integer.parseInt(arrayOfString[2].replaceAll("\\D", ""));
/* 1068 */     int m = Integer.parseInt(arrayOfString[3].replaceAll("\\D", ""));
/* 1069 */     int n = Integer.parseInt(arrayOfString[4].replaceAll("\\D", ""));
/* 1070 */     return i << 24 | j << 20 | k << 12 | m << 8 | n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String versionIntToString(int paramInt) throws SQLException {
/* 1082 */     int i = (paramInt & 0xFF000000) >> 24 & 0xFF;
/* 1083 */     int j = (paramInt & 0xF00000) >> 20 & 0xFF;
/* 1084 */     int k = (paramInt & 0xFF000) >> 12 & 0xFF;
/* 1085 */     int m = (paramInt & 0xF00) >> 8 & 0xFF;
/* 1086 */     int n = paramInt & 0xFF;
/* 1087 */     return "" + i + "." + j + "." + k + "." + m + "." + n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1103 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1108 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CTTIoauthenticate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */