/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Iterator;
/*     */ import oracle.jdbc.aq.AQNotificationEvent;
/*     */ import oracle.jdbc.dcn.DatabaseChangeEvent;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFConnection
/*     */   extends Thread
/*     */ {
/*     */   private static final int NS_HEADER_SIZE = 10;
/*     */   private static final int INTERRUPT_SIGNAL = -2;
/*     */   private SocketChannel channel;
/*  72 */   private ByteBuffer inBuffer = null;
/*  73 */   private ByteBuffer outBuffer = null;
/*     */ 
/*     */   
/*     */   private int currentNSPacketLength;
/*     */ 
/*     */   
/*     */   private int currentNSPacketType;
/*     */ 
/*     */   
/*     */   private ByteBuffer currentNSPacketDataBuffer;
/*     */   
/*     */   private boolean needsToBeClosed = false;
/*     */   
/*     */   private NTFManager ntfManager;
/*     */   
/*  88 */   private Selector selector = null;
/*  89 */   private Iterator iterator = null;
/*  90 */   private SelectionKey aKey = null;
/*     */   
/*     */   int remotePort;
/*     */   
/*     */   String remoteAddress;
/*     */   
/*     */   String remoteName;
/*     */   int localPort;
/*     */   String localAddress;
/*     */   String localName;
/*     */   String connectionDescription;
/* 101 */   CharacterSet charset = null;
/*     */   
/*     */   static final int NSPTCN = 1;
/*     */   
/*     */   static final int NSPTAC = 2;
/*     */   
/*     */   static final int NSPTAK = 3;
/*     */   
/*     */   static final int NSPTRF = 4;
/*     */   
/*     */   static final int NSPTRD = 5;
/*     */   
/*     */   static final int NSPTDA = 6;
/*     */   static final int NSPTNL = 7;
/*     */   static final int NSPTAB = 9;
/*     */   static final int NSPTRS = 11;
/*     */   static final int NSPTMK = 12;
/*     */   static final int NSPTAT = 13;
/*     */   static final int NSPTCNL = 14;
/*     */   static final int NSPTHI = 19;
/*     */   static final short KPDNFY_TIMEOUT = 1;
/*     */   static final short KPDNFY_GROUPING = 2;
/*     */   
/*     */   NTFConnection(NTFManager paramNTFManager, SocketChannel paramSocketChannel) {
/*     */     try {
/* 126 */       this.ntfManager = paramNTFManager;
/* 127 */       this.channel = paramSocketChannel;
/* 128 */       this.channel.configureBlocking(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       this.inBuffer = ByteBuffer.allocate(4096);
/* 141 */       this.outBuffer = ByteBuffer.allocate(2048);
/* 142 */       Socket socket = this.channel.socket();
/* 143 */       InetAddress inetAddress1 = socket.getInetAddress();
/* 144 */       InetAddress inetAddress2 = socket.getLocalAddress();
/* 145 */       this.remotePort = socket.getPort();
/* 146 */       this.localPort = socket.getLocalPort();
/* 147 */       this.remoteAddress = inetAddress1.getHostAddress();
/* 148 */       this.remoteName = inetAddress1.getHostName();
/* 149 */       this.localAddress = inetAddress2.getHostAddress();
/* 150 */       this.localName = inetAddress2.getHostName();
/* 151 */       this.connectionDescription = "local=" + this.localName + "/" + this.localAddress + ":" + this.localPort + ", remote=" + this.remoteName + "/" + this.remoteAddress + ":" + this.remotePort;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 156 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 168 */       this.selector = Selector.open();
/* 169 */       this.channel.register(this.selector, 1);
/*     */       
/* 171 */       int i = 0;
/* 172 */       this.inBuffer.limit(0);
/*     */       
/* 174 */       while (!this.needsToBeClosed) {
/*     */ 
/*     */         
/* 177 */         if (!this.inBuffer.hasRemaining()) {
/*     */           do {
/* 179 */             i = readFromNetwork();
/* 180 */           } while (i == 0);
/*     */         }
/* 182 */         if (i == -1) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 188 */         if (i != -2)
/*     */         {
/* 190 */           unmarshalOneNSPacket(); } 
/*     */       } 
/* 192 */       this.selector.close();
/* 193 */       this.channel.close();
/*     */     }
/* 195 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readFromNetwork() throws IOException {
/* 226 */     this.inBuffer.compact();
/*     */ 
/*     */     
/*     */     while (true) {
/* 230 */       if (this.iterator == null || !this.iterator.hasNext()) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 235 */         this.selector.select();
/*     */ 
/*     */ 
/*     */         
/* 239 */         if (this.needsToBeClosed)
/*     */         {
/* 241 */           return -2;
/*     */         }
/*     */         
/* 244 */         this.iterator = this.selector.selectedKeys().iterator(); continue;
/*     */       } 
/* 246 */       this.aKey = this.iterator.next();
/* 247 */       if ((this.aKey.readyOps() & 0x1) == 1) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     int i = this.channel.read(this.inBuffer);
/* 261 */     if (i > 0)
/*     */     {
/*     */       
/* 264 */       this.inBuffer.flip();
/*     */     }
/*     */ 
/*     */     
/* 268 */     this.iterator.remove();
/*     */     
/* 270 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getNextNSPacket() throws IOException {
/* 284 */     while (!this.inBuffer.hasRemaining() || this.inBuffer.remaining() < 10) {
/* 285 */       readFromNetwork();
/*     */     }
/* 287 */     this.currentNSPacketLength = this.inBuffer.getShort();
/*     */     
/* 289 */     this.inBuffer.position(this.inBuffer.position() + 2);
/* 290 */     this.currentNSPacketType = this.inBuffer.get();
/*     */     
/* 292 */     this.inBuffer.position(this.inBuffer.position() + 5);
/*     */ 
/*     */ 
/*     */     
/* 296 */     while (this.inBuffer.remaining() < this.currentNSPacketLength - 10) {
/* 297 */       readFromNetwork();
/*     */     }
/*     */     
/* 300 */     int i = this.inBuffer.limit();
/* 301 */     int j = this.inBuffer.position() + this.currentNSPacketLength - 10;
/*     */ 
/*     */ 
/*     */     
/* 305 */     this.inBuffer.limit(j);
/* 306 */     this.currentNSPacketDataBuffer = this.inBuffer.slice();
/* 307 */     this.inBuffer.limit(i);
/*     */     
/* 309 */     this.inBuffer.position(j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unmarshalOneNSPacket() throws IOException {
/* 325 */     getNextNSPacket();
/*     */ 
/*     */ 
/*     */     
/* 329 */     if (this.currentNSPacketDataBuffer.hasRemaining()) {
/*     */       byte[] arrayOfByte;
/* 331 */       switch (this.currentNSPacketType) {
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 336 */           arrayOfByte = new byte[] { 0, 24, 0, 0, 2, 0, 0, 0, 1, 52, 0, 0, 8, 0, Byte.MAX_VALUE, -1, 1, 0, 0, 0, 0, 24, 65, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 341 */           this.outBuffer.clear();
/* 342 */           this.outBuffer.put(arrayOfByte);
/* 343 */           this.outBuffer.limit(24);
/* 344 */           this.outBuffer.rewind();
/* 345 */           this.channel.write(this.outBuffer);
/*     */           break;
/*     */         
/*     */         case 6:
/* 349 */           if (this.currentNSPacketDataBuffer.get(0) == -34 && this.currentNSPacketDataBuffer.get(1) == -83) {
/*     */ 
/*     */ 
/*     */             
/* 353 */             byte[] arrayOfByte1 = { 0, Byte.MAX_VALUE, 0, 0, 6, 0, 0, 0, 0, 0, -34, -83, -66, -17, 0, 117, 10, 32, 1, 0, 0, 4, 0, 0, 4, 0, 3, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, 0, 31, 0, 14, 0, 1, -34, -83, -66, -17, 0, 3, 0, 0, 0, 2, 0, 4, 0, 1, 0, 1, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, -5, -1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0, 0, 3, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 371 */             this.outBuffer.clear();
/* 372 */             this.outBuffer.put(arrayOfByte1);
/* 373 */             this.outBuffer.limit(arrayOfByte1.length);
/* 374 */             this.outBuffer.rewind();
/* 375 */             this.channel.write(this.outBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 420 */           unmarshalNSDataPacket();
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unmarshalNSDataPacket() throws IOException {
/* 494 */     short s1 = readShort();
/*     */ 
/*     */     
/* 497 */     int i = readInt();
/*     */     
/* 499 */     byte b1 = readByte();
/* 500 */     int j = readInt();
/* 501 */     short s2 = readShort();
/* 502 */     if (this.charset == null || this.charset.getOracleId() != s2) {
/* 503 */       this.charset = CharacterSet.make(s2);
/*     */     }
/*     */     
/* 506 */     byte b2 = readByte();
/* 507 */     int k = readInt();
/* 508 */     short s3 = readShort();
/*     */ 
/*     */     
/* 511 */     byte b3 = readByte();
/* 512 */     int m = readInt();
/* 513 */     short s4 = readShort();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 518 */     int n = (i - 21) / 9;
/* 519 */     int[] arrayOfInt = new int[n];
/* 520 */     for (byte b = 0; b < n; b++) {
/*     */       
/* 522 */       byte b4 = readByte();
/* 523 */       int i2 = readInt();
/* 524 */       byte[] arrayOfByte = new byte[i2];
/* 525 */       readBuffer(arrayOfByte, 0, i2);
/*     */ 
/*     */ 
/*     */       
/* 529 */       for (byte b5 = 0; b5 < i2; b5++) {
/* 530 */         if (b5 < 4)
/* 531 */           arrayOfInt[b] = arrayOfInt[b] | (arrayOfByte[b5] & 0xFF) << 8 * (i2 - b5 - 1); 
/*     */       } 
/*     */     } 
/* 534 */     NTFDCNEvent nTFDCNEvent = null;
/* 535 */     NTFAQEvent nTFAQEvent = null;
/* 536 */     int i1 = 0;
/* 537 */     short s5 = 0;
/* 538 */     NTFRegistration[] arrayOfNTFRegistration = null;
/*     */     
/* 540 */     if (s1 >= 2) {
/*     */ 
/*     */       
/* 543 */       short s = readShort();
/* 544 */       arrayOfNTFRegistration = new NTFRegistration[arrayOfInt.length];
/* 545 */       for (byte b4 = 0; b4 < arrayOfInt.length; b4++) {
/*     */         
/* 547 */         arrayOfNTFRegistration[b4] = this.ntfManager.getRegistration(arrayOfInt[b4]);
/* 548 */         if (arrayOfNTFRegistration[b4] != null) {
/*     */           
/* 550 */           i1 = arrayOfNTFRegistration[b4].getNamespace();
/* 551 */           s5 = arrayOfNTFRegistration[b4].getDatabaseVersion();
/*     */         } 
/*     */       } 
/*     */       
/* 555 */       if (i1 == 2) {
/*     */ 
/*     */         
/* 558 */         nTFDCNEvent = new NTFDCNEvent(this, s5);
/*     */       }
/* 560 */       else if (i1 == 1) {
/*     */ 
/*     */         
/* 563 */         nTFAQEvent = new NTFAQEvent(this, s5);
/*     */       }
/* 565 */       else if (i1 == 0) {
/*     */       
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 578 */     short s6 = 0;
/* 579 */     if (s1 >= 3) {
/*     */ 
/*     */       
/* 582 */       short s = readShort();
/* 583 */       int i2 = readInt();
/* 584 */       byte b4 = readByte();
/* 585 */       int i3 = readInt();
/* 586 */       s6 = readShort();
/* 587 */       if (i1 == 2 && nTFDCNEvent != null) {
/*     */ 
/*     */         
/* 590 */         nTFDCNEvent.setAdditionalEventType(DatabaseChangeEvent.AdditionalEventType.getEventType(s6));
/*     */ 
/*     */         
/* 593 */         if (s6 == 1) {
/* 594 */           nTFDCNEvent.setEventType(DatabaseChangeEvent.EventType.DEREG);
/*     */         }
/* 596 */       } else if (i1 == 1 && nTFAQEvent != null) {
/*     */ 
/*     */         
/* 599 */         nTFAQEvent.setAdditionalEventType(AQNotificationEvent.AdditionalEventType.getEventType(s6));
/*     */ 
/*     */         
/* 602 */         if (s6 == 1) {
/* 603 */           nTFAQEvent.setEventType(AQNotificationEvent.EventType.DEREG);
/*     */         }
/*     */       } 
/*     */     } 
/* 607 */     if (s1 > 3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 612 */     if (arrayOfNTFRegistration != null) {
/*     */       
/* 614 */       if (i1 == 2)
/* 615 */         for (byte b4 = 0; b4 < arrayOfNTFRegistration.length; b4++) {
/* 616 */           if (arrayOfNTFRegistration[b4] != null && nTFDCNEvent != null)
/*     */           {
/* 618 */             arrayOfNTFRegistration[b4].notify(nTFDCNEvent); } 
/*     */         }  
/* 620 */       if (i1 == 1) {
/* 621 */         for (byte b4 = 0; b4 < arrayOfNTFRegistration.length; b4++) {
/* 622 */           if (arrayOfNTFRegistration[b4] != null && nTFAQEvent != null)
/*     */           {
/* 624 */             arrayOfNTFRegistration[b4].notify(nTFAQEvent);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeThisConnection() {
/* 637 */     this.needsToBeClosed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte readByte() throws IOException {
/* 648 */     byte b = 0;
/* 649 */     if (this.currentNSPacketDataBuffer.hasRemaining()) {
/* 650 */       b = this.currentNSPacketDataBuffer.get();
/*     */     } else {
/*     */       
/* 653 */       getNextNSPacket();
/* 654 */       b = this.currentNSPacketDataBuffer.get();
/*     */     } 
/* 656 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short readShort() throws IOException {
/* 665 */     short s = 0;
/* 666 */     if (this.currentNSPacketDataBuffer.remaining() >= 2) {
/* 667 */       s = this.currentNSPacketDataBuffer.getShort();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 673 */       int i = readByte() & 0xFF;
/* 674 */       int j = readByte() & 0xFF;
/* 675 */       s = (short)(i << 8 | j);
/*     */     } 
/* 677 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int readInt() throws IOException {
/* 686 */     int i = 0;
/* 687 */     if (this.currentNSPacketDataBuffer.remaining() >= 4) {
/* 688 */       i = this.currentNSPacketDataBuffer.getInt();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 694 */       int j = readByte() & 0xFF;
/* 695 */       int k = readByte() & 0xFF;
/* 696 */       int m = readByte() & 0xFF;
/* 697 */       int n = readByte() & 0xFF;
/* 698 */       i = j << 24 | k << 16 | m << 8 | n;
/*     */     } 
/* 700 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long readLong() throws IOException {
/* 709 */     long l = 0L;
/* 710 */     if (this.currentNSPacketDataBuffer.remaining() >= 8) {
/* 711 */       l = this.currentNSPacketDataBuffer.getLong();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 717 */       long l1 = (readByte() & 0xFF);
/* 718 */       long l2 = (readByte() & 0xFF);
/* 719 */       long l3 = (readByte() & 0xFF);
/* 720 */       long l4 = (readByte() & 0xFF);
/* 721 */       long l5 = (readByte() & 0xFF);
/* 722 */       long l6 = (readByte() & 0xFF);
/* 723 */       long l7 = (readByte() & 0xFF);
/* 724 */       long l8 = (readByte() & 0xFF);
/* 725 */       l = l1 << 56L | l2 << 48L | l3 << 40L | l4 << 32L | l5 << 24L | l6 << 16L | l7 << 8L | l8;
/*     */     } 
/* 727 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 738 */     if (this.currentNSPacketDataBuffer.remaining() >= paramInt2) {
/* 739 */       this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, paramInt2);
/*     */     } else {
/*     */       
/* 742 */       boolean bool = false;
/* 743 */       int i = 0;
/* 744 */       int j = 0;
/* 745 */       int k = this.currentNSPacketDataBuffer.remaining();
/* 746 */       this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, k);
/* 747 */       paramInt1 += k;
/* 748 */       i += k;
/* 749 */       while (!bool) {
/*     */         
/* 751 */         getNextNSPacket();
/* 752 */         k = this.currentNSPacketDataBuffer.remaining();
/* 753 */         j = Math.min(k, paramInt2 - i);
/* 754 */         this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, j);
/* 755 */         paramInt1 += j;
/* 756 */         i += j;
/* 757 */         if (i == paramInt2) {
/* 758 */           bool = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String packetToString(ByteBuffer paramByteBuffer) throws IOException {
/* 770 */     byte b = 0;
/*     */     
/* 772 */     char[] arrayOfChar = new char[8];
/* 773 */     StringBuffer stringBuffer = new StringBuffer();
/* 774 */     int i = paramByteBuffer.position();
/*     */     
/* 776 */     while (paramByteBuffer.hasRemaining()) {
/* 777 */       byte b1 = paramByteBuffer.get();
/* 778 */       String str = Integer.toHexString(b1 & 0xFF);
/* 779 */       str = str.toUpperCase();
/* 780 */       if (str.length() == 1)
/* 781 */         str = "0" + str; 
/* 782 */       stringBuffer.append(str);
/* 783 */       stringBuffer.append(' ');
/* 784 */       if (b1 > 32 && b1 < Byte.MAX_VALUE) {
/* 785 */         arrayOfChar[b] = (char)b1;
/*     */       } else {
/* 787 */         arrayOfChar[b] = '.';
/* 788 */       }  b++;
/* 789 */       if (b == 8) {
/* 790 */         stringBuffer.append('|');
/* 791 */         stringBuffer.append(arrayOfChar);
/* 792 */         stringBuffer.append('|');
/* 793 */         stringBuffer.append('\n');
/* 794 */         b = 0;
/*     */       } 
/*     */     } 
/* 797 */     if (b != 0) {
/* 798 */       int j = 8 - b; byte b1;
/* 799 */       for (b1 = 0; b1 < j * 3; b1++)
/* 800 */         stringBuffer.append(' '); 
/* 801 */       stringBuffer.append('|');
/* 802 */       stringBuffer.append(arrayOfChar, 0, b);
/* 803 */       for (b1 = 0; b1 < j; b1++)
/* 804 */         stringBuffer.append(' '); 
/* 805 */       stringBuffer.append('|');
/* 806 */       stringBuffer.append('\n');
/*     */     } 
/* 808 */     stringBuffer.append("\nEnd of Packet\n\n");
/* 809 */     paramByteBuffer.position(i);
/* 810 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 815 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NTFConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */