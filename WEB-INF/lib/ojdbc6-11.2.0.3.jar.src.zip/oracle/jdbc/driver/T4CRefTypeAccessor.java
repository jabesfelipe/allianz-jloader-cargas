/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CRefTypeAccessor
/*     */   extends RefTypeAccessor
/*     */ {
/*     */   static final int maxLength = 4000;
/*     */   T4CMAREngine mare;
/*     */   final int[] meta;
/*     */   
/*     */   T4CRefTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  47 */     super(paramOracleStatement, paramString, paramShort, paramInt, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; this.byteLength = 4000; } T4CRefTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     this.definedColumnType = paramInt7;
/*     */     this.definedColumnSize = paramInt8;
/*     */     this.byteLength = 4000; }
/*     */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     }  }
/* 155 */   boolean unmarshalOneRow() throws SQLException, IOException { if (this.isUseLess) {
/*     */       
/* 157 */       this.lastRowProcessed++;
/*     */       
/* 159 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 164 */     byte[] arrayOfByte = this.mare.unmarshalCLRforREFS();
/*     */     
/* 166 */     if (arrayOfByte == null) {
/* 167 */       arrayOfByte = new byte[0];
/*     */     }
/* 169 */     this.pickledBytes[this.lastRowProcessed] = arrayOfByte;
/* 170 */     this.meta[0] = arrayOfByte.length;
/*     */     
/* 172 */     processIndicator(this.meta[0]);
/*     */ 
/*     */     
/* 175 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 176 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */     
/* 178 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 182 */       this.rowSpaceIndicator[i] = -1;
/* 183 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 187 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 192 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 195 */     this.lastRowProcessed++;
/*     */     
/* 197 */     return false; } String getString(int paramInt) throws SQLException {
/*     */     String str = super.getString(paramInt);
/*     */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */       str = str.substring(0, this.definedColumnSize); 
/*     */     return str;
/* 202 */   } private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4CRefTypeAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */