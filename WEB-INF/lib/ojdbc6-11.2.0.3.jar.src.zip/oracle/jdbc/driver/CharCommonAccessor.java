/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ import oracle.sql.CHAR;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CharCommonAccessor
/*     */   extends Accessor
/*     */ {
/*     */   int internalMaxLengthNewer;
/*     */   int internalMaxLengthOlder;
/*     */   static final int MAX_NB_CHAR_PLSQL = 32766;
/*     */   
/*     */   void setOffsets(int paramInt) {
/*  42 */     this.columnIndex = this.statement.defineCharSubRange;
/*  43 */     this.statement.defineCharSubRange = this.columnIndex + paramInt * this.charLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, short paramShort, int paramInt4, boolean paramBoolean, int paramInt5, int paramInt6) throws SQLException {
/*  52 */     if (paramBoolean) {
/*     */       
/*  54 */       if (paramInt1 != 23) {
/*  55 */         paramInt1 = 1;
/*     */       }
/*  57 */       if (paramOracleStatement.maxFieldSize > 0 && (paramInt3 == -1 || paramInt3 < paramOracleStatement.maxFieldSize)) {
/*  58 */         paramInt3 = paramOracleStatement.maxFieldSize;
/*     */       }
/*     */     } 
/*  61 */     init(paramOracleStatement, paramInt1, paramInt2, paramShort, paramBoolean);
/*     */ 
/*     */     
/*  64 */     if (paramBoolean && paramOracleStatement.connection.defaultnchar) {
/*  65 */       this.formOfUse = 2;
/*     */     }
/*  67 */     this.internalMaxLengthNewer = paramInt5;
/*  68 */     this.internalMaxLengthOlder = paramInt6;
/*     */     
/*  70 */     initForDataAccess(paramInt4, paramInt3, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, short paramShort, int paramInt9, int paramInt10) throws SQLException {
/*  80 */     init(paramOracleStatement, paramInt1, paramInt2, paramShort, false);
/*  81 */     initForDescribe(paramInt1, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort, null);
/*     */ 
/*     */     
/*  84 */     int i = paramOracleStatement.maxFieldSize;
/*     */     
/*  86 */     if (i != 0 && i <= paramInt3) {
/*  87 */       paramInt3 = i;
/*     */     }
/*  89 */     this.internalMaxLengthNewer = paramInt9;
/*  90 */     this.internalMaxLengthOlder = paramInt10;
/*     */     
/*  92 */     initForDataAccess(0, paramInt3, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 100 */     if (paramInt1 != 0) {
/* 101 */       this.externalType = paramInt1;
/*     */     }
/* 103 */     if (this.statement.connection.getVersionNumber() >= 8000) {
/* 104 */       this.internalTypeMaxLength = this.internalMaxLengthNewer;
/*     */     } else {
/* 106 */       this.internalTypeMaxLength = this.internalMaxLengthOlder;
/*     */     } 
/* 108 */     if (paramInt2 == 0) {
/* 109 */       this.internalTypeMaxLength = 0;
/*     */     }
/* 111 */     else if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/* 112 */       this.internalTypeMaxLength = paramInt2;
/*     */     } 
/*     */     
/* 115 */     this.charLength = this.isNullByDescribe ? 0 : (this.internalTypeMaxLength + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getInt(int paramInt) throws SQLException {
/* 123 */     int i = 0;
/*     */     
/* 125 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 129 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 130 */       sQLException.fillInStackTrace();
/* 131 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*     */       try {
/*     */         
/* 141 */         i = Integer.parseInt(getString(paramInt).trim());
/*     */       }
/* 143 */       catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */         
/* 146 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 147 */         sQLException.fillInStackTrace();
/* 148 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 153 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getBoolean(int paramInt) throws SQLException {
/* 170 */     String str = getString(paramInt);
/* 171 */     if (str == null)
/*     */     {
/* 173 */       return false;
/*     */     }
/* 175 */     str = str.trim();
/*     */     
/*     */     try {
/* 178 */       BigDecimal bigDecimal = new BigDecimal(str);
/* 179 */       return (bigDecimal.signum() != 0);
/*     */     }
/* 181 */     catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */       
/* 184 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 185 */       sQLException.fillInStackTrace();
/* 186 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getShort(int paramInt) throws SQLException {
/* 197 */     short s = 0;
/*     */     
/* 199 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 203 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 204 */       sQLException.fillInStackTrace();
/* 205 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*     */       try {
/*     */         
/* 215 */         s = Short.parseShort(getString(paramInt).trim());
/*     */       }
/* 217 */       catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */         
/* 220 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 221 */         sQLException.fillInStackTrace();
/* 222 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 227 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte getByte(int paramInt) throws SQLException {
/* 235 */     byte b = 0;
/*     */     
/* 237 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 241 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 242 */       sQLException.fillInStackTrace();
/* 243 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*     */       try {
/*     */         
/* 253 */         b = Byte.parseByte(getString(paramInt).trim());
/*     */       }
/* 255 */       catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */         
/* 258 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 259 */         sQLException.fillInStackTrace();
/* 260 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 265 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getLong(int paramInt) throws SQLException {
/* 273 */     long l = 0L;
/*     */     
/* 275 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 279 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 280 */       sQLException.fillInStackTrace();
/* 281 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 287 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*     */       try {
/*     */         
/* 291 */         l = Long.parseLong(getString(paramInt).trim());
/*     */       }
/* 293 */       catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */         
/* 296 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 297 */         sQLException.fillInStackTrace();
/* 298 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 303 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float getFloat(int paramInt) throws SQLException {
/* 311 */     float f = 0.0F;
/*     */     
/* 313 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 317 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 318 */       sQLException.fillInStackTrace();
/* 319 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 325 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*     */       try {
/*     */         
/* 329 */         f = Float.parseFloat(getString(paramInt).trim());
/*     */       }
/* 331 */       catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */         
/* 334 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 335 */         sQLException.fillInStackTrace();
/* 336 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 341 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double getDouble(int paramInt) throws SQLException {
/* 349 */     double d = 0.0D;
/*     */     
/* 351 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 355 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 356 */       sQLException.fillInStackTrace();
/* 357 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 363 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*     */       try {
/*     */         
/* 367 */         d = Double.parseDouble(getString(paramInt).trim());
/*     */       }
/* 369 */       catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */         
/* 372 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 373 */         sQLException.fillInStackTrace();
/* 374 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 379 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 387 */     BigDecimal bigDecimal = null;
/*     */     
/* 389 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 393 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 394 */       sQLException.fillInStackTrace();
/* 395 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 401 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*     */       try {
/*     */         
/* 405 */         String str = getString(paramInt);
/*     */         
/* 407 */         if (str != null) {
/* 408 */           bigDecimal = new BigDecimal(str.trim());
/*     */         }
/* 410 */       } catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */         
/* 413 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 414 */         sQLException.fillInStackTrace();
/* 415 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 420 */     return bigDecimal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 428 */     BigDecimal bigDecimal = getBigDecimal(paramInt1);
/*     */     
/* 430 */     if (bigDecimal != null) {
/* 431 */       bigDecimal.setScale(paramInt2, 6);
/*     */     }
/* 433 */     return bigDecimal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 441 */     String str = null;
/*     */     
/* 443 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 447 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 448 */       sQLException.fillInStackTrace();
/* 449 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 455 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 457 */       int i = this.columnIndex + this.charLength * paramInt;
/* 458 */       int j = this.rowSpaceChar[i] >> 1;
/*     */       
/* 460 */       if (j > this.internalTypeMaxLength) {
/* 461 */         j = this.internalTypeMaxLength;
/*     */       }
/* 463 */       str = new String(this.rowSpaceChar, i + 1, j);
/*     */     } 
/*     */     
/* 466 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 474 */     Date date = null;
/*     */     
/* 476 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 480 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 481 */       sQLException.fillInStackTrace();
/* 482 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 488 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*     */     {
/* 490 */       date = Date.valueOf(getString(paramInt).trim());
/*     */     }
/*     */     
/* 493 */     return date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/* 501 */     Time time = null;
/*     */     
/* 503 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 507 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 508 */       sQLException.fillInStackTrace();
/* 509 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 515 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*     */     {
/* 517 */       time = Time.valueOf(getString(paramInt).trim());
/*     */     }
/*     */     
/* 520 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 528 */     Timestamp timestamp = null;
/*     */     
/* 530 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 534 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 535 */       sQLException.fillInStackTrace();
/* 536 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 542 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*     */     {
/* 544 */       timestamp = Timestamp.valueOf(getString(paramInt).trim());
/*     */     }
/*     */     
/* 547 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 560 */     return getBytesInternal(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   byte[] getBytesInternal(int paramInt) throws SQLException {
/* 565 */     byte[] arrayOfByte = null;
/*     */     
/* 567 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 571 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 572 */       sQLException.fillInStackTrace();
/* 573 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 579 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 581 */       int i = this.columnIndex + this.charLength * paramInt;
/* 582 */       int j = this.rowSpaceChar[i] >> 1;
/*     */       
/* 584 */       if (j > this.internalTypeMaxLength) {
/* 585 */         j = this.internalTypeMaxLength;
/*     */       }
/* 587 */       DBConversion dBConversion = this.statement.connection.conversion;
/*     */ 
/*     */ 
/*     */       
/* 591 */       byte[] arrayOfByte1 = new byte[j * 6];
/* 592 */       int k = (this.formOfUse == 2) ? dBConversion.javaCharsToNCHARBytes(this.rowSpaceChar, i + 1, arrayOfByte1, 0, j) : dBConversion.javaCharsToCHARBytes(this.rowSpaceChar, i + 1, arrayOfByte1, 0, j);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 598 */       arrayOfByte = new byte[k];
/*     */       
/* 600 */       System.arraycopy(arrayOfByte1, 0, arrayOfByte, 0, k);
/*     */     } 
/*     */     
/* 603 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getAsciiStream(int paramInt) throws SQLException {
/* 620 */     InputStream inputStream = null;
/*     */     
/* 622 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 626 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 627 */       sQLException.fillInStackTrace();
/* 628 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 633 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 635 */       int i = this.columnIndex + this.charLength * paramInt;
/* 636 */       int j = this.rowSpaceChar[i] >> 1;
/*     */       
/* 638 */       if (j > this.internalTypeMaxLength) {
/* 639 */         j = this.internalTypeMaxLength;
/*     */       }
/* 641 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 643 */       inputStream = physicalConnection.conversion.CharsToStream(this.rowSpaceChar, i + 1, j, 10);
/*     */     } 
/*     */ 
/*     */     
/* 647 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 661 */     InputStream inputStream = null;
/*     */     
/* 663 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 667 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 668 */       sQLException.fillInStackTrace();
/* 669 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 674 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 676 */       int i = this.columnIndex + this.charLength * paramInt;
/* 677 */       int j = this.rowSpaceChar[i] >> 1;
/*     */       
/* 679 */       if (j > this.internalTypeMaxLength) {
/* 680 */         j = this.internalTypeMaxLength;
/*     */       }
/* 682 */       PhysicalConnection physicalConnection = this.statement.connection;
/*     */       
/* 684 */       inputStream = physicalConnection.conversion.CharsToStream(this.rowSpaceChar, i + 1, j << 1, 11);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 689 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Reader getCharacterStream(int paramInt) throws SQLException {
/* 703 */     CharArrayReader charArrayReader = null;
/* 704 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 708 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 709 */       sQLException.fillInStackTrace();
/* 710 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 715 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 717 */       int i = this.columnIndex + this.charLength * paramInt;
/* 718 */       int j = this.rowSpaceChar[i] >> 1;
/*     */       
/* 720 */       if (j > this.internalTypeMaxLength) {
/* 721 */         j = this.internalTypeMaxLength;
/*     */       }
/* 723 */       charArrayReader = new CharArrayReader(this.rowSpaceChar, i + 1, j);
/*     */     } 
/* 725 */     return charArrayReader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getBinaryStream(int paramInt) throws SQLException {
/* 739 */     ByteArrayInputStream byteArrayInputStream = null;
/*     */     
/* 741 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 745 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 746 */       sQLException.fillInStackTrace();
/* 747 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 752 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 754 */       int i = this.columnIndex + this.charLength * paramInt;
/* 755 */       int j = this.rowSpaceChar[i] >> 1;
/*     */       
/* 757 */       if (j > this.internalTypeMaxLength) {
/* 758 */         j = this.internalTypeMaxLength;
/*     */       }
/* 760 */       DBConversion dBConversion = this.statement.connection.conversion;
/*     */ 
/*     */ 
/*     */       
/* 764 */       byte[] arrayOfByte = new byte[j * 6];
/* 765 */       int k = (this.formOfUse == 2) ? dBConversion.javaCharsToNCHARBytes(this.rowSpaceChar, i + 1, arrayOfByte, 0, j) : dBConversion.javaCharsToCHARBytes(this.rowSpaceChar, i + 1, arrayOfByte, 0, j);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 771 */       byteArrayInputStream = new ByteArrayInputStream(arrayOfByte, 0, k);
/*     */     } 
/*     */     
/* 774 */     return byteArrayInputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 788 */     return getString(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 803 */     return getString(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 817 */     return (Datum)getCHAR(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CHAR getCHAR(int paramInt) throws SQLException {
/*     */     CharacterSet characterSet;
/* 831 */     byte[] arrayOfByte = getBytesInternal(paramInt);
/*     */ 
/*     */     
/* 834 */     if (arrayOfByte == null || arrayOfByte.length == 0)
/*     */     {
/* 836 */       return null;
/*     */     }
/*     */     
/* 839 */     if (this.formOfUse == 2) {
/*     */       
/* 841 */       characterSet = this.statement.connection.conversion.getDriverNCharSetObj();
/*     */     }
/*     */     else {
/*     */       
/* 845 */       characterSet = this.statement.connection.conversion.getDriverCharSetObj();
/*     */     } 
/*     */     
/* 848 */     return new CHAR(arrayOfByte, characterSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   URL getURL(int paramInt) throws SQLException {
/* 862 */     URL uRL = null;
/*     */     
/* 864 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 868 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 869 */       sQLException.fillInStackTrace();
/* 870 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 876 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*     */       try {
/*     */         
/* 880 */         uRL = new URL(getString(paramInt));
/*     */       }
/* 882 */       catch (MalformedURLException malformedURLException) {
/*     */ 
/*     */         
/* 885 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 886 */         sQLException.fillInStackTrace();
/* 887 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 892 */     return uRL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytesFromHexChars(int paramInt) throws SQLException {
/* 899 */     byte[] arrayOfByte = null;
/*     */     
/* 901 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 905 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 906 */       sQLException.fillInStackTrace();
/* 907 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 913 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 915 */       int i = this.columnIndex + this.charLength * paramInt;
/* 916 */       int j = this.rowSpaceChar[i] >> 1;
/*     */       
/* 918 */       if (j > this.internalTypeMaxLength) {
/* 919 */         j = this.internalTypeMaxLength;
/*     */       }
/* 921 */       arrayOfByte = this.statement.connection.conversion.hexChars2Bytes(this.rowSpaceChar, i + 1, j);
/*     */     } 
/*     */     
/* 924 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long updateChecksum(long paramLong, int paramInt) throws SQLException {
/* 930 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*     */       
/* 932 */       paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 938 */       int i = this.columnIndex + this.charLength * paramInt;
/* 939 */       int j = this.rowSpaceChar[i] >> 1;
/*     */       
/* 941 */       paramLong = CRC64.updateChecksum(paramLong, this.rowSpaceChar, i + 1, j);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 947 */     return paramLong;
/*     */   }
/*     */ 
/*     */   
/* 951 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\CharCommonAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */