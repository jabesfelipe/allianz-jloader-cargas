/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8TTIBlob
/*     */   extends T4C8TTILob
/*     */ {
/*     */   T4C8TTIBlob(T4CConnection paramT4CConnection) {
/* 115 */     super(paramT4CConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
/* 139 */     if (paramInt == 12) {
/*     */       
/* 141 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
/* 142 */       sQLException.fillInStackTrace();
/* 143 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 148 */     BLOB bLOB = null;
/*     */ 
/*     */     
/* 151 */     initializeLobdef();
/*     */ 
/*     */     
/* 154 */     this.lobops = 272L;
/* 155 */     this.sourceLobLocator = new byte[86];
/* 156 */     this.sourceLobLocator[1] = 84;
/*     */ 
/*     */     
/* 159 */     this.characterSet = 1;
/*     */ 
/*     */ 
/*     */     
/* 163 */     this.destinationOffset = 113L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     this.destinationLength = paramInt;
/*     */     
/* 170 */     this.lobamt = paramInt;
/* 171 */     this.sendLobamt = true;
/*     */ 
/*     */     
/* 174 */     this.nullO2U = true;
/*     */     
/* 176 */     if (this.connection.versionNumber >= 9000) {
/*     */       
/* 178 */       this.lobscn = new int[1];
/* 179 */       this.lobscn[0] = paramBoolean ? 1 : 0;
/* 180 */       this.lobscnl = 1;
/*     */     } 
/*     */     
/* 183 */     doRPC();
/*     */ 
/*     */ 
/*     */     
/* 187 */     if (this.sourceLobLocator != null)
/*     */     {
/* 189 */       bLOB = new BLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */     }
/*     */ 
/*     */     
/* 193 */     return (Datum)bLOB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 211 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */     
/* 215 */     byte b = 2;
/*     */     
/* 217 */     if (paramInt == 0) {
/* 218 */       b = 1;
/*     */     }
/* 220 */     bool = _open(paramArrayOfbyte, b, 32768);
/*     */     
/* 222 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 240 */     boolean bool = false;
/*     */     
/* 242 */     bool = _close(paramArrayOfbyte, 65536);
/*     */     
/* 244 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 262 */     boolean bool = false;
/*     */     
/* 264 */     bool = _isOpen(paramArrayOfbyte, 69632);
/*     */     
/* 266 */     return bool;
/*     */   }
/*     */ 
/*     */   
/* 270 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T4C8TTIBlob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */