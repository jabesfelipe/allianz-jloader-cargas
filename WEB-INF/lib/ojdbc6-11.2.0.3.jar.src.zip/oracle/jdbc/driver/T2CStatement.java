/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.ShortBuffer;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.oracore.OracleType;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T2CStatement
/*      */   extends OracleStatement
/*      */ {
/*   36 */   T2CConnection connection = null;
/*   37 */   int userResultSetType = -1;
/*   38 */   int userResultSetConcur = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   44 */   static int T2C_EXTEND_BUFFER = -3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   59 */   long[] t2cOutput = new long[10];
/*      */ 
/*      */ 
/*      */   
/*      */   static final int T2C_OUTPUT_USE_NIO = 5;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int T2C_OUTPUT_STMT_LOB_PREFETCH_SIZE = 6;
/*      */ 
/*      */ 
/*      */   
/*      */   int extractedCharOffset;
/*      */ 
/*      */ 
/*      */   
/*      */   int extractedByteOffset;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_SIZE_THIS_COLUMN_OFFSET = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_LOB_LENGTH_OFFSET = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_FORM_OFFSET = 2;
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_CHUNK_OFFSET = 3;
/*      */ 
/*      */   
/*      */   static final byte T2C_LOB_PREFETCH_DATA_OFFSET = 4;
/*      */ 
/*      */ 
/*      */   
/*      */   T2CStatement(T2CConnection paramT2CConnection, int paramInt1, int paramInt2) throws SQLException {
/*   98 */     this(paramT2CConnection, paramInt1, paramInt2, -1, -1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  105 */     this.connection = paramT2CConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T2CStatement(T2CConnection paramT2CConnection, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  115 */     super(paramT2CConnection, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  121 */     this.userResultSetType = paramInt3;
/*  122 */     this.userResultSetConcur = paramInt4;
/*      */     
/*  124 */     this.connection = paramT2CConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cParseExecuteDescribe(OracleStatement paramOracleStatement, long paramLong, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, byte[] paramArrayOfbyte1, int paramInt4, byte paramByte, int paramInt5, int paramInt6, short[] paramArrayOfshort1, int paramInt7, byte[] paramArrayOfbyte2, char[] paramArrayOfchar1, int paramInt8, int paramInt9, short[] paramArrayOfshort2, int paramInt10, int paramInt11, byte[] paramArrayOfbyte3, char[] paramArrayOfchar2, int paramInt12, int paramInt13, int[] paramArrayOfint, short[] paramArrayOfshort3, byte[] paramArrayOfbyte4, int paramInt14, int paramInt15, int paramInt16, int paramInt17, boolean paramBoolean5, boolean paramBoolean6, Accessor[] paramArrayOfAccessor, byte[][][] paramArrayOfbyte, long[] paramArrayOflong, byte[] paramArrayOfbyte5, int paramInt18, char[] paramArrayOfchar3, int paramInt19, short[] paramArrayOfshort4, int paramInt20, boolean paramBoolean7) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cDefineExecuteFetch(OracleStatement paramOracleStatement, long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2, byte[] paramArrayOfbyte1, int paramInt5, byte paramByte, int paramInt6, int paramInt7, short[] paramArrayOfshort1, int paramInt8, byte[] paramArrayOfbyte2, char[] paramArrayOfchar1, int paramInt9, int paramInt10, short[] paramArrayOfshort2, byte[] paramArrayOfbyte3, int paramInt11, int paramInt12, boolean paramBoolean3, boolean paramBoolean4, Accessor[] paramArrayOfAccessor, byte[][][] paramArrayOfbyte, long[] paramArrayOflong, byte[] paramArrayOfbyte4, int paramInt13, char[] paramArrayOfchar2, int paramInt14, short[] paramArrayOfshort3, int paramInt15, ByteBuffer[] paramArrayOfByteBuffer, Object[] paramArrayOfObject) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cDescribe(long paramLong, short[] paramArrayOfshort, byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfbyte2, int paramInt5, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cDefineFetch(OracleStatement paramOracleStatement, long paramLong, int paramInt1, short[] paramArrayOfshort1, byte[] paramArrayOfbyte1, int paramInt2, int paramInt3, Accessor[] paramArrayOfAccessor, byte[] paramArrayOfbyte2, int paramInt4, char[] paramArrayOfchar, int paramInt5, short[] paramArrayOfshort2, int paramInt6, long[] paramArrayOflong, ByteBuffer[] paramArrayOfByteBuffer, Object[] paramArrayOfObject);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cFetch(long paramLong, boolean paramBoolean, int paramInt1, Accessor[] paramArrayOfAccessor, byte[] paramArrayOfbyte, int paramInt2, char[] paramArrayOfchar, int paramInt3, short[] paramArrayOfshort, int paramInt4, long[] paramArrayOflong, ByteBuffer[] paramArrayOfByteBuffer, Object[] paramArrayOfObject);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cCloseStatement(long paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cEndToEndUpdate(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, int paramInt5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cGetRowsDmlReturned(long paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cFetchDmlReturnParams(long paramLong, Accessor[] paramArrayOfAccessor, byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String bytes2String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  344 */     byte[] arrayOfByte = new byte[paramInt2];
/*      */     
/*  346 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*      */     
/*  348 */     return this.connection.conversion.CharBytesToString(arrayOfByte, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processDescribeData() throws SQLException {
/*  364 */     this.described = true;
/*  365 */     this.describedWithNames = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  376 */     if (this.accessors == null || this.numberOfDefinePositions > this.accessors.length) {
/*  377 */       this.accessors = new Accessor[this.numberOfDefinePositions];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  393 */     int i = this.connection.queryMetaData1Offset;
/*  394 */     int j = this.connection.queryMetaData2Offset;
/*  395 */     short[] arrayOfShort = this.connection.queryMetaData1;
/*  396 */     byte[] arrayOfByte = this.connection.queryMetaData2;
/*      */     
/*  398 */     for (byte b = 0; b < this.numberOfDefinePositions; 
/*  399 */       b++, i += 13) {
/*      */       
/*  401 */       short s1 = arrayOfShort[i + 0];
/*  402 */       short s2 = arrayOfShort[i + 1];
/*  403 */       short s3 = arrayOfShort[i + 11];
/*  404 */       boolean bool1 = (arrayOfShort[i + 2] != 0) ? true : false;
/*  405 */       short s4 = arrayOfShort[i + 3];
/*  406 */       short s5 = arrayOfShort[i + 4];
/*  407 */       boolean bool2 = false;
/*  408 */       boolean bool3 = false;
/*  409 */       boolean bool4 = false;
/*  410 */       short s6 = arrayOfShort[i + 5];
/*  411 */       short s7 = arrayOfShort[i + 6];
/*  412 */       String str1 = bytes2String(arrayOfByte, j, s7);
/*  413 */       short s8 = arrayOfShort[i + 12];
/*  414 */       String str2 = null;
/*  415 */       OracleTypeADT oracleTypeADT = null;
/*      */       
/*  417 */       j += s7;
/*      */       
/*  419 */       if (s8 > 0) {
/*      */         
/*  421 */         str2 = bytes2String(arrayOfByte, j, s8);
/*  422 */         j += s8;
/*  423 */         oracleTypeADT = new OracleTypeADT(str2, (Connection)this.connection);
/*  424 */         oracleTypeADT.tdoCState = (arrayOfShort[i + 7] & 0xFFFFL) << 48L | (arrayOfShort[i + 8] & 0xFFFFL) << 32L | (arrayOfShort[i + 9] & 0xFFFFL) << 16L | arrayOfShort[i + 10] & 0xFFFFL;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  432 */       Accessor accessor = this.accessors[b];
/*      */       
/*  434 */       if (accessor != null && !accessor.useForDescribeIfPossible(s1, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2))
/*      */       {
/*      */ 
/*      */         
/*  438 */         accessor = null;
/*      */       }
/*      */       
/*  441 */       if (accessor == null) {
/*      */         SQLException sQLException;
/*  443 */         switch (s1) {
/*      */ 
/*      */           
/*      */           case 1:
/*  447 */             accessor = new VarcharAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */             
/*  451 */             if (s3 > 0) {
/*  452 */               accessor.setDisplaySize(s3);
/*      */             }
/*      */             break;
/*      */           
/*      */           case 96:
/*  457 */             accessor = new CharAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */             
/*  461 */             if (s3 > 0) {
/*  462 */               accessor.setDisplaySize(s3);
/*      */             }
/*      */             break;
/*      */           
/*      */           case 2:
/*  467 */             accessor = new NumberAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 23:
/*  474 */             accessor = new RawAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 100:
/*  481 */             accessor = new BinaryFloatAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 101:
/*  488 */             accessor = new BinaryDoubleAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/*  495 */             accessor = new LongAccessor(this, b + 1, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  502 */             this.rowPrefetch = 1;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 24:
/*  507 */             accessor = new LongRawAccessor(this, b + 1, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  514 */             this.rowPrefetch = 1;
/*      */             break;
/*      */ 
/*      */           
/*      */           case 104:
/*  519 */             accessor = new RowidAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 102:
/*      */           case 116:
/*  528 */             accessor = new T2CResultSetAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 12:
/*  535 */             accessor = new DateAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 180:
/*  542 */             accessor = new TimestampAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 181:
/*  549 */             accessor = new TimestamptzAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 231:
/*  556 */             accessor = new TimestampltzAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 182:
/*  563 */             accessor = new IntervalymAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 183:
/*  570 */             accessor = new IntervaldsAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 112:
/*  577 */             accessor = new ClobAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 113:
/*  584 */             accessor = new BlobAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 114:
/*  591 */             accessor = new BfileAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 109:
/*  598 */             accessor = new NamedTypeAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2, (OracleType)oracleTypeADT);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 111:
/*  606 */             accessor = new RefTypeAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2, (OracleType)oracleTypeADT);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  615 */             sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unknown or unimplemented accessor type: " + s1);
/*      */             
/*  617 */             sQLException.fillInStackTrace();
/*  618 */             throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  623 */         this.accessors[b] = accessor;
/*      */       }
/*  625 */       else if (oracleTypeADT != null) {
/*      */ 
/*      */ 
/*      */         
/*  629 */         accessor.describeOtype = (OracleType)oracleTypeADT;
/*  630 */         accessor.initMetadata();
/*      */       } 
/*      */       
/*  633 */       accessor.columnName = str1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*      */     boolean bool3;
/*  674 */     this.t2cOutput[0] = 0L;
/*  675 */     this.t2cOutput[2] = 0L;
/*      */ 
/*      */ 
/*      */     
/*  679 */     this.lobPrefetchMetaData = null;
/*      */     
/*  681 */     boolean bool1 = !this.described ? true : false;
/*  682 */     boolean bool2 = false;
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/*  687 */       bool3 = false;
/*      */ 
/*      */       
/*  690 */       if (this.connection.endToEndAnyChanged) {
/*      */         
/*  692 */         pushEndToEndValues();
/*      */         
/*  694 */         this.connection.endToEndAnyChanged = false;
/*      */       } 
/*      */ 
/*      */       
/*  698 */       byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
/*      */       
/*  700 */       int i = 0;
/*      */       
/*      */       try {
/*  703 */         i = t2cParseExecuteDescribe(this, this.c_state, this.numberOfBindPositions, 0, 0, false, this.needToParse, bool1, bool2, arrayOfByte, arrayOfByte.length, convertSqlKindEnumToByte(this.sqlKind), this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, this.ibtBindIndicators, this.ibtBindIndicatorOffset, this.ibtBindIndicatorSize, this.ibtBindBytes, this.ibtBindChars, this.ibtBindByteOffset, this.ibtBindCharOffset, this.returnParamMeta, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, true, true, this.accessors, (byte[][][])null, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.connection.plsqlCompilerWarnings);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  750 */       catch (IOException iOException) {
/*      */ 
/*      */         
/*  753 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
/*  754 */         sQLException.fillInStackTrace();
/*  755 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  760 */       this.validRows = (int)this.t2cOutput[1];
/*      */ 
/*      */       
/*  763 */       if (i == -1 || i == -4) {
/*      */         
/*  765 */         this.connection.checkError(i);
/*      */       }
/*  767 */       else if (i == T2C_EXTEND_BUFFER) {
/*      */         
/*  769 */         i = this.connection.queryMetaData1Size * 2;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  774 */       if (this.t2cOutput[3] != 0L) {
/*      */         
/*  776 */         foundPlsqlCompilerWarning();
/*      */       }
/*  778 */       else if (this.t2cOutput[2] != 0L) {
/*      */         
/*  780 */         this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  785 */       this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4];
/*      */ 
/*      */       
/*  788 */       this.needToParse = false;
/*  789 */       bool2 = true;
/*      */       
/*  791 */       if (this.sqlKind.isSELECT())
/*      */       {
/*  793 */         this.numberOfDefinePositions = i;
/*      */         
/*  795 */         if (this.numberOfDefinePositions > this.connection.queryMetaData1Size)
/*      */         {
/*  797 */           bool3 = true;
/*  798 */           bool2 = true;
/*      */ 
/*      */           
/*  801 */           this.connection.reallocateQueryMetaData(this.numberOfDefinePositions, this.numberOfDefinePositions * 8);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*  808 */         this.numberOfDefinePositions = 0;
/*  809 */         this.validRows = i;
/*      */       }
/*      */     
/*  812 */     } while (bool3);
/*      */     
/*  814 */     processDescribeData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void pushEndToEndValues() throws SQLException {
/*  821 */     T2CConnection t2CConnection = this.connection;
/*  822 */     byte[] arrayOfByte1 = new byte[0];
/*  823 */     byte[] arrayOfByte2 = new byte[0];
/*  824 */     byte[] arrayOfByte3 = new byte[0];
/*  825 */     byte[] arrayOfByte4 = new byte[0];
/*      */     
/*  827 */     if (t2CConnection.endToEndValues != null) {
/*      */       
/*  829 */       if (t2CConnection.endToEndHasChanged[0]) {
/*      */         
/*  831 */         String str = t2CConnection.endToEndValues[0];
/*      */         
/*  833 */         if (str != null) {
/*  834 */           arrayOfByte1 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  837 */         t2CConnection.endToEndHasChanged[0] = false;
/*      */       } 
/*      */       
/*  840 */       if (t2CConnection.endToEndHasChanged[1]) {
/*      */         
/*  842 */         String str = t2CConnection.endToEndValues[1];
/*      */         
/*  844 */         if (str != null) {
/*  845 */           arrayOfByte2 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  848 */         t2CConnection.endToEndHasChanged[1] = false;
/*      */       } 
/*      */       
/*  851 */       if (t2CConnection.endToEndHasChanged[2]) {
/*      */         
/*  853 */         String str = t2CConnection.endToEndValues[2];
/*      */         
/*  855 */         if (str != null) {
/*  856 */           arrayOfByte3 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  859 */         t2CConnection.endToEndHasChanged[2] = false;
/*      */       } 
/*      */       
/*  862 */       if (t2CConnection.endToEndHasChanged[3]) {
/*      */         
/*  864 */         String str = t2CConnection.endToEndValues[3];
/*      */         
/*  866 */         if (str != null) {
/*  867 */           arrayOfByte4 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
/*      */         }
/*      */         
/*  870 */         t2CConnection.endToEndHasChanged[3] = false;
/*      */       } 
/*      */       
/*  873 */       t2cEndToEndUpdate(this.c_state, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, t2CConnection.endToEndECIDSequenceNumber);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*  926 */     if (this.connection.endToEndAnyChanged) {
/*      */       
/*  928 */       pushEndToEndValues();
/*      */       
/*  930 */       this.connection.endToEndAnyChanged = false;
/*      */     } 
/*      */ 
/*      */     
/*  934 */     if (!paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  942 */       if (this.numberOfDefinePositions > 0)
/*      */       {
/*  944 */         doDefineExecuteFetch();
/*      */       }
/*      */       else
/*      */       {
/*  948 */         executeForDescribe();
/*      */       }
/*      */     
/*  951 */     } else if (this.numberOfDefinePositions > 0) {
/*  952 */       doDefineFetch();
/*      */     } 
/*      */ 
/*      */     
/*  956 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setupForDefine() throws SQLException {
/*  966 */     if (this.numberOfDefinePositions > this.connection.queryMetaData1Size) {
/*      */       
/*  968 */       int j = this.numberOfDefinePositions / 100 + 1;
/*      */       
/*  970 */       this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * j, this.connection.queryMetaData2Size * j * 8);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  975 */     short[] arrayOfShort = this.connection.queryMetaData1;
/*  976 */     int i = this.connection.queryMetaData1Offset;
/*      */ 
/*      */     
/*  979 */     for (byte b = 0; b < this.numberOfDefinePositions; 
/*  980 */       b++, i += 13) {
/*      */       
/*  982 */       Accessor accessor = this.accessors[b];
/*      */       
/*  984 */       if (accessor == null) {
/*      */         
/*  986 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  987 */         sQLException.fillInStackTrace();
/*  988 */         throw sQLException;
/*      */       } 
/*      */       
/*  991 */       arrayOfShort[i + 0] = (short)accessor.defineType;
/*      */       
/*  993 */       arrayOfShort[i + 11] = (short)accessor.charLength;
/*      */       
/*  995 */       arrayOfShort[i + 1] = (short)accessor.byteLength;
/*      */       
/*  997 */       arrayOfShort[i + 5] = accessor.formOfUse;
/*      */ 
/*      */       
/* 1000 */       if (accessor.internalOtype != null) {
/*      */         
/* 1002 */         long l = ((OracleTypeADT)accessor.internalOtype).getTdoCState();
/*      */ 
/*      */         
/* 1005 */         arrayOfShort[i + 7] = (short)(int)((l & 0xFFFF000000000000L) >> 48L);
/*      */         
/* 1007 */         arrayOfShort[i + 8] = (short)(int)((l & 0xFFFF00000000L) >> 32L);
/*      */         
/* 1009 */         arrayOfShort[i + 9] = (short)(int)((l & 0xFFFF0000L) >> 16L);
/*      */         
/* 1011 */         arrayOfShort[i + 10] = (short)(int)(l & 0xFFFFL);
/*      */       } 
/*      */ 
/*      */       
/* 1015 */       switch (accessor.internalType) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 112:
/*      */         case 113:
/* 1021 */           if (accessor.lobPrefetchSizeForThisColumn == -1) {
/* 1022 */             accessor.lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/*      */           }
/*      */           
/* 1025 */           arrayOfShort[i + 7] = (short)accessor.lobPrefetchSizeForThisColumn;
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object[] getLobPrefetchMetaData() {
/* 1045 */     Object[] arrayOfObject = null;
/* 1046 */     Object object = null;
/* 1047 */     int[] arrayOfInt = null;
/* 1048 */     byte b1 = 0;
/* 1049 */     byte b2 = 0;
/*      */     
/* 1051 */     if (this.accessors != null) {
/* 1052 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */         
/* 1054 */         switch ((this.accessors[b]).internalType) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 24:
/* 1061 */             b2 = b;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 112:
/*      */           case 113:
/* 1068 */             if (arrayOfInt == null)
/*      */             {
/* 1070 */               arrayOfInt = new int[this.accessors.length];
/*      */             }
/*      */             
/* 1073 */             if ((this.accessors[b]).lobPrefetchSizeForThisColumn != -1) {
/*      */               
/* 1075 */               b1++;
/*      */               
/* 1077 */               arrayOfInt[b] = (this.accessors[b]).lobPrefetchSizeForThisColumn;
/*      */               
/*      */               break;
/*      */             } 
/* 1081 */             arrayOfInt[b] = -1;
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/*      */     }
/* 1089 */     if (b1 > 0) {
/*      */       
/* 1091 */       if (arrayOfObject == null)
/*      */       {
/* 1093 */         arrayOfObject = new Object[] { null, new long[this.rowPrefetch * b1], new byte[this.accessors.length], new int[this.accessors.length], new Object[this.rowPrefetch * b1] };
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1115 */       for (byte b = 0; b < b2; b++) {
/*      */         
/* 1117 */         switch ((this.accessors[b]).internalType) {
/*      */           
/*      */           case 112:
/*      */           case 113:
/* 1121 */             (this.accessors[b]).lobPrefetchSizeForThisColumn = -1;
/* 1122 */             arrayOfInt[b] = -1;
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/* 1127 */       arrayOfObject[0] = arrayOfInt;
/*      */     } 
/*      */ 
/*      */     
/* 1131 */     return arrayOfObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processLobPrefetchMetaData(Object[] paramArrayOfObject) {
/* 1138 */     byte b1 = 0;
/* 1139 */     byte b2 = (this.validRows == -2) ? 1 : this.validRows;
/*      */     
/* 1141 */     byte[] arrayOfByte = (byte[])paramArrayOfObject[2];
/* 1142 */     int[] arrayOfInt1 = (int[])paramArrayOfObject[3];
/* 1143 */     long[] arrayOfLong = (long[])paramArrayOfObject[1];
/* 1144 */     Object[] arrayOfObject = (Object[])paramArrayOfObject[4];
/* 1145 */     int[] arrayOfInt2 = (int[])paramArrayOfObject[0];
/*      */     
/* 1147 */     if (this.accessors != null) {
/* 1148 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */         
/* 1150 */         switch ((this.accessors[b]).internalType) {
/*      */ 
/*      */           
/*      */           case 112:
/*      */           case 113:
/* 1155 */             if ((this.accessors[b]).lobPrefetchSizeForThisColumn >= 0) {
/*      */               
/* 1157 */               Accessor accessor = this.accessors[b];
/*      */               
/* 1159 */               if (accessor.prefetchedLobDataL == null || accessor.prefetchedLobDataL.length < this.rowPrefetch) {
/*      */ 
/*      */                 
/* 1162 */                 if (accessor.internalType == 112) {
/* 1163 */                   accessor.prefetchedLobCharData = new char[this.rowPrefetch][];
/*      */                 } else {
/* 1165 */                   accessor.prefetchedLobData = new byte[this.rowPrefetch][];
/*      */                 } 
/* 1167 */                 accessor.prefetchedLobChunkSize = new int[this.rowPrefetch];
/* 1168 */                 accessor.prefetchedClobFormOfUse = new byte[this.rowPrefetch];
/* 1169 */                 accessor.prefetchedLobDataL = new int[this.rowPrefetch];
/* 1170 */                 accessor.prefetchedLobSize = new long[this.rowPrefetch];
/*      */               } 
/*      */               
/* 1173 */               int i = b2 * b1;
/* 1174 */               for (byte b3 = 0; b3 < b2; b3++) {
/*      */                 
/* 1176 */                 accessor.prefetchedLobChunkSize[b3] = arrayOfInt1[b];
/*      */                 
/* 1178 */                 accessor.prefetchedClobFormOfUse[b3] = arrayOfByte[b];
/*      */ 
/*      */                 
/* 1181 */                 accessor.prefetchedLobSize[b3] = arrayOfLong[i + b3];
/*      */ 
/*      */                 
/* 1184 */                 accessor.prefetchedLobDataL[b3] = 0;
/* 1185 */                 if (arrayOfInt2[b] > 0 && arrayOfLong[i + b3] > 0L)
/*      */                 {
/*      */                   
/* 1188 */                   if (accessor.internalType == 112) {
/*      */                     
/* 1190 */                     accessor.prefetchedLobCharData[b3] = (char[])arrayOfObject[i + b3];
/*      */                     
/* 1192 */                     if (accessor.prefetchedLobCharData[b3] != null) {
/* 1193 */                       accessor.prefetchedLobDataL[b3] = (accessor.prefetchedLobCharData[b3]).length;
/*      */                     }
/*      */                   }
/*      */                   else {
/*      */                     
/* 1198 */                     accessor.prefetchedLobData[b3] = (byte[])arrayOfObject[i + b3];
/*      */                     
/* 1200 */                     if (accessor.prefetchedLobData[b3] != null) {
/* 1201 */                       accessor.prefetchedLobDataL[b3] = (accessor.prefetchedLobData[b3]).length;
/*      */                     }
/*      */                   } 
/*      */                 }
/*      */               } 
/* 1206 */               b1++;
/*      */             } 
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDefineFetch() throws SQLException {
/* 1219 */     if (!this.needToPrepareDefineBuffer) {
/* 1220 */       throw new Error("doDefineFetch called when needToPrepareDefineBuffer=false " + this.sqlObject.getSql(this.processEscapes, this.convertNcharLiterals));
/*      */     }
/*      */     
/* 1223 */     setupForDefine();
/*      */     
/* 1225 */     this.t2cOutput[2] = 0L;
/* 1226 */     this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1227 */     this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1228 */     if (this.connection.useNio) {
/* 1229 */       resetNioAttributesBeforeFetch();
/* 1230 */       allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1236 */     if (this.lobPrefetchMetaData == null) {
/* 1237 */       this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */     }
/* 1239 */     this.validRows = t2cDefineFetch(this, this.c_state, this.rowPrefetch, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1252 */     if (this.validRows == -1 || this.validRows == -4) {
/* 1253 */       this.connection.checkError(this.validRows);
/*      */     }
/*      */     
/* 1256 */     if (this.t2cOutput[2] != 0L)
/*      */     {
/* 1258 */       this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */     }
/*      */ 
/*      */     
/* 1262 */     if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */     {
/* 1264 */       extractNioDefineBuffers(0);
/*      */     }
/* 1266 */     if (this.lobPrefetchMetaData != null)
/*      */     {
/* 1268 */       processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateNioBuffersIfRequired(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1278 */     if (this.nioBuffers == null) {
/* 1279 */       this.nioBuffers = new ByteBuffer[4];
/*      */     }
/* 1281 */     if (paramInt2 > 0)
/*      */     {
/* 1283 */       if (this.nioBuffers[0] == null || this.nioBuffers[0].capacity() < paramInt2) {
/*      */ 
/*      */         
/* 1286 */         this.nioBuffers[0] = ByteBuffer.allocateDirect(paramInt2);
/* 1287 */       } else if (this.nioBuffers[0] != null) {
/*      */         
/* 1289 */         this.nioBuffers[0].rewind();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1296 */     paramInt1 *= 2;
/* 1297 */     if (paramInt1 > 0)
/*      */     {
/* 1299 */       if (this.nioBuffers[1] == null || this.nioBuffers[1].capacity() < paramInt1) {
/*      */ 
/*      */         
/* 1302 */         this.nioBuffers[1] = ByteBuffer.allocateDirect(paramInt1);
/* 1303 */       } else if (this.nioBuffers[1] != null) {
/*      */         
/* 1305 */         this.nioBuffers[1].rewind();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1312 */     paramInt3 *= 2;
/* 1313 */     if (paramInt3 > 0)
/*      */     {
/* 1315 */       if (this.nioBuffers[2] == null || this.nioBuffers[2].capacity() < paramInt3) {
/*      */ 
/*      */         
/* 1318 */         this.nioBuffers[2] = ByteBuffer.allocateDirect(paramInt3);
/* 1319 */       } else if (this.nioBuffers[2] != null) {
/*      */         
/* 1321 */         this.nioBuffers[2].rewind();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDefineExecuteFetch() throws SQLException {
/* 1330 */     short[] arrayOfShort = null;
/*      */     
/* 1332 */     if (this.needToPrepareDefineBuffer || this.needToParse) {
/*      */       
/* 1334 */       setupForDefine();
/*      */       
/* 1336 */       arrayOfShort = this.connection.queryMetaData1;
/*      */     } 
/*      */     
/* 1339 */     this.t2cOutput[0] = 0L;
/* 1340 */     this.t2cOutput[2] = 0L;
/*      */     
/* 1342 */     byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
/* 1343 */     this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1344 */     this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1345 */     if (this.connection.useNio) {
/* 1346 */       resetNioAttributesBeforeFetch();
/* 1347 */       allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1353 */     if (this.lobPrefetchMetaData == null) {
/* 1354 */       this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */     }
/*      */     try {
/* 1357 */       this.validRows = t2cDefineExecuteFetch(this, this.c_state, this.numberOfDefinePositions, this.numberOfBindPositions, 0, 0, false, this.needToParse, arrayOfByte, arrayOfByte.length, convertSqlKindEnumToByte(this.sqlKind), this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, arrayOfShort, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, true, true, this.accessors, (byte[][][])null, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1395 */     catch (IOException iOException) {
/*      */       
/* 1397 */       this.validRows = 0;
/*      */       
/* 1399 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1400 */       sQLException.fillInStackTrace();
/* 1401 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1405 */     if (this.validRows == -1) {
/* 1406 */       this.connection.checkError(this.validRows);
/*      */     }
/* 1408 */     if (this.t2cOutput[2] != 0L) {
/* 1409 */       this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1414 */     this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4];
/*      */     
/* 1416 */     if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */     {
/* 1418 */       extractNioDefineBuffers(0);
/*      */     }
/* 1420 */     if (this.lobPrefetchMetaData != null)
/*      */     {
/* 1422 */       processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */     }
/*      */     
/* 1425 */     this.needToParse = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1468 */     if (this.numberOfDefinePositions > 0)
/*      */     {
/* 1470 */       if (this.needToPrepareDefineBuffer) {
/* 1471 */         doDefineFetch();
/*      */       } else {
/*      */         
/* 1474 */         this.t2cOutput[2] = 0L;
/* 1475 */         this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
/* 1476 */         this.t2cOutput[6] = this.defaultLobPrefetchSize;
/* 1477 */         if (this.connection.useNio) {
/* 1478 */           resetNioAttributesBeforeFetch();
/* 1479 */           allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1486 */         if (this.lobPrefetchMetaData == null) {
/* 1487 */           this.lobPrefetchMetaData = getLobPrefetchMetaData();
/*      */         }
/* 1489 */         this.validRows = t2cFetch(this.c_state, this.needToPrepareDefineBuffer, this.rowPrefetch, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1497 */         if (this.validRows == -1 || this.validRows == -4) {
/* 1498 */           this.connection.checkError(this.validRows);
/*      */         }
/* 1500 */         if (this.t2cOutput[2] != 0L)
/*      */         {
/* 1502 */           this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */         }
/*      */         
/* 1505 */         if (this.lobPrefetchMetaData != null)
/*      */         {
/* 1507 */           processLobPrefetchMetaData(this.lobPrefetchMetaData);
/*      */         }
/* 1509 */         if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
/*      */         {
/* 1511 */           extractNioDefineBuffers(0);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void resetNioAttributesBeforeFetch() {
/* 1520 */     this.extractedCharOffset = 0;
/* 1521 */     this.extractedByteOffset = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void extractNioDefineBuffers(int paramInt) throws SQLException {
/* 1530 */     if (this.accessors == null || this.defineIndicators == null || paramInt == this.numberOfDefinePositions) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1535 */     int i = 0;
/* 1536 */     int j = 0;
/* 1537 */     int k = 0;
/* 1538 */     int m = 0;
/* 1539 */     int n = 0;
/*      */ 
/*      */     
/* 1542 */     if (!this.hasStream) {
/*      */       
/* 1544 */       i = (this.defineBytes != null) ? this.defineBytes.length : 0;
/* 1545 */       j = (this.defineChars != null) ? this.defineChars.length : 0;
/* 1546 */       k = this.defineIndicators.length;
/*      */     }
/*      */     else {
/*      */       
/* 1550 */       if (this.numberOfDefinePositions > paramInt) {
/*      */         
/* 1552 */         n = (this.accessors[paramInt]).indicatorIndex;
/* 1553 */         m = (this.accessors[paramInt]).lengthIndex;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1558 */       for (int i1 = paramInt; i1 < this.numberOfDefinePositions; i1++) {
/*      */         
/* 1560 */         switch ((this.accessors[i1]).internalType) {
/*      */           case 8:
/*      */           case 24:
/*      */             break;
/*      */         } 
/*      */         
/* 1566 */         i += (this.accessors[i1]).byteLength;
/* 1567 */         j += (this.accessors[i1]).charLength;
/* 1568 */         k++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1573 */     ByteBuffer byteBuffer = this.nioBuffers[0];
/* 1574 */     if (byteBuffer != null && this.defineBytes != null)
/*      */     {
/* 1576 */       if (i > 0) {
/*      */         
/* 1578 */         byteBuffer.position(this.extractedByteOffset);
/* 1579 */         byteBuffer.get(this.defineBytes, this.extractedByteOffset, i);
/* 1580 */         this.extractedByteOffset += i;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1595 */     if (this.nioBuffers[1] != null && this.defineChars != null) {
/*      */       
/* 1597 */       byteBuffer = this.nioBuffers[1].order(ByteOrder.LITTLE_ENDIAN);
/* 1598 */       CharBuffer charBuffer = byteBuffer.asCharBuffer();
/*      */       
/* 1600 */       if (j > 0) {
/*      */         
/* 1602 */         charBuffer.position(this.extractedCharOffset);
/* 1603 */         charBuffer.get(this.defineChars, this.extractedCharOffset, j);
/* 1604 */         this.extractedCharOffset += j;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1623 */     if (this.nioBuffers[2] != null) {
/* 1624 */       byteBuffer = this.nioBuffers[2].order(ByteOrder.LITTLE_ENDIAN);
/* 1625 */       ShortBuffer shortBuffer = byteBuffer.asShortBuffer();
/* 1626 */       if (this.hasStream) {
/*      */         
/* 1628 */         if (k > 0) {
/*      */           
/* 1630 */           shortBuffer.position(n);
/* 1631 */           shortBuffer.get(this.defineIndicators, n, k);
/* 1632 */           shortBuffer.position(m);
/* 1633 */           shortBuffer.get(this.defineIndicators, m, k);
/*      */         } 
/*      */       } else {
/*      */         
/* 1637 */         shortBuffer.get(this.defineIndicators);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1685 */     if (this.defineBytes != null) {
/*      */       
/* 1687 */       this.defineBytes = null;
/* 1688 */       this.accessorByteOffset = 0;
/*      */     } 
/*      */     
/* 1691 */     if (this.defineChars != null) {
/*      */       
/* 1693 */       this.defineChars = null;
/* 1694 */       this.accessorCharOffset = 0;
/*      */     } 
/*      */     
/* 1697 */     if (this.defineIndicators != null) {
/*      */       
/* 1699 */       this.defineIndicators = null;
/* 1700 */       this.accessorShortOffset = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1704 */     int i = t2cCloseStatement(this.c_state);
/*      */     
/* 1706 */     this.nioBuffers = null;
/*      */     
/* 1708 */     if (i != 0) {
/* 1709 */       this.connection.checkError(i);
/*      */     }
/* 1711 */     this.t2cOutput = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1729 */     if (this.streamList != null)
/*      */     {
/* 1731 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1735 */           this.nextStream.close();
/*      */         }
/* 1737 */         catch (IOException iOException) {
/*      */ 
/*      */           
/* 1740 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1741 */           sQLException.fillInStackTrace();
/* 1742 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1746 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException {
/* 1763 */     if (paramInt1 == 116 || paramInt1 == 102) {
/*      */ 
/*      */       
/* 1766 */       if (paramBoolean && paramString != null) {
/*      */         
/* 1768 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 1769 */         sQLException.fillInStackTrace();
/* 1770 */         throw sQLException;
/*      */       } 
/*      */       
/* 1773 */       return new T2CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1779 */     return super.allocateAccessor(paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramString, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeUsedStreams(int paramInt) throws SQLException {
/* 1787 */     while (this.nextStream != null && this.nextStream.columnIndex < paramInt) {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 1793 */         this.nextStream.close();
/*      */       }
/* 1795 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 1798 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1799 */         sQLException.fillInStackTrace();
/* 1800 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1804 */       this.nextStream = this.nextStream.nextStream;
/*      */     } 
/*      */     
/* 1807 */     if (this.nextStream != null) {
/*      */       
/*      */       try {
/* 1810 */         this.nextStream.needBytes();
/*      */       }
/* 1812 */       catch (IOException iOException) {
/*      */         
/* 1814 */         interalCloseOnIOException(iOException);
/*      */         
/* 1816 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1817 */         sQLException.fillInStackTrace();
/* 1818 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void interalCloseOnIOException(IOException paramIOException) throws SQLException {
/* 1827 */     this.closed = true;
/*      */     
/* 1829 */     if (this.currentResultSet != null) {
/* 1830 */       this.currentResultSet.closed = true;
/*      */     }
/* 1832 */     doClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetchDmlReturnParams() throws SQLException {
/* 1839 */     this.rowsDmlReturned = t2cGetRowsDmlReturned(this.c_state);
/*      */     
/* 1841 */     if (this.rowsDmlReturned != 0) {
/*      */       
/* 1843 */       allocateDmlReturnStorage();
/*      */       
/* 1845 */       int i = t2cFetchDmlReturnParams(this.c_state, this.returnParamAccessors, this.returnParamBytes, this.returnParamChars, this.returnParamIndicators);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1853 */       if (i == -1 || i == -4) {
/* 1854 */         this.connection.checkError(i);
/*      */       }
/*      */       
/* 1857 */       if (this.t2cOutput[2] != 0L)
/*      */       {
/* 1859 */         this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
/*      */       }
/*      */ 
/*      */       
/* 1863 */       if (this.connection.useNio && (i > 0 || i == -2))
/*      */       {
/* 1865 */         extractNioDefineBuffers(0);
/*      */       }
/*      */     } 
/* 1868 */     this.returnParamsFetched = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1879 */   static int PREAMBLE_PER_POSITION = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initializeIndicatorSubRange() {
/* 1885 */     this.bindIndicatorSubRange = this.numberOfBindPositions * PREAMBLE_PER_POSITION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int calculateIndicatorSubRangeSize() {
/* 1892 */     return this.numberOfBindPositions * PREAMBLE_PER_POSITION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   short getInoutIndicator(int paramInt) {
/* 1899 */     return this.bindIndicators[paramInt * PREAMBLE_PER_POSITION];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*      */     boolean bool;
/* 1918 */     if (this.closed) {
/*      */       
/* 1920 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1921 */       sQLException.fillInStackTrace();
/* 1922 */       throw sQLException;
/*      */     } 
/*      */     
/* 1925 */     if (this.described == true) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1930 */     if (!this.isOpen) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1935 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 1936 */       sQLException.fillInStackTrace();
/* 1937 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 1946 */       bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1955 */       boolean bool1 = (this.sqlKind.isSELECT() && this.needToParse && (!this.described || !this.serverCursor)) ? true : false;
/* 1956 */       byte[] arrayOfByte = bool1 ? this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals) : PhysicalConnection.EMPTY_BYTE_ARRAY;
/* 1957 */       this.numberOfDefinePositions = t2cDescribe(this.c_state, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, arrayOfByte, arrayOfByte.length, bool1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1968 */       if (!this.described) {
/* 1969 */         this.described = true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1976 */       if (this.numberOfDefinePositions == -1)
/*      */       {
/* 1978 */         this.connection.checkError(this.numberOfDefinePositions);
/*      */       }
/*      */ 
/*      */       
/* 1982 */       if (this.numberOfDefinePositions != T2C_EXTEND_BUFFER)
/*      */         continue; 
/* 1984 */       bool = true;
/*      */ 
/*      */ 
/*      */       
/* 1988 */       this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * 2, this.connection.queryMetaData2Size * 2);
/*      */ 
/*      */     
/*      */     }
/* 1992 */     while (bool);
/*      */     
/* 1994 */     processDescribeData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2000 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\T2CStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */