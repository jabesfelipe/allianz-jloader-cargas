/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.TimeZone;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DateTimeCommonAccessor
/*     */   extends Accessor
/*     */ {
/*     */   static final int GREGORIAN_CUTOVER_YEAR = 1582;
/*     */   static final long GREGORIAN_CUTOVER = -12219292800000L;
/*     */   static final int JAN_1_1_JULIAN_DAY = 1721426;
/*     */   static final int EPOCH_JULIAN_DAY = 2440588;
/*     */   static final int ONE_SECOND = 1000;
/*     */   static final int ONE_MINUTE = 60000;
/*     */   static final int ONE_HOUR = 3600000;
/*     */   static final long ONE_DAY = 86400000L;
/*  42 */   static final int[] NUM_DAYS = new int[] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   static final int[] LEAP_NUM_DAYS = new int[] { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 };
/*     */   
/*     */   static final int ORACLE_CENTURY = 0;
/*     */   
/*     */   static final int ORACLE_YEAR = 1;
/*     */   
/*     */   static final int ORACLE_MONTH = 2;
/*     */   
/*     */   static final int ORACLE_DAY = 3;
/*     */   
/*     */   static final int ORACLE_HOUR = 4;
/*     */   
/*     */   static final int ORACLE_MIN = 5;
/*     */   
/*     */   static final int ORACLE_SEC = 6;
/*     */   
/*     */   static final int ORACLE_NANO1 = 7;
/*     */   
/*     */   static final int ORACLE_NANO2 = 8;
/*     */   
/*     */   static final int ORACLE_NANO3 = 9;
/*     */   static final int ORACLE_NANO4 = 10;
/*     */   static final int ORACLE_TZ1 = 11;
/*     */   static final int ORACLE_TZ2 = 12;
/*     */   static final int SIZE_DATE = 7;
/*     */   static final int MAX_TIMESTAMP_LENGTH = 11;
/*     */   static TimeZone epochTimeZone;
/*     */   static long epochTimeZoneOffset;
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/*  77 */     Time time = null;
/*     */     
/*  79 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/*  83 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  84 */       sQLException.fillInStackTrace();
/*  85 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*  93 */       int i = this.columnIndex + this.byteLength * paramInt;
/*     */ 
/*     */ 
/*     */       
/*  97 */       TimeZone timeZone = this.statement.getDefaultTimeZone();
/*     */       
/*  99 */       if (timeZone != epochTimeZone) {
/*     */         
/* 101 */         epochTimeZoneOffset = calculateEpochOffset(timeZone);
/* 102 */         epochTimeZone = timeZone;
/*     */       } 
/*     */       
/* 105 */       time = new Time(oracleTime(i) - epochTimeZoneOffset);
/*     */     } 
/*     */     
/* 108 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 117 */     return getDate(paramInt, this.statement.getDefaultCalendar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 126 */     if (paramCalendar == null) {
/* 127 */       return getDate(paramInt);
/*     */     }
/* 129 */     Date date = null;
/*     */     
/* 131 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 135 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 136 */       sQLException.fillInStackTrace();
/* 137 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 145 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 146 */       int j = ((this.rowSpaceByte[0 + i] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + i] & 0xFF) - 100;
/*     */ 
/*     */       
/* 149 */       paramCalendar.set(j, oracleMonth(i), oracleDay(i), 0, 0, 0);
/* 150 */       paramCalendar.set(14, 0);
/*     */ 
/*     */ 
/*     */       
/* 154 */       if (j > 0 && paramCalendar.isSet(0)) {
/* 155 */         paramCalendar.set(0, 1);
/*     */       }
/* 157 */       date = new Date(paramCalendar.getTimeInMillis());
/*     */     } 
/*     */     
/* 160 */     return date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 169 */     if (paramCalendar == null) {
/* 170 */       return getTime(paramInt);
/*     */     }
/* 172 */     Time time = null;
/*     */     
/* 174 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 178 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 179 */       sQLException.fillInStackTrace();
/* 180 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 188 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 189 */       int j = ((this.rowSpaceByte[0 + i] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + i] & 0xFF) - 100;
/*     */ 
/*     */       
/* 192 */       paramCalendar.set(1, 1970);
/* 193 */       paramCalendar.set(2, 0);
/* 194 */       paramCalendar.set(5, 1);
/* 195 */       paramCalendar.set(11, oracleHour(i));
/* 196 */       paramCalendar.set(12, oracleMin(i));
/* 197 */       paramCalendar.set(13, oracleSec(i));
/* 198 */       paramCalendar.set(14, 0);
/*     */ 
/*     */ 
/*     */       
/* 202 */       if (j > 0 && paramCalendar.isSet(0)) {
/* 203 */         paramCalendar.set(0, 1);
/*     */       }
/*     */       
/* 206 */       time = new Time(paramCalendar.getTimeInMillis());
/*     */     } 
/*     */     
/* 209 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 217 */     return getTimestamp(paramInt, this.statement.getDefaultCalendar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 226 */     if (paramCalendar == null) {
/* 227 */       return getTimestamp(paramInt);
/*     */     }
/* 229 */     Timestamp timestamp = null;
/*     */     
/* 231 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 235 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 236 */       sQLException.fillInStackTrace();
/* 237 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 245 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 246 */       int j = ((this.rowSpaceByte[0 + i] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + i] & 0xFF) - 100;
/*     */ 
/*     */       
/* 249 */       paramCalendar.set(j, oracleMonth(i), oracleDay(i), oracleHour(i), oracleMin(i), oracleSec(i));
/*     */       
/* 251 */       paramCalendar.set(14, 0);
/*     */ 
/*     */ 
/*     */       
/* 255 */       if (j > 0 && paramCalendar.isSet(0)) {
/* 256 */         paramCalendar.set(0, 1);
/*     */       }
/* 258 */       timestamp = new Timestamp(paramCalendar.getTimeInMillis());
/*     */       
/* 260 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 261 */       if (s >= 11)
/*     */       {
/* 263 */         timestamp.setNanos(oracleNanos(i));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 268 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException {
/* 278 */     DATE dATE = null;
/*     */     
/* 280 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 284 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 285 */       sQLException.fillInStackTrace();
/* 286 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 294 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 295 */       byte[] arrayOfByte = new byte[7];
/*     */       
/* 297 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, 7);
/*     */       
/* 299 */       dATE = new DATE(arrayOfByte);
/*     */     } 
/*     */     
/* 302 */     return dATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 310 */     TIMESTAMP tIMESTAMP = null;
/*     */     
/* 312 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 316 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 317 */       sQLException.fillInStackTrace();
/* 318 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 326 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 327 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 328 */       byte[] arrayOfByte = new byte[s];
/* 329 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/* 330 */       tIMESTAMP = new TIMESTAMP(arrayOfByte);
/*     */     } 
/*     */     
/* 333 */     return tIMESTAMP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleYear(int paramInt) {
/* 341 */     int i = ((this.rowSpaceByte[0 + paramInt] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + paramInt] & 0xFF) - 100;
/*     */ 
/*     */ 
/*     */     
/* 345 */     return (i <= 0) ? (i + 1) : i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleMonth(int paramInt) {
/* 353 */     return this.rowSpaceByte[2 + paramInt] - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleDay(int paramInt) {
/* 361 */     return this.rowSpaceByte[3 + paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleHour(int paramInt) {
/* 369 */     return this.rowSpaceByte[4 + paramInt] - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleMin(int paramInt) {
/* 377 */     return this.rowSpaceByte[5 + paramInt] - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleSec(int paramInt) {
/* 385 */     return this.rowSpaceByte[6 + paramInt] - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleTZ1(int paramInt) {
/* 393 */     return this.rowSpaceByte[11 + paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleTZ2(int paramInt) {
/* 401 */     return this.rowSpaceByte[12 + paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleTime(int paramInt) {
/* 408 */     int i = oracleHour(paramInt);
/*     */     
/* 410 */     i *= 60;
/* 411 */     i += oracleMin(paramInt);
/* 412 */     i *= 60;
/* 413 */     i += oracleSec(paramInt);
/* 414 */     i *= 1000;
/*     */     
/* 416 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int oracleNanos(int paramInt) {
/* 423 */     int i = (this.rowSpaceByte[7 + paramInt] & 0xFF) << 24;
/*     */     
/* 425 */     i |= (this.rowSpaceByte[8 + paramInt] & 0xFF) << 16;
/* 426 */     i |= (this.rowSpaceByte[9 + paramInt] & 0xFF) << 8;
/* 427 */     i |= this.rowSpaceByte[10 + paramInt] & 0xFF & 0xFF;
/*     */     
/* 429 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final long computeJulianDay(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
/* 437 */     boolean bool = (paramInt1 % 4 == 0) ? true : false;
/* 438 */     int i = paramInt1 - 1;
/* 439 */     long l = 365L * i + floorDivide(i, 4L) + 1721423L;
/*     */     
/* 441 */     if (paramBoolean) {
/*     */       
/* 443 */       bool = (bool && (paramInt1 % 100 != 0 || paramInt1 % 400 == 0)) ? true : false;
/*     */ 
/*     */       
/* 446 */       l += floorDivide(i, 400L) - floorDivide(i, 100L) + 2L;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 453 */     return l + paramInt3 + (bool ? LEAP_NUM_DAYS[paramInt2] : NUM_DAYS[paramInt2]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final long floorDivide(long paramLong1, long paramLong2) {
/* 460 */     return (paramLong1 >= 0L) ? (paramLong1 / paramLong2) : ((paramLong1 + 1L) / paramLong2 - 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final long julianDayToMillis(long paramLong) {
/* 468 */     return (paramLong - 2440588L) * 86400000L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final long zoneOffset(TimeZone paramTimeZone, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 478 */     return paramTimeZone.getOffset((paramInt1 < 0) ? 0 : 1, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long getMillis(int paramInt1, int paramInt2, int paramInt3, int paramInt4, TimeZone paramTimeZone) {
/* 499 */     boolean bool = (paramInt1 >= 1582) ? true : false;
/* 500 */     long l1 = computeJulianDay(bool, paramInt1, paramInt2, paramInt3);
/* 501 */     long l2 = (l1 - 2440588L) * 86400000L;
/*     */ 
/*     */ 
/*     */     
/* 505 */     if (bool != ((l2 >= -12219292800000L) ? true : false)) {
/*     */       
/* 507 */       l1 = computeJulianDay(!bool, paramInt1, paramInt2, paramInt3);
/* 508 */       l2 = (l1 - 2440588L) * 86400000L;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 513 */     l2 += paramInt4;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 518 */     return l2 - zoneOffset(paramTimeZone, paramInt1, paramInt2, paramInt3, julianDayToDayOfWeek(l1), paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int julianDayToDayOfWeek(long paramLong) {
/* 536 */     int i = (int)((paramLong + 1L) % 7L);
/*     */     
/* 538 */     return i + ((i < 0) ? 8 : 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long calculateEpochOffset(TimeZone paramTimeZone) {
/* 557 */     return zoneOffset(paramTimeZone, 1970, 0, 1, 5, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString) throws SQLException {
/* 572 */     return TIMESTAMPTZ.toString(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 585 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\DateTimeCommonAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */