/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFListener
/*     */   extends Thread
/*     */ {
/*  50 */   private NTFConnection[] connections = null;
/*  51 */   private int nbOfConnections = 0;
/*     */   
/*     */   private boolean needsToBeClosed = false;
/*     */   
/*     */   NTFManager dcnManager;
/*     */   ServerSocketChannel ssChannel;
/*     */   int tcpport;
/*     */   
/*     */   NTFListener(NTFManager paramNTFManager, ServerSocketChannel paramServerSocketChannel, int paramInt) {
/*  60 */     this.dcnManager = paramNTFManager;
/*  61 */     this.connections = new NTFConnection[10];
/*  62 */     this.ssChannel = paramServerSocketChannel;
/*  63 */     this.tcpport = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*  72 */       Selector selector = Selector.open();
/*  73 */       this.ssChannel.register(selector, 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/*  80 */         selector.select();
/*  81 */         if (this.needsToBeClosed) {
/*     */           break;
/*     */         }
/*  84 */         Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
/*  85 */         while (iterator.hasNext()) {
/*     */           
/*  87 */           SelectionKey selectionKey = iterator.next();
/*     */           
/*  89 */           if ((selectionKey.readyOps() & 0x10) == 16) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  94 */             ServerSocketChannel serverSocketChannel = (ServerSocketChannel)selectionKey.channel();
/*     */             
/*  96 */             SocketChannel socketChannel = serverSocketChannel.accept();
/*  97 */             NTFConnection nTFConnection = new NTFConnection(this.dcnManager, socketChannel);
/*     */ 
/*     */             
/* 100 */             if (this.connections.length == this.nbOfConnections) {
/*     */ 
/*     */               
/* 103 */               NTFConnection[] arrayOfNTFConnection = new NTFConnection[this.connections.length * 2];
/* 104 */               System.arraycopy(this.connections, 0, arrayOfNTFConnection, 0, this.connections.length);
/* 105 */               this.connections = arrayOfNTFConnection;
/*     */             } 
/* 107 */             this.connections[this.nbOfConnections++] = nTFConnection;
/* 108 */             nTFConnection.start();
/* 109 */             iterator.remove();
/*     */           } 
/*     */         } 
/*     */       } 
/* 113 */       selector.close();
/* 114 */       this.ssChannel.close();
/*     */     }
/* 116 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void closeThisListener() {
/* 128 */     for (byte b = 0; b < this.nbOfConnections; b++) {
/*     */       
/* 130 */       this.connections[b].closeThisConnection();
/* 131 */       this.connections[b].interrupt();
/*     */     } 
/* 133 */     this.needsToBeClosed = true;
/*     */   }
/*     */ 
/*     */   
/* 137 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\NTFListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */