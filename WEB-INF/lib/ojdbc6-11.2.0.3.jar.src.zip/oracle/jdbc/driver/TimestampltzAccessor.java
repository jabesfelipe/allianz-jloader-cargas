/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.OffsetDST;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPLTZ;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ import oracle.sql.TIMEZONETAB;
/*     */ import oracle.sql.ZONEIDMAP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimestampltzAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  35 */     init(paramOracleStatement, 231, 231, paramShort, paramBoolean);
/*  36 */     initForDataAccess(paramInt2, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  45 */     init(paramOracleStatement, 231, 231, paramShort, false);
/*  46 */     initForDescribe(231, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  48 */     initForDataAccess(0, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  56 */     if (paramInt1 != 0) {
/*  57 */       this.externalType = paramInt1;
/*     */     }
/*  59 */     this.internalTypeMaxLength = 11;
/*     */     
/*  61 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*  62 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  64 */     this.byteLength = this.internalTypeMaxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*  72 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/*  76 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  77 */       sQLException.fillInStackTrace();
/*  78 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/*  92 */     String str1 = this.statement.connection.getSessionTimeZone();
/*     */     
/*  94 */     if (str1 == null) {
/*     */ 
/*     */       
/*  97 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/*  98 */       sQLException.fillInStackTrace();
/*  99 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 103 */     TimeZone timeZone = TimeZone.getTimeZone(str1);
/*     */     
/* 105 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 107 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 108 */     short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*     */     
/* 110 */     int j = ((this.rowSpaceByte[0 + i] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + i] & 0xFF) - 100;
/*     */ 
/*     */     
/* 113 */     calendar1.set(1, j);
/* 114 */     calendar1.set(2, oracleMonth(i));
/* 115 */     calendar1.set(5, oracleDay(i));
/* 116 */     calendar1.set(11, oracleHour(i));
/* 117 */     calendar1.set(12, oracleMin(i));
/* 118 */     calendar1.set(13, oracleSec(i));
/* 119 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/* 122 */     TimeZoneAdjust(calendar1, calendar2);
/*     */ 
/*     */     
/* 125 */     j = calendar2.get(1);
/*     */     
/* 127 */     int k = calendar2.get(2) + 1;
/* 128 */     int m = calendar2.get(5);
/* 129 */     int n = calendar2.get(11);
/* 130 */     int i1 = calendar2.get(12);
/* 131 */     int i2 = calendar2.get(13);
/* 132 */     int i3 = 0;
/* 133 */     boolean bool = (n < 12) ? true : false;
/* 134 */     String str2 = calendar2.getTimeZone().getID();
/* 135 */     if (str2.length() > 3 && str2.startsWith("GMT")) {
/* 136 */       str2 = str2.substring(3);
/*     */     }
/* 138 */     if (s == 11)
/*     */     {
/* 140 */       i3 = oracleNanos(i);
/*     */     }
/*     */     
/* 143 */     return toText(j, k, m, n, i1, i2, i3, bool, str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 154 */     return getDate(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 160 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 164 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 165 */       sQLException.fillInStackTrace();
/* 166 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 173 */       return null;
/*     */     }
/*     */     
/* 176 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 180 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 182 */     if (str == null) {
/*     */ 
/*     */       
/* 185 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 186 */       sQLException.fillInStackTrace();
/* 187 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 191 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/*     */     
/* 193 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 195 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 196 */     int j = ((this.rowSpaceByte[0 + i] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + i] & 0xFF) - 100;
/*     */ 
/*     */     
/* 199 */     calendar1.set(1, j);
/* 200 */     calendar1.set(2, oracleMonth(i));
/* 201 */     calendar1.set(5, oracleDay(i));
/* 202 */     calendar1.set(11, oracleHour(i));
/* 203 */     calendar1.set(12, oracleMin(i));
/* 204 */     calendar1.set(13, oracleSec(i));
/* 205 */     calendar1.set(14, 0);
/*     */     
/* 207 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 209 */     return new Date(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 218 */     return getTime(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/* 224 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 228 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 229 */       sQLException.fillInStackTrace();
/* 230 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 235 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 236 */       return null;
/*     */     }
/*     */     
/* 239 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 243 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 245 */     if (str == null) {
/*     */ 
/*     */       
/* 248 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 249 */       sQLException.fillInStackTrace();
/* 250 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 254 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/*     */     
/* 256 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 258 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 259 */     int j = ((this.rowSpaceByte[0 + i] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + i] & 0xFF) - 100;
/*     */ 
/*     */     
/* 262 */     calendar1.set(1, j);
/* 263 */     calendar1.set(2, oracleMonth(i));
/* 264 */     calendar1.set(5, oracleDay(i));
/* 265 */     calendar1.set(11, oracleHour(i));
/* 266 */     calendar1.set(12, oracleMin(i));
/* 267 */     calendar1.set(13, oracleSec(i));
/* 268 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/* 271 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 273 */     return new Time(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 283 */     return getTimestamp(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 290 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 294 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 295 */       sQLException.fillInStackTrace();
/* 296 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 302 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/* 303 */       return null;
/*     */     }
/*     */     
/* 306 */     Calendar calendar1 = this.statement.connection.getDbTzCalendar();
/*     */ 
/*     */ 
/*     */     
/* 310 */     String str = this.statement.connection.getSessionTimeZone();
/*     */     
/* 312 */     if (str == null) {
/*     */ 
/*     */       
/* 315 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
/* 316 */       sQLException.fillInStackTrace();
/* 317 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 321 */     TimeZone timeZone = TimeZone.getTimeZone(str);
/* 322 */     Calendar calendar2 = Calendar.getInstance(timeZone);
/*     */     
/* 324 */     int i = this.columnIndex + this.byteLength * paramInt;
/* 325 */     short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*     */     
/* 327 */     int j = ((this.rowSpaceByte[0 + i] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + i] & 0xFF) - 100;
/*     */ 
/*     */     
/* 330 */     calendar1.set(1, j);
/* 331 */     calendar1.set(2, oracleMonth(i));
/* 332 */     calendar1.set(5, oracleDay(i));
/* 333 */     calendar1.set(11, oracleHour(i));
/* 334 */     calendar1.set(12, oracleMin(i));
/* 335 */     calendar1.set(13, oracleSec(i));
/* 336 */     calendar1.set(14, 0);
/*     */ 
/*     */     
/* 339 */     long l = TimeZoneAdjustUTC(calendar1);
/*     */     
/* 341 */     Timestamp timestamp = new Timestamp(l);
/*     */     
/* 343 */     if (s == 11)
/*     */     {
/* 345 */       timestamp.setNanos(oracleNanos(i));
/*     */     }
/*     */     
/* 348 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 356 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 364 */     return (Datum)getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 372 */     return getTIMESTAMPLTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 380 */     TIMESTAMPLTZ tIMESTAMPLTZ = null;
/*     */     
/* 382 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 386 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 387 */       sQLException.fillInStackTrace();
/* 388 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 396 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 397 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 398 */       byte[] arrayOfByte = new byte[s];
/*     */       
/* 400 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/*     */       
/* 402 */       tIMESTAMPLTZ = new TIMESTAMPLTZ(arrayOfByte);
/*     */     } 
/*     */     
/* 405 */     return tIMESTAMPLTZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 412 */     TIMESTAMPTZ tIMESTAMPTZ = null;
/*     */     
/* 414 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 418 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 419 */       sQLException.fillInStackTrace();
/* 420 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 426 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 428 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 429 */       int i = this.columnIndex + this.byteLength * paramInt;
/* 430 */       byte[] arrayOfByte = new byte[s];
/*     */       
/* 432 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/*     */       
/* 434 */       tIMESTAMPTZ = TIMESTAMPLTZ.toTIMESTAMPTZ((Connection)this.statement.connection, arrayOfByte);
/*     */     } 
/*     */     
/* 437 */     return tIMESTAMPTZ;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 443 */     TIMESTAMPTZ tIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
/* 444 */     return TIMESTAMPTZ.toTIMESTAMP((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException {
/* 449 */     TIMESTAMPTZ tIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
/* 450 */     return TIMESTAMPTZ.toDATE((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void TimeZoneAdjust(Calendar paramCalendar1, Calendar paramCalendar2) throws SQLException {
/* 460 */     String str1 = paramCalendar1.getTimeZone().getID();
/* 461 */     String str2 = paramCalendar2.getTimeZone().getID();
/*     */ 
/*     */     
/* 464 */     if (!str2.equals(str1)) {
/*     */       int i3;
/* 466 */       OffsetDST offsetDST = new OffsetDST();
/*     */ 
/*     */       
/* 469 */       byte b = getZoneOffset(paramCalendar1, offsetDST);
/*     */       
/* 471 */       int i4 = offsetDST.getOFFSET();
/*     */ 
/*     */       
/* 474 */       paramCalendar1.add(11, -(i4 / 3600000));
/* 475 */       paramCalendar1.add(12, -(i4 % 3600000) / 60000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 481 */       if (str2.equals("Custom") || (str2.startsWith("GMT") && str2.length() > 3)) {
/*     */ 
/*     */ 
/*     */         
/* 485 */         i3 = paramCalendar2.getTimeZone().getRawOffset();
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 490 */         int i5 = ZONEIDMAP.getID(str2);
/*     */         
/* 492 */         if (!ZONEIDMAP.isValidID(i5)) {
/*     */           
/* 494 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
/* 495 */           sQLException.fillInStackTrace();
/* 496 */           throw sQLException;
/*     */         } 
/*     */         
/* 499 */         TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/* 500 */         if (tIMEZONETAB.checkID(i5))
/*     */         {
/* 502 */           tIMEZONETAB.updateTable((Connection)this.statement.connection, i5);
/*     */         }
/*     */         
/* 505 */         Calendar calendar = this.statement.getGMTCalendar();
/*     */         
/* 507 */         calendar.set(1, paramCalendar1.get(1));
/* 508 */         calendar.set(2, paramCalendar1.get(2));
/* 509 */         calendar.set(5, paramCalendar1.get(5));
/* 510 */         calendar.set(11, paramCalendar1.get(11));
/* 511 */         calendar.set(12, paramCalendar1.get(12));
/* 512 */         calendar.set(13, paramCalendar1.get(13));
/* 513 */         calendar.set(14, paramCalendar1.get(14));
/*     */ 
/*     */         
/* 516 */         i3 = tIMEZONETAB.getOffset(calendar, i5);
/*     */       } 
/*     */ 
/*     */       
/* 520 */       paramCalendar1.add(11, i3 / 3600000);
/* 521 */       paramCalendar1.add(12, i3 % 3600000 / 60000);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 528 */     if ((str2.equals("Custom") && str1.equals("Custom")) || (str2.startsWith("GMT") && str2.length() > 3 && str1.startsWith("GMT") && str1.length() > 3)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 533 */       int i3 = paramCalendar1.getTimeZone().getRawOffset();
/* 534 */       int i4 = paramCalendar2.getTimeZone().getRawOffset();
/* 535 */       int i5 = 0;
/*     */ 
/*     */       
/* 538 */       if (i3 != i4) {
/*     */ 
/*     */         
/* 541 */         i5 = i3 - i4;
/* 542 */         i5 = (i5 > 0) ? i5 : -i5;
/*     */       } 
/*     */       
/* 545 */       if (i3 > i4) {
/* 546 */         i5 = -i5;
/*     */       }
/* 548 */       paramCalendar1.add(11, i5 / 3600000);
/* 549 */       paramCalendar1.add(12, i5 % 3600000 / 60000);
/*     */     } 
/*     */ 
/*     */     
/* 553 */     int i = paramCalendar1.get(1);
/* 554 */     int j = paramCalendar1.get(2);
/* 555 */     int k = paramCalendar1.get(5);
/* 556 */     int m = paramCalendar1.get(11);
/* 557 */     int n = paramCalendar1.get(12);
/* 558 */     int i1 = paramCalendar1.get(13);
/* 559 */     int i2 = paramCalendar1.get(14);
/*     */ 
/*     */     
/* 562 */     paramCalendar2.set(1, i);
/* 563 */     paramCalendar2.set(2, j);
/* 564 */     paramCalendar2.set(5, k);
/* 565 */     paramCalendar2.set(11, m);
/* 566 */     paramCalendar2.set(12, n);
/* 567 */     paramCalendar2.set(13, i1);
/* 568 */     paramCalendar2.set(14, i2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long TimeZoneAdjustUTC(Calendar paramCalendar) throws SQLException {
/* 578 */     String str = paramCalendar.getTimeZone().getID();
/*     */     
/* 580 */     if (str.equals("Custom") || (str.startsWith("GMT") && str.length() > 3)) {
/*     */ 
/*     */ 
/*     */       
/* 584 */       int i3 = paramCalendar.getTimeZone().getRawOffset();
/* 585 */       paramCalendar.add(11, -(i3 / 3600000));
/* 586 */       paramCalendar.add(12, -(i3 % 3600000) / 60000);
/*     */     }
/* 588 */     else if (!str.equals("GMT") && !str.equals("UTC")) {
/*     */       
/* 590 */       OffsetDST offsetDST = new OffsetDST();
/*     */ 
/*     */       
/* 593 */       byte b = getZoneOffset(paramCalendar, offsetDST);
/*     */       
/* 595 */       int i3 = offsetDST.getOFFSET();
/*     */ 
/*     */ 
/*     */       
/* 599 */       paramCalendar.add(11, -(i3 / 3600000));
/* 600 */       paramCalendar.add(12, -(i3 % 3600000) / 60000);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 608 */     int i = paramCalendar.get(1);
/* 609 */     int j = paramCalendar.get(2);
/* 610 */     int k = paramCalendar.get(5);
/* 611 */     int m = paramCalendar.get(11);
/* 612 */     int n = paramCalendar.get(12);
/* 613 */     int i1 = paramCalendar.get(13);
/* 614 */     int i2 = paramCalendar.get(14);
/*     */     
/* 616 */     Calendar calendar = this.statement.getGMTCalendar();
/*     */ 
/*     */     
/* 619 */     calendar.set(1, i);
/* 620 */     calendar.set(2, j);
/* 621 */     calendar.set(5, k);
/* 622 */     calendar.set(11, m);
/* 623 */     calendar.set(12, n);
/* 624 */     calendar.set(13, i1);
/* 625 */     calendar.set(14, i2);
/*     */     
/* 627 */     return calendar.getTimeInMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte getZoneOffset(Calendar paramCalendar, OffsetDST paramOffsetDST) throws SQLException {
/* 637 */     byte b = 0;
/*     */ 
/*     */     
/* 640 */     String str = paramCalendar.getTimeZone().getID();
/*     */ 
/*     */     
/* 643 */     if (str == "Custom" || (str.startsWith("GMT") && str.length() > 3)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 648 */       paramOffsetDST.setOFFSET(paramCalendar.getTimeZone().getRawOffset());
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 654 */       int i = ZONEIDMAP.getID(str);
/*     */       
/* 656 */       if (!ZONEIDMAP.isValidID(i)) {
/*     */         
/* 658 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
/* 659 */         sQLException.fillInStackTrace();
/* 660 */         throw sQLException;
/*     */       } 
/*     */       
/* 663 */       TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/* 664 */       if (tIMEZONETAB.checkID(i)) {
/* 665 */         tIMEZONETAB.updateTable((Connection)this.statement.connection, i);
/*     */       }
/*     */ 
/*     */       
/* 669 */       b = tIMEZONETAB.getLocalOffset(paramCalendar, i, paramOffsetDST);
/*     */     } 
/*     */     
/* 672 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 677 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\TimestampltzAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */