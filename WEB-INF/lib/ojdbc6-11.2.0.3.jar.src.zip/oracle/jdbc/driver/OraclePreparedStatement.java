/*       */ package oracle.jdbc.driver;
/*       */ 
/*       */ import java.io.BufferedInputStream;
/*       */ import java.io.BufferedReader;
/*       */ import java.io.ByteArrayInputStream;
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.io.Reader;
/*       */ import java.io.StringReader;
/*       */ import java.math.BigDecimal;
/*       */ import java.net.URL;
/*       */ import java.sql.Array;
/*       */ import java.sql.BatchUpdateException;
/*       */ import java.sql.Blob;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Connection;
/*       */ import java.sql.Date;
/*       */ import java.sql.NClob;
/*       */ import java.sql.ParameterMetaData;
/*       */ import java.sql.Ref;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.RowId;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLXML;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.Calendar;
/*       */ import java.util.Locale;
/*       */ import java.util.TimeZone;
/*       */ import oracle.jdbc.OracleConnection;
/*       */ import oracle.jdbc.OracleParameterMetaData;
/*       */ import oracle.jdbc.internal.OraclePreparedStatement;
/*       */ import oracle.jdbc.internal.OracleStatement;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.oracore.OracleTypeCOLLECTION;
/*       */ import oracle.jdbc.oracore.OracleTypeNUMBER;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.CHAR;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.OPAQUE;
/*       */ import oracle.sql.ORAData;
/*       */ import oracle.sql.OpaqueDescriptor;
/*       */ import oracle.sql.RAW;
/*       */ import oracle.sql.REF;
/*       */ import oracle.sql.ROWID;
/*       */ import oracle.sql.STRUCT;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ abstract class OraclePreparedStatement
/*       */   extends OracleStatement
/*       */   implements OraclePreparedStatement, ScrollRsetStatement
/*       */ {
/*       */   int numberOfBindRowsAllocated;
/*   102 */   static Binder theStaticVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
/*       */   
/*   104 */   static Binder theStaticVarnumNullBinder = OraclePreparedStatementReadOnly.theStaticVarnumNullBinder;
/*       */   
/*   106 */   Binder theVarnumNullBinder = theStaticVarnumNullBinder;
/*       */   
/*   108 */   static Binder theStaticBooleanBinder = OraclePreparedStatementReadOnly.theStaticBooleanBinder;
/*       */   
/*   110 */   Binder theBooleanBinder = theStaticBooleanBinder;
/*       */   
/*   112 */   static Binder theStaticByteBinder = OraclePreparedStatementReadOnly.theStaticByteBinder;
/*       */   
/*   114 */   Binder theByteBinder = theStaticByteBinder;
/*       */   
/*   116 */   static Binder theStaticShortBinder = OraclePreparedStatementReadOnly.theStaticShortBinder;
/*       */   
/*   118 */   Binder theShortBinder = theStaticShortBinder;
/*       */   
/*   120 */   static Binder theStaticIntBinder = OraclePreparedStatementReadOnly.theStaticIntBinder;
/*       */   
/*   122 */   Binder theIntBinder = theStaticIntBinder;
/*       */   
/*   124 */   static Binder theStaticLongBinder = OraclePreparedStatementReadOnly.theStaticLongBinder;
/*       */   
/*   126 */   Binder theLongBinder = theStaticLongBinder;
/*       */   
/*   128 */   static Binder theStaticFloatBinder = OraclePreparedStatementReadOnly.theStaticFloatBinder;
/*       */   
/*   130 */   Binder theFloatBinder = null;
/*       */   
/*   132 */   static Binder theStaticDoubleBinder = OraclePreparedStatementReadOnly.theStaticDoubleBinder;
/*       */   
/*   134 */   Binder theDoubleBinder = null;
/*       */   
/*   136 */   static Binder theStaticBigDecimalBinder = OraclePreparedStatementReadOnly.theStaticBigDecimalBinder;
/*       */   
/*   138 */   Binder theBigDecimalBinder = theStaticBigDecimalBinder;
/*       */   
/*   140 */   static Binder theStaticVarcharCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarcharCopyingBinder;
/*       */   
/*   142 */   static Binder theStaticVarcharNullBinder = OraclePreparedStatementReadOnly.theStaticVarcharNullBinder;
/*       */   
/*   144 */   Binder theVarcharNullBinder = theStaticVarcharNullBinder;
/*       */   
/*   146 */   static Binder theStaticStringBinder = OraclePreparedStatementReadOnly.theStaticStringBinder;
/*       */   
/*   148 */   Binder theStringBinder = theStaticStringBinder;
/*       */   
/*   150 */   static Binder theStaticSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
/*       */   
/*   152 */   static Binder theStaticSetCHARBinder = OraclePreparedStatementReadOnly.theStaticSetCHARBinder;
/*       */   
/*   154 */   static Binder theStaticLittleEndianSetCHARBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianSetCHARBinder;
/*       */   
/*   156 */   static Binder theStaticSetCHARNullBinder = OraclePreparedStatementReadOnly.theStaticSetCHARNullBinder;
/*       */   
/*       */   Binder theSetCHARBinder;
/*   159 */   Binder theSetCHARNullBinder = theStaticSetCHARNullBinder;
/*       */   
/*   161 */   static Binder theStaticFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
/*       */   
/*   163 */   static Binder theStaticFixedCHARBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARBinder;
/*       */   
/*   165 */   static Binder theStaticFixedCHARNullBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARNullBinder;
/*       */   
/*   167 */   Binder theFixedCHARBinder = theStaticFixedCHARBinder;
/*   168 */   Binder theFixedCHARNullBinder = theStaticFixedCHARNullBinder;
/*       */   
/*   170 */   static Binder theStaticDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
/*       */   
/*   172 */   static Binder theStaticDateBinder = OraclePreparedStatementReadOnly.theStaticDateBinder;
/*       */   
/*   174 */   static Binder theStaticDateNullBinder = OraclePreparedStatementReadOnly.theStaticDateNullBinder;
/*       */   
/*   176 */   Binder theDateBinder = theStaticDateBinder;
/*   177 */   Binder theDateNullBinder = theStaticDateNullBinder;
/*       */   
/*   179 */   static Binder theStaticTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
/*       */   
/*   181 */   static Binder theStaticTimeBinder = OraclePreparedStatementReadOnly.theStaticTimeBinder;
/*       */   
/*   183 */   Binder theTimeBinder = theStaticTimeBinder;
/*       */   
/*   185 */   static Binder theStaticTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
/*       */   
/*   187 */   static Binder theStaticTimestampBinder = OraclePreparedStatementReadOnly.theStaticTimestampBinder;
/*       */   
/*   189 */   static Binder theStaticTimestampNullBinder = OraclePreparedStatementReadOnly.theStaticTimestampNullBinder;
/*       */   
/*   191 */   Binder theTimestampBinder = theStaticTimestampBinder;
/*   192 */   Binder theTimestampNullBinder = theStaticTimestampNullBinder;
/*       */   
/*   194 */   static Binder theStaticOracleNumberBinder = OraclePreparedStatementReadOnly.theStaticOracleNumberBinder;
/*       */   
/*   196 */   Binder theOracleNumberBinder = theStaticOracleNumberBinder;
/*       */   
/*   198 */   static Binder theStaticOracleDateBinder = OraclePreparedStatementReadOnly.theStaticOracleDateBinder;
/*       */   
/*   200 */   Binder theOracleDateBinder = theStaticOracleDateBinder;
/*       */   
/*   202 */   static Binder theStaticOracleTimestampBinder = OraclePreparedStatementReadOnly.theStaticOracleTimestampBinder;
/*       */   
/*   204 */   Binder theOracleTimestampBinder = theStaticOracleTimestampBinder;
/*       */   
/*   206 */   static Binder theStaticTSTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSTZCopyingBinder;
/*       */   
/*   208 */   static Binder theStaticTSTZBinder = OraclePreparedStatementReadOnly.theStaticTSTZBinder;
/*       */   
/*   210 */   static Binder theStaticTSTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSTZNullBinder;
/*       */   
/*   212 */   Binder theTSTZBinder = theStaticTSTZBinder;
/*   213 */   Binder theTSTZNullBinder = theStaticTSTZNullBinder;
/*       */   
/*   215 */   static Binder theStaticTSLTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSLTZCopyingBinder;
/*       */   
/*   217 */   static Binder theStaticTSLTZBinder = OraclePreparedStatementReadOnly.theStaticTSLTZBinder;
/*       */   
/*   219 */   static Binder theStaticTSLTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSLTZNullBinder;
/*       */   
/*   221 */   Binder theTSLTZBinder = theStaticTSLTZBinder;
/*   222 */   Binder theTSLTZNullBinder = theStaticTSLTZNullBinder;
/*       */   
/*   224 */   static Binder theStaticRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
/*       */   
/*   226 */   static Binder theStaticRowidBinder = OraclePreparedStatementReadOnly.theStaticRowidBinder;
/*       */   
/*   228 */   static Binder theStaticLittleEndianRowidBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianRowidBinder;
/*       */   
/*   230 */   static Binder theStaticRowidNullBinder = OraclePreparedStatementReadOnly.theStaticRowidNullBinder;
/*       */   
/*   232 */   static Binder theStaticURowidNullBinder = OraclePreparedStatementReadOnly.theStaticURowidNullBinder;
/*       */   
/*       */   Binder theRowidBinder;
/*   235 */   Binder theRowidNullBinder = theStaticRowidNullBinder;
/*       */   
/*       */   Binder theURowidBinder;
/*   238 */   Binder theURowidNullBinder = theStaticURowidNullBinder;
/*       */   
/*   240 */   static Binder theStaticIntervalDSCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSCopyingBinder;
/*       */   
/*   242 */   static Binder theStaticIntervalDSBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSBinder;
/*       */   
/*   244 */   static Binder theStaticIntervalDSNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSNullBinder;
/*       */   
/*   246 */   Binder theIntervalDSBinder = theStaticIntervalDSBinder;
/*   247 */   Binder theIntervalDSNullBinder = theStaticIntervalDSNullBinder;
/*       */   
/*   249 */   static Binder theStaticIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
/*       */   
/*   251 */   static Binder theStaticIntervalYMBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMBinder;
/*       */   
/*   253 */   static Binder theStaticIntervalYMNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMNullBinder;
/*       */   
/*   255 */   Binder theIntervalYMBinder = theStaticIntervalYMBinder;
/*   256 */   Binder theIntervalYMNullBinder = theStaticIntervalYMNullBinder;
/*       */   
/*   258 */   static Binder theStaticBfileCopyingBinder = OraclePreparedStatementReadOnly.theStaticBfileCopyingBinder;
/*       */   
/*   260 */   static Binder theStaticBfileBinder = OraclePreparedStatementReadOnly.theStaticBfileBinder;
/*       */   
/*   262 */   static Binder theStaticBfileNullBinder = OraclePreparedStatementReadOnly.theStaticBfileNullBinder;
/*       */   
/*   264 */   Binder theBfileBinder = theStaticBfileBinder;
/*   265 */   Binder theBfileNullBinder = theStaticBfileNullBinder;
/*       */   
/*   267 */   static Binder theStaticBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
/*       */   
/*   269 */   static Binder theStaticBlobBinder = OraclePreparedStatementReadOnly.theStaticBlobBinder;
/*       */   
/*   271 */   static Binder theStaticBlobNullBinder = OraclePreparedStatementReadOnly.theStaticBlobNullBinder;
/*       */   
/*   273 */   Binder theBlobBinder = theStaticBlobBinder;
/*   274 */   Binder theBlobNullBinder = theStaticBlobNullBinder;
/*       */   
/*   276 */   static Binder theStaticClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
/*       */   
/*   278 */   static Binder theStaticClobBinder = OraclePreparedStatementReadOnly.theStaticClobBinder;
/*       */   
/*   280 */   static Binder theStaticClobNullBinder = OraclePreparedStatementReadOnly.theStaticClobNullBinder;
/*       */   
/*   282 */   Binder theClobBinder = theStaticClobBinder;
/*   283 */   Binder theClobNullBinder = theStaticClobNullBinder;
/*       */   
/*   285 */   static Binder theStaticRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
/*       */   
/*   287 */   static Binder theStaticRawBinder = OraclePreparedStatementReadOnly.theStaticRawBinder;
/*       */   
/*   289 */   static Binder theStaticRawNullBinder = OraclePreparedStatementReadOnly.theStaticRawNullBinder;
/*       */   
/*   291 */   Binder theRawBinder = theStaticRawBinder;
/*   292 */   Binder theRawNullBinder = theStaticRawNullBinder;
/*       */   
/*   294 */   static Binder theStaticPlsqlRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawCopyingBinder;
/*       */   
/*   296 */   static Binder theStaticPlsqlRawBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawBinder;
/*       */   
/*   298 */   Binder thePlsqlRawBinder = theStaticPlsqlRawBinder;
/*       */   
/*   300 */   static Binder theStaticBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
/*       */   
/*   302 */   static Binder theStaticBinaryFloatBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatBinder;
/*       */   
/*   304 */   static Binder theStaticBinaryFloatNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatNullBinder;
/*       */   
/*   306 */   Binder theBinaryFloatBinder = theStaticBinaryFloatBinder;
/*   307 */   Binder theBinaryFloatNullBinder = theStaticBinaryFloatNullBinder;
/*       */   
/*   309 */   static Binder theStaticBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
/*       */   
/*   311 */   static Binder theStaticBINARY_FLOATBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATBinder;
/*       */   
/*   313 */   static Binder theStaticBINARY_FLOATNullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATNullBinder;
/*       */   
/*   315 */   Binder theBINARY_FLOATBinder = theStaticBINARY_FLOATBinder;
/*   316 */   Binder theBINARY_FLOATNullBinder = theStaticBINARY_FLOATNullBinder;
/*       */   
/*   318 */   static Binder theStaticBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
/*       */   
/*   320 */   static Binder theStaticBinaryDoubleBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleBinder;
/*       */   
/*   322 */   static Binder theStaticBinaryDoubleNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleNullBinder;
/*       */   
/*   324 */   Binder theBinaryDoubleBinder = theStaticBinaryDoubleBinder;
/*   325 */   Binder theBinaryDoubleNullBinder = theStaticBinaryDoubleNullBinder;
/*       */   
/*   327 */   static Binder theStaticBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
/*       */   
/*   329 */   static Binder theStaticBINARY_DOUBLEBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLEBinder;
/*       */   
/*   331 */   static Binder theStaticBINARY_DOUBLENullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   333 */   Binder theBINARY_DOUBLEBinder = theStaticBINARY_DOUBLEBinder;
/*   334 */   Binder theBINARY_DOUBLENullBinder = theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   336 */   static Binder theStaticLongStreamBinder = OraclePreparedStatementReadOnly.theStaticLongStreamBinder;
/*       */   
/*   338 */   Binder theLongStreamBinder = theStaticLongStreamBinder;
/*       */   
/*   340 */   static Binder theStaticLongStreamForStringBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringBinder;
/*       */   
/*   342 */   Binder theLongStreamForStringBinder = theStaticLongStreamForStringBinder;
/*   343 */   static Binder theStaticLongStreamForStringCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringCopyingBinder;
/*       */ 
/*       */   
/*   346 */   static Binder theStaticLongRawStreamBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamBinder;
/*       */   
/*   348 */   Binder theLongRawStreamBinder = theStaticLongRawStreamBinder;
/*       */   
/*   350 */   static Binder theStaticLongRawStreamForBytesBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesBinder;
/*       */   
/*   352 */   Binder theLongRawStreamForBytesBinder = theStaticLongRawStreamForBytesBinder;
/*   353 */   static Binder theStaticLongRawStreamForBytesCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesCopyingBinder;
/*       */ 
/*       */   
/*   356 */   static Binder theStaticNamedTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeCopyingBinder;
/*       */   
/*   358 */   static Binder theStaticNamedTypeBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeBinder;
/*       */   
/*   360 */   static Binder theStaticNamedTypeNullBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeNullBinder;
/*       */   
/*   362 */   Binder theNamedTypeBinder = theStaticNamedTypeBinder;
/*   363 */   Binder theNamedTypeNullBinder = theStaticNamedTypeNullBinder;
/*       */   
/*   365 */   static Binder theStaticRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
/*       */   
/*   367 */   static Binder theStaticRefTypeBinder = OraclePreparedStatementReadOnly.theStaticRefTypeBinder;
/*       */   
/*   369 */   static Binder theStaticRefTypeNullBinder = OraclePreparedStatementReadOnly.theStaticRefTypeNullBinder;
/*       */   
/*   371 */   Binder theRefTypeBinder = theStaticRefTypeBinder;
/*   372 */   Binder theRefTypeNullBinder = theStaticRefTypeNullBinder;
/*       */   
/*   374 */   static Binder theStaticPlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
/*       */   
/*   376 */   static Binder theStaticPlsqlIbtBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtBinder;
/*       */   
/*   378 */   static Binder theStaticPlsqlIbtNullBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtNullBinder;
/*       */   
/*   380 */   Binder thePlsqlIbtBinder = theStaticPlsqlIbtBinder;
/*   381 */   Binder thePlsqlNullBinder = theStaticPlsqlIbtNullBinder;
/*       */   
/*   383 */   static Binder theStaticOutBinder = OraclePreparedStatementReadOnly.theStaticOutBinder;
/*       */   
/*   385 */   Binder theOutBinder = theStaticOutBinder;
/*       */   
/*   387 */   static Binder theStaticReturnParamBinder = OraclePreparedStatementReadOnly.theStaticReturnParamBinder;
/*       */   
/*   389 */   Binder theReturnParamBinder = theStaticReturnParamBinder;
/*       */   
/*   391 */   static Binder theStaticT4CRowidBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidBinder;
/*       */   
/*   393 */   static Binder theStaticT4CURowidBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidBinder;
/*       */   
/*   395 */   static Binder theStaticT4CRowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidNullBinder;
/*       */   
/*   397 */   static Binder theStaticT4CURowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidNullBinder;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   404 */   private static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
/*   405 */   private static final Calendar UTC_US_CALENDAR = Calendar.getInstance(UTC_TIME_ZONE, Locale.US);
/*       */   
/*   407 */   protected Calendar cachedUTCUSCalendar = (Calendar)UTC_US_CALENDAR.clone();
/*       */   
/*       */   public static final int TypeBinder_BYTELEN = 24;
/*       */   
/*   411 */   char[] digits = new char[20];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[][] binders;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[][] parameterInt;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   long[][] parameterLong;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   float[][] parameterFloat;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   double[][] parameterDouble;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BigDecimal[][] parameterBigDecimal;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String[][] parameterString;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Date[][] parameterDate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Time[][] parameterTime;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Timestamp[][] parameterTimestamp;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[][][] parameterDatum;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTypeADT[][] parameterOtype;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CLOB[] lastBoundClobs;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BLOB[] lastBoundBlobs;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PlsqlIbtBindInfo[][] parameterPlsqlIbt;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[] currentRowBinders;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentRowCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor[] currentRowBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short[] currentRowFormOfUse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean currentRowNeedToPrepareBinds = true;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentBatchCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor[] currentBatchBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short[] currentBatchFormOfUse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean currentBatchNeedToPrepareBinds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PushedBatch pushedBatches;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PushedBatch pushedBatchesTail;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   class PushedBatch
/*       */   {
/*       */     int[] currentBatchCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int[] lastBoundCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     Accessor[] currentBatchBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean lastBoundNeeded;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean need_to_parse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean current_batch_need_to_prepare_binds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int first_row_in_batch;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int number_of_rows_to_be_bound;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     PushedBatch next;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   869 */   int cachedBindByteSize = 0;
/*   870 */   int cachedBindCharSize = 0;
/*   871 */   int cachedBindIndicatorSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindByteLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindCharLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindIndicatorLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BIND_POSITIONS_OFFSET = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_HI = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_LO = 2;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_HI = 3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_LO = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_PER_POSITION_DATA_OFFSET = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_TYPE_OFFSET = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BYTE_PITCH_OFFSET = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_CHAR_PITCH_OFFSET = 2;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_HI = 3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_LO = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_HI = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_LO = 6;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_HI = 7;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_LO = 8;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_FORM_OF_USE_OFFSET = 9;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_PER_POSITION_SIZE = 10;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int SETLOB_NO_LENGTH = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int bindBufferCapacity;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int numberOfBoundRows;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int indicatorsOffset;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int valueLengthsOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedAllBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedCharBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[] lastBinders;
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] lastBoundBytes;
/*       */ 
/*       */ 
/*       */   
/*       */   int lastBoundByteOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   char[] lastBoundChars;
/*       */ 
/*       */ 
/*       */   
/*       */   int lastBoundCharOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundByteOffsets;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundCharOffsets;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundByteLens;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundCharLens;
/*       */ 
/*       */ 
/*       */   
/*       */   short[] lastBoundInds;
/*       */ 
/*       */ 
/*       */   
/*       */   short[] lastBoundLens;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean lastBoundNeeded = false;
/*       */ 
/*       */ 
/*       */   
/*       */   byte[][] lastBoundTypeBytes;
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTypeADT[] lastBoundTypeOtypes;
/*       */ 
/*       */ 
/*       */   
/*       */   InputStream[] lastBoundStream;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int STREAM_MAX_BYTES_SQL = 2147483647;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesPlsql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsCharsSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsNCharsSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsql;
/*       */ 
/*       */ 
/*       */   
/*  1092 */   private int maxCharSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1098 */   private int maxNCharSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1106 */   private int charMaxCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1114 */   private int charMaxNCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1121 */   private int maxVcsCharsPlsql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1128 */   private int maxVcsNCharsPlsql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1134 */   int maxIbtVarcharElementLength = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1142 */   private int maxStreamCharsSql = 0; protected boolean isServerCharSetFixedWidth = false; private boolean isServerNCharSetFixedWidth = false; int minVcsBindSize; int prematureBatchCount; boolean checkBindTypes = true; boolean scrollRsetTypeSolved; int SetBigStringTryClob; static final int BSTYLE_UNKNOWN = 0; static final int BSTYLE_ORACLE = 1; static final int BSTYLE_JDBC = 2; int m_batchStyle; void allocBinds(int paramInt) throws SQLException { boolean bool = (paramInt > this.numberOfBindRowsAllocated) ? true : false; initializeIndicatorSubRange(); int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10; int j = paramInt * this.numberOfBindPositions; int k = i + 2 * j; if (k > this.totalBindIndicatorLength) { short[] arrayOfShort = this.bindIndicators; int i2 = this.bindIndicatorOffset; this.bindIndicatorOffset = 0; this.bindIndicators = new short[k]; this.totalBindIndicatorLength = k; if (arrayOfShort != null && bool) System.arraycopy(arrayOfShort, i2, this.bindIndicators, this.bindIndicatorOffset, i);  }  this.bindIndicatorSubRange += this.bindIndicatorOffset; this.bindIndicators[this.bindIndicatorSubRange + 0] = (short)this.numberOfBindPositions; this.indicatorsOffset = this.bindIndicatorOffset + i; this.valueLengthsOffset = this.indicatorsOffset + j; int m = this.indicatorsOffset; int n = this.valueLengthsOffset; int i1 = this.bindIndicatorSubRange + 5; for (byte b = 0; b < this.numberOfBindPositions; b++) { this.bindIndicators[i1 + 5] = (short)(m >> 16); this.bindIndicators[i1 + 6] = (short)(m & 0xFFFF); this.bindIndicators[i1 + 7] = (short)(n >> 16); this.bindIndicators[i1 + 8] = (short)(n & 0xFFFF); m += paramInt; n += paramInt; i1 += 10; }  }
/*       */   void initializeBinds() throws SQLException { this.numberOfBindPositions = this.sqlObject.getParameterCount(); this.numReturnParams = this.sqlObject.getReturnParameterCount(); if (this.numberOfBindPositions == 0) { this.currentRowNeedToPrepareBinds = false; return; }  this.numberOfBindRowsAllocated = this.batch; this.binders = new Binder[this.numberOfBindRowsAllocated][this.numberOfBindPositions]; this.currentRowBinders = this.binders[0]; this.currentRowCharLens = new int[this.numberOfBindPositions]; this.currentBatchCharLens = new int[this.numberOfBindPositions]; this.currentRowFormOfUse = new short[this.numberOfBindPositions]; this.currentBatchFormOfUse = new short[this.numberOfBindPositions]; this.lastBoundClobs = new CLOB[this.numberOfBindPositions]; this.lastBoundBlobs = new BLOB[this.numberOfBindPositions]; byte b1 = 1; if (this.connection.defaultnchar) b1 = 2;  for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { this.currentRowFormOfUse[b2] = b1; this.currentBatchFormOfUse[b2] = b1; }  this.lastBinders = new Binder[this.numberOfBindPositions]; this.lastBoundCharLens = new int[this.numberOfBindPositions]; this.lastBoundByteOffsets = new int[this.numberOfBindPositions]; this.lastBoundCharOffsets = new int[this.numberOfBindPositions]; this.lastBoundByteLens = new int[this.numberOfBindPositions]; this.lastBoundInds = new short[this.numberOfBindPositions]; this.lastBoundLens = new short[this.numberOfBindPositions]; this.lastBoundTypeBytes = new byte[this.numberOfBindPositions][]; this.lastBoundTypeOtypes = new OracleTypeADT[this.numberOfBindPositions]; allocBinds(this.numberOfBindRowsAllocated); }
/*       */   void growBinds(int paramInt) throws SQLException { Binder[][] arrayOfBinder = this.binders; this.binders = new Binder[paramInt][]; if (arrayOfBinder != null) System.arraycopy(arrayOfBinder, 0, this.binders, 0, this.numberOfBindRowsAllocated);  int i; for (i = this.numberOfBindRowsAllocated; i < paramInt; i++) this.binders[i] = new Binder[this.numberOfBindPositions];  allocBinds(paramInt); if (this.parameterInt != null) { int[][] arrayOfInt = this.parameterInt; this.parameterInt = new int[paramInt][]; System.arraycopy(arrayOfInt, 0, this.parameterInt, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterInt[i] = new int[this.numberOfBindPositions];  }  if (this.parameterLong != null) { long[][] arrayOfLong = this.parameterLong; this.parameterLong = new long[paramInt][]; System.arraycopy(arrayOfLong, 0, this.parameterLong, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterLong[i] = new long[this.numberOfBindPositions];  }  if (this.parameterFloat != null) { float[][] arrayOfFloat = this.parameterFloat; this.parameterFloat = new float[paramInt][]; System.arraycopy(arrayOfFloat, 0, this.parameterFloat, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterFloat[i] = new float[this.numberOfBindPositions];  }  if (this.parameterDouble != null) { double[][] arrayOfDouble = this.parameterDouble; this.parameterDouble = new double[paramInt][]; System.arraycopy(arrayOfDouble, 0, this.parameterDouble, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDouble[i] = new double[this.numberOfBindPositions];  }  if (this.parameterBigDecimal != null) { BigDecimal[][] arrayOfBigDecimal = this.parameterBigDecimal; this.parameterBigDecimal = new BigDecimal[paramInt][]; System.arraycopy(arrayOfBigDecimal, 0, this.parameterBigDecimal, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterBigDecimal[i] = new BigDecimal[this.numberOfBindPositions];  }  if (this.parameterString != null) { String[][] arrayOfString = this.parameterString; this.parameterString = new String[paramInt][]; System.arraycopy(arrayOfString, 0, this.parameterString, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterString[i] = new String[this.numberOfBindPositions];  }  if (this.parameterDate != null) { Date[][] arrayOfDate = this.parameterDate; this.parameterDate = new Date[paramInt][]; System.arraycopy(arrayOfDate, 0, this.parameterDate, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDate[i] = new Date[this.numberOfBindPositions];  }  if (this.parameterTime != null) { Time[][] arrayOfTime = this.parameterTime; this.parameterTime = new Time[paramInt][]; System.arraycopy(arrayOfTime, 0, this.parameterTime, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterTime[i] = new Time[this.numberOfBindPositions];  }  if (this.parameterTimestamp != null) { Timestamp[][] arrayOfTimestamp = this.parameterTimestamp; this.parameterTimestamp = new Timestamp[paramInt][]; System.arraycopy(arrayOfTimestamp, 0, this.parameterTimestamp, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterTimestamp[i] = new Timestamp[this.numberOfBindPositions];  }  if (this.parameterDatum != null) { byte[][][] arrayOfByte = this.parameterDatum; this.parameterDatum = new byte[paramInt][][]; System.arraycopy(arrayOfByte, 0, this.parameterDatum, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDatum[i] = new byte[this.numberOfBindPositions][];  }  if (this.parameterOtype != null) { OracleTypeADT[][] arrayOfOracleTypeADT = this.parameterOtype; this.parameterOtype = new OracleTypeADT[paramInt][]; System.arraycopy(arrayOfOracleTypeADT, 0, this.parameterOtype, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterOtype[i] = new OracleTypeADT[this.numberOfBindPositions];  }  if (this.parameterStream != null) { InputStream[][] arrayOfInputStream = this.parameterStream; this.parameterStream = new InputStream[paramInt][]; System.arraycopy(arrayOfInputStream, 0, this.parameterStream, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterStream[i] = new InputStream[this.numberOfBindPositions];  }  if (this.userStream != null) { Object[][] arrayOfObject = this.userStream; this.userStream = new Object[paramInt][]; System.arraycopy(arrayOfObject, 0, this.userStream, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.userStream[i] = new Object[this.numberOfBindPositions];  }  if (this.parameterPlsqlIbt != null) { PlsqlIbtBindInfo[][] arrayOfPlsqlIbtBindInfo = this.parameterPlsqlIbt; this.parameterPlsqlIbt = new PlsqlIbtBindInfo[paramInt][]; System.arraycopy(arrayOfPlsqlIbtBindInfo, 0, this.parameterPlsqlIbt, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterPlsqlIbt[i] = new PlsqlIbtBindInfo[this.numberOfBindPositions];  }  this.numberOfBindRowsAllocated = paramInt; this.currentRowNeedToPrepareBinds = true; }
/*       */   void processCompletedBindRow(int paramInt, boolean paramBoolean) throws SQLException { // Byte code:
/*       */     //   0: aload_0
/*       */     //   1: getfield numberOfBindPositions : I
/*       */     //   4: ifne -> 8
/*       */     //   7: return
/*       */     //   8: iconst_0
/*       */     //   9: istore #4
/*       */     //   11: iconst_0
/*       */     //   12: istore #5
/*       */     //   14: iconst_0
/*       */     //   15: istore #6
/*       */     //   17: aload_0
/*       */     //   18: getfield currentRank : I
/*       */     //   21: aload_0
/*       */     //   22: getfield firstRowInBatch : I
/*       */     //   25: if_icmpne -> 32
/*       */     //   28: iconst_1
/*       */     //   29: goto -> 33
/*       */     //   32: iconst_0
/*       */     //   33: istore #7
/*       */     //   35: aload_0
/*       */     //   36: getfield currentRank : I
/*       */     //   39: ifne -> 62
/*       */     //   42: aload_0
/*       */     //   43: getfield lastBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   46: iconst_0
/*       */     //   47: aaload
/*       */     //   48: ifnonnull -> 55
/*       */     //   51: aconst_null
/*       */     //   52: goto -> 73
/*       */     //   55: aload_0
/*       */     //   56: getfield lastBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   59: goto -> 73
/*       */     //   62: aload_0
/*       */     //   63: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   66: aload_0
/*       */     //   67: getfield currentRank : I
/*       */     //   70: iconst_1
/*       */     //   71: isub
/*       */     //   72: aaload
/*       */     //   73: astore #8
/*       */     //   75: aload_0
/*       */     //   76: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   79: ifnonnull -> 591
/*       */     //   82: aload_0
/*       */     //   83: getfield isAutoGeneratedKey : Z
/*       */     //   86: ifeq -> 100
/*       */     //   89: aload_0
/*       */     //   90: getfield clearParameters : Z
/*       */     //   93: ifeq -> 100
/*       */     //   96: iconst_1
/*       */     //   97: goto -> 101
/*       */     //   100: iconst_0
/*       */     //   101: istore #9
/*       */     //   103: aload #8
/*       */     //   105: ifnonnull -> 174
/*       */     //   108: iconst_0
/*       */     //   109: istore_3
/*       */     //   110: iload_3
/*       */     //   111: aload_0
/*       */     //   112: getfield numberOfBindPositions : I
/*       */     //   115: if_icmpge -> 565
/*       */     //   118: aload_0
/*       */     //   119: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   122: iload_3
/*       */     //   123: aaload
/*       */     //   124: ifnonnull -> 168
/*       */     //   127: iload #9
/*       */     //   129: ifeq -> 142
/*       */     //   132: aload_0
/*       */     //   133: invokevirtual registerReturnParamsForAutoKey : ()V
/*       */     //   136: iconst_0
/*       */     //   137: istore #9
/*       */     //   139: goto -> 168
/*       */     //   142: aload_0
/*       */     //   143: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   146: bipush #41
/*       */     //   148: iload_3
/*       */     //   149: iconst_1
/*       */     //   150: iadd
/*       */     //   151: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   154: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   157: astore #10
/*       */     //   159: aload #10
/*       */     //   161: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   164: pop
/*       */     //   165: aload #10
/*       */     //   167: athrow
/*       */     //   168: iinc #3, 1
/*       */     //   171: goto -> 110
/*       */     //   174: aload_0
/*       */     //   175: getfield checkBindTypes : Z
/*       */     //   178: ifeq -> 462
/*       */     //   181: aload_0
/*       */     //   182: getfield currentRank : I
/*       */     //   185: ifne -> 195
/*       */     //   188: aload_0
/*       */     //   189: getfield lastBoundTypeOtypes : [Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   192: goto -> 217
/*       */     //   195: aload_0
/*       */     //   196: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   199: ifnonnull -> 206
/*       */     //   202: aconst_null
/*       */     //   203: goto -> 217
/*       */     //   206: aload_0
/*       */     //   207: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   210: aload_0
/*       */     //   211: getfield currentRank : I
/*       */     //   214: iconst_1
/*       */     //   215: isub
/*       */     //   216: aaload
/*       */     //   217: astore #10
/*       */     //   219: iconst_0
/*       */     //   220: istore_3
/*       */     //   221: iload_3
/*       */     //   222: aload_0
/*       */     //   223: getfield numberOfBindPositions : I
/*       */     //   226: if_icmpge -> 459
/*       */     //   229: aload_0
/*       */     //   230: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   233: iload_3
/*       */     //   234: aaload
/*       */     //   235: ifnonnull -> 250
/*       */     //   238: iload #9
/*       */     //   240: ifeq -> 250
/*       */     //   243: aload_0
/*       */     //   244: invokevirtual registerReturnParamsForAutoKey : ()V
/*       */     //   247: iconst_0
/*       */     //   248: istore #9
/*       */     //   250: aload_0
/*       */     //   251: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   254: iload_3
/*       */     //   255: aaload
/*       */     //   256: astore #11
/*       */     //   258: aload #11
/*       */     //   260: ifnonnull -> 340
/*       */     //   263: aload_0
/*       */     //   264: getfield clearParameters : Z
/*       */     //   267: ifeq -> 296
/*       */     //   270: aload_0
/*       */     //   271: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   274: bipush #41
/*       */     //   276: iload_3
/*       */     //   277: iconst_1
/*       */     //   278: iadd
/*       */     //   279: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   282: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   285: astore #12
/*       */     //   287: aload #12
/*       */     //   289: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   292: pop
/*       */     //   293: aload #12
/*       */     //   295: athrow
/*       */     //   296: aload_0
/*       */     //   297: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   300: iload_3
/*       */     //   301: aload #8
/*       */     //   303: iload_3
/*       */     //   304: aaload
/*       */     //   305: invokevirtual copyingBinder : ()Loracle/jdbc/driver/Binder;
/*       */     //   308: aastore
/*       */     //   309: aload_0
/*       */     //   310: getfield currentRank : I
/*       */     //   313: ifne -> 327
/*       */     //   316: aload_0
/*       */     //   317: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   320: iload_3
/*       */     //   321: aaload
/*       */     //   322: aload_0
/*       */     //   323: iload_3
/*       */     //   324: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   327: aload_0
/*       */     //   328: getfield currentRowCharLens : [I
/*       */     //   331: iload_3
/*       */     //   332: iconst_m1
/*       */     //   333: iastore
/*       */     //   334: iconst_1
/*       */     //   335: istore #5
/*       */     //   337: goto -> 435
/*       */     //   340: aload #11
/*       */     //   342: getfield type : S
/*       */     //   345: istore #12
/*       */     //   347: iload #12
/*       */     //   349: aload #8
/*       */     //   351: iload_3
/*       */     //   352: aaload
/*       */     //   353: getfield type : S
/*       */     //   356: if_icmpne -> 432
/*       */     //   359: iload #12
/*       */     //   361: bipush #109
/*       */     //   363: if_icmpeq -> 373
/*       */     //   366: iload #12
/*       */     //   368: bipush #111
/*       */     //   370: if_icmpne -> 394
/*       */     //   373: aload_0
/*       */     //   374: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   377: aload_0
/*       */     //   378: getfield currentRank : I
/*       */     //   381: aaload
/*       */     //   382: iload_3
/*       */     //   383: aaload
/*       */     //   384: aload #10
/*       */     //   386: iload_3
/*       */     //   387: aaload
/*       */     //   388: invokevirtual isInHierarchyOf : (Loracle/jdbc/oracore/OracleType;)Z
/*       */     //   391: ifeq -> 432
/*       */     //   394: iload #12
/*       */     //   396: bipush #9
/*       */     //   398: if_icmpne -> 435
/*       */     //   401: aload #11
/*       */     //   403: getfield bytelen : I
/*       */     //   406: ifne -> 413
/*       */     //   409: iconst_1
/*       */     //   410: goto -> 414
/*       */     //   413: iconst_0
/*       */     //   414: aload #8
/*       */     //   416: iload_3
/*       */     //   417: aaload
/*       */     //   418: getfield bytelen : I
/*       */     //   421: ifne -> 428
/*       */     //   424: iconst_1
/*       */     //   425: goto -> 429
/*       */     //   428: iconst_0
/*       */     //   429: if_icmpeq -> 435
/*       */     //   432: iconst_1
/*       */     //   433: istore #4
/*       */     //   435: aload_0
/*       */     //   436: getfield currentBatchFormOfUse : [S
/*       */     //   439: iload_3
/*       */     //   440: saload
/*       */     //   441: aload_0
/*       */     //   442: getfield currentRowFormOfUse : [S
/*       */     //   445: iload_3
/*       */     //   446: saload
/*       */     //   447: if_icmpeq -> 453
/*       */     //   450: iconst_1
/*       */     //   451: istore #4
/*       */     //   453: iinc #3, 1
/*       */     //   456: goto -> 221
/*       */     //   459: goto -> 565
/*       */     //   462: iconst_0
/*       */     //   463: istore_3
/*       */     //   464: iload_3
/*       */     //   465: aload_0
/*       */     //   466: getfield numberOfBindPositions : I
/*       */     //   469: if_icmpge -> 565
/*       */     //   472: aload_0
/*       */     //   473: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   476: iload_3
/*       */     //   477: aaload
/*       */     //   478: astore #10
/*       */     //   480: aload #10
/*       */     //   482: ifnonnull -> 559
/*       */     //   485: aload_0
/*       */     //   486: getfield clearParameters : Z
/*       */     //   489: ifeq -> 518
/*       */     //   492: aload_0
/*       */     //   493: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   496: bipush #41
/*       */     //   498: iload_3
/*       */     //   499: iconst_1
/*       */     //   500: iadd
/*       */     //   501: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   504: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   507: astore #11
/*       */     //   509: aload #11
/*       */     //   511: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   514: pop
/*       */     //   515: aload #11
/*       */     //   517: athrow
/*       */     //   518: aload_0
/*       */     //   519: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   522: iload_3
/*       */     //   523: aload #8
/*       */     //   525: iload_3
/*       */     //   526: aaload
/*       */     //   527: invokevirtual copyingBinder : ()Loracle/jdbc/driver/Binder;
/*       */     //   530: aastore
/*       */     //   531: aload_0
/*       */     //   532: getfield currentRank : I
/*       */     //   535: ifne -> 549
/*       */     //   538: aload_0
/*       */     //   539: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   542: iload_3
/*       */     //   543: aaload
/*       */     //   544: aload_0
/*       */     //   545: iload_3
/*       */     //   546: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   549: aload_0
/*       */     //   550: getfield currentRowCharLens : [I
/*       */     //   553: iload_3
/*       */     //   554: iconst_m1
/*       */     //   555: iastore
/*       */     //   556: iconst_1
/*       */     //   557: istore #5
/*       */     //   559: iinc #3, 1
/*       */     //   562: goto -> 464
/*       */     //   565: iload #5
/*       */     //   567: ifeq -> 588
/*       */     //   570: iload #7
/*       */     //   572: ifne -> 583
/*       */     //   575: aload_0
/*       */     //   576: getfield m_batchStyle : I
/*       */     //   579: iconst_2
/*       */     //   580: if_icmpne -> 588
/*       */     //   583: aload_0
/*       */     //   584: iconst_1
/*       */     //   585: putfield lastBoundNeeded : Z
/*       */     //   588: goto -> 1259
/*       */     //   591: aload #8
/*       */     //   593: ifnonnull -> 729
/*       */     //   596: iconst_0
/*       */     //   597: istore_3
/*       */     //   598: iload_3
/*       */     //   599: aload_0
/*       */     //   600: getfield numberOfBindPositions : I
/*       */     //   603: if_icmpge -> 1244
/*       */     //   606: aload_0
/*       */     //   607: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   610: iload_3
/*       */     //   611: aaload
/*       */     //   612: astore #9
/*       */     //   614: aload_0
/*       */     //   615: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   618: iload_3
/*       */     //   619: aaload
/*       */     //   620: astore #10
/*       */     //   622: aload #9
/*       */     //   624: ifnonnull -> 671
/*       */     //   627: aload #10
/*       */     //   629: ifnonnull -> 658
/*       */     //   632: aload_0
/*       */     //   633: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   636: bipush #41
/*       */     //   638: iload_3
/*       */     //   639: iconst_1
/*       */     //   640: iadd
/*       */     //   641: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   644: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   647: astore #11
/*       */     //   649: aload #11
/*       */     //   651: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   654: pop
/*       */     //   655: aload #11
/*       */     //   657: athrow
/*       */     //   658: aload_0
/*       */     //   659: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   662: iload_3
/*       */     //   663: aload_0
/*       */     //   664: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   667: aastore
/*       */     //   668: goto -> 723
/*       */     //   671: aload #10
/*       */     //   673: ifnull -> 723
/*       */     //   676: aload #10
/*       */     //   678: getfield defineType : I
/*       */     //   681: aload #9
/*       */     //   683: getfield type : S
/*       */     //   686: if_icmpeq -> 723
/*       */     //   689: aload_0
/*       */     //   690: getfield connection : Loracle/jdbc/driver/PhysicalConnection;
/*       */     //   693: getfield permitTimestampDateMismatch : Z
/*       */     //   696: ifeq -> 720
/*       */     //   699: aload #9
/*       */     //   701: getfield type : S
/*       */     //   704: sipush #180
/*       */     //   707: if_icmpne -> 720
/*       */     //   710: aload #10
/*       */     //   712: getfield defineType : I
/*       */     //   715: bipush #12
/*       */     //   717: if_icmpeq -> 723
/*       */     //   720: iconst_1
/*       */     //   721: istore #6
/*       */     //   723: iinc #3, 1
/*       */     //   726: goto -> 598
/*       */     //   729: aload_0
/*       */     //   730: getfield checkBindTypes : Z
/*       */     //   733: ifeq -> 1117
/*       */     //   736: aload_0
/*       */     //   737: getfield currentRank : I
/*       */     //   740: ifne -> 750
/*       */     //   743: aload_0
/*       */     //   744: getfield lastBoundTypeOtypes : [Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   747: goto -> 772
/*       */     //   750: aload_0
/*       */     //   751: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   754: ifnonnull -> 761
/*       */     //   757: aconst_null
/*       */     //   758: goto -> 772
/*       */     //   761: aload_0
/*       */     //   762: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   765: aload_0
/*       */     //   766: getfield currentRank : I
/*       */     //   769: iconst_1
/*       */     //   770: isub
/*       */     //   771: aaload
/*       */     //   772: astore #9
/*       */     //   774: iconst_0
/*       */     //   775: istore_3
/*       */     //   776: iload_3
/*       */     //   777: aload_0
/*       */     //   778: getfield numberOfBindPositions : I
/*       */     //   781: if_icmpge -> 1114
/*       */     //   784: aload_0
/*       */     //   785: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   788: iload_3
/*       */     //   789: aaload
/*       */     //   790: astore #10
/*       */     //   792: aload_0
/*       */     //   793: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   796: iload_3
/*       */     //   797: aaload
/*       */     //   798: astore #11
/*       */     //   800: aload #10
/*       */     //   802: ifnonnull -> 885
/*       */     //   805: aload_0
/*       */     //   806: getfield clearParameters : Z
/*       */     //   809: ifeq -> 849
/*       */     //   812: aload #8
/*       */     //   814: iload_3
/*       */     //   815: aaload
/*       */     //   816: aload_0
/*       */     //   817: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   820: if_acmpeq -> 849
/*       */     //   823: aload_0
/*       */     //   824: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   827: bipush #41
/*       */     //   829: iload_3
/*       */     //   830: iconst_1
/*       */     //   831: iadd
/*       */     //   832: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   835: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   838: astore #12
/*       */     //   840: aload #12
/*       */     //   842: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   845: pop
/*       */     //   846: aload #12
/*       */     //   848: athrow
/*       */     //   849: aload #8
/*       */     //   851: iload_3
/*       */     //   852: aaload
/*       */     //   853: astore #10
/*       */     //   855: aload_0
/*       */     //   856: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   859: iload_3
/*       */     //   860: aload #10
/*       */     //   862: aastore
/*       */     //   863: aload_0
/*       */     //   864: getfield currentRowCharLens : [I
/*       */     //   867: iload_3
/*       */     //   868: iconst_m1
/*       */     //   869: iastore
/*       */     //   870: aload #10
/*       */     //   872: aload_0
/*       */     //   873: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   876: if_acmpeq -> 980
/*       */     //   879: iconst_1
/*       */     //   880: istore #5
/*       */     //   882: goto -> 980
/*       */     //   885: aload #10
/*       */     //   887: getfield type : S
/*       */     //   890: istore #12
/*       */     //   892: iload #12
/*       */     //   894: aload #8
/*       */     //   896: iload_3
/*       */     //   897: aaload
/*       */     //   898: getfield type : S
/*       */     //   901: if_icmpne -> 977
/*       */     //   904: iload #12
/*       */     //   906: bipush #109
/*       */     //   908: if_icmpeq -> 918
/*       */     //   911: iload #12
/*       */     //   913: bipush #111
/*       */     //   915: if_icmpne -> 939
/*       */     //   918: aload_0
/*       */     //   919: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   922: aload_0
/*       */     //   923: getfield currentRank : I
/*       */     //   926: aaload
/*       */     //   927: iload_3
/*       */     //   928: aaload
/*       */     //   929: aload #9
/*       */     //   931: iload_3
/*       */     //   932: aaload
/*       */     //   933: invokevirtual isInHierarchyOf : (Loracle/jdbc/oracore/OracleType;)Z
/*       */     //   936: ifeq -> 977
/*       */     //   939: iload #12
/*       */     //   941: bipush #9
/*       */     //   943: if_icmpne -> 980
/*       */     //   946: aload #10
/*       */     //   948: getfield bytelen : I
/*       */     //   951: ifne -> 958
/*       */     //   954: iconst_1
/*       */     //   955: goto -> 959
/*       */     //   958: iconst_0
/*       */     //   959: aload #8
/*       */     //   961: iload_3
/*       */     //   962: aaload
/*       */     //   963: getfield bytelen : I
/*       */     //   966: ifne -> 973
/*       */     //   969: iconst_1
/*       */     //   970: goto -> 974
/*       */     //   973: iconst_0
/*       */     //   974: if_icmpeq -> 980
/*       */     //   977: iconst_1
/*       */     //   978: istore #4
/*       */     //   980: aload_0
/*       */     //   981: getfield currentBatchFormOfUse : [S
/*       */     //   984: iload_3
/*       */     //   985: saload
/*       */     //   986: aload_0
/*       */     //   987: getfield currentRowFormOfUse : [S
/*       */     //   990: iload_3
/*       */     //   991: saload
/*       */     //   992: if_icmpeq -> 998
/*       */     //   995: iconst_1
/*       */     //   996: istore #4
/*       */     //   998: aload_0
/*       */     //   999: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1002: iload_3
/*       */     //   1003: aaload
/*       */     //   1004: astore #12
/*       */     //   1006: aload #11
/*       */     //   1008: ifnonnull -> 1026
/*       */     //   1011: aload #12
/*       */     //   1013: astore #11
/*       */     //   1015: aload_0
/*       */     //   1016: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1019: iload_3
/*       */     //   1020: aload #11
/*       */     //   1022: aastore
/*       */     //   1023: goto -> 1047
/*       */     //   1026: aload #12
/*       */     //   1028: ifnull -> 1047
/*       */     //   1031: aload #11
/*       */     //   1033: getfield defineType : I
/*       */     //   1036: aload #12
/*       */     //   1038: getfield defineType : I
/*       */     //   1041: if_icmpeq -> 1047
/*       */     //   1044: iconst_1
/*       */     //   1045: istore #4
/*       */     //   1047: aload #11
/*       */     //   1049: ifnull -> 1108
/*       */     //   1052: aload #10
/*       */     //   1054: aload_0
/*       */     //   1055: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1058: if_acmpeq -> 1108
/*       */     //   1061: aload #11
/*       */     //   1063: getfield defineType : I
/*       */     //   1066: aload #10
/*       */     //   1068: getfield type : S
/*       */     //   1071: if_icmpeq -> 1108
/*       */     //   1074: aload_0
/*       */     //   1075: getfield connection : Loracle/jdbc/driver/PhysicalConnection;
/*       */     //   1078: getfield permitTimestampDateMismatch : Z
/*       */     //   1081: ifeq -> 1105
/*       */     //   1084: aload #10
/*       */     //   1086: getfield type : S
/*       */     //   1089: sipush #180
/*       */     //   1092: if_icmpne -> 1105
/*       */     //   1095: aload #11
/*       */     //   1097: getfield defineType : I
/*       */     //   1100: bipush #12
/*       */     //   1102: if_icmpeq -> 1108
/*       */     //   1105: iconst_1
/*       */     //   1106: istore #6
/*       */     //   1108: iinc #3, 1
/*       */     //   1111: goto -> 776
/*       */     //   1114: goto -> 1244
/*       */     //   1117: iconst_0
/*       */     //   1118: istore_3
/*       */     //   1119: iload_3
/*       */     //   1120: aload_0
/*       */     //   1121: getfield numberOfBindPositions : I
/*       */     //   1124: if_icmpge -> 1244
/*       */     //   1127: aload_0
/*       */     //   1128: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1131: iload_3
/*       */     //   1132: aaload
/*       */     //   1133: astore #9
/*       */     //   1135: aload #9
/*       */     //   1137: ifnonnull -> 1217
/*       */     //   1140: aload_0
/*       */     //   1141: getfield clearParameters : Z
/*       */     //   1144: ifeq -> 1184
/*       */     //   1147: aload #8
/*       */     //   1149: iload_3
/*       */     //   1150: aaload
/*       */     //   1151: aload_0
/*       */     //   1152: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1155: if_acmpeq -> 1184
/*       */     //   1158: aload_0
/*       */     //   1159: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   1162: bipush #41
/*       */     //   1164: iload_3
/*       */     //   1165: iconst_1
/*       */     //   1166: iadd
/*       */     //   1167: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   1170: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   1173: astore #10
/*       */     //   1175: aload #10
/*       */     //   1177: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   1180: pop
/*       */     //   1181: aload #10
/*       */     //   1183: athrow
/*       */     //   1184: aload #8
/*       */     //   1186: iload_3
/*       */     //   1187: aaload
/*       */     //   1188: astore #9
/*       */     //   1190: aload_0
/*       */     //   1191: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1194: iload_3
/*       */     //   1195: aload #9
/*       */     //   1197: aastore
/*       */     //   1198: aload_0
/*       */     //   1199: getfield currentRowCharLens : [I
/*       */     //   1202: iload_3
/*       */     //   1203: iconst_m1
/*       */     //   1204: iastore
/*       */     //   1205: aload #9
/*       */     //   1207: aload_0
/*       */     //   1208: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1211: if_acmpeq -> 1217
/*       */     //   1214: iconst_1
/*       */     //   1215: istore #5
/*       */     //   1217: aload_0
/*       */     //   1218: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1221: iload_3
/*       */     //   1222: aaload
/*       */     //   1223: ifnonnull -> 1238
/*       */     //   1226: aload_0
/*       */     //   1227: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1230: iload_3
/*       */     //   1231: aload_0
/*       */     //   1232: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1235: iload_3
/*       */     //   1236: aaload
/*       */     //   1237: aastore
/*       */     //   1238: iinc #3, 1
/*       */     //   1241: goto -> 1119
/*       */     //   1244: iload #5
/*       */     //   1246: ifeq -> 1259
/*       */     //   1249: iload #7
/*       */     //   1251: ifeq -> 1259
/*       */     //   1254: aload_0
/*       */     //   1255: iconst_1
/*       */     //   1256: putfield lastBoundNeeded : Z
/*       */     //   1259: iload #4
/*       */     //   1261: ifeq -> 1360
/*       */     //   1264: iload #7
/*       */     //   1266: ifne -> 1342
/*       */     //   1269: aload_0
/*       */     //   1270: getfield m_batchStyle : I
/*       */     //   1273: iconst_2
/*       */     //   1274: if_icmpne -> 1285
/*       */     //   1277: aload_0
/*       */     //   1278: iconst_0
/*       */     //   1279: invokevirtual pushBatch : (Z)V
/*       */     //   1282: goto -> 1342
/*       */     //   1285: aload_0
/*       */     //   1286: getfield validRows : I
/*       */     //   1289: istore #9
/*       */     //   1291: aload_0
/*       */     //   1292: aload_0
/*       */     //   1293: invokevirtual sendBatch : ()I
/*       */     //   1296: putfield prematureBatchCount : I
/*       */     //   1299: aload_0
/*       */     //   1300: iload #9
/*       */     //   1302: putfield validRows : I
/*       */     //   1305: iconst_0
/*       */     //   1306: istore_3
/*       */     //   1307: iload_3
/*       */     //   1308: aload_0
/*       */     //   1309: getfield numberOfBindPositions : I
/*       */     //   1312: if_icmpge -> 1332
/*       */     //   1315: aload_0
/*       */     //   1316: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1319: iload_3
/*       */     //   1320: aaload
/*       */     //   1321: aload_0
/*       */     //   1322: iload_3
/*       */     //   1323: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   1326: iinc #3, 1
/*       */     //   1329: goto -> 1307
/*       */     //   1332: iload #5
/*       */     //   1334: ifeq -> 1342
/*       */     //   1337: aload_0
/*       */     //   1338: iconst_1
/*       */     //   1339: putfield lastBoundNeeded : Z
/*       */     //   1342: aload_0
/*       */     //   1343: iconst_1
/*       */     //   1344: putfield needToParse : Z
/*       */     //   1347: aload_0
/*       */     //   1348: iconst_1
/*       */     //   1349: putfield currentRowNeedToPrepareBinds : Z
/*       */     //   1352: aload_0
/*       */     //   1353: iconst_1
/*       */     //   1354: putfield needToPrepareDefineBuffer : Z
/*       */     //   1357: goto -> 1379
/*       */     //   1360: iload_2
/*       */     //   1361: ifeq -> 1379
/*       */     //   1364: aload_0
/*       */     //   1365: iconst_0
/*       */     //   1366: invokevirtual pushBatch : (Z)V
/*       */     //   1369: aload_0
/*       */     //   1370: iconst_0
/*       */     //   1371: putfield needToParse : Z
/*       */     //   1374: aload_0
/*       */     //   1375: iconst_0
/*       */     //   1376: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1379: iload #6
/*       */     //   1381: ifeq -> 1404
/*       */     //   1384: aload_0
/*       */     //   1385: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   1388: bipush #12
/*       */     //   1390: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;I)Ljava/sql/SQLException;
/*       */     //   1393: astore #9
/*       */     //   1395: aload #9
/*       */     //   1397: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   1400: pop
/*       */     //   1401: aload #9
/*       */     //   1403: athrow
/*       */     //   1404: iconst_0
/*       */     //   1405: istore_3
/*       */     //   1406: iload_3
/*       */     //   1407: aload_0
/*       */     //   1408: getfield numberOfBindPositions : I
/*       */     //   1411: if_icmpge -> 1491
/*       */     //   1414: aload_0
/*       */     //   1415: getfield currentRowCharLens : [I
/*       */     //   1418: iload_3
/*       */     //   1419: iaload
/*       */     //   1420: istore #9
/*       */     //   1422: iload #9
/*       */     //   1424: iconst_m1
/*       */     //   1425: if_icmpne -> 1447
/*       */     //   1428: aload_0
/*       */     //   1429: getfield currentRank : I
/*       */     //   1432: aload_0
/*       */     //   1433: getfield firstRowInBatch : I
/*       */     //   1436: if_icmpne -> 1447
/*       */     //   1439: aload_0
/*       */     //   1440: getfield lastBoundCharLens : [I
/*       */     //   1443: iload_3
/*       */     //   1444: iaload
/*       */     //   1445: istore #9
/*       */     //   1447: aload_0
/*       */     //   1448: getfield currentBatchCharLens : [I
/*       */     //   1451: iload_3
/*       */     //   1452: iaload
/*       */     //   1453: iload #9
/*       */     //   1455: if_icmpge -> 1466
/*       */     //   1458: aload_0
/*       */     //   1459: getfield currentBatchCharLens : [I
/*       */     //   1462: iload_3
/*       */     //   1463: iload #9
/*       */     //   1465: iastore
/*       */     //   1466: aload_0
/*       */     //   1467: getfield currentRowCharLens : [I
/*       */     //   1470: iload_3
/*       */     //   1471: iconst_0
/*       */     //   1472: iastore
/*       */     //   1473: aload_0
/*       */     //   1474: getfield currentBatchFormOfUse : [S
/*       */     //   1477: iload_3
/*       */     //   1478: aload_0
/*       */     //   1479: getfield currentRowFormOfUse : [S
/*       */     //   1482: iload_3
/*       */     //   1483: saload
/*       */     //   1484: sastore
/*       */     //   1485: iinc #3, 1
/*       */     //   1488: goto -> 1406
/*       */     //   1491: aload_0
/*       */     //   1492: getfield currentRowNeedToPrepareBinds : Z
/*       */     //   1495: ifeq -> 1503
/*       */     //   1498: aload_0
/*       */     //   1499: iconst_1
/*       */     //   1500: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1503: aload_0
/*       */     //   1504: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1507: ifnull -> 1568
/*       */     //   1510: aload_0
/*       */     //   1511: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1514: astore #9
/*       */     //   1516: aload_0
/*       */     //   1517: aload_0
/*       */     //   1518: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1521: putfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1524: aload #9
/*       */     //   1526: ifnonnull -> 1541
/*       */     //   1529: aload_0
/*       */     //   1530: getfield numberOfBindPositions : I
/*       */     //   1533: anewarray oracle/jdbc/driver/Accessor
/*       */     //   1536: astore #9
/*       */     //   1538: goto -> 1562
/*       */     //   1541: iconst_0
/*       */     //   1542: istore_3
/*       */     //   1543: iload_3
/*       */     //   1544: aload_0
/*       */     //   1545: getfield numberOfBindPositions : I
/*       */     //   1548: if_icmpge -> 1562
/*       */     //   1551: aload #9
/*       */     //   1553: iload_3
/*       */     //   1554: aconst_null
/*       */     //   1555: aastore
/*       */     //   1556: iinc #3, 1
/*       */     //   1559: goto -> 1543
/*       */     //   1562: aload_0
/*       */     //   1563: aload #9
/*       */     //   1565: putfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1568: aload_0
/*       */     //   1569: getfield currentRank : I
/*       */     //   1572: iconst_1
/*       */     //   1573: iadd
/*       */     //   1574: istore #9
/*       */     //   1576: iload #9
/*       */     //   1578: iload_1
/*       */     //   1579: if_icmpge -> 1652
/*       */     //   1582: iload #9
/*       */     //   1584: aload_0
/*       */     //   1585: getfield numberOfBindRowsAllocated : I
/*       */     //   1588: if_icmplt -> 1638
/*       */     //   1591: aload_0
/*       */     //   1592: getfield numberOfBindRowsAllocated : I
/*       */     //   1595: iconst_1
/*       */     //   1596: ishl
/*       */     //   1597: istore #10
/*       */     //   1599: iload #10
/*       */     //   1601: iload #9
/*       */     //   1603: if_icmpgt -> 1612
/*       */     //   1606: iload #9
/*       */     //   1608: iconst_1
/*       */     //   1609: iadd
/*       */     //   1610: istore #10
/*       */     //   1612: aload_0
/*       */     //   1613: iload #10
/*       */     //   1615: invokevirtual growBinds : (I)V
/*       */     //   1618: aload_0
/*       */     //   1619: iconst_1
/*       */     //   1620: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1623: aload_0
/*       */     //   1624: getfield pushedBatches : Loracle/jdbc/driver/OraclePreparedStatement$PushedBatch;
/*       */     //   1627: ifnull -> 1638
/*       */     //   1630: aload_0
/*       */     //   1631: getfield pushedBatches : Loracle/jdbc/driver/OraclePreparedStatement$PushedBatch;
/*       */     //   1634: iconst_1
/*       */     //   1635: putfield current_batch_need_to_prepare_binds : Z
/*       */     //   1638: aload_0
/*       */     //   1639: aload_0
/*       */     //   1640: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   1643: iload #9
/*       */     //   1645: aaload
/*       */     //   1646: putfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1649: goto -> 1668
/*       */     //   1652: aload_0
/*       */     //   1653: iconst_0
/*       */     //   1654: iload_1
/*       */     //   1655: invokevirtual setupBindBuffers : (II)V
/*       */     //   1658: aload_0
/*       */     //   1659: aload_0
/*       */     //   1660: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   1663: iconst_0
/*       */     //   1664: aaload
/*       */     //   1665: putfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1668: aload_0
/*       */     //   1669: iconst_0
/*       */     //   1670: putfield currentRowNeedToPrepareBinds : Z
/*       */     //   1673: aload_0
/*       */     //   1674: iconst_0
/*       */     //   1675: putfield clearParameters : Z
/*       */     //   1678: return
/*       */     // Line number table:
/*       */     //   Java source line number -> byte code offset
/*       */     //   #1782	-> 0
/*       */     //   #1785	-> 7
/*       */     //   #1788	-> 8
/*       */     //   #1789	-> 11
/*       */     //   #1790	-> 14
/*       */     //   #1791	-> 17
/*       */     //   #1798	-> 35
/*       */     //   #1802	-> 75
/*       */     //   #1804	-> 82
/*       */     //   #1807	-> 103
/*       */     //   #1811	-> 108
/*       */     //   #1812	-> 118
/*       */     //   #1814	-> 127
/*       */     //   #1816	-> 132
/*       */     //   #1817	-> 136
/*       */     //   #1820	-> 142
/*       */     //   #1821	-> 159
/*       */     //   #1822	-> 165
/*       */     //   #1811	-> 168
/*       */     //   #1826	-> 174
/*       */     //   #1831	-> 181
/*       */     //   #1835	-> 219
/*       */     //   #1837	-> 229
/*       */     //   #1839	-> 243
/*       */     //   #1840	-> 247
/*       */     //   #1842	-> 250
/*       */     //   #1844	-> 258
/*       */     //   #1849	-> 263
/*       */     //   #1851	-> 270
/*       */     //   #1852	-> 287
/*       */     //   #1853	-> 293
/*       */     //   #1862	-> 296
/*       */     //   #1865	-> 309
/*       */     //   #1866	-> 316
/*       */     //   #1873	-> 327
/*       */     //   #1879	-> 334
/*       */     //   #1883	-> 340
/*       */     //   #1885	-> 347
/*       */     //   #1894	-> 432
/*       */     //   #1897	-> 435
/*       */     //   #1901	-> 450
/*       */     //   #1835	-> 453
/*       */     //   #1904	-> 459
/*       */     //   #1910	-> 462
/*       */     //   #1912	-> 472
/*       */     //   #1914	-> 480
/*       */     //   #1919	-> 485
/*       */     //   #1921	-> 492
/*       */     //   #1922	-> 509
/*       */     //   #1923	-> 515
/*       */     //   #1932	-> 518
/*       */     //   #1935	-> 531
/*       */     //   #1936	-> 538
/*       */     //   #1942	-> 549
/*       */     //   #1948	-> 556
/*       */     //   #1910	-> 559
/*       */     //   #1953	-> 565
/*       */     //   #1955	-> 583
/*       */     //   #1956	-> 588
/*       */     //   #1961	-> 591
/*       */     //   #1967	-> 596
/*       */     //   #1969	-> 606
/*       */     //   #1970	-> 614
/*       */     //   #1972	-> 622
/*       */     //   #1977	-> 627
/*       */     //   #1982	-> 632
/*       */     //   #1983	-> 649
/*       */     //   #1984	-> 655
/*       */     //   #1990	-> 658
/*       */     //   #1992	-> 671
/*       */     //   #2000	-> 689
/*       */     //   #2004	-> 720
/*       */     //   #1967	-> 723
/*       */     //   #2009	-> 729
/*       */     //   #2016	-> 736
/*       */     //   #2020	-> 774
/*       */     //   #2022	-> 784
/*       */     //   #2023	-> 792
/*       */     //   #2025	-> 800
/*       */     //   #2031	-> 805
/*       */     //   #2034	-> 823
/*       */     //   #2035	-> 840
/*       */     //   #2036	-> 846
/*       */     //   #2047	-> 849
/*       */     //   #2048	-> 855
/*       */     //   #2049	-> 863
/*       */     //   #2051	-> 870
/*       */     //   #2057	-> 879
/*       */     //   #2061	-> 885
/*       */     //   #2063	-> 892
/*       */     //   #2072	-> 977
/*       */     //   #2075	-> 980
/*       */     //   #2079	-> 995
/*       */     //   #2081	-> 998
/*       */     //   #2083	-> 1006
/*       */     //   #2089	-> 1011
/*       */     //   #2090	-> 1015
/*       */     //   #2092	-> 1026
/*       */     //   #2097	-> 1044
/*       */     //   #2099	-> 1047
/*       */     //   #2108	-> 1074
/*       */     //   #2112	-> 1105
/*       */     //   #2020	-> 1108
/*       */     //   #2116	-> 1114
/*       */     //   #2123	-> 1117
/*       */     //   #2125	-> 1127
/*       */     //   #2127	-> 1135
/*       */     //   #2133	-> 1140
/*       */     //   #2135	-> 1158
/*       */     //   #2136	-> 1175
/*       */     //   #2137	-> 1181
/*       */     //   #2147	-> 1184
/*       */     //   #2148	-> 1190
/*       */     //   #2149	-> 1198
/*       */     //   #2151	-> 1205
/*       */     //   #2157	-> 1214
/*       */     //   #2160	-> 1217
/*       */     //   #2165	-> 1226
/*       */     //   #2123	-> 1238
/*       */     //   #2177	-> 1244
/*       */     //   #2178	-> 1254
/*       */     //   #2181	-> 1259
/*       */     //   #2185	-> 1264
/*       */     //   #2191	-> 1269
/*       */     //   #2198	-> 1277
/*       */     //   #2207	-> 1285
/*       */     //   #2209	-> 1291
/*       */     //   #2210	-> 1299
/*       */     //   #2215	-> 1305
/*       */     //   #2216	-> 1315
/*       */     //   #2215	-> 1326
/*       */     //   #2220	-> 1332
/*       */     //   #2221	-> 1337
/*       */     //   #2227	-> 1342
/*       */     //   #2231	-> 1347
/*       */     //   #2234	-> 1352
/*       */     //   #2236	-> 1360
/*       */     //   #2242	-> 1364
/*       */     //   #2246	-> 1369
/*       */     //   #2254	-> 1374
/*       */     //   #2257	-> 1379
/*       */     //   #2264	-> 1384
/*       */     //   #2265	-> 1395
/*       */     //   #2266	-> 1401
/*       */     //   #2278	-> 1404
/*       */     //   #2280	-> 1414
/*       */     //   #2282	-> 1422
/*       */     //   #2283	-> 1439
/*       */     //   #2285	-> 1447
/*       */     //   #2286	-> 1458
/*       */     //   #2288	-> 1466
/*       */     //   #2289	-> 1473
/*       */     //   #2278	-> 1485
/*       */     //   #2294	-> 1491
/*       */     //   #2295	-> 1498
/*       */     //   #2304	-> 1503
/*       */     //   #2306	-> 1510
/*       */     //   #2308	-> 1516
/*       */     //   #2310	-> 1524
/*       */     //   #2311	-> 1529
/*       */     //   #2313	-> 1541
/*       */     //   #2314	-> 1551
/*       */     //   #2313	-> 1556
/*       */     //   #2316	-> 1562
/*       */     //   #2319	-> 1568
/*       */     //   #2321	-> 1576
/*       */     //   #2326	-> 1582
/*       */     //   #2332	-> 1591
/*       */     //   #2334	-> 1599
/*       */     //   #2335	-> 1606
/*       */     //   #2337	-> 1612
/*       */     //   #2339	-> 1618
/*       */     //   #2341	-> 1623
/*       */     //   #2342	-> 1630
/*       */     //   #2346	-> 1638
/*       */     //   #2355	-> 1652
/*       */     //   #2362	-> 1658
/*       */     //   #2367	-> 1668
/*       */     //   #2369	-> 1673
/*       */     //   #2371	-> 1678 }
/*       */   void processPlsqlIndexTabBinds(int paramInt) throws SQLException { byte b1 = 0; int i = 0; int j = 0; int k = 0; Binder[] arrayOfBinder = this.binders[paramInt]; PlsqlIbtBindInfo[] arrayOfPlsqlIbtBindInfo = (this.parameterPlsqlIbt == null) ? null : this.parameterPlsqlIbt[paramInt]; int m; for (m = 0; m < this.numberOfBindPositions; m++) { Binder binder = arrayOfBinder[m]; Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[m]; PlsqlIndexTableAccessor plsqlIndexTableAccessor = (accessor == null || accessor.defineType != 998) ? null : (PlsqlIndexTableAccessor)accessor; if (binder.type == 998) { PlsqlIbtBindInfo plsqlIbtBindInfo = arrayOfPlsqlIbtBindInfo[m]; if (plsqlIndexTableAccessor != null) { if (plsqlIbtBindInfo.element_internal_type != plsqlIndexTableAccessor.elementInternalType) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12); sQLException.fillInStackTrace(); throw sQLException; }  if (plsqlIbtBindInfo.maxLen < plsqlIndexTableAccessor.maxNumberOfElements) plsqlIbtBindInfo.maxLen = plsqlIndexTableAccessor.maxNumberOfElements;  if (plsqlIbtBindInfo.elemMaxLen < plsqlIndexTableAccessor.elementMaxLen) plsqlIbtBindInfo.elemMaxLen = plsqlIndexTableAccessor.elementMaxLen;  if (plsqlIbtBindInfo.ibtByteLength > 0) { plsqlIbtBindInfo.ibtByteLength = plsqlIbtBindInfo.elemMaxLen * plsqlIbtBindInfo.maxLen; } else { plsqlIbtBindInfo.ibtCharLength = plsqlIbtBindInfo.elemMaxLen * plsqlIbtBindInfo.maxLen; }  }  b1++; j += plsqlIbtBindInfo.ibtByteLength; k += plsqlIbtBindInfo.ibtCharLength; i += plsqlIbtBindInfo.maxLen; } else if (plsqlIndexTableAccessor != null) { b1++; j += plsqlIndexTableAccessor.ibtByteLength; k += plsqlIndexTableAccessor.ibtCharLength; i += plsqlIndexTableAccessor.maxNumberOfElements; }  }  if (b1 == 0) return;  this.ibtBindIndicatorSize = 6 + b1 * 8 + i * 2; this.ibtBindIndicators = new short[this.ibtBindIndicatorSize]; this.ibtBindIndicatorOffset = 0; if (j > 0) this.ibtBindBytes = new byte[j];  this.ibtBindByteOffset = 0; if (k > 0) this.ibtBindChars = new char[k];  this.ibtBindCharOffset = 0; m = this.ibtBindByteOffset; int n = this.ibtBindCharOffset; int i1 = this.ibtBindIndicatorOffset; int i2 = i1 + 6 + b1 * 8; this.ibtBindIndicators[i1++] = (short)(b1 >> 16); this.ibtBindIndicators[i1++] = (short)(b1 & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(j >> 16); this.ibtBindIndicators[i1++] = (short)(j & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(k >> 16); this.ibtBindIndicators[i1++] = (short)(k & 0xFFFF); for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { Binder binder = arrayOfBinder[b2]; Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[b2]; PlsqlIndexTableAccessor plsqlIndexTableAccessor = (accessor == null || accessor.defineType != 998) ? null : (PlsqlIndexTableAccessor)accessor; if (binder.type == 998) { int i3; PlsqlIbtBindInfo plsqlIbtBindInfo = arrayOfPlsqlIbtBindInfo[b2]; int i4 = plsqlIbtBindInfo.maxLen; this.ibtBindIndicators[i1++] = (short)plsqlIbtBindInfo.element_internal_type; this.ibtBindIndicators[i1++] = (short)plsqlIbtBindInfo.elemMaxLen; this.ibtBindIndicators[i1++] = (short)(i4 >> 16); this.ibtBindIndicators[i1++] = (short)(i4 & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(plsqlIbtBindInfo.curLen >> 16); this.ibtBindIndicators[i1++] = (short)(plsqlIbtBindInfo.curLen & 0xFFFF); if (plsqlIbtBindInfo.ibtByteLength > 0) { i3 = m; m += plsqlIbtBindInfo.ibtByteLength; } else { i3 = n; n += plsqlIbtBindInfo.ibtCharLength; }  this.ibtBindIndicators[i1++] = (short)(i3 >> 16); this.ibtBindIndicators[i1++] = (short)(i3 & 0xFFFF); plsqlIbtBindInfo.ibtValueIndex = i3; plsqlIbtBindInfo.ibtIndicatorIndex = i2; plsqlIbtBindInfo.ibtLengthIndex = i2 + i4; if (plsqlIndexTableAccessor != null) { plsqlIndexTableAccessor.ibtIndicatorIndex = plsqlIbtBindInfo.ibtIndicatorIndex; plsqlIndexTableAccessor.ibtLengthIndex = plsqlIbtBindInfo.ibtLengthIndex; plsqlIndexTableAccessor.ibtMetaIndex = i1 - 8; plsqlIndexTableAccessor.ibtValueIndex = i3; }  i2 += 2 * i4; } else if (plsqlIndexTableAccessor != null) { int i3, i4 = plsqlIndexTableAccessor.maxNumberOfElements; this.ibtBindIndicators[i1++] = (short)plsqlIndexTableAccessor.elementInternalType; this.ibtBindIndicators[i1++] = (short)plsqlIndexTableAccessor.elementMaxLen; this.ibtBindIndicators[i1++] = (short)(i4 >> 16); this.ibtBindIndicators[i1++] = (short)(i4 & 0xFFFF); this.ibtBindIndicators[i1++] = 0; this.ibtBindIndicators[i1++] = 0; if (plsqlIndexTableAccessor.ibtByteLength > 0) { i3 = m; m += plsqlIndexTableAccessor.ibtByteLength; } else { i3 = n; n += plsqlIndexTableAccessor.ibtCharLength; }  this.ibtBindIndicators[i1++] = (short)(i3 >> 16); this.ibtBindIndicators[i1++] = (short)(i3 & 0xFFFF); plsqlIndexTableAccessor.ibtValueIndex = i3; plsqlIndexTableAccessor.ibtIndicatorIndex = i2; plsqlIndexTableAccessor.ibtLengthIndex = i2 + i4; plsqlIndexTableAccessor.ibtMetaIndex = i1 - 8; i2 += 2 * i4; }  }  }
/*       */   void initializeBindSubRanges(int paramInt1, int paramInt2) { this.bindByteSubRange = 0; this.bindCharSubRange = 0; }
/*       */   int calculateIndicatorSubRangeSize() { return 0; }
/*       */   short getInoutIndicator(int paramInt) { return 0; }
/*  1150 */   private int maxStreamNCharsSql = 0; void initializeIndicatorSubRange() { this.bindIndicatorSubRange = calculateIndicatorSubRangeSize(); } void prepareBindPreambles(int paramInt1, int paramInt2) {} void setupBindBuffers(int paramInt1, int paramInt2) throws SQLException { try { if (this.numberOfBindPositions == 0) { if (paramInt2 != 0) { if (this.bindIndicators == null)
/*       */             allocBinds(paramInt2);  this.numberOfBoundRows = paramInt2; this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF); }  return; }  this.preparedAllBinds = this.currentBatchNeedToPrepareBinds; this.preparedCharBinds = false; this.currentBatchNeedToPrepareBinds = false; this.numberOfBoundRows = paramInt2; this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF); int i = this.bindBufferCapacity; if (this.numberOfBoundRows > this.bindBufferCapacity) { i = this.numberOfBoundRows; this.preparedAllBinds = true; }  if (this.currentBatchBindAccessors != null) { if (this.outBindAccessors == null)
/*       */           this.outBindAccessors = new Accessor[this.numberOfBindPositions];  for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { Accessor accessor = this.currentBatchBindAccessors[b1]; this.outBindAccessors[b1] = accessor; if (accessor != null) { int i8 = accessor.charLength; if (i8 == 0 || this.currentBatchCharLens[b1] < i8)
/*       */               this.currentBatchCharLens[b1] = i8;  }  }  }  int j = 0; int k = 0; int m = this.bindIndicatorSubRange + 5; int n = m; if (this.preparedAllBinds) { this.preparedCharBinds = true; Binder[] arrayOfBinder1 = this.binders[paramInt1]; for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s; int i8; Binder binder = arrayOfBinder1[b1]; int i9 = this.currentBatchCharLens[b1]; if (binder == this.theOutBinder) { Accessor accessor = this.currentBatchBindAccessors[b1]; i8 = accessor.byteLength; s = (short)accessor.defineType; } else { i8 = binder.bytelen; s = binder.type; }  k += i8; j += i9; this.bindIndicators[n + 0] = s; this.bindIndicators[n + 1] = (short)i8; this.bindIndicators[n + 2] = (short)i9; this.bindIndicators[n + 9] = this.currentBatchFormOfUse[b1]; n += 10; }  } else if (this.preparedCharBinds) { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = this.currentBatchCharLens[b1]; j += i8; this.bindIndicators[n + 2] = (short)i8; n += 10; }  } else { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = n + 2; int i9 = this.currentBatchCharLens[b1]; short s = this.bindIndicators[i8]; int i10 = (this.bindIndicators[n + 5] << 16) + (this.bindIndicators[n + 6] & 0xFFFF); boolean bool1 = (this.bindIndicators[i10] == -1) ? true : false; if (bool1 && i9 > 1)
/*       */             this.preparedCharBinds = true;  if (s >= i9 && !this.preparedCharBinds) { this.currentBatchCharLens[b1] = s; j += s; } else { this.bindIndicators[i8] = (short)i9; j += i9; this.preparedCharBinds = true; }  n += 10; }  }  if (this.preparedCharBinds)
/*       */         initializeBindSubRanges(this.numberOfBoundRows, i);  if (this.preparedAllBinds) { int i8 = this.bindByteSubRange + k * i; if (this.lastBoundNeeded || i8 > this.totalBindByteLength) { this.bindByteOffset = 0; this.bindBytes = this.connection.getByteBuffer(i8); this.totalBindByteLength = i8; }  this.bindBufferCapacity = i; this.bindIndicators[this.bindIndicatorSubRange + 1] = (short)((this.bindBufferCapacity & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 2] = (short)(this.bindBufferCapacity & 0xFFFF); }  if (this.preparedCharBinds) { int i8 = this.bindCharSubRange + j * this.bindBufferCapacity; if (this.lastBoundNeeded || i8 > this.totalBindCharLength) { this.bindCharOffset = 0; this.bindChars = this.connection.getCharBuffer(i8); this.totalBindCharLength = i8; }  this.bindByteSubRange += this.bindByteOffset; this.bindCharSubRange += this.bindCharOffset; }  int i1 = this.bindByteSubRange; int i2 = this.bindCharSubRange; int i3 = this.indicatorsOffset; int i4 = this.valueLengthsOffset; n = m; if (this.preparedCharBinds) { if (this.currentBatchBindAccessors == null) { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b1]; int i9 = (i8 == 0) ? i1 : i2; this.bindIndicators[n + 3] = (short)(i9 >> 16); this.bindIndicators[n + 4] = (short)(i9 & 0xFFFF); i1 += s * this.bindBufferCapacity; i2 += i8 * this.bindBufferCapacity; n += 10; }  } else { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b1]; int i9 = (i8 == 0) ? i1 : i2; this.bindIndicators[n + 3] = (short)(i9 >> 16); this.bindIndicators[n + 4] = (short)(i9 & 0xFFFF); Accessor accessor = this.currentBatchBindAccessors[b1]; if (accessor != null) { if (i8 > 0) { accessor.columnIndex = i2; accessor.charLength = i8; } else { accessor.columnIndex = i1; accessor.byteLength = s; }  accessor.lengthIndex = i4; accessor.indicatorIndex = i3; accessor.rowSpaceByte = this.bindBytes; accessor.rowSpaceChar = this.bindChars; accessor.rowSpaceIndicator = this.bindIndicators; if (accessor.defineType == 109 || accessor.defineType == 111)
/*       */                 accessor.setOffsets(this.bindBufferCapacity);  }  i1 += s * this.bindBufferCapacity; i2 += i8 * this.bindBufferCapacity; i3 += this.numberOfBindRowsAllocated; i4 += this.numberOfBindRowsAllocated; n += 10; }
/*       */            }
/*       */          i1 = this.bindByteSubRange; i2 = this.bindCharSubRange; i3 = this.indicatorsOffset; i4 = this.valueLengthsOffset; n = m; }
/*       */        int i5 = this.bindBufferCapacity - this.numberOfBoundRows; int i6 = this.numberOfBoundRows - 1; int i7 = i6 + paramInt1; Binder[] arrayOfBinder = this.binders[i7]; if (this.parameterOtype != null) { System.arraycopy(this.parameterDatum[i7], 0, this.lastBoundTypeBytes, 0, this.numberOfBindPositions); System.arraycopy(this.parameterOtype[i7], 0, this.lastBoundTypeOtypes, 0, this.numberOfBindPositions); }
/*       */        if (this.hasIbtBind)
/*       */         processPlsqlIndexTabBinds(paramInt1);  if (this.numReturnParams > 0 && (this.returnParamAccessors == null || this.returnParamAccessors.length < this.numReturnParams)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173); sQLException.fillInStackTrace(); throw sQLException; }
/*       */        if (this.returnParamAccessors != null)
/*       */         processDmlReturningBind();  boolean bool = (!this.sqlKind.isPlsqlOrCall() || this.currentRowBindAccessors == null) ? true : false; for (byte b = 0; b < this.numberOfBindPositions; b++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b]; this.lastBinders[b] = arrayOfBinder[b]; this.lastBoundByteLens[b] = s; for (byte b1 = 0; b1 < this.numberOfBoundRows; b1++) { int i9 = paramInt1 + b1; this.binders[i9][b].bind(this, b, b1, i9, this.bindBytes, this.bindChars, this.bindIndicators, s, i8, i1, i2, i4 + b1, i3 + b1, bool); this.binders[i9][b] = null; if (this.userStream != null)
/*       */             this.userStream[b1][b] = null;  i1 += s; i2 += i8; }
/*       */          this.lastBoundByteOffsets[b] = i1 - s; this.lastBoundCharOffsets[b] = i2 - i8; this.lastBoundInds[b] = this.bindIndicators[i3 + i6]; this.lastBoundLens[b] = this.bindIndicators[i4 + i6]; this.lastBoundCharLens[b] = 0; i1 += i5 * s; i2 += i5 * i8; i3 += this.numberOfBindRowsAllocated; i4 += this.numberOfBindRowsAllocated; n += 10; }
/*       */        this.lastBoundBytes = this.bindBytes; this.lastBoundByteOffset = this.bindByteOffset; this.lastBoundChars = this.bindChars; this.lastBoundCharOffset = this.bindCharOffset; if (this.parameterStream != null)
/*       */         this.lastBoundStream = this.parameterStream[paramInt1 + this.numberOfBoundRows - 1];  int[] arrayOfInt = this.currentBatchCharLens; this.currentBatchCharLens = this.lastBoundCharLens; this.lastBoundCharLens = arrayOfInt; this.lastBoundNeeded = false; prepareBindPreambles(this.numberOfBoundRows, this.bindBufferCapacity); }
/*       */     catch (NullPointerException nullPointerException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89); sQLException.fillInStackTrace(); throw sQLException; }
/*       */      } void releaseBuffers() { this.cachedBindCharSize = (this.bindChars != null) ? this.bindChars.length : 0; if (this.bindChars != this.lastBoundChars)
/*       */       this.connection.cacheBuffer(this.lastBoundChars);  this.lastBoundChars = null; this.connection.cacheBuffer(this.bindChars); this.bindChars = null; this.cachedBindByteSize = (this.bindBytes != null) ? this.bindBytes.length : 0; if (this.bindBytes != this.lastBoundBytes)
/*       */       this.connection.cacheBuffer(this.lastBoundBytes);  this.lastBoundBytes = null; this.connection.cacheBuffer(this.bindBytes); this.bindBytes = null; super.releaseBuffers(); }
/*       */   public void enterImplicitCache() throws SQLException { alwaysOnClose(); if (!this.connection.isClosed())
/*       */       cleanAllTempLobs();  if (this.connection.clearStatementMetaData) { this.lastBoundBytes = null; this.lastBoundChars = null; }
/*       */      clearParameters(); this.cacheState = 2; this.creationState = 1; this.currentResultSet = null; this.lastIndex = 0; this.queryTimeout = 0; this.autoRollback = 2; this.rowPrefetchChanged = false; this.currentRank = 0; this.currentRow = -1; this.validRows = 0; this.maxRows = 0; this.totalRowsVisited = 0; this.maxFieldSize = 0; this.gotLastBatch = false; this.clearParameters = true; this.scrollRset = null; this.defaultFetchDirection = 1000; this.defaultTimeZone = null; this.defaultCalendar = null; this.checkSum = 0L; this.checkSumComputationFailure = false; if (this.sqlKind.isOTHER()) { this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; }
/*       */      releaseBuffers(); this.definedColumnType = null; this.definedColumnSize = null; this.definedColumnFormOfUse = null; if (this.accessors != null) { int i = this.accessors.length; for (byte b = 0; b < i; b++) { if (this.accessors[b] != null) { (this.accessors[b]).rowSpaceByte = null; (this.accessors[b]).rowSpaceChar = null; (this.accessors[b]).rowSpaceIndicator = null; if (this.columnsDefinedByUser)
/*       */             (this.accessors[b]).externalType = 0;  }
/*       */          }
/*       */        }
/*       */      this.fixedString = this.connection.getDefaultFixedString(); this.defaultRowPrefetch = this.rowPrefetch; this.rowPrefetchInLastFetch = -1; if (this.connection.clearStatementMetaData) { this.sqlStringChanged = true; this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; if (this.userRsetType == 0) { this.userRsetType = 1; this.realRsetType = 1; }
/*       */        this.currentRowNeedToPrepareBinds = true; }
/*       */      }
/*       */   public void enterExplicitCache() throws SQLException { this.cacheState = 2; this.creationState = 2; this.defaultTimeZone = null; alwaysOnClose(); }
/*       */   public void exitImplicitCacheToActive() throws SQLException { this.cacheState = 1; this.closed = false; if (this.rowPrefetch != this.connection.getDefaultRowPrefetch())
/*       */       if (this.streamList == null) { this.rowPrefetch = this.connection.getDefaultRowPrefetch(); this.defaultRowPrefetch = this.rowPrefetch; this.rowPrefetchChanged = true; }
/*       */         if (this.batch != this.connection.getDefaultExecuteBatch())
/*       */       resetBatch();  this.processEscapes = this.connection.processEscapes; if (this.cachedDefineIndicatorSize != 0) { this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize); this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize); this.defineIndicators = new short[this.cachedDefineIndicatorSize]; if (this.accessors != null) { int i = this.accessors.length; for (byte b = 0; b < i; b++) { if (this.accessors[b] != null) { (this.accessors[b]).rowSpaceByte = this.defineBytes; (this.accessors[b]).rowSpaceChar = this.defineChars; (this.accessors[b]).rowSpaceIndicator = this.defineIndicators; }
/*       */            }
/*       */          doInitializationAfterDefineBufferRestore(); }
/*       */        }
/*       */      if (this.cachedBindCharSize != 0 || this.cachedBindByteSize != 0) { if (this.cachedBindByteSize > 0)
/*       */         this.bindBytes = this.connection.getByteBuffer(this.cachedBindByteSize);  if (this.cachedBindCharSize > 0)
/*       */         this.bindChars = this.connection.getCharBuffer(this.cachedBindCharSize);  doLocalInitialization(); }
/*       */      }
/*       */   void doLocalInitialization() {}
/*       */   void doInitializationAfterDefineBufferRestore() {}
/*       */   public void exitExplicitCacheToActive() throws SQLException { this.cacheState = 1; this.closed = false; }
/*       */   public void exitImplicitCacheToClose() throws SQLException { this.cacheState = 0; this.closed = false; synchronized (this.connection) { hardClose(); }
/*       */      }
/*       */   public void exitExplicitCacheToClose() throws SQLException { this.cacheState = 0; this.closed = false; synchronized (this.connection) { hardClose(); }
/*       */      }
/*       */   public void closeWithKey(String paramString) throws SQLException { synchronized (this.connection) { closeOrCache(paramString); }
/*       */      }
/*       */   int executeInternal() throws SQLException { this.noMoreUpdateCounts = false; this.checkSum = 0L; this.checkSumComputationFailure = false; ensureOpen(); if (this.currentRank > 0 && this.m_batchStyle == 2) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared"); sQLException.fillInStackTrace(); throw sQLException; }
/*       */      boolean bool1 = (this.userRsetType == 1) ? true : false; prepareForNewResults(true, false); processCompletedBindRow(this.sqlKind.isSELECT() ? 1 : this.batch, false); if (!bool1 && !this.scrollRsetTypeSolved)
/*       */       return doScrollPstmtExecuteUpdate() + this.prematureBatchCount;  doExecuteWithTimeout(); boolean bool2 = (this.prematureBatchCount != 0 && this.validRows > 0) ? true : false; if (!bool1) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType); if (!this.connection.accumulateBatchResult)
/*       */         bool2 = false;  }
/*       */      if (bool2) { this.validRows += this.prematureBatchCount; this.prematureBatchCount = 0; }
/*       */      if (this.sqlKind.isOTHER())
/*       */       this.needToParse = true;  return this.validRows; }
/*       */   public ResultSet executeQuery() throws SQLException { synchronized (this.connection) { this.executionType = 1; executeInternal(); if (this.userRsetType == 1) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); return (ResultSet)this.currentResultSet; }
/*       */        if (this.scrollRset == null) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.scrollRset = this.currentResultSet; }
/*       */        return (ResultSet)this.scrollRset; }
/*       */      }
/*       */   public int executeUpdate() throws SQLException { synchronized (this.connection) { this.executionType = 2; return executeInternal(); }
/*       */      }
/*       */   public boolean execute() throws SQLException { synchronized (this.connection) { this.executionType = 3; executeInternal(); return this.sqlKind.isSELECT(); }
/*       */      }
/*       */   void slideDownCurrentRow(int paramInt) { if (this.binders != null) { this.binders[paramInt] = this.binders[0]; this.binders[0] = this.currentRowBinders; }
/*       */      if (this.parameterInt != null) { int[] arrayOfInt = this.parameterInt[0]; this.parameterInt[0] = this.parameterInt[paramInt]; this.parameterInt[paramInt] = arrayOfInt; }
/*       */      if (this.parameterLong != null) { long[] arrayOfLong = this.parameterLong[0]; this.parameterLong[0] = this.parameterLong[paramInt]; this.parameterLong[paramInt] = arrayOfLong; }
/*       */      if (this.parameterFloat != null) { float[] arrayOfFloat = this.parameterFloat[0]; this.parameterFloat[0] = this.parameterFloat[paramInt]; this.parameterFloat[paramInt] = arrayOfFloat; }
/*       */      if (this.parameterDouble != null) { double[] arrayOfDouble = this.parameterDouble[0]; this.parameterDouble[0] = this.parameterDouble[paramInt]; this.parameterDouble[paramInt] = arrayOfDouble; }
/*       */      if (this.parameterBigDecimal != null) { BigDecimal[] arrayOfBigDecimal = this.parameterBigDecimal[0]; this.parameterBigDecimal[0] = this.parameterBigDecimal[paramInt]; this.parameterBigDecimal[paramInt] = arrayOfBigDecimal; }
/*       */      if (this.parameterString != null) { String[] arrayOfString = this.parameterString[0]; this.parameterString[0] = this.parameterString[paramInt]; this.parameterString[paramInt] = arrayOfString; }
/*       */      if (this.parameterDate != null) { Date[] arrayOfDate = this.parameterDate[0]; this.parameterDate[0] = this.parameterDate[paramInt]; this.parameterDate[paramInt] = arrayOfDate; }
/*       */      if (this.parameterTime != null) { Time[] arrayOfTime = this.parameterTime[0]; this.parameterTime[0] = this.parameterTime[paramInt]; this.parameterTime[paramInt] = arrayOfTime; }
/*       */      if (this.parameterTimestamp != null) { Timestamp[] arrayOfTimestamp = this.parameterTimestamp[0]; this.parameterTimestamp[0] = this.parameterTimestamp[paramInt]; this.parameterTimestamp[paramInt] = arrayOfTimestamp; }
/*       */      if (this.parameterDatum != null) { byte[][] arrayOfByte = this.parameterDatum[0]; this.parameterDatum[0] = this.parameterDatum[paramInt]; this.parameterDatum[paramInt] = arrayOfByte; }
/*       */      if (this.parameterOtype != null) { OracleTypeADT[] arrayOfOracleTypeADT = this.parameterOtype[0]; this.parameterOtype[0] = this.parameterOtype[paramInt]; this.parameterOtype[paramInt] = arrayOfOracleTypeADT; }
/*       */      if (this.parameterStream != null) { InputStream[] arrayOfInputStream = this.parameterStream[0]; this.parameterStream[0] = this.parameterStream[paramInt]; this.parameterStream[paramInt] = arrayOfInputStream; }
/*       */      if (this.userStream != null) { Object[] arrayOfObject = this.userStream[0]; this.userStream[0] = this.userStream[paramInt]; this.userStream[paramInt] = arrayOfObject; }
/*       */      }
/*  1233 */   OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException { this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*       */ 
/*       */     
/*  1236 */     this.cacheState = 1; }
/*       */   void resetBatch() { this.batch = this.connection.getDefaultExecuteBatch(); }
/*       */   public int sendBatch() throws SQLException { if (isJdbcBatchStyle()) return 0;  synchronized (this.connection) { try { ensureOpen(); if (this.currentRank <= 0) return this.connection.accumulateBatchResult ? 0 : this.validRows;  int i = this.batch; try { int j = this.currentRank; if (this.batch != this.currentRank) this.batch = this.currentRank;  setupBindBuffers(0, this.currentRank); this.currentRank--; doExecuteWithTimeout(); slideDownCurrentRow(j); } finally { if (this.batch != i) this.batch = i;  }  if (this.connection.accumulateBatchResult) { this.validRows += this.prematureBatchCount; this.prematureBatchCount = 0; }  return this.validRows; } finally { this.currentRank = 0; }  }  }
/*       */   public void setExecuteBatch(int paramInt) throws SQLException { synchronized (this.connection) { setOracleBatchStyle(); set_execute_batch(paramInt); }  }
/*       */   void set_execute_batch(int paramInt) throws SQLException { synchronized (this.connection) { if (paramInt <= 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt == this.batch) return;  if (this.currentRank > 0) { int j = this.validRows; this.prematureBatchCount = sendBatch(); this.validRows = j; }  int i = this.batch; this.batch = paramInt; if (this.numberOfBindRowsAllocated < this.batch) growBinds(this.batch);  }  }
/*       */   public final int getExecuteBatch() { return this.batch; }
/*       */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { SQLException sQLException; if (paramInt3 < 0) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramInt1 < 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  switch (paramInt2) { case -7: case -6: case -5: case 2: case 3: case 4: case 5: case 6: case 7: case 8: paramInt2 = 6; break;case 1: paramInt2 = 96; break;case 12: paramInt2 = 1; break;case 91: case 92: paramInt2 = 12; break;case -103: paramInt2 = 182; break;case -104: paramInt2 = 183; break;case -100: case 93: paramInt2 = 180; break;case -101: paramInt2 = 181; break;case -102: paramInt2 = 231; break;case -3: case -2: paramInt2 = 23; break;case 100: paramInt2 = 100; break;case 101: paramInt2 = 101; break;case -8: paramInt2 = 104; break;case 2004: paramInt2 = 113; break;case 2005: paramInt2 = 112; break;case -13: paramInt2 = 114; break;case -10: paramInt2 = 102; break;case 0: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException;default: sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }  }  }
/*       */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { int i = this.connection.getNlsRatio(); if (paramInt2 == 1 || paramInt2 == 12) { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3 * i); } else { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3); }  }  }
/*       */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3); }  }
/*       */   public ResultSetMetaData getMetaData() throws SQLException { if (this.sqlObject.getSqlKind().isSELECT()) return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, this);  return null; }
/*       */   public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException { setNullInternal(paramInt1, paramInt2, paramString); }
/*       */   void setNullInternal(int paramInt1, int paramInt2, String paramString) throws SQLException { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt2 == 2002 || paramInt2 == 2008 || paramInt2 == 2003 || paramInt2 == 2007 || paramInt2 == 2009 || paramInt2 == 2006) { synchronized (this.connection) { setNullCritical(i, paramInt2, paramString); this.currentRowCharLens[i] = 0; }  } else { setNullInternal(paramInt1, paramInt2); return; }  }
/*  1248 */   void setNullInternal(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setNullCritical(paramInt1, paramInt2); }  } void setNullCritical(int paramInt1, int paramInt2, String paramString) throws SQLException { OracleTypeCOLLECTION oracleTypeCOLLECTION; OracleTypeADT oracleTypeADT1; StructDescriptor structDescriptor; ArrayDescriptor arrayDescriptor; OpaqueDescriptor opaqueDescriptor; OracleTypeADT oracleTypeADT2 = null; Binder binder = this.theNamedTypeNullBinder; switch (paramInt2) { case 2006: binder = this.theRefTypeNullBinder;case 2002: case 2008: structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeADT2 = structDescriptor.getOracleTypeADT(); break;case 2003: arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeCOLLECTION = arrayDescriptor.getOracleTypeCOLLECTION(); break;case 2007: case 2009: opaqueDescriptor = OpaqueDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeADT1 = (OracleTypeADT)opaqueDescriptor.getPickler(); break; }  this.currentRowBinders[paramInt1] = binder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt1] = null; if (oracleTypeADT1 != null) oracleTypeADT1.getTOID();  if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt1] = oracleTypeADT1; } public void setNullAtName(String paramString1, int paramInt, String paramString2) throws SQLException { String str = paramString1.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setNullInternal(b + 1, paramInt, paramString2); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1); sQLException.fillInStackTrace(); throw sQLException; }  } public void setNull(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setNullCritical(paramInt1, paramInt2); }  } void setNullCritical(int paramInt1, int paramInt2) throws SQLException { SQLException sQLException; int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  Binder binder = null; int j = getInternalType(paramInt2); switch (j) { case 6: binder = this.theVarnumNullBinder; break;case 1: case 8: case 96: case 995: binder = this.theVarcharNullBinder; this.currentRowCharLens[i] = 1; break;case 999: binder = this.theFixedCHARNullBinder; break;case 12: binder = this.theDateNullBinder; break;case 180: binder = this.theTimestampNullBinder; break;case 181: binder = this.theTSTZNullBinder; break;case 231: binder = this.theTSLTZNullBinder; break;case 104: binder = getRowidNullBinder(i); break;case 183: binder = this.theIntervalDSNullBinder; break;case 182: binder = this.theIntervalYMNullBinder; break;case 23: case 24: binder = this.theRawNullBinder; break;case 100: binder = this.theBinaryFloatNullBinder; break;case 101: binder = this.theBinaryDoubleNullBinder; break;case 113: binder = this.theBlobNullBinder; break;case 112: binder = this.theClobNullBinder; break;case 114: binder = this.theBfileNullBinder; break;case 109: case 111: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "sqlType=" + paramInt2); sQLException.fillInStackTrace(); throw sQLException;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "sqlType=" + paramInt2); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = binder; } Binder getRowidNullBinder(int paramInt) { return this.theRowidNullBinder; } public void setNullAtName(String paramString, int paramInt) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setNull(b + 1, paramInt); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException { synchronized (this.connection) { setBooleanInternal(paramInt, paramBoolean); }  } void setBooleanInternal(int paramInt, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theBooleanBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramBoolean ? 1 : 0; } public void setByte(int paramInt, byte paramByte) throws SQLException { synchronized (this.connection) { setByteInternal(paramInt, paramByte); }  } void setByteInternal(int paramInt, byte paramByte) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theByteBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramByte; } public void setShort(int paramInt, short paramShort) throws SQLException { synchronized (this.connection) { setShortInternal(paramInt, paramShort); }  } void setShortInternal(int paramInt, short paramShort) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theShortBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramShort; } public void setInt(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setIntInternal(paramInt1, paramInt2); }  } void setIntInternal(int paramInt1, int paramInt2) throws SQLException { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theIntBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramInt2; } public void setLong(int paramInt, long paramLong) throws SQLException { synchronized (this.connection) { setLongInternal(paramInt, paramLong); }  } void setLongInternal(int paramInt, long paramLong) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theLongBinder; if (this.parameterLong == null) this.parameterLong = new long[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterLong[this.currentRank][i] = paramLong; } public void setFloat(int paramInt, float paramFloat) throws SQLException { synchronized (this.connection) { setFloatInternal(paramInt, paramFloat); }  } void setFloatInternal(int paramInt, float paramFloat) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (this.theFloatBinder == null) { this.theFloatBinder = theStaticFloatBinder; if (this.connection.setFloatAndDoubleUseBinary) this.theFloatBinder = theStaticBinaryFloatBinder;  }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theFloatBinder; if (this.theFloatBinder == theStaticFloatBinder) { if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterDouble[this.currentRank][i] = paramFloat; } else { if (this.parameterFloat == null) this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterFloat[this.currentRank][i] = paramFloat; }  } public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException { synchronized (this.connection) { setBinaryFloatInternal(paramInt, paramFloat); }  } void setBinaryFloatInternal(int paramInt, float paramFloat) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theBinaryFloatBinder; if (this.parameterFloat == null) this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterFloat[this.currentRank][i] = paramFloat; } public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException { synchronized (this.connection) { setBinaryFloatInternal(paramInt, paramBINARY_FLOAT); }  } void setBinaryFloatInternal(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBINARY_FLOAT == null) { this.currentRowBinders[i] = this.theBINARY_FLOATNullBinder; } else { this.currentRowBinders[i] = this.theBINARY_FLOATBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBINARY_FLOAT.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException { synchronized (this.connection) { setBinaryDoubleInternal(paramInt, paramDouble); }  } void setBinaryDoubleInternal(int paramInt, double paramDouble) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theBinaryDoubleBinder; if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.currentRowCharLens[i] = 0; this.parameterDouble[this.currentRank][i] = paramDouble; } public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException { synchronized (this.connection) { setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE); }  } void setBinaryDoubleInternal(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBINARY_DOUBLE == null) { this.currentRowBinders[i] = this.theBINARY_DOUBLENullBinder; } else { this.currentRowBinders[i] = this.theBINARY_DOUBLEBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBINARY_DOUBLE.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setDouble(int paramInt, double paramDouble) throws SQLException { synchronized (this.connection) { setDoubleInternal(paramInt, paramDouble); }  } void setDoubleInternal(int paramInt, double paramDouble) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (this.theDoubleBinder == null) { this.theDoubleBinder = theStaticDoubleBinder; if (this.connection.setFloatAndDoubleUseBinary) this.theDoubleBinder = theStaticBinaryDoubleBinder;  }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theDoubleBinder; if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterDouble[this.currentRank][i] = paramDouble; } public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException { synchronized (this.connection) { setBigDecimalInternal(paramInt, paramBigDecimal); }  } void setBigDecimalInternal(int paramInt, BigDecimal paramBigDecimal) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBigDecimal == null) { this.currentRowBinders[i] = this.theVarnumNullBinder; } else { this.currentRowBinders[i] = this.theBigDecimalBinder; if (this.parameterBigDecimal == null) this.parameterBigDecimal = new BigDecimal[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterBigDecimal[this.currentRank][i] = paramBigDecimal; }  this.currentRowCharLens[i] = 0; } public void setString(int paramInt, String paramString) throws SQLException { setStringInternal(paramInt, paramString); } void setStringInternal(int paramInt, String paramString) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  byte b = (paramString != null) ? paramString.length() : 0; if (!b) { basicBindNullString(paramInt); } else if (this.currentRowFormOfUse[paramInt - 1] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (b > this.maxVcsBytesPlsql || (b > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) { setStringForClobCritical(paramInt, paramString); } else if (b > this.maxVcsCharsPlsql) { int j = this.connection.conversion.encodedByteLength(paramString, false); if (j > this.maxVcsBytesPlsql) { setStringForClobCritical(paramInt, paramString); } else { basicBindString(paramInt, paramString); }  } else { basicBindString(paramInt, paramString); }  } else if (b <= this.maxVcsCharsSql) { basicBindString(paramInt, paramString); } else if (b <= this.maxStreamCharsSql) { basicBindCharacterStream(paramInt, new StringReader(paramString), b, true); } else { setStringForClobCritical(paramInt, paramString); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (b > this.maxVcsBytesPlsql || (b > this.maxVcsNCharsPlsql && this.isServerNCharSetFixedWidth)) { setStringForClobCritical(paramInt, paramString); } else if (b > this.maxVcsNCharsPlsql) { int j = this.connection.conversion.encodedByteLength(paramString, true); if (j > this.maxVcsBytesPlsql) { setStringForClobCritical(paramInt, paramString); } else { basicBindString(paramInt, paramString); }  } else { basicBindString(paramInt, paramString); }  } else if (b <= this.maxVcsCharsSql) { basicBindString(paramInt, paramString); } else if (b <= this.maxStreamNCharsSql) { setStringForClobCritical(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } void basicBindNullString(int paramInt) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; this.currentRowBinders[i] = this.theVarcharNullBinder; if (this.sqlKind.isPlsqlOrCall()) { this.currentRowCharLens[i] = this.minVcsBindSize; } else { this.currentRowCharLens[i] = 1; }  }  } void basicBindString(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; this.currentRowBinders[i] = this.theStringBinder; int j = paramString.length(); if (this.sqlKind.isPlsqlOrCall()) { int k = this.connection.minVcsBindSize; int m = j + 1; this.currentRowCharLens[i] = (m < k) ? k : m; } else { this.currentRowCharLens[i] = j + 1; }  if (this.parameterString == null) this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterString[this.currentRank][i] = paramString; }  } public void setStringForClob(int paramInt, String paramString) throws SQLException { if (paramString == null) { setNull(paramInt, 1); return; }  int i = paramString.length(); if (i == 0) { setNull(paramInt, 1); return; }  if (this.sqlKind.isPlsqlOrCall()) { if (i <= this.maxVcsCharsPlsql) { setStringInternal(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } else if (i <= this.maxVcsCharsSql) { setStringInternal(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } void setStringForClobCritical(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); cLOB.setString(1L, paramString); addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } void setReaderContentsForClobCritical(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramReader = isReaderEmpty(paramReader)) == null) { if (paramBoolean) throw new IOException(paramLong + " char of CLOB data cannot be read");  setCLOBInternal(paramInt, (CLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); OracleClobWriter oracleClobWriter = (OracleClobWriter)cLOB.setCharacterStream(1L); int i = cLOB.getBufferSize(); char[] arrayOfChar = new char[i]; long l = 0L; int j = 0; l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramReader.read(arrayOfChar); } else { j = paramReader.read(arrayOfChar, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " char of CLOB data cannot be read");  break; }  oracleClobWriter.write(arrayOfChar, 0, j); l -= j; }  oracleClobWriter.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } void setAsciiStreamContentsForClobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null) { if (paramBoolean) throw new IOException(paramLong + " byte of CLOB data cannot be read");  setCLOBInternal(paramInt, (CLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); OracleClobWriter oracleClobWriter = (OracleClobWriter)cLOB.setCharacterStream(1L); int i = cLOB.getBufferSize(); byte[] arrayOfByte = new byte[i]; char[] arrayOfChar = new char[i]; int j = 0; long l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramInputStream.read(arrayOfByte); } else { j = paramInputStream.read(arrayOfByte, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " byte of CLOB data cannot be read");  break; }  DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar); oracleClobWriter.write(arrayOfChar, 0, j); l -= j; }  oracleClobWriter.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { super(paramPhysicalConnection, paramInt1, paramInt2, paramInt3, paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  5294 */     this.SetBigStringTryClob = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9919 */     this.m_batchStyle = 0; this.cacheState = 1; if (paramInt1 > 1) setOracleBatchStyle();  this.theSetCHARBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianSetCHARBinder : theStaticSetCHARBinder; this.theURowidBinder = this.theRowidBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianRowidBinder : theStaticRowidBinder; this.statementType = 1; this.currentRow = -1; this.needToParse = true; this.processEscapes = paramPhysicalConnection.processEscapes; this.sqlObject.initialize(paramString); this.sqlKind = this.sqlObject.getSqlKind(); this.clearParameters = true; this.scrollRsetTypeSolved = false; this.prematureBatchCount = 0; initializeBinds(); this.minVcsBindSize = paramPhysicalConnection.minVcsBindSize; this.maxRawBytesSql = paramPhysicalConnection.maxRawBytesSql; this.maxRawBytesPlsql = paramPhysicalConnection.maxRawBytesPlsql; this.maxVcsCharsSql = paramPhysicalConnection.maxVcsCharsSql; this.maxVcsNCharsSql = paramPhysicalConnection.maxVcsNCharsSql; this.maxVcsBytesPlsql = paramPhysicalConnection.maxVcsBytesPlsql; this.maxIbtVarcharElementLength = paramPhysicalConnection.maxIbtVarcharElementLength; this.maxCharSize = this.connection.conversion.sMaxCharSize; this.maxNCharSize = this.connection.conversion.maxNCharSize; this.maxVcsCharsPlsql = this.maxVcsBytesPlsql / this.maxCharSize; this.maxVcsNCharsPlsql = this.maxVcsBytesPlsql / this.maxNCharSize; this.maxStreamCharsSql = Integer.MAX_VALUE / this.maxCharSize; this.maxStreamNCharsSql = this.maxRawBytesSql / this.maxNCharSize; this.isServerCharSetFixedWidth = this.connection.conversion.isServerCharSetFixedWidth; this.isServerNCharSetFixedWidth = this.connection.conversion.isServerNCharSetFixedWidth; }
/*       */   public void setStringForClobAtName(String paramString1, String paramString2) throws SQLException { String str = paramString1.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setStringForClob(b + 1, paramString2); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1); sQLException.fillInStackTrace(); throw sQLException; }  }
/*       */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { setFixedCHARInternal(paramInt, paramString); }  }
/*       */   void setFixedCHARInternal(int paramInt, String paramString) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  int j = 0; if (paramString != null) j = paramString.length();  if (j > 32766) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 157); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString == null) { this.currentRowBinders[i] = this.theFixedCHARNullBinder; this.currentRowCharLens[i] = 1; } else { this.currentRowBinders[i] = this.theFixedCHARBinder; this.currentRowCharLens[i] = j + 1; if (this.parameterString == null) this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterString[this.currentRank][i] = paramString; }  }
/*       */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException { synchronized (this.connection) { setCursorInternal(paramInt, paramResultSet); }  }
/*       */   void setCursorInternal(int paramInt, ResultSet paramResultSet) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException { synchronized (this.connection) { setROWIDInternal(paramInt, paramROWID); }  }
/*       */   void setROWIDInternal(int paramInt, ROWID paramROWID) throws SQLException { if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) { if (paramROWID == null) { setNull(paramInt, 12); } else { setStringInternal(paramInt, paramROWID.stringValue()); }  return; }  int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramROWID == null || paramROWID.shareBytes() == null) { this.currentRowBinders[i] = this.theRowidNullBinder; } else { this.currentRowBinders[i] = T4CRowidAccessor.isUROWID(paramROWID.shareBytes(), 0) ? this.theURowidBinder : this.theRowidBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramROWID.getBytes(); }  this.currentRowCharLens[i] = 0; }
/*       */   public void setArray(int paramInt, Array paramArray) throws SQLException { setARRAYInternal(paramInt, (ARRAY)paramArray); }
/*       */   void setArrayInternal(int paramInt, Array paramArray) throws SQLException { setARRAYInternal(paramInt, (ARRAY)paramArray); }
/*       */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException { setARRAYInternal(paramInt, paramARRAY); }
/*  9930 */   void setARRAYInternal(int paramInt, ARRAY paramARRAY) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramARRAY == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setArrayCritical(i, paramARRAY); this.currentRowCharLens[i] = 0; }  } void setArrayCritical(int paramInt, ARRAY paramARRAY) throws SQLException { ArrayDescriptor arrayDescriptor = paramARRAY.getDescriptor(); if (arrayDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramARRAY.toBytes(); OracleTypeCOLLECTION oracleTypeCOLLECTION = arrayDescriptor.getOracleTypeCOLLECTION(); oracleTypeCOLLECTION.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = (OracleTypeADT)oracleTypeCOLLECTION; } public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException { setOPAQUEInternal(paramInt, paramOPAQUE); } void setOPAQUEInternal(int paramInt, OPAQUE paramOPAQUE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramOPAQUE == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setOPAQUECritical(i, paramOPAQUE); this.currentRowCharLens[i] = 0; }  } void setOPAQUECritical(int paramInt, OPAQUE paramOPAQUE) throws SQLException { OpaqueDescriptor opaqueDescriptor = paramOPAQUE.getDescriptor(); if (opaqueDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramOPAQUE.toBytes(); OracleTypeADT oracleTypeADT = (OracleTypeADT)opaqueDescriptor.getPickler(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } void setSQLXMLInternal(int paramInt, SQLXML paramSQLXML) throws SQLException { if (paramSQLXML == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  setOPAQUEInternal(paramInt, (OPAQUE)paramSQLXML); } public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { setStructDescriptorInternal(paramInt, paramStructDescriptor); } void setStructDescriptorInternal(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramStructDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setStructDescriptorCritical(i, paramStructDescriptor); this.currentRowCharLens[i] = 0; }  } void setStructDescriptorCritical(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  OracleTypeADT oracleTypeADT = paramStructDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setStructDescriptorInternal(b + 1, paramStructDescriptor); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } void setPreBindsCompelete() throws SQLException {} public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException { setSTRUCTInternal(paramInt, paramSTRUCT); } void setSTRUCTInternal(int paramInt, STRUCT paramSTRUCT) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramSTRUCT == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setSTRUCTCritical(i, paramSTRUCT); this.currentRowCharLens[i] = 0; }  } void setSTRUCTCritical(int paramInt, STRUCT paramSTRUCT) throws SQLException { StructDescriptor structDescriptor = paramSTRUCT.getDescriptor(); if (structDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramSTRUCT.toBytes(); OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setRAW(int paramInt, RAW paramRAW) throws SQLException { setRAWInternal(paramInt, paramRAW); } final void setOracleBatchStyle() throws SQLException { if (this.m_batchStyle == 2) {
/*       */ 
/*       */       
/*  9933 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with JDBC-2.0-style batching");
/*  9934 */       sQLException.fillInStackTrace();
/*  9935 */       throw sQLException;
/*       */     } 
/*       */     
/*  9938 */     if (this.m_batchStyle == 0);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9943 */     this.m_batchStyle = 1; } void setRAWInternal(int paramInt, RAW paramRAW) throws SQLException { boolean bool = false; synchronized (this.connection) { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramRAW == null) { this.currentRowBinders[i] = this.theRawNullBinder; } else { bool = true; }  }  if (bool) setBytesInternal(paramInt, paramRAW.getBytes());  } public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException { synchronized (this.connection) { setCHARInternal(paramInt, paramCHAR); }  } void setCHARInternal(int paramInt, CHAR paramCHAR) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramCHAR == null || paramCHAR.getLength() == 0L) { this.currentRowBinders[i] = this.theSetCHARNullBinder; this.currentRowCharLens[i] = 1; } else { byte[] arrayOfByte; short s = (short)paramCHAR.oracleId(); this.currentRowBinders[i] = this.theSetCHARBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  CharacterSet characterSet = (this.currentRowFormOfUse[i] == 2) ? this.connection.setCHARNCharSetObj : this.connection.setCHARCharSetObj; if (characterSet != null && characterSet.getOracleId() != s) { byte[] arrayOfByte1 = paramCHAR.shareBytes(); arrayOfByte = characterSet.convert(paramCHAR.getCharacterSet(), arrayOfByte1, 0, arrayOfByte1.length); } else { arrayOfByte = paramCHAR.getBytes(); }  this.parameterDatum[this.currentRank][i] = arrayOfByte; this.currentRowCharLens[i] = (arrayOfByte.length + 1 >> 1) + 1; }  if (this.sqlKind.isPlsqlOrCall()) if (this.currentRowCharLens[i] < this.minVcsBindSize) this.currentRowCharLens[i] = this.minVcsBindSize;   } public void setDATE(int paramInt, DATE paramDATE) throws SQLException { synchronized (this.connection) { setDATEInternal(paramInt, paramDATE); }  } void setDATEInternal(int paramInt, DATE paramDATE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramDATE == null) { this.currentRowBinders[i] = this.theDateNullBinder; } else { this.currentRowBinders[i] = this.theOracleDateBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramDATE.getBytes(); }  } public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException { synchronized (this.connection) { setNUMBERInternal(paramInt, paramNUMBER); }  } void setNUMBERInternal(int paramInt, NUMBER paramNUMBER) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramNUMBER == null) { this.currentRowBinders[i] = this.theVarnumNullBinder; } else { this.currentRowBinders[i] = this.theOracleNumberBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramNUMBER.getBytes(); }  } public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException { synchronized (this.connection) { setBLOBInternal(paramInt, paramBLOB); }  } void setBLOBInternal(int paramInt, BLOB paramBLOB) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramBLOB == null) { this.currentRowBinders[i] = this.theBlobNullBinder; } else { this.currentRowBinders[i] = this.theBlobBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBLOB.getBytes(); }  } public void setBlob(int paramInt, Blob paramBlob) throws SQLException { synchronized (this.connection) { setBLOBInternal(paramInt, (BLOB)paramBlob); }  } void setBlobInternal(int paramInt, Blob paramBlob) throws SQLException { setBLOBInternal(paramInt, (BLOB)paramBlob); } public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException { synchronized (this.connection) { setCLOBInternal(paramInt, paramCLOB); }  } void setCLOBInternal(int paramInt, CLOB paramCLOB) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramCLOB == null) { this.currentRowBinders[i] = this.theClobNullBinder; } else { this.currentRowBinders[i] = this.theClobBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramCLOB.getBytes(); }  } public void setClob(int paramInt, Clob paramClob) throws SQLException { synchronized (this.connection) { setCLOBInternal(paramInt, (CLOB)paramClob); }  } void setClobInternal(int paramInt, Clob paramClob) throws SQLException { setCLOBInternal(paramInt, (CLOB)paramClob); } public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException { synchronized (this.connection) { setBFILEInternal(paramInt, paramBFILE); }  } void setBFILEInternal(int paramInt, BFILE paramBFILE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramBFILE == null) { this.currentRowBinders[i] = this.theBfileNullBinder; } else { this.currentRowBinders[i] = this.theBfileBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBFILE.getBytes(); }  } public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException { synchronized (this.connection) { setBFILEInternal(paramInt, paramBFILE); }  } void setBfileInternal(int paramInt, BFILE paramBFILE) throws SQLException { setBFILEInternal(paramInt, paramBFILE); } public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException { setBytesInternal(paramInt, paramArrayOfbyte); } void setBytesInternal(int paramInt, byte[] paramArrayOfbyte) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  byte b = (paramArrayOfbyte != null) ? paramArrayOfbyte.length : 0; if (!b) { setNullInternal(paramInt, -2); } else if (this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) { if (b > this.maxRawBytesPlsql) { setBytesForBlobCritical(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } else if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) { if (b > this.maxRawBytesPlsql) { setBytesForBlobCritical(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } else if (b > this.maxRawBytesSql) { bindBytesAsStream(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } void bindBytesAsStream(int paramInt, byte[] paramArrayOfbyte) throws SQLException { int i = paramArrayOfbyte.length; byte[] arrayOfByte = new byte[i]; System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, i); set_execute_batch(1); basicBindBinaryStream(paramInt, new ByteArrayInputStream(arrayOfByte), i, true); } void basicBindBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; Binder binder = this.sqlKind.isPlsqlOrCall() ? this.thePlsqlRawBinder : this.theRawBinder; this.currentRowBinders[i] = binder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramArrayOfbyte; this.currentRowCharLens[i] = 0; }  } void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { basicBindBinaryStream(paramInt1, paramInputStream, paramInt2, false); } void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (paramBoolean) { this.currentRowBinders[i] = this.theLongRawStreamForBytesBinder; } else { this.currentRowBinders[i] = this.theLongRawStreamBinder; }  if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramInputStream, 6, paramInt2) : this.connection.conversion.ConvertStream(paramInputStream, 6, paramInt2); this.currentRowCharLens[i] = 0; }  } public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException { if (paramArrayOfbyte == null) { setNull(paramInt, -2); return; }  int i = paramArrayOfbyte.length; if (i == 0) { setNull(paramInt, -2); return; }  if (this.sqlKind.isPlsqlOrCall()) { if (i <= this.maxRawBytesPlsql) { setBytes(paramInt, paramArrayOfbyte); } else { setBytesForBlobCritical(paramInt, paramArrayOfbyte); }  } else if (i <= this.maxRawBytesSql) { setBytes(paramInt, paramArrayOfbyte); } else { setBytesForBlobCritical(paramInt, paramArrayOfbyte); }  } void setBytesForBlobCritical(int paramInt, byte[] paramArrayOfbyte) throws SQLException { BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); bLOB.putBytes(1L, paramArrayOfbyte); addToTempLobsToFree(bLOB); this.lastBoundBlobs[paramInt - 1] = bLOB; setBLOBInternal(paramInt, bLOB); } void setBinaryStreamContentsForBlobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null) { if (paramBoolean) throw new IOException(paramLong + " byte of BLOB data cannot be read");  setBLOBInternal(paramInt, (BLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); OracleBlobOutputStream oracleBlobOutputStream = (OracleBlobOutputStream)bLOB.setBinaryStream(1L); int i = bLOB.getBufferSize(); byte[] arrayOfByte = new byte[i]; long l = 0L; int j = 0; l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramInputStream.read(arrayOfByte); } else { j = paramInputStream.read(arrayOfByte, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " byte of BLOB data cannot be read");  break; }  oracleBlobOutputStream.write(arrayOfByte, 0, j); l -= j; }  oracleBlobOutputStream.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(bLOB); this.lastBoundBlobs[paramInt - 1] = bLOB; setBLOBInternal(paramInt, bLOB); }  } public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setBytesForBlob(b + 1, paramArrayOfbyte); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } public void setInternalBytes(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException { synchronized (this.connection) { setInternalBytesInternal(paramInt1, paramArrayOfbyte, paramInt2); }  } void setInternalBytesInternal(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setDate(int paramInt, Date paramDate) throws SQLException { synchronized (this.connection) { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, getDefaultCalendar())); }  } void setDateInternal(int paramInt, Date paramDate) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, getDefaultCalendar())); } public void setTime(int paramInt, Time paramTime) throws SQLException { synchronized (this.connection) { setTimeInternal(paramInt, paramTime); }  } void setTimeInternal(int paramInt, Time paramTime) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTime == null) { this.currentRowBinders[i] = this.theDateNullBinder; } else { this.currentRowBinders[i] = this.theTimeBinder; if (this.parameterTime == null) this.parameterTime = new Time[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterTime[this.currentRank][i] = paramTime; }  this.currentRowCharLens[i] = 0; } public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException { synchronized (this.connection) { setTimestampInternal(paramInt, paramTimestamp); }  } void setTimestampInternal(int paramInt, Timestamp paramTimestamp) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTimestamp == null) { this.currentRowBinders[i] = this.theTimestampNullBinder; } else { this.currentRowBinders[i] = this.theTimestampBinder; if (this.parameterTimestamp == null) this.parameterTimestamp = new Timestamp[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterTimestamp[this.currentRank][i] = paramTimestamp; }  this.currentRowCharLens[i] = 0; } public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException { synchronized (this.connection) { setINTERVALYMInternal(paramInt, paramINTERVALYM); }  } void setINTERVALYMInternal(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramINTERVALYM == null) { this.currentRowBinders[i] = this.theIntervalYMNullBinder; } else { this.currentRowBinders[i] = this.theIntervalYMBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramINTERVALYM.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException { synchronized (this.connection) { setINTERVALDSInternal(paramInt, paramINTERVALDS); }  } void setINTERVALDSInternal(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramINTERVALDS == null) { this.currentRowBinders[i] = this.theIntervalDSNullBinder; } else { this.currentRowBinders[i] = this.theIntervalDSBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramINTERVALDS.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException { synchronized (this.connection) { setTIMESTAMPInternal(paramInt, paramTIMESTAMP); }  } void setTIMESTAMPInternal(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMP == null) { this.currentRowBinders[i] = this.theTimestampNullBinder; } else { this.currentRowBinders[i] = this.theOracleTimestampBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMP.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException { synchronized (this.connection) { setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ); }  } void setTIMESTAMPTZInternal(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMPTZ == null) { this.currentRowBinders[i] = this.theTSTZNullBinder; } else { this.currentRowBinders[i] = this.theTSTZBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMPTZ.getBytes(); }  this.currentRowCharLens[i] = 0; }
/*       */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException { synchronized (this.connection) { setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ); }  }
/*       */   void setTIMESTAMPLTZInternal(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException { if (this.connection.getSessionTimeZone() == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 105); sQLException.fillInStackTrace(); throw sQLException; }  int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMPLTZ == null) { this.currentRowBinders[i] = this.theTSLTZNullBinder; } else { this.currentRowBinders[i] = this.theTSLTZBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMPLTZ.getBytes(); }  this.currentRowCharLens[i] = 0; }
/*       */   private Reader isReaderEmpty(Reader paramReader) throws IOException { if (!paramReader.markSupported()) paramReader = new BufferedReader(paramReader, 5);  paramReader.mark(100); int i; if ((i = paramReader.read()) == -1) return null;  paramReader.reset(); return paramReader; }
/*       */   private InputStream isInputStreamEmpty(InputStream paramInputStream) throws IOException { if (!paramInputStream.markSupported()) paramInputStream = new BufferedInputStream(paramInputStream, 5);  paramInputStream.mark(100); int i; if ((i = paramInputStream.read()) == -1) return null;  paramInputStream.reset(); return paramInputStream; }
/*       */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2); }  }
/*       */   void setAsciiStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2, true); }
/*  9950 */   boolean isOracleBatchStyle() { return (this.m_batchStyle == 1); } void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { basicBindNullString(paramInt); } else { if (this.userRsetType != 1 && (paramLong > this.maxVcsCharsSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (this.currentRowFormOfUse[i] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (paramLong <= this.maxVcsCharsPlsql) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  } else if (paramLong <= this.maxVcsCharsSql) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else if (paramLong > 2147483647L) { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else { basicBindAsciiStream(paramInt, paramInputStream, (int)paramLong); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong <= this.maxVcsNCharsPlsql) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  } else if (paramLong <= this.maxVcsNCharsSql) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  }  } void basicBindAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { if (this.userRsetType != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  int i = paramInt1 - 1; this.currentRowBinders[i] = this.theLongStreamBinder; if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 5, paramInt2); this.currentRowCharLens[i] = 0; }  } void setAsciiStreamContentsForStringInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramInputStream.read(arrayOfByte, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i == 0) basicBindNullString(paramInt1);  char[] arrayOfChar = new char[paramInt2]; DBConversion.asciiBytesToJavaChars(arrayOfByte, i, arrayOfChar); basicBindString(paramInt1, new String(arrayOfChar)); } public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2); } void setBinaryStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2, true); } void checkUserStreamForDuplicates(Object paramObject, int paramInt) throws SQLException { if (paramObject == null) return;  if (this.userStream != null) { for (Object[] arrayOfObject : this.userStream) { for (Object object : arrayOfObject) { if (object == paramObject) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 270, Integer.valueOf(paramInt + 1)); sQLException.fillInStackTrace(); throw sQLException; }  }  }  } else { this.userStream = new Object[this.numberOfBindRowsAllocated][this.numberOfBindPositions]; }  this.userStream[this.currentRank][paramInt] = paramObject; } void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { setRAWInternal(paramInt, (RAW)null); } else { if (this.userRsetType != 1 && (paramLong > this.maxRawBytesSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxRawBytesPlsql) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else { setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong); }  } else if (paramLong > 2147483647L) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (paramLong > this.maxRawBytesSql) { basicBindBinaryStream(paramInt, paramInputStream, (int)paramLong); } else { setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong); }  }  }  } void setBinaryStreamContentsForByteArrayInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramInputStream.read(arrayOfByte, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { byte[] arrayOfByte1 = new byte[i]; System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i); arrayOfByte = arrayOfByte1; }  setBytesInternal(paramInt1, arrayOfByte); } public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2); } void setUnicodeStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { setStringInternal(paramInt1, (String)null); } else { if (this.userRsetType != 1 && paramInt2 > this.maxVcsCharsSql) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (this.sqlKind.isPlsqlOrCall() || paramInt2 <= this.maxVcsCharsSql) { byte[] arrayOfByte = new byte[paramInt2]; int j = 0; int k = paramInt2; try { int m; while (k > 0 && (m = paramInputStream.read(arrayOfByte, j, k)) != -1) { j += m; k -= m; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  char[] arrayOfChar = new char[j >> 1]; DBConversion.ucs2BytesToJavaChars(arrayOfByte, j, arrayOfChar); setStringInternal(paramInt1, new String(arrayOfChar)); } else { this.currentRowBinders[i] = this.theLongStreamBinder; if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 4, paramInt2); this.currentRowCharLens[i] = 0; }  }  }  } public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException { synchronized (this.connection) { setObjectInternal(paramInt, this.connection.toDatum(paramCustomDatum)); }  } void setCustomDatumInternal(int paramInt, CustomDatum paramCustomDatum) throws SQLException { synchronized (this.connection) { Datum datum = this.connection.toDatum(paramCustomDatum); int i = sqlTypeForObject(datum); setObjectCritical(paramInt, datum, i, 0); }  } public void setORAData(int paramInt, ORAData paramORAData) throws SQLException { setORADataInternal(paramInt, paramORAData); }
/*       */   void setORADataInternal(int paramInt, ORAData paramORAData) throws SQLException { synchronized (this.connection) { Datum datum = paramORAData.toDatum((Connection)this.connection); int i = sqlTypeForObject(datum); setObjectCritical(paramInt, datum, i, 0); if (i == 2002 || i == 2008 || i == 2003) this.currentRowCharLens[paramInt - 1] = 0;  }  }
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { setObjectInternal(paramInt1, paramObject, paramInt2, paramInt3); }  }
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { if (paramObject == null && paramInt2 != 2002 && paramInt2 != 2008 && paramInt2 != 2003 && paramInt2 != 2007 && paramInt2 != 2006 && paramInt2 != 2009) { setNullInternal(paramInt1, paramInt2); } else if (paramInt2 == 2002 || paramInt2 == 2008 || paramInt2 == 2003 || paramInt2 == 2009) { setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3); this.currentRowCharLens[paramInt1 - 1] = 0; } else { setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3); }  }
/*       */   void setObjectCritical(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { switch (paramInt2) { case -15: setFormOfUse(paramInt1, (short)2);case 1: if (paramObject instanceof CHAR) { setCHARInternal(paramInt1, (CHAR)paramObject); } else if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -9: setFormOfUse(paramInt1, (short)2);case 12: if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 999: setFixedCHARInternal(paramInt1, (String)paramObject); return;case -16: setFormOfUse(paramInt1, (short)2);case -1: if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 2: if (paramObject instanceof NUMBER) { setNUMBERInternal(paramInt1, (NUMBER)paramObject); } else if (paramObject instanceof Integer) { setIntInternal(paramInt1, ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setLongInternal(paramInt1, ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setFloatInternal(paramInt1, ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setDoubleInternal(paramInt1, ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setBigDecimalInternal(paramInt1, (BigDecimal)paramObject); } else if (paramObject instanceof String) { setNUMBERInternal(paramInt1, new NUMBER((String)paramObject, paramInt3)); } else if (paramObject instanceof Boolean) { setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0); } else if (paramObject instanceof Short) { setShortInternal(paramInt1, ((Short)paramObject).shortValue()); } else if (paramObject instanceof Byte) { setByteInternal(paramInt1, ((Byte)paramObject).byteValue()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 3: if (paramObject instanceof BigDecimal) { setBigDecimalInternal(paramInt1, (BigDecimal)paramObject); } else if (paramObject instanceof Number) { setBigDecimalInternal(paramInt1, new BigDecimal(((Number)paramObject).doubleValue())); } else if (paramObject instanceof NUMBER) { setBigDecimalInternal(paramInt1, ((NUMBER)paramObject).bigDecimalValue()); } else if (paramObject instanceof String) { setBigDecimalInternal(paramInt1, new BigDecimal((String)paramObject)); } else if (paramObject instanceof Boolean) { setBigDecimalInternal(paramInt1, new BigDecimal(((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -7: if (paramObject instanceof Boolean) { setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof String) { setByteInternal(paramInt1, (byte)(("true".equalsIgnoreCase((String)paramObject) || "1".equals(paramObject)) ? 1 : 0)); } else if (paramObject instanceof Number) { setIntInternal(paramInt1, (((Number)paramObject).byteValue() != 0) ? 1 : 0); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -6: if (paramObject instanceof Number) { setByteInternal(paramInt1, ((Number)paramObject).byteValue()); } else if (paramObject instanceof String) { setByteInternal(paramInt1, Byte.parseByte((String)paramObject)); } else if (paramObject instanceof Boolean) { setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 5: if (paramObject instanceof Number) { setShortInternal(paramInt1, ((Number)paramObject).shortValue()); } else if (paramObject instanceof String) { setShortInternal(paramInt1, Short.parseShort((String)paramObject)); } else if (paramObject instanceof Boolean) { setShortInternal(paramInt1, (short)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 4: if (paramObject instanceof Number) { setIntInternal(paramInt1, ((Number)paramObject).intValue()); } else if (paramObject instanceof String) { setIntInternal(paramInt1, Integer.parseInt((String)paramObject)); } else if (paramObject instanceof Boolean) { setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -5: if (paramObject instanceof Number) { setLongInternal(paramInt1, ((Number)paramObject).longValue()); } else if (paramObject instanceof String) { setLongInternal(paramInt1, Long.parseLong((String)paramObject)); } else if (paramObject instanceof Boolean) { setLongInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1L : 0L); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 7: if (paramObject instanceof Number) { setFloatInternal(paramInt1, ((Number)paramObject).floatValue()); } else if (paramObject instanceof String) { setFloatInternal(paramInt1, Float.valueOf((String)paramObject).floatValue()); } else if (paramObject instanceof Boolean) { setFloatInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0F : 0.0F); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 6: case 8: if (paramObject instanceof Number) { setDoubleInternal(paramInt1, ((Number)paramObject).doubleValue()); } else if (paramObject instanceof String) { setDoubleInternal(paramInt1, Double.valueOf((String)paramObject).doubleValue()); } else if (paramObject instanceof Boolean) { setDoubleInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -2: if (paramObject instanceof RAW) { setRAWInternal(paramInt1, (RAW)paramObject); } else { setBytesInternal(paramInt1, (byte[])paramObject); }  return;case -3: setBytesInternal(paramInt1, (byte[])paramObject); return;case -4: setBytesInternal(paramInt1, (byte[])paramObject); return;case 91: if (paramObject instanceof DATE) { setDATEInternal(paramInt1, (DATE)paramObject); } else if (paramObject instanceof Date) { setDATEInternal(paramInt1, new DATE(paramObject, getDefaultCalendar())); } else if (paramObject instanceof Timestamp) { setDATEInternal(paramInt1, new DATE((Timestamp)paramObject)); } else if (paramObject instanceof String) { setDateInternal(paramInt1, Date.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 92: if (paramObject instanceof Time) { setTimeInternal(paramInt1, (Time)paramObject); } else if (paramObject instanceof Timestamp) { setTimeInternal(paramInt1, new Time(((Timestamp)paramObject).getTime())); } else if (paramObject instanceof Date) { setTimeInternal(paramInt1, new Time(((Date)paramObject).getTime())); } else if (paramObject instanceof String) { setTimeInternal(paramInt1, Time.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 93: if (paramObject instanceof TIMESTAMP) { setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject); } else if (paramObject instanceof Timestamp) { setTimestampInternal(paramInt1, (Timestamp)paramObject); } else if (paramObject instanceof Date) { setTIMESTAMPInternal(paramInt1, new TIMESTAMP((Date)paramObject)); } else if (paramObject instanceof DATE) { setTIMESTAMPInternal(paramInt1, new TIMESTAMP(((DATE)paramObject).timestampValue())); } else if (paramObject instanceof String) { setTimestampInternal(paramInt1, Timestamp.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -100: setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject); return;case -101: setTIMESTAMPTZInternal(paramInt1, (TIMESTAMPTZ)paramObject); return;case -102: setTIMESTAMPLTZInternal(paramInt1, (TIMESTAMPLTZ)paramObject); return;case -103: setINTERVALYMInternal(paramInt1, (INTERVALYM)paramObject); return;case -104: setINTERVALDSInternal(paramInt1, (INTERVALDS)paramObject); return;case -8: setROWIDInternal(paramInt1, (ROWID)paramObject); return;case 100: setBinaryFloatInternal(paramInt1, (BINARY_FLOAT)paramObject); return;case 101: setBinaryDoubleInternal(paramInt1, (BINARY_DOUBLE)paramObject); return;case 2004: setBLOBInternal(paramInt1, (BLOB)paramObject); return;case 2005: case 2011: setCLOBInternal(paramInt1, (CLOB)paramObject); if (((CLOB)paramObject).isNCLOB()) setFormOfUse(paramInt1, (short)2);  return;case -13: setBFILEInternal(paramInt1, (BFILE)paramObject); return;case 2002: case 2008: setSTRUCTInternal(paramInt1, STRUCT.toSTRUCT(paramObject, (OracleConnection)this.connection)); return;case 2003: setARRAYInternal(paramInt1, ARRAY.toARRAY(paramObject, (OracleConnection)this.connection)); return;case 2007: setOPAQUEInternal(paramInt1, (OPAQUE)paramObject); return;case 2006: setREFInternal(paramInt1, (REF)paramObject); return;case 2009: setSQLXMLInternal(paramInt1, (SQLXML)paramObject); return; }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setObjectInternal(b + 1, paramObject); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  }
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException { setObjectInternal(paramInt1, paramObject, paramInt2, 0); }
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2) throws SQLException { setObjectInternal(paramInt1, paramObject, paramInt2, 0); }
/*       */   public void setRefType(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*       */   void setRefTypeInternal(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*       */   public void setRef(int paramInt, Ref paramRef) throws SQLException { setREFInternal(paramInt, (REF)paramRef); }
/*       */   void setRefInternal(int paramInt, Ref paramRef) throws SQLException { setREFInternal(paramInt, (REF)paramRef); }
/*       */   public void setREF(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*  9963 */   final void setJdbcBatchStyle() throws SQLException { if (this.m_batchStyle == 1) {
/*       */ 
/*       */       
/*  9966 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with Oracle-style batching");
/*  9967 */       sQLException.fillInStackTrace();
/*  9968 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  9972 */     this.m_batchStyle = 2; } void setREFInternal(int paramInt, REF paramREF) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramREF == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  setREFCritical(i, paramREF); this.currentRowCharLens[i] = 0; } void setREFCritical(int paramInt, REF paramREF) throws SQLException { StructDescriptor structDescriptor = paramREF.getDescriptor(); if (structDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 52); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theRefTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramREF.getBytes(); OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setObject(int paramInt, Object paramObject) throws SQLException { setObjectInternal(paramInt, paramObject); } void setObjectInternal(int paramInt, Object paramObject) throws SQLException { if (paramObject instanceof ORAData) { setORADataInternal(paramInt, (ORAData)paramObject); } else if (paramObject instanceof CustomDatum) { setCustomDatumInternal(paramInt, (CustomDatum)paramObject); } else { int i = sqlTypeForObject(paramObject); setObjectInternal(paramInt, paramObject, i, 0); }  } public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException { setObjectInternal(paramInt, paramDatum); } void setOracleObjectInternal(int paramInt, Datum paramDatum) throws SQLException { setObjectInternal(paramInt, paramDatum); } public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException { synchronized (this.connection) { setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5); }  } void setPlsqlIndexTableInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException { Datum[] arrayOfDatum; String[] arrayOfString2; SQLException sQLException; int k, i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramObject == null) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 271); sQLException1.fillInStackTrace(); throw sQLException1; }  int j = getInternalType(paramInt4); String[] arrayOfString1 = null; switch (j) { case 1: case 96: arrayOfString2 = null; k = 0; if (paramObject instanceof CHAR[]) { CHAR[] arrayOfCHAR = (CHAR[])paramObject; k = arrayOfCHAR.length; arrayOfString2 = new String[k]; for (byte b = 0; b < k; b++) { CHAR cHAR = arrayOfCHAR[b]; if (cHAR != null) arrayOfString2[b] = cHAR.getString();  }  } else if (paramObject instanceof String[]) { arrayOfString2 = (String[])paramObject; k = arrayOfString2.length; } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramInt5 == 0 && arrayOfString2 != null) for (byte b = 0; b < k; b++) { String str = arrayOfString2[b]; if (str != null && paramInt5 < str.length()) paramInt5 = str.length();  }   arrayOfString1 = arrayOfString2; break;case 2: case 6: arrayOfDatum = OracleTypeNUMBER.toNUMBERArray(paramObject, this.connection, 1L, paramInt3); if (paramInt5 == 0 && arrayOfDatum != null) paramInt5 = 22;  this.currentRowCharLens[i] = 0; break;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97); sQLException.fillInStackTrace(); throw sQLException; }  if (arrayOfDatum.length == 0 && paramInt2 == 0) { sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 272); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.thePlsqlIbtBinder; if (this.parameterPlsqlIbt == null) this.parameterPlsqlIbt = new PlsqlIbtBindInfo[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterPlsqlIbt[this.currentRank][i] = new PlsqlIbtBindInfo((Object[])arrayOfDatum, paramInt2, paramInt3, j, paramInt5); this.hasIbtBind = true; } public void setPlsqlIndexTableAtName(String paramString, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { synchronized (this.connection) { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setPlsqlIndexTableInternal(b + 1, paramObject, paramInt1, paramInt2, paramInt3, paramInt4); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  }  } void endOfResultSet(boolean paramBoolean) throws SQLException { if (!paramBoolean) prepareForNewResults(false, false);  this.rowPrefetchInLastFetch = -1; } int sqlTypeForObject(Object paramObject) { if (paramObject == null) return 0;  if (!(paramObject instanceof Datum)) { if (paramObject instanceof String) return this.fixedString ? 999 : 12;  if (paramObject instanceof BigDecimal) return 2;  if (paramObject instanceof Boolean) return -7;  if (paramObject instanceof Integer) return 4;  if (paramObject instanceof Long) return -5;  if (paramObject instanceof Float) return 7;  if (paramObject instanceof Double) return 8;  if (paramObject instanceof byte[]) return -3;  if (paramObject instanceof Short) return 5;  if (paramObject instanceof Byte) return -6;  if (paramObject instanceof Date) return 91;  if (paramObject instanceof Time) return 92;  if (paramObject instanceof Timestamp) return 93;  if (paramObject instanceof java.sql.SQLData) return 2002;  if (paramObject instanceof oracle.jdbc.internal.ObjectData) return 2002;  } else { if (paramObject instanceof BINARY_FLOAT) return 100;  if (paramObject instanceof BINARY_DOUBLE) return 101;  if (paramObject instanceof BLOB) return 2004;  if (paramObject instanceof CLOB) return 2005;  if (paramObject instanceof BFILE) return -13;  if (paramObject instanceof ROWID) return -8;  if (paramObject instanceof NUMBER) return 2;  if (paramObject instanceof DATE) return 91;  if (paramObject instanceof TIMESTAMP) return 93;  if (paramObject instanceof TIMESTAMPTZ) return -101;  if (paramObject instanceof TIMESTAMPLTZ) return -102;  if (paramObject instanceof REF) return 2006;  if (paramObject instanceof CHAR) return 1;  if (paramObject instanceof RAW) return -2;  if (paramObject instanceof ARRAY) return 2003;  if (paramObject instanceof STRUCT) return 2002;  if (paramObject instanceof OPAQUE) return 2007;  if (paramObject instanceof INTERVALYM) return -103;  if (paramObject instanceof INTERVALDS) return -104;  if (paramObject instanceof SQLXML) return 2009;  }  return 1111; }
/*       */   public void clearParameters() throws SQLException { synchronized (this.connection) { this.clearParameters = true; for (byte b = 0; b < this.numberOfBindPositions; b++) this.currentRowBinders[b] = null;  }  }
/*       */   void printByteArray(byte[] paramArrayOfbyte) { if (paramArrayOfbyte != null) { int i = paramArrayOfbyte.length; for (byte b = 0; b < i; b++) { int j = paramArrayOfbyte[b] & 0xFF; if (j < 16); }  }  }
/*       */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { setCharacterStreamInternal(paramInt1, paramReader, paramInt2); }
/*       */   void setCharacterStreamInternal(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { setCharacterStreamInternal(paramInt1, paramReader, paramInt2, true); }
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramReader, i); if (paramReader == null) { basicBindNullString(paramInt); } else { if (this.userRsetType != 1 && (paramLong > this.maxVcsCharsSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (this.currentRowFormOfUse[i] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxVcsBytesPlsql || (paramLong > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (paramLong <= this.maxVcsCharsPlsql) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, false); }  } else if (paramLong <= this.maxVcsCharsSql) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else if (paramLong > 2147483647L) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else { basicBindCharacterStream(paramInt, paramReader, (int)paramLong, false); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxVcsBytesPlsql || (paramLong > this.maxVcsNCharsPlsql && this.isServerCharSetFixedWidth)) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (paramLong <= this.maxVcsNCharsPlsql) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, true); }  } else if (paramLong <= this.maxVcsNCharsSql) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); }  }  }
/*       */   void basicBindCharacterStream(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (paramBoolean) { this.currentRowBinders[i] = this.theLongStreamForStringBinder; } else { this.currentRowBinders[i] = this.theLongStreamBinder; }  if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]) : this.connection.conversion.ConvertStream(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]); this.currentRowCharLens[i] = 0; }  }
/*       */   void setReaderContentsForStringOrClobInVariableWidthCase(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException { char[] arrayOfChar = new char[paramInt2]; int i = 0; int j = paramInt2; try { int m; while (j > 0 && (m = paramReader.read(arrayOfChar, i, j)) != -1) { i += m; j -= m; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { char[] arrayOfChar1 = new char[i]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i); arrayOfChar = arrayOfChar1; }  int k = this.connection.conversion.encodedByteLength(arrayOfChar, paramBoolean); if (k < this.maxVcsBytesPlsql) { setStringInternal(paramInt1, new String(arrayOfChar)); } else { setStringForClobCritical(paramInt1, new String(arrayOfChar)); }  }
/*       */   void setReaderContentsForStringInternal(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { char[] arrayOfChar = new char[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramReader.read(arrayOfChar, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { char[] arrayOfChar1 = new char[i]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i); arrayOfChar = arrayOfChar1; }  setStringInternal(paramInt1, new String(arrayOfChar)); }
/*       */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, paramCalendar)); }
/*       */   void setDateInternal(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, paramCalendar)); }
/*       */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramTime == null) ? null : new DATE(paramTime, paramCalendar)); }
/*       */   void setTimeInternal(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramTime == null) ? null : new DATE(paramTime, paramCalendar)); }
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { setTimestampInternal(paramInt, paramTimestamp, paramCalendar); }
/*       */   void setTimestampInternal(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { setTIMESTAMPInternal(paramInt, (paramTimestamp == null) ? null : new TIMESTAMP(paramTimestamp, paramCalendar)); }
/*       */   public void setCheckBindTypes(boolean paramBoolean) { this.checkBindTypes = paramBoolean; }
/*  9988 */   final void checkIfJdbcBatchExists() throws SQLException { if (doesJdbcBatchExist()) {
/*       */ 
/*       */       
/*  9991 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/*  9992 */       sQLException.fillInStackTrace();
/*  9993 */       throw sQLException;
/*       */     }  }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean doesJdbcBatchExist() {
/* 10002 */     if (this.currentRank > 0 && this.m_batchStyle == 2) {
/* 10003 */       return true;
/*       */     }
/* 10005 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isJdbcBatchStyle() {
/* 10012 */     return (this.m_batchStyle == 2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch() throws SQLException {
/* 10033 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10048 */       setJdbcBatchStyle();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10058 */       processCompletedBindRow(this.currentRank + 2, (this.currentRank > 0 && this.sqlKind.isPlsqlOrCall()));
/*       */ 
/*       */ 
/*       */       
/* 10062 */       this.currentRank++;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch(String paramString) throws SQLException {
/* 10072 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10075 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10076 */       sQLException.fillInStackTrace();
/* 10077 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearBatch() throws SQLException {
/* 10096 */     synchronized (this.connection) {
/*       */       
/* 10098 */       for (int i = this.currentRank - 1; i >= 0; i--) {
/* 10099 */         for (byte b = 0; b < this.numberOfBindPositions; b++)
/* 10100 */           this.binders[i][b] = null; 
/*       */       } 
/* 10102 */       this.currentRank = 0;
/*       */       
/* 10104 */       if (this.binders != null) {
/* 10105 */         this.currentRowBinders = this.binders[0];
/*       */       }
/* 10107 */       this.pushedBatches = null;
/* 10108 */       this.pushedBatchesTail = null;
/* 10109 */       this.firstRowInBatch = 0;
/*       */       
/* 10111 */       this.clearParameters = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void executeForRowsWithTimeout(boolean paramBoolean) throws SQLException {
/* 10124 */     if (this.queryTimeout > 0) {
/*       */ 
/*       */       
/*       */       try {
/* 10128 */         this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
/* 10129 */         this.isExecuting = true;
/* 10130 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally {
/*       */         
/* 10134 */         this.connection.getTimeout().cancelTimeout();
/* 10135 */         this.isExecuting = false;
/*       */       } 
/*       */     } else {
/*       */ 
/*       */       
/*       */       try {
/*       */         
/* 10142 */         this.isExecuting = true;
/* 10143 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally {
/*       */         
/* 10147 */         this.isExecuting = false;
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int[] executeBatch() throws SQLException {
/* 10174 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10177 */       int[] arrayOfInt = new int[this.currentRank];
/* 10178 */       this.checkSum = 0L;
/* 10179 */       this.checkSumComputationFailure = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10185 */       byte b = 0;
/*       */       
/* 10187 */       cleanOldTempLobs();
/* 10188 */       setJdbcBatchStyle();
/*       */       
/* 10190 */       if (this.currentRank > 0) {
/*       */ 
/*       */ 
/*       */         
/* 10194 */         ensureOpen();
/*       */ 
/*       */         
/* 10197 */         prepareForNewResults(true, true);
/*       */         
/* 10199 */         if (this.sqlKind.isSELECT()) {
/*       */ 
/*       */           
/* 10202 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, 0, (int[])null);
/* 10203 */           batchUpdateException.fillInStackTrace();
/* 10204 */           throw batchUpdateException;
/*       */         } 
/*       */ 
/*       */ 
/*       */         
/* 10209 */         this.noMoreUpdateCounts = false;
/*       */         
/* 10211 */         int i = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         try {
/* 10223 */           this.connection.registerHeartbeat();
/*       */           
/* 10225 */           this.connection.needLine();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10231 */           if (!this.isOpen) {
/*       */             
/* 10233 */             this.connection.open(this);
/*       */             
/* 10235 */             this.isOpen = true;
/*       */           } 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10241 */           int j = this.currentRank;
/*       */           
/* 10243 */           if (this.pushedBatches == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 10248 */             setupBindBuffers(0, this.currentRank);
/* 10249 */             executeForRowsWithTimeout(false);
/*       */ 
/*       */           
/*       */           }
/*       */           else {
/*       */ 
/*       */ 
/*       */             
/* 10257 */             if (this.currentRank > this.firstRowInBatch)
/*       */             {
/*       */ 
/*       */               
/* 10261 */               pushBatch(true);
/*       */             }
/* 10263 */             boolean bool = this.needToParse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             do {
/* 10271 */               PushedBatch pushedBatch = this.pushedBatches;
/*       */               
/* 10273 */               this.currentBatchCharLens = pushedBatch.currentBatchCharLens;
/* 10274 */               this.lastBoundCharLens = pushedBatch.lastBoundCharLens;
/* 10275 */               this.lastBoundNeeded = pushedBatch.lastBoundNeeded;
/* 10276 */               this.currentBatchBindAccessors = pushedBatch.currentBatchBindAccessors;
/* 10277 */               this.needToParse = pushedBatch.need_to_parse;
/* 10278 */               this.currentBatchNeedToPrepareBinds = pushedBatch.current_batch_need_to_prepare_binds;
/*       */               
/* 10280 */               this.firstRowInBatch = pushedBatch.first_row_in_batch;
/*       */               
/* 10282 */               setupBindBuffers(pushedBatch.first_row_in_batch, pushedBatch.number_of_rows_to_be_bound);
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 10287 */               this.currentRank = pushedBatch.number_of_rows_to_be_bound;
/*       */               
/* 10289 */               executeForRowsWithTimeout(false);
/*       */               
/* 10291 */               i += this.validRows;
/* 10292 */               if (this.sqlKind.isPlsqlOrCall())
/*       */               {
/* 10294 */                 arrayOfInt[b++] = this.validRows;
/*       */               }
/*       */               
/* 10297 */               this.pushedBatches = pushedBatch.next;
/*       */             
/*       */             }
/* 10300 */             while (this.pushedBatches != null);
/*       */ 
/*       */             
/* 10303 */             this.pushedBatchesTail = null;
/* 10304 */             this.firstRowInBatch = 0;
/*       */             
/* 10306 */             this.needToParse = bool;
/*       */           } 
/*       */ 
/*       */ 
/*       */           
/* 10311 */           slideDownCurrentRow(j);
/*       */ 
/*       */         
/*       */         }
/* 10315 */         catch (SQLException sQLException) {
/*       */ 
/*       */ 
/*       */           
/* 10319 */           int j = this.currentRank;
/* 10320 */           clearBatch();
/* 10321 */           this.needToParse = true;
/*       */           
/* 10323 */           if (!this.sqlKind.isPlsqlOrCall())
/*       */           {
/*       */ 
/*       */ 
/*       */             
/* 10328 */             if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch != j) {
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 10333 */               arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 10334 */               for (b = 0; b < this.numberOfExecutedElementsInBatch; b++) {
/* 10335 */                 arrayOfInt[b] = -2;
/*       */               }
/*       */             } else {
/* 10338 */               for (b = 0; b < arrayOfInt.length; b++)
/* 10339 */                 arrayOfInt[b] = -3; 
/*       */             }  } 
/* 10341 */           resetCurrentRowBinders();
/*       */ 
/*       */           
/* 10344 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(sQLException, this.sqlKind.isPlsqlOrCall() ? b : arrayOfInt.length, arrayOfInt);
/* 10345 */           batchUpdateException.fillInStackTrace();
/* 10346 */           throw batchUpdateException;
/*       */         
/*       */         }
/*       */         finally {
/*       */           
/* 10351 */           if (this.sqlKind.isPlsqlOrCall() || i > this.validRows) {
/* 10352 */             this.validRows = i;
/*       */           }
/* 10354 */           checkValidRowsStatus();
/*       */           
/* 10356 */           this.currentRank = 0;
/*       */         } 
/*       */         
/* 10359 */         if (this.validRows < 0) {
/*       */           
/* 10361 */           for (b = 0; b < arrayOfInt.length; b++) {
/* 10362 */             arrayOfInt[b] = -3;
/*       */           }
/*       */           
/* 10365 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, 0, arrayOfInt);
/* 10366 */           batchUpdateException.fillInStackTrace();
/* 10367 */           throw batchUpdateException;
/*       */         } 
/*       */         
/* 10370 */         if (!this.sqlKind.isPlsqlOrCall())
/*       */         {
/* 10372 */           for (b = 0; b < arrayOfInt.length; b++) {
/* 10373 */             arrayOfInt[b] = -2;
/*       */           }
/*       */         }
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10381 */       this.connection.registerHeartbeat();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10387 */       return arrayOfInt;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void pushBatch(boolean paramBoolean) {
/* 10395 */     PushedBatch pushedBatch = new PushedBatch();
/*       */     
/* 10397 */     pushedBatch.currentBatchCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10399 */     System.arraycopy(this.currentBatchCharLens, 0, pushedBatch.currentBatchCharLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 10402 */     pushedBatch.lastBoundCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10404 */     System.arraycopy(this.lastBoundCharLens, 0, pushedBatch.lastBoundCharLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 10407 */     if (this.currentBatchBindAccessors != null) {
/*       */       
/* 10409 */       pushedBatch.currentBatchBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */       
/* 10411 */       System.arraycopy(this.currentBatchBindAccessors, 0, pushedBatch.currentBatchBindAccessors, 0, this.numberOfBindPositions);
/*       */     } 
/*       */ 
/*       */     
/* 10415 */     pushedBatch.lastBoundNeeded = this.lastBoundNeeded;
/* 10416 */     pushedBatch.need_to_parse = this.needToParse;
/* 10417 */     pushedBatch.current_batch_need_to_prepare_binds = this.currentBatchNeedToPrepareBinds;
/* 10418 */     pushedBatch.first_row_in_batch = this.firstRowInBatch;
/* 10419 */     pushedBatch.number_of_rows_to_be_bound = this.currentRank - this.firstRowInBatch;
/*       */     
/* 10421 */     if (this.pushedBatches == null) {
/* 10422 */       this.pushedBatches = pushedBatch;
/*       */     } else {
/* 10424 */       this.pushedBatchesTail.next = pushedBatch;
/*       */     } 
/* 10426 */     this.pushedBatchesTail = pushedBatch;
/*       */     
/* 10428 */     if (!paramBoolean) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10434 */       int[] arrayOfInt = this.currentBatchCharLens;
/*       */       
/* 10436 */       this.currentBatchCharLens = this.lastBoundCharLens;
/* 10437 */       this.lastBoundCharLens = arrayOfInt;
/*       */       
/* 10439 */       this.lastBoundNeeded = false;
/*       */       
/* 10441 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/* 10442 */         this.currentBatchCharLens[b] = 0;
/*       */       }
/* 10444 */       this.firstRowInBatch = this.currentRank;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int doScrollPstmtExecuteUpdate() throws SQLException {
/* 10458 */     doScrollExecuteCommon();
/*       */     
/* 10460 */     if (this.sqlKind.isSELECT()) {
/* 10461 */       this.scrollRsetTypeSolved = true;
/*       */     }
/* 10463 */     return this.validRows;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int copyBinds(Statement paramStatement, int paramInt) throws SQLException {
/* 10478 */     if (this.numberOfBindPositions > 0) {
/*       */       
/* 10480 */       OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)paramStatement;
/*       */       
/* 10482 */       int i = this.bindIndicatorSubRange + 5;
/*       */       
/* 10484 */       int j = this.bindByteSubRange;
/* 10485 */       int k = this.bindCharSubRange;
/* 10486 */       int m = this.indicatorsOffset;
/* 10487 */       int n = this.valueLengthsOffset;
/*       */       
/* 10489 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*       */         
/* 10491 */         short s1 = this.bindIndicators[i + 0];
/*       */         
/* 10493 */         short s2 = this.bindIndicators[i + 1];
/*       */         
/* 10495 */         short s3 = this.bindIndicators[i + 2];
/*       */ 
/*       */         
/* 10498 */         int i1 = b + paramInt;
/*       */ 
/*       */ 
/*       */         
/* 10502 */         if (oraclePreparedStatement.parameterDatum == null) {
/* 10503 */           oraclePreparedStatement.parameterDatum = new byte[oraclePreparedStatement.numberOfBindRowsAllocated][oraclePreparedStatement.numberOfBindPositions][];
/*       */         }
/*       */         
/* 10506 */         if (oraclePreparedStatement.parameterOtype == null) {
/* 10507 */           oraclePreparedStatement.parameterOtype = new OracleTypeADT[oraclePreparedStatement.numberOfBindRowsAllocated][oraclePreparedStatement.numberOfBindPositions];
/*       */         }
/*       */         
/* 10510 */         if (this.bindIndicators[m] == -1) {
/*       */           
/* 10512 */           oraclePreparedStatement.currentRowBinders[i1] = copiedNullBinder(s1, s2);
/*       */           
/* 10514 */           if (s3 > 0) {
/* 10515 */             oraclePreparedStatement.currentRowCharLens[i1] = 1;
/*       */           }
/* 10517 */         } else if (s1 == 109 || s1 == 111) {
/*       */           
/* 10519 */           oraclePreparedStatement.currentRowBinders[i1] = (s1 == 109) ? this.theNamedTypeBinder : this.theRefTypeBinder;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10524 */           byte[] arrayOfByte1 = this.parameterDatum[0][b];
/* 10525 */           int i2 = arrayOfByte1.length;
/* 10526 */           byte[] arrayOfByte2 = new byte[i2];
/*       */           
/* 10528 */           oraclePreparedStatement.parameterDatum[0][i1] = arrayOfByte2;
/*       */           
/* 10530 */           System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i2);
/*       */           
/* 10532 */           oraclePreparedStatement.parameterOtype[0][i1] = this.parameterOtype[0][b];
/*       */         }
/* 10534 */         else if (s2 > 0) {
/*       */           
/* 10536 */           oraclePreparedStatement.currentRowBinders[i1] = copiedByteBinder(s1, this.bindBytes, j, s2, this.bindIndicators[n]);
/*       */         
/*       */         }
/* 10539 */         else if (s3 > 0) {
/*       */           
/* 10541 */           oraclePreparedStatement.currentRowBinders[i1] = copiedCharBinder(s1, this.bindChars, k, s3, this.bindIndicators[n], getInoutIndicator(b));
/*       */           
/* 10543 */           oraclePreparedStatement.currentRowCharLens[i1] = s3;
/*       */         }
/*       */         else {
/*       */           
/* 10547 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "copyBinds doesn't understand type " + s1);
/* 10548 */           sQLException.fillInStackTrace();
/* 10549 */           throw sQLException;
/*       */         } 
/*       */         
/* 10552 */         j += this.bindBufferCapacity * s2;
/* 10553 */         k += this.bindBufferCapacity * s3;
/* 10554 */         m += this.numberOfBindRowsAllocated;
/* 10555 */         n += this.numberOfBindRowsAllocated;
/* 10556 */         i += 10;
/*       */       } 
/*       */     } 
/*       */     
/* 10560 */     return this.numberOfBindPositions;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedNullBinder(short paramShort, int paramInt) throws SQLException {
/* 10567 */     return new CopiedNullBinder(paramShort, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedByteBinder(short paramShort1, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, short paramShort2) throws SQLException {
/* 10575 */     byte[] arrayOfByte = new byte[paramInt2];
/*       */     
/* 10577 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*       */     
/* 10579 */     return new CopiedByteBinder(paramShort1, paramInt2, arrayOfByte, paramShort2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedCharBinder(short paramShort1, char[] paramArrayOfchar, int paramInt1, int paramInt2, short paramShort2, short paramShort3) throws SQLException {
/* 10587 */     char[] arrayOfChar = new char[paramInt2];
/*       */     
/* 10589 */     System.arraycopy(paramArrayOfchar, paramInt1, arrayOfChar, 0, paramInt2);
/*       */     
/* 10591 */     return new CopiedCharBinder(paramShort1, arrayOfChar, paramShort2, paramShort3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void hardClose() throws SQLException {
/* 10599 */     super.hardClose();
/*       */     
/* 10601 */     this.connection.cacheBuffer(this.bindBytes);
/* 10602 */     this.bindBytes = null;
/* 10603 */     this.connection.cacheBuffer(this.bindChars);
/* 10604 */     this.bindChars = null;
/* 10605 */     this.bindIndicators = null;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10610 */     if (!this.connection.isClosed())
/*       */     {
/* 10612 */       cleanAllTempLobs();
/*       */     }
/*       */     
/* 10615 */     this.lastBoundBytes = null;
/* 10616 */     this.lastBoundChars = null;
/*       */     
/* 10618 */     clearParameters();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void alwaysOnClose() throws SQLException {
/* 10630 */     if (this.currentRank > 0)
/*       */     {
/* 10632 */       if (this.m_batchStyle == 2) {
/* 10633 */         clearBatch();
/*       */       
/*       */       }
/*       */       else {
/*       */ 
/*       */         
/* 10639 */         int i = this.validRows;
/*       */         
/* 10641 */         this.prematureBatchCount = sendBatch();
/* 10642 */         this.validRows = i;
/*       */       } 
/*       */     }
/*       */     
/* 10646 */     super.alwaysOnClose();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDisableStmtCaching(boolean paramBoolean) {
/* 10659 */     synchronized (this.connection) {
/*       */       
/* 10661 */       if (paramBoolean == true) {
/* 10662 */         this.cacheState = 3;
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFormOfUse(int paramInt, short paramShort) {
/* 10672 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10675 */       int i = paramInt - 1;
/*       */       
/* 10677 */       if (this.currentRowFormOfUse[i] != paramShort) {
/*       */         
/* 10679 */         this.currentRowFormOfUse[i] = paramShort;
/*       */ 
/*       */ 
/*       */         
/* 10683 */         if (this.currentRowBindAccessors != null) {
/*       */           
/* 10685 */           Accessor accessor = this.currentRowBindAccessors[i];
/*       */           
/* 10687 */           if (accessor != null) {
/* 10688 */             accessor.setFormOfUse(paramShort);
/*       */           }
/*       */         } 
/*       */         
/* 10692 */         if (this.returnParamAccessors != null) {
/*       */           
/* 10694 */           Accessor accessor = this.returnParamAccessors[i];
/*       */           
/* 10696 */           if (accessor != null) {
/* 10697 */             accessor.setFormOfUse(paramShort);
/*       */           }
/*       */         } 
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/* 10724 */     setURLInternal(paramInt, paramURL);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setURLInternal(int paramInt, URL paramURL) throws SQLException {
/* 10731 */     setStringInternal(paramInt, paramURL.toString());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 10738 */     return (ParameterMetaData)new OracleParameterMetaData(this.sqlObject.getParameterCount());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
/* 10761 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10762 */     sQLException.fillInStackTrace();
/* 10763 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2) throws SQLException {
/* 10773 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 10775 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10776 */       sQLException.fillInStackTrace();
/* 10777 */       throw sQLException;
/*       */     } 
/*       */     
/* 10780 */     if (this.numReturnParams <= 0) {
/*       */       
/* 10782 */       this.numReturnParams = this.sqlObject.getReturnParameterCount();
/* 10783 */       if (this.numReturnParams <= 0) {
/*       */         
/* 10785 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10786 */         sQLException.fillInStackTrace();
/* 10787 */         throw sQLException;
/*       */       } 
/*       */     } 
/*       */     
/* 10791 */     int i = paramInt1 - 1;
/* 10792 */     if (i < this.numberOfBindPositions - this.numReturnParams || paramInt1 > this.numberOfBindPositions) {
/*       */ 
/*       */       
/* 10795 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10796 */       sQLException.fillInStackTrace();
/* 10797 */       throw sQLException;
/*       */     } 
/*       */     
/* 10800 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10802 */     short s = 0;
/* 10803 */     if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[i] != 0) {
/* 10804 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10806 */     registerReturnParameterInternal(i, j, paramInt2, -1, s, null);
/*       */ 
/*       */     
/* 10809 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 10820 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 10822 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10823 */       sQLException.fillInStackTrace();
/* 10824 */       throw sQLException;
/*       */     } 
/*       */     
/* 10827 */     int i = paramInt1 - 1;
/* 10828 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/* 10830 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10831 */       sQLException.fillInStackTrace();
/* 10832 */       throw sQLException;
/*       */     } 
/*       */     
/* 10835 */     if (paramInt2 != 1 && paramInt2 != 12 && paramInt2 != -1 && paramInt2 != -2 && paramInt2 != -3 && paramInt2 != -4 && paramInt2 != 12) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10844 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10845 */       sQLException.fillInStackTrace();
/* 10846 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10850 */     if (paramInt3 <= 0) {
/*       */ 
/*       */       
/* 10853 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10854 */       sQLException.fillInStackTrace();
/* 10855 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10859 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10861 */     short s = 0;
/* 10862 */     if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[i] != 0) {
/* 10863 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10865 */     registerReturnParameterInternal(i, j, paramInt2, paramInt3, s, null);
/*       */ 
/*       */     
/* 10868 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 10879 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 10881 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10882 */       sQLException.fillInStackTrace();
/* 10883 */       throw sQLException;
/*       */     } 
/*       */     
/* 10886 */     int i = paramInt1 - 1;
/* 10887 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/* 10889 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10890 */       sQLException.fillInStackTrace();
/* 10891 */       throw sQLException;
/*       */     } 
/*       */     
/* 10894 */     int j = getInternalTypeForDmlReturning(paramInt2);
/* 10895 */     if (j != 111 && j != 109) {
/*       */ 
/*       */ 
/*       */       
/* 10899 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10900 */       sQLException.fillInStackTrace();
/* 10901 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10905 */     registerReturnParameterInternal(i, j, paramInt2, -1, (short)0, paramString);
/*       */ 
/*       */     
/* 10908 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ResultSet getReturnResultSet() throws SQLException {
/* 10916 */     if (this.closed) {
/*       */       
/* 10918 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 10919 */       sQLException.fillInStackTrace();
/* 10920 */       throw sQLException;
/*       */     } 
/*       */     
/* 10923 */     if (this.returnParamAccessors == null || this.numReturnParams == 0) {
/*       */       
/* 10925 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 10926 */       sQLException.fillInStackTrace();
/* 10927 */       throw sQLException;
/*       */     } 
/*       */     
/* 10930 */     if (this.returnResultSet == null || this.numReturnParams == 0 || !this.isOpen)
/*       */     {
/*       */ 
/*       */       
/* 10934 */       this.returnResultSet = new OracleReturnResultSet(this);
/*       */     }
/*       */     
/* 10937 */     return (ResultSet)this.returnResultSet;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int getInternalTypeForDmlReturning(int paramInt) throws SQLException {
/* 10951 */     char c = Character.MIN_VALUE;
/*       */     
/* 10953 */     switch (paramInt) {
/*       */       
/*       */       case -7:
/*       */       case -6:
/*       */       case -5:
/*       */       case 2:
/*       */       case 3:
/*       */       case 4:
/*       */       case 5:
/*       */       case 6:
/*       */       case 7:
/*       */       case 8:
/* 10965 */         c = '\006';
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 11087 */         return c;case 100: c = 'd'; return c;case 101: c = 'e'; return c;case -15: case 1: c = '`'; return c;case -9: case 12: c = '\001'; return c;case -16: case -1: c = '\b'; return c;case 91: case 92: c = '\f'; return c;case 93: c = '´'; return c;case -101: c = 'µ'; return c;case -102: c = 'ç'; return c;case -103: c = '¶'; return c;case -104: c = '·'; return c;case -3: case -2: c = '\027'; return c;case -4: c = '\030'; return c;case -8: c = 'h'; return c;case 2004: c = 'q'; return c;case 2005: case 2011: c = 'p'; return c;case -13: c = 'r'; return c;case 2002: case 2003: case 2007: case 2008: case 2009: c = 'm'; return c;case 2006: c = 'o'; return c;case 70: c = '\001'; return c;
/*       */     } 
/*       */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*       */     sQLException.fillInStackTrace();
/*       */     throw sQLException;
/*       */   }
/*       */   
/*       */   void registerReturnParamsForAutoKey() throws SQLException {
/* 11095 */     int[] arrayOfInt1 = this.autoKeyInfo.returnTypes;
/* 11096 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 11097 */     int[] arrayOfInt2 = this.autoKeyInfo.columnIndexes;
/*       */     
/* 11099 */     int i = arrayOfInt1.length;
/*       */ 
/*       */     
/* 11102 */     int j = this.numberOfBindPositions - i;
/*       */ 
/*       */     
/* 11105 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 11107 */       int k = j + b;
/* 11108 */       this.currentRowBinders[k] = this.theReturnParamBinder;
/*       */       
/* 11110 */       byte b1 = this.connection.defaultnchar ? 2 : 1;
/*       */ 
/*       */       
/* 11113 */       if (arrayOfShort != null && arrayOfInt2 != null)
/*       */       {
/* 11115 */         if (arrayOfShort[arrayOfInt2[b] - 1] == 2) {
/*       */ 
/*       */           
/* 11118 */           b1 = 2;
/* 11119 */           setFormOfUse(k + 1, b1);
/*       */         } 
/*       */       }
/*       */       
/* 11123 */       checkTypeForAutoKey(arrayOfInt1[b]);
/*       */       
/* 11125 */       String str = null;
/* 11126 */       if (arrayOfInt1[b] == 111) {
/* 11127 */         str = this.autoKeyInfo.tableTypeNames[arrayOfInt2[b] - 1];
/*       */       }
/* 11129 */       registerReturnParameterInternal(k, arrayOfInt1[b], arrayOfInt1[b], -1, b1, str);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanOldTempLobs() {
/* 11139 */     if (this.m_batchStyle != 1 || this.currentRank == this.batch - 1)
/*       */     {
/* 11141 */       super.cleanOldTempLobs();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   void resetOnExceptionDuringExecute() {
/* 11148 */     super.resetOnExceptionDuringExecute();
/* 11149 */     this.currentRank = 0;
/* 11150 */     this.currentBatchNeedToPrepareBinds = true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetCurrentRowBinders() {
/* 11159 */     Binder[] arrayOfBinder = this.currentRowBinders;
/* 11160 */     if (this.binders != null && this.currentRowBinders != null && arrayOfBinder != this.binders[0]) {
/*       */ 
/*       */ 
/*       */       
/* 11164 */       this.currentRowBinders = this.binders[0];
/* 11165 */       this.binders[this.numberOfBoundRows] = arrayOfBinder;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11184 */     setAsciiStreamInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11199 */     setAsciiStreamInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11213 */     setBinaryStreamInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11228 */     setBinaryStreamInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11241 */     setBlobInternal(paramInt, paramInputStream);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11255 */     if (paramLong < 0L) {
/*       */       
/* 11257 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
/* 11258 */       sQLException.fillInStackTrace();
/* 11259 */       throw sQLException;
/*       */     } 
/* 11261 */     setBlobInternal(paramInt, paramInputStream, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 11275 */     setCharacterStreamInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11290 */     setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11304 */     if (paramLong < 0L) {
/*       */       
/* 11306 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
/* 11307 */       sQLException.fillInStackTrace();
/* 11308 */       throw sQLException;
/*       */     } 
/* 11310 */     setClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClob(int paramInt, Reader paramReader) throws SQLException {
/* 11324 */     setClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRowId(int paramInt, RowId paramRowId) throws SQLException {
/* 11339 */     setRowIdInternal(paramInt, paramRowId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 11355 */     setNCharacterStreamInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11371 */     setNCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, NClob paramNClob) throws SQLException {
/* 11386 */     setNClobInternal(paramInt, paramNClob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11402 */     setNClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClob(int paramInt, Reader paramReader) throws SQLException {
/* 11417 */     setNClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/* 11424 */     setSQLXMLInternal(paramInt, paramSQLXML);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNString(int paramInt, String paramString) throws SQLException {
/* 11439 */     setNStringInternal(paramInt, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11447 */     setAsciiStreamInternal(paramInt, paramInputStream, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11455 */     setAsciiStreamInternal(paramInt, paramInputStream, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11463 */     setBinaryStreamInternal(paramInt, paramInputStream, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11471 */     setBinaryStreamInternal(paramInt, paramInputStream, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBlobInternal(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 11480 */     int i = paramInt - 1;
/*       */     
/* 11482 */     if (i < 0 || paramInt > this.numberOfBindPositions) {
/*       */       
/* 11484 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11485 */       sQLException.fillInStackTrace();
/* 11486 */       throw sQLException;
/*       */     } 
/*       */     
/* 11489 */     if (paramInputStream == null) {
/* 11490 */       setNullInternal(paramInt, 2004);
/*       */     } else {
/* 11492 */       setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, !(paramLong == -1L));
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setBlobInternal(int paramInt, InputStream paramInputStream) throws SQLException {
/* 11501 */     setBlobInternal(paramInt, paramInputStream, -1L);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader) throws SQLException {
/* 11509 */     setCharacterStreamInternal(paramInt, paramReader, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11517 */     setCharacterStreamInternal(paramInt, paramReader, paramLong, true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setClobInternal(int paramInt, Reader paramReader) throws SQLException {
/* 11525 */     setClobInternal(paramInt, paramReader, -1L);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setClobInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11533 */     int i = paramInt - 1;
/*       */     
/* 11535 */     if (i < 0 || paramInt > this.numberOfBindPositions) {
/*       */       
/* 11537 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 11538 */       sQLException.fillInStackTrace();
/* 11539 */       throw sQLException;
/*       */     } 
/*       */     
/* 11542 */     if (paramReader == null) {
/* 11543 */       setNullInternal(paramInt, 2005);
/*       */     } else {
/* 11545 */       setReaderContentsForClobCritical(paramInt, paramReader, paramLong, !(paramLong == -1L));
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNCharacterStreamInternal(int paramInt, Reader paramReader) throws SQLException {
/* 11553 */     setFormOfUse(paramInt, (short)2);
/* 11554 */     setCharacterStreamInternal(paramInt, paramReader, 0L, false);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11562 */     setFormOfUse(paramInt, (short)2);
/* 11563 */     setCharacterStreamInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, NClob paramNClob) throws SQLException {
/* 11571 */     setFormOfUse(paramInt, (short)2);
/* 11572 */     setClobInternal(paramInt, paramNClob);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, Reader paramReader) throws SQLException {
/* 11580 */     setFormOfUse(paramInt, (short)2);
/* 11581 */     setClobInternal(paramInt, paramReader);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNClobInternal(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 11589 */     setFormOfUse(paramInt, (short)2);
/* 11590 */     setClobInternal(paramInt, paramReader, paramLong);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setNStringInternal(int paramInt, String paramString) throws SQLException {
/* 11598 */     setFormOfUse(paramInt, (short)2);
/* 11599 */     setStringInternal(paramInt, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setRowIdInternal(int paramInt, RowId paramRowId) throws SQLException {
/* 11607 */     setROWIDInternal(paramInt, (ROWID)paramRowId);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setArrayAtName(String paramString, Array paramArray) throws SQLException {
/* 11634 */     String str = paramString.intern();
/* 11635 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11636 */     boolean bool = false;
/* 11637 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11639 */     for (byte b = 0; b < i; b++) {
/* 11640 */       if (arrayOfString[b] == str) {
/*       */         
/* 11642 */         setArray(b + 1, paramArray);
/*       */         
/* 11644 */         bool = true;
/*       */       } 
/*       */     } 
/* 11647 */     if (!bool) {
/*       */       
/* 11649 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11650 */       sQLException.fillInStackTrace();
/* 11651 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/* 11671 */     String str = paramString.intern();
/* 11672 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11673 */     boolean bool = false;
/* 11674 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11676 */     for (byte b = 0; b < i; b++) {
/* 11677 */       if (arrayOfString[b] == str) {
/*       */         
/* 11679 */         setBigDecimal(b + 1, paramBigDecimal);
/*       */         
/* 11681 */         bool = true;
/*       */       } 
/*       */     } 
/* 11684 */     if (!bool) {
/*       */       
/* 11686 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11687 */       sQLException.fillInStackTrace();
/* 11688 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, Blob paramBlob) throws SQLException {
/* 11708 */     String str = paramString.intern();
/* 11709 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11710 */     boolean bool = false;
/* 11711 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11713 */     for (byte b = 0; b < i; b++) {
/* 11714 */       if (arrayOfString[b] == str) {
/*       */         
/* 11716 */         setBlob(b + 1, paramBlob);
/*       */         
/* 11718 */         bool = true;
/*       */       } 
/*       */     } 
/* 11721 */     if (!bool) {
/*       */       
/* 11723 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11724 */       sQLException.fillInStackTrace();
/* 11725 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBooleanAtName(String paramString, boolean paramBoolean) throws SQLException {
/* 11745 */     String str = paramString.intern();
/* 11746 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11747 */     boolean bool = false;
/* 11748 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11750 */     for (byte b = 0; b < i; b++) {
/* 11751 */       if (arrayOfString[b] == str) {
/*       */         
/* 11753 */         setBoolean(b + 1, paramBoolean);
/*       */         
/* 11755 */         bool = true;
/*       */       } 
/*       */     } 
/* 11758 */     if (!bool) {
/*       */       
/* 11760 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11761 */       sQLException.fillInStackTrace();
/* 11762 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setByteAtName(String paramString, byte paramByte) throws SQLException {
/* 11782 */     String str = paramString.intern();
/* 11783 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11784 */     boolean bool = false;
/* 11785 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11787 */     for (byte b = 0; b < i; b++) {
/* 11788 */       if (arrayOfString[b] == str) {
/*       */         
/* 11790 */         setByte(b + 1, paramByte);
/*       */         
/* 11792 */         bool = true;
/*       */       } 
/*       */     } 
/* 11795 */     if (!bool) {
/*       */       
/* 11797 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11798 */       sQLException.fillInStackTrace();
/* 11799 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBytesAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 11819 */     String str = paramString.intern();
/* 11820 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11821 */     boolean bool = false;
/* 11822 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11824 */     for (byte b = 0; b < i; b++) {
/* 11825 */       if (arrayOfString[b] == str) {
/*       */         
/* 11827 */         setBytes(b + 1, paramArrayOfbyte);
/*       */         
/* 11829 */         bool = true;
/*       */       } 
/*       */     } 
/* 11832 */     if (!bool) {
/*       */       
/* 11834 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11835 */       sQLException.fillInStackTrace();
/* 11836 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Clob paramClob) throws SQLException {
/* 11856 */     String str = paramString.intern();
/* 11857 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11858 */     boolean bool = false;
/* 11859 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11861 */     for (byte b = 0; b < i; b++) {
/* 11862 */       if (arrayOfString[b] == str) {
/*       */         
/* 11864 */         setClob(b + 1, paramClob);
/*       */         
/* 11866 */         bool = true;
/*       */       } 
/*       */     } 
/* 11869 */     if (!bool) {
/*       */       
/* 11871 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11872 */       sQLException.fillInStackTrace();
/* 11873 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDateAtName(String paramString, Date paramDate) throws SQLException {
/* 11893 */     String str = paramString.intern();
/* 11894 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11895 */     boolean bool = false;
/* 11896 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11898 */     for (byte b = 0; b < i; b++) {
/* 11899 */       if (arrayOfString[b] == str) {
/*       */         
/* 11901 */         setDate(b + 1, paramDate);
/*       */         
/* 11903 */         bool = true;
/*       */       } 
/*       */     } 
/* 11906 */     if (!bool) {
/*       */       
/* 11908 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11909 */       sQLException.fillInStackTrace();
/* 11910 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 11930 */     String str = paramString.intern();
/* 11931 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11932 */     boolean bool = false;
/* 11933 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11935 */     for (byte b = 0; b < i; b++) {
/* 11936 */       if (arrayOfString[b] == str) {
/*       */         
/* 11938 */         setDate(b + 1, paramDate, paramCalendar);
/*       */         
/* 11940 */         bool = true;
/*       */       } 
/*       */     } 
/* 11943 */     if (!bool) {
/*       */       
/* 11945 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11946 */       sQLException.fillInStackTrace();
/* 11947 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 11967 */     String str = paramString.intern();
/* 11968 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11969 */     boolean bool = false;
/* 11970 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11972 */     for (byte b = 0; b < i; b++) {
/* 11973 */       if (arrayOfString[b] == str) {
/*       */         
/* 11975 */         setDouble(b + 1, paramDouble);
/*       */         
/* 11977 */         bool = true;
/*       */       } 
/*       */     } 
/* 11980 */     if (!bool) {
/*       */       
/* 11982 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11983 */       sQLException.fillInStackTrace();
/* 11984 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 12004 */     String str = paramString.intern();
/* 12005 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12006 */     boolean bool = false;
/* 12007 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12009 */     for (byte b = 0; b < i; b++) {
/* 12010 */       if (arrayOfString[b] == str) {
/*       */         
/* 12012 */         setFloat(b + 1, paramFloat);
/*       */         
/* 12014 */         bool = true;
/*       */       } 
/*       */     } 
/* 12017 */     if (!bool) {
/*       */       
/* 12019 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12020 */       sQLException.fillInStackTrace();
/* 12021 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setIntAtName(String paramString, int paramInt) throws SQLException {
/* 12041 */     String str = paramString.intern();
/* 12042 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12043 */     boolean bool = false;
/* 12044 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12046 */     for (byte b = 0; b < i; b++) {
/* 12047 */       if (arrayOfString[b] == str) {
/*       */         
/* 12049 */         setInt(b + 1, paramInt);
/*       */         
/* 12051 */         bool = true;
/*       */       } 
/*       */     } 
/* 12054 */     if (!bool) {
/*       */       
/* 12056 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12057 */       sQLException.fillInStackTrace();
/* 12058 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setLongAtName(String paramString, long paramLong) throws SQLException {
/* 12078 */     String str = paramString.intern();
/* 12079 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12080 */     boolean bool = false;
/* 12081 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12083 */     for (byte b = 0; b < i; b++) {
/* 12084 */       if (arrayOfString[b] == str) {
/*       */         
/* 12086 */         setLong(b + 1, paramLong);
/*       */         
/* 12088 */         bool = true;
/*       */       } 
/*       */     } 
/* 12091 */     if (!bool) {
/*       */       
/* 12093 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12094 */       sQLException.fillInStackTrace();
/* 12095 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, NClob paramNClob) throws SQLException {
/* 12115 */     String str = paramString.intern();
/* 12116 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12117 */     boolean bool = false;
/* 12118 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12120 */     for (byte b = 0; b < i; b++) {
/* 12121 */       if (arrayOfString[b] == str) {
/*       */         
/* 12123 */         setNClob(b + 1, paramNClob);
/*       */         
/* 12125 */         bool = true;
/*       */       } 
/*       */     } 
/* 12128 */     if (!bool) {
/*       */       
/* 12130 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12131 */       sQLException.fillInStackTrace();
/* 12132 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNStringAtName(String paramString1, String paramString2) throws SQLException {
/* 12152 */     String str = paramString1.intern();
/* 12153 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12154 */     boolean bool = false;
/* 12155 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12157 */     for (byte b = 0; b < i; b++) {
/* 12158 */       if (arrayOfString[b] == str) {
/*       */         
/* 12160 */         setNString(b + 1, paramString2);
/*       */         
/* 12162 */         bool = true;
/*       */       } 
/*       */     } 
/* 12165 */     if (!bool) {
/*       */       
/* 12167 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 12168 */       sQLException.fillInStackTrace();
/* 12169 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObjectAtName(String paramString, Object paramObject) throws SQLException {
/* 12189 */     String str = paramString.intern();
/* 12190 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12191 */     boolean bool = false;
/* 12192 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12194 */     for (byte b = 0; b < i; b++) {
/* 12195 */       if (arrayOfString[b] == str) {
/*       */         
/* 12197 */         setObject(b + 1, paramObject);
/*       */         
/* 12199 */         bool = true;
/*       */       } 
/*       */     } 
/* 12202 */     if (!bool) {
/*       */       
/* 12204 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12205 */       sQLException.fillInStackTrace();
/* 12206 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt) throws SQLException {
/* 12226 */     String str = paramString.intern();
/* 12227 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12228 */     boolean bool = false;
/* 12229 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12231 */     for (byte b = 0; b < i; b++) {
/* 12232 */       if (arrayOfString[b] == str) {
/*       */         
/* 12234 */         setObject(b + 1, paramObject, paramInt);
/*       */         
/* 12236 */         bool = true;
/*       */       } 
/*       */     } 
/* 12239 */     if (!bool) {
/*       */       
/* 12241 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12242 */       sQLException.fillInStackTrace();
/* 12243 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefAtName(String paramString, Ref paramRef) throws SQLException {
/* 12263 */     String str = paramString.intern();
/* 12264 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12265 */     boolean bool = false;
/* 12266 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12268 */     for (byte b = 0; b < i; b++) {
/* 12269 */       if (arrayOfString[b] == str) {
/*       */         
/* 12271 */         setRef(b + 1, paramRef);
/*       */         
/* 12273 */         bool = true;
/*       */       } 
/*       */     } 
/* 12276 */     if (!bool) {
/*       */       
/* 12278 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12279 */       sQLException.fillInStackTrace();
/* 12280 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRowIdAtName(String paramString, RowId paramRowId) throws SQLException {
/* 12300 */     String str = paramString.intern();
/* 12301 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12302 */     boolean bool = false;
/* 12303 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12305 */     for (byte b = 0; b < i; b++) {
/* 12306 */       if (arrayOfString[b] == str) {
/*       */         
/* 12308 */         setRowId(b + 1, paramRowId);
/*       */         
/* 12310 */         bool = true;
/*       */       } 
/*       */     } 
/* 12313 */     if (!bool) {
/*       */       
/* 12315 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12316 */       sQLException.fillInStackTrace();
/* 12317 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setShortAtName(String paramString, short paramShort) throws SQLException {
/* 12337 */     String str = paramString.intern();
/* 12338 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12339 */     boolean bool = false;
/* 12340 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12342 */     for (byte b = 0; b < i; b++) {
/* 12343 */       if (arrayOfString[b] == str) {
/*       */         
/* 12345 */         setShort(b + 1, paramShort);
/*       */         
/* 12347 */         bool = true;
/*       */       } 
/*       */     } 
/* 12350 */     if (!bool) {
/*       */       
/* 12352 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12353 */       sQLException.fillInStackTrace();
/* 12354 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSQLXMLAtName(String paramString, SQLXML paramSQLXML) throws SQLException {
/* 12374 */     String str = paramString.intern();
/* 12375 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12376 */     boolean bool = false;
/* 12377 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12379 */     for (byte b = 0; b < i; b++) {
/* 12380 */       if (arrayOfString[b] == str) {
/*       */         
/* 12382 */         setSQLXML(b + 1, paramSQLXML);
/*       */         
/* 12384 */         bool = true;
/*       */       } 
/*       */     } 
/* 12387 */     if (!bool) {
/*       */       
/* 12389 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12390 */       sQLException.fillInStackTrace();
/* 12391 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setStringAtName(String paramString1, String paramString2) throws SQLException {
/* 12411 */     String str = paramString1.intern();
/* 12412 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12413 */     boolean bool = false;
/* 12414 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12416 */     for (byte b = 0; b < i; b++) {
/* 12417 */       if (arrayOfString[b] == str) {
/*       */         
/* 12419 */         setString(b + 1, paramString2);
/*       */         
/* 12421 */         bool = true;
/*       */       } 
/*       */     } 
/* 12424 */     if (!bool) {
/*       */       
/* 12426 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 12427 */       sQLException.fillInStackTrace();
/* 12428 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimeAtName(String paramString, Time paramTime) throws SQLException {
/* 12448 */     String str = paramString.intern();
/* 12449 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12450 */     boolean bool = false;
/* 12451 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12453 */     for (byte b = 0; b < i; b++) {
/* 12454 */       if (arrayOfString[b] == str) {
/*       */         
/* 12456 */         setTime(b + 1, paramTime);
/*       */         
/* 12458 */         bool = true;
/*       */       } 
/*       */     } 
/* 12461 */     if (!bool) {
/*       */       
/* 12463 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12464 */       sQLException.fillInStackTrace();
/* 12465 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 12485 */     String str = paramString.intern();
/* 12486 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12487 */     boolean bool = false;
/* 12488 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12490 */     for (byte b = 0; b < i; b++) {
/* 12491 */       if (arrayOfString[b] == str) {
/*       */         
/* 12493 */         setTime(b + 1, paramTime, paramCalendar);
/*       */         
/* 12495 */         bool = true;
/*       */       } 
/*       */     } 
/* 12498 */     if (!bool) {
/*       */       
/* 12500 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12501 */       sQLException.fillInStackTrace();
/* 12502 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp) throws SQLException {
/* 12522 */     String str = paramString.intern();
/* 12523 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12524 */     boolean bool = false;
/* 12525 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12527 */     for (byte b = 0; b < i; b++) {
/* 12528 */       if (arrayOfString[b] == str) {
/*       */         
/* 12530 */         setTimestamp(b + 1, paramTimestamp);
/*       */         
/* 12532 */         bool = true;
/*       */       } 
/*       */     } 
/* 12535 */     if (!bool) {
/*       */       
/* 12537 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12538 */       sQLException.fillInStackTrace();
/* 12539 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 12559 */     String str = paramString.intern();
/* 12560 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12561 */     boolean bool = false;
/* 12562 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12564 */     for (byte b = 0; b < i; b++) {
/* 12565 */       if (arrayOfString[b] == str) {
/*       */         
/* 12567 */         setTimestamp(b + 1, paramTimestamp, paramCalendar);
/*       */         
/* 12569 */         bool = true;
/*       */       } 
/*       */     } 
/* 12572 */     if (!bool) {
/*       */       
/* 12574 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12575 */       sQLException.fillInStackTrace();
/* 12576 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURLAtName(String paramString, URL paramURL) throws SQLException {
/* 12596 */     String str = paramString.intern();
/* 12597 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12598 */     boolean bool = false;
/* 12599 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12601 */     for (byte b = 0; b < i; b++) {
/* 12602 */       if (arrayOfString[b] == str) {
/*       */         
/* 12604 */         setURL(b + 1, paramURL);
/*       */         
/* 12606 */         bool = true;
/*       */       } 
/*       */     } 
/* 12609 */     if (!bool) {
/*       */       
/* 12611 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12612 */       sQLException.fillInStackTrace();
/* 12613 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setARRAYAtName(String paramString, ARRAY paramARRAY) throws SQLException {
/* 12633 */     String str = paramString.intern();
/* 12634 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12635 */     boolean bool = false;
/* 12636 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12638 */     for (byte b = 0; b < i; b++) {
/* 12639 */       if (arrayOfString[b] == str) {
/*       */         
/* 12641 */         setARRAY(b + 1, paramARRAY);
/*       */         
/* 12643 */         bool = true;
/*       */       } 
/*       */     } 
/* 12646 */     if (!bool) {
/*       */       
/* 12648 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12649 */       sQLException.fillInStackTrace();
/* 12650 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBFILEAtName(String paramString, BFILE paramBFILE) throws SQLException {
/* 12670 */     String str = paramString.intern();
/* 12671 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12672 */     boolean bool = false;
/* 12673 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12675 */     for (byte b = 0; b < i; b++) {
/* 12676 */       if (arrayOfString[b] == str) {
/*       */         
/* 12678 */         setBFILE(b + 1, paramBFILE);
/*       */         
/* 12680 */         bool = true;
/*       */       } 
/*       */     } 
/* 12683 */     if (!bool) {
/*       */       
/* 12685 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12686 */       sQLException.fillInStackTrace();
/* 12687 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBfileAtName(String paramString, BFILE paramBFILE) throws SQLException {
/* 12707 */     String str = paramString.intern();
/* 12708 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12709 */     boolean bool = false;
/* 12710 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12712 */     for (byte b = 0; b < i; b++) {
/* 12713 */       if (arrayOfString[b] == str) {
/*       */         
/* 12715 */         setBfile(b + 1, paramBFILE);
/*       */         
/* 12717 */         bool = true;
/*       */       } 
/*       */     } 
/* 12720 */     if (!bool) {
/*       */       
/* 12722 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12723 */       sQLException.fillInStackTrace();
/* 12724 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 12744 */     String str = paramString.intern();
/* 12745 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12746 */     boolean bool = false;
/* 12747 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12749 */     for (byte b = 0; b < i; b++) {
/* 12750 */       if (arrayOfString[b] == str) {
/*       */         
/* 12752 */         setBinaryFloat(b + 1, paramFloat);
/*       */         
/* 12754 */         bool = true;
/*       */       } 
/*       */     } 
/* 12757 */     if (!bool) {
/*       */       
/* 12759 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12760 */       sQLException.fillInStackTrace();
/* 12761 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 12781 */     String str = paramString.intern();
/* 12782 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12783 */     boolean bool = false;
/* 12784 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12786 */     for (byte b = 0; b < i; b++) {
/* 12787 */       if (arrayOfString[b] == str) {
/*       */         
/* 12789 */         setBinaryFloat(b + 1, paramBINARY_FLOAT);
/*       */         
/* 12791 */         bool = true;
/*       */       } 
/*       */     } 
/* 12794 */     if (!bool) {
/*       */       
/* 12796 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12797 */       sQLException.fillInStackTrace();
/* 12798 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 12818 */     String str = paramString.intern();
/* 12819 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12820 */     boolean bool = false;
/* 12821 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12823 */     for (byte b = 0; b < i; b++) {
/* 12824 */       if (arrayOfString[b] == str) {
/*       */         
/* 12826 */         setBinaryDouble(b + 1, paramDouble);
/*       */         
/* 12828 */         bool = true;
/*       */       } 
/*       */     } 
/* 12831 */     if (!bool) {
/*       */       
/* 12833 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12834 */       sQLException.fillInStackTrace();
/* 12835 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 12855 */     String str = paramString.intern();
/* 12856 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12857 */     boolean bool = false;
/* 12858 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12860 */     for (byte b = 0; b < i; b++) {
/* 12861 */       if (arrayOfString[b] == str) {
/*       */         
/* 12863 */         setBinaryDouble(b + 1, paramBINARY_DOUBLE);
/*       */         
/* 12865 */         bool = true;
/*       */       } 
/*       */     } 
/* 12868 */     if (!bool) {
/*       */       
/* 12870 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12871 */       sQLException.fillInStackTrace();
/* 12872 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBLOBAtName(String paramString, BLOB paramBLOB) throws SQLException {
/* 12892 */     String str = paramString.intern();
/* 12893 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12894 */     boolean bool = false;
/* 12895 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12897 */     for (byte b = 0; b < i; b++) {
/* 12898 */       if (arrayOfString[b] == str) {
/*       */         
/* 12900 */         setBLOB(b + 1, paramBLOB);
/*       */         
/* 12902 */         bool = true;
/*       */       } 
/*       */     } 
/* 12905 */     if (!bool) {
/*       */       
/* 12907 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12908 */       sQLException.fillInStackTrace();
/* 12909 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCHARAtName(String paramString, CHAR paramCHAR) throws SQLException {
/* 12929 */     String str = paramString.intern();
/* 12930 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12931 */     boolean bool = false;
/* 12932 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12934 */     for (byte b = 0; b < i; b++) {
/* 12935 */       if (arrayOfString[b] == str) {
/*       */         
/* 12937 */         setCHAR(b + 1, paramCHAR);
/*       */         
/* 12939 */         bool = true;
/*       */       } 
/*       */     } 
/* 12942 */     if (!bool) {
/*       */       
/* 12944 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12945 */       sQLException.fillInStackTrace();
/* 12946 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCLOBAtName(String paramString, CLOB paramCLOB) throws SQLException {
/* 12966 */     String str = paramString.intern();
/* 12967 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12968 */     boolean bool = false;
/* 12969 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12971 */     for (byte b = 0; b < i; b++) {
/* 12972 */       if (arrayOfString[b] == str) {
/*       */         
/* 12974 */         setCLOB(b + 1, paramCLOB);
/*       */         
/* 12976 */         bool = true;
/*       */       } 
/*       */     } 
/* 12979 */     if (!bool) {
/*       */       
/* 12981 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12982 */       sQLException.fillInStackTrace();
/* 12983 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCursorAtName(String paramString, ResultSet paramResultSet) throws SQLException {
/* 13003 */     String str = paramString.intern();
/* 13004 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13005 */     boolean bool = false;
/* 13006 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13008 */     for (byte b = 0; b < i; b++) {
/* 13009 */       if (arrayOfString[b] == str) {
/*       */         
/* 13011 */         setCursor(b + 1, paramResultSet);
/*       */         
/* 13013 */         bool = true;
/*       */       } 
/*       */     } 
/* 13016 */     if (!bool) {
/*       */       
/* 13018 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13019 */       sQLException.fillInStackTrace();
/* 13020 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 13040 */     String str = paramString.intern();
/* 13041 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13042 */     boolean bool = false;
/* 13043 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13045 */     for (byte b = 0; b < i; b++) {
/* 13046 */       if (arrayOfString[b] == str) {
/*       */         
/* 13048 */         setCustomDatum(b + 1, paramCustomDatum);
/*       */         
/* 13050 */         bool = true;
/*       */       } 
/*       */     } 
/* 13053 */     if (!bool) {
/*       */       
/* 13055 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13056 */       sQLException.fillInStackTrace();
/* 13057 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDATEAtName(String paramString, DATE paramDATE) throws SQLException {
/* 13077 */     String str = paramString.intern();
/* 13078 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13079 */     boolean bool = false;
/* 13080 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13082 */     for (byte b = 0; b < i; b++) {
/* 13083 */       if (arrayOfString[b] == str) {
/*       */         
/* 13085 */         setDATE(b + 1, paramDATE);
/*       */         
/* 13087 */         bool = true;
/*       */       } 
/*       */     } 
/* 13090 */     if (!bool) {
/*       */       
/* 13092 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13093 */       sQLException.fillInStackTrace();
/* 13094 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFixedCHARAtName(String paramString1, String paramString2) throws SQLException {
/* 13114 */     String str = paramString1.intern();
/* 13115 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13116 */     boolean bool = false;
/* 13117 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13119 */     for (byte b = 0; b < i; b++) {
/* 13120 */       if (arrayOfString[b] == str) {
/*       */         
/* 13122 */         setFixedCHAR(b + 1, paramString2);
/*       */         
/* 13124 */         bool = true;
/*       */       } 
/*       */     } 
/* 13127 */     if (!bool) {
/*       */       
/* 13129 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 13130 */       sQLException.fillInStackTrace();
/* 13131 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 13151 */     String str = paramString.intern();
/* 13152 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13153 */     boolean bool = false;
/* 13154 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13156 */     for (byte b = 0; b < i; b++) {
/* 13157 */       if (arrayOfString[b] == str) {
/*       */         
/* 13159 */         setINTERVALDS(b + 1, paramINTERVALDS);
/*       */         
/* 13161 */         bool = true;
/*       */       } 
/*       */     } 
/* 13164 */     if (!bool) {
/*       */       
/* 13166 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13167 */       sQLException.fillInStackTrace();
/* 13168 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 13188 */     String str = paramString.intern();
/* 13189 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13190 */     boolean bool = false;
/* 13191 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13193 */     for (byte b = 0; b < i; b++) {
/* 13194 */       if (arrayOfString[b] == str) {
/*       */         
/* 13196 */         setINTERVALYM(b + 1, paramINTERVALYM);
/*       */         
/* 13198 */         bool = true;
/*       */       } 
/*       */     } 
/* 13201 */     if (!bool) {
/*       */       
/* 13203 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13204 */       sQLException.fillInStackTrace();
/* 13205 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 13225 */     String str = paramString.intern();
/* 13226 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13227 */     boolean bool = false;
/* 13228 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13230 */     for (byte b = 0; b < i; b++) {
/* 13231 */       if (arrayOfString[b] == str) {
/*       */         
/* 13233 */         setNUMBER(b + 1, paramNUMBER);
/*       */         
/* 13235 */         bool = true;
/*       */       } 
/*       */     } 
/* 13238 */     if (!bool) {
/*       */       
/* 13240 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13241 */       sQLException.fillInStackTrace();
/* 13242 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 13262 */     String str = paramString.intern();
/* 13263 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13264 */     boolean bool = false;
/* 13265 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13267 */     for (byte b = 0; b < i; b++) {
/* 13268 */       if (arrayOfString[b] == str) {
/*       */         
/* 13270 */         setOPAQUE(b + 1, paramOPAQUE);
/*       */         
/* 13272 */         bool = true;
/*       */       } 
/*       */     } 
/* 13275 */     if (!bool) {
/*       */       
/* 13277 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13278 */       sQLException.fillInStackTrace();
/* 13279 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOracleObjectAtName(String paramString, Datum paramDatum) throws SQLException {
/* 13299 */     String str = paramString.intern();
/* 13300 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13301 */     boolean bool = false;
/* 13302 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13304 */     for (byte b = 0; b < i; b++) {
/* 13305 */       if (arrayOfString[b] == str) {
/*       */         
/* 13307 */         setOracleObject(b + 1, paramDatum);
/*       */         
/* 13309 */         bool = true;
/*       */       } 
/*       */     } 
/* 13312 */     if (!bool) {
/*       */       
/* 13314 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13315 */       sQLException.fillInStackTrace();
/* 13316 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setORADataAtName(String paramString, ORAData paramORAData) throws SQLException {
/* 13336 */     String str = paramString.intern();
/* 13337 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13338 */     boolean bool = false;
/* 13339 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13341 */     for (byte b = 0; b < i; b++) {
/* 13342 */       if (arrayOfString[b] == str) {
/*       */         
/* 13344 */         setORAData(b + 1, paramORAData);
/*       */         
/* 13346 */         bool = true;
/*       */       } 
/*       */     } 
/* 13349 */     if (!bool) {
/*       */       
/* 13351 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13352 */       sQLException.fillInStackTrace();
/* 13353 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRAWAtName(String paramString, RAW paramRAW) throws SQLException {
/* 13373 */     String str = paramString.intern();
/* 13374 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13375 */     boolean bool = false;
/* 13376 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13378 */     for (byte b = 0; b < i; b++) {
/* 13379 */       if (arrayOfString[b] == str) {
/*       */         
/* 13381 */         setRAW(b + 1, paramRAW);
/*       */         
/* 13383 */         bool = true;
/*       */       } 
/*       */     } 
/* 13386 */     if (!bool) {
/*       */       
/* 13388 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13389 */       sQLException.fillInStackTrace();
/* 13390 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setREFAtName(String paramString, REF paramREF) throws SQLException {
/* 13410 */     String str = paramString.intern();
/* 13411 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13412 */     boolean bool = false;
/* 13413 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13415 */     for (byte b = 0; b < i; b++) {
/* 13416 */       if (arrayOfString[b] == str) {
/*       */         
/* 13418 */         setREF(b + 1, paramREF);
/*       */         
/* 13420 */         bool = true;
/*       */       } 
/*       */     } 
/* 13423 */     if (!bool) {
/*       */       
/* 13425 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13426 */       sQLException.fillInStackTrace();
/* 13427 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefTypeAtName(String paramString, REF paramREF) throws SQLException {
/* 13447 */     String str = paramString.intern();
/* 13448 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13449 */     boolean bool = false;
/* 13450 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13452 */     for (byte b = 0; b < i; b++) {
/* 13453 */       if (arrayOfString[b] == str) {
/*       */         
/* 13455 */         setRefType(b + 1, paramREF);
/*       */         
/* 13457 */         bool = true;
/*       */       } 
/*       */     } 
/* 13460 */     if (!bool) {
/*       */       
/* 13462 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13463 */       sQLException.fillInStackTrace();
/* 13464 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setROWIDAtName(String paramString, ROWID paramROWID) throws SQLException {
/* 13484 */     String str = paramString.intern();
/* 13485 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13486 */     boolean bool = false;
/* 13487 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13489 */     for (byte b = 0; b < i; b++) {
/* 13490 */       if (arrayOfString[b] == str) {
/*       */         
/* 13492 */         setROWID(b + 1, paramROWID);
/*       */         
/* 13494 */         bool = true;
/*       */       } 
/*       */     } 
/* 13497 */     if (!bool) {
/*       */       
/* 13499 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13500 */       sQLException.fillInStackTrace();
/* 13501 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 13521 */     String str = paramString.intern();
/* 13522 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13523 */     boolean bool = false;
/* 13524 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13526 */     for (byte b = 0; b < i; b++) {
/* 13527 */       if (arrayOfString[b] == str) {
/*       */         
/* 13529 */         setSTRUCT(b + 1, paramSTRUCT);
/*       */         
/* 13531 */         bool = true;
/*       */       } 
/*       */     } 
/* 13534 */     if (!bool) {
/*       */       
/* 13536 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13537 */       sQLException.fillInStackTrace();
/* 13538 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 13558 */     String str = paramString.intern();
/* 13559 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13560 */     boolean bool = false;
/* 13561 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13563 */     for (byte b = 0; b < i; b++) {
/* 13564 */       if (arrayOfString[b] == str) {
/*       */         
/* 13566 */         setTIMESTAMPLTZ(b + 1, paramTIMESTAMPLTZ);
/*       */         
/* 13568 */         bool = true;
/*       */       } 
/*       */     } 
/* 13571 */     if (!bool) {
/*       */       
/* 13573 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13574 */       sQLException.fillInStackTrace();
/* 13575 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 13595 */     String str = paramString.intern();
/* 13596 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13597 */     boolean bool = false;
/* 13598 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13600 */     for (byte b = 0; b < i; b++) {
/* 13601 */       if (arrayOfString[b] == str) {
/*       */         
/* 13603 */         setTIMESTAMPTZ(b + 1, paramTIMESTAMPTZ);
/*       */         
/* 13605 */         bool = true;
/*       */       } 
/*       */     } 
/* 13608 */     if (!bool) {
/*       */       
/* 13610 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13611 */       sQLException.fillInStackTrace();
/* 13612 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 13632 */     String str = paramString.intern();
/* 13633 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13634 */     boolean bool = false;
/* 13635 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13637 */     for (byte b = 0; b < i; b++) {
/* 13638 */       if (arrayOfString[b] == str) {
/*       */         
/* 13640 */         setTIMESTAMP(b + 1, paramTIMESTAMP);
/*       */         
/* 13642 */         bool = true;
/*       */       } 
/*       */     } 
/* 13645 */     if (!bool) {
/*       */       
/* 13647 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13648 */       sQLException.fillInStackTrace();
/* 13649 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 13671 */     String str = paramString.intern();
/* 13672 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13673 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13674 */     boolean bool = true;
/*       */     
/* 13676 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13678 */       if (arrayOfString[b] == str)
/*       */       {
/* 13680 */         if (bool) {
/*       */           
/* 13682 */           setBlob(b + 1, paramInputStream);
/*       */           
/* 13684 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13689 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13690 */           sQLException.fillInStackTrace();
/* 13691 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13696 */     if (bool) {
/*       */       
/* 13698 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13699 */       sQLException.fillInStackTrace();
/* 13700 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 13720 */     String str = paramString.intern();
/* 13721 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13722 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13723 */     boolean bool = true;
/*       */     
/* 13725 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13727 */       if (arrayOfString[b] == str)
/*       */       {
/* 13729 */         if (bool) {
/*       */           
/* 13731 */           setBlob(b + 1, paramInputStream, paramLong);
/*       */           
/* 13733 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13738 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13739 */           sQLException.fillInStackTrace();
/* 13740 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13745 */     if (bool) {
/*       */       
/* 13747 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13748 */       sQLException.fillInStackTrace();
/* 13749 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Reader paramReader) throws SQLException {
/* 13769 */     String str = paramString.intern();
/* 13770 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13771 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13772 */     boolean bool = true;
/*       */     
/* 13774 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13776 */       if (arrayOfString[b] == str)
/*       */       {
/* 13778 */         if (bool) {
/*       */           
/* 13780 */           setClob(b + 1, paramReader);
/*       */           
/* 13782 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13787 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13788 */           sQLException.fillInStackTrace();
/* 13789 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13794 */     if (bool) {
/*       */       
/* 13796 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13797 */       sQLException.fillInStackTrace();
/* 13798 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 13818 */     String str = paramString.intern();
/* 13819 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13820 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13821 */     boolean bool = true;
/*       */     
/* 13823 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13825 */       if (arrayOfString[b] == str)
/*       */       {
/* 13827 */         if (bool) {
/*       */           
/* 13829 */           setClob(b + 1, paramReader, paramLong);
/*       */           
/* 13831 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13836 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13837 */           sQLException.fillInStackTrace();
/* 13838 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13843 */     if (bool) {
/*       */       
/* 13845 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13846 */       sQLException.fillInStackTrace();
/* 13847 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, Reader paramReader) throws SQLException {
/* 13867 */     String str = paramString.intern();
/* 13868 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13869 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13870 */     boolean bool = true;
/*       */     
/* 13872 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13874 */       if (arrayOfString[b] == str)
/*       */       {
/* 13876 */         if (bool) {
/*       */           
/* 13878 */           setNClob(b + 1, paramReader);
/*       */           
/* 13880 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13885 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13886 */           sQLException.fillInStackTrace();
/* 13887 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13892 */     if (bool) {
/*       */       
/* 13894 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13895 */       sQLException.fillInStackTrace();
/* 13896 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNClobAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 13916 */     String str = paramString.intern();
/* 13917 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13918 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13919 */     boolean bool = true;
/*       */     
/* 13921 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13923 */       if (arrayOfString[b] == str)
/*       */       {
/* 13925 */         if (bool) {
/*       */           
/* 13927 */           setNClob(b + 1, paramReader, paramLong);
/*       */           
/* 13929 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13934 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13935 */           sQLException.fillInStackTrace();
/* 13936 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13941 */     if (bool) {
/*       */       
/* 13943 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13944 */       sQLException.fillInStackTrace();
/* 13945 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 13965 */     String str = paramString.intern();
/* 13966 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13967 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13968 */     boolean bool = true;
/*       */     
/* 13970 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13972 */       if (arrayOfString[b] == str)
/*       */       {
/* 13974 */         if (bool) {
/*       */           
/* 13976 */           setAsciiStream(b + 1, paramInputStream);
/*       */           
/* 13978 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13983 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13984 */           sQLException.fillInStackTrace();
/* 13985 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13990 */     if (bool) {
/*       */       
/* 13992 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13993 */       sQLException.fillInStackTrace();
/* 13994 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 14014 */     String str = paramString.intern();
/* 14015 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14016 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14017 */     boolean bool = true;
/*       */     
/* 14019 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14021 */       if (arrayOfString[b] == str)
/*       */       {
/* 14023 */         if (bool) {
/*       */           
/* 14025 */           setAsciiStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 14027 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14032 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14033 */           sQLException.fillInStackTrace();
/* 14034 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14039 */     if (bool) {
/*       */       
/* 14041 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14042 */       sQLException.fillInStackTrace();
/* 14043 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 14063 */     String str = paramString.intern();
/* 14064 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14065 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14066 */     boolean bool = true;
/*       */     
/* 14068 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14070 */       if (arrayOfString[b] == str)
/*       */       {
/* 14072 */         if (bool) {
/*       */           
/* 14074 */           setAsciiStream(b + 1, paramInputStream, paramLong);
/*       */           
/* 14076 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14081 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14082 */           sQLException.fillInStackTrace();
/* 14083 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14088 */     if (bool) {
/*       */       
/* 14090 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14091 */       sQLException.fillInStackTrace();
/* 14092 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream) throws SQLException {
/* 14112 */     String str = paramString.intern();
/* 14113 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14114 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14115 */     boolean bool = true;
/*       */     
/* 14117 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14119 */       if (arrayOfString[b] == str)
/*       */       {
/* 14121 */         if (bool) {
/*       */           
/* 14123 */           setBinaryStream(b + 1, paramInputStream);
/*       */           
/* 14125 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14130 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14131 */           sQLException.fillInStackTrace();
/* 14132 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14137 */     if (bool) {
/*       */       
/* 14139 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14140 */       sQLException.fillInStackTrace();
/* 14141 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 14161 */     String str = paramString.intern();
/* 14162 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14163 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14164 */     boolean bool = true;
/*       */     
/* 14166 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14168 */       if (arrayOfString[b] == str)
/*       */       {
/* 14170 */         if (bool) {
/*       */           
/* 14172 */           setBinaryStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 14174 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14179 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14180 */           sQLException.fillInStackTrace();
/* 14181 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14186 */     if (bool) {
/*       */       
/* 14188 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14189 */       sQLException.fillInStackTrace();
/* 14190 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 14210 */     String str = paramString.intern();
/* 14211 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14212 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14213 */     boolean bool = true;
/*       */     
/* 14215 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14217 */       if (arrayOfString[b] == str)
/*       */       {
/* 14219 */         if (bool) {
/*       */           
/* 14221 */           setBinaryStream(b + 1, paramInputStream, paramLong);
/*       */           
/* 14223 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14228 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14229 */           sQLException.fillInStackTrace();
/* 14230 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14235 */     if (bool) {
/*       */       
/* 14237 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14238 */       sQLException.fillInStackTrace();
/* 14239 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader) throws SQLException {
/* 14259 */     String str = paramString.intern();
/* 14260 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14261 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14262 */     boolean bool = true;
/*       */     
/* 14264 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14266 */       if (arrayOfString[b] == str)
/*       */       {
/* 14268 */         if (bool) {
/*       */           
/* 14270 */           setCharacterStream(b + 1, paramReader);
/*       */           
/* 14272 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14277 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14278 */           sQLException.fillInStackTrace();
/* 14279 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14284 */     if (bool) {
/*       */       
/* 14286 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14287 */       sQLException.fillInStackTrace();
/* 14288 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 14308 */     String str = paramString.intern();
/* 14309 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14310 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14311 */     boolean bool = true;
/*       */     
/* 14313 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14315 */       if (arrayOfString[b] == str)
/*       */       {
/* 14317 */         if (bool) {
/*       */           
/* 14319 */           setCharacterStream(b + 1, paramReader, paramInt);
/*       */           
/* 14321 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14326 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14327 */           sQLException.fillInStackTrace();
/* 14328 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14333 */     if (bool) {
/*       */       
/* 14335 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14336 */       sQLException.fillInStackTrace();
/* 14337 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 14357 */     String str = paramString.intern();
/* 14358 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14359 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14360 */     boolean bool = true;
/*       */     
/* 14362 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14364 */       if (arrayOfString[b] == str)
/*       */       {
/* 14366 */         if (bool) {
/*       */           
/* 14368 */           setCharacterStream(b + 1, paramReader, paramLong);
/*       */           
/* 14370 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14375 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14376 */           sQLException.fillInStackTrace();
/* 14377 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14382 */     if (bool) {
/*       */       
/* 14384 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14385 */       sQLException.fillInStackTrace();
/* 14386 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStreamAtName(String paramString, Reader paramReader) throws SQLException {
/* 14406 */     String str = paramString.intern();
/* 14407 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14408 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14409 */     boolean bool = true;
/*       */     
/* 14411 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14413 */       if (arrayOfString[b] == str)
/*       */       {
/* 14415 */         if (bool) {
/*       */           
/* 14417 */           setNCharacterStream(b + 1, paramReader);
/*       */           
/* 14419 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14424 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14425 */           sQLException.fillInStackTrace();
/* 14426 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14431 */     if (bool) {
/*       */       
/* 14433 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14434 */       sQLException.fillInStackTrace();
/* 14435 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNCharacterStreamAtName(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 14455 */     String str = paramString.intern();
/* 14456 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14457 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14458 */     boolean bool = true;
/*       */     
/* 14460 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14462 */       if (arrayOfString[b] == str)
/*       */       {
/* 14464 */         if (bool) {
/*       */           
/* 14466 */           setNCharacterStream(b + 1, paramReader, paramLong);
/*       */           
/* 14468 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14473 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14474 */           sQLException.fillInStackTrace();
/* 14475 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14480 */     if (bool) {
/*       */       
/* 14482 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14483 */       sQLException.fillInStackTrace();
/* 14484 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 14504 */     String str = paramString.intern();
/* 14505 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 14506 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 14507 */     boolean bool = true;
/*       */     
/* 14509 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 14511 */       if (arrayOfString[b] == str)
/*       */       {
/* 14513 */         if (bool) {
/*       */           
/* 14515 */           setUnicodeStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 14517 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 14522 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 14523 */           sQLException.fillInStackTrace();
/* 14524 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 14529 */     if (bool) {
/*       */       
/* 14531 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 14532 */       sQLException.fillInStackTrace();
/* 14533 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 14542 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*       */   public static final boolean TRACE = false;
/*       */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OraclePreparedStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */