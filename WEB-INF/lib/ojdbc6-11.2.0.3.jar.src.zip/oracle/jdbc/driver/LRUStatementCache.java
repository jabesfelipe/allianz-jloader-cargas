/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LRUStatementCache
/*     */ {
/*     */   private int cacheSize;
/*     */   private int numElements;
/*     */   private OracleStatementCacheEntry applicationCacheStart;
/*     */   private OracleStatementCacheEntry applicationCacheEnd;
/*     */   private OracleStatementCacheEntry implicitCacheStart;
/*     */   private OracleStatementCacheEntry explicitCacheStart;
/*     */   boolean implicitCacheEnabled;
/*     */   boolean explicitCacheEnabled;
/*     */   private boolean debug = false;
/*     */   
/*     */   protected LRUStatementCache(int paramInt) throws SQLException {
/*  65 */     if (paramInt < 0) {
/*     */       
/*  67 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 123);
/*  68 */       sQLException.fillInStackTrace();
/*  69 */       throw sQLException;
/*     */     } 
/*     */     
/*  72 */     this.cacheSize = paramInt;
/*  73 */     this.numElements = 0;
/*     */     
/*  75 */     this.implicitCacheStart = null;
/*  76 */     this.explicitCacheStart = null;
/*     */     
/*  78 */     this.implicitCacheEnabled = false;
/*  79 */     this.explicitCacheEnabled = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resize(int paramInt) throws SQLException {
/*  97 */     if (paramInt < 0) {
/*     */       
/*  99 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 123);
/* 100 */       sQLException.fillInStackTrace();
/* 101 */       throw sQLException;
/*     */     } 
/*     */     
/* 104 */     if (paramInt >= this.cacheSize || paramInt >= this.numElements) {
/*     */ 
/*     */       
/* 107 */       this.cacheSize = paramInt;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 113 */       OracleStatementCacheEntry oracleStatementCacheEntry = this.applicationCacheEnd;
/* 114 */       for (; this.numElements > paramInt; oracleStatementCacheEntry = oracleStatementCacheEntry.applicationPrev) {
/* 115 */         purgeCacheEntry(oracleStatementCacheEntry);
/*     */       }
/* 117 */       this.cacheSize = paramInt;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/* 135 */     if (!paramBoolean) {
/* 136 */       purgeImplicitCache();
/*     */     }
/* 138 */     this.implicitCacheEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getImplicitCachingEnabled() throws SQLException {
/*     */     boolean bool;
/* 155 */     if (this.cacheSize == 0) {
/* 156 */       bool = false;
/*     */     } else {
/* 158 */       bool = this.implicitCacheEnabled;
/* 159 */     }  return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/* 176 */     if (!paramBoolean) {
/* 177 */       purgeExplicitCache();
/*     */     }
/* 179 */     this.explicitCacheEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getExplicitCachingEnabled() throws SQLException {
/*     */     boolean bool;
/* 196 */     if (this.cacheSize == 0) {
/* 197 */       bool = false;
/*     */     } else {
/* 199 */       bool = this.explicitCacheEnabled;
/* 200 */     }  return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addToImplicitCache(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 222 */     if (!this.implicitCacheEnabled || this.cacheSize == 0 || paramOraclePreparedStatement.cacheState == 2) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     if (this.numElements == this.cacheSize) {
/* 234 */       purgeCacheEntry(this.applicationCacheEnd);
/*     */     }
/*     */ 
/*     */     
/* 238 */     paramOraclePreparedStatement.enterImplicitCache();
/*     */ 
/*     */     
/* 241 */     OracleStatementCacheEntry oracleStatementCacheEntry = new OracleStatementCacheEntry();
/*     */     
/* 243 */     oracleStatementCacheEntry.statement = paramOraclePreparedStatement;
/* 244 */     oracleStatementCacheEntry.onImplicit = true;
/*     */     
/* 246 */     oracleStatementCacheEntry.sql = paramString;
/* 247 */     oracleStatementCacheEntry.statementType = paramInt1;
/* 248 */     oracleStatementCacheEntry.scrollType = paramInt2;
/*     */ 
/*     */     
/* 251 */     oracleStatementCacheEntry.applicationNext = this.applicationCacheStart;
/* 252 */     oracleStatementCacheEntry.applicationPrev = null;
/*     */     
/* 254 */     if (this.applicationCacheStart != null) {
/* 255 */       this.applicationCacheStart.applicationPrev = oracleStatementCacheEntry;
/*     */     }
/* 257 */     this.applicationCacheStart = oracleStatementCacheEntry;
/*     */     
/* 259 */     oracleStatementCacheEntry.implicitNext = this.implicitCacheStart;
/* 260 */     oracleStatementCacheEntry.implicitPrev = null;
/*     */     
/* 262 */     if (this.implicitCacheStart != null) {
/* 263 */       this.implicitCacheStart.implicitPrev = oracleStatementCacheEntry;
/*     */     }
/* 265 */     this.implicitCacheStart = oracleStatementCacheEntry;
/*     */ 
/*     */     
/* 268 */     if (this.applicationCacheEnd == null) {
/* 269 */       this.applicationCacheEnd = oracleStatementCacheEntry;
/*     */     }
/*     */ 
/*     */     
/* 273 */     this.numElements++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addToExplicitCache(OraclePreparedStatement paramOraclePreparedStatement, String paramString) throws SQLException {
/* 291 */     if (!this.explicitCacheEnabled || this.cacheSize == 0 || paramOraclePreparedStatement.cacheState == 2) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 300 */     if (this.numElements == this.cacheSize) {
/* 301 */       purgeCacheEntry(this.applicationCacheEnd);
/*     */     }
/*     */ 
/*     */     
/* 305 */     paramOraclePreparedStatement.enterExplicitCache();
/*     */ 
/*     */     
/* 308 */     OracleStatementCacheEntry oracleStatementCacheEntry = new OracleStatementCacheEntry();
/*     */     
/* 310 */     oracleStatementCacheEntry.statement = paramOraclePreparedStatement;
/* 311 */     oracleStatementCacheEntry.sql = paramString;
/* 312 */     oracleStatementCacheEntry.onImplicit = false;
/*     */ 
/*     */     
/* 315 */     oracleStatementCacheEntry.applicationNext = this.applicationCacheStart;
/* 316 */     oracleStatementCacheEntry.applicationPrev = null;
/*     */     
/* 318 */     if (this.applicationCacheStart != null) {
/* 319 */       this.applicationCacheStart.applicationPrev = oracleStatementCacheEntry;
/*     */     }
/* 321 */     this.applicationCacheStart = oracleStatementCacheEntry;
/*     */     
/* 323 */     oracleStatementCacheEntry.explicitNext = this.explicitCacheStart;
/* 324 */     oracleStatementCacheEntry.explicitPrev = null;
/*     */     
/* 326 */     if (this.explicitCacheStart != null) {
/* 327 */       this.explicitCacheStart.explicitPrev = oracleStatementCacheEntry;
/*     */     }
/* 329 */     this.explicitCacheStart = oracleStatementCacheEntry;
/*     */ 
/*     */     
/* 332 */     if (this.applicationCacheEnd == null) {
/* 333 */       this.applicationCacheEnd = oracleStatementCacheEntry;
/*     */     }
/*     */ 
/*     */     
/* 337 */     this.numElements++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleStatement searchImplicitCache(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 360 */     if (!this.implicitCacheEnabled)
/*     */     {
/*     */ 
/*     */       
/* 364 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 368 */     OracleStatementCacheEntry oracleStatementCacheEntry = null;
/*     */     
/* 370 */     for (oracleStatementCacheEntry = this.implicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.implicitNext) {
/*     */       
/* 372 */       if (oracleStatementCacheEntry.statementType == paramInt1 && oracleStatementCacheEntry.scrollType == paramInt2 && oracleStatementCacheEntry.sql.equals(paramString)) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 377 */     if (oracleStatementCacheEntry != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 386 */       if (oracleStatementCacheEntry.applicationPrev != null) {
/* 387 */         oracleStatementCacheEntry.applicationPrev.applicationNext = oracleStatementCacheEntry.applicationNext;
/*     */       }
/* 389 */       if (oracleStatementCacheEntry.applicationNext != null) {
/* 390 */         oracleStatementCacheEntry.applicationNext.applicationPrev = oracleStatementCacheEntry.applicationPrev;
/*     */       }
/* 392 */       if (this.applicationCacheStart == oracleStatementCacheEntry) {
/* 393 */         this.applicationCacheStart = oracleStatementCacheEntry.applicationNext;
/*     */       }
/* 395 */       if (this.applicationCacheEnd == oracleStatementCacheEntry) {
/* 396 */         this.applicationCacheEnd = oracleStatementCacheEntry.applicationPrev;
/*     */       }
/* 398 */       if (oracleStatementCacheEntry.implicitPrev != null) {
/* 399 */         oracleStatementCacheEntry.implicitPrev.implicitNext = oracleStatementCacheEntry.implicitNext;
/*     */       }
/* 401 */       if (oracleStatementCacheEntry.implicitNext != null) {
/* 402 */         oracleStatementCacheEntry.implicitNext.implicitPrev = oracleStatementCacheEntry.implicitPrev;
/*     */       }
/* 404 */       if (this.implicitCacheStart == oracleStatementCacheEntry) {
/* 405 */         this.implicitCacheStart = oracleStatementCacheEntry.implicitNext;
/*     */       }
/*     */ 
/*     */       
/* 409 */       this.numElements--;
/*     */ 
/*     */       
/* 412 */       oracleStatementCacheEntry.statement.exitImplicitCacheToActive();
/*     */ 
/*     */ 
/*     */       
/* 416 */       return oracleStatementCacheEntry.statement;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 426 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleStatement searchExplicitCache(String paramString) throws SQLException {
/* 445 */     if (!this.explicitCacheEnabled)
/*     */     {
/*     */ 
/*     */       
/* 449 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 453 */     OracleStatementCacheEntry oracleStatementCacheEntry = null;
/*     */     
/* 455 */     for (oracleStatementCacheEntry = this.explicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.explicitNext) {
/*     */       
/* 457 */       if (oracleStatementCacheEntry.sql.equals(paramString)) {
/*     */         break;
/*     */       }
/*     */     } 
/* 461 */     if (oracleStatementCacheEntry != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 471 */       if (oracleStatementCacheEntry.applicationPrev != null) {
/* 472 */         oracleStatementCacheEntry.applicationPrev.applicationNext = oracleStatementCacheEntry.applicationNext;
/*     */       }
/* 474 */       if (oracleStatementCacheEntry.applicationNext != null) {
/* 475 */         oracleStatementCacheEntry.applicationNext.applicationPrev = oracleStatementCacheEntry.applicationPrev;
/*     */       }
/* 477 */       if (this.applicationCacheStart == oracleStatementCacheEntry) {
/* 478 */         this.applicationCacheStart = oracleStatementCacheEntry.applicationNext;
/*     */       }
/* 480 */       if (this.applicationCacheEnd == oracleStatementCacheEntry) {
/* 481 */         this.applicationCacheEnd = oracleStatementCacheEntry.applicationPrev;
/*     */       }
/* 483 */       if (oracleStatementCacheEntry.explicitPrev != null) {
/* 484 */         oracleStatementCacheEntry.explicitPrev.explicitNext = oracleStatementCacheEntry.explicitNext;
/*     */       }
/* 486 */       if (oracleStatementCacheEntry.explicitNext != null) {
/* 487 */         oracleStatementCacheEntry.explicitNext.explicitPrev = oracleStatementCacheEntry.explicitPrev;
/*     */       }
/* 489 */       if (this.explicitCacheStart == oracleStatementCacheEntry) {
/* 490 */         this.explicitCacheStart = oracleStatementCacheEntry.explicitNext;
/*     */       }
/*     */ 
/*     */       
/* 494 */       this.numElements--;
/*     */ 
/*     */       
/* 497 */       oracleStatementCacheEntry.statement.exitExplicitCacheToActive();
/*     */       
/* 499 */       return oracleStatementCacheEntry.statement;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 507 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void purgeImplicitCache() throws SQLException {
/* 523 */     for (OracleStatementCacheEntry oracleStatementCacheEntry = this.implicitCacheStart; oracleStatementCacheEntry != null; 
/* 524 */       oracleStatementCacheEntry = oracleStatementCacheEntry.implicitNext) {
/* 525 */       purgeCacheEntry(oracleStatementCacheEntry);
/*     */     }
/* 527 */     this.implicitCacheStart = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void purgeExplicitCache() throws SQLException {
/* 543 */     for (OracleStatementCacheEntry oracleStatementCacheEntry = this.explicitCacheStart; oracleStatementCacheEntry != null; 
/* 544 */       oracleStatementCacheEntry = oracleStatementCacheEntry.explicitNext) {
/* 545 */       purgeCacheEntry(oracleStatementCacheEntry);
/*     */     }
/* 547 */     this.explicitCacheStart = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void purgeCacheEntry(OracleStatementCacheEntry paramOracleStatementCacheEntry) throws SQLException {
/* 565 */     if (paramOracleStatementCacheEntry.applicationNext != null) {
/* 566 */       paramOracleStatementCacheEntry.applicationNext.applicationPrev = paramOracleStatementCacheEntry.applicationPrev;
/*     */     }
/* 568 */     if (paramOracleStatementCacheEntry.applicationPrev != null) {
/* 569 */       paramOracleStatementCacheEntry.applicationPrev.applicationNext = paramOracleStatementCacheEntry.applicationNext;
/*     */     }
/* 571 */     if (this.applicationCacheStart == paramOracleStatementCacheEntry) {
/* 572 */       this.applicationCacheStart = paramOracleStatementCacheEntry.applicationNext;
/*     */     }
/* 574 */     if (this.applicationCacheEnd == paramOracleStatementCacheEntry) {
/* 575 */       this.applicationCacheEnd = paramOracleStatementCacheEntry.applicationPrev;
/*     */     }
/* 577 */     if (paramOracleStatementCacheEntry.onImplicit) {
/*     */       
/* 579 */       if (paramOracleStatementCacheEntry.implicitNext != null) {
/* 580 */         paramOracleStatementCacheEntry.implicitNext.implicitPrev = paramOracleStatementCacheEntry.implicitPrev;
/*     */       }
/* 582 */       if (paramOracleStatementCacheEntry.implicitPrev != null) {
/* 583 */         paramOracleStatementCacheEntry.implicitPrev.implicitNext = paramOracleStatementCacheEntry.implicitNext;
/*     */       }
/* 585 */       if (this.implicitCacheStart == paramOracleStatementCacheEntry) {
/* 586 */         this.implicitCacheStart = paramOracleStatementCacheEntry.implicitNext;
/*     */       }
/*     */     } else {
/*     */       
/* 590 */       if (paramOracleStatementCacheEntry.explicitNext != null) {
/* 591 */         paramOracleStatementCacheEntry.explicitNext.explicitPrev = paramOracleStatementCacheEntry.explicitPrev;
/*     */       }
/* 593 */       if (paramOracleStatementCacheEntry.explicitPrev != null) {
/* 594 */         paramOracleStatementCacheEntry.explicitPrev.explicitNext = paramOracleStatementCacheEntry.explicitNext;
/*     */       }
/* 596 */       if (this.explicitCacheStart == paramOracleStatementCacheEntry) {
/* 597 */         this.explicitCacheStart = paramOracleStatementCacheEntry.explicitNext;
/*     */       }
/*     */     } 
/*     */     
/* 601 */     this.numElements--;
/*     */ 
/*     */     
/* 604 */     if (paramOracleStatementCacheEntry.onImplicit) {
/* 605 */       paramOracleStatementCacheEntry.statement.exitImplicitCacheToClose();
/*     */     } else {
/* 607 */       paramOracleStatementCacheEntry.statement.exitExplicitCacheToClose();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCacheSize() {
/* 619 */     return this.cacheSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printCache(String paramString) throws SQLException {
/* 634 */     System.out.println("*** Start of Statement Cache Dump (" + paramString + ") ***");
/* 635 */     System.out.println("cache size: " + this.cacheSize + " num elements: " + this.numElements + " implicit enabled: " + this.implicitCacheEnabled + " explicit enabled: " + this.explicitCacheEnabled);
/*     */ 
/*     */ 
/*     */     
/* 639 */     System.out.println("applicationStart: " + this.applicationCacheStart + "  applicationEnd: " + this.applicationCacheEnd);
/*     */     
/*     */     OracleStatementCacheEntry oracleStatementCacheEntry;
/* 642 */     for (oracleStatementCacheEntry = this.applicationCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.applicationNext) {
/* 643 */       oracleStatementCacheEntry.print();
/*     */     }
/* 645 */     System.out.println("implicitStart: " + this.implicitCacheStart);
/*     */     
/* 647 */     for (oracleStatementCacheEntry = this.implicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.implicitNext) {
/* 648 */       oracleStatementCacheEntry.print();
/*     */     }
/* 650 */     System.out.println("explicitStart: " + this.explicitCacheStart);
/*     */     
/* 652 */     for (oracleStatementCacheEntry = this.explicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.explicitNext) {
/* 653 */       oracleStatementCacheEntry.print();
/*     */     }
/* 655 */     System.out.println("*** End of Statement Cache Dump (" + paramString + ") ***");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 667 */     OracleStatementCacheEntry oracleStatementCacheEntry = this.applicationCacheStart;
/* 668 */     for (; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.applicationNext) {
/*     */ 
/*     */ 
/*     */       
/* 672 */       if (oracleStatementCacheEntry.onImplicit) {
/* 673 */         oracleStatementCacheEntry.statement.exitImplicitCacheToClose();
/*     */       } else {
/* 675 */         oracleStatementCacheEntry.statement.exitExplicitCacheToClose();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 681 */     this.applicationCacheStart = null;
/* 682 */     this.applicationCacheEnd = null;
/* 683 */     this.implicitCacheStart = null;
/* 684 */     this.explicitCacheStart = null;
/* 685 */     this.numElements = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 700 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 705 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\LRUStatementCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */