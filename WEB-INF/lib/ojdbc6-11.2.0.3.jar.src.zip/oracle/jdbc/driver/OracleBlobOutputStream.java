/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.BLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleBlobOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   long lobOffset;
/*     */   BLOB blob;
/*     */   byte[] buf;
/*     */   int count;
/*     */   int bufSize;
/*     */   boolean isClosed;
/*     */   
/*     */   public OracleBlobOutputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/*  43 */     this(paramBLOB, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleBlobOutputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/*  60 */     if (paramBLOB == null || paramInt <= 0 || paramLong < 1L)
/*     */     {
/*  62 */       throw new IllegalArgumentException("Illegal Arguments");
/*     */     }
/*     */     
/*  65 */     this.blob = paramBLOB;
/*  66 */     this.lobOffset = paramLong;
/*     */     
/*  68 */     PhysicalConnection physicalConnection = (PhysicalConnection)paramBLOB.getInternalConnection();
/*  69 */     synchronized (physicalConnection) {
/*  70 */       this.buf = physicalConnection.getByteBuffer(paramInt);
/*     */     } 
/*  72 */     this.count = 0;
/*  73 */     this.bufSize = paramInt;
/*     */     
/*  75 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int paramInt) throws IOException {
/*  89 */     ensureOpen();
/*     */     
/*  91 */     if (this.count >= this.bufSize) {
/*  92 */       flushBuffer();
/*     */     }
/*  94 */     this.buf[this.count++] = (byte)paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 111 */     ensureOpen();
/*     */     
/* 113 */     int i = paramInt1;
/* 114 */     int j = Math.min(paramInt2, paramArrayOfbyte.length - paramInt1);
/*     */     
/* 116 */     if (j >= 2 * this.bufSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       if (this.count > 0) flushBuffer();
/*     */       
/*     */       try {
/* 126 */         this.lobOffset += this.blob.setBytes(this.lobOffset, paramArrayOfbyte, paramInt1, j);
/*     */       }
/* 128 */       catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 131 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 132 */         iOException.fillInStackTrace();
/* 133 */         throw iOException;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 139 */       int k = i + j;
/*     */       
/* 141 */       while (i < k) {
/*     */         
/* 143 */         int m = Math.min(this.bufSize - this.count, k - i);
/*     */         
/* 145 */         System.arraycopy(paramArrayOfbyte, i, this.buf, this.count, m);
/*     */         
/* 147 */         i += m;
/* 148 */         this.count += m;
/*     */         
/* 150 */         if (this.count >= this.bufSize) {
/* 151 */           flushBuffer();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 167 */     ensureOpen();
/*     */     
/* 169 */     flushBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 183 */     if (this.isClosed) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 188 */       this.isClosed = true;
/* 189 */       flushBuffer();
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/* 194 */         PhysicalConnection physicalConnection = (PhysicalConnection)this.blob.getInternalConnection();
/* 195 */         synchronized (physicalConnection) {
/*     */           
/* 197 */           if (this.buf != null) {
/*     */             
/* 199 */             physicalConnection.cacheBuffer(this.buf);
/* 200 */             this.buf = null;
/*     */           } 
/*     */         } 
/* 203 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 206 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 207 */         iOException.fillInStackTrace();
/* 208 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushBuffer() throws IOException {
/*     */     try {
/* 226 */       if (this.count > 0)
/*     */       {
/* 228 */         this.lobOffset += this.blob.setBytes(this.lobOffset, this.buf, 0, this.count);
/* 229 */         this.count = 0;
/*     */       }
/*     */     
/* 232 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 235 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 236 */       iOException.fillInStackTrace();
/* 237 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureOpen() throws IOException {
/*     */     try {
/* 254 */       if (this.isClosed)
/*     */       {
/* 256 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 257 */         sQLException.fillInStackTrace();
/* 258 */         throw sQLException;
/*     */       }
/*     */     
/* 261 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 264 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 265 */       iOException.fillInStackTrace();
/* 266 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*     */     try {
/* 286 */       return this.blob.getInternalConnection();
/*     */     }
/* 288 */     catch (Exception exception) {
/*     */       
/* 290 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 297 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\OracleBlobOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */