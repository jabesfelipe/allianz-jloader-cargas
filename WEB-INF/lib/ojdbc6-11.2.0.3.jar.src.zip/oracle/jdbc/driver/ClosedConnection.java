/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.pool.OraclePooledConnection;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClosedConnection
/*     */   extends PhysicalConnection
/*     */ {
/*     */   void initializePassword(String paramString) throws SQLException {}
/*     */   
/*     */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException {
/*  44 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  45 */     sQLException.fillInStackTrace();
/*  46 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getDefaultStreamChunkSize() {
/*  54 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short doGetVersionNumber() throws SQLException {
/*  62 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  63 */     sQLException.fillInStackTrace();
/*  64 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String doGetDatabaseProductVersion() throws SQLException {
/*  74 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  75 */     sQLException.fillInStackTrace();
/*  76 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doRollback() throws SQLException {
/*  86 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  87 */     sQLException.fillInStackTrace();
/*  88 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doCommit(int paramInt) throws SQLException {
/*  97 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  98 */     sQLException.fillInStackTrace();
/*  99 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doSetAutoCommit(boolean paramBoolean) throws SQLException {
/* 108 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 109 */     sQLException.fillInStackTrace();
/* 110 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void cancelOperationOnServer() throws SQLException {
/* 119 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 120 */     sQLException.fillInStackTrace();
/* 121 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doAbort() throws SQLException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void open(OracleStatement paramOracleStatement) throws SQLException {
/* 137 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 138 */     sQLException.fillInStackTrace();
/* 139 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void logon() throws SQLException {
/* 148 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 149 */     sQLException.fillInStackTrace();
/* 150 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 160 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 161 */     sQLException.fillInStackTrace();
/* 162 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException {
/* 171 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 172 */     sQLException.fillInStackTrace();
/* 173 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/* 182 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 183 */     sQLException.fillInStackTrace();
/* 184 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\ClosedConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */