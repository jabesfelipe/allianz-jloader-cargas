/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DateAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   static final int maxLength = 7;
/*     */   
/*     */   DateAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  31 */     init(paramOracleStatement, 12, 12, paramShort, paramBoolean);
/*  32 */     initForDataAccess(paramInt2, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DateAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  41 */     init(paramOracleStatement, 12, 12, paramShort, false);
/*  42 */     initForDescribe(12, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  44 */     initForDataAccess(0, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  52 */     if (paramInt1 != 0) {
/*  53 */       this.externalType = paramInt1;
/*     */     }
/*  55 */     this.internalTypeMaxLength = 7;
/*     */     
/*  57 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*  58 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  60 */     this.byteLength = this.internalTypeMaxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*  68 */     String str = null;
/*     */     
/*  70 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/*  74 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  75 */       sQLException.fillInStackTrace();
/*  76 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*  84 */       int i = this.columnIndex + this.byteLength * paramInt;
/*  85 */       int j = ((this.rowSpaceByte[0 + i] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + i] & 0xFF) - 100;
/*     */ 
/*     */       
/*  88 */       int k = 0;
/*  89 */       str = toText(j, this.rowSpaceByte[2 + i], this.rowSpaceByte[3 + i], k = this.rowSpaceByte[4 + i] - 1, this.rowSpaceByte[5 + i] - 1, this.rowSpaceByte[6 + i] - 1, -1, (k < 12), (String)null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/*     */     Date date;
/* 108 */     Timestamp timestamp = null;
/*     */     
/* 110 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 115 */       sQLException.fillInStackTrace();
/* 116 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 121 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*     */     {
/* 123 */       if (this.externalType == 0) {
/*     */ 
/*     */         
/* 126 */         if (this.statement.connection.mapDateToTimestamp) {
/* 127 */           timestamp = getTimestamp(paramInt);
/*     */         } else {
/* 129 */           date = getDate(paramInt);
/*     */         } 
/*     */       } else {
/*     */         
/* 133 */         switch (this.externalType) {
/*     */           
/*     */           case 91:
/* 136 */             return getDate(paramInt);
/*     */           case 92:
/* 138 */             return getTime(paramInt);
/*     */           case 93:
/* 140 */             return getTimestamp(paramInt);
/*     */         } 
/*     */         
/* 143 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*     */         
/* 145 */         sQLException.fillInStackTrace();
/* 146 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 152 */     return date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 160 */     return (Datum)getDATE(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 168 */     return getObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String toStr(int paramInt) {
/* 175 */     return (paramInt < 10) ? ("0" + paramInt) : Integer.toString(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 180 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\driver\DateAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */