/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CHAR;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeCHAR
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = -6899444518695804629L;
/*     */   int form;
/*     */   int charset;
/*     */   int length;
/*     */   int characterSemantic;
/*     */   private transient OracleConnection connection;
/*     */   private short pickleCharaterSetId;
/*     */   private transient CharacterSet pickleCharacterSet;
/*     */   private short pickleNcharCharacterSet;
/*     */   static final int SQLCS_IMPLICIT = 1;
/*     */   static final int SQLCS_NCHAR = 2;
/*     */   static final int SQLCS_EXPLICIT = 3;
/*     */   static final int SQLCS_FLEXIBLE = 4;
/*     */   static final int SQLCS_LIT_NULL = 5;
/*     */   
/*     */   protected OracleTypeCHAR() {}
/*     */   
/*     */   public OracleTypeCHAR(OracleConnection paramOracleConnection) {
/*  68 */     this.form = 0;
/*  69 */     this.charset = 0;
/*  70 */     this.length = 0;
/*  71 */     this.connection = paramOracleConnection;
/*  72 */     this.pickleCharaterSetId = 0;
/*  73 */     this.pickleNcharCharacterSet = 0;
/*  74 */     this.pickleCharacterSet = null;
/*     */ 
/*     */     
/*     */     try {
/*  78 */       this.pickleCharaterSetId = this.connection.getStructAttrCsId();
/*     */     }
/*  80 */     catch (SQLException sQLException) {
/*     */ 
/*     */       
/*  83 */       this.pickleCharaterSetId = -1;
/*     */     } 
/*     */     
/*  86 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleTypeCHAR(OracleConnection paramOracleConnection, int paramInt) {
/*  92 */     super(paramInt);
/*     */     
/*  94 */     this.form = 0;
/*  95 */     this.charset = 0;
/*  96 */     this.length = 0;
/*  97 */     this.connection = paramOracleConnection;
/*  98 */     this.pickleCharaterSetId = 0;
/*  99 */     this.pickleNcharCharacterSet = 0;
/* 100 */     this.pickleCharacterSet = null;
/*     */ 
/*     */     
/*     */     try {
/* 104 */       this.pickleCharaterSetId = this.connection.getStructAttrCsId();
/*     */     }
/* 106 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 110 */       this.pickleCharaterSetId = -1;
/*     */     } 
/*     */     
/* 113 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/* 139 */     if (paramObject == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     return (Datum)((paramObject instanceof CHAR) ? (CHAR)paramObject : new CHAR(paramObject, this.pickleCharacterSet));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/* 166 */     Datum[] arrayOfDatum = null;
/*     */     
/* 168 */     if (paramObject != null) {
/*     */       
/* 170 */       if (paramObject instanceof Object[] && !(paramObject instanceof char[][])) {
/* 171 */         return super.toDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */       }
/* 173 */       arrayOfDatum = cArrayToDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */     } 
/*     */     
/* 176 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/* 191 */     super.parseTDSrec(paramTDSReader);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 196 */       this.length = paramTDSReader.readUB2();
/* 197 */       this.form = paramTDSReader.readByte();
/* 198 */       this.characterSemantic = this.form & 0x80;
/* 199 */       this.form &= 0x7F;
/* 200 */       this.charset = paramTDSReader.readUB2();
/*     */     }
/* 202 */     catch (SQLException sQLException1) {
/*     */ 
/*     */       
/* 205 */       SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
/* 206 */       sQLException2.fillInStackTrace();
/* 207 */       throw sQLException2;
/*     */     } 
/*     */ 
/*     */     
/* 211 */     if (this.form != 2 || this.pickleNcharCharacterSet != 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 220 */       this.pickleNcharCharacterSet = this.connection.getStructAttrNCsId();
/*     */     }
/* 222 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 226 */       this.pickleNcharCharacterSet = 2000;
/*     */     } 
/*     */     
/* 229 */     this.pickleCharaterSetId = this.pickleNcharCharacterSet;
/* 230 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException {
/* 256 */     CHAR cHAR = getDbCHAR(paramDatum);
/*     */     
/* 258 */     if (this.characterSemantic != 0 && this.form != 2) {
/*     */ 
/*     */ 
/*     */       
/* 262 */       if (cHAR.getStringWithReplacement().length() > this.length)
/*     */       {
/* 264 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, "\"" + cHAR.getStringWithReplacement() + "\"");
/* 265 */         sQLException.fillInStackTrace();
/* 266 */         throw sQLException;
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 273 */     else if (cHAR.getLength() > this.length) {
/*     */       
/* 275 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, "\"" + cHAR.getStringWithReplacement() + "\"");
/* 276 */       sQLException.fillInStackTrace();
/* 277 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 281 */     return super.pickle81(paramPickleContext, (Datum)cHAR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 293 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 294 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 298 */     CHAR cHAR = null;
/*     */     
/* 300 */     switch (this.form) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 308 */         cHAR = new CHAR(paramArrayOfbyte, this.pickleCharacterSet);
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/* 317 */         cHAR = new CHAR(paramArrayOfbyte, null);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 322 */     if (paramInt == 1)
/* 323 */       return cHAR; 
/* 324 */     if (paramInt == 2)
/* 325 */       return cHAR.stringValue(); 
/* 326 */     if (paramInt == 3) {
/* 327 */       return paramArrayOfbyte;
/*     */     }
/*     */     
/* 330 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
/* 331 */     sQLException.fillInStackTrace();
/* 332 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CHAR getDbCHAR(Datum paramDatum) {
/* 346 */     CHAR cHAR1 = (CHAR)paramDatum;
/* 347 */     CHAR cHAR2 = null;
/*     */     
/* 349 */     if (cHAR1.getCharacterSet().getOracleId() == this.pickleCharaterSetId) {
/*     */       
/* 351 */       cHAR2 = cHAR1;
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 357 */         cHAR2 = new CHAR(cHAR1.toString(), this.pickleCharacterSet);
/*     */       }
/* 359 */       catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */         
/* 363 */         cHAR2 = cHAR1;
/*     */       } 
/*     */     } 
/* 366 */     return cHAR2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Datum[] cArrayToDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/* 395 */     Datum[] arrayOfDatum = null;
/*     */     
/* 397 */     if (paramObject != null)
/*     */     {
/* 399 */       if (paramObject instanceof char[][]) {
/*     */         
/* 401 */         char[][] arrayOfChar = (char[][])paramObject;
/* 402 */         int i = (int)((paramInt == -1) ? arrayOfChar.length : Math.min(arrayOfChar.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 405 */         arrayOfDatum = new Datum[i];
/*     */         
/* 407 */         for (byte b = 0; b < i; b++) {
/* 408 */           arrayOfDatum[b] = (Datum)new CHAR(new String(arrayOfChar[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 411 */       else if (paramObject instanceof boolean[]) {
/*     */         
/* 413 */         boolean[] arrayOfBoolean = (boolean[])paramObject;
/* 414 */         int i = (int)((paramInt == -1) ? arrayOfBoolean.length : Math.min(arrayOfBoolean.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 417 */         arrayOfDatum = new Datum[i];
/*     */         
/* 419 */         for (byte b = 0; b < i; b++) {
/* 420 */           arrayOfDatum[b] = (Datum)new CHAR(Boolean.valueOf(arrayOfBoolean[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 423 */       else if (paramObject instanceof short[]) {
/*     */         
/* 425 */         short[] arrayOfShort = (short[])paramObject;
/* 426 */         int i = (int)((paramInt == -1) ? arrayOfShort.length : Math.min(arrayOfShort.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 429 */         arrayOfDatum = new Datum[i];
/*     */ 
/*     */ 
/*     */         
/* 433 */         for (byte b = 0; b < i; b++) {
/* 434 */           arrayOfDatum[b] = (Datum)new CHAR(Integer.valueOf(arrayOfShort[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         
/*     */         }
/*     */       }
/* 438 */       else if (paramObject instanceof int[]) {
/*     */         
/* 440 */         int[] arrayOfInt = (int[])paramObject;
/* 441 */         int i = (int)((paramInt == -1) ? arrayOfInt.length : Math.min(arrayOfInt.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 444 */         arrayOfDatum = new Datum[i];
/*     */         
/* 446 */         for (byte b = 0; b < i; b++) {
/* 447 */           arrayOfDatum[b] = (Datum)new CHAR(Integer.valueOf(arrayOfInt[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 450 */       else if (paramObject instanceof long[]) {
/*     */         
/* 452 */         long[] arrayOfLong = (long[])paramObject;
/* 453 */         int i = (int)((paramInt == -1) ? arrayOfLong.length : Math.min(arrayOfLong.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 456 */         arrayOfDatum = new Datum[i];
/*     */         
/* 458 */         for (byte b = 0; b < i; b++) {
/* 459 */           arrayOfDatum[b] = (Datum)new CHAR(new Long(arrayOfLong[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 462 */       else if (paramObject instanceof float[]) {
/*     */         
/* 464 */         float[] arrayOfFloat = (float[])paramObject;
/* 465 */         int i = (int)((paramInt == -1) ? arrayOfFloat.length : Math.min(arrayOfFloat.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 468 */         arrayOfDatum = new Datum[i];
/*     */         
/* 470 */         for (byte b = 0; b < i; b++) {
/* 471 */           arrayOfDatum[b] = (Datum)new CHAR(new Float(arrayOfFloat[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 474 */       else if (paramObject instanceof double[]) {
/*     */         
/* 476 */         double[] arrayOfDouble = (double[])paramObject;
/* 477 */         int i = (int)((paramInt == -1) ? arrayOfDouble.length : Math.min(arrayOfDouble.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 480 */         arrayOfDatum = new Datum[i];
/*     */         
/* 482 */         for (byte b = 0; b < i; b++) {
/* 483 */           arrayOfDatum[b] = (Datum)new CHAR(new Double(arrayOfDouble[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 489 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 490 */         sQLException.fillInStackTrace();
/* 491 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 496 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 503 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 514 */     paramObjectOutputStream.writeInt(this.form);
/* 515 */     paramObjectOutputStream.writeInt(this.charset);
/* 516 */     paramObjectOutputStream.writeInt(this.length);
/* 517 */     paramObjectOutputStream.writeInt(this.characterSemantic);
/* 518 */     paramObjectOutputStream.writeShort(this.pickleCharaterSetId);
/* 519 */     paramObjectOutputStream.writeShort(this.pickleNcharCharacterSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 527 */     this.form = paramObjectInputStream.readInt();
/* 528 */     this.charset = paramObjectInputStream.readInt();
/* 529 */     this.length = paramObjectInputStream.readInt();
/* 530 */     this.characterSemantic = paramObjectInputStream.readInt();
/* 531 */     this.pickleCharaterSetId = paramObjectInputStream.readShort();
/* 532 */     this.pickleNcharCharacterSet = paramObjectInputStream.readShort();
/*     */     
/* 534 */     if (this.pickleNcharCharacterSet != 0) {
/* 535 */       this.pickleCharacterSet = CharacterSet.make(this.pickleNcharCharacterSet);
/*     */     } else {
/* 537 */       this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 544 */     this.connection = paramOracleConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNCHAR() throws SQLException {
/* 558 */     return (this.form == 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 573 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 618 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\oracore\OracleTypeCHAR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */