/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NUMBER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeNUMBER
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = -7182242886677299812L;
/*     */   int precision;
/*     */   int scale;
/*     */   
/*     */   protected OracleTypeNUMBER() {}
/*     */   
/*     */   protected OracleTypeNUMBER(int paramInt) {
/*  43 */     super(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  59 */     return (Datum)toNUMBER(paramObject, paramOracleConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/*  73 */     return toNUMBERArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/*  84 */     this.precision = paramTDSReader.readUnsignedByte();
/*     */ 
/*     */     
/*  87 */     this.scale = paramTDSReader.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Object unpickle81NativeArray(PickleContext paramPickleContext, long paramLong, int paramInt1, int paramInt2) throws SQLException {
/*     */     int[] arrayOfInt;
/*     */     double[] arrayOfDouble;
/*     */     long[] arrayOfLong;
/*     */     float[] arrayOfFloat;
/*     */     short[] arrayOfShort;
/*     */     byte b2;
/*  99 */     for (byte b1 = 1; b1 < paramLong && paramInt1 > 0; b1++) {
/* 100 */       paramPickleContext.skipDataValue();
/*     */     }
/* 102 */     byte[] arrayOfByte = null;
/*     */     
/* 104 */     switch (paramInt2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 113 */         arrayOfInt = new int[paramInt1];
/*     */         
/* 115 */         for (b2 = 0; b2 < paramInt1; b2++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 135 */           if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
/* 136 */             arrayOfInt[b2] = NUMBER.toInt(arrayOfByte);
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 141 */         return arrayOfInt;
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 146 */         arrayOfDouble = new double[paramInt1];
/*     */         
/* 148 */         for (b2 = 0; b2 < paramInt1; b2++) {
/*     */           
/* 150 */           if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
/* 151 */             arrayOfDouble[b2] = NUMBER.toDouble(arrayOfByte);
/*     */           }
/*     */         } 
/* 154 */         return arrayOfDouble;
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 159 */         arrayOfLong = new long[paramInt1];
/*     */         
/* 161 */         for (b2 = 0; b2 < paramInt1; b2++) {
/*     */           
/* 163 */           if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
/* 164 */             arrayOfLong[b2] = NUMBER.toLong(arrayOfByte);
/*     */           }
/*     */         } 
/* 167 */         return arrayOfLong;
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 172 */         arrayOfFloat = new float[paramInt1];
/*     */         
/* 174 */         for (b2 = 0; b2 < paramInt1; b2++) {
/*     */           
/* 176 */           if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
/* 177 */             arrayOfFloat[b2] = NUMBER.toFloat(arrayOfByte);
/*     */           }
/*     */         } 
/* 180 */         return arrayOfFloat;
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 185 */         arrayOfShort = new short[paramInt1];
/*     */         
/* 187 */         for (b2 = 0; b2 < paramInt1; b2++) {
/*     */           
/* 189 */           if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
/* 190 */             arrayOfShort[b2] = NUMBER.toShort(arrayOfByte);
/*     */           }
/*     */         } 
/* 193 */         return arrayOfShort;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 198 */     SQLException sQLException = DatabaseError.createSqlException(null, 23);
/* 199 */     sQLException.fillInStackTrace();
/* 200 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 214 */     return toNumericObject(paramArrayOfbyte, paramInt, paramMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object toNumericObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 222 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 223 */       return null;
/*     */     }
/* 225 */     switch (paramInt) {
/*     */ 
/*     */       
/*     */       case 1:
/* 229 */         return new NUMBER(paramArrayOfbyte);
/*     */       
/*     */       case 2:
/* 232 */         return NUMBER.toBigDecimal(paramArrayOfbyte);
/*     */       
/*     */       case 3:
/* 235 */         return paramArrayOfbyte;
/*     */     } 
/*     */ 
/*     */     
/* 239 */     SQLException sQLException = DatabaseError.createSqlException(null, 23);
/* 240 */     sQLException.fillInStackTrace();
/* 241 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NUMBER toNUMBER(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/* 255 */     NUMBER nUMBER = null;
/*     */     
/* 257 */     if (paramObject != null) {
/*     */       
/*     */       try {
/*     */         
/* 261 */         if (paramObject instanceof NUMBER) {
/* 262 */           nUMBER = (NUMBER)paramObject;
/*     */         } else {
/* 264 */           nUMBER = new NUMBER(paramObject);
/*     */         } 
/* 266 */       } catch (SQLException sQLException1) {
/*     */ 
/*     */         
/* 269 */         SQLException sQLException2 = DatabaseError.createSqlException(null, 59, paramObject);
/* 270 */         sQLException2.fillInStackTrace();
/* 271 */         throw sQLException2;
/*     */       } 
/*     */     }
/*     */     
/* 275 */     return nUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Datum[] toNUMBERArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/* 290 */     Datum[] arrayOfDatum = null;
/*     */     
/* 292 */     if (paramObject != null)
/*     */     {
/* 294 */       if (paramObject instanceof Object[] && !(paramObject instanceof char[][])) {
/*     */         
/* 296 */         Object[] arrayOfObject = (Object[])paramObject;
/*     */         
/* 298 */         int i = (int)((paramInt == -1) ? arrayOfObject.length : Math.min(arrayOfObject.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 301 */         arrayOfDatum = new Datum[i];
/*     */         
/* 303 */         for (byte b = 0; b < i; b++) {
/* 304 */           arrayOfDatum[b] = (Datum)toNUMBER(arrayOfObject[(int)paramLong + b - 1], paramOracleConnection);
/*     */         }
/*     */       } else {
/* 307 */         arrayOfDatum = cArrayToNUMBERArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */       }  } 
/* 309 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Datum[] cArrayToNUMBERArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/* 325 */     Datum[] arrayOfDatum = null;
/*     */     
/* 327 */     if (paramObject != null)
/*     */     {
/* 329 */       if (paramObject instanceof short[]) {
/*     */         
/* 331 */         short[] arrayOfShort = (short[])paramObject;
/* 332 */         int i = (int)((paramInt == -1) ? arrayOfShort.length : Math.min(arrayOfShort.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 335 */         arrayOfDatum = new Datum[i];
/*     */         
/* 337 */         for (byte b = 0; b < i; b++) {
/* 338 */           arrayOfDatum[b] = (Datum)new NUMBER(arrayOfShort[(int)paramLong + b - 1]);
/*     */         }
/* 340 */       } else if (paramObject instanceof int[]) {
/*     */         
/* 342 */         int[] arrayOfInt = (int[])paramObject;
/* 343 */         int i = (int)((paramInt == -1) ? arrayOfInt.length : Math.min(arrayOfInt.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 346 */         arrayOfDatum = new Datum[i];
/*     */         
/* 348 */         for (byte b = 0; b < i; b++) {
/* 349 */           arrayOfDatum[b] = (Datum)new NUMBER(arrayOfInt[(int)paramLong + b - 1]);
/*     */         }
/* 351 */       } else if (paramObject instanceof long[]) {
/*     */         
/* 353 */         long[] arrayOfLong = (long[])paramObject;
/* 354 */         int i = (int)((paramInt == -1) ? arrayOfLong.length : Math.min(arrayOfLong.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 357 */         arrayOfDatum = new Datum[i];
/*     */         
/* 359 */         for (byte b = 0; b < i; b++) {
/* 360 */           arrayOfDatum[b] = (Datum)new NUMBER(arrayOfLong[(int)paramLong + b - 1]);
/*     */         }
/* 362 */       } else if (paramObject instanceof float[]) {
/*     */         
/* 364 */         float[] arrayOfFloat = (float[])paramObject;
/* 365 */         int i = (int)((paramInt == -1) ? arrayOfFloat.length : Math.min(arrayOfFloat.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 368 */         arrayOfDatum = new Datum[i];
/*     */         
/* 370 */         for (byte b = 0; b < i; b++) {
/* 371 */           arrayOfDatum[b] = (Datum)new NUMBER(arrayOfFloat[(int)paramLong + b - 1]);
/*     */         }
/* 373 */       } else if (paramObject instanceof double[]) {
/*     */         
/* 375 */         double[] arrayOfDouble = (double[])paramObject;
/* 376 */         int i = (int)((paramInt == -1) ? arrayOfDouble.length : Math.min(arrayOfDouble.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 379 */         arrayOfDatum = new Datum[i];
/*     */         
/* 381 */         for (byte b = 0; b < i; b++) {
/* 382 */           arrayOfDatum[b] = (Datum)new NUMBER(arrayOfDouble[(int)paramLong + b - 1]);
/*     */         }
/* 384 */       } else if (paramObject instanceof boolean[]) {
/*     */         
/* 386 */         boolean[] arrayOfBoolean = (boolean[])paramObject;
/* 387 */         int i = (int)((paramInt == -1) ? arrayOfBoolean.length : Math.min(arrayOfBoolean.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 390 */         arrayOfDatum = new Datum[i];
/*     */         
/* 392 */         for (byte b = 0; b < i; b++) {
/* 393 */           arrayOfDatum[b] = (Datum)new NUMBER(Boolean.valueOf(arrayOfBoolean[(int)paramLong + b - 1]));
/*     */         }
/*     */       }
/* 396 */       else if (paramObject instanceof char[][]) {
/*     */         
/* 398 */         char[][] arrayOfChar = (char[][])paramObject;
/* 399 */         int i = (int)((paramInt == -1) ? arrayOfChar.length : Math.min(arrayOfChar.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 402 */         arrayOfDatum = new Datum[i];
/*     */         
/* 404 */         for (byte b = 0; b < i; b++) {
/* 405 */           arrayOfDatum[b] = (Datum)new NUMBER(new String(arrayOfChar[(int)paramLong + b - 1]));
/*     */         
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 411 */         SQLException sQLException = DatabaseError.createSqlException(null, 59, paramObject);
/* 412 */         sQLException.fillInStackTrace();
/* 413 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */     
/* 417 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision() {
/* 424 */     return this.precision;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale() {
/* 431 */     return this.scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 442 */     paramObjectOutputStream.writeInt(this.scale);
/* 443 */     paramObjectOutputStream.writeInt(this.precision);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 451 */     this.scale = paramObjectInputStream.readInt();
/* 452 */     this.precision = paramObjectInputStream.readInt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 491 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\oracore\OracleTypeNUMBER.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */