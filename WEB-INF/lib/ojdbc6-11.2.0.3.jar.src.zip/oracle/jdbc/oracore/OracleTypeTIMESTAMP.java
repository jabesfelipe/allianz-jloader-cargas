/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeTIMESTAMP
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 3948043338303602796L;
/*  57 */   int precision = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleTypeTIMESTAMP() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleTypeTIMESTAMP(OracleConnection paramOracleConnection) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeCode() {
/*  86 */     return 93;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/*  94 */     this.precision = paramTDSReader.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale() throws SQLException {
/* 101 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision() throws SQLException {
/* 108 */     return this.precision;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 117 */     this.precision = paramObjectInputStream.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 125 */     paramObjectOutputStream.writeByte(this.precision);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 133 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 134 */       return null;
/*     */     }
/* 136 */     switch (paramInt) {
/*     */ 
/*     */       
/*     */       case 1:
/* 140 */         return new TIMESTAMP(paramArrayOfbyte);
/*     */       
/*     */       case 2:
/* 143 */         return TIMESTAMP.toTimestamp(paramArrayOfbyte);
/*     */       
/*     */       case 3:
/* 146 */         return paramArrayOfbyte;
/*     */     } 
/*     */ 
/*     */     
/* 150 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 151 */     sQLException.fillInStackTrace();
/* 152 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/* 170 */     TIMESTAMP tIMESTAMP = null;
/*     */     
/* 172 */     if (paramObject != null) {
/*     */       
/*     */       try {
/*     */         
/* 176 */         if (paramObject instanceof TIMESTAMP) {
/* 177 */           tIMESTAMP = (TIMESTAMP)paramObject;
/* 178 */         } else if (paramObject instanceof byte[]) {
/* 179 */           tIMESTAMP = new TIMESTAMP((byte[])paramObject);
/* 180 */         } else if (paramObject instanceof Timestamp) {
/* 181 */           tIMESTAMP = new TIMESTAMP((Timestamp)paramObject);
/* 182 */         } else if (paramObject instanceof DATE) {
/* 183 */           tIMESTAMP = new TIMESTAMP((DATE)paramObject);
/* 184 */         } else if (paramObject instanceof String) {
/* 185 */           tIMESTAMP = new TIMESTAMP((String)paramObject);
/* 186 */         } else if (paramObject instanceof Date) {
/* 187 */           tIMESTAMP = new TIMESTAMP((Date)paramObject);
/* 188 */         } else if (paramObject instanceof Time) {
/* 189 */           tIMESTAMP = new TIMESTAMP((Time)paramObject);
/*     */         } else {
/*     */           
/* 192 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 193 */           sQLException.fillInStackTrace();
/* 194 */           throw sQLException;
/*     */         }
/*     */       
/* 197 */       } catch (Exception exception) {
/*     */ 
/*     */         
/* 200 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 201 */         sQLException.fillInStackTrace();
/* 202 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 207 */     return (Datum)tIMESTAMP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object unpickle81rec(UnpickleContext paramUnpickleContext, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/* 221 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 222 */     sQLException.fillInStackTrace();
/* 223 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 232 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\oracore\OracleTypeTIMESTAMP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */