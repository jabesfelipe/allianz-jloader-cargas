/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.BINARY_DOUBLE;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeBINARY_DOUBLE
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  48 */     BINARY_DOUBLE bINARY_DOUBLE = null;
/*     */     
/*  50 */     if (paramObject != null)
/*     */     {
/*  52 */       if (paramObject instanceof BINARY_DOUBLE) {
/*  53 */         bINARY_DOUBLE = (BINARY_DOUBLE)paramObject;
/*  54 */       } else if (paramObject instanceof Double) {
/*  55 */         bINARY_DOUBLE = new BINARY_DOUBLE((Double)paramObject);
/*  56 */       } else if (paramObject instanceof byte[]) {
/*  57 */         bINARY_DOUBLE = new BINARY_DOUBLE((byte[])paramObject);
/*     */       } else {
/*     */         
/*  60 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  61 */         sQLException.fillInStackTrace();
/*  62 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */     
/*  66 */     return (Datum)bINARY_DOUBLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/*  82 */     Datum[] arrayOfDatum = null;
/*     */     
/*  84 */     if (paramObject != null)
/*     */     {
/*  86 */       if (paramObject instanceof Object[]) {
/*     */         
/*  88 */         Object[] arrayOfObject = (Object[])paramObject;
/*     */         
/*  90 */         int i = (int)((paramInt == -1) ? arrayOfObject.length : Math.min(arrayOfObject.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/*  93 */         arrayOfDatum = new Datum[i];
/*     */         
/*  95 */         for (byte b = 0; b < i; b++) {
/*     */           
/*  97 */           Object object = arrayOfObject[(int)paramLong + b - 1];
/*     */           
/*  99 */           if (object != null) {
/*     */             
/* 101 */             if (object instanceof Double) {
/* 102 */               arrayOfDatum[b] = (Datum)new BINARY_DOUBLE(((Double)object).doubleValue());
/*     */             }
/* 104 */             else if (object instanceof BINARY_DOUBLE) {
/* 105 */               arrayOfDatum[b] = (Datum)object;
/*     */             } else {
/*     */               
/* 108 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 109 */               sQLException.fillInStackTrace();
/* 110 */               throw sQLException;
/*     */             }
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 116 */             arrayOfDatum[b] = null;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 122 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeCode() {
/* 132 */     return 101;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 157 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 158 */       return null;
/*     */     }
/* 160 */     if (paramInt == 1)
/* 161 */       return new BINARY_DOUBLE(paramArrayOfbyte); 
/* 162 */     if (paramInt == 2)
/* 163 */       return (new BINARY_DOUBLE(paramArrayOfbyte)).toJdbc(); 
/* 164 */     if (paramInt == 3) {
/* 165 */       return paramArrayOfbyte;
/*     */     }
/*     */     
/* 168 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
/* 169 */     sQLException.fillInStackTrace();
/* 170 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 175 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\oracore\OracleTypeBINARY_DOUBLE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */