/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeDATE
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = -5858803341118747965L;
/*     */   
/*     */   public OracleTypeDATE() {}
/*     */   
/*     */   public OracleTypeDATE(int paramInt) {
/*  41 */     super(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  56 */     DATE dATE = null;
/*     */     
/*  58 */     if (paramObject != null) {
/*     */       
/*     */       try {
/*     */         
/*  62 */         if (paramObject instanceof DATE) {
/*  63 */           dATE = (DATE)paramObject;
/*  64 */         } else if (paramObject instanceof TIMESTAMP) {
/*  65 */           dATE = new DATE(((TIMESTAMP)paramObject).timestampValue());
/*     */         } else {
/*  67 */           dATE = new DATE(paramObject);
/*     */         } 
/*  69 */       } catch (SQLException sQLException1) {
/*     */ 
/*     */         
/*  72 */         SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  73 */         sQLException2.fillInStackTrace();
/*  74 */         throw sQLException2;
/*     */       } 
/*     */     }
/*     */     
/*  78 */     return (Datum)dATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/*  92 */     Datum[] arrayOfDatum = null;
/*     */     
/*  94 */     if (paramObject != null)
/*     */     {
/*  96 */       if (paramObject instanceof char[][]) {
/*     */         
/*  98 */         char[][] arrayOfChar = (char[][])paramObject;
/*  99 */         int i = (int)((paramInt == -1) ? arrayOfChar.length : Math.min(arrayOfChar.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 102 */         arrayOfDatum = new Datum[i];
/*     */         
/* 104 */         for (byte b = 0; b < i; b++) {
/* 105 */           arrayOfDatum[b] = toDatum(new String(arrayOfChar[(int)paramLong + b - 1]), paramOracleConnection);
/*     */         }
/*     */       } else {
/* 108 */         if (paramObject instanceof Object[])
/*     */         {
/* 110 */           return super.toDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */         }
/*     */ 
/*     */         
/* 114 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 115 */         sQLException.fillInStackTrace();
/* 116 */         throw sQLException;
/*     */       } 
/*     */     }
/* 119 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeCode() {
/* 129 */     return 91;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 152 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 153 */       return null;
/*     */     }
/* 155 */     if (paramInt == 1)
/* 156 */       return new DATE(paramArrayOfbyte); 
/* 157 */     if (paramInt == 2)
/* 158 */       return DATE.toTimestamp(paramArrayOfbyte); 
/* 159 */     if (paramInt == 3) {
/* 160 */       return paramArrayOfbyte;
/*     */     }
/*     */     
/* 163 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
/* 164 */     sQLException.fillInStackTrace();
/* 165 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\oracore\OracleTypeDATE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */