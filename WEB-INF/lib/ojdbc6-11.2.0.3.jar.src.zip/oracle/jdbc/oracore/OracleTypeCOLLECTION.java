/*      */ package oracle.jdbc.oracore;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Serializable;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleCallableStatement;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.ArrayDescriptor;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleTypeCOLLECTION
/*      */   extends OracleTypeADT
/*      */   implements Serializable
/*      */ {
/*      */   static final long serialVersionUID = -7279638692691669378L;
/*      */   public static final int TYPE_PLSQL_INDEX_TABLE = 1;
/*      */   public static final int TYPE_NESTED_TABLE = 2;
/*      */   public static final int TYPE_VARRAY = 3;
/*   59 */   int userCode = 0;
/*   60 */   long maxSize = 0L;
/*   61 */   OracleType elementType = null;
/*      */   static final int CURRENT_USER_OBJECT = 0;
/*      */   static final int CURRENT_USER_SYNONYM = 1;
/*      */   static final int CURRENT_USER_SYNONYM_10g = 2;
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT = 5;
/*      */   
/*      */   public OracleTypeCOLLECTION(String paramString, OracleConnection paramOracleConnection) throws SQLException {
/*   70 */     super(paramString, (Connection)paramOracleConnection);
/*      */   }
/*      */   
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
/*      */   static final int OTHER_USER_OBJECT = 7;
/*      */   static final int OTHER_USER_SYNONYM = 8;
/*      */   
/*      */   public OracleTypeCOLLECTION(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) throws SQLException {
/*   78 */     super(paramOracleTypeADT, paramInt, (Connection)paramOracleConnection);
/*      */   }
/*      */ 
/*      */   
/*      */   static final int PUBLIC_SYNONYM = 9;
/*      */   
/*      */   static final int PUBLIC_SYNONYM_10g = 10;
/*      */   
/*      */   static final int BREAK = 11;
/*      */   
/*      */   public OracleTypeCOLLECTION(SQLName paramSQLName, byte[] paramArrayOfbyte1, int paramInt, byte[] paramArrayOfbyte2, OracleConnection paramOracleConnection) throws SQLException {
/*   89 */     super(paramSQLName, paramArrayOfbyte1, paramInt, paramArrayOfbyte2, paramOracleConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  105 */     if (paramObject != null) {
/*      */       
/*  107 */       if (paramObject instanceof ARRAY) {
/*  108 */         return (Datum)paramObject;
/*      */       }
/*      */       
/*  111 */       ArrayDescriptor arrayDescriptor = createArrayDescriptor();
/*      */       
/*  113 */       return (Datum)new ARRAY(arrayDescriptor, (Connection)this.connection, paramObject);
/*      */     } 
/*      */ 
/*      */     
/*  117 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTypeCode() {
/*  129 */     return 2003;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInHierarchyOf(OracleType paramOracleType) throws SQLException {
/*  140 */     if (paramOracleType == null) {
/*  141 */       return false;
/*      */     }
/*  143 */     if (paramOracleType == this) {
/*  144 */       return true;
/*      */     }
/*  146 */     if (paramOracleType.getClass() != getClass()) {
/*  147 */       return false;
/*      */     }
/*  149 */     return paramOracleType.getTypeDescriptor().getName().equals(this.descriptor.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInHierarchyOf(StructDescriptor paramStructDescriptor) throws SQLException {
/*  158 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isObjectType() {
/*  165 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/*  179 */     long l = paramTDSReader.readLong();
/*      */ 
/*      */ 
/*      */     
/*  183 */     this.maxSize = paramTDSReader.readLong();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  189 */     this.userCode = paramTDSReader.readByte();
/*      */ 
/*      */     
/*  192 */     paramTDSReader.addSimplePatch(l, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
/*  204 */     return unlinearize(paramArrayOfbyte, paramLong, paramDatum, 1L, -1, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*  213 */     OracleConnection oracleConnection = getConnection();
/*  214 */     Datum datum = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  219 */     if (oracleConnection == null) {
/*      */       
/*  221 */       datum = unlinearizeInternal(paramArrayOfbyte, paramLong1, paramDatum, paramLong2, paramInt1, paramInt2, paramMap);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  226 */       synchronized (oracleConnection) {
/*      */         
/*  228 */         datum = unlinearizeInternal(paramArrayOfbyte, paramLong1, paramDatum, paramLong2, paramInt1, paramInt2, paramMap);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  233 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Datum unlinearizeInternal(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*  245 */     if (paramArrayOfbyte == null) {
/*  246 */       return null;
/*      */     }
/*      */     
/*  249 */     PickleContext pickleContext = new PickleContext(paramArrayOfbyte, paramLong1);
/*      */     
/*  251 */     return (Datum)unpickle81(pickleContext, (ARRAY)paramDatum, paramLong2, paramInt1, 1, paramInt2, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isInlineImage(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
/*  262 */     if (paramArrayOfbyte == null) {
/*  263 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  267 */     if (PickleContext.isCollectionImage_pctx(paramArrayOfbyte[paramInt]))
/*  268 */       return true; 
/*  269 */     if (PickleContext.isDegenerateImage_pctx(paramArrayOfbyte[paramInt])) {
/*  270 */       return false;
/*      */     }
/*      */     
/*  273 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
/*  274 */     sQLException.fillInStackTrace();
/*  275 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException {
/*  289 */     ARRAY aRRAY = (ARRAY)paramDatum;
/*      */     
/*  291 */     boolean bool = aRRAY.hasDataSeg();
/*  292 */     int i = 0;
/*  293 */     int j = paramPickleContext.offset() + 2;
/*      */     
/*  295 */     if (bool) {
/*      */       
/*  297 */       if (!this.metaDataInitialized) {
/*  298 */         copy_properties((OracleTypeCOLLECTION)aRRAY.getDescriptor().getPickler());
/*      */       }
/*  300 */       Datum[] arrayOfDatum = aRRAY.getOracleArray();
/*      */ 
/*      */       
/*  303 */       if (this.userCode == 3)
/*      */       {
/*  305 */         if (arrayOfDatum.length > this.maxSize) {
/*      */           
/*  307 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 71, null);
/*  308 */           sQLException.fillInStackTrace();
/*  309 */           throw sQLException;
/*      */         } 
/*      */       }
/*      */       
/*  313 */       i += paramPickleContext.writeCollImageHeader(arrayOfDatum.length, this.typeVersion);
/*      */       
/*  315 */       for (byte b = 0; b < arrayOfDatum.length; b++)
/*      */       {
/*  317 */         if (arrayOfDatum[b] == null) {
/*  318 */           i += paramPickleContext.writeElementNull();
/*      */         } else {
/*  320 */           i += this.elementType.pickle81(paramPickleContext, arrayOfDatum[b]);
/*      */         } 
/*  322 */         String str = "idx=" + b + " is " + arrayOfDatum[b];
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  328 */       i += paramPickleContext.writeCollImageHeader(aRRAY.getLocator());
/*      */     } 
/*      */     
/*  331 */     paramPickleContext.patchImageLen(j, i);
/*      */     
/*  333 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ARRAY unpickle81(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*  344 */     return unpickle81(paramPickleContext, paramARRAY, 1L, -1, paramInt1, paramInt2, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ARRAY unpickle81(PickleContext paramPickleContext, ARRAY paramARRAY, long paramLong, int paramInt1, int paramInt2, int paramInt3, Map paramMap) throws SQLException {
/*  358 */     ARRAY aRRAY = paramARRAY;
/*      */     
/*  360 */     if (aRRAY == null) {
/*      */       
/*  362 */       ArrayDescriptor arrayDescriptor = createArrayDescriptor();
/*      */       
/*  364 */       aRRAY = new ARRAY(arrayDescriptor, (byte[])null, (Connection)this.connection);
/*      */     } 
/*      */     
/*  367 */     if (unpickle81ImgHeader(paramPickleContext, aRRAY, paramInt2, paramInt3))
/*      */     {
/*  369 */       if (paramLong == 1L && paramInt1 == -1) {
/*  370 */         unpickle81ImgBody(paramPickleContext, aRRAY, paramInt3, paramMap);
/*      */       } else {
/*  372 */         unpickle81ImgBody(paramPickleContext, aRRAY, paramLong, paramInt1, paramInt3, paramMap);
/*      */       } 
/*      */     }
/*      */     
/*  376 */     return aRRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean unpickle81ImgHeader(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2) throws SQLException {
/*  384 */     boolean bool = true;
/*      */     
/*  386 */     if (paramInt1 == 3)
/*      */     {
/*  388 */       paramARRAY.setImage(paramPickleContext.image(), paramPickleContext.absoluteOffset(), 0L);
/*      */     }
/*      */     
/*  391 */     byte b = paramPickleContext.readByte();
/*      */     
/*  393 */     if (!PickleContext.is81format(b)) {
/*      */       
/*  395 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format");
/*  396 */       sQLException.fillInStackTrace();
/*  397 */       throw sQLException;
/*      */     } 
/*      */     
/*  400 */     if (!PickleContext.hasPrefix(b)) {
/*      */       
/*  402 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image has no prefix segment");
/*  403 */       sQLException.fillInStackTrace();
/*  404 */       throw sQLException;
/*      */     } 
/*      */     
/*  407 */     if (PickleContext.isCollectionImage_pctx(b)) {
/*  408 */       bool = true;
/*  409 */     } else if (PickleContext.isDegenerateImage_pctx(b)) {
/*  410 */       bool = false;
/*      */     } else {
/*      */       
/*  413 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
/*  414 */       sQLException.fillInStackTrace();
/*  415 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  419 */     paramPickleContext.readByte();
/*      */ 
/*      */     
/*  422 */     if (paramInt1 == 9) {
/*      */       
/*  424 */       paramPickleContext.skipBytes(paramPickleContext.readLength(true) - 2);
/*      */       
/*  426 */       return false;
/*      */     } 
/*  428 */     if (paramInt1 == 3) {
/*      */       
/*  430 */       long l = paramPickleContext.readLength();
/*      */       
/*  432 */       paramARRAY.setImageLength(l);
/*  433 */       paramPickleContext.skipTo(paramARRAY.getImageOffset() + l);
/*      */       
/*  435 */       return false;
/*      */     } 
/*      */     
/*  438 */     paramPickleContext.skipLength();
/*      */ 
/*      */     
/*  441 */     int i = paramPickleContext.readLength();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  446 */     paramARRAY.setPrefixFlag(paramPickleContext.readByte());
/*      */     
/*  448 */     if (paramARRAY.isInline()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  455 */       paramPickleContext.readDataValue(i - 1);
/*      */     }
/*      */     else {
/*      */       
/*  459 */       paramARRAY.setLocator(paramPickleContext.readDataValue(i - 1));
/*      */     } 
/*      */     
/*  462 */     return paramARRAY.isInline();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unpickle81ImgBody(PickleContext paramPickleContext, ARRAY paramARRAY, long paramLong, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*  474 */     paramPickleContext.readByte();
/*      */ 
/*      */     
/*  477 */     int i = paramPickleContext.readLength();
/*      */     
/*  479 */     paramARRAY.setLength(i);
/*      */     
/*  481 */     if (paramInt2 == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  486 */     int j = (int)getAccessLength(i, paramLong, paramInt1);
/*  487 */     boolean bool = (ArrayDescriptor.getCacheStyle(paramARRAY) == 1) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  492 */     if (paramLong > 1L && j > 0) {
/*      */       
/*  494 */       long l = paramARRAY.getLastIndex();
/*      */       
/*  496 */       if (l < paramLong) {
/*      */         
/*  498 */         if (l > 0L) {
/*  499 */           paramPickleContext.skipTo(paramARRAY.getLastOffset());
/*      */         } else {
/*  501 */           l = 1L;
/*      */         } 
/*  503 */         if (bool) {
/*      */           long l1;
/*  505 */           for (l1 = l; l1 < paramLong; l1++) {
/*      */             
/*  507 */             paramARRAY.setIndexOffset(l1, paramPickleContext.offset());
/*  508 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           } 
/*      */         } else {
/*      */           long l1;
/*      */           
/*  513 */           for (l1 = l; l1 < paramLong; l1++) {
/*  514 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           }
/*      */         } 
/*  517 */       } else if (l > paramLong) {
/*      */         
/*  519 */         long l1 = paramARRAY.getOffset(paramLong);
/*      */         
/*  521 */         if (l1 != -1L) {
/*      */           
/*  523 */           paramPickleContext.skipTo(l1);
/*      */ 
/*      */         
/*      */         }
/*  527 */         else if (bool) {
/*      */           
/*  529 */           for (byte b = 1; b < paramLong; b++)
/*      */           {
/*  531 */             paramARRAY.setIndexOffset(b, paramPickleContext.offset());
/*  532 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  537 */           for (byte b = 1; b < paramLong; b++) {
/*  538 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         
/*  543 */         paramPickleContext.skipTo(paramARRAY.getLastOffset());
/*      */       } 
/*  545 */       paramARRAY.setLastIndexOffset(paramLong, paramPickleContext.offset());
/*      */     } 
/*      */ 
/*      */     
/*  549 */     unpickle81ImgBodyElements(paramPickleContext, paramARRAY, (int)paramLong, j, paramInt2, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unpickle81ImgBody(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt, Map paramMap) throws SQLException {
/*  561 */     paramPickleContext.readByte();
/*      */ 
/*      */     
/*  564 */     int i = paramPickleContext.readLength();
/*      */     
/*  566 */     paramARRAY.setLength(i);
/*      */     
/*  568 */     if (paramInt == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  573 */     unpickle81ImgBodyElements(paramPickleContext, paramARRAY, 1, i, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unpickle81ImgBodyElements(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2, int paramInt3, Map paramMap) throws SQLException {
/*      */     Datum[] arrayOfDatum;
/*      */     Object[] arrayOfObject;
/*      */     SQLException sQLException;
/*  584 */     boolean bool = (ArrayDescriptor.getCacheStyle(paramARRAY) == 1) ? true : false;
/*      */ 
/*      */ 
/*      */     
/*  588 */     switch (paramInt3) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  593 */         arrayOfDatum = new Datum[paramInt2];
/*      */         
/*  595 */         if (bool) {
/*      */           
/*  597 */           for (byte b = 0; b < paramInt2; b++)
/*      */           {
/*  599 */             paramARRAY.setIndexOffset((paramInt1 + b), paramPickleContext.offset());
/*      */             
/*  601 */             arrayOfDatum[b] = (Datum)this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  607 */           for (byte b = 0; b < paramInt2; b++) {
/*  608 */             arrayOfDatum[b] = (Datum)this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */           }
/*      */         } 
/*      */         
/*  612 */         paramARRAY.setDatumArray(arrayOfDatum);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  619 */         arrayOfObject = ArrayDescriptor.makeJavaArray(paramInt2, this.elementType.getTypeCode());
/*      */ 
/*      */         
/*  622 */         if (bool) {
/*      */           
/*  624 */           for (byte b = 0; b < paramInt2; b++)
/*      */           {
/*  626 */             paramARRAY.setIndexOffset((paramInt1 + b), paramPickleContext.offset());
/*      */             
/*  628 */             arrayOfObject[b] = this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  633 */           for (byte b = 0; b < paramInt2; b++) {
/*  634 */             arrayOfObject[b] = this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */           }
/*      */         } 
/*  637 */         paramARRAY.setObjArray(arrayOfObject);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  652 */         if (this.elementType instanceof OracleTypeNUMBER || this.elementType instanceof OracleTypeFLOAT) {
/*      */ 
/*      */           
/*  655 */           paramARRAY.setObjArray(OracleTypeNUMBER.unpickle81NativeArray(paramPickleContext, 1L, paramInt2, paramInt3));
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  660 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "This feature is limited to numeric collection");
/*  661 */         sQLException.fillInStackTrace();
/*  662 */         throw sQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  670 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "Invalid conversion type " + this.elementType);
/*  671 */         sQLException.fillInStackTrace();
/*  672 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  677 */     paramARRAY.setLastIndexOffset((paramInt1 + paramInt2), paramPickleContext.offset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  700 */   static final String[] sqlString = new String[] { "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME = :1", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = :1 AND TYPE_NAME = :2", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ", "DECLARE /*+RULE*/  the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", "DECLARE /*+RULE*/  the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initCollElemTypeName() throws SQLException {
/*  806 */     if (this.connection == null)
/*      */       return; 
/*  808 */     synchronized (this.connection) {
/*  809 */       if (this.sqlName == null) {
/*  810 */         getFullName();
/*      */       }
/*  812 */       CallableStatement callableStatement = null;
/*  813 */       PreparedStatement preparedStatement = null;
/*  814 */       ResultSet resultSet = null;
/*      */       try {
/*  816 */         byte b = this.sqlName.getSchema().equalsIgnoreCase(this.connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7;
/*      */ 
/*      */         
/*  819 */         while (b != 11) {
/*      */           
/*  821 */           switch (b) {
/*      */ 
/*      */             
/*      */             case false:
/*  825 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  826 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  827 */               preparedStatement.setFetchSize(1);
/*  828 */               resultSet = preparedStatement.executeQuery();
/*  829 */               b = 1;
/*      */               break;
/*      */             
/*      */             case true:
/*  833 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/*  835 */                 b = 2;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/*  840 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  841 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  842 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  843 */               preparedStatement.setFetchSize(1);
/*  844 */               resultSet = preparedStatement.executeQuery();
/*  845 */               b = 3;
/*      */               break;
/*      */             
/*      */             case true:
/*  849 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/*  851 */                 b = 4;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/*  856 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  857 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  858 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  859 */               preparedStatement.setFetchSize(1);
/*  860 */               resultSet = preparedStatement.executeQuery();
/*  861 */               b = 5;
/*      */               break;
/*      */             
/*      */             case true:
/*  865 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/*  867 */                 b = 6;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/*  872 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  873 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  874 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  875 */               preparedStatement.setFetchSize(1);
/*  876 */               resultSet = preparedStatement.executeQuery();
/*  877 */               b = 8;
/*      */               break;
/*      */ 
/*      */             
/*      */             case true:
/*  882 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  883 */               preparedStatement.setString(1, this.sqlName.getSchema());
/*  884 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  885 */               preparedStatement.setFetchSize(1);
/*  886 */               resultSet = preparedStatement.executeQuery();
/*  887 */               b = 8;
/*      */               break;
/*      */ 
/*      */             
/*      */             case true:
/*  892 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  893 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  894 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  895 */               preparedStatement.setFetchSize(1);
/*  896 */               resultSet = preparedStatement.executeQuery();
/*  897 */               b = 9;
/*      */               break;
/*      */             
/*      */             case true:
/*  901 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/*  903 */                 b = 10;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/*  908 */               callableStatement = this.connection.prepareCall(getSqlHint() + sqlString[b]);
/*  909 */               callableStatement.setString(1, this.sqlName.getSimpleName());
/*  910 */               callableStatement.registerOutParameter(2, -10);
/*  911 */               callableStatement.execute();
/*  912 */               resultSet = ((OracleCallableStatement)callableStatement).getCursor(2);
/*  913 */               b = 11;
/*      */               break;
/*      */           } 
/*      */           
/*  917 */           if (resultSet.next()) {
/*      */             
/*  919 */             if (this.attrTypeNames == null) {
/*  920 */               this.attrTypeNames = new String[1];
/*      */             }
/*  922 */             this.attrTypeNames[0] = resultSet.getString(2) + "." + resultSet.getString(1);
/*  923 */             b = 11; continue;
/*  924 */           }  if (b == 11) {
/*      */             
/*  926 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*  927 */             sQLException.fillInStackTrace();
/*  928 */             throw sQLException;
/*      */           } 
/*      */         } 
/*  931 */         while (b != 11);
/*      */       } finally {
/*      */         
/*  934 */         if (resultSet != null)
/*  935 */           resultSet.close(); 
/*  936 */         if (preparedStatement != null)
/*  937 */           preparedStatement.close(); 
/*  938 */         if (callableStatement != null) {
/*  939 */           callableStatement.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeName(int paramInt) throws SQLException {
/*  949 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*  950 */     sQLException.fillInStackTrace();
/*  951 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeName(int paramInt, boolean paramBoolean) throws SQLException {
/*  959 */     return getAttributeName(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeType(int paramInt) throws SQLException {
/*  972 */     if (paramInt != 1) {
/*      */       
/*  974 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  975 */       sQLException.fillInStackTrace();
/*  976 */       throw sQLException;
/*      */     } 
/*      */     
/*  979 */     if (this.sqlName == null) {
/*  980 */       getFullName();
/*      */     }
/*  982 */     if (this.attrTypeNames == null) {
/*  983 */       initCollElemTypeName();
/*      */     }
/*  985 */     return this.attrTypeNames[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeType(int paramInt, boolean paramBoolean) throws SQLException {
/*  992 */     if (paramBoolean) {
/*  993 */       return getAttributeType(paramInt);
/*      */     }
/*      */     
/*  996 */     if (paramInt != 1) {
/*      */       
/*  998 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  999 */       sQLException.fillInStackTrace();
/* 1000 */       throw sQLException;
/*      */     } 
/*      */     
/* 1003 */     if (this.sqlName != null && this.attrTypeNames != null) {
/* 1004 */       return this.attrTypeNames[0];
/*      */     }
/* 1006 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumAttrs() throws SQLException {
/* 1014 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleType getAttrTypeAt(int paramInt) throws SQLException {
/* 1021 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayDescriptor createArrayDescriptor() throws SQLException {
/* 1028 */     return new ArrayDescriptor(this, (Connection)this.connection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayDescriptor createArrayDescriptorWithItsOwnTree() throws SQLException {
/* 1035 */     if (this.descriptor == null)
/*      */     {
/* 1037 */       if (this.sqlName == null && getFullName(false) == null) {
/*      */         
/* 1039 */         this.descriptor = (TypeDescriptor)new ArrayDescriptor(this, (Connection)this.connection);
/*      */       }
/*      */       else {
/*      */         
/* 1043 */         this.descriptor = (TypeDescriptor)ArrayDescriptor.createDescriptor(this.sqlName, (Connection)this.connection);
/*      */       } 
/*      */     }
/*      */     
/* 1047 */     return (ArrayDescriptor)this.descriptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleType getElementType() throws SQLException {
/* 1054 */     return this.elementType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUserCode() throws SQLException {
/* 1061 */     return this.userCode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getMaxLength() throws SQLException {
/* 1068 */     return this.maxSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long getAccessLength(long paramLong1, long paramLong2, int paramInt) throws SQLException {
/* 1076 */     if (paramLong2 > paramLong1) {
/* 1077 */       return 0L;
/*      */     }
/* 1079 */     if (paramInt < 0)
/*      */     {
/* 1081 */       return paramLong1 - paramLong2 + 1L;
/*      */     }
/*      */ 
/*      */     
/* 1085 */     return Math.min(paramLong1 - paramLong2 + 1L, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 1097 */     paramObjectOutputStream.writeInt(this.userCode);
/* 1098 */     paramObjectOutputStream.writeLong(this.maxSize);
/* 1099 */     paramObjectOutputStream.writeObject(this.elementType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 1107 */     this.userCode = paramObjectInputStream.readInt();
/* 1108 */     this.maxSize = paramObjectInputStream.readLong();
/* 1109 */     this.elementType = (OracleType)paramObjectInputStream.readObject();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 1116 */     this.connection = paramOracleConnection;
/*      */     
/* 1118 */     this.elementType.setConnection(paramOracleConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initMetadataRecursively() throws SQLException {
/* 1125 */     initMetadata(this.connection);
/* 1126 */     if (this.elementType != null) this.elementType.initMetadataRecursively();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void initChildNamesRecursively(Map paramMap) throws SQLException {
/* 1133 */     TypeTreeElement typeTreeElement = (TypeTreeElement)paramMap.get(this.sqlName);
/*      */     
/* 1135 */     if (this.elementType != null) {
/*      */       
/* 1137 */       this.elementType.setNames(typeTreeElement.getChildSchemaName(0), typeTreeElement.getChildTypeName(0));
/* 1138 */       this.elementType.initChildNamesRecursively(paramMap);
/* 1139 */       this.elementType.cacheDescriptor();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cacheDescriptor() throws SQLException {
/* 1147 */     this.descriptor = (TypeDescriptor)ArrayDescriptor.createDescriptor(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt) throws SQLException {
/* 1154 */     printXML(paramPrintWriter, paramInt, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean) throws SQLException {
/*      */     byte b;
/* 1161 */     for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
/* 1162 */      paramPrintWriter.println("<OracleTypeCOLLECTION sqlName=\"" + this.sqlName + "\" " + ">");
/*      */ 
/*      */     
/* 1165 */     if (this.elementType != null)
/* 1166 */       this.elementType.printXML(paramPrintWriter, paramInt + 1, paramBoolean); 
/* 1167 */     for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
/* 1168 */      paramPrintWriter.println("</OracleTypeCOLLECTION>");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1173 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\oracore\OracleTypeCOLLECTION.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */