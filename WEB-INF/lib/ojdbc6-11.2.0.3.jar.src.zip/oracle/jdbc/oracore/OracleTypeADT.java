/*      */ package oracle.jdbc.oracore;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringWriter;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.OracleCallableStatement;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.AttributeDescriptor;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.JAVA_STRUCT;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleTypeADT
/*      */   extends OracleNamedType
/*      */   implements Serializable
/*      */ {
/*      */   static final long serialVersionUID = 3031304012507165702L;
/*      */   static final int S_TOP = 1;
/*      */   static final int S_EMBEDDED = 2;
/*      */   static final int S_UPT_ADT = 4;
/*      */   static final int S_JAVA_OBJECT = 16;
/*      */   static final int S_FINAL_TYPE = 32;
/*      */   static final int S_SUB_TYPE = 64;
/*      */   static final int S_ATTR_TDS = 128;
/*      */   static final int S_HAS_METADATA = 256;
/*      */   static final int S_TDS_PARSED = 512;
/*   61 */   private int statusBits = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   68 */   int tdsVersion = -9999;
/*      */   
/*      */   static final int KOPT_V80 = 1;
/*      */   
/*      */   static final int KOPT_V81 = 2;
/*      */   
/*      */   static final int KOPT_VNFT = 3;
/*      */   
/*      */   static final int KOPT_VERSION = 3;
/*      */   
/*      */   boolean endOfAdt = false;
/*      */   
/*   80 */   int typeVersion = 1;
/*      */ 
/*      */   
/*   83 */   long fixedDataSize = -1L;
/*   84 */   int alignmentRequirement = -1;
/*      */ 
/*      */   
/*   87 */   OracleType[] attrTypes = null;
/*      */   
/*      */   String[] attrNames;
/*      */   String[] attrTypeNames;
/*   91 */   public long tdoCState = 0L;
/*      */   
/*   93 */   byte[] toid = null;
/*      */   
/*      */   int charSetId;
/*      */   
/*      */   int charSetForm;
/*      */   
/*      */   int flattenedAttrNum;
/*      */   
/*      */   transient int opcode;
/*  102 */   transient int idx = 1;
/*      */   
/*      */   boolean isTransient = false;
/*      */   
/*      */   static final int CURRENT_USER_OBJECT = 0;
/*      */   
/*      */   static final int CURRENT_USER_SYNONYM = 1;
/*      */   
/*      */   static final int CURRENT_USER_SYNONYM_10g = 2;
/*      */   
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
/*      */   
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
/*      */   
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT = 5;
/*      */   
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
/*      */   
/*      */   static final int OTHER_USER_OBJECT = 7;
/*      */   static final int OTHER_USER_SYNONYM = 8;
/*      */   static final int PUBLIC_SYNONYM = 9;
/*      */   static final int PUBLIC_SYNONYM_10g = 10;
/*      */   static final int BREAK = 11;
/*      */   
/*      */   protected OracleTypeADT() {}
/*      */   
/*      */   public OracleTypeADT(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, short paramShort, String paramString) throws SQLException {
/*  129 */     this(paramString, (Connection)null);
/*      */     
/*  131 */     this.toid = paramArrayOfbyte;
/*  132 */     this.typeVersion = paramInt1;
/*  133 */     this.charSetId = paramInt2;
/*  134 */     this.charSetForm = paramShort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleTypeADT(String paramString, Connection paramConnection) throws SQLException {
/*  143 */     super(paramString, (OracleConnection)paramConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleTypeADT(OracleTypeADT paramOracleTypeADT, int paramInt, Connection paramConnection) throws SQLException {
/*  154 */     super(paramOracleTypeADT, paramInt, (OracleConnection)paramConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleTypeADT(SQLName paramSQLName, byte[] paramArrayOfbyte1, int paramInt, byte[] paramArrayOfbyte2, OracleConnection paramOracleConnection) throws SQLException {
/*  168 */     this.sqlName = paramSQLName;
/*  169 */     init(paramArrayOfbyte2, paramOracleConnection);
/*  170 */     this.toid = paramArrayOfbyte1;
/*  171 */     this.typeVersion = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleTypeADT(AttributeDescriptor[] paramArrayOfAttributeDescriptor, OracleConnection paramOracleConnection) throws SQLException {
/*  191 */     setConnectionInternal(paramOracleConnection);
/*  192 */     this.isTransient = true;
/*  193 */     this.flattenedAttrNum = paramArrayOfAttributeDescriptor.length;
/*  194 */     this.attrTypes = new OracleType[this.flattenedAttrNum];
/*  195 */     this.attrNames = new String[this.flattenedAttrNum]; byte b;
/*  196 */     for (b = 0; b < this.flattenedAttrNum; b++)
/*  197 */       this.attrNames[b] = paramArrayOfAttributeDescriptor[b].getAttributeName(); 
/*  198 */     this.statusBits |= 0x100;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  204 */     for (b = 0; b < this.flattenedAttrNum; b++) {
/*      */       SQLException sQLException;
/*  206 */       TypeDescriptor typeDescriptor = paramArrayOfAttributeDescriptor[b].getTypeDescriptor();
/*  207 */       switch (typeDescriptor.getInternalTypeCode()) {
/*      */         
/*      */         case 12:
/*  210 */           this.attrTypes[b] = new OracleTypeDATE();
/*      */           break;
/*      */         case 9:
/*  213 */           this.attrTypes[b] = new OracleTypeCHAR(this.connection, 12);
/*  214 */           ((OracleTypeCHAR)this.attrTypes[b]).length = (int)typeDescriptor.getPrecision();
/*  215 */           ((OracleTypeCHAR)this.attrTypes[b]).form = 1;
/*      */           break;
/*      */         case 96:
/*  218 */           this.attrTypes[b] = new OracleTypeCHAR(this.connection, 1);
/*  219 */           ((OracleTypeCHAR)this.attrTypes[b]).length = (int)typeDescriptor.getPrecision();
/*  220 */           ((OracleTypeCHAR)this.attrTypes[b]).form = 1;
/*      */           break;
/*      */         case 108:
/*  223 */           this.attrTypes[b] = typeDescriptor.getPickler();
/*  224 */           ((OracleTypeADT)this.attrTypes[b]).setEmbeddedADT();
/*      */           break;
/*      */         case 2:
/*  227 */           this.attrTypes[b] = new OracleTypeNUMBER(2);
/*  228 */           ((OracleTypeNUMBER)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*  229 */           ((OracleTypeNUMBER)this.attrTypes[b]).scale = typeDescriptor.getScale();
/*      */           break;
/*      */         case 7:
/*  232 */           this.attrTypes[b] = new OracleTypeNUMBER(3);
/*  233 */           ((OracleTypeNUMBER)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*  234 */           ((OracleTypeNUMBER)this.attrTypes[b]).scale = typeDescriptor.getScale();
/*      */           break;
/*      */         case 22:
/*  237 */           this.attrTypes[b] = new OracleTypeNUMBER(8);
/*  238 */           ((OracleTypeNUMBER)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*  239 */           ((OracleTypeNUMBER)this.attrTypes[b]).scale = typeDescriptor.getScale();
/*      */           break;
/*      */         case 4:
/*  242 */           this.attrTypes[b] = new OracleTypeFLOAT();
/*  243 */           ((OracleTypeFLOAT)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*      */           break;
/*      */         case 100:
/*  246 */           this.attrTypes[b] = new OracleTypeBINARY_FLOAT();
/*      */           break;
/*      */         case 101:
/*  249 */           this.attrTypes[b] = new OracleTypeBINARY_DOUBLE();
/*      */           break;
/*      */         
/*      */         case 29:
/*  253 */           this.attrTypes[b] = new OracleTypeSINT32();
/*      */           break;
/*      */         
/*      */         case 110:
/*  257 */           this.attrTypes[b] = new OracleTypeREF(this, b, this.connection);
/*      */           break;
/*      */         case 114:
/*  260 */           this.attrTypes[b] = new OracleTypeBFILE(this.connection);
/*      */           break;
/*      */         case 95:
/*  263 */           this.attrTypes[b] = new OracleTypeRAW();
/*      */           break;
/*      */         case 112:
/*  266 */           this.attrTypes[b] = new OracleTypeCLOB(this.connection);
/*      */           break;
/*      */         case 113:
/*  269 */           this.attrTypes[b] = new OracleTypeBLOB(this.connection);
/*      */           break;
/*      */         case 187:
/*  272 */           this.attrTypes[b] = new OracleTypeTIMESTAMP(this.connection);
/*  273 */           ((OracleTypeTIMESTAMP)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*      */           break;
/*      */         case 188:
/*  276 */           this.attrTypes[b] = new OracleTypeTIMESTAMPTZ(this.connection);
/*  277 */           ((OracleTypeTIMESTAMPTZ)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*      */           break;
/*      */         case 232:
/*  280 */           this.attrTypes[b] = new OracleTypeTIMESTAMPLTZ(this.connection);
/*  281 */           ((OracleTypeTIMESTAMPLTZ)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*      */           break;
/*      */         case 189:
/*  284 */           this.attrTypes[b] = new OracleTypeINTERVAL(this.connection);
/*  285 */           ((OracleTypeINTERVAL)this.attrTypes[b]).typeId = 7;
/*  286 */           ((OracleTypeINTERVAL)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*  287 */           ((OracleTypeINTERVAL)this.attrTypes[b]).scale = typeDescriptor.getScale();
/*      */           break;
/*      */         case 190:
/*  290 */           this.attrTypes[b] = new OracleTypeINTERVAL(this.connection);
/*  291 */           ((OracleTypeINTERVAL)this.attrTypes[b]).typeId = 10;
/*  292 */           ((OracleTypeINTERVAL)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
/*  293 */           ((OracleTypeINTERVAL)this.attrTypes[b]).scale = typeDescriptor.getScale();
/*      */           break;
/*      */         case 122:
/*  296 */           this.attrTypes[b] = new OracleTypeCOLLECTION(this, b, this.connection);
/*      */           break;
/*      */         
/*      */         default:
/*  300 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 48, "type: " + typeDescriptor.getInternalTypeCode());
/*  301 */           sQLException.fillInStackTrace();
/*  302 */           throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  320 */     if (paramObject != null) {
/*      */       
/*  322 */       if (paramObject instanceof STRUCT)
/*      */       {
/*  324 */         return (Datum)paramObject;
/*      */       }
/*  326 */       if (paramObject instanceof java.sql.SQLData || paramObject instanceof oracle.jdbc.internal.ObjectData)
/*      */       {
/*      */         
/*  329 */         return (Datum)STRUCT.toSTRUCT(paramObject, (OracleConnection)paramOracleConnection);
/*      */       }
/*  331 */       if (paramObject instanceof Object[]) {
/*      */         
/*  333 */         StructDescriptor structDescriptor = createStructDescriptor();
/*  334 */         return (Datum)createObjSTRUCT(structDescriptor, (Object[])paramObject);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  339 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  340 */       sQLException.fillInStackTrace();
/*  341 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  345 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/*  359 */     Datum[] arrayOfDatum = null;
/*      */     
/*  361 */     if (paramObject != null)
/*      */     {
/*  363 */       if (paramObject instanceof Object[]) {
/*      */         
/*  365 */         Object[] arrayOfObject = (Object[])paramObject;
/*      */         
/*  367 */         int i = (int)((paramInt == -1) ? arrayOfObject.length : Math.min(arrayOfObject.length - paramLong + 1L, paramInt));
/*      */ 
/*      */         
/*  370 */         arrayOfDatum = new Datum[i];
/*      */         
/*  372 */         for (byte b = 0; b < i; b++) {
/*  373 */           arrayOfDatum[b] = toDatum(arrayOfObject[(int)paramLong + b - 1], paramOracleConnection);
/*      */         }
/*      */       } else {
/*      */         
/*  377 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  378 */         sQLException.fillInStackTrace();
/*  379 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */     
/*  383 */     return arrayOfDatum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTypeCode() throws SQLException {
/*  393 */     if ((getStatus() & 0x10) != 0) {
/*  394 */       return 2008;
/*      */     }
/*  396 */     return 2002;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleType[] getAttrTypes() throws SQLException {
/*  403 */     if (this.attrTypes == null) {
/*  404 */       init(this.connection);
/*      */     }
/*  406 */     return this.attrTypes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInHierarchyOf(OracleType paramOracleType) throws SQLException {
/*  417 */     if (paramOracleType == null) {
/*  418 */       return false;
/*      */     }
/*  420 */     if (!paramOracleType.isObjectType()) {
/*  421 */       return false;
/*      */     }
/*  423 */     StructDescriptor structDescriptor = (StructDescriptor)paramOracleType.getTypeDescriptor();
/*      */ 
/*      */     
/*  426 */     return this.descriptor.isInHierarchyOf(structDescriptor.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInHierarchyOf(StructDescriptor paramStructDescriptor) throws SQLException {
/*  435 */     if (paramStructDescriptor == null) {
/*  436 */       return false;
/*      */     }
/*  438 */     return this.descriptor.isInHierarchyOf(paramStructDescriptor.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isObjectType() {
/*  445 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDescriptor getTypeDescriptor() {
/*  452 */     return this.descriptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init(OracleConnection paramOracleConnection) throws SQLException {
/*  468 */     synchronized (paramOracleConnection) {
/*      */       
/*  470 */       byte[] arrayOfByte = initMetadata(paramOracleConnection);
/*  471 */       init(arrayOfByte, paramOracleConnection);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init(byte[] paramArrayOfbyte, OracleConnection paramOracleConnection) throws SQLException {
/*  485 */     synchronized (paramOracleConnection) {
/*      */       
/*  487 */       this.statusBits = 1;
/*  488 */       this.connection = paramOracleConnection;
/*      */       
/*  490 */       if (paramArrayOfbyte != null) parseTDS(paramArrayOfbyte, 0L); 
/*  491 */       setStatusBits(256);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] initMetadata(OracleConnection paramOracleConnection) throws SQLException {
/*  509 */     synchronized (this.connection) {
/*      */       
/*  511 */       byte[] arrayOfByte = null;
/*  512 */       if ((this.statusBits & 0x100) != 0) return null;
/*      */ 
/*      */       
/*  515 */       if (this.sqlName == null) getFullName();
/*      */ 
/*      */       
/*  518 */       if ((this.statusBits & 0x100) == 0) {
/*      */         
/*  520 */         CallableStatement callableStatement = null;
/*      */         
/*      */         try {
/*  523 */           if (this.tdoCState == 0L) this.tdoCState = this.connection.getTdoCState(this.sqlName.getSchema(), this.sqlName.getSimpleName());
/*      */ 
/*      */ 
/*      */           
/*  527 */           String str = "begin :1 := dbms_pickler.get_type_shape(:2,:3,:4,:5,:6,:7); end;";
/*      */ 
/*      */ 
/*      */           
/*  531 */           boolean bool = false;
/*  532 */           callableStatement = this.connection.prepareCall(str);
/*      */           
/*  534 */           callableStatement.registerOutParameter(1, 2);
/*  535 */           callableStatement.registerOutParameter(4, -4);
/*  536 */           callableStatement.registerOutParameter(5, 4);
/*  537 */           callableStatement.registerOutParameter(6, -4);
/*  538 */           callableStatement.registerOutParameter(7, -4);
/*  539 */           callableStatement.setString(2, this.sqlName.getSchema());
/*  540 */           callableStatement.setString(3, this.sqlName.getSimpleName());
/*      */ 
/*      */ 
/*      */           
/*  544 */           callableStatement.execute();
/*      */ 
/*      */           
/*  547 */           int i = callableStatement.getInt(1);
/*  548 */           if (i != 0) {
/*      */ 
/*      */             
/*  551 */             if (i != 24331) {
/*      */               
/*  553 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74, this.sqlName.toString());
/*  554 */               sQLException.fillInStackTrace();
/*  555 */               throw sQLException;
/*      */             } 
/*  557 */             if (i == 24331) {
/*      */               
/*  559 */               bool = true;
/*  560 */               callableStatement.registerOutParameter(6, 2004);
/*      */ 
/*      */               
/*  563 */               callableStatement.execute();
/*      */ 
/*      */               
/*  566 */               i = callableStatement.getInt(1);
/*  567 */               if (i != 0) {
/*      */ 
/*      */                 
/*  570 */                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74, this.sqlName.toString());
/*  571 */                 sQLException.fillInStackTrace();
/*  572 */                 throw sQLException;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  579 */           this.toid = callableStatement.getBytes(4);
/*  580 */           this.typeVersion = NUMBER.toInt(callableStatement.getBytes(5));
/*  581 */           if (!bool) {
/*      */             
/*  583 */             arrayOfByte = callableStatement.getBytes(6);
/*      */           } else {
/*      */ 
/*      */             
/*      */             try {
/*      */ 
/*      */               
/*  590 */               Blob blob = ((OracleCallableStatement)callableStatement).getBlob(6);
/*  591 */               InputStream inputStream = blob.getBinaryStream();
/*  592 */               arrayOfByte = new byte[(int)blob.length()];
/*  593 */               inputStream.read(arrayOfByte);
/*  594 */               inputStream.close();
/*  595 */               ((BLOB)blob).freeTemporary();
/*  596 */             } catch (IOException iOException) {
/*      */ 
/*      */               
/*  599 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  600 */               sQLException.fillInStackTrace();
/*  601 */               throw sQLException;
/*      */             } 
/*      */           } 
/*      */           
/*  605 */           this.metaDataInitialized = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  611 */           this.flattenedAttrNum = Util.getUnsignedByte(arrayOfByte[8]) * 256 + Util.getUnsignedByte(arrayOfByte[9]);
/*      */           
/*  613 */           callableStatement.getBytes(7);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         finally {
/*      */ 
/*      */ 
/*      */           
/*  622 */           if (callableStatement != null) callableStatement.close(); 
/*      */         } 
/*      */       } 
/*  625 */       setStatusBits(256);
/*  626 */       return arrayOfByte;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TDSReader parseTDS(byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/*  635 */     if (this.attrTypes != null) {
/*  636 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  641 */     TDSReader tDSReader = new TDSReader(paramArrayOfbyte, paramLong);
/*      */ 
/*      */     
/*  644 */     long l1 = tDSReader.readLong() + tDSReader.offset();
/*      */ 
/*      */ 
/*      */     
/*  648 */     tDSReader.checkNextByte((byte)38);
/*      */ 
/*      */     
/*  651 */     this.tdsVersion = tDSReader.readByte();
/*      */ 
/*      */     
/*  654 */     tDSReader.skipBytes(2);
/*      */ 
/*      */     
/*  657 */     this.flattenedAttrNum = tDSReader.readUB2();
/*      */ 
/*      */     
/*  660 */     if ((tDSReader.readByte() & 0xFF) == 255) {
/*  661 */       setStatusBits(128);
/*      */     }
/*      */ 
/*      */     
/*  665 */     long l2 = tDSReader.offset();
/*      */ 
/*      */     
/*  668 */     tDSReader.checkNextByte((byte)41);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  673 */     if (tDSReader.readUB2() != 0) {
/*      */       
/*  675 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
/*  676 */       sQLException.fillInStackTrace();
/*  677 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  682 */     long l3 = tDSReader.readLong();
/*      */ 
/*      */     
/*  685 */     parseTDSrec(tDSReader);
/*      */ 
/*      */     
/*  688 */     if (this.tdsVersion >= 3) {
/*      */ 
/*      */ 
/*      */       
/*  692 */       tDSReader.skip_to(l2 + l3 + 2L);
/*      */ 
/*      */       
/*  695 */       tDSReader.skipBytes(2 * this.flattenedAttrNum);
/*      */ 
/*      */       
/*  698 */       byte b = tDSReader.readByte();
/*      */ 
/*      */       
/*  701 */       if (tDSReader.isJavaObject(this.tdsVersion, b)) {
/*  702 */         setStatusBits(16);
/*      */       }
/*      */ 
/*      */       
/*  706 */       if (tDSReader.isFinalType(this.tdsVersion, b)) {
/*  707 */         setStatusBits(32);
/*      */       }
/*      */ 
/*      */       
/*  711 */       if (tDSReader.readByte() != 1) {
/*  712 */         setStatusBits(64);
/*      */       }
/*      */     } else {
/*      */       
/*  716 */       setStatusBits(32);
/*      */     } 
/*      */     
/*  719 */     tDSReader.skip_to(l1);
/*  720 */     return tDSReader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/*  728 */     Vector<OracleType> vector = new Vector(5);
/*  729 */     OracleType oracleType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  739 */     this.idx = 1;
/*      */     
/*  741 */     while ((oracleType = getNextTypeObject(paramTDSReader)) != null)
/*      */     {
/*  743 */       vector.addElement(oracleType);
/*      */     }
/*      */ 
/*      */     
/*  747 */     if (this.opcode == 42) {
/*      */       
/*  749 */       this.endOfAdt = true;
/*      */       
/*  751 */       applyTDSpatches(paramTDSReader);
/*      */     } 
/*      */     
/*  754 */     this.attrTypes = new OracleType[vector.size()];
/*      */     
/*  756 */     vector.copyInto((Object[])this.attrTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void applyTDSpatches(TDSReader paramTDSReader) throws SQLException {
/*  766 */     TDSPatch tDSPatch = paramTDSReader.getNextPatch();
/*      */     
/*  768 */     while (tDSPatch != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  773 */       paramTDSReader.moveToPatchPos(tDSPatch);
/*      */       
/*  775 */       int i = tDSPatch.getType();
/*      */       
/*  777 */       if (i == 0) {
/*      */         OracleNamedType oracleNamedType; SQLException sQLException;
/*      */         OracleTypeADT oracleTypeADT;
/*      */         TDSReader tDSReader;
/*  781 */         paramTDSReader.readByte();
/*      */         
/*  783 */         byte b = tDSPatch.getUptTypeCode();
/*      */         
/*  785 */         switch (b) {
/*      */ 
/*      */ 
/*      */           
/*      */           case -6:
/*  790 */             paramTDSReader.readLong();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case -5:
/*  797 */             oracleNamedType = tDSPatch.getOwner();
/*  798 */             oracleTypeADT = null;
/*      */             
/*  800 */             if (oracleNamedType.hasName()) {
/*      */               
/*  802 */               oracleTypeADT = new OracleTypeADT(oracleNamedType.getFullName(), (Connection)this.connection);
/*      */             }
/*      */             else {
/*      */               
/*  806 */               oracleTypeADT = new OracleTypeADT(oracleNamedType.getParent(), oracleNamedType.getOrder(), (Connection)this.connection);
/*      */             } 
/*      */ 
/*      */             
/*  810 */             oracleTypeADT.setUptADT();
/*  811 */             tDSReader = oracleTypeADT.parseTDS(paramTDSReader.tds(), paramTDSReader.absoluteOffset());
/*      */             
/*  813 */             paramTDSReader.skipBytes((int)tDSReader.offset());
/*  814 */             tDSPatch.apply(oracleTypeADT.cleanup());
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 58:
/*  821 */             oracleNamedType = tDSPatch.getOwner();
/*  822 */             oracleTypeADT = null;
/*      */             
/*  824 */             if (oracleNamedType.hasName()) {
/*      */               
/*  826 */               oracleTypeADT = new OracleTypeOPAQUE(oracleNamedType.getFullName(), this.connection);
/*      */             }
/*      */             else {
/*      */               
/*  830 */               oracleTypeADT = new OracleTypeOPAQUE(oracleNamedType.getParent(), oracleNamedType.getOrder(), this.connection);
/*      */             } 
/*      */ 
/*      */             
/*  834 */             oracleTypeADT.parseTDSrec(paramTDSReader);
/*  835 */             tDSPatch.apply(oracleTypeADT);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  843 */             sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*  844 */             sQLException.fillInStackTrace();
/*  845 */             throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*  850 */       } else if (i == 1) {
/*      */ 
/*      */ 
/*      */         
/*  854 */         OracleType oracleType = getNextTypeObject(paramTDSReader);
/*      */ 
/*      */ 
/*      */         
/*  858 */         tDSPatch.apply(oracleType, this.opcode);
/*      */       }
/*      */       else {
/*      */         
/*  862 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
/*  863 */         sQLException.fillInStackTrace();
/*  864 */         throw sQLException;
/*      */       } 
/*      */       
/*  867 */       tDSPatch = paramTDSReader.getNextPatch();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleNamedType cleanup() {
/*  878 */     synchronized (this.connection) {
/*      */       
/*  880 */       if (this.attrTypes.length == 1 && this.attrTypes[0] instanceof OracleTypeCOLLECTION) {
/*      */ 
/*      */ 
/*      */         
/*  884 */         OracleTypeCOLLECTION oracleTypeCOLLECTION = (OracleTypeCOLLECTION)this.attrTypes[0];
/*      */         
/*  886 */         oracleTypeCOLLECTION.copy_properties(this);
/*      */         
/*  888 */         return oracleTypeCOLLECTION;
/*      */       } 
/*  890 */       if (this.attrTypes.length == 1 && (this.statusBits & 0x80) != 0 && this.attrTypes[0] instanceof OracleTypeUPT && ((OracleTypeUPT)this.attrTypes[0]).realType instanceof OracleTypeOPAQUE) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  895 */         OracleTypeOPAQUE oracleTypeOPAQUE = (OracleTypeOPAQUE)((OracleTypeUPT)this.attrTypes[0]).realType;
/*      */ 
/*      */         
/*  898 */         oracleTypeOPAQUE.copy_properties(this);
/*      */         
/*  900 */         return oracleTypeOPAQUE;
/*      */       } 
/*      */       
/*  903 */       return this;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copy_properties(OracleTypeADT paramOracleTypeADT) {
/*  911 */     this.sqlName = paramOracleTypeADT.sqlName;
/*  912 */     this.parent = paramOracleTypeADT.parent;
/*  913 */     this.idx = paramOracleTypeADT.idx;
/*  914 */     this.connection = paramOracleTypeADT.connection;
/*  915 */     this.toid = paramOracleTypeADT.toid;
/*  916 */     this.tdsVersion = paramOracleTypeADT.tdsVersion;
/*  917 */     this.typeVersion = paramOracleTypeADT.typeVersion;
/*  918 */     this.tdoCState = paramOracleTypeADT.tdoCState;
/*  919 */     this.endOfAdt = paramOracleTypeADT.endOfAdt; } OracleType getNextTypeObject(TDSReader paramTDSReader) throws SQLException { OracleTypeDATE oracleTypeDATE; OracleTypeCHAR oracleTypeCHAR; OracleTypeADT oracleTypeADT; OracleTypeNUMBER oracleTypeNUMBER; OracleTypeFLOAT oracleTypeFLOAT;
/*      */     OracleTypeBINARY_FLOAT oracleTypeBINARY_FLOAT;
/*      */     OracleTypeBINARY_DOUBLE oracleTypeBINARY_DOUBLE;
/*      */     OracleTypeSINT32 oracleTypeSINT32;
/*      */     OracleTypeREF oracleTypeREF;
/*      */     OracleTypeBFILE oracleTypeBFILE;
/*      */     OracleTypeRAW oracleTypeRAW;
/*      */     OracleTypeCLOB oracleTypeCLOB;
/*      */     OracleTypeBLOB oracleTypeBLOB;
/*      */     OracleTypeTIMESTAMP oracleTypeTIMESTAMP;
/*      */     OracleTypeTIMESTAMPTZ oracleTypeTIMESTAMPTZ;
/*      */     OracleTypeTIMESTAMPLTZ oracleTypeTIMESTAMPLTZ;
/*      */     OracleTypeINTERVAL oracleTypeINTERVAL;
/*      */     OracleTypeCOLLECTION oracleTypeCOLLECTION;
/*      */     while (true) {
/*  934 */       this.opcode = paramTDSReader.readByte();
/*      */       
/*  936 */       if (this.opcode == 43) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  942 */       if (this.opcode == 44) {
/*      */ 
/*      */ 
/*      */         
/*  946 */         byte b = paramTDSReader.readByte();
/*      */         
/*  948 */         if (paramTDSReader.isJavaObject(3, b)) {
/*  949 */           setStatusBits(16);
/*      */         }
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */       
/*      */       break;
/*      */     } 
/*      */ 
/*      */     
/*  961 */     switch (this.opcode) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 40:
/*      */       case 42:
/*  968 */         return null;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  973 */         oracleTypeDATE = new OracleTypeDATE();
/*      */         
/*  975 */         oracleTypeDATE.parseTDSrec(paramTDSReader);
/*      */         
/*  977 */         this.idx++;
/*      */         
/*  979 */         return oracleTypeDATE;
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*  984 */         oracleTypeCHAR = new OracleTypeCHAR(this.connection, 12);
/*      */ 
/*      */         
/*  987 */         oracleTypeCHAR.parseTDSrec(paramTDSReader);
/*      */         
/*  989 */         this.idx++;
/*      */         
/*  991 */         return oracleTypeCHAR;
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  996 */         oracleTypeCHAR = new OracleTypeCHAR(this.connection, 1);
/*      */         
/*  998 */         oracleTypeCHAR.parseTDSrec(paramTDSReader);
/*      */         
/* 1000 */         this.idx++;
/*      */         
/* 1002 */         return oracleTypeCHAR;
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/* 1007 */         oracleTypeADT = new OracleTypeADT(this, this.idx, (Connection)this.connection);
/*      */         
/* 1009 */         oracleTypeADT.setEmbeddedADT();
/* 1010 */         oracleTypeADT.parseTDSrec(paramTDSReader);
/*      */         
/* 1012 */         this.idx++;
/*      */         
/* 1014 */         return oracleTypeADT;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/* 1019 */         oracleTypeNUMBER = new OracleTypeNUMBER(2);
/*      */         
/* 1021 */         oracleTypeNUMBER.parseTDSrec(paramTDSReader);
/*      */         
/* 1023 */         this.idx++;
/*      */         
/* 1025 */         return oracleTypeNUMBER;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 1030 */         oracleTypeNUMBER = new OracleTypeNUMBER(3);
/*      */         
/* 1032 */         oracleTypeNUMBER.parseTDSrec(paramTDSReader);
/*      */         
/* 1034 */         this.idx++;
/*      */         
/* 1036 */         return oracleTypeNUMBER;
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/* 1041 */         oracleTypeNUMBER = new OracleTypeNUMBER(8);
/*      */         
/* 1043 */         oracleTypeNUMBER.parseTDSrec(paramTDSReader);
/*      */         
/* 1045 */         this.idx++;
/*      */         
/* 1047 */         return oracleTypeNUMBER;
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/* 1052 */         oracleTypeFLOAT = new OracleTypeFLOAT();
/*      */         
/* 1054 */         oracleTypeFLOAT.parseTDSrec(paramTDSReader);
/*      */         
/* 1056 */         this.idx++;
/*      */         
/* 1058 */         return oracleTypeFLOAT;
/*      */ 
/*      */ 
/*      */       
/*      */       case 37:
/* 1063 */         oracleTypeBINARY_FLOAT = new OracleTypeBINARY_FLOAT();
/*      */         
/* 1065 */         oracleTypeBINARY_FLOAT.parseTDSrec(paramTDSReader);
/*      */         
/* 1067 */         this.idx++;
/*      */         
/* 1069 */         return oracleTypeBINARY_FLOAT;
/*      */ 
/*      */ 
/*      */       
/*      */       case 45:
/* 1074 */         oracleTypeBINARY_DOUBLE = new OracleTypeBINARY_DOUBLE();
/*      */         
/* 1076 */         oracleTypeBINARY_DOUBLE.parseTDSrec(paramTDSReader);
/*      */         
/* 1078 */         this.idx++;
/*      */         
/* 1080 */         return oracleTypeBINARY_DOUBLE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/* 1086 */         oracleTypeSINT32 = new OracleTypeSINT32();
/*      */         
/* 1088 */         oracleTypeSINT32.parseTDSrec(paramTDSReader);
/*      */         
/* 1090 */         this.idx++;
/*      */         
/* 1092 */         return oracleTypeSINT32;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 9:
/* 1098 */         oracleTypeREF = new OracleTypeREF(this, this.idx, this.connection);
/*      */         
/* 1100 */         oracleTypeREF.parseTDSrec(paramTDSReader);
/*      */         
/* 1102 */         this.idx++;
/*      */         
/* 1104 */         return oracleTypeREF;
/*      */ 
/*      */ 
/*      */       
/*      */       case 31:
/* 1109 */         oracleTypeBFILE = new OracleTypeBFILE(this.connection);
/*      */         
/* 1111 */         oracleTypeBFILE.parseTDSrec(paramTDSReader);
/*      */         
/* 1113 */         this.idx++;
/*      */         
/* 1115 */         return oracleTypeBFILE;
/*      */ 
/*      */ 
/*      */       
/*      */       case 19:
/* 1120 */         oracleTypeRAW = new OracleTypeRAW();
/*      */         
/* 1122 */         oracleTypeRAW.parseTDSrec(paramTDSReader);
/*      */         
/* 1124 */         this.idx++;
/*      */         
/* 1126 */         return oracleTypeRAW;
/*      */ 
/*      */ 
/*      */       
/*      */       case 29:
/* 1131 */         oracleTypeCLOB = new OracleTypeCLOB(this.connection);
/*      */         
/* 1133 */         oracleTypeCLOB.parseTDSrec(paramTDSReader);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1148 */         if (this.sqlName != null && !this.endOfAdt) {
/* 1149 */           this.connection.getForm(this, oracleTypeCLOB, this.idx);
/*      */         }
/* 1151 */         this.idx++;
/*      */         
/* 1153 */         return oracleTypeCLOB;
/*      */ 
/*      */ 
/*      */       
/*      */       case 30:
/* 1158 */         oracleTypeBLOB = new OracleTypeBLOB(this.connection);
/*      */         
/* 1160 */         oracleTypeBLOB.parseTDSrec(paramTDSReader);
/*      */         
/* 1162 */         this.idx++;
/*      */         
/* 1164 */         return oracleTypeBLOB;
/*      */ 
/*      */ 
/*      */       
/*      */       case 21:
/* 1169 */         oracleTypeTIMESTAMP = new OracleTypeTIMESTAMP(this.connection);
/*      */         
/* 1171 */         oracleTypeTIMESTAMP.parseTDSrec(paramTDSReader);
/*      */         
/* 1173 */         this.idx++;
/*      */         
/* 1175 */         return oracleTypeTIMESTAMP;
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/* 1180 */         oracleTypeTIMESTAMPTZ = new OracleTypeTIMESTAMPTZ(this.connection);
/*      */         
/* 1182 */         oracleTypeTIMESTAMPTZ.parseTDSrec(paramTDSReader);
/*      */         
/* 1184 */         this.idx++;
/*      */         
/* 1186 */         return oracleTypeTIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */       
/*      */       case 33:
/* 1191 */         oracleTypeTIMESTAMPLTZ = new OracleTypeTIMESTAMPLTZ(this.connection);
/*      */         
/* 1193 */         oracleTypeTIMESTAMPLTZ.parseTDSrec(paramTDSReader);
/*      */         
/* 1195 */         this.idx++;
/*      */         
/* 1197 */         return oracleTypeTIMESTAMPLTZ;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/* 1202 */         oracleTypeINTERVAL = new OracleTypeINTERVAL(this.connection);
/*      */         
/* 1204 */         oracleTypeINTERVAL.parseTDSrec(paramTDSReader);
/*      */         
/* 1206 */         this.idx++;
/*      */         
/* 1208 */         return oracleTypeINTERVAL;
/*      */ 
/*      */ 
/*      */       
/*      */       case 28:
/* 1213 */         oracleTypeCOLLECTION = new OracleTypeCOLLECTION(this, this.idx, this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1218 */         oracleTypeCOLLECTION.parseTDSrec(paramTDSReader);
/*      */         
/* 1220 */         this.idx++;
/*      */         
/* 1222 */         return oracleTypeCOLLECTION;
/*      */ 
/*      */ 
/*      */       
/*      */       case 27:
/* 1227 */         oracleTypeUPT = new OracleTypeUPT(this, this.idx, this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1232 */         oracleTypeUPT.parseTDSrec(paramTDSReader);
/*      */         
/* 1234 */         this.idx++;
/*      */         
/* 1236 */         return oracleTypeUPT;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1254 */     OracleTypeUPT oracleTypeUPT = null;
/*      */ 
/*      */     
/* 1257 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 48, "get_next_type: " + this.opcode);
/* 1258 */     sQLException.fillInStackTrace();
/* 1259 */     throw sQLException; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] linearize(Datum paramDatum) throws SQLException {
/* 1278 */     synchronized (this.connection) {
/*      */       
/* 1280 */       return pickle81(paramDatum);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
/* 1298 */     OracleConnection oracleConnection = getConnection();
/* 1299 */     Datum datum = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1304 */     if (oracleConnection == null) {
/*      */       
/* 1306 */       datum = _unlinearize(paramArrayOfbyte, paramLong, paramDatum, paramInt, paramMap);
/*      */     }
/*      */     else {
/*      */       
/* 1310 */       synchronized (oracleConnection) {
/* 1311 */         datum = _unlinearize(paramArrayOfbyte, paramLong, paramDatum, paramInt, paramMap);
/*      */       } 
/*      */     } 
/*      */     
/* 1315 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum _unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
/* 1326 */     synchronized (this.connection) {
/*      */       
/* 1328 */       if (paramArrayOfbyte == null) {
/* 1329 */         return null;
/*      */       }
/*      */       
/* 1332 */       PickleContext pickleContext = new PickleContext(paramArrayOfbyte, paramLong);
/*      */       
/* 1334 */       return (Datum)unpickle81(pickleContext, (STRUCT)paramDatum, 1, paramInt, paramMap);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected STRUCT unpickle81(PickleContext paramPickleContext, STRUCT paramSTRUCT, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*      */     long l2;
/*      */     Datum[] arrayOfDatum;
/*      */     Object[] arrayOfObject;
/*      */     byte b1;
/* 1356 */     STRUCT sTRUCT = paramSTRUCT;
/* 1357 */     long l1 = paramPickleContext.offset();
/*      */ 
/*      */     
/* 1360 */     byte b = paramPickleContext.readByte();
/*      */     
/* 1362 */     if (!PickleContext.is81format(b)) {
/*      */       
/* 1364 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format");
/* 1365 */       sQLException1.fillInStackTrace();
/* 1366 */       throw sQLException1;
/*      */     } 
/*      */     
/* 1369 */     if (PickleContext.isCollectionImage_pctx(b)) {
/*      */       
/* 1371 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is a collection image,expecting ADT");
/* 1372 */       sQLException1.fillInStackTrace();
/* 1373 */       throw sQLException1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1378 */     if (!paramPickleContext.readAndCheckVersion()) {
/*      */       
/* 1380 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image version is not recognized");
/* 1381 */       sQLException1.fillInStackTrace();
/* 1382 */       throw sQLException1;
/*      */     } 
/*      */     
/* 1385 */     switch (paramInt1)
/*      */     
/*      */     { 
/*      */       
/*      */       case 9:
/* 1390 */         paramPickleContext.skipBytes(paramPickleContext.readLength(true) - 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1477 */         return sTRUCT;case 3: l2 = paramPickleContext.readLength(); sTRUCT = unpickle81Prefix(paramPickleContext, sTRUCT, b); if (sTRUCT == null) { StructDescriptor structDescriptor = createStructDescriptor(); sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null); }  sTRUCT.setImage(paramPickleContext.image(), l1, 0L); sTRUCT.setImageLength(l2); paramPickleContext.skipTo(l1 + l2); return sTRUCT; }  paramPickleContext.skipLength(); sTRUCT = unpickle81Prefix(paramPickleContext, sTRUCT, b); if (sTRUCT == null) { StructDescriptor structDescriptor = createStructDescriptor(); sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null); }  OracleType[] arrayOfOracleType = sTRUCT.getDescriptor().getOracleTypeADT().getAttrTypes(); switch (paramInt2) { case 1: arrayOfDatum = new Datum[arrayOfOracleType.length]; for (b1 = 0; b1 < arrayOfOracleType.length; b1++) arrayOfDatum[b1] = (Datum)arrayOfOracleType[b1].unpickle81rec(paramPickleContext, paramInt2, paramMap);  sTRUCT.setDatumArray(arrayOfDatum); return sTRUCT;case 2: arrayOfObject = new Object[arrayOfOracleType.length]; for (b1 = 0; b1 < arrayOfOracleType.length; b1++) arrayOfObject[b1] = arrayOfOracleType[b1].unpickle81rec(paramPickleContext, paramInt2, paramMap);  sTRUCT.setObjArray(arrayOfObject); return sTRUCT; }
/*      */     
/*      */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*      */     sQLException.fillInStackTrace();
/*      */     throw sQLException;
/*      */   }
/*      */   
/*      */   protected STRUCT unpickle81Prefix(PickleContext paramPickleContext, STRUCT paramSTRUCT, byte paramByte) throws SQLException {
/* 1485 */     STRUCT sTRUCT = paramSTRUCT;
/*      */     
/* 1487 */     if (PickleContext.hasPrefix(paramByte)) {
/*      */       
/* 1489 */       long l = (paramPickleContext.readLength() + paramPickleContext.absoluteOffset());
/*      */       
/* 1491 */       byte b1 = paramPickleContext.readByte();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1498 */       byte b2 = (byte)(b1 & 0xC);
/* 1499 */       boolean bool1 = (b2 == 0) ? true : false;
/*      */       
/* 1501 */       boolean bool2 = (b2 == 4) ? true : false;
/*      */       
/* 1503 */       boolean bool3 = (b2 == 8) ? true : false;
/*      */       
/* 1505 */       boolean bool4 = (b2 == 12) ? true : false;
/*      */ 
/*      */       
/* 1508 */       boolean bool5 = ((b1 & 0x10) != 0) ? true : false;
/*      */ 
/*      */       
/* 1511 */       if (bool2) {
/*      */         
/* 1513 */         byte[] arrayOfByte = paramPickleContext.readBytes(16);
/* 1514 */         String str = toid2typename((Connection)this.connection, arrayOfByte);
/*      */         
/* 1516 */         StructDescriptor structDescriptor = (StructDescriptor)TypeDescriptor.getTypeDescriptor(str, (OracleConnection)this.connection);
/*      */ 
/*      */ 
/*      */         
/* 1520 */         if (sTRUCT == null) {
/* 1521 */           sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null);
/*      */         } else {
/* 1523 */           sTRUCT.setDescriptor(structDescriptor);
/*      */         } 
/*      */       } 
/* 1526 */       if (bool5)
/*      */       {
/* 1528 */         paramPickleContext.readLength();
/*      */       }
/*      */       
/* 1531 */       if ((bool3 | bool4) != 0) {
/*      */         
/* 1533 */         SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 1534 */         sQLException.fillInStackTrace();
/* 1535 */         throw sQLException;
/*      */       } 
/*      */       
/* 1538 */       paramPickleContext.skipTo(l);
/*      */     } 
/*      */     
/* 1541 */     return sTRUCT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object unpickle81rec(PickleContext paramPickleContext, int paramInt, Map paramMap) throws SQLException {
/* 1554 */     byte b = paramPickleContext.readByte();
/* 1555 */     byte b1 = 0;
/*      */     
/* 1557 */     if (PickleContext.isAtomicNull(b))
/* 1558 */       return null; 
/* 1559 */     if (PickleContext.isImmediatelyEmbeddedNull(b)) {
/* 1560 */       b1 = paramPickleContext.readByte();
/*      */     }
/* 1562 */     STRUCT sTRUCT = unpickle81datum(paramPickleContext, b, b1);
/*      */     
/* 1564 */     return toObject(sTRUCT, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object unpickle81rec(PickleContext paramPickleContext, byte paramByte, int paramInt, Map paramMap) throws SQLException {
/* 1573 */     STRUCT sTRUCT = unpickle81datum(paramPickleContext, paramByte, (byte)0);
/*      */     
/* 1575 */     return toObject(sTRUCT, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private STRUCT unpickle81datum(PickleContext paramPickleContext, byte paramByte1, byte paramByte2) throws SQLException {
/* 1583 */     int i = getNumAttrs();
/*      */ 
/*      */     
/* 1586 */     StructDescriptor structDescriptor = createStructDescriptor();
/* 1587 */     STRUCT sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null);
/* 1588 */     OracleType oracleType = getAttrTypeAt(0);
/* 1589 */     Object object = null;
/*      */ 
/*      */ 
/*      */     
/* 1593 */     if (PickleContext.isImmediatelyEmbeddedNull(paramByte1) && paramByte2 == 1) {
/* 1594 */       object = null;
/* 1595 */     } else if (PickleContext.isImmediatelyEmbeddedNull(paramByte1)) {
/* 1596 */       object = ((OracleTypeADT)oracleType).unpickle81datum(paramPickleContext, paramByte1, (byte)(paramByte2 - 1));
/*      */     }
/* 1598 */     else if (PickleContext.isElementNull(paramByte1)) {
/*      */       
/* 1600 */       if (oracleType.getTypeCode() == 2002 || oracleType.getTypeCode() == 2008) {
/*      */         
/* 1602 */         Datum datum = oracleType.unpickle81datumAsNull(paramPickleContext, paramByte1, paramByte2);
/*      */       } else {
/* 1604 */         object = null;
/*      */       } 
/*      */     } else {
/* 1607 */       object = oracleType.unpickle81rec(paramPickleContext, paramByte1, 1, null);
/*      */     } 
/*      */     
/* 1610 */     Datum[] arrayOfDatum = new Datum[i];
/*      */     
/* 1612 */     arrayOfDatum[0] = (Datum)object;
/*      */     
/* 1614 */     for (byte b = 1; b < i; b++) {
/*      */       
/* 1616 */       oracleType = getAttrTypeAt(b);
/* 1617 */       arrayOfDatum[b] = (Datum)oracleType.unpickle81rec(paramPickleContext, 1, null);
/*      */     } 
/*      */     
/* 1620 */     sTRUCT.setDatumArray(arrayOfDatum);
/*      */     
/* 1622 */     return sTRUCT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Datum unpickle81datumAsNull(PickleContext paramPickleContext, byte paramByte1, byte paramByte2) throws SQLException {
/* 1630 */     int i = getNumAttrs();
/*      */ 
/*      */     
/* 1633 */     StructDescriptor structDescriptor = createStructDescriptor();
/* 1634 */     STRUCT sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null);
/* 1635 */     Datum[] arrayOfDatum = new Datum[i];
/* 1636 */     byte b = 0;
/* 1637 */     OracleType oracleType = getAttrTypeAt(b);
/*      */ 
/*      */     
/* 1640 */     if (oracleType.getTypeCode() == 2002 || oracleType.getTypeCode() == 2008) {
/*      */       
/* 1642 */       arrayOfDatum[b++] = oracleType.unpickle81datumAsNull(paramPickleContext, paramByte1, paramByte2);
/*      */     } else {
/* 1644 */       arrayOfDatum[b++] = (Datum)null;
/*      */     } 
/* 1646 */     for (; b < i; b++) {
/*      */       
/* 1648 */       oracleType = getAttrTypeAt(b);
/* 1649 */       if (oracleType.getTypeCode() == 2002 || oracleType.getTypeCode() == 2008) {
/*      */         
/* 1651 */         arrayOfDatum[b] = (Datum)oracleType.unpickle81rec(paramPickleContext, 1, null);
/*      */       } else {
/*      */         
/* 1654 */         arrayOfDatum[b] = (Datum)oracleType.unpickle81rec(paramPickleContext, 1, null);
/*      */       } 
/* 1656 */     }  sTRUCT.setDatumArray(arrayOfDatum);
/* 1657 */     return (Datum)sTRUCT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] pickle81(Datum paramDatum) throws SQLException {
/* 1674 */     PickleContext pickleContext = new PickleContext();
/*      */     
/* 1676 */     pickleContext.initStream();
/* 1677 */     pickle81(pickleContext, paramDatum);
/*      */     
/* 1679 */     byte[] arrayOfByte = pickleContext.stream2Bytes();
/*      */ 
/*      */     
/* 1682 */     paramDatum.setShareBytes(arrayOfByte);
/*      */     
/* 1684 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException {
/* 1691 */     int i = paramPickleContext.offset() + 2;
/* 1692 */     int j = 0;
/*      */ 
/*      */     
/* 1695 */     j += paramPickleContext.writeImageHeader(shouldHavePrefix());
/*      */     
/* 1697 */     j += pickle81Prefix(paramPickleContext);
/* 1698 */     j += pickle81rec(paramPickleContext, paramDatum, 0);
/*      */     
/* 1700 */     paramPickleContext.patchImageLen(i, j);
/*      */     
/* 1702 */     return j;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasVersion() {
/* 1709 */     return (this.typeVersion > 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean needsToid() {
/* 1716 */     if (this.isTransient)
/* 1717 */       return false; 
/* 1718 */     return ((this.statusBits & 0x40) != 0 || (this.statusBits & 0x20) == 0 || hasVersion());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean shouldHavePrefix() {
/* 1726 */     if (this.isTransient)
/* 1727 */       return false; 
/* 1728 */     return (hasVersion() || needsToid());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int pickle81Prefix(PickleContext paramPickleContext) throws SQLException {
/* 1735 */     if (shouldHavePrefix()) {
/*      */       
/* 1737 */       int i = 0;
/* 1738 */       int j = 1;
/* 1739 */       int k = 1;
/*      */       
/* 1741 */       if (needsToid()) {
/*      */         
/* 1743 */         k += (getTOID()).length;
/* 1744 */         j |= 0x4;
/*      */       } 
/*      */       
/* 1747 */       if (hasVersion()) {
/*      */         
/* 1749 */         j |= 0x10;
/*      */         
/* 1751 */         if (this.typeVersion > PickleContext.KOPI20_LN_MAXV) {
/* 1752 */           k += 5;
/*      */         } else {
/* 1754 */           k += 2;
/*      */         } 
/*      */       } 
/* 1757 */       i = paramPickleContext.writeLength(k);
/*      */       
/* 1759 */       i += paramPickleContext.writeData((byte)j);
/*      */       
/* 1761 */       if (needsToid()) {
/* 1762 */         i += paramPickleContext.writeData(this.toid);
/*      */       }
/* 1764 */       if (hasVersion())
/*      */       {
/* 1766 */         if (this.typeVersion > PickleContext.KOPI20_LN_MAXV) {
/* 1767 */           i += paramPickleContext.writeLength(this.typeVersion);
/*      */         } else {
/* 1769 */           i += paramPickleContext.writeSB2(this.typeVersion);
/*      */         } 
/*      */       }
/* 1772 */       return i;
/*      */     } 
/*      */     
/* 1775 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int pickle81rec(PickleContext paramPickleContext, Datum paramDatum, int paramInt) throws SQLException {
/* 1785 */     int i = 0;
/*      */     
/* 1787 */     if (!this.metaDataInitialized) {
/* 1788 */       copy_properties((OracleTypeADT)((STRUCT)paramDatum).getDescriptor().getPickler());
/*      */     }
/* 1790 */     Datum[] arrayOfDatum = ((STRUCT)paramDatum).getOracleAttributes();
/* 1791 */     int j = arrayOfDatum.length;
/* 1792 */     byte b = 0;
/* 1793 */     OracleType oracleType = getAttrTypeAt(0);
/*      */     
/* 1795 */     if (oracleType instanceof OracleTypeADT && !(oracleType instanceof OracleTypeCOLLECTION) && !(oracleType instanceof OracleTypeUPT)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1802 */       b = 1;
/*      */       
/* 1804 */       if (arrayOfDatum[0] == null) {
/*      */         
/* 1806 */         if (paramInt > 0) {
/* 1807 */           i += paramPickleContext.writeImmediatelyEmbeddedElementNull((byte)paramInt);
/*      */         } else {
/* 1809 */           i += paramPickleContext.writeAtomicNull();
/*      */         } 
/*      */       } else {
/*      */         
/* 1813 */         i += ((OracleTypeADT)oracleType).pickle81rec(paramPickleContext, arrayOfDatum[0], paramInt + 1);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1818 */     for (; b < j; b++) {
/*      */       
/* 1820 */       oracleType = getAttrTypeAt(b);
/*      */ 
/*      */       
/* 1823 */       if (arrayOfDatum[b] == null) {
/*      */         
/* 1825 */         if (oracleType instanceof OracleTypeADT && !(oracleType instanceof OracleTypeCOLLECTION) && !(oracleType instanceof OracleTypeUPT))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1831 */           i += paramPickleContext.writeAtomicNull();
/*      */         }
/*      */         else
/*      */         {
/* 1835 */           i += paramPickleContext.writeElementNull();
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 1840 */       else if (oracleType instanceof OracleTypeADT && !(oracleType instanceof OracleTypeCOLLECTION) && !(oracleType instanceof OracleTypeUPT)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1846 */         i += ((OracleTypeADT)oracleType).pickle81rec(paramPickleContext, arrayOfDatum[b], 1);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1853 */         i += oracleType.pickle81(paramPickleContext, arrayOfDatum[b]);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1858 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object toObject(STRUCT paramSTRUCT, int paramInt, Map paramMap) throws SQLException {
/* 1870 */     switch (paramInt) {
/*      */ 
/*      */       
/*      */       case 1:
/* 1874 */         return paramSTRUCT;
/*      */       
/*      */       case 2:
/* 1877 */         if (paramSTRUCT != null) {
/* 1878 */           return paramSTRUCT.toJdbc(paramMap);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1892 */         return null;
/*      */     } 
/*      */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*      */     sQLException.fillInStackTrace();
/*      */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeType(int paramInt) throws SQLException {
/* 1909 */     return getAttributeType(paramInt, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeType(int paramInt, boolean paramBoolean) throws SQLException {
/* 1921 */     if (paramBoolean) {
/*      */       
/* 1923 */       if (this.sqlName == null) {
/* 1924 */         getFullName();
/*      */       }
/* 1926 */       if (this.attrNames == null)
/* 1927 */         initADTAttrNames(); 
/*      */     } 
/* 1929 */     if (paramInt < 1 || (this.attrTypeNames != null && paramInt > this.attrTypeNames.length)) {
/*      */       
/* 1931 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
/* 1932 */       sQLException.fillInStackTrace();
/* 1933 */       throw sQLException;
/*      */     } 
/*      */     
/* 1936 */     if (this.attrTypeNames != null) {
/* 1937 */       return this.attrTypeNames[paramInt - 1];
/*      */     }
/* 1939 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeName(int paramInt) throws SQLException {
/* 1952 */     if (this.attrNames == null) {
/* 1953 */       initADTAttrNames();
/*      */     }
/* 1955 */     String str = null;
/* 1956 */     if (this.attrNames != null) {
/*      */       
/* 1958 */       synchronized (this.connection) {
/* 1959 */         if (paramInt < 1 || paramInt > this.attrNames.length) {
/*      */           
/* 1961 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
/* 1962 */           sQLException.fillInStackTrace();
/* 1963 */           throw sQLException;
/*      */         } 
/*      */       } 
/* 1966 */       str = this.attrNames[paramInt - 1];
/*      */     } 
/* 1968 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeName(int paramInt, boolean paramBoolean) throws SQLException {
/* 1980 */     if (paramBoolean && this.connection != null) {
/* 1981 */       return getAttributeName(paramInt);
/*      */     }
/*      */     
/* 1984 */     if (paramInt < 1 || (this.attrNames != null && paramInt > this.attrNames.length)) {
/*      */       
/* 1986 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
/* 1987 */       sQLException.fillInStackTrace();
/* 1988 */       throw sQLException;
/*      */     } 
/*      */     
/* 1991 */     if (this.attrNames != null) {
/* 1992 */       return this.attrNames[paramInt - 1];
/*      */     }
/* 1994 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2014 */   static final String[] sqlString = new String[] { "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME = :1 ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ORDER BY ATTR_NO", "SELECT /*+RULE*/ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ORDER BY ATTR_NO", "SELECT /*+RULE*/ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE OWNER = :1 AND TYPE_NAME = :2 ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ORDER BY ATTR_NO", "DECLARE /*+RULE*/  the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME,  ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", "DECLARE /*+RULE*/  the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME,  ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;" };
/*      */ 
/*      */   
/*      */   static final int TDS_SIZE = 4;
/*      */ 
/*      */   
/*      */   static final int TDS_NUMBER = 1;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_SQL_CHAR = 1;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_DATE = 2;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_DECIMAL = 3;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_DOUBLE = 4;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_FLOAT = 5;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_NUMBER = 6;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_SQL_VARCHAR2 = 7;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_SINT32 = 8;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_REF = 9;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_VARRAY = 10;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_UINT8 = 11;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_SINT8 = 12;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_UINT16 = 13;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_UINT32 = 14;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_LOB = 15;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_CANONICAL = 17;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_OCTET = 18;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_RAW = 19;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_ROWID = 20;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_STAMP = 21;
/*      */ 
/*      */   
/*      */   static final int KOPM_OTS_TZSTAMP = 23;
/*      */   
/*      */   static final int KOPM_OTS_INTERVAL = 24;
/*      */   
/*      */   static final int KOPM_OTS_PTR = 25;
/*      */   
/*      */   static final int KOPM_OTS_SINT16 = 26;
/*      */   
/*      */   static final int KOPM_OTS_UPT = 27;
/*      */   
/*      */   static final int KOPM_OTS_COLLECTION = 28;
/*      */   
/*      */   static final int KOPM_OTS_CLOB = 29;
/*      */   
/*      */   static final int KOPM_OTS_BLOB = 30;
/*      */   
/*      */   static final int KOPM_OTS_BFILE = 31;
/*      */   
/*      */   static final int KOPM_OTS_BINARY_INTEGE = 32;
/*      */   
/*      */   static final int KOPM_OTS_IMPTZSTAMP = 33;
/*      */   
/*      */   static final int KOPM_OTS_BFLOAT = 37;
/*      */   
/*      */   static final int KOPM_OTS_BDOUBLE = 45;
/*      */   
/*      */   static final int KOTTCOPQ = 58;
/*      */   
/*      */   static final int KOPT_OP_STARTEMBADT = 39;
/*      */   
/*      */   static final int KOPT_OP_ENDEMBADT = 40;
/*      */   
/*      */   static final int KOPT_OP_STARTADT = 41;
/*      */   
/*      */   static final int KOPT_OP_ENDADT = 42;
/*      */   
/*      */   static final int KOPT_OP_SUBTYPE_MARKER = 43;
/*      */   
/*      */   static final int KOPT_OP_EMBADT_INFO = 44;
/*      */   
/*      */   static final int KOPT_OPCODE_START = 38;
/*      */   
/*      */   static final int KOPT_OP_VERSION = 38;
/*      */   
/*      */   static final int REGULAR_PATCH = 0;
/*      */   
/*      */   static final int SIMPLE_PATCH = 1;
/*      */ 
/*      */   
/*      */   private void initADTAttrNames() throws SQLException {
/* 2133 */     if (this.connection == null)
/*      */       return; 
/* 2135 */     if (this.sqlName == null)
/* 2136 */       getFullName(); 
/* 2137 */     synchronized (this.connection) {
/*      */       
/* 2139 */       CallableStatement callableStatement = null;
/* 2140 */       PreparedStatement preparedStatement = null;
/* 2141 */       ResultSet resultSet = null;
/* 2142 */       String[] arrayOfString1 = new String[this.attrTypes.length];
/* 2143 */       String[] arrayOfString2 = new String[this.attrTypes.length];
/* 2144 */       byte b1 = 0;
/* 2145 */       byte b2 = 0;
/* 2146 */       if (this.attrNames == null) {
/*      */         
/* 2148 */         b1 = this.sqlName.getSchema().equalsIgnoreCase(this.connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7;
/*      */ 
/*      */         
/* 2151 */         while (b1 != 11) {
/*      */           
/* 2153 */           switch (b1) {
/*      */ 
/*      */             
/*      */             case false:
/* 2157 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]);
/* 2158 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2159 */               preparedStatement.setFetchSize(this.idx);
/* 2160 */               resultSet = preparedStatement.executeQuery();
/* 2161 */               b1 = 1;
/*      */               break;
/*      */             
/*      */             case true:
/* 2165 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/* 2167 */                 b1 = 2;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/* 2172 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]);
/* 2173 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2174 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2175 */               preparedStatement.setFetchSize(this.idx);
/* 2176 */               resultSet = preparedStatement.executeQuery();
/* 2177 */               b1 = 3;
/*      */               break;
/*      */             
/*      */             case true:
/* 2181 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/* 2183 */                 b1 = 4;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/* 2188 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]);
/* 2189 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2190 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2191 */               preparedStatement.setFetchSize(this.idx);
/* 2192 */               resultSet = preparedStatement.executeQuery();
/* 2193 */               b1 = 5;
/*      */               break;
/*      */             
/*      */             case true:
/* 2197 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/* 2199 */                 b1 = 6;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/* 2204 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]);
/* 2205 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2206 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2207 */               preparedStatement.setFetchSize(this.idx);
/* 2208 */               resultSet = preparedStatement.executeQuery();
/* 2209 */               b1 = 8;
/*      */               break;
/*      */ 
/*      */             
/*      */             case true:
/* 2214 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]);
/* 2215 */               preparedStatement.setString(1, this.sqlName.getSchema());
/* 2216 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2217 */               preparedStatement.setFetchSize(this.idx);
/* 2218 */               resultSet = preparedStatement.executeQuery();
/* 2219 */               b1 = 8;
/*      */               break;
/*      */ 
/*      */             
/*      */             case true:
/* 2224 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]);
/* 2225 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 2226 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/* 2227 */               preparedStatement.setFetchSize(this.idx);
/* 2228 */               resultSet = preparedStatement.executeQuery();
/* 2229 */               b1 = 9;
/*      */               break;
/*      */             
/*      */             case true:
/* 2233 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/* 2235 */                 b1 = 10;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/* 2240 */               callableStatement = this.connection.prepareCall(getSqlHint() + sqlString[b1]);
/* 2241 */               callableStatement.setString(1, this.sqlName.getSimpleName());
/* 2242 */               callableStatement.registerOutParameter(2, -10);
/* 2243 */               callableStatement.execute();
/* 2244 */               resultSet = ((OracleCallableStatement)callableStatement).getCursor(2);
/* 2245 */               b1 = 11;
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/* 2252 */             b2 = 0;
/* 2253 */             for (; b2 < this.attrTypes.length && resultSet.next(); 
/* 2254 */               b2++) {
/*      */               
/* 2256 */               if (resultSet.getInt(1) != b2 + 1) {
/*      */                 
/* 2258 */                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "inconsistent ADT attribute");
/* 2259 */                 sQLException.fillInStackTrace();
/* 2260 */                 throw sQLException;
/*      */               } 
/*      */ 
/*      */               
/* 2264 */               arrayOfString1[b2] = resultSet.getString(2);
/*      */ 
/*      */               
/* 2267 */               String str = resultSet.getString(4);
/* 2268 */               arrayOfString2[b2] = "";
/* 2269 */               if (str != null)
/* 2270 */                 arrayOfString2[b2] = str + "."; 
/* 2271 */               arrayOfString2[b2] = arrayOfString2[b2] + resultSet.getString(3);
/*      */             } 
/*      */             
/* 2274 */             if (b2 != 0) {
/*      */               
/* 2276 */               this.attrTypeNames = arrayOfString2;
/*      */               
/* 2278 */               this.attrNames = arrayOfString1;
/* 2279 */               b1 = 11;
/*      */             } else {
/*      */               
/* 2282 */               if (resultSet != null)
/* 2283 */                 resultSet.close(); 
/* 2284 */               if (preparedStatement != null)
/* 2285 */                 preparedStatement.close(); 
/*      */             } 
/*      */           } finally {
/* 2288 */             if (resultSet != null)
/* 2289 */               resultSet.close(); 
/* 2290 */             if (preparedStatement != null)
/* 2291 */               preparedStatement.close(); 
/* 2292 */             if (callableStatement != null) {
/* 2293 */               callableStatement.close();
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   StructDescriptor createStructDescriptor() throws SQLException {
/* 2314 */     StructDescriptor structDescriptor = (StructDescriptor)this.descriptor;
/*      */     
/* 2316 */     if (structDescriptor == null) {
/* 2317 */       structDescriptor = new StructDescriptor(this, (Connection)this.connection);
/*      */     }
/* 2319 */     return structDescriptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   STRUCT createObjSTRUCT(StructDescriptor paramStructDescriptor, Object[] paramArrayOfObject) throws SQLException {
/* 2327 */     if ((this.statusBits & 0x10) != 0) {
/* 2328 */       return (STRUCT)new JAVA_STRUCT(paramStructDescriptor, (Connection)this.connection, paramArrayOfObject);
/*      */     }
/* 2330 */     return new STRUCT(paramStructDescriptor, (Connection)this.connection, paramArrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   STRUCT createByteSTRUCT(StructDescriptor paramStructDescriptor, byte[] paramArrayOfbyte) throws SQLException {
/* 2338 */     if ((this.statusBits & 0x10) != 0) {
/* 2339 */       return (STRUCT)new JAVA_STRUCT(paramStructDescriptor, paramArrayOfbyte, (Connection)this.connection);
/*      */     }
/* 2341 */     return new STRUCT(paramStructDescriptor, paramArrayOfbyte, (Connection)this.connection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSubtypeName(Connection paramConnection, byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 2353 */     PickleContext pickleContext = new PickleContext(paramArrayOfbyte, paramLong);
/* 2354 */     byte b = pickleContext.readByte();
/*      */     
/* 2356 */     if (PickleContext.is81format(b)) if (!PickleContext.isCollectionImage_pctx(b)) if (PickleContext.hasPrefix(b)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2362 */           if (!pickleContext.readAndCheckVersion()) {
/*      */             
/* 2364 */             SQLException sQLException = DatabaseError.createSqlException(null, 1, "Image version is not recognized");
/* 2365 */             sQLException.fillInStackTrace();
/* 2366 */             throw sQLException;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 2371 */           pickleContext.skipLength();
/*      */ 
/*      */           
/* 2374 */           pickleContext.skipLength();
/*      */           
/* 2376 */           b = pickleContext.readByte();
/*      */ 
/*      */           
/* 2379 */           if ((b & 0x4) != 0) {
/*      */             
/* 2381 */             byte[] arrayOfByte = pickleContext.readBytes(16);
/*      */             
/* 2383 */             return toid2typename(paramConnection, arrayOfByte);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2392 */           return null;
/*      */         } 
/*      */     
/*      */     
/*      */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toid2typename(Connection paramConnection, byte[] paramArrayOfbyte) throws SQLException {
/* 2402 */     String str = (String)((OracleConnection)paramConnection).getDescriptor(paramArrayOfbyte);
/*      */     
/* 2404 */     if (str == null) {
/*      */       
/* 2406 */       PreparedStatement preparedStatement = null;
/* 2407 */       ResultSet resultSet = null;
/*      */ 
/*      */       
/*      */       try {
/* 2411 */         preparedStatement = paramConnection.prepareStatement("select owner, type_name from all_types where type_oid = :1");
/*      */ 
/*      */         
/* 2414 */         preparedStatement.setBytes(1, paramArrayOfbyte);
/*      */         
/* 2416 */         resultSet = preparedStatement.executeQuery();
/*      */         
/* 2418 */         if (resultSet.next())
/*      */         {
/* 2420 */           str = resultSet.getString(1) + "." + resultSet.getString(2);
/*      */           
/* 2422 */           ((OracleConnection)paramConnection).putDescriptor(paramArrayOfbyte, str);
/*      */         }
/*      */         else
/*      */         {
/* 2426 */           SQLException sQLException = DatabaseError.createSqlException(null, 1, "Invalid type oid");
/* 2427 */           sQLException.fillInStackTrace();
/* 2428 */           throw sQLException;
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/* 2433 */         if (resultSet != null) {
/* 2434 */           resultSet.close();
/*      */         }
/* 2436 */         if (preparedStatement != null) {
/* 2437 */           preparedStatement.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2442 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTdsVersion() {
/* 2449 */     return this.tdsVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printDebug() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String debugText() {
/* 2468 */     StringWriter stringWriter = new StringWriter();
/* 2469 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/* 2471 */     printWriter.println("OracleTypeADT = " + this);
/* 2472 */     printWriter.println("sqlName = " + this.sqlName);
/*      */     
/* 2474 */     printWriter.println("OracleType[] : ");
/*      */     
/* 2476 */     if (this.attrTypes != null) {
/*      */       
/* 2478 */       for (byte b = 0; b < this.attrTypes.length; b++) {
/* 2479 */         printWriter.println("[" + b + "] = " + this.attrTypes[b]);
/*      */       }
/*      */     } else {
/* 2482 */       printWriter.println("null");
/*      */     } 
/* 2484 */     printWriter.println("toid : ");
/*      */     
/* 2486 */     if (this.toid != null) {
/* 2487 */       printUnsignedByteArray(this.toid, printWriter);
/*      */     } else {
/* 2489 */       printWriter.println("null");
/*      */     } 
/*      */     
/* 2492 */     printWriter.println("tds version : " + this.tdsVersion);
/* 2493 */     printWriter.println("type version : " + this.typeVersion);
/* 2494 */     printWriter.println("type version : " + this.typeVersion);
/* 2495 */     printWriter.println("opcode : " + this.opcode);
/*      */     
/* 2497 */     printWriter.println("tdoCState : " + this.tdoCState);
/*      */     
/* 2499 */     return stringWriter.getBuffer().substring(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getTOID() {
/*      */     try {
/* 2515 */       if (this.toid == null)
/*      */       {
/*      */         
/* 2518 */         initMetadata(this.connection);
/*      */       }
/*      */     }
/* 2521 */     catch (SQLException sQLException) {}
/*      */     
/* 2523 */     return this.toid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getImageFormatVersion() {
/* 2530 */     return PickleContext.KOPI20_VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTypeVersion() {
/*      */     try {
/* 2539 */       if (this.typeVersion == -1)
/*      */       {
/* 2541 */         initMetadata(this.connection);
/*      */       }
/* 2543 */     } catch (SQLException sQLException) {}
/*      */     
/* 2545 */     return this.typeVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCharSet() {
/* 2552 */     return this.charSetId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCharSetForm() {
/* 2559 */     return this.charSetForm;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTdoCState() {
/* 2569 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*      */       try {
/* 2573 */         if (this.tdoCState == 0L)
/*      */         {
/* 2575 */           getFullName();
/* 2576 */           this.tdoCState = this.connection.getTdoCState(this.sqlName.getSchema(), this.sqlName.getSimpleName());
/*      */         }
/*      */       
/*      */       }
/* 2580 */       catch (SQLException sQLException) {}
/* 2581 */       return this.tdoCState;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getFIXED_DATA_SIZE() {
/*      */     try {
/* 2591 */       return getFixedDataSize();
/*      */     }
/* 2593 */     catch (SQLException sQLException) {
/*      */       
/* 2595 */       return 0L;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getFixedDataSize() throws SQLException {
/* 2602 */     return this.fixedDataSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getAlignmentReq() throws SQLException {
/* 2609 */     return this.alignmentRequirement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumAttrs() throws SQLException {
/* 2616 */     if (this.attrTypes == null && this.connection != null) {
/* 2617 */       init(this.connection);
/*      */     }
/* 2619 */     return this.attrTypes.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleType getAttrTypeAt(int paramInt) throws SQLException {
/* 2626 */     if (this.attrTypes == null && this.connection != null) {
/* 2627 */       init(this.connection);
/*      */     }
/* 2629 */     return this.attrTypes[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmbeddedADT() throws SQLException {
/* 2636 */     return ((this.statusBits & 0x2) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUptADT() throws SQLException {
/* 2643 */     return ((this.statusBits & 0x4) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTopADT() throws SQLException {
/* 2650 */     return ((this.statusBits & 0x1) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStatus(int paramInt) throws SQLException {
/* 2657 */     this.statusBits = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setEmbeddedADT() throws SQLException {
/* 2664 */     maskAndSetStatusBits(-16, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setUptADT() throws SQLException {
/* 2671 */     maskAndSetStatusBits(-16, 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSubType() throws SQLException {
/* 2678 */     return ((this.statusBits & 0x40) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFinalType() throws SQLException {
/* 2687 */     return (((this.statusBits & 0x20) != 0)) | (((this.statusBits & 0x2) != 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isJavaObject() throws SQLException {
/* 2695 */     return ((this.statusBits & 0x10) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getStatus() throws SQLException {
/* 2704 */     if ((this.statusBits & 0x1) != 0 && (this.statusBits & 0x100) == 0)
/* 2705 */       init(this.connection); 
/* 2706 */     return this.statusBits;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static OracleTypeADT shallowClone(OracleTypeADT paramOracleTypeADT) throws SQLException {
/* 2714 */     OracleTypeADT oracleTypeADT = new OracleTypeADT();
/* 2715 */     shallowCopy(paramOracleTypeADT, oracleTypeADT);
/* 2716 */     return oracleTypeADT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shallowCopy(OracleTypeADT paramOracleTypeADT1, OracleTypeADT paramOracleTypeADT2) throws SQLException {
/* 2724 */     paramOracleTypeADT2.connection = paramOracleTypeADT1.connection;
/* 2725 */     paramOracleTypeADT2.sqlName = paramOracleTypeADT1.sqlName;
/* 2726 */     paramOracleTypeADT2.parent = paramOracleTypeADT1.parent;
/* 2727 */     paramOracleTypeADT2.idx = paramOracleTypeADT1.idx;
/* 2728 */     paramOracleTypeADT2.descriptor = paramOracleTypeADT1.descriptor;
/* 2729 */     paramOracleTypeADT2.statusBits = paramOracleTypeADT1.statusBits;
/*      */     
/* 2731 */     paramOracleTypeADT2.typeCode = paramOracleTypeADT1.typeCode;
/* 2732 */     paramOracleTypeADT2.dbTypeCode = paramOracleTypeADT1.dbTypeCode;
/* 2733 */     paramOracleTypeADT2.tdsVersion = paramOracleTypeADT1.tdsVersion;
/* 2734 */     paramOracleTypeADT2.typeVersion = paramOracleTypeADT1.typeVersion;
/* 2735 */     paramOracleTypeADT2.fixedDataSize = paramOracleTypeADT1.fixedDataSize;
/* 2736 */     paramOracleTypeADT2.alignmentRequirement = paramOracleTypeADT1.alignmentRequirement;
/* 2737 */     paramOracleTypeADT2.attrTypes = paramOracleTypeADT1.attrTypes;
/* 2738 */     paramOracleTypeADT2.sqlName = paramOracleTypeADT1.sqlName;
/* 2739 */     paramOracleTypeADT2.tdoCState = paramOracleTypeADT1.tdoCState;
/* 2740 */     paramOracleTypeADT2.toid = paramOracleTypeADT1.toid;
/* 2741 */     paramOracleTypeADT2.charSetId = paramOracleTypeADT1.charSetId;
/* 2742 */     paramOracleTypeADT2.charSetForm = paramOracleTypeADT1.charSetForm;
/* 2743 */     paramOracleTypeADT2.flattenedAttrNum = paramOracleTypeADT1.flattenedAttrNum;
/* 2744 */     paramOracleTypeADT2.statusBits = paramOracleTypeADT1.statusBits;
/* 2745 */     paramOracleTypeADT2.attrNames = paramOracleTypeADT1.attrNames;
/* 2746 */     paramOracleTypeADT2.attrTypeNames = paramOracleTypeADT1.attrTypeNames;
/* 2747 */     paramOracleTypeADT2.opcode = paramOracleTypeADT1.opcode;
/* 2748 */     paramOracleTypeADT2.idx = paramOracleTypeADT1.idx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 2759 */     paramObjectOutputStream.writeInt(this.statusBits);
/* 2760 */     paramObjectOutputStream.writeInt(this.tdsVersion);
/* 2761 */     paramObjectOutputStream.writeInt(this.typeVersion);
/* 2762 */     paramObjectOutputStream.writeObject(null);
/* 2763 */     paramObjectOutputStream.writeObject(null);
/* 2764 */     paramObjectOutputStream.writeLong(this.fixedDataSize);
/* 2765 */     paramObjectOutputStream.writeInt(this.alignmentRequirement);
/* 2766 */     paramObjectOutputStream.writeObject(this.attrTypes);
/* 2767 */     paramObjectOutputStream.writeObject(this.attrNames);
/* 2768 */     paramObjectOutputStream.writeObject(this.attrTypeNames);
/* 2769 */     paramObjectOutputStream.writeLong(this.tdoCState);
/* 2770 */     paramObjectOutputStream.writeObject(this.toid);
/* 2771 */     paramObjectOutputStream.writeObject(null);
/* 2772 */     paramObjectOutputStream.writeInt(this.charSetId);
/* 2773 */     paramObjectOutputStream.writeInt(this.charSetForm);
/* 2774 */     paramObjectOutputStream.writeBoolean(true);
/* 2775 */     paramObjectOutputStream.writeInt(this.flattenedAttrNum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 2783 */     this.statusBits = paramObjectInputStream.readInt();
/* 2784 */     this.tdsVersion = paramObjectInputStream.readInt();
/* 2785 */     this.typeVersion = paramObjectInputStream.readInt();
/* 2786 */     paramObjectInputStream.readObject();
/* 2787 */     paramObjectInputStream.readObject();
/* 2788 */     paramObjectInputStream.readLong();
/* 2789 */     paramObjectInputStream.readInt();
/* 2790 */     this.attrTypes = (OracleType[])paramObjectInputStream.readObject();
/* 2791 */     this.attrNames = (String[])paramObjectInputStream.readObject();
/* 2792 */     this.attrTypeNames = (String[])paramObjectInputStream.readObject();
/* 2793 */     paramObjectInputStream.readLong();
/* 2794 */     this.toid = (byte[])paramObjectInputStream.readObject();
/* 2795 */     paramObjectInputStream.readObject();
/* 2796 */     this.charSetId = paramObjectInputStream.readInt();
/* 2797 */     this.charSetForm = paramObjectInputStream.readInt();
/* 2798 */     paramObjectInputStream.readBoolean();
/* 2799 */     this.flattenedAttrNum = paramObjectInputStream.readInt();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 2805 */     synchronized (paramOracleConnection) {
/*      */       
/* 2807 */       this.connection = paramOracleConnection;
/* 2808 */       for (byte b = 0; b < this.attrTypes.length; b++) {
/* 2809 */         this.attrTypes[b].setConnection(this.connection);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void setStatusBits(int paramInt) {
/* 2816 */     synchronized (this.connection) {
/*      */       
/* 2818 */       this.statusBits |= paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void maskAndSetStatusBits(int paramInt1, int paramInt2) {
/* 2825 */     synchronized (this.connection) {
/*      */       
/* 2827 */       this.statusBits &= paramInt1;
/* 2828 */       this.statusBits |= paramInt2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void printUnsignedByteArray(byte[] paramArrayOfbyte, PrintWriter paramPrintWriter) {
/* 2837 */     int i = paramArrayOfbyte.length;
/*      */ 
/*      */     
/* 2840 */     int[] arrayOfInt = Util.toJavaUnsignedBytes(paramArrayOfbyte);
/*      */     byte b;
/* 2842 */     for (b = 0; b < i; b++)
/*      */     {
/* 2844 */       paramPrintWriter.print("0x" + Integer.toHexString(arrayOfInt[b]) + " ");
/*      */     }
/*      */     
/* 2847 */     paramPrintWriter.println();
/*      */     
/* 2849 */     for (b = 0; b < i; b++)
/*      */     {
/* 2851 */       paramPrintWriter.print(arrayOfInt[b] + " ");
/*      */     }
/*      */     
/* 2854 */     paramPrintWriter.println();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initChildNamesRecursively(Map paramMap) throws SQLException {
/* 2862 */     TypeTreeElement typeTreeElement = (TypeTreeElement)paramMap.get(this.sqlName);
/*      */     
/* 2864 */     if (this.attrTypes != null && this.attrTypes.length > 0)
/*      */     {
/* 2866 */       for (byte b = 0; b < this.attrTypes.length; b++) {
/*      */         
/* 2868 */         OracleType oracleType = this.attrTypes[b];
/* 2869 */         oracleType.setNames(typeTreeElement.getChildSchemaName(b + 1), typeTreeElement.getChildTypeName(b + 1));
/* 2870 */         oracleType.initChildNamesRecursively(paramMap);
/* 2871 */         oracleType.cacheDescriptor();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cacheDescriptor() throws SQLException {
/* 2880 */     this.descriptor = (TypeDescriptor)StructDescriptor.createDescriptor(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt) throws SQLException {
/* 2889 */     printXML(paramPrintWriter, paramInt, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean) throws SQLException {
/*      */     byte b;
/* 2899 */     for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
/* 2900 */      paramPrintWriter.print("<OracleTypeADT sqlName=\"" + this.sqlName + "\" ");
/*      */     
/* 2902 */     paramPrintWriter.print(" typecode=\"" + this.typeCode + "\"");
/* 2903 */     if (this.tdsVersion != -9999)
/* 2904 */       paramPrintWriter.print(" tds_version=\"" + this.tdsVersion + "\""); 
/* 2905 */     paramPrintWriter.println();
/* 2906 */     for (b = 0; b < paramInt + 4; ) { paramPrintWriter.print("  "); b++; }
/* 2907 */      paramPrintWriter.println(" is_embedded=\"" + isEmbeddedADT() + "\"" + " is_top_level=\"" + isTopADT() + "\"" + " is_upt=\"" + isUptADT() + "\"" + " finalType=\"" + isFinalType() + "\"" + " subtype=\"" + isSubType() + "\">");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2913 */     if (this.attrTypes != null && this.attrTypes.length > 0) {
/*      */       
/* 2915 */       for (b = 0; b < paramInt + 1; ) { paramPrintWriter.print("  "); b++; }
/* 2916 */        paramPrintWriter.println("<attributes>");
/* 2917 */       for (b = 0; b < this.attrTypes.length; b++) {
/*      */         byte b1;
/* 2919 */         for (b1 = 0; b1 < paramInt + 2; ) { paramPrintWriter.print("  "); b1++; }
/*      */ 
/*      */         
/* 2922 */         paramPrintWriter.println("<attribute name=\"" + getAttributeName(b + 1, paramBoolean) + "\" " + " type=\"" + getAttributeType(b + 1, false) + "\" >");
/*      */ 
/*      */         
/* 2925 */         this.attrTypes[b].printXML(paramPrintWriter, paramInt + 3, paramBoolean);
/* 2926 */         for (b1 = 0; b1 < paramInt + 2; ) { paramPrintWriter.print("  "); b1++; }
/* 2927 */          paramPrintWriter.println("</attribute> ");
/*      */       } 
/* 2929 */       for (b = 0; b < paramInt + 1; ) { paramPrintWriter.print("  "); b++; }
/* 2930 */        paramPrintWriter.println("</attributes>");
/*      */     } 
/* 2932 */     for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
/* 2933 */      paramPrintWriter.println("</OracleTypeADT>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2992 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\oracore\OracleTypeADT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */