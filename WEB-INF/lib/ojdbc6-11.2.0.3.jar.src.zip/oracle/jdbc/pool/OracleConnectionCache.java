package oracle.jdbc.pool;

import java.sql.SQLException;
import javax.sql.DataSource;
import javax.sql.PooledConnection;

public interface OracleConnectionCache extends DataSource {
  void reusePooledConnection(PooledConnection paramPooledConnection) throws SQLException;
  
  void closePooledConnection(PooledConnection paramPooledConnection) throws SQLException;
  
  void close() throws SQLException;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\pool\OracleConnectionCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */