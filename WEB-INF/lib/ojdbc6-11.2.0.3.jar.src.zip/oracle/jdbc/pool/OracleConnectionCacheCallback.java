package oracle.jdbc.pool;

import oracle.jdbc.OracleConnection;

public interface OracleConnectionCacheCallback {
  boolean handleAbandonedConnection(OracleConnection paramOracleConnection, Object paramObject);
  
  void releaseConnection(OracleConnection paramOracleConnection, Object paramObject);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\pool\OracleConnectionCacheCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */