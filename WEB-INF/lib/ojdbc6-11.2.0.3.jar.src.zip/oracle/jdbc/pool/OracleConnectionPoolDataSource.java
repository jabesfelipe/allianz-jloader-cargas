/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.sql.ConnectionPoolDataSource;
/*     */ import javax.sql.PooledConnection;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleConnectionPoolDataSource
/*     */   extends OracleDataSource
/*     */   implements ConnectionPoolDataSource
/*     */ {
/*     */   public PooledConnection getPooledConnection() throws SQLException {
/*  63 */     String str1 = null;
/*  64 */     String str2 = null;
/*  65 */     synchronized (this) {
/*     */       
/*  67 */       str1 = this.user;
/*  68 */       str2 = this.password;
/*     */     } 
/*  70 */     return getPooledConnection(str1, str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PooledConnection getPooledConnection(String paramString1, String paramString2) throws SQLException {
/*  88 */     Connection connection = getPhysicalConnection(this.url, paramString1, paramString2);
/*  89 */     OraclePooledConnection oraclePooledConnection = new OraclePooledConnection(connection);
/*     */ 
/*     */     
/*  92 */     if (paramString2 == null)
/*  93 */       paramString2 = this.password; 
/*  94 */     oraclePooledConnection.setUserName(!paramString1.startsWith("\"") ? paramString1.toLowerCase() : paramString1, paramString2);
/*     */ 
/*     */     
/*  97 */     return oraclePooledConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PooledConnection getPooledConnection(Properties paramProperties) throws SQLException {
/* 105 */     Connection connection = getPhysicalConnection(paramProperties);
/* 106 */     OraclePooledConnection oraclePooledConnection = new OraclePooledConnection(connection);
/*     */     
/* 108 */     String str1 = paramProperties.getProperty("user");
/* 109 */     if (str1 == null)
/* 110 */       str1 = ((OracleConnection)connection).getUserName(); 
/* 111 */     String str2 = paramProperties.getProperty("password");
/* 112 */     if (str2 == null)
/* 113 */       str2 = this.password; 
/* 114 */     oraclePooledConnection.setUserName(!str1.startsWith("\"") ? str1.toLowerCase() : str1, str2);
/*     */ 
/*     */     
/* 117 */     return oraclePooledConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getPhysicalConnection() throws SQLException {
/* 127 */     return getConnection(this.user, this.password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getPhysicalConnection(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 138 */     this.url = paramString1;
/* 139 */     return getConnection(paramString2, paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getPhysicalConnection(String paramString1, String paramString2) throws SQLException {
/* 150 */     return getConnection(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 155 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\pool\OracleConnectionPoolDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */