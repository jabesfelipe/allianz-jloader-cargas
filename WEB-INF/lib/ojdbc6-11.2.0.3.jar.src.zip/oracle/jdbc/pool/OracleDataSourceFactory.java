/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.xa.client.OracleXADataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleDataSourceFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable paramHashtable) throws Exception {
/*  42 */     Reference reference = (Reference)paramObject;
/*  43 */     OracleDataSource oracleDataSource = null;
/*  44 */     String str = reference.getClassName();
/*  45 */     Properties properties = new Properties();
/*     */     
/*  47 */     if (str.equals("oracle.jdbc.pool.OracleDataSource") || str.equals("oracle.jdbc.xa.client.OracleXADataSource")) {
/*     */       OracleXADataSource oracleXADataSource;
/*     */       
/*  50 */       if (str.equals("oracle.jdbc.pool.OracleDataSource")) {
/*  51 */         oracleDataSource = new OracleDataSource();
/*     */       } else {
/*  53 */         oracleXADataSource = new OracleXADataSource();
/*     */       } 
/*  55 */       StringRefAddr stringRefAddr = null;
/*     */ 
/*     */       
/*  58 */       if ((stringRefAddr = (StringRefAddr)reference.get("connectionCachingEnabled")) != null) {
/*     */         
/*  60 */         String str1 = (String)stringRefAddr.getContent();
/*     */         
/*  62 */         if (str1.equals(String.valueOf("true"))) {
/*  63 */           oracleXADataSource.setConnectionCachingEnabled(true);
/*     */         }
/*     */       } 
/*  66 */       if ((stringRefAddr = (StringRefAddr)reference.get("connectionCacheName")) != null)
/*     */       {
/*  68 */         oracleXADataSource.setConnectionCacheName((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/*  71 */       if ((stringRefAddr = (StringRefAddr)reference.get("connectionCacheProperties")) != null) {
/*     */         
/*  73 */         String str1 = (String)stringRefAddr.getContent();
/*  74 */         Properties properties1 = extractConnectionCacheProperties(str1);
/*     */         
/*  76 */         oracleXADataSource.setConnectionCacheProperties(properties1);
/*     */       } 
/*     */       
/*  79 */       if ((stringRefAddr = (StringRefAddr)reference.get("fastConnectionFailoverEnabled")) != null) {
/*     */ 
/*     */         
/*  82 */         String str1 = (String)stringRefAddr.getContent();
/*     */         
/*  84 */         if (str1.equals(String.valueOf("true"))) {
/*  85 */           oracleXADataSource.setFastConnectionFailoverEnabled(true);
/*     */         }
/*     */       } 
/*  88 */       if ((stringRefAddr = (StringRefAddr)reference.get("onsConfigStr")) != null)
/*     */       {
/*  90 */         oracleXADataSource.setONSConfiguration((String)stringRefAddr.getContent());
/*     */       }
/*     */     }
/*  93 */     else if (str.equals("oracle.jdbc.pool.OracleConnectionPoolDataSource")) {
/*  94 */       oracleDataSource = new OracleConnectionPoolDataSource();
/*  95 */     } else if (str.equals("oracle.jdbc.pool.OracleOCIConnectionPool")) {
/*     */ 
/*     */       
/*  98 */       oracleDataSource = new OracleOCIConnectionPool();
/*     */       
/* 100 */       String str1 = null;
/* 101 */       String str2 = null;
/* 102 */       String str3 = null;
/* 103 */       String str4 = null;
/* 104 */       String str5 = null;
/* 105 */       String str6 = null;
/* 106 */       String str7 = null;
/* 107 */       StringRefAddr stringRefAddr = null;
/*     */       
/* 109 */       Object object = null;
/* 110 */       String str8 = null;
/*     */ 
/*     */ 
/*     */       
/* 114 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_min_limit")) != null)
/*     */       {
/* 116 */         str1 = (String)stringRefAddr.getContent();
/*     */       }
/* 118 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_max_limit")) != null)
/*     */       {
/* 120 */         str2 = (String)stringRefAddr.getContent();
/*     */       }
/* 122 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_increment")) != null)
/*     */       {
/* 124 */         str3 = (String)stringRefAddr.getContent();
/*     */       }
/* 126 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_active_size")) != null)
/*     */       {
/* 128 */         str4 = (String)stringRefAddr.getContent();
/*     */       }
/* 130 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_pool_size")) != null)
/*     */       {
/* 132 */         str5 = (String)stringRefAddr.getContent();
/*     */       }
/* 134 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_timeout")) != null)
/*     */       {
/* 136 */         str6 = (String)stringRefAddr.getContent();
/*     */       }
/* 138 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_nowait")) != null)
/*     */       {
/* 140 */         str7 = (String)stringRefAddr.getContent();
/*     */       }
/* 142 */       if ((stringRefAddr = (StringRefAddr)reference.get("transactions_distributed")) != null)
/*     */       {
/* 144 */         str8 = (String)stringRefAddr.getContent();
/*     */       }
/*     */ 
/*     */       
/* 148 */       properties.put("connpool_min_limit", str1);
/* 149 */       properties.put("connpool_max_limit", str2);
/* 150 */       properties.put("connpool_increment", str3);
/* 151 */       properties.put("connpool_active_size", str4);
/*     */       
/* 153 */       properties.put("connpool_pool_size", str5);
/* 154 */       properties.put("connpool_timeout", str6);
/*     */       
/* 156 */       if (str7 == "true") {
/* 157 */         properties.put("connpool_nowait", str7);
/*     */       }
/* 159 */       if (str8 == "true") {
/* 160 */         properties.put("transactions_distributed", str8);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 168 */       return null;
/*     */     } 
/* 170 */     if (oracleDataSource != null) {
/*     */ 
/*     */ 
/*     */       
/* 174 */       StringRefAddr stringRefAddr = null;
/*     */       
/* 176 */       if ((stringRefAddr = (StringRefAddr)reference.get("url")) != null)
/*     */       {
/* 178 */         oracleDataSource.setURL((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 181 */       if ((stringRefAddr = (StringRefAddr)reference.get("userName")) != null || (stringRefAddr = (StringRefAddr)reference.get("u")) != null || (stringRefAddr = (StringRefAddr)reference.get("user")) != null)
/*     */       {
/*     */ 
/*     */         
/* 185 */         oracleDataSource.setUser((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 188 */       if ((stringRefAddr = (StringRefAddr)reference.get("passWord")) != null || (stringRefAddr = (StringRefAddr)reference.get("password")) != null)
/*     */       {
/*     */         
/* 191 */         oracleDataSource.setPassword((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 194 */       if ((stringRefAddr = (StringRefAddr)reference.get("description")) != null || (stringRefAddr = (StringRefAddr)reference.get("describe")) != null)
/*     */       {
/* 196 */         oracleDataSource.setDescription((String)stringRefAddr.getContent());
/*     */       }
/* 198 */       if ((stringRefAddr = (StringRefAddr)reference.get("driverType")) != null || (stringRefAddr = (StringRefAddr)reference.get("driver")) != null)
/*     */       {
/*     */         
/* 201 */         oracleDataSource.setDriverType((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 204 */       if ((stringRefAddr = (StringRefAddr)reference.get("serverName")) != null || (stringRefAddr = (StringRefAddr)reference.get("host")) != null)
/*     */       {
/*     */         
/* 207 */         oracleDataSource.setServerName((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 210 */       if ((stringRefAddr = (StringRefAddr)reference.get("databaseName")) != null || (stringRefAddr = (StringRefAddr)reference.get("sid")) != null)
/*     */       {
/*     */         
/* 213 */         oracleDataSource.setDatabaseName((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 216 */       if ((stringRefAddr = (StringRefAddr)reference.get("serviceName")) != null)
/*     */       {
/* 218 */         oracleDataSource.setServiceName((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 221 */       if ((stringRefAddr = (StringRefAddr)reference.get("networkProtocol")) != null || (stringRefAddr = (StringRefAddr)reference.get("protocol")) != null)
/*     */       {
/*     */         
/* 224 */         oracleDataSource.setNetworkProtocol((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 227 */       if ((stringRefAddr = (StringRefAddr)reference.get("portNumber")) != null || (stringRefAddr = (StringRefAddr)reference.get("port")) != null) {
/*     */ 
/*     */         
/* 230 */         String str1 = (String)stringRefAddr.getContent();
/*     */         
/* 232 */         oracleDataSource.setPortNumber(Integer.parseInt(str1));
/*     */       } 
/*     */       
/* 235 */       if ((stringRefAddr = (StringRefAddr)reference.get("tnsentryname")) != null || (stringRefAddr = (StringRefAddr)reference.get("tns")) != null) {
/*     */ 
/*     */         
/* 238 */         oracleDataSource.setTNSEntryName((String)stringRefAddr.getContent());
/*     */       
/*     */       }
/* 241 */       else if (str.equals("oracle.jdbc.pool.OracleOCIConnectionPool")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 258 */         String str1 = null;
/*     */         
/* 260 */         if ((stringRefAddr = (StringRefAddr)reference.get("connpool_is_poolcreated")) != null)
/*     */         {
/* 262 */           str1 = (String)stringRefAddr.getContent();
/*     */         }
/* 264 */         if (str1.equals(String.valueOf("true"))) {
/* 265 */           ((OracleOCIConnectionPool)oracleDataSource).setPoolConfig(properties);
/*     */         }
/*     */       } 
/*     */     } 
/* 269 */     return oracleDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties extractConnectionCacheProperties(String paramString) throws SQLException {
/* 291 */     Properties properties = new Properties();
/*     */ 
/*     */     
/* 294 */     paramString = paramString.substring(1, paramString.length() - 1);
/*     */ 
/*     */     
/* 297 */     int i = paramString.indexOf("AttributeWeights", 0);
/*     */     
/* 299 */     if (i >= 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 308 */       if (paramString.charAt(i + 16) != '=' || (i > 0 && paramString.charAt(i - 1) != ' ')) {
/*     */ 
/*     */ 
/*     */         
/* 312 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 139);
/*     */         
/* 314 */         sQLException.fillInStackTrace();
/* 315 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */       
/* 319 */       Properties properties1 = new Properties();
/* 320 */       int j = paramString.indexOf("}", i);
/* 321 */       String str1 = paramString.substring(i, j);
/*     */ 
/*     */       
/* 324 */       String str2 = str1.substring(18);
/*     */       
/* 326 */       StringTokenizer stringTokenizer1 = new StringTokenizer(str2, ", ");
/*     */ 
/*     */       
/* 329 */       synchronized (stringTokenizer1) {
/*     */         
/* 331 */         while (stringTokenizer1.hasMoreTokens()) {
/*     */           
/* 333 */           String str3 = stringTokenizer1.nextToken();
/* 334 */           int k = str3.length();
/* 335 */           int m = str3.indexOf("=");
/*     */           
/* 337 */           String str4 = str3.substring(0, m);
/* 338 */           String str5 = str3.substring(m + 1, k);
/*     */           
/* 340 */           properties1.setProperty(str4, str5);
/*     */         } 
/*     */       } 
/*     */       
/* 344 */       properties.put("AttributeWeights", properties1);
/*     */ 
/*     */       
/* 347 */       if (i > 0 && j + 1 == paramString.length()) {
/*     */         
/* 349 */         paramString = paramString.substring(0, i - 2);
/*     */       }
/* 351 */       else if (i > 0 && j + 1 < paramString.length()) {
/*     */         
/* 353 */         String str3 = paramString.substring(0, i - 2);
/* 354 */         String str4 = paramString.substring(j + 1, paramString.length());
/*     */         
/* 356 */         paramString = str3.concat(str4);
/*     */       }
/*     */       else {
/*     */         
/* 360 */         paramString = paramString.substring(j + 2, paramString.length());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 365 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ", ");
/*     */     
/* 367 */     synchronized (stringTokenizer) {
/*     */       
/* 369 */       while (stringTokenizer.hasMoreTokens()) {
/*     */         
/* 371 */         String str1 = stringTokenizer.nextToken();
/* 372 */         int j = str1.length();
/* 373 */         int k = str1.indexOf("=");
/*     */         
/* 375 */         String str2 = str1.substring(0, k);
/* 376 */         String str3 = str1.substring(k + 1, j);
/*     */         
/* 378 */         properties.setProperty(str2, str3);
/*     */       } 
/*     */     } 
/* 381 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 396 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 401 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\pool\OracleDataSourceFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */