/*      */ package oracle.jdbc.pool;
/*      */ 
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Random;
/*      */ import java.util.Vector;
/*      */ import javax.sql.PooledConnection;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.xa.client.OracleXADataSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleImplicitConnectionCache
/*      */ {
/*   51 */   protected OracleDataSource cacheEnabledDS = null;
/*   52 */   protected String cacheName = null;
/*   53 */   protected OracleConnectionPoolDataSource connectionPoolDS = null;
/*      */   
/*      */   protected boolean fastConnectionFailoverEnabled = false;
/*      */   
/*   57 */   protected String defaultUser = null;
/*   58 */   protected String defaultPassword = null;
/*      */   
/*      */   protected static final int DEFAULT_MIN_LIMIT = 0;
/*      */   
/*      */   protected static final int DEFAULT_MAX_LIMIT = 2147483647;
/*      */   
/*      */   protected static final int DEFAULT_INITIAL_LIMIT = 0;
/*      */   
/*      */   protected static final int DEFAULT_MAX_STATEMENTS_LIMIT = 0;
/*      */   
/*      */   protected static final int DEFAULT_INACTIVITY_TIMEOUT = 0;
/*      */   
/*      */   protected static final int DEFAULT_TIMETOLIVE_TIMEOUT = 0;
/*      */   
/*      */   protected static final int DEFAULT_ABANDONED_CONN_TIMEOUT = 0;
/*      */   
/*      */   protected static final int DEFAULT_CONNECTION_WAIT_TIMEOUT = 0;
/*      */   protected static final String DEFAULT_ATTRIBUTE_WEIGHT = "0";
/*      */   protected static final int DEFAULT_LOWER_THRESHOLD_LIMIT = 20;
/*      */   protected static final int DEFAULT_PROPERTY_CHECK_INTERVAL = 900;
/*      */   protected static final int CLOSE_AND_REMOVE_ALL_CONNECTIONS = 1;
/*      */   protected static final int CLOSE_AND_REMOVE_FAILOVER_CONNECTIONS = 2;
/*      */   protected static final int PROCESS_INACTIVITY_TIMEOUT = 4;
/*      */   protected static final int CLOSE_AND_REMOVE_N_CONNECTIONS = 8;
/*      */   protected static final int DISABLE_STATEMENT_CACHING = 16;
/*      */   protected static final int RESET_STATEMENT_CACHE_SIZE = 18;
/*      */   protected static final int CLOSE_AND_REMOVE_RLB_CONNECTIONS = 24;
/*      */   protected static final int ABORT_AND_CLOSE_ALL_CONNECTIONS = 32;
/*      */   public static final int REFRESH_INVALID_CONNECTIONS = 4096;
/*      */   public static final int REFRESH_ALL_CONNECTIONS = 8192;
/*      */   private static final String ATTRKEY_DELIM = "0xffff";
/*   89 */   protected int cacheMinLimit = 0;
/*   90 */   protected int cacheMaxLimit = Integer.MAX_VALUE;
/*   91 */   protected int cacheInitialLimit = 0;
/*   92 */   protected int cacheMaxStatementsLimit = 0;
/*   93 */   protected Properties cacheAttributeWeights = null;
/*   94 */   protected int cacheInactivityTimeout = 0;
/*   95 */   protected int cacheTimeToLiveTimeout = 0;
/*   96 */   protected int cacheAbandonedConnectionTimeout = 0;
/*   97 */   protected int cacheLowerThresholdLimit = 20;
/*   98 */   protected int cachePropertyCheckInterval = 900;
/*      */   protected boolean cacheClosestConnectionMatch = false;
/*      */   protected boolean cacheValidateConnection = false;
/*  101 */   protected int cacheConnectionWaitTimeout = 0;
/*      */   
/*      */   static final String MIN_LIMIT_KEY = "MinLimit";
/*      */   
/*      */   static final String MAX_LIMIT_KEY = "MaxLimit";
/*      */   
/*      */   static final String INITIAL_LIMIT_KEY = "InitialLimit";
/*      */   
/*      */   static final String MAX_STATEMENTS_LIMIT_KEY = "MaxStatementsLimit";
/*      */   
/*      */   static final String ATTRIBUTE_WEIGHTS_KEY = "AttributeWeights";
/*      */   
/*      */   static final String INACTIVITY_TIMEOUT_KEY = "InactivityTimeout";
/*      */   
/*      */   static final String TIME_TO_LIVE_TIMEOUT_KEY = "TimeToLiveTimeout";
/*      */   
/*      */   static final String ABANDONED_CONNECTION_TIMEOUT_KEY = "AbandonedConnectionTimeout";
/*      */   static final String LOWER_THRESHOLD_LIMIT_KEY = "LowerThresholdLimit";
/*      */   static final String PROPERTY_CHECK_INTERVAL_KEY = "PropertyCheckInterval";
/*      */   static final String VALIDATE_CONNECTION_KEY = "ValidateConnection";
/*      */   static final String CLOSEST_CONNECTION_MATCH_KEY = "ClosestConnectionMatch";
/*      */   static final String CONNECTION_WAIT_TIMEOUT_KEY = "ConnectionWaitTimeout";
/*      */   static final String LOCAL_TXN_COMMIT_ON_CLOSE = "LocalTransactionCommitOnClose";
/*      */   static final int INSTANCE_GOOD = 1;
/*      */   static final int INSTANCE_UNKNOWN = 2;
/*      */   static final int INSTANCE_VIOLATING = 3;
/*      */   static final int INSTANCE_NO_DATA = 4;
/*      */   static final int INSTANCE_BLOCKED = 5;
/*      */   static final int RLB_NUMBER_OF_HITS_PER_INSTANCE = 1000;
/*  130 */   int dbInstancePercentTotal = 0;
/*      */   boolean useGoodGroup = false;
/*  132 */   Vector instancesToRetireQueue = null;
/*  133 */   OracleDatabaseInstance instanceToRetire = null;
/*  134 */   int retireConnectionsCount = 0;
/*  135 */   int countTotal = 0;
/*      */   
/*  137 */   protected OracleConnectionCacheManager cacheManager = null;
/*      */   protected boolean disableConnectionRequest = false;
/*  139 */   protected OracleImplicitConnectionCacheThread timeoutThread = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  146 */   protected OracleRuntimeLoadBalancingEventHandlerThread runtimeLoadBalancingThread = null;
/*      */ 
/*      */ 
/*      */   
/*  150 */   protected OracleGravitateConnectionCacheThread gravitateCacheThread = null;
/*  151 */   protected int connectionsToRemove = 0;
/*      */ 
/*      */ 
/*      */   
/*  155 */   private HashMap userMap = null;
/*  156 */   Vector checkedOutConnectionList = null;
/*      */ 
/*      */   
/*  159 */   LinkedList databaseInstancesList = null;
/*      */   
/*  161 */   int cacheSize = 0;
/*      */   
/*      */   protected static final String EVENT_DELIMITER = " ";
/*      */   
/*      */   protected boolean isEntireServiceDownProcessed = false;
/*  166 */   protected int defaultUserPreFailureSize = 0;
/*  167 */   protected String dataSourceServiceName = null;
/*  168 */   protected OracleFailoverWorkerThread failoverWorkerThread = null;
/*  169 */   protected Random rand = null;
/*  170 */   protected int downEventCount = 0;
/*  171 */   protected int upEventCount = 0;
/*  172 */   protected int pendingCreationRequests = 0;
/*      */   
/*  174 */   protected int connectionClosedCount = 0;
/*  175 */   protected int connectionCreatedCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean cacheLocalTxnCommitOnClose = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleImplicitConnectionCache(OracleDataSource paramOracleDataSource, Properties paramProperties) throws SQLException {
/*  188 */     this.cacheEnabledDS = paramOracleDataSource;
/*      */     
/*  190 */     initializeConnectionCache();
/*  191 */     setConnectionCacheProperties(paramProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  198 */     defaultUserPrePopulateCache(this.cacheInitialLimit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void defaultUserPrePopulateCache(int paramInt) throws SQLException {
/*  211 */     if (paramInt > 0) {
/*      */       
/*  213 */       String str1 = this.defaultUser;
/*  214 */       String str2 = this.defaultPassword;
/*      */       
/*  216 */       validateUser(str1, str2);
/*      */       
/*  218 */       OraclePooledConnection oraclePooledConnection = null;
/*      */       
/*  220 */       for (byte b = 0; b < paramInt; b++) {
/*      */         
/*  222 */         oraclePooledConnection = makeOneConnection(str1, str2);
/*  223 */         synchronized (this) {
/*      */           
/*  225 */           if (oraclePooledConnection != null) {
/*      */ 
/*      */ 
/*      */             
/*  229 */             this.cacheSize--;
/*  230 */             storeCacheConnection(null, oraclePooledConnection);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeConnectionCache() throws SQLException {
/*  245 */     this.userMap = new HashMap<Object, Object>();
/*  246 */     this.checkedOutConnectionList = new Vector();
/*      */     
/*  248 */     if (this.cacheManager == null) {
/*  249 */       this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
/*      */     }
/*      */     
/*  252 */     if (this.cacheEnabledDS.user != null && !this.cacheEnabledDS.user.startsWith("\"")) {
/*      */       
/*  254 */       this.defaultUser = this.cacheEnabledDS.user.toLowerCase();
/*      */     } else {
/*  256 */       this.defaultUser = this.cacheEnabledDS.user;
/*      */     } 
/*  258 */     this.defaultPassword = this.cacheEnabledDS.password;
/*  259 */     if (this.connectionPoolDS == null) {
/*      */       
/*  261 */       if (this.cacheEnabledDS instanceof OracleXADataSource) {
/*      */         
/*  263 */         this.connectionPoolDS = (OracleConnectionPoolDataSource)new OracleXADataSource();
/*      */       }
/*      */       else {
/*      */         
/*  267 */         this.connectionPoolDS = new OracleConnectionPoolDataSource();
/*      */       } 
/*      */ 
/*      */       
/*  271 */       this.cacheEnabledDS.copy(this.connectionPoolDS);
/*      */     } 
/*      */     
/*  274 */     if (this.fastConnectionFailoverEnabled = this.cacheEnabledDS.getFastConnectionFailoverEnabled()) {
/*      */ 
/*      */       
/*  277 */       this.rand = new Random(0L);
/*  278 */       this.instancesToRetireQueue = new Vector();
/*  279 */       this.cacheManager.failoverEnabledCacheCount++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateUser(String paramString1, String paramString2) throws SQLException {
/*  293 */     if (paramString1 == null || paramString2 == null) {
/*      */       
/*  295 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 79);
/*  296 */       sQLException.fillInStackTrace();
/*  297 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Connection getConnection(String paramString1, String paramString2, Properties paramProperties) throws SQLException {
/*  317 */     OraclePooledConnection oraclePooledConnection = null;
/*  318 */     Connection connection = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  327 */       if (this.disableConnectionRequest) {
/*      */ 
/*      */         
/*  330 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 142);
/*  331 */         sQLException.fillInStackTrace();
/*  332 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  337 */       validateUser(paramString1, paramString2);
/*      */ 
/*      */       
/*  340 */       if (!paramString1.startsWith("\"")) {
/*  341 */         paramString1 = paramString1.toLowerCase();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  356 */       if (getNumberOfCheckedOutConnections() < this.cacheMaxLimit) {
/*  357 */         oraclePooledConnection = getCacheConnection(paramString1, paramString2, paramProperties);
/*      */       }
/*      */       
/*  360 */       if (oraclePooledConnection == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  367 */         processConnectionCacheCallback();
/*      */         
/*  369 */         if (this.cacheSize > 0) {
/*  370 */           oraclePooledConnection = getCacheConnection(paramString1, paramString2, paramProperties);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  379 */         if (oraclePooledConnection == null && this.cacheConnectionWaitTimeout > 0) {
/*      */           
/*  381 */           long l1 = this.cacheConnectionWaitTimeout * 1000L;
/*  382 */           long l2 = System.currentTimeMillis();
/*  383 */           long l3 = 0L;
/*      */           
/*      */           do {
/*  386 */             processConnectionWaitTimeout(l1);
/*      */             
/*  388 */             if (this.cacheSize > 0) {
/*  389 */               oraclePooledConnection = getCacheConnection(paramString1, paramString2, paramProperties);
/*      */             }
/*  391 */             l3 = System.currentTimeMillis();
/*  392 */             l1 -= System.currentTimeMillis() - l2;
/*  393 */             l2 = l3;
/*      */           
/*      */           }
/*  396 */           while (oraclePooledConnection == null && l1 > 0L);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  401 */       if (oraclePooledConnection != null && oraclePooledConnection.physicalConn != null) {
/*      */ 
/*      */ 
/*      */         
/*  405 */         connection = oraclePooledConnection.getConnection();
/*      */         
/*  407 */         if (connection != null) {
/*      */           
/*  409 */           if (this.cacheValidateConnection && testDatabaseConnection((OracleConnection)connection) != 0) {
/*      */ 
/*      */ 
/*      */             
/*  413 */             ((OracleConnection)connection).close(4096);
/*      */ 
/*      */             
/*  416 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143);
/*  417 */             sQLException.fillInStackTrace();
/*  418 */             throw sQLException;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  423 */           if (this.cacheAbandonedConnectionTimeout > 0) {
/*  424 */             ((OracleConnection)connection).setAbandonedTimeoutEnabled(true);
/*      */           }
/*      */           
/*  427 */           if (this.cacheTimeToLiveTimeout > 0) {
/*  428 */             ((OracleConnection)connection).setStartTime(System.currentTimeMillis());
/*      */           }
/*  430 */           synchronized (this) {
/*      */ 
/*      */ 
/*      */             
/*  434 */             this.cacheSize--;
/*  435 */             this.checkedOutConnectionList.addElement(oraclePooledConnection);
/*      */           } 
/*      */         } 
/*      */       } 
/*  439 */     } catch (SQLException sQLException) {
/*      */       
/*  441 */       synchronized (this) {
/*      */         
/*  443 */         if (oraclePooledConnection != null) {
/*      */           
/*  445 */           this.cacheSize--;
/*  446 */           abortConnection(oraclePooledConnection);
/*      */         } 
/*      */       } 
/*  449 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  455 */     return connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OraclePooledConnection getCacheConnection(String paramString1, String paramString2, Properties paramProperties) throws SQLException {
/*  471 */     OraclePooledConnection oraclePooledConnection = retrieveCacheConnection(paramString1, paramString2, paramProperties);
/*      */     
/*  473 */     if (oraclePooledConnection == null) {
/*      */       
/*  475 */       oraclePooledConnection = makeOneConnection(paramString1, paramString2);
/*      */       
/*  477 */       if (oraclePooledConnection != null && paramProperties != null && !paramProperties.isEmpty()) {
/*  478 */         setUnMatchedAttributes(paramProperties, oraclePooledConnection);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  486 */     return oraclePooledConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OraclePooledConnection makeOneConnection(String paramString1, String paramString2) throws SQLException {
/*  498 */     OraclePooledConnection oraclePooledConnection = null;
/*  499 */     boolean bool = false;
/*  500 */     synchronized (this) {
/*      */ 
/*      */       
/*  503 */       if (getTotalCachedConnections() + this.pendingCreationRequests < this.cacheMaxLimit) {
/*      */ 
/*      */         
/*  506 */         this.pendingCreationRequests++;
/*  507 */         bool = true;
/*      */       } 
/*      */     } 
/*      */     
/*  511 */     if (bool) {
/*      */       
/*      */       try {
/*      */         
/*  515 */         oraclePooledConnection = makeCacheConnection(paramString1, paramString2);
/*      */ 
/*      */       
/*      */       }
/*      */       finally {
/*      */ 
/*      */ 
/*      */         
/*  523 */         synchronized (this) {
/*      */           
/*  525 */           if (oraclePooledConnection != null)
/*  526 */             this.connectionCreatedCount++; 
/*  527 */           this.pendingCreationRequests--;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  532 */     return oraclePooledConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getTotalCachedConnections() {
/*  543 */     return this.cacheSize + getNumberOfCheckedOutConnections();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getNumberOfCheckedOutConnections() {
/*  554 */     return this.checkedOutConnectionList.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized OraclePooledConnection retrieveCacheConnection(String paramString1, String paramString2, Properties paramProperties) throws SQLException {
/*  566 */     OraclePooledConnection oraclePooledConnection = null;
/*      */     
/*  568 */     OracleConnectionCacheEntry oracleConnectionCacheEntry = (OracleConnectionCacheEntry)this.userMap.get(OraclePooledConnection.generateKey(paramString1, paramString2));
/*      */ 
/*      */     
/*  571 */     if (oracleConnectionCacheEntry != null)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  576 */       if (paramProperties == null || (paramProperties != null && paramProperties.isEmpty())) {
/*      */         
/*  578 */         if (oracleConnectionCacheEntry.userConnList != null) {
/*  579 */           oraclePooledConnection = retrieveFromConnectionList(oracleConnectionCacheEntry.userConnList);
/*      */         }
/*  581 */       } else if (oracleConnectionCacheEntry.attrConnMap != null) {
/*      */         
/*  583 */         String str = buildAttrKey(paramProperties);
/*  584 */         Vector vector = (Vector)oracleConnectionCacheEntry.attrConnMap.get(str);
/*      */ 
/*      */         
/*  587 */         if (vector != null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  594 */           oraclePooledConnection = retrieveFromConnectionList(vector);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  602 */         if (oraclePooledConnection == null && this.cacheClosestConnectionMatch) {
/*  603 */           oraclePooledConnection = retrieveClosestConnectionMatch(oracleConnectionCacheEntry.attrConnMap, paramProperties);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  608 */         if (oraclePooledConnection == null && oracleConnectionCacheEntry.userConnList != null) {
/*  609 */           oraclePooledConnection = retrieveFromConnectionList(oracleConnectionCacheEntry.userConnList);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  614 */     if (oraclePooledConnection != null)
/*      */     {
/*  616 */       if (paramProperties != null && !paramProperties.isEmpty()) {
/*  617 */         setUnMatchedAttributes(paramProperties, oraclePooledConnection);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  623 */     return oraclePooledConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OraclePooledConnection retrieveClosestConnectionMatch(HashMap paramHashMap, Properties paramProperties) throws SQLException {
/*  635 */     OraclePooledConnection oraclePooledConnection1 = null;
/*  636 */     OraclePooledConnection oraclePooledConnection2 = null;
/*  637 */     Vector vector = null;
/*      */     
/*  639 */     int i = paramProperties.size();
/*  640 */     int j = 0;
/*  641 */     int k = 0;
/*  642 */     int m = 0;
/*  643 */     int n = 0;
/*  644 */     int i1 = 0;
/*      */     
/*  646 */     if (this.cacheAttributeWeights != null) {
/*  647 */       j = getAttributesWeightCount(paramProperties, null);
/*      */     }
/*  649 */     if (paramHashMap != null && !paramHashMap.isEmpty()) {
/*      */ 
/*      */ 
/*      */       
/*  653 */       Iterator<Map.Entry> iterator = paramHashMap.entrySet().iterator();
/*      */       
/*  655 */       while (iterator.hasNext()) {
/*      */         
/*  657 */         Map.Entry entry = iterator.next();
/*      */         
/*  659 */         Vector vector1 = (Vector)entry.getValue();
/*  660 */         Object[] arrayOfObject = vector1.toArray();
/*  661 */         int i2 = vector1.size();
/*      */         
/*  663 */         for (byte b = 0; b < i2; b++) {
/*      */           
/*  665 */           oraclePooledConnection1 = (OraclePooledConnection)arrayOfObject[b];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  672 */           if (oraclePooledConnection1.cachedConnectionAttributes != null && !oraclePooledConnection1.cachedConnectionAttributes.isEmpty() && oraclePooledConnection1.cachedConnectionAttributes.size() <= i)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  686 */             if (j > 0) {
/*      */               
/*  688 */               m = getAttributesWeightCount(paramProperties, oraclePooledConnection1.cachedConnectionAttributes);
/*      */ 
/*      */ 
/*      */               
/*  692 */               if (m > k)
/*      */               {
/*  694 */                 oraclePooledConnection2 = oraclePooledConnection1;
/*  695 */                 k = m;
/*  696 */                 vector = vector1;
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/*  701 */               i1 = getAttributesMatchCount(paramProperties, oraclePooledConnection1.cachedConnectionAttributes);
/*      */ 
/*      */               
/*  704 */               if (i1 > n) {
/*      */                 
/*  706 */                 oraclePooledConnection2 = oraclePooledConnection1;
/*  707 */                 n = i1;
/*  708 */                 vector = vector1;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  716 */     if (vector != null) {
/*  717 */       vector.remove(oraclePooledConnection2);
/*      */     }
/*  719 */     return oraclePooledConnection2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getAttributesMatchCount(Properties paramProperties1, Properties paramProperties2) throws SQLException {
/*  734 */     byte b = 0;
/*  735 */     Map.Entry entry = null;
/*  736 */     Object object1 = null;
/*  737 */     Object object2 = null;
/*      */     
/*  739 */     Iterator<Map.Entry<Object, Object>> iterator = paramProperties1.entrySet().iterator();
/*      */     
/*  741 */     while (iterator.hasNext()) {
/*      */       
/*  743 */       entry = iterator.next();
/*  744 */       object1 = entry.getKey();
/*  745 */       object2 = entry.getValue();
/*      */       
/*  747 */       if (paramProperties2.containsKey(object1) && object2.equals(paramProperties2.get(object1)))
/*      */       {
/*  749 */         b++; } 
/*      */     } 
/*  751 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getAttributesWeightCount(Properties paramProperties1, Properties paramProperties2) throws SQLException {
/*  780 */     Map.Entry entry = null;
/*  781 */     Object object1 = null;
/*  782 */     Object object2 = null;
/*  783 */     int i = 0;
/*      */     
/*  785 */     Iterator<Map.Entry<Object, Object>> iterator = paramProperties1.entrySet().iterator();
/*      */     
/*  787 */     while (iterator.hasNext()) {
/*      */       
/*  789 */       entry = iterator.next();
/*  790 */       object1 = entry.getKey();
/*  791 */       object2 = entry.getValue();
/*      */ 
/*      */       
/*  794 */       if (paramProperties2 == null) {
/*      */         
/*  796 */         if (this.cacheAttributeWeights.containsKey(object1))
/*      */         {
/*  798 */           i += Integer.parseInt((String)this.cacheAttributeWeights.get(object1));
/*      */         }
/*      */         continue;
/*      */       } 
/*  802 */       if (paramProperties2.containsKey(object1) && object2.equals(paramProperties2.get(object1))) {
/*      */ 
/*      */         
/*  805 */         if (this.cacheAttributeWeights.containsKey(object1)) {
/*      */           
/*  807 */           i += Integer.parseInt((String)this.cacheAttributeWeights.get(object1));
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  813 */         i++;
/*      */       } 
/*      */     } 
/*      */     
/*  817 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setUnMatchedAttributes(Properties paramProperties, OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/*  831 */     if (paramOraclePooledConnection.unMatchedCachedConnAttr == null) {
/*  832 */       paramOraclePooledConnection.unMatchedCachedConnAttr = new Properties();
/*      */     } else {
/*  834 */       paramOraclePooledConnection.unMatchedCachedConnAttr.clear();
/*      */     } 
/*  836 */     if (!this.cacheClosestConnectionMatch) {
/*      */       
/*  838 */       paramOraclePooledConnection.unMatchedCachedConnAttr.putAll(paramProperties);
/*      */     }
/*      */     else {
/*      */       
/*  842 */       Properties properties = paramOraclePooledConnection.cachedConnectionAttributes;
/*  843 */       Map.Entry entry = null;
/*  844 */       Object object1 = null;
/*  845 */       Object object2 = null;
/*      */       
/*  847 */       Iterator<Map.Entry<Object, Object>> iterator = paramProperties.entrySet().iterator();
/*      */       
/*  849 */       while (iterator.hasNext()) {
/*      */         
/*  851 */         entry = iterator.next();
/*  852 */         object1 = entry.getKey();
/*  853 */         object2 = entry.getValue();
/*      */         
/*  855 */         if (!properties.containsKey(object1) && !object2.equals(properties.get(object1)))
/*      */         {
/*  857 */           paramOraclePooledConnection.unMatchedCachedConnAttr.put(object1, object2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OraclePooledConnection retrieveFromConnectionList(Vector<OraclePooledConnection> paramVector) throws SQLException {
/*  874 */     if (paramVector.isEmpty()) {
/*  875 */       return null;
/*      */     }
/*  877 */     OraclePooledConnection oraclePooledConnection = null;
/*  878 */     if (this.fastConnectionFailoverEnabled) {
/*      */ 
/*      */       
/*  881 */       if (this.useGoodGroup && this.databaseInstancesList != null && this.databaseInstancesList.size() > 0) {
/*      */         
/*  883 */         synchronized (this.databaseInstancesList) {
/*  884 */           int i = this.databaseInstancesList.size();
/*  885 */           OracleDatabaseInstance oracleDatabaseInstance = null;
/*  886 */           int j = 0;
/*      */           
/*  888 */           boolean[] arrayOfBoolean = new boolean[i];
/*  889 */           int k = this.dbInstancePercentTotal;
/*      */           byte b;
/*  891 */           label53: for (b = 0; b < i; b++) {
/*  892 */             int m = 0;
/*      */ 
/*      */             
/*  895 */             if (k <= 1) {
/*  896 */               j = 0;
/*      */             } else {
/*  898 */               j = this.rand.nextInt(k - 1);
/*      */             } 
/*  900 */             for (byte b1 = 0; b1 < i; b1++) {
/*      */               
/*  902 */               oracleDatabaseInstance = this.databaseInstancesList.get(b1);
/*      */               
/*  904 */               if (!arrayOfBoolean[b1] && oracleDatabaseInstance.flag <= 3) {
/*      */                 
/*  906 */                 m += oracleDatabaseInstance.percent;
/*      */ 
/*      */                 
/*  909 */                 if (j <= m) {
/*      */ 
/*      */                   
/*  912 */                   if (b == 0) oracleDatabaseInstance.attemptedConnRequestCount++;
/*      */                   
/*  914 */                   if ((oraclePooledConnection = selectConnectionFromList(paramVector, oracleDatabaseInstance)) != null) {
/*      */                     break label53;
/*      */                   }
/*      */ 
/*      */ 
/*      */                   
/*  920 */                   k -= oracleDatabaseInstance.percent;
/*  921 */                   arrayOfBoolean[b1] = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } else {
/*  938 */         int i = paramVector.size();
/*  939 */         int j = this.rand.nextInt(i);
/*  940 */         OraclePooledConnection oraclePooledConnection1 = null;
/*      */         
/*  942 */         for (byte b = 0; b < i; b++) {
/*      */           
/*  944 */           oraclePooledConnection1 = paramVector.get((j++ + i) % i);
/*      */ 
/*      */           
/*  947 */           if (!oraclePooledConnection1.connectionMarkedDown) {
/*      */             
/*  949 */             oraclePooledConnection = oraclePooledConnection1;
/*  950 */             paramVector.remove(oraclePooledConnection);
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/*  957 */       oraclePooledConnection = paramVector.remove(0);
/*      */     } 
/*  959 */     return oraclePooledConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OraclePooledConnection selectConnectionFromList(Vector<OraclePooledConnection> paramVector, OracleDatabaseInstance paramOracleDatabaseInstance) {
/*  971 */     OraclePooledConnection oraclePooledConnection1 = null;
/*  972 */     OraclePooledConnection oraclePooledConnection2 = null;
/*      */ 
/*      */     
/*  975 */     int i = paramVector.size();
/*  976 */     for (byte b = 0; b < i; b++) {
/*      */       
/*  978 */       oraclePooledConnection2 = paramVector.get(b);
/*      */       
/*  980 */       if (!oraclePooledConnection2.connectionMarkedDown && oraclePooledConnection2.dataSourceDbUniqNameKey == paramOracleDatabaseInstance.databaseUniqName && oraclePooledConnection2.dataSourceInstanceNameKey == paramOracleDatabaseInstance.instanceName) {
/*      */ 
/*      */ 
/*      */         
/*  984 */         oraclePooledConnection1 = oraclePooledConnection2;
/*  985 */         paramVector.remove(oraclePooledConnection1);
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  993 */     return oraclePooledConnection1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeCacheConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 1005 */     boolean bool = false;
/*      */     
/* 1007 */     OracleConnectionCacheEntry oracleConnectionCacheEntry = paramOraclePooledConnection.removeFromImplictCache(this.userMap);
/*      */ 
/*      */     
/* 1010 */     if (oracleConnectionCacheEntry != null) {
/*      */       
/* 1012 */       Properties properties = paramOraclePooledConnection.cachedConnectionAttributes;
/*      */       
/* 1014 */       if (properties == null || (properties != null && properties.isEmpty())) {
/*      */         
/* 1016 */         if (oracleConnectionCacheEntry.userConnList != null) {
/* 1017 */           bool = oracleConnectionCacheEntry.userConnList.removeElement(paramOraclePooledConnection);
/*      */         }
/* 1019 */       } else if (oracleConnectionCacheEntry.attrConnMap != null) {
/*      */         
/* 1021 */         String str = buildAttrKey(properties);
/*      */         
/* 1023 */         Vector vector = (Vector)oracleConnectionCacheEntry.attrConnMap.get(str);
/*      */ 
/*      */         
/* 1026 */         if (vector != null) {
/*      */ 
/*      */ 
/*      */           
/* 1030 */           if (paramOraclePooledConnection.unMatchedCachedConnAttr != null) {
/*      */             
/* 1032 */             paramOraclePooledConnection.unMatchedCachedConnAttr.clear();
/* 1033 */             paramOraclePooledConnection.unMatchedCachedConnAttr = null;
/*      */           } 
/*      */           
/* 1036 */           if (paramOraclePooledConnection.cachedConnectionAttributes != null) {
/*      */             
/* 1038 */             paramOraclePooledConnection.cachedConnectionAttributes.clear();
/* 1039 */             paramOraclePooledConnection.cachedConnectionAttributes = null;
/*      */           } 
/*      */           
/* 1042 */           properties = null;
/* 1043 */           bool = vector.removeElement(paramOraclePooledConnection);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1049 */     if (bool)
/*      */     {
/* 1051 */       this.cacheSize--;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doForEveryCachedConnection(int paramInt) throws SQLException {
/* 1076 */     byte b = 0;
/*      */     
/* 1078 */     synchronized (this) {
/*      */       
/* 1080 */       if (this.userMap != null && !this.userMap.isEmpty()) {
/*      */         
/* 1082 */         Iterator<Map.Entry> iterator = this.userMap.entrySet().iterator();
/*      */         
/* 1084 */         while (iterator.hasNext()) {
/*      */           
/* 1086 */           Map.Entry entry = iterator.next();
/* 1087 */           OracleConnectionCacheEntry oracleConnectionCacheEntry = (OracleConnectionCacheEntry)entry.getValue();
/*      */ 
/*      */ 
/*      */           
/* 1091 */           if (oracleConnectionCacheEntry.userConnList != null && !oracleConnectionCacheEntry.userConnList.isEmpty()) {
/*      */             
/* 1093 */             Vector vector = oracleConnectionCacheEntry.userConnList;
/* 1094 */             Object[] arrayOfObject = vector.toArray();
/*      */             
/* 1096 */             for (byte b1 = 0; b1 < arrayOfObject.length; b1++) {
/*      */               
/* 1098 */               OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b1];
/*      */               
/* 1100 */               if (oraclePooledConnection != null && performPooledConnectionTask(oraclePooledConnection, paramInt)) {
/* 1101 */                 b++;
/*      */               }
/*      */             } 
/*      */           } 
/* 1105 */           if (oracleConnectionCacheEntry.attrConnMap != null && !oracleConnectionCacheEntry.attrConnMap.isEmpty()) {
/*      */             
/* 1107 */             Iterator<Map.Entry> iterator1 = oracleConnectionCacheEntry.attrConnMap.entrySet().iterator();
/*      */             
/* 1109 */             while (iterator1.hasNext()) {
/*      */               
/* 1111 */               Map.Entry entry1 = iterator1.next();
/*      */               
/* 1113 */               Vector vector = (Vector)entry1.getValue();
/* 1114 */               Object[] arrayOfObject = vector.toArray();
/*      */               
/* 1116 */               for (byte b1 = 0; b1 < arrayOfObject.length; b1++) {
/*      */                 
/* 1118 */                 OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b1];
/*      */                 
/* 1120 */                 if (oraclePooledConnection != null && performPooledConnectionTask(oraclePooledConnection, paramInt)) {
/* 1121 */                   b++;
/*      */                 }
/*      */               } 
/*      */             } 
/* 1125 */             if (paramInt == 1 || paramInt == 32)
/*      */             {
/* 1127 */               oracleConnectionCacheEntry.attrConnMap.clear();
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 1132 */         if (paramInt == 1 || paramInt == 32) {
/*      */ 
/*      */           
/* 1135 */           this.userMap.clear();
/*      */           
/* 1137 */           this.cacheSize = 0;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1147 */     if (b > 0)
/*      */     {
/*      */       
/* 1150 */       defaultUserPrePopulateCache(b);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean performPooledConnectionTask(OraclePooledConnection paramOraclePooledConnection, int paramInt) throws SQLException {
/*      */     Connection connection;
/* 1171 */     boolean bool = false;
/*      */     
/* 1173 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 1179 */         if (paramOraclePooledConnection.connectionMarkedDown) {
/*      */ 
/*      */ 
/*      */           
/* 1183 */           paramOraclePooledConnection.needToAbort = true;
/* 1184 */           closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/* 1193 */         if (this.connectionsToRemove > 0) {
/*      */           
/* 1195 */           closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */           
/* 1197 */           this.connectionsToRemove--;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/* 1206 */         if (this.retireConnectionsCount > 0)
/*      */         {
/* 1208 */           if (this.instanceToRetire.databaseUniqName == paramOraclePooledConnection.dataSourceDbUniqNameKey && this.instanceToRetire.instanceName == paramOraclePooledConnection.dataSourceInstanceNameKey) {
/*      */ 
/*      */             
/* 1211 */             closeAndRemovePooledConnection(paramOraclePooledConnection);
/* 1212 */             this.retireConnectionsCount--;
/*      */             
/* 1214 */             if (getTotalCachedConnections() < this.cacheMinLimit) {
/* 1215 */               bool = true;
/*      */             }
/*      */           } 
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 4096:
/* 1224 */         connection = paramOraclePooledConnection.getLogicalHandle();
/*      */         
/* 1226 */         if (connection != null || (connection = paramOraclePooledConnection.getPhysicalHandle()) != null)
/*      */         {
/*      */           
/* 1229 */           if (testDatabaseConnection((OracleConnection)connection) != 0) {
/*      */ 
/*      */             
/* 1232 */             closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */             
/* 1234 */             bool = true;
/*      */           } 
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8192:
/* 1243 */         closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */         
/* 1245 */         bool = true;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/* 1252 */         closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/* 1259 */         processInactivityTimeout(paramOraclePooledConnection);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 16:
/* 1266 */         setStatementCaching(paramOraclePooledConnection, this.cacheMaxStatementsLimit, false);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 18:
/* 1273 */         setStatementCaching(paramOraclePooledConnection, this.cacheMaxStatementsLimit, true);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 32:
/* 1280 */         abortConnection(paramOraclePooledConnection);
/* 1281 */         closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1289 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void doForEveryCheckedOutConnection(int paramInt) throws SQLException {
/*      */     byte b;
/* 1306 */     int i = this.checkedOutConnectionList.size();
/*      */ 
/*      */     
/* 1309 */     switch (paramInt) {
/*      */       
/*      */       case 1:
/* 1312 */         for (b = 0; b < i; b++)
/*      */         {
/* 1314 */           closeCheckedOutConnection(this.checkedOutConnectionList.get(b), false);
/*      */         }
/*      */ 
/*      */         
/* 1318 */         this.checkedOutConnectionList.removeAllElements();
/*      */         break;
/*      */       
/*      */       case 24:
/* 1322 */         for (b = 0; b < i && this.retireConnectionsCount > 0; b++) {
/*      */           
/* 1324 */           OraclePooledConnection oraclePooledConnection = this.checkedOutConnectionList.get(b);
/* 1325 */           if (this.instanceToRetire.databaseUniqName == oraclePooledConnection.dataSourceDbUniqNameKey && this.instanceToRetire.instanceName == oraclePooledConnection.dataSourceInstanceNameKey) {
/*      */ 
/*      */             
/* 1328 */             oraclePooledConnection.closeOption = 4096;
/*      */ 
/*      */             
/* 1331 */             this.retireConnectionsCount -= 2;
/*      */           } 
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 32:
/* 1337 */         for (b = 0; b < i; b++) {
/*      */           
/* 1339 */           OraclePooledConnection oraclePooledConnection = null;
/* 1340 */           abortConnection(oraclePooledConnection = this.checkedOutConnectionList.get(b));
/* 1341 */           closeCheckedOutConnection(oraclePooledConnection, false);
/*      */         } 
/*      */ 
/*      */         
/* 1345 */         this.checkedOutConnectionList.removeAllElements();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closeCheckedOutConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException {
/* 1366 */     if (paramOraclePooledConnection != null) {
/*      */       
/* 1368 */       OracleConnection oracleConnection1 = (OracleConnection)paramOraclePooledConnection.getLogicalHandle();
/* 1369 */       OracleConnection oracleConnection2 = (OracleConnection)paramOraclePooledConnection.getPhysicalHandle();
/* 1370 */       boolean bool = oracleConnection1.getAutoCommit();
/*      */       
/* 1372 */       if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1378 */         boolean bool1 = paramOraclePooledConnection.localTxnCommitOnClose;
/*      */ 
/*      */         
/*      */         try {
/* 1382 */           paramOraclePooledConnection.localTxnCommitOnClose = false;
/* 1383 */           oracleConnection1.cleanupAndClose(true);
/*      */ 
/*      */           
/*      */           try {
/* 1387 */             if (!bool && !paramOraclePooledConnection.needToAbort) {
/* 1388 */               oracleConnection2.rollback();
/*      */             }
/* 1390 */           } catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1395 */         catch (SQLException sQLException) {
/*      */ 
/*      */         
/*      */         } finally {
/*      */           
/* 1400 */           if (paramOraclePooledConnection.localTxnCommitOnClose != bool1) {
/* 1401 */             paramOraclePooledConnection.localTxnCommitOnClose = bool1;
/*      */           }
/*      */         } 
/*      */       } else {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/* 1409 */           if (!bool && !paramOraclePooledConnection.needToAbort)
/*      */           {
/* 1411 */             oracleConnection2.cancel();
/* 1412 */             oracleConnection2.rollback();
/*      */           }
/*      */         
/* 1415 */         } catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1420 */         actualPooledConnectionClose(paramOraclePooledConnection);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void storeCacheConnection(Properties paramProperties, OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 1438 */     boolean bool = false;
/*      */     
/* 1440 */     if (paramOraclePooledConnection == null || paramOraclePooledConnection.physicalConn == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1445 */     if (this.cacheInactivityTimeout > 0)
/*      */     {
/* 1447 */       paramOraclePooledConnection.setLastAccessedTime(System.currentTimeMillis());
/*      */     }
/*      */     
/* 1450 */     if (paramOraclePooledConnection.unMatchedCachedConnAttr != null) {
/*      */       
/* 1452 */       paramOraclePooledConnection.unMatchedCachedConnAttr.clear();
/* 1453 */       paramOraclePooledConnection.unMatchedCachedConnAttr = null;
/*      */     } 
/*      */     
/* 1456 */     OracleConnectionCacheEntry oracleConnectionCacheEntry = paramOraclePooledConnection.removeFromImplictCache(this.userMap);
/*      */ 
/*      */     
/* 1459 */     if (oracleConnectionCacheEntry != null) {
/*      */       
/* 1461 */       if (paramProperties == null || (paramProperties != null && paramProperties.isEmpty())) {
/*      */         
/* 1463 */         if (oracleConnectionCacheEntry.userConnList == null) {
/* 1464 */           oracleConnectionCacheEntry.userConnList = new Vector();
/*      */         }
/* 1466 */         bool = oracleConnectionCacheEntry.userConnList.add(paramOraclePooledConnection);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1472 */         paramOraclePooledConnection.cachedConnectionAttributes = paramProperties;
/*      */         
/* 1474 */         if (oracleConnectionCacheEntry.attrConnMap == null) {
/* 1475 */           oracleConnectionCacheEntry.attrConnMap = new HashMap<Object, Object>();
/*      */         }
/* 1477 */         String str = buildAttrKey(paramProperties);
/* 1478 */         Vector<OraclePooledConnection> vector = (Vector)oracleConnectionCacheEntry.attrConnMap.get(str);
/*      */ 
/*      */         
/* 1481 */         if (vector != null)
/*      */         {
/* 1483 */           bool = vector.add(paramOraclePooledConnection);
/*      */         }
/*      */         else
/*      */         {
/* 1487 */           vector = new Vector<OraclePooledConnection>();
/*      */           
/* 1489 */           bool = vector.add(paramOraclePooledConnection);
/* 1490 */           oracleConnectionCacheEntry.attrConnMap.put(str, vector);
/*      */         }
/*      */       
/*      */       } 
/*      */     } else {
/*      */       
/* 1496 */       oracleConnectionCacheEntry = new OracleConnectionCacheEntry();
/*      */       
/* 1498 */       paramOraclePooledConnection.addToImplicitCache(this.userMap, oracleConnectionCacheEntry);
/*      */       
/* 1500 */       if (paramProperties == null || (paramProperties != null && paramProperties.isEmpty())) {
/*      */         
/* 1502 */         Vector<OraclePooledConnection> vector = new Vector();
/*      */         
/* 1504 */         bool = vector.add(paramOraclePooledConnection);
/*      */         
/* 1506 */         oracleConnectionCacheEntry.userConnList = vector;
/*      */       }
/*      */       else {
/*      */         
/* 1510 */         String str = buildAttrKey(paramProperties);
/*      */ 
/*      */         
/* 1513 */         paramOraclePooledConnection.cachedConnectionAttributes = paramProperties;
/*      */         
/* 1515 */         HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 1516 */         Vector<OraclePooledConnection> vector = new Vector();
/*      */         
/* 1518 */         bool = vector.add(paramOraclePooledConnection);
/* 1519 */         hashMap.put(str, vector);
/*      */         
/* 1521 */         oracleConnectionCacheEntry.attrConnMap = hashMap;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1526 */     if (bool) {
/* 1527 */       this.cacheSize++;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1538 */     if (this.cacheConnectionWaitTimeout > 0)
/*      */     {
/* 1540 */       notifyAll();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String buildAttrKey(Properties paramProperties) throws SQLException {
/* 1557 */     int i = paramProperties.keySet().size();
/* 1558 */     Object[] arrayOfObject = paramProperties.keySet().toArray();
/* 1559 */     boolean bool = true;
/* 1560 */     StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */     
/* 1563 */     while (bool) {
/*      */       
/* 1565 */       bool = false;
/*      */       
/* 1567 */       for (byte b1 = 0; b1 < i - 1; b1++) {
/*      */         
/* 1569 */         if (((String)arrayOfObject[b1]).compareTo((String)arrayOfObject[b1 + 1]) > 0) {
/*      */           
/* 1571 */           bool = true;
/*      */           
/* 1573 */           Object object = arrayOfObject[b1];
/*      */           
/* 1575 */           arrayOfObject[b1] = arrayOfObject[b1 + 1];
/* 1576 */           arrayOfObject[b1 + 1] = object;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1582 */     for (byte b = 0; b < i; b++) {
/* 1583 */       stringBuffer.append(arrayOfObject[b] + "0xffff" + paramProperties.get(arrayOfObject[b]));
/*      */     }
/* 1585 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OraclePooledConnection makeCacheConnection(String paramString1, String paramString2) throws SQLException {
/* 1598 */     OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)this.connectionPoolDS.getPooledConnection(paramString1, paramString2);
/*      */ 
/*      */ 
/*      */     
/* 1602 */     if (oraclePooledConnection != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1610 */       if (this.cacheMaxStatementsLimit > 0) {
/* 1611 */         setStatementCaching(oraclePooledConnection, this.cacheMaxStatementsLimit, true);
/*      */       }
/*      */       
/* 1614 */       oraclePooledConnection.registerImplicitCacheConnectionEventListener(new OracleConnectionCacheEventListener(this));
/*      */ 
/*      */       
/* 1617 */       oraclePooledConnection.cachedConnectionAttributes = new Properties();
/*      */ 
/*      */       
/* 1620 */       if (this.fastConnectionFailoverEnabled)
/*      */       {
/* 1622 */         initFailoverParameters(oraclePooledConnection);
/*      */       }
/*      */ 
/*      */       
/* 1626 */       synchronized (this) {
/*      */         
/* 1628 */         this.cacheSize++;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1633 */         if (this.fastConnectionFailoverEnabled && this.runtimeLoadBalancingThread == null) {
/*      */ 
/*      */           
/* 1636 */           this.runtimeLoadBalancingThread = new OracleRuntimeLoadBalancingEventHandlerThread(this.dataSourceServiceName);
/*      */           
/* 1638 */           this.cacheManager.checkAndStartThread(this.runtimeLoadBalancingThread);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1644 */       oraclePooledConnection.localTxnCommitOnClose = this.cacheLocalTxnCommitOnClose;
/*      */     } 
/* 1646 */     return oraclePooledConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setStatementCaching(OraclePooledConnection paramOraclePooledConnection, int paramInt, boolean paramBoolean) throws SQLException {
/* 1657 */     if (paramInt > 0) {
/* 1658 */       paramOraclePooledConnection.setStatementCacheSize(paramInt);
/*      */     }
/* 1660 */     paramOraclePooledConnection.setImplicitCachingEnabled(paramBoolean);
/* 1661 */     paramOraclePooledConnection.setExplicitCachingEnabled(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void reusePooledConnection(PooledConnection paramPooledConnection) throws SQLException {
/* 1683 */     OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)paramPooledConnection;
/* 1684 */     if (oraclePooledConnection != null && oraclePooledConnection.physicalConn != null) {
/*      */       
/* 1686 */       if (oraclePooledConnection.localTxnCommitOnClose)
/* 1687 */         oraclePooledConnection.physicalConn.commit(); 
/* 1688 */       storeCacheConnection(oraclePooledConnection.cachedConnectionAttributes, oraclePooledConnection);
/*      */ 
/*      */       
/* 1691 */       this.checkedOutConnectionList.removeElement(oraclePooledConnection);
/*      */ 
/*      */ 
/*      */       
/* 1695 */       oraclePooledConnection.logicalHandle = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closePooledConnection(PooledConnection paramPooledConnection) throws SQLException {
/* 1718 */     if (paramPooledConnection != null) {
/*      */       
/* 1720 */       actualPooledConnectionClose((OraclePooledConnection)paramPooledConnection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1726 */       if (((OraclePooledConnection)paramPooledConnection).closeOption == 4096) {
/* 1727 */         this.checkedOutConnectionList.removeElement(paramPooledConnection);
/*      */       }
/* 1729 */       paramPooledConnection = null;
/*      */       
/* 1731 */       if (getTotalCachedConnections() < this.cacheMinLimit) {
/* 1732 */         defaultUserPrePopulateCache(1);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void refreshCacheConnections(int paramInt) throws SQLException {
/* 1748 */     doForEveryCachedConnection(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reinitializeCacheConnections(Properties paramProperties) throws SQLException {
/* 1764 */     int i = 0;
/*      */ 
/*      */     
/* 1767 */     synchronized (this) {
/*      */       
/* 1769 */       this.defaultUser = this.cacheEnabledDS.user;
/* 1770 */       this.defaultPassword = this.cacheEnabledDS.password;
/* 1771 */       this.fastConnectionFailoverEnabled = this.cacheEnabledDS.getFastConnectionFailoverEnabled();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1779 */       cleanupTimeoutThread();
/*      */ 
/*      */ 
/*      */       
/* 1783 */       doForEveryCheckedOutConnection(1);
/*      */ 
/*      */       
/* 1786 */       int j = this.cacheInitialLimit;
/* 1787 */       int k = this.cacheMaxLimit;
/* 1788 */       int m = this.cacheMaxStatementsLimit;
/*      */ 
/*      */       
/* 1791 */       setConnectionCacheProperties(paramProperties);
/*      */       
/* 1793 */       if (this.cacheInitialLimit > j) {
/* 1794 */         i = this.cacheInitialLimit - j;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1800 */       if (k != Integer.MAX_VALUE)
/*      */       {
/* 1802 */         if (this.cacheMaxLimit < k && this.cacheSize > this.cacheMaxLimit) {
/*      */           
/* 1804 */           this.connectionsToRemove = this.cacheSize - this.cacheMaxLimit;
/*      */           
/* 1806 */           doForEveryCachedConnection(8);
/*      */           
/* 1808 */           this.connectionsToRemove = 0;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1814 */       if (this.cacheMaxStatementsLimit != m)
/*      */       {
/* 1816 */         if (this.cacheMaxStatementsLimit == 0) {
/* 1817 */           doForEveryCachedConnection(16);
/*      */         } else {
/* 1819 */           doForEveryCachedConnection(18);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1826 */     if (i > 0)
/*      */     {
/* 1828 */       defaultUserPrePopulateCache(i);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void setConnectionCacheProperties(Properties paramProperties) throws SQLException {
/*      */     try {
/* 1855 */       if (paramProperties != null) {
/*      */         
/* 1857 */         String str = null;
/*      */ 
/*      */         
/* 1860 */         if ((str = paramProperties.getProperty("MinLimit")) != null)
/*      */         {
/* 1862 */           if ((this.cacheMinLimit = Integer.parseInt(str)) < 0) {
/* 1863 */             this.cacheMinLimit = 0;
/*      */           }
/*      */         }
/*      */         
/* 1867 */         if ((str = paramProperties.getProperty("MaxLimit")) != null)
/*      */         {
/* 1869 */           if ((this.cacheMaxLimit = Integer.parseInt(str)) < 0) {
/* 1870 */             this.cacheMaxLimit = Integer.MAX_VALUE;
/*      */           }
/*      */         }
/*      */         
/* 1874 */         if (this.cacheMaxLimit < this.cacheMinLimit) {
/* 1875 */           this.cacheMinLimit = this.cacheMaxLimit;
/*      */         }
/*      */         
/* 1878 */         if ((str = paramProperties.getProperty("InitialLimit")) != null)
/*      */         {
/* 1880 */           if ((this.cacheInitialLimit = Integer.parseInt(str)) < 0) {
/* 1881 */             this.cacheInitialLimit = 0;
/*      */           }
/*      */         }
/* 1884 */         if (this.cacheInitialLimit > this.cacheMaxLimit) {
/* 1885 */           this.cacheInitialLimit = this.cacheMaxLimit;
/*      */         }
/*      */         
/* 1888 */         if ((str = paramProperties.getProperty("MaxStatementsLimit")) != null)
/*      */         {
/* 1890 */           if ((this.cacheMaxStatementsLimit = Integer.parseInt(str)) < 0) {
/* 1891 */             this.cacheMaxStatementsLimit = 0;
/*      */           }
/*      */         }
/*      */         
/* 1895 */         Properties properties = (Properties)paramProperties.get("AttributeWeights");
/*      */ 
/*      */         
/* 1898 */         if (properties != null) {
/*      */           
/* 1900 */           Map.Entry entry = null;
/* 1901 */           int i = 0;
/* 1902 */           Object object = null;
/*      */           
/* 1904 */           Iterator<Map.Entry<Object, Object>> iterator = properties.entrySet().iterator();
/*      */           
/* 1906 */           while (iterator.hasNext()) {
/*      */             
/* 1908 */             entry = iterator.next();
/* 1909 */             object = entry.getKey();
/*      */             
/* 1911 */             if ((str = (String)properties.get(object)) != null)
/*      */             {
/* 1913 */               if ((i = Integer.parseInt(str)) < 0) {
/* 1914 */                 properties.put(object, "0");
/*      */               }
/*      */             }
/*      */           } 
/* 1918 */           if (this.cacheAttributeWeights == null) {
/* 1919 */             this.cacheAttributeWeights = new Properties();
/*      */           }
/* 1921 */           this.cacheAttributeWeights.putAll(properties);
/*      */         } 
/*      */ 
/*      */         
/* 1925 */         if ((str = paramProperties.getProperty("InactivityTimeout")) != null)
/*      */         {
/* 1927 */           if ((this.cacheInactivityTimeout = Integer.parseInt(str)) < 0) {
/* 1928 */             this.cacheInactivityTimeout = 0;
/*      */           }
/*      */         }
/*      */         
/* 1932 */         if ((str = paramProperties.getProperty("TimeToLiveTimeout")) != null)
/*      */         {
/* 1934 */           if ((this.cacheTimeToLiveTimeout = Integer.parseInt(str)) < 0) {
/* 1935 */             this.cacheTimeToLiveTimeout = 0;
/*      */           }
/*      */         }
/*      */         
/* 1939 */         if ((str = paramProperties.getProperty("AbandonedConnectionTimeout")) != null)
/*      */         {
/* 1941 */           if ((this.cacheAbandonedConnectionTimeout = Integer.parseInt(str)) < 0) {
/* 1942 */             this.cacheAbandonedConnectionTimeout = 0;
/*      */           }
/*      */         }
/*      */         
/* 1946 */         if ((str = paramProperties.getProperty("LowerThresholdLimit")) != null) {
/*      */           
/* 1948 */           this.cacheLowerThresholdLimit = Integer.parseInt(str);
/*      */           
/* 1950 */           if (this.cacheLowerThresholdLimit < 0 || this.cacheLowerThresholdLimit > 100)
/*      */           {
/* 1952 */             this.cacheLowerThresholdLimit = 20;
/*      */           }
/*      */         } 
/*      */         
/* 1956 */         if ((str = paramProperties.getProperty("PropertyCheckInterval")) != null)
/*      */         {
/* 1958 */           if ((this.cachePropertyCheckInterval = Integer.parseInt(str)) < 0)
/*      */           {
/* 1960 */             this.cachePropertyCheckInterval = 900;
/*      */           }
/*      */         }
/*      */ 
/*      */         
/* 1965 */         if ((str = paramProperties.getProperty("ValidateConnection")) != null) {
/* 1966 */           this.cacheValidateConnection = Boolean.valueOf(str).booleanValue();
/*      */         }
/*      */ 
/*      */         
/* 1970 */         if ((str = paramProperties.getProperty("ClosestConnectionMatch")) != null)
/*      */         {
/* 1972 */           this.cacheClosestConnectionMatch = Boolean.valueOf(str).booleanValue();
/*      */         }
/*      */ 
/*      */         
/* 1976 */         if ((str = paramProperties.getProperty("ConnectionWaitTimeout")) != null)
/*      */         {
/* 1978 */           if ((this.cacheConnectionWaitTimeout = Integer.parseInt(str)) < 0) {
/* 1979 */             this.cacheConnectionWaitTimeout = 0;
/*      */           }
/*      */         }
/*      */         
/* 1983 */         if ((str = paramProperties.getProperty("LocalTransactionCommitOnClose")) != null)
/*      */         {
/* 1985 */           this.cacheLocalTxnCommitOnClose = str.equalsIgnoreCase("true");
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1991 */         this.cacheMinLimit = 0;
/* 1992 */         this.cacheMaxLimit = Integer.MAX_VALUE;
/* 1993 */         this.cacheInitialLimit = 0;
/* 1994 */         this.cacheMaxStatementsLimit = 0;
/* 1995 */         this.cacheAttributeWeights = null;
/* 1996 */         this.cacheInactivityTimeout = 0;
/* 1997 */         this.cacheTimeToLiveTimeout = 0;
/* 1998 */         this.cacheAbandonedConnectionTimeout = 0;
/* 1999 */         this.cacheLowerThresholdLimit = 20;
/* 2000 */         this.cachePropertyCheckInterval = 900;
/* 2001 */         this.cacheClosestConnectionMatch = false;
/* 2002 */         this.cacheValidateConnection = false;
/* 2003 */         this.cacheConnectionWaitTimeout = 0;
/* 2004 */         this.cacheLocalTxnCommitOnClose = false;
/*      */       } 
/*      */ 
/*      */       
/* 2008 */       if ((this.cacheInactivityTimeout > 0 || this.cacheTimeToLiveTimeout > 0 || this.cacheAbandonedConnectionTimeout > 0) && this.cachePropertyCheckInterval > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2013 */         if (this.timeoutThread == null) {
/* 2014 */           this.timeoutThread = new OracleImplicitConnectionCacheThread(this);
/*      */         }
/* 2016 */         this.cacheManager.checkAndStartThread(this.timeoutThread);
/*      */       } 
/*      */       
/* 2019 */       if (this.cachePropertyCheckInterval == 0)
/*      */       {
/*      */ 
/*      */         
/* 2023 */         cleanupTimeoutThread();
/*      */       }
/*      */     }
/* 2026 */     catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */       
/* 2029 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 139, "OracleImplicitConnectionCache:setConnectionCacheProperties() - NumberFormatException Occurred :" + numberFormatException.getMessage());
/*      */ 
/*      */ 
/*      */       
/* 2033 */       sQLException.fillInStackTrace();
/* 2034 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Properties getConnectionCacheProperties() throws SQLException {
/* 2048 */     Properties properties = new Properties();
/*      */     
/* 2050 */     properties.setProperty("MinLimit", String.valueOf(this.cacheMinLimit));
/* 2051 */     properties.setProperty("MaxLimit", String.valueOf(this.cacheMaxLimit));
/* 2052 */     properties.setProperty("InitialLimit", String.valueOf(this.cacheInitialLimit));
/*      */     
/* 2054 */     properties.setProperty("MaxStatementsLimit", String.valueOf(this.cacheMaxStatementsLimit));
/*      */ 
/*      */     
/* 2057 */     if (this.cacheAttributeWeights != null) {
/* 2058 */       properties.put("AttributeWeights", this.cacheAttributeWeights);
/*      */     } else {
/* 2060 */       properties.setProperty("AttributeWeights", "NULL");
/*      */     } 
/* 2062 */     properties.setProperty("InactivityTimeout", String.valueOf(this.cacheInactivityTimeout));
/*      */     
/* 2064 */     properties.setProperty("TimeToLiveTimeout", String.valueOf(this.cacheTimeToLiveTimeout));
/*      */     
/* 2066 */     properties.setProperty("AbandonedConnectionTimeout", String.valueOf(this.cacheAbandonedConnectionTimeout));
/*      */     
/* 2068 */     properties.setProperty("LowerThresholdLimit", String.valueOf(this.cacheLowerThresholdLimit));
/*      */     
/* 2070 */     properties.setProperty("PropertyCheckInterval", String.valueOf(this.cachePropertyCheckInterval));
/*      */     
/* 2072 */     properties.setProperty("ConnectionWaitTimeout", String.valueOf(this.cacheConnectionWaitTimeout));
/*      */     
/* 2074 */     properties.setProperty("ValidateConnection", String.valueOf(this.cacheValidateConnection));
/*      */     
/* 2076 */     properties.setProperty("ClosestConnectionMatch", String.valueOf(this.cacheClosestConnectionMatch));
/*      */     
/* 2078 */     properties.setProperty("LocalTransactionCommitOnClose", String.valueOf(this.cacheLocalTxnCommitOnClose));
/*      */ 
/*      */     
/* 2081 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int testDatabaseConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 2093 */     return paramOracleConnection.pingDatabase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void closeConnectionCache(int paramInt) throws SQLException {
/* 2110 */     cleanupTimeoutThread();
/*      */ 
/*      */ 
/*      */     
/* 2114 */     purgeCacheConnections(true, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2121 */     this.connectionPoolDS = null;
/* 2122 */     this.cacheEnabledDS = null;
/* 2123 */     this.checkedOutConnectionList = null;
/* 2124 */     this.userMap = null;
/* 2125 */     this.cacheManager = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void disableConnectionCache() throws SQLException {
/* 2137 */     this.disableConnectionRequest = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void enableConnectionCache() throws SQLException {
/* 2149 */     this.disableConnectionRequest = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initFailoverParameters(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 2163 */     String str1 = null;
/* 2164 */     String str2 = null;
/* 2165 */     String str3 = null;
/*      */     
/* 2167 */     Properties properties = ((OracleConnection)paramOraclePooledConnection.getPhysicalHandle()).getServerSessionInfo();
/*      */     
/* 2169 */     str3 = properties.getProperty("INSTANCE_NAME");
/* 2170 */     if (str3 != null) {
/* 2171 */       str1 = paramOraclePooledConnection.dataSourceInstanceNameKey = str3.trim().toLowerCase().intern();
/*      */     }
/*      */ 
/*      */     
/* 2175 */     str3 = properties.getProperty("SERVER_HOST");
/* 2176 */     if (str3 != null) {
/* 2177 */       paramOraclePooledConnection.dataSourceHostNameKey = str3.trim().toLowerCase().intern();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2182 */     str3 = properties.getProperty("SERVICE_NAME");
/* 2183 */     if (str3 != null) {
/* 2184 */       this.dataSourceServiceName = str3.trim();
/*      */     }
/*      */ 
/*      */     
/* 2188 */     str3 = properties.getProperty("DATABASE_NAME");
/* 2189 */     if (str3 != null) {
/* 2190 */       str2 = paramOraclePooledConnection.dataSourceDbUniqNameKey = str3.trim().toLowerCase().intern();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2197 */     if (this.databaseInstancesList == null) {
/* 2198 */       this.databaseInstancesList = new LinkedList();
/*      */     }
/* 2200 */     int i = this.databaseInstancesList.size();
/* 2201 */     synchronized (this.databaseInstancesList) {
/*      */       
/* 2203 */       OracleDatabaseInstance oracleDatabaseInstance = null;
/* 2204 */       boolean bool = false;
/*      */       
/* 2206 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 2208 */         oracleDatabaseInstance = this.databaseInstancesList.get(b);
/* 2209 */         if (oracleDatabaseInstance.databaseUniqName == str2 && oracleDatabaseInstance.instanceName == str1) {
/*      */ 
/*      */           
/* 2212 */           oracleDatabaseInstance.numberOfConnectionsCount++;
/* 2213 */           bool = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 2218 */       if (!bool) {
/*      */         
/* 2220 */         OracleDatabaseInstance oracleDatabaseInstance1 = new OracleDatabaseInstance(str2, str1);
/*      */ 
/*      */         
/* 2223 */         oracleDatabaseInstance1.numberOfConnectionsCount++;
/* 2224 */         this.databaseInstancesList.add(oracleDatabaseInstance1);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void processFailoverEvent(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt2) {
/* 2251 */     if (paramInt1 == 256) {
/*      */       
/* 2253 */       if (paramString4.equalsIgnoreCase("down") || paramString4.equalsIgnoreCase("not_restarting") || paramString4.equalsIgnoreCase("restart_failed"))
/*      */       {
/*      */ 
/*      */         
/* 2257 */         this.downEventCount++;
/*      */         
/* 2259 */         markDownLostConnections(true, false, paramString1, paramString2, paramString3, paramString4);
/*      */         
/* 2261 */         cleanupFailoverConnections(true, false, paramString1, paramString2, paramString3, paramString4);
/*      */       
/*      */       }
/* 2264 */       else if (paramString4.equalsIgnoreCase("up"))
/*      */       {
/*      */ 
/*      */         
/* 2268 */         if (this.downEventCount > 0) {
/* 2269 */           this.upEventCount++;
/*      */         }
/*      */         
/*      */         try {
/* 2273 */           processUpEvent(paramInt2);
/*      */         }
/* 2275 */         catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2281 */         this.isEntireServiceDownProcessed = false;
/*      */       }
/*      */     
/* 2284 */     } else if (paramInt1 == 512 && paramString4.equalsIgnoreCase("nodedown")) {
/*      */ 
/*      */ 
/*      */       
/* 2288 */       markDownLostConnections(false, true, paramString1, paramString2, paramString3, paramString4);
/*      */       
/* 2290 */       cleanupFailoverConnections(false, true, paramString1, paramString2, paramString3, paramString4);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void processUpEvent(int paramInt) throws SQLException {
/* 2367 */     int i = 0;
/* 2368 */     int j = 0;
/* 2369 */     int k = getTotalCachedConnections();
/* 2370 */     boolean bool = false;
/*      */     
/* 2372 */     synchronized (this) {
/*      */ 
/*      */ 
/*      */       
/* 2376 */       if (paramInt <= 1) {
/* 2377 */         paramInt = 2;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2384 */       if (this.downEventCount == 0 && this.upEventCount == 0 && getNumberOfDefaultUserConnections() > 0) {
/*      */ 
/*      */ 
/*      */         
/* 2388 */         i = (int)(this.cacheSize * 0.25D);
/*      */       }
/*      */       else {
/*      */         
/* 2392 */         i = this.defaultUserPreFailureSize;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2404 */       if (i <= 0) {
/*      */         
/* 2406 */         if (getNumberOfDefaultUserConnections() > 0)
/*      */         {
/* 2408 */           j = (int)(this.cacheSize * 0.25D);
/* 2409 */           bool = true;
/*      */         }
/*      */         else
/*      */         {
/*      */           return;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 2418 */         j = i / paramInt;
/*      */ 
/*      */ 
/*      */         
/* 2422 */         if (j + k > this.cacheMaxLimit) {
/* 2423 */           bool = true;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2438 */       if (this.downEventCount == this.upEventCount) {
/*      */         
/* 2440 */         this.defaultUserPreFailureSize = 0;
/* 2441 */         this.downEventCount = 0;
/* 2442 */         this.upEventCount = 0;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2447 */     if (j > 0) {
/* 2448 */       loadBalanceConnections(j, bool);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadBalanceConnections(int paramInt, boolean paramBoolean) throws SQLException {
/* 2460 */     if (paramBoolean) {
/*      */       
/* 2462 */       this.connectionsToRemove = paramInt;
/*      */       
/* 2464 */       doForEveryCachedConnection(8);
/*      */       
/* 2466 */       this.connectionsToRemove = 0;
/*      */     } 
/*      */ 
/*      */     
/* 2470 */     if (paramInt <= 10) {
/*      */ 
/*      */       
/*      */       try {
/* 2474 */         defaultUserPrePopulateCache(paramInt);
/*      */       }
/* 2476 */       catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2486 */       int i = (int)(paramInt * 0.25D);
/*      */       
/* 2488 */       for (byte b = 0; b < 4; b++) {
/*      */ 
/*      */         
/*      */         try {
/* 2492 */           defaultUserPrePopulateCache(i);
/*      */         }
/* 2494 */         catch (Exception exception) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getNumberOfDefaultUserConnections() {
/* 2511 */     int i = 0;
/*      */     
/* 2513 */     if (this.userMap != null && !this.userMap.isEmpty()) {
/*      */ 
/*      */       
/* 2516 */       OracleConnectionCacheEntry oracleConnectionCacheEntry = (OracleConnectionCacheEntry)this.userMap.get(OraclePooledConnection.generateKey(this.defaultUser, this.defaultPassword));
/*      */ 
/*      */ 
/*      */       
/* 2520 */       if (oracleConnectionCacheEntry != null && oracleConnectionCacheEntry.userConnList != null && !oracleConnectionCacheEntry.userConnList.isEmpty())
/*      */       {
/*      */         
/* 2523 */         i = oracleConnectionCacheEntry.userConnList.size();
/*      */       }
/*      */     } 
/* 2526 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void markDownLostConnections(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, String paramString3, String paramString4) {
/* 2547 */     if (!this.isEntireServiceDownProcessed) {
/*      */       
/* 2549 */       if (this.userMap != null && !this.userMap.isEmpty()) {
/*      */ 
/*      */ 
/*      */         
/* 2553 */         Iterator<Map.Entry> iterator = this.userMap.entrySet().iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2561 */         while (iterator.hasNext()) {
/*      */           
/* 2563 */           boolean bool = false;
/*      */           
/* 2565 */           Map.Entry entry = iterator.next();
/* 2566 */           String str = null;
/* 2567 */           if (this.defaultUser != null && this.defaultPassword != null) {
/* 2568 */             str = this.defaultUser + this.defaultPassword;
/*      */           }
/*      */           
/* 2571 */           if (str != null && str.equalsIgnoreCase((String)entry.getKey()))
/*      */           {
/* 2573 */             bool = true;
/*      */           }
/* 2575 */           OracleConnectionCacheEntry oracleConnectionCacheEntry = (OracleConnectionCacheEntry)entry.getValue();
/*      */ 
/*      */ 
/*      */           
/* 2579 */           if (oracleConnectionCacheEntry != null && oracleConnectionCacheEntry.userConnList != null && !oracleConnectionCacheEntry.userConnList.isEmpty()) {
/*      */ 
/*      */             
/* 2582 */             boolean bool1 = false;
/* 2583 */             Iterator<OraclePooledConnection> iterator1 = oracleConnectionCacheEntry.userConnList.iterator();
/*      */             
/* 2585 */             while (iterator1.hasNext()) {
/*      */               
/* 2587 */               OraclePooledConnection oraclePooledConnection = iterator1.next();
/*      */               
/* 2589 */               if (paramBoolean1) {
/* 2590 */                 bool1 = markDownConnectionsForServiceEvent(paramString1, paramString2, oraclePooledConnection);
/*      */               }
/* 2592 */               else if (paramBoolean2) {
/* 2593 */                 bool1 = markDownConnectionsForHostEvent(paramString3, oraclePooledConnection);
/*      */               } 
/*      */ 
/*      */               
/* 2597 */               if (bool1 && bool) {
/* 2598 */                 this.defaultUserPreFailureSize++;
/*      */               }
/*      */             } 
/*      */           } 
/*      */           
/* 2603 */           if (oracleConnectionCacheEntry != null && oracleConnectionCacheEntry.attrConnMap != null && !oracleConnectionCacheEntry.attrConnMap.isEmpty()) {
/*      */ 
/*      */             
/* 2606 */             Iterator<Map.Entry> iterator1 = oracleConnectionCacheEntry.attrConnMap.entrySet().iterator();
/*      */             
/* 2608 */             while (iterator1.hasNext()) {
/*      */               
/* 2610 */               Map.Entry entry1 = iterator1.next();
/* 2611 */               Iterator<OraclePooledConnection> iterator2 = ((Vector)entry1.getValue()).iterator();
/*      */               
/* 2613 */               while (iterator2.hasNext()) {
/*      */                 
/* 2615 */                 OraclePooledConnection oraclePooledConnection = iterator2.next();
/*      */                 
/* 2617 */                 if (paramBoolean1) {
/* 2618 */                   markDownConnectionsForServiceEvent(paramString1, paramString2, oraclePooledConnection); continue;
/*      */                 } 
/* 2620 */                 if (paramBoolean2) {
/* 2621 */                   markDownConnectionsForHostEvent(paramString3, oraclePooledConnection);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 2628 */       if (paramString1 == null) {
/* 2629 */         this.isEntireServiceDownProcessed = true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean markDownConnectionsForServiceEvent(String paramString1, String paramString2, OraclePooledConnection paramOraclePooledConnection) {
/* 2643 */     boolean bool = false;
/*      */     
/* 2645 */     if (paramString1 == null || (paramString2 == paramOraclePooledConnection.dataSourceDbUniqNameKey && paramString1 == paramOraclePooledConnection.dataSourceInstanceNameKey)) {
/*      */ 
/*      */ 
/*      */       
/* 2649 */       paramOraclePooledConnection.connectionMarkedDown = true;
/* 2650 */       bool = true;
/*      */     } 
/*      */     
/* 2653 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean markDownConnectionsForHostEvent(String paramString, OraclePooledConnection paramOraclePooledConnection) {
/* 2664 */     boolean bool = false;
/*      */     
/* 2666 */     if (paramString == paramOraclePooledConnection.dataSourceHostNameKey) {
/*      */       
/* 2668 */       paramOraclePooledConnection.connectionMarkedDown = true;
/* 2669 */       paramOraclePooledConnection.needToAbort = true;
/* 2670 */       bool = true;
/*      */     } 
/* 2672 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void cleanupFailoverConnections(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2, String paramString3, String paramString4) {
/* 2694 */     OraclePooledConnection oraclePooledConnection = null;
/* 2695 */     Object[] arrayOfObject = this.checkedOutConnectionList.toArray();
/* 2696 */     int i = this.checkedOutConnectionList.size();
/*      */     
/* 2698 */     OraclePooledConnection[] arrayOfOraclePooledConnection = new OraclePooledConnection[i];
/* 2699 */     byte b1 = 0;
/*      */     byte b2;
/* 2701 */     for (b2 = 0; b2 < i; b2++) {
/*      */ 
/*      */       
/*      */       try {
/* 2705 */         oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b2];
/*      */         
/* 2707 */         if ((paramBoolean1 && (paramString1 == null || paramString1 == oraclePooledConnection.dataSourceInstanceNameKey) && paramString2 == oraclePooledConnection.dataSourceDbUniqNameKey) || (paramBoolean2 && paramString3 == oraclePooledConnection.dataSourceHostNameKey))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2714 */           if (oraclePooledConnection.isSameUser(this.defaultUser, this.defaultPassword) && oraclePooledConnection.cachedConnectionAttributes != null && oraclePooledConnection.cachedConnectionAttributes.isEmpty())
/*      */           {
/*      */             
/* 2717 */             this.defaultUserPreFailureSize++;
/*      */           }
/*      */           
/* 2720 */           this.checkedOutConnectionList.removeElement(oraclePooledConnection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2727 */           abortConnection(oraclePooledConnection);
/* 2728 */           oraclePooledConnection.needToAbort = true;
/*      */ 
/*      */           
/* 2731 */           arrayOfOraclePooledConnection[b1++] = oraclePooledConnection;
/*      */         }
/*      */       
/* 2734 */       } catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2741 */     for (b2 = 0; b2 < b1; b2++) {
/*      */ 
/*      */       
/*      */       try {
/* 2745 */         closeCheckedOutConnection(arrayOfOraclePooledConnection[b2], false);
/*      */       }
/* 2747 */       catch (SQLException sQLException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2754 */     if (this.checkedOutConnectionList.size() < i && this.cacheConnectionWaitTimeout > 0)
/*      */     {
/*      */       
/* 2757 */       notifyAll();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2763 */       doForEveryCachedConnection(2);
/*      */     }
/* 2765 */     catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2772 */     if (this.databaseInstancesList != null && (i = this.databaseInstancesList.size()) > 0)
/*      */     {
/*      */       
/* 2775 */       synchronized (this.databaseInstancesList) {
/*      */         
/* 2777 */         OracleDatabaseInstance oracleDatabaseInstance = null;
/* 2778 */         arrayOfObject = this.databaseInstancesList.toArray();
/*      */         
/* 2780 */         for (byte b = 0; b < i; b++) {
/*      */           
/* 2782 */           oracleDatabaseInstance = (OracleDatabaseInstance)arrayOfObject[b];
/*      */           
/* 2784 */           if (oracleDatabaseInstance.databaseUniqName == paramString2 && oracleDatabaseInstance.instanceName == paramString1) {
/*      */ 
/*      */ 
/*      */             
/* 2788 */             if (oracleDatabaseInstance.flag <= 3)
/* 2789 */               this.dbInstancePercentTotal -= oracleDatabaseInstance.percent; 
/* 2790 */             this.databaseInstancesList.remove(oracleDatabaseInstance);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void zapRLBInfo() {
/* 2804 */     this.databaseInstancesList.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void closeAndRemovePooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 2816 */     if (paramOraclePooledConnection != null) {
/*      */       
/* 2818 */       if (paramOraclePooledConnection.needToAbort) {
/* 2819 */         abortConnection(paramOraclePooledConnection);
/*      */       }
/* 2821 */       actualPooledConnectionClose(paramOraclePooledConnection);
/* 2822 */       removeCacheConnection(paramOraclePooledConnection);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void abortConnection(OraclePooledConnection paramOraclePooledConnection) {
/*      */     try {
/* 2841 */       ((OracleConnection)paramOraclePooledConnection.getPhysicalHandle()).abort();
/* 2842 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void actualPooledConnectionClose(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 2861 */     int i = 0;
/* 2862 */     if (this.databaseInstancesList != null && (i = this.databaseInstancesList.size()) > 0)
/*      */     {
/*      */       
/* 2865 */       synchronized (this.databaseInstancesList) {
/*      */         
/* 2867 */         OracleDatabaseInstance oracleDatabaseInstance = null;
/*      */         
/* 2869 */         for (byte b = 0; b < i; b++) {
/*      */           
/* 2871 */           oracleDatabaseInstance = this.databaseInstancesList.get(b);
/* 2872 */           if (oracleDatabaseInstance.databaseUniqName == paramOraclePooledConnection.dataSourceDbUniqNameKey && oracleDatabaseInstance.instanceName == paramOraclePooledConnection.dataSourceInstanceNameKey) {
/*      */ 
/*      */             
/* 2875 */             if (oracleDatabaseInstance.numberOfConnectionsCount > 0) {
/* 2876 */               oracleDatabaseInstance.numberOfConnectionsCount--;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2890 */       this.connectionClosedCount++;
/* 2891 */       paramOraclePooledConnection.close();
/*      */     }
/* 2893 */     catch (SQLException sQLException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getCacheTimeToLiveTimeout() {
/* 2903 */     return this.cacheTimeToLiveTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getCacheInactivityTimeout() {
/* 2910 */     return this.cacheInactivityTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getCachePropertyCheckInterval() {
/* 2917 */     return this.cachePropertyCheckInterval;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getCacheAbandonedTimeout() {
/* 2924 */     return this.cacheAbandonedConnectionTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void processConnectionCacheCallback() throws SQLException {
/* 2939 */     float f = this.cacheMaxLimit / 100.0F;
/* 2940 */     int i = (int)(this.cacheLowerThresholdLimit * f);
/*      */ 
/*      */     
/* 2943 */     releaseBasedOnPriority(1024, i);
/*      */ 
/*      */     
/* 2946 */     if (this.cacheSize < i) {
/* 2947 */       releaseBasedOnPriority(512, i);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void releaseBasedOnPriority(int paramInt1, int paramInt2) throws SQLException {
/* 2960 */     Object[] arrayOfObject = this.checkedOutConnectionList.toArray();
/*      */     
/* 2962 */     for (byte b = 0; b < arrayOfObject.length && this.cacheSize < paramInt2; b++) {
/*      */       
/* 2964 */       OraclePooledConnection oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b];
/* 2965 */       OracleConnection oracleConnection = null;
/*      */       
/* 2967 */       if (oraclePooledConnection != null) {
/* 2968 */         oracleConnection = (OracleConnection)oraclePooledConnection.getLogicalHandle();
/*      */       }
/* 2970 */       if (oracleConnection != null) {
/*      */         
/* 2972 */         OracleConnectionCacheCallback oracleConnectionCacheCallback = oracleConnection.getConnectionCacheCallbackObj();
/*      */ 
/*      */         
/* 2975 */         if (oracleConnectionCacheCallback != null && (oracleConnection.getConnectionCacheCallbackFlag() == 2 || oracleConnection.getConnectionCacheCallbackFlag() == 4))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2981 */           if (paramInt1 == oracleConnection.getConnectionReleasePriority()) {
/*      */             
/* 2983 */             Object object = oracleConnection.getConnectionCacheCallbackPrivObj();
/* 2984 */             oracleConnectionCacheCallback.releaseConnection((OracleConnection)oracleConnection, object);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void processConnectionWaitTimeout(long paramLong) throws SQLException {
/*      */     try {
/* 3005 */       wait(paramLong);
/*      */     }
/* 3007 */     catch (InterruptedException interruptedException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processInactivityTimeout(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 3027 */     long l1 = paramOraclePooledConnection.getLastAccessedTime();
/* 3028 */     long l2 = System.currentTimeMillis();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3036 */     if (getTotalCachedConnections() > this.cacheMinLimit && l2 - l1 > (this.cacheInactivityTimeout * 1000))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3042 */       closeAndRemovePooledConnection(paramOraclePooledConnection);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cleanupTimeoutThread() throws SQLException {
/* 3056 */     if (this.timeoutThread != null) {
/*      */       
/* 3058 */       this.timeoutThread.timeToLive = false;
/*      */ 
/*      */ 
/*      */       
/* 3062 */       if (this.timeoutThread.isSleeping) {
/* 3063 */         this.timeoutThread.interrupt();
/*      */       }
/* 3065 */       this.timeoutThread = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void purgeCacheConnections(boolean paramBoolean, int paramInt) {
/*      */     try {
/* 3082 */       if (paramBoolean) {
/* 3083 */         doForEveryCheckedOutConnection(paramInt);
/*      */       }
/*      */       
/* 3086 */       doForEveryCachedConnection(paramInt);
/*      */     }
/* 3088 */     catch (SQLException sQLException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateDatabaseInstance(String paramString1, String paramString2, int paramInt1, int paramInt2) {
/* 3103 */     if (this.databaseInstancesList == null) {
/* 3104 */       this.databaseInstancesList = new LinkedList();
/*      */     }
/* 3106 */     synchronized (this.databaseInstancesList) {
/*      */       
/* 3108 */       int i = this.databaseInstancesList.size();
/* 3109 */       boolean bool = false;
/*      */       
/* 3111 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 3113 */         OracleDatabaseInstance oracleDatabaseInstance = this.databaseInstancesList.get(b);
/*      */         
/* 3115 */         if (oracleDatabaseInstance.databaseUniqName == paramString1 && oracleDatabaseInstance.instanceName == paramString2) {
/*      */ 
/*      */           
/* 3118 */           oracleDatabaseInstance.percent = paramInt1;
/* 3119 */           oracleDatabaseInstance.flag = paramInt2;
/* 3120 */           bool = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 3125 */       if (!bool) {
/*      */         
/* 3127 */         OracleDatabaseInstance oracleDatabaseInstance = new OracleDatabaseInstance(paramString1, paramString2);
/*      */ 
/*      */         
/* 3130 */         oracleDatabaseInstance.percent = paramInt1;
/* 3131 */         oracleDatabaseInstance.flag = paramInt2;
/*      */         
/* 3133 */         this.databaseInstancesList.add(oracleDatabaseInstance);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void processDatabaseInstances() throws SQLException {
/* 3148 */     OracleDatabaseInstance oracleDatabaseInstance = null;
/*      */     
/* 3150 */     if (this.databaseInstancesList != null) {
/*      */       
/* 3152 */       synchronized (this.databaseInstancesList) {
/*      */         
/* 3154 */         int i = 0;
/* 3155 */         boolean bool = false;
/*      */ 
/*      */         
/* 3158 */         this.useGoodGroup = false;
/*      */ 
/*      */         
/* 3161 */         int j = this.databaseInstancesList.size();
/*      */         byte b;
/* 3163 */         for (b = 0; b < j; b++) {
/*      */           
/* 3165 */           oracleDatabaseInstance = this.databaseInstancesList.get(b);
/*      */ 
/*      */ 
/*      */           
/* 3169 */           if (oracleDatabaseInstance.flag <= 3) {
/* 3170 */             i += oracleDatabaseInstance.percent;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 3176 */         if (i > 0) {
/*      */           
/* 3178 */           this.dbInstancePercentTotal = i;
/* 3179 */           this.useGoodGroup = true;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3186 */         if (j > 1) {
/*      */ 
/*      */           
/* 3189 */           for (b = 0; b < j; b++) {
/*      */             
/* 3191 */             oracleDatabaseInstance = this.databaseInstancesList.get(b);
/* 3192 */             this.countTotal += oracleDatabaseInstance.attemptedConnRequestCount;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3200 */           if (this.countTotal > j * 1000) {
/*      */             
/* 3202 */             for (b = 0; b < j; b++) {
/*      */               
/* 3204 */               oracleDatabaseInstance = this.databaseInstancesList.get(b);
/*      */ 
/*      */               
/* 3207 */               float f1 = oracleDatabaseInstance.attemptedConnRequestCount / this.countTotal;
/*      */               
/* 3209 */               float f2 = oracleDatabaseInstance.numberOfConnectionsCount / getTotalCachedConnections();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3222 */               if (f2 > f1 * 2.0F) {
/*      */ 
/*      */ 
/*      */                 
/* 3226 */                 if ((int)(oracleDatabaseInstance.numberOfConnectionsCount * 0.25D) >= 1) {
/* 3227 */                   this.instancesToRetireQueue.addElement(oracleDatabaseInstance);
/*      */                 }
/* 3229 */                 bool = true;
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/* 3234 */             if (bool) {
/*      */               
/* 3236 */               for (b = 0; b < j; b++) {
/*      */                 
/* 3238 */                 oracleDatabaseInstance = this.databaseInstancesList.get(b);
/*      */                 
/* 3240 */                 oracleDatabaseInstance.attemptedConnRequestCount = 0;
/*      */               } 
/* 3242 */               bool = false;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3259 */       if (this.instancesToRetireQueue.size() > 0) {
/*      */         
/* 3261 */         if (this.gravitateCacheThread != null) {
/*      */ 
/*      */           
/*      */           try {
/* 3265 */             this.gravitateCacheThread.interrupt();
/* 3266 */             this.gravitateCacheThread.join();
/*      */           }
/* 3268 */           catch (InterruptedException interruptedException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3273 */           this.gravitateCacheThread = null;
/*      */         } 
/*      */ 
/*      */         
/* 3277 */         this.gravitateCacheThread = new OracleGravitateConnectionCacheThread(this);
/*      */ 
/*      */         
/* 3280 */         this.cacheManager.checkAndStartThread(this.gravitateCacheThread);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void gravitateCache() {
/* 3295 */     while (this.instancesToRetireQueue.size() > 0) {
/*      */ 
/*      */       
/* 3298 */       this.instanceToRetire = this.instancesToRetireQueue.remove(0);
/* 3299 */       this.retireConnectionsCount = (int)(this.instanceToRetire.numberOfConnectionsCount * 0.25D);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 3307 */         doForEveryCachedConnection(24);
/*      */       }
/* 3309 */       catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3321 */       if (this.retireConnectionsCount > 0) {
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */           
/* 3327 */           doForEveryCheckedOutConnection(24);
/*      */         
/*      */         }
/* 3330 */         catch (SQLException sQLException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3338 */     this.retireConnectionsCount = 0;
/* 3339 */     this.instanceToRetire = null;
/* 3340 */     this.countTotal = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cleanupRLBThreads() {
/* 3359 */     if (this.gravitateCacheThread != null) {
/*      */ 
/*      */       
/*      */       try {
/* 3363 */         this.gravitateCacheThread.interrupt();
/* 3364 */         this.gravitateCacheThread.join();
/*      */       }
/* 3366 */       catch (InterruptedException interruptedException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3371 */       this.gravitateCacheThread = null;
/*      */     } 
/*      */     
/* 3374 */     if (this.runtimeLoadBalancingThread != null) {
/*      */ 
/*      */       
/*      */       try {
/* 3378 */         this.runtimeLoadBalancingThread.interrupt();
/*      */       }
/* 3380 */       catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3385 */       this.runtimeLoadBalancingThread = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map getStatistics() throws SQLException {
/* 3397 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>(2);
/* 3398 */     hashMap.put("PhysicalConnectionClosedCount", new Integer(this.connectionClosedCount));
/* 3399 */     hashMap.put("PhysicalConnectionCreatedCount", new Integer(this.connectionCreatedCount));
/*      */     
/* 3401 */     return hashMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 3416 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 3421 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\pool\OracleImplicitConnectionCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */