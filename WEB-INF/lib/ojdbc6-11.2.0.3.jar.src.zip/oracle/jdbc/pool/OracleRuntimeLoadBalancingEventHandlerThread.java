/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.sql.SQLException;
/*     */ import oracle.ons.Notification;
/*     */ import oracle.ons.ONSException;
/*     */ import oracle.ons.Subscriber;
/*     */ import oracle.ons.SubscriptionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleRuntimeLoadBalancingEventHandlerThread
/*     */   extends Thread
/*     */ {
/*  41 */   private Notification event = null;
/*  42 */   private OracleConnectionCacheManager cacheManager = null;
/*     */ 
/*     */   
/*     */   String m_service;
/*     */ 
/*     */ 
/*     */   
/*     */   OracleRuntimeLoadBalancingEventHandlerThread(String paramString) throws SQLException {
/*  50 */     this.m_service = paramString;
/*  51 */     this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  60 */     Subscriber subscriber = null;
/*     */ 
/*     */     
/*  63 */     final String type = "%\"eventType=database/event/servicemetrics/" + this.m_service + "\"";
/*     */ 
/*     */     
/*  66 */     while (this.cacheManager.failoverEnabledCacheExists()) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/*  71 */         subscriber = AccessController.<Subscriber>doPrivileged(new PrivilegedExceptionAction<Subscriber>()
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               public Object run()
/*     */               {
/*     */                 try {
/*  80 */                   return new Subscriber(type, "", 30000L);
/*     */                 }
/*  82 */                 catch (SubscriptionException subscriptionException) {
/*     */ 
/*     */                   
/*  85 */                   return null;
/*     */                 }
/*     */               
/*     */               }
/*     */             });
/*  90 */       } catch (PrivilegedActionException privilegedActionException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  96 */       if (subscriber != null) {
/*     */         
/*     */         try {
/*     */           
/* 100 */           while (this.cacheManager.failoverEnabledCacheExists()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 106 */             if ((this.event = subscriber.receive(300000L)) != null) {
/* 107 */               handleEvent(this.event);
/*     */             }
/*     */           } 
/* 110 */         } catch (ONSException oNSException) {
/*     */           
/* 112 */           subscriber.close();
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 120 */         Thread.currentThread(); Thread.sleep(10000L);
/*     */       }
/* 122 */       catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleEvent(Notification paramNotification) {
/*     */     try {
/* 136 */       this.cacheManager.parseRuntimeLoadBalancingEvent(this.m_service, (paramNotification == null) ? null : paramNotification.body());
/*     */     }
/* 138 */     catch (SQLException sQLException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\pool\OracleRuntimeLoadBalancingEventHandlerThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */