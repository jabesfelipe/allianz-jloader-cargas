/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleImplicitConnectionCacheThread
/*     */   extends Thread
/*     */ {
/*  35 */   private OracleImplicitConnectionCache implicitCache = null;
/*     */ 
/*     */   
/*     */   protected boolean timeToLive = true;
/*     */ 
/*     */   
/*     */   protected boolean isSleeping = false;
/*     */ 
/*     */   
/*     */   OracleImplicitConnectionCacheThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
/*  45 */     this.implicitCache = paramOracleImplicitConnectionCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  53 */     long l1 = 0L;
/*  54 */     long l2 = 0L;
/*  55 */     long l3 = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     while (this.timeToLive) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/*  66 */         if (this.timeToLive && (l1 = this.implicitCache.getCacheTimeToLiveTimeout()) > 0L)
/*     */         {
/*     */           
/*  69 */           runTimeToLiveTimeout(l1);
/*     */         }
/*     */ 
/*     */         
/*  73 */         if (this.timeToLive && (l2 = this.implicitCache.getCacheInactivityTimeout()) > 0L)
/*     */         {
/*  75 */           runInactivityTimeout();
/*     */         }
/*     */ 
/*     */         
/*  79 */         if (this.timeToLive && (l3 = this.implicitCache.getCacheAbandonedTimeout()) > 0L)
/*     */         {
/*  81 */           runAbandonedTimeout(l3);
/*     */         }
/*     */ 
/*     */         
/*  85 */         if (this.timeToLive) {
/*     */           
/*  87 */           this.isSleeping = true;
/*     */ 
/*     */           
/*     */           try {
/*  91 */             sleep((this.implicitCache.getCachePropertyCheckInterval() * 1000));
/*     */           }
/*  93 */           catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  98 */           this.isSleeping = false;
/*     */         } 
/*     */ 
/*     */         
/* 102 */         if (this.implicitCache == null || (l1 <= 0L && l2 <= 0L && l3 <= 0L))
/*     */         {
/*     */           
/* 105 */           this.timeToLive = false;
/*     */         }
/* 107 */       } catch (SQLException sQLException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runTimeToLiveTimeout(long paramLong) throws SQLException {
/* 121 */     long l1 = 0L;
/* 122 */     long l2 = 0L;
/*     */ 
/*     */     
/* 125 */     if (this.implicitCache.getNumberOfCheckedOutConnections() > 0) {
/*     */       
/* 127 */       OraclePooledConnection oraclePooledConnection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 132 */       synchronized (this.implicitCache) {
/*     */ 
/*     */ 
/*     */         
/* 136 */         Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
/* 137 */         int i = this.implicitCache.checkedOutConnectionList.size();
/*     */         
/* 139 */         for (byte b = 0; b < i; b++) {
/*     */           
/* 141 */           oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b];
/*     */           
/* 143 */           Connection connection = oraclePooledConnection.getLogicalHandle();
/*     */           
/* 145 */           if (connection != null) {
/*     */             
/* 147 */             l2 = ((OracleConnection)connection).getStartTime();
/*     */             
/* 149 */             l1 = System.currentTimeMillis();
/*     */ 
/*     */             
/* 152 */             if (l1 - l2 > paramLong * 1000L) {
/*     */               
/*     */               try {
/*     */ 
/*     */ 
/*     */                 
/* 158 */                 this.implicitCache.closeCheckedOutConnection(oraclePooledConnection, true);
/*     */               }
/* 160 */               catch (SQLException sQLException) {}
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runInactivityTimeout() {
/*     */     try {
/* 180 */       this.implicitCache.doForEveryCachedConnection(4);
/*     */     }
/* 182 */     catch (SQLException sQLException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runAbandonedTimeout(long paramLong) throws SQLException {
/* 198 */     if (this.implicitCache.getNumberOfCheckedOutConnections() > 0) {
/*     */       
/* 200 */       OraclePooledConnection oraclePooledConnection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 205 */       synchronized (this.implicitCache) {
/*     */         
/* 207 */         Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
/*     */ 
/*     */         
/* 210 */         for (byte b = 0; b < arrayOfObject.length; b++) {
/*     */           
/* 212 */           oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b];
/*     */           
/* 214 */           OracleConnection oracleConnection = (OracleConnection)oraclePooledConnection.getLogicalHandle();
/*     */           
/* 216 */           if (oracleConnection != null) {
/*     */ 
/*     */ 
/*     */             
/* 220 */             OracleConnectionCacheCallback oracleConnectionCacheCallback = oracleConnection.getConnectionCacheCallbackObj();
/*     */ 
/*     */ 
/*     */             
/* 224 */             if ((oracleConnection.getHeartbeatNoChangeCount() * this.implicitCache.getCachePropertyCheckInterval()) > paramLong) {
/*     */               
/*     */               try {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 232 */                 boolean bool = true;
/* 233 */                 if (oracleConnectionCacheCallback != null && (oracleConnection.getConnectionCacheCallbackFlag() == 4 || oracleConnection.getConnectionCacheCallbackFlag() == 1))
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 244 */                   bool = oracleConnectionCacheCallback.handleAbandonedConnection((OracleConnection)oracleConnection, oracleConnection.getConnectionCacheCallbackPrivObj());
/*     */                 }
/*     */ 
/*     */ 
/*     */                 
/* 249 */                 if (bool)
/* 250 */                   this.implicitCache.closeCheckedOutConnection(oraclePooledConnection, true); 
/* 251 */               } catch (SQLException sQLException) {}
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 268 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final String BUILD_DATE = "Fri_Aug_26_08:19:15_PDT_2011";
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\pool\OracleImplicitConnectionCacheThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */