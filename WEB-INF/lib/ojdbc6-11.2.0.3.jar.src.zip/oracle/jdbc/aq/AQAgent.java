package oracle.jdbc.aq;

import java.sql.SQLException;

public interface AQAgent {
  void setAddress(String paramString) throws SQLException;
  
  String getAddress();
  
  void setName(String paramString) throws SQLException;
  
  String getName();
  
  void setProtocol(int paramInt) throws SQLException;
  
  int getProtocol();
  
  String toString();
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\aq\AQAgent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */