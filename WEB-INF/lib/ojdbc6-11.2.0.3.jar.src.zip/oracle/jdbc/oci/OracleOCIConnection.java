/*    */ package oracle.jdbc.oci;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import oracle.jdbc.driver.OracleOCIConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleOCIConnection
/*    */   extends OracleOCIConnection
/*    */ {
/*    */   public OracleOCIConnection(String paramString, Properties paramProperties, Object paramObject) throws SQLException {
/* 35 */     super(paramString, paramProperties, paramObject);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\ojdbc6-11.2.0.3.jar!\oracle\jdbc\oci\OracleOCIConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */