/*    */ package org.apache.log4j.lf5.viewer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogTableColumnFormatException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 6529165785030431653L;
/*    */   
/*    */   public LogTableColumnFormatException(String message) {
/* 49 */     super(message);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\log4j-1.2.17.jar!\org\apache\log4j\lf5\viewer\LogTableColumnFormatException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */