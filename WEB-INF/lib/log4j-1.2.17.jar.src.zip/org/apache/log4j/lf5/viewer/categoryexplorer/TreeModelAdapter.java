package org.apache.log4j.lf5.viewer.categoryexplorer;

import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;

public class TreeModelAdapter implements TreeModelListener {
  public void treeNodesChanged(TreeModelEvent e) {}
  
  public void treeNodesInserted(TreeModelEvent e) {}
  
  public void treeNodesRemoved(TreeModelEvent e) {}
  
  public void treeStructureChanged(TreeModelEvent e) {}
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\log4j-1.2.17.jar!\org\apache\log4j\lf5\viewer\categoryexplorer\TreeModelAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */