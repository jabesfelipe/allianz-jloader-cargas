package org.apache.log4j.spi;

import java.io.Writer;

class NullWriter extends Writer {
  public void close() {}
  
  public void flush() {}
  
  public void write(char[] cbuf, int off, int len) {}
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\log4j-1.2.17.jar!\org\apache\log4j\spi\NullWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */