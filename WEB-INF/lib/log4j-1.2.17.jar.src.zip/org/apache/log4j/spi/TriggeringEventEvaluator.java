package org.apache.log4j.spi;

public interface TriggeringEventEvaluator {
  boolean isTriggeringEvent(LoggingEvent paramLoggingEvent);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\log4j-1.2.17.jar!\org\apache\log4j\spi\TriggeringEventEvaluator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */