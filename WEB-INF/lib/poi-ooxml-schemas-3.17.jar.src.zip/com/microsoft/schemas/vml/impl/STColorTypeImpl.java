package com.microsoft.schemas.vml.impl;

import com.microsoft.schemas.vml.STColorType;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringHolderEx;

public class STColorTypeImpl extends JavaStringHolderEx implements STColorType {
  public STColorTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STColorTypeImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\com\microsoft\schemas\vml\impl\STColorTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */