package org.etsi.uri.x01903.v13.impl;

import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CertificateValuesType;
import org.etsi.uri.x01903.v13.CompleteCertificateRefsType;
import org.etsi.uri.x01903.v13.CompleteRevocationRefsType;
import org.etsi.uri.x01903.v13.CounterSignatureType;
import org.etsi.uri.x01903.v13.RevocationValuesType;
import org.etsi.uri.x01903.v13.UnsignedSignaturePropertiesType;
import org.etsi.uri.x01903.v13.XAdESTimeStampType;

public class UnsignedSignaturePropertiesTypeImpl extends XmlComplexContentImpl implements UnsignedSignaturePropertiesType {
  private static final QName COUNTERSIGNATURE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CounterSignature");
  
  private static final QName SIGNATURETIMESTAMP$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SignatureTimeStamp");
  
  private static final QName COMPLETECERTIFICATEREFS$4 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CompleteCertificateRefs");
  
  private static final QName COMPLETEREVOCATIONREFS$6 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CompleteRevocationRefs");
  
  private static final QName ATTRIBUTECERTIFICATEREFS$8 = new QName("http://uri.etsi.org/01903/v1.3.2#", "AttributeCertificateRefs");
  
  private static final QName ATTRIBUTEREVOCATIONREFS$10 = new QName("http://uri.etsi.org/01903/v1.3.2#", "AttributeRevocationRefs");
  
  private static final QName SIGANDREFSTIMESTAMP$12 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SigAndRefsTimeStamp");
  
  private static final QName REFSONLYTIMESTAMP$14 = new QName("http://uri.etsi.org/01903/v1.3.2#", "RefsOnlyTimeStamp");
  
  private static final QName CERTIFICATEVALUES$16 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CertificateValues");
  
  private static final QName REVOCATIONVALUES$18 = new QName("http://uri.etsi.org/01903/v1.3.2#", "RevocationValues");
  
  private static final QName ATTRAUTHORITIESCERTVALUES$20 = new QName("http://uri.etsi.org/01903/v1.3.2#", "AttrAuthoritiesCertValues");
  
  private static final QName ATTRIBUTEREVOCATIONVALUES$22 = new QName("http://uri.etsi.org/01903/v1.3.2#", "AttributeRevocationValues");
  
  private static final QName ARCHIVETIMESTAMP$24 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ArchiveTimeStamp");
  
  private static final QName ID$26 = new QName("", "Id");
  
  public UnsignedSignaturePropertiesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CounterSignatureType> getCounterSignatureList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<CounterSignatureType>)new CounterSignatureList(this);
    } 
  }
  
  public CounterSignatureType[] getCounterSignatureArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(COUNTERSIGNATURE$0, arrayList);
      CounterSignatureType[] arrayOfCounterSignatureType = new CounterSignatureType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCounterSignatureType);
      return arrayOfCounterSignatureType;
    } 
  }
  
  public CounterSignatureType getCounterSignatureArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CounterSignatureType counterSignatureType = null;
      counterSignatureType = (CounterSignatureType)get_store().find_element_user(COUNTERSIGNATURE$0, paramInt);
      if (counterSignatureType == null)
        throw new IndexOutOfBoundsException(); 
      return counterSignatureType;
    } 
  }
  
  public int sizeOfCounterSignatureArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(COUNTERSIGNATURE$0);
    } 
  }
  
  public void setCounterSignatureArray(CounterSignatureType[] paramArrayOfCounterSignatureType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfCounterSignatureType, COUNTERSIGNATURE$0);
    } 
  }
  
  public void setCounterSignatureArray(int paramInt, CounterSignatureType paramCounterSignatureType) {
    synchronized (monitor()) {
      check_orphaned();
      CounterSignatureType counterSignatureType = null;
      counterSignatureType = (CounterSignatureType)get_store().find_element_user(COUNTERSIGNATURE$0, paramInt);
      if (counterSignatureType == null)
        throw new IndexOutOfBoundsException(); 
      counterSignatureType.set((XmlObject)paramCounterSignatureType);
    } 
  }
  
  public CounterSignatureType insertNewCounterSignature(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CounterSignatureType counterSignatureType = null;
      counterSignatureType = (CounterSignatureType)get_store().insert_element_user(COUNTERSIGNATURE$0, paramInt);
      return counterSignatureType;
    } 
  }
  
  public CounterSignatureType addNewCounterSignature() {
    synchronized (monitor()) {
      check_orphaned();
      CounterSignatureType counterSignatureType = null;
      counterSignatureType = (CounterSignatureType)get_store().add_element_user(COUNTERSIGNATURE$0);
      return counterSignatureType;
    } 
  }
  
  public void removeCounterSignature(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(COUNTERSIGNATURE$0, paramInt);
    } 
  }
  
  public List<XAdESTimeStampType> getSignatureTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<XAdESTimeStampType>)new SignatureTimeStampList(this);
    } 
  }
  
  public XAdESTimeStampType[] getSignatureTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SIGNATURETIMESTAMP$2, arrayList);
      XAdESTimeStampType[] arrayOfXAdESTimeStampType = new XAdESTimeStampType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfXAdESTimeStampType);
      return arrayOfXAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType getSignatureTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(SIGNATURETIMESTAMP$2, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      return xAdESTimeStampType;
    } 
  }
  
  public int sizeOfSignatureTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SIGNATURETIMESTAMP$2);
    } 
  }
  
  public void setSignatureTimeStampArray(XAdESTimeStampType[] paramArrayOfXAdESTimeStampType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfXAdESTimeStampType, SIGNATURETIMESTAMP$2);
    } 
  }
  
  public void setSignatureTimeStampArray(int paramInt, XAdESTimeStampType paramXAdESTimeStampType) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(SIGNATURETIMESTAMP$2, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      xAdESTimeStampType.set((XmlObject)paramXAdESTimeStampType);
    } 
  }
  
  public XAdESTimeStampType insertNewSignatureTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().insert_element_user(SIGNATURETIMESTAMP$2, paramInt);
      return xAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType addNewSignatureTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().add_element_user(SIGNATURETIMESTAMP$2);
      return xAdESTimeStampType;
    } 
  }
  
  public void removeSignatureTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNATURETIMESTAMP$2, paramInt);
    } 
  }
  
  public List<CompleteCertificateRefsType> getCompleteCertificateRefsList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<CompleteCertificateRefsType>)new CompleteCertificateRefsList(this);
    } 
  }
  
  public CompleteCertificateRefsType[] getCompleteCertificateRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(COMPLETECERTIFICATEREFS$4, arrayList);
      CompleteCertificateRefsType[] arrayOfCompleteCertificateRefsType = new CompleteCertificateRefsType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCompleteCertificateRefsType);
      return arrayOfCompleteCertificateRefsType;
    } 
  }
  
  public CompleteCertificateRefsType getCompleteCertificateRefsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().find_element_user(COMPLETECERTIFICATEREFS$4, paramInt);
      if (completeCertificateRefsType == null)
        throw new IndexOutOfBoundsException(); 
      return completeCertificateRefsType;
    } 
  }
  
  public int sizeOfCompleteCertificateRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(COMPLETECERTIFICATEREFS$4);
    } 
  }
  
  public void setCompleteCertificateRefsArray(CompleteCertificateRefsType[] paramArrayOfCompleteCertificateRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfCompleteCertificateRefsType, COMPLETECERTIFICATEREFS$4);
    } 
  }
  
  public void setCompleteCertificateRefsArray(int paramInt, CompleteCertificateRefsType paramCompleteCertificateRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().find_element_user(COMPLETECERTIFICATEREFS$4, paramInt);
      if (completeCertificateRefsType == null)
        throw new IndexOutOfBoundsException(); 
      completeCertificateRefsType.set((XmlObject)paramCompleteCertificateRefsType);
    } 
  }
  
  public CompleteCertificateRefsType insertNewCompleteCertificateRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().insert_element_user(COMPLETECERTIFICATEREFS$4, paramInt);
      return completeCertificateRefsType;
    } 
  }
  
  public CompleteCertificateRefsType addNewCompleteCertificateRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().add_element_user(COMPLETECERTIFICATEREFS$4);
      return completeCertificateRefsType;
    } 
  }
  
  public void removeCompleteCertificateRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(COMPLETECERTIFICATEREFS$4, paramInt);
    } 
  }
  
  public List<CompleteRevocationRefsType> getCompleteRevocationRefsList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<CompleteRevocationRefsType>)new CompleteRevocationRefsList(this);
    } 
  }
  
  public CompleteRevocationRefsType[] getCompleteRevocationRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(COMPLETEREVOCATIONREFS$6, arrayList);
      CompleteRevocationRefsType[] arrayOfCompleteRevocationRefsType = new CompleteRevocationRefsType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCompleteRevocationRefsType);
      return arrayOfCompleteRevocationRefsType;
    } 
  }
  
  public CompleteRevocationRefsType getCompleteRevocationRefsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().find_element_user(COMPLETEREVOCATIONREFS$6, paramInt);
      if (completeRevocationRefsType == null)
        throw new IndexOutOfBoundsException(); 
      return completeRevocationRefsType;
    } 
  }
  
  public int sizeOfCompleteRevocationRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(COMPLETEREVOCATIONREFS$6);
    } 
  }
  
  public void setCompleteRevocationRefsArray(CompleteRevocationRefsType[] paramArrayOfCompleteRevocationRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfCompleteRevocationRefsType, COMPLETEREVOCATIONREFS$6);
    } 
  }
  
  public void setCompleteRevocationRefsArray(int paramInt, CompleteRevocationRefsType paramCompleteRevocationRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().find_element_user(COMPLETEREVOCATIONREFS$6, paramInt);
      if (completeRevocationRefsType == null)
        throw new IndexOutOfBoundsException(); 
      completeRevocationRefsType.set((XmlObject)paramCompleteRevocationRefsType);
    } 
  }
  
  public CompleteRevocationRefsType insertNewCompleteRevocationRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().insert_element_user(COMPLETEREVOCATIONREFS$6, paramInt);
      return completeRevocationRefsType;
    } 
  }
  
  public CompleteRevocationRefsType addNewCompleteRevocationRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().add_element_user(COMPLETEREVOCATIONREFS$6);
      return completeRevocationRefsType;
    } 
  }
  
  public void removeCompleteRevocationRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(COMPLETEREVOCATIONREFS$6, paramInt);
    } 
  }
  
  public List<CompleteCertificateRefsType> getAttributeCertificateRefsList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<CompleteCertificateRefsType>)new AttributeCertificateRefsList(this);
    } 
  }
  
  public CompleteCertificateRefsType[] getAttributeCertificateRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ATTRIBUTECERTIFICATEREFS$8, arrayList);
      CompleteCertificateRefsType[] arrayOfCompleteCertificateRefsType = new CompleteCertificateRefsType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCompleteCertificateRefsType);
      return arrayOfCompleteCertificateRefsType;
    } 
  }
  
  public CompleteCertificateRefsType getAttributeCertificateRefsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().find_element_user(ATTRIBUTECERTIFICATEREFS$8, paramInt);
      if (completeCertificateRefsType == null)
        throw new IndexOutOfBoundsException(); 
      return completeCertificateRefsType;
    } 
  }
  
  public int sizeOfAttributeCertificateRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ATTRIBUTECERTIFICATEREFS$8);
    } 
  }
  
  public void setAttributeCertificateRefsArray(CompleteCertificateRefsType[] paramArrayOfCompleteCertificateRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfCompleteCertificateRefsType, ATTRIBUTECERTIFICATEREFS$8);
    } 
  }
  
  public void setAttributeCertificateRefsArray(int paramInt, CompleteCertificateRefsType paramCompleteCertificateRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().find_element_user(ATTRIBUTECERTIFICATEREFS$8, paramInt);
      if (completeCertificateRefsType == null)
        throw new IndexOutOfBoundsException(); 
      completeCertificateRefsType.set((XmlObject)paramCompleteCertificateRefsType);
    } 
  }
  
  public CompleteCertificateRefsType insertNewAttributeCertificateRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().insert_element_user(ATTRIBUTECERTIFICATEREFS$8, paramInt);
      return completeCertificateRefsType;
    } 
  }
  
  public CompleteCertificateRefsType addNewAttributeCertificateRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().add_element_user(ATTRIBUTECERTIFICATEREFS$8);
      return completeCertificateRefsType;
    } 
  }
  
  public void removeAttributeCertificateRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ATTRIBUTECERTIFICATEREFS$8, paramInt);
    } 
  }
  
  public List<CompleteRevocationRefsType> getAttributeRevocationRefsList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<CompleteRevocationRefsType>)new AttributeRevocationRefsList(this);
    } 
  }
  
  public CompleteRevocationRefsType[] getAttributeRevocationRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ATTRIBUTEREVOCATIONREFS$10, arrayList);
      CompleteRevocationRefsType[] arrayOfCompleteRevocationRefsType = new CompleteRevocationRefsType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCompleteRevocationRefsType);
      return arrayOfCompleteRevocationRefsType;
    } 
  }
  
  public CompleteRevocationRefsType getAttributeRevocationRefsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().find_element_user(ATTRIBUTEREVOCATIONREFS$10, paramInt);
      if (completeRevocationRefsType == null)
        throw new IndexOutOfBoundsException(); 
      return completeRevocationRefsType;
    } 
  }
  
  public int sizeOfAttributeRevocationRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ATTRIBUTEREVOCATIONREFS$10);
    } 
  }
  
  public void setAttributeRevocationRefsArray(CompleteRevocationRefsType[] paramArrayOfCompleteRevocationRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfCompleteRevocationRefsType, ATTRIBUTEREVOCATIONREFS$10);
    } 
  }
  
  public void setAttributeRevocationRefsArray(int paramInt, CompleteRevocationRefsType paramCompleteRevocationRefsType) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().find_element_user(ATTRIBUTEREVOCATIONREFS$10, paramInt);
      if (completeRevocationRefsType == null)
        throw new IndexOutOfBoundsException(); 
      completeRevocationRefsType.set((XmlObject)paramCompleteRevocationRefsType);
    } 
  }
  
  public CompleteRevocationRefsType insertNewAttributeRevocationRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().insert_element_user(ATTRIBUTEREVOCATIONREFS$10, paramInt);
      return completeRevocationRefsType;
    } 
  }
  
  public CompleteRevocationRefsType addNewAttributeRevocationRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().add_element_user(ATTRIBUTEREVOCATIONREFS$10);
      return completeRevocationRefsType;
    } 
  }
  
  public void removeAttributeRevocationRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ATTRIBUTEREVOCATIONREFS$10, paramInt);
    } 
  }
  
  public List<XAdESTimeStampType> getSigAndRefsTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<XAdESTimeStampType>)new SigAndRefsTimeStampList(this);
    } 
  }
  
  public XAdESTimeStampType[] getSigAndRefsTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SIGANDREFSTIMESTAMP$12, arrayList);
      XAdESTimeStampType[] arrayOfXAdESTimeStampType = new XAdESTimeStampType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfXAdESTimeStampType);
      return arrayOfXAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType getSigAndRefsTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(SIGANDREFSTIMESTAMP$12, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      return xAdESTimeStampType;
    } 
  }
  
  public int sizeOfSigAndRefsTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SIGANDREFSTIMESTAMP$12);
    } 
  }
  
  public void setSigAndRefsTimeStampArray(XAdESTimeStampType[] paramArrayOfXAdESTimeStampType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfXAdESTimeStampType, SIGANDREFSTIMESTAMP$12);
    } 
  }
  
  public void setSigAndRefsTimeStampArray(int paramInt, XAdESTimeStampType paramXAdESTimeStampType) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(SIGANDREFSTIMESTAMP$12, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      xAdESTimeStampType.set((XmlObject)paramXAdESTimeStampType);
    } 
  }
  
  public XAdESTimeStampType insertNewSigAndRefsTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().insert_element_user(SIGANDREFSTIMESTAMP$12, paramInt);
      return xAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType addNewSigAndRefsTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().add_element_user(SIGANDREFSTIMESTAMP$12);
      return xAdESTimeStampType;
    } 
  }
  
  public void removeSigAndRefsTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGANDREFSTIMESTAMP$12, paramInt);
    } 
  }
  
  public List<XAdESTimeStampType> getRefsOnlyTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<XAdESTimeStampType>)new RefsOnlyTimeStampList(this);
    } 
  }
  
  public XAdESTimeStampType[] getRefsOnlyTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(REFSONLYTIMESTAMP$14, arrayList);
      XAdESTimeStampType[] arrayOfXAdESTimeStampType = new XAdESTimeStampType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfXAdESTimeStampType);
      return arrayOfXAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType getRefsOnlyTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(REFSONLYTIMESTAMP$14, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      return xAdESTimeStampType;
    } 
  }
  
  public int sizeOfRefsOnlyTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(REFSONLYTIMESTAMP$14);
    } 
  }
  
  public void setRefsOnlyTimeStampArray(XAdESTimeStampType[] paramArrayOfXAdESTimeStampType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfXAdESTimeStampType, REFSONLYTIMESTAMP$14);
    } 
  }
  
  public void setRefsOnlyTimeStampArray(int paramInt, XAdESTimeStampType paramXAdESTimeStampType) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(REFSONLYTIMESTAMP$14, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      xAdESTimeStampType.set((XmlObject)paramXAdESTimeStampType);
    } 
  }
  
  public XAdESTimeStampType insertNewRefsOnlyTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().insert_element_user(REFSONLYTIMESTAMP$14, paramInt);
      return xAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType addNewRefsOnlyTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().add_element_user(REFSONLYTIMESTAMP$14);
      return xAdESTimeStampType;
    } 
  }
  
  public void removeRefsOnlyTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(REFSONLYTIMESTAMP$14, paramInt);
    } 
  }
  
  public List<CertificateValuesType> getCertificateValuesList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<CertificateValuesType>)new CertificateValuesList(this);
    } 
  }
  
  public CertificateValuesType[] getCertificateValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CERTIFICATEVALUES$16, arrayList);
      CertificateValuesType[] arrayOfCertificateValuesType = new CertificateValuesType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCertificateValuesType);
      return arrayOfCertificateValuesType;
    } 
  }
  
  public CertificateValuesType getCertificateValuesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().find_element_user(CERTIFICATEVALUES$16, paramInt);
      if (certificateValuesType == null)
        throw new IndexOutOfBoundsException(); 
      return certificateValuesType;
    } 
  }
  
  public int sizeOfCertificateValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CERTIFICATEVALUES$16);
    } 
  }
  
  public void setCertificateValuesArray(CertificateValuesType[] paramArrayOfCertificateValuesType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfCertificateValuesType, CERTIFICATEVALUES$16);
    } 
  }
  
  public void setCertificateValuesArray(int paramInt, CertificateValuesType paramCertificateValuesType) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().find_element_user(CERTIFICATEVALUES$16, paramInt);
      if (certificateValuesType == null)
        throw new IndexOutOfBoundsException(); 
      certificateValuesType.set((XmlObject)paramCertificateValuesType);
    } 
  }
  
  public CertificateValuesType insertNewCertificateValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().insert_element_user(CERTIFICATEVALUES$16, paramInt);
      return certificateValuesType;
    } 
  }
  
  public CertificateValuesType addNewCertificateValues() {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().add_element_user(CERTIFICATEVALUES$16);
      return certificateValuesType;
    } 
  }
  
  public void removeCertificateValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CERTIFICATEVALUES$16, paramInt);
    } 
  }
  
  public List<RevocationValuesType> getRevocationValuesList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<RevocationValuesType>)new RevocationValuesList(this);
    } 
  }
  
  public RevocationValuesType[] getRevocationValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(REVOCATIONVALUES$18, arrayList);
      RevocationValuesType[] arrayOfRevocationValuesType = new RevocationValuesType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfRevocationValuesType);
      return arrayOfRevocationValuesType;
    } 
  }
  
  public RevocationValuesType getRevocationValuesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().find_element_user(REVOCATIONVALUES$18, paramInt);
      if (revocationValuesType == null)
        throw new IndexOutOfBoundsException(); 
      return revocationValuesType;
    } 
  }
  
  public int sizeOfRevocationValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(REVOCATIONVALUES$18);
    } 
  }
  
  public void setRevocationValuesArray(RevocationValuesType[] paramArrayOfRevocationValuesType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfRevocationValuesType, REVOCATIONVALUES$18);
    } 
  }
  
  public void setRevocationValuesArray(int paramInt, RevocationValuesType paramRevocationValuesType) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().find_element_user(REVOCATIONVALUES$18, paramInt);
      if (revocationValuesType == null)
        throw new IndexOutOfBoundsException(); 
      revocationValuesType.set((XmlObject)paramRevocationValuesType);
    } 
  }
  
  public RevocationValuesType insertNewRevocationValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().insert_element_user(REVOCATIONVALUES$18, paramInt);
      return revocationValuesType;
    } 
  }
  
  public RevocationValuesType addNewRevocationValues() {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().add_element_user(REVOCATIONVALUES$18);
      return revocationValuesType;
    } 
  }
  
  public void removeRevocationValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(REVOCATIONVALUES$18, paramInt);
    } 
  }
  
  public List<CertificateValuesType> getAttrAuthoritiesCertValuesList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<CertificateValuesType>)new AttrAuthoritiesCertValuesList(this);
    } 
  }
  
  public CertificateValuesType[] getAttrAuthoritiesCertValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ATTRAUTHORITIESCERTVALUES$20, arrayList);
      CertificateValuesType[] arrayOfCertificateValuesType = new CertificateValuesType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCertificateValuesType);
      return arrayOfCertificateValuesType;
    } 
  }
  
  public CertificateValuesType getAttrAuthoritiesCertValuesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().find_element_user(ATTRAUTHORITIESCERTVALUES$20, paramInt);
      if (certificateValuesType == null)
        throw new IndexOutOfBoundsException(); 
      return certificateValuesType;
    } 
  }
  
  public int sizeOfAttrAuthoritiesCertValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ATTRAUTHORITIESCERTVALUES$20);
    } 
  }
  
  public void setAttrAuthoritiesCertValuesArray(CertificateValuesType[] paramArrayOfCertificateValuesType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfCertificateValuesType, ATTRAUTHORITIESCERTVALUES$20);
    } 
  }
  
  public void setAttrAuthoritiesCertValuesArray(int paramInt, CertificateValuesType paramCertificateValuesType) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().find_element_user(ATTRAUTHORITIESCERTVALUES$20, paramInt);
      if (certificateValuesType == null)
        throw new IndexOutOfBoundsException(); 
      certificateValuesType.set((XmlObject)paramCertificateValuesType);
    } 
  }
  
  public CertificateValuesType insertNewAttrAuthoritiesCertValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().insert_element_user(ATTRAUTHORITIESCERTVALUES$20, paramInt);
      return certificateValuesType;
    } 
  }
  
  public CertificateValuesType addNewAttrAuthoritiesCertValues() {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().add_element_user(ATTRAUTHORITIESCERTVALUES$20);
      return certificateValuesType;
    } 
  }
  
  public void removeAttrAuthoritiesCertValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ATTRAUTHORITIESCERTVALUES$20, paramInt);
    } 
  }
  
  public List<RevocationValuesType> getAttributeRevocationValuesList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<RevocationValuesType>)new AttributeRevocationValuesList(this);
    } 
  }
  
  public RevocationValuesType[] getAttributeRevocationValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ATTRIBUTEREVOCATIONVALUES$22, arrayList);
      RevocationValuesType[] arrayOfRevocationValuesType = new RevocationValuesType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfRevocationValuesType);
      return arrayOfRevocationValuesType;
    } 
  }
  
  public RevocationValuesType getAttributeRevocationValuesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().find_element_user(ATTRIBUTEREVOCATIONVALUES$22, paramInt);
      if (revocationValuesType == null)
        throw new IndexOutOfBoundsException(); 
      return revocationValuesType;
    } 
  }
  
  public int sizeOfAttributeRevocationValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ATTRIBUTEREVOCATIONVALUES$22);
    } 
  }
  
  public void setAttributeRevocationValuesArray(RevocationValuesType[] paramArrayOfRevocationValuesType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfRevocationValuesType, ATTRIBUTEREVOCATIONVALUES$22);
    } 
  }
  
  public void setAttributeRevocationValuesArray(int paramInt, RevocationValuesType paramRevocationValuesType) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().find_element_user(ATTRIBUTEREVOCATIONVALUES$22, paramInt);
      if (revocationValuesType == null)
        throw new IndexOutOfBoundsException(); 
      revocationValuesType.set((XmlObject)paramRevocationValuesType);
    } 
  }
  
  public RevocationValuesType insertNewAttributeRevocationValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().insert_element_user(ATTRIBUTEREVOCATIONVALUES$22, paramInt);
      return revocationValuesType;
    } 
  }
  
  public RevocationValuesType addNewAttributeRevocationValues() {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().add_element_user(ATTRIBUTEREVOCATIONVALUES$22);
      return revocationValuesType;
    } 
  }
  
  public void removeAttributeRevocationValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ATTRIBUTEREVOCATIONVALUES$22, paramInt);
    } 
  }
  
  public List<XAdESTimeStampType> getArchiveTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      return (List<XAdESTimeStampType>)new ArchiveTimeStampList(this);
    } 
  }
  
  public XAdESTimeStampType[] getArchiveTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ARCHIVETIMESTAMP$24, arrayList);
      XAdESTimeStampType[] arrayOfXAdESTimeStampType = new XAdESTimeStampType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfXAdESTimeStampType);
      return arrayOfXAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType getArchiveTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(ARCHIVETIMESTAMP$24, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      return xAdESTimeStampType;
    } 
  }
  
  public int sizeOfArchiveTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ARCHIVETIMESTAMP$24);
    } 
  }
  
  public void setArchiveTimeStampArray(XAdESTimeStampType[] paramArrayOfXAdESTimeStampType) {
    synchronized (monitor()) {
      check_orphaned();
      arraySetterHelper((XmlObject[])paramArrayOfXAdESTimeStampType, ARCHIVETIMESTAMP$24);
    } 
  }
  
  public void setArchiveTimeStampArray(int paramInt, XAdESTimeStampType paramXAdESTimeStampType) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(ARCHIVETIMESTAMP$24, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      xAdESTimeStampType.set((XmlObject)paramXAdESTimeStampType);
    } 
  }
  
  public XAdESTimeStampType insertNewArchiveTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().insert_element_user(ARCHIVETIMESTAMP$24, paramInt);
      return xAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType addNewArchiveTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().add_element_user(ARCHIVETIMESTAMP$24);
      return xAdESTimeStampType;
    } 
  }
  
  public void removeArchiveTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ARCHIVETIMESTAMP$24, paramInt);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$26);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$26);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$26) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$26);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$26); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$26);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$26); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$26);
    } 
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\impl\UnsignedSignaturePropertiesTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */