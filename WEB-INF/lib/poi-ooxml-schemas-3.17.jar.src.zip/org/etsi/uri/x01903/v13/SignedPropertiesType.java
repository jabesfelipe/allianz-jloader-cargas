package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.poi.POIXMLTypeLoader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface SignedPropertiesType extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(SignedPropertiesType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s8C3F193EE11A2F798ACF65489B9E6078").resolveHandle("signedpropertiestype163dtype");
  
  SignedSignaturePropertiesType getSignedSignatureProperties();
  
  boolean isSetSignedSignatureProperties();
  
  void setSignedSignatureProperties(SignedSignaturePropertiesType paramSignedSignaturePropertiesType);
  
  SignedSignaturePropertiesType addNewSignedSignatureProperties();
  
  void unsetSignedSignatureProperties();
  
  SignedDataObjectPropertiesType getSignedDataObjectProperties();
  
  boolean isSetSignedDataObjectProperties();
  
  void setSignedDataObjectProperties(SignedDataObjectPropertiesType paramSignedDataObjectPropertiesType);
  
  SignedDataObjectPropertiesType addNewSignedDataObjectProperties();
  
  void unsetSignedDataObjectProperties();
  
  String getId();
  
  XmlID xgetId();
  
  boolean isSetId();
  
  void setId(String paramString);
  
  void xsetId(XmlID paramXmlID);
  
  void unsetId();
  
  public static final class Factory {
    public static SignedPropertiesType newInstance() {
      return (SignedPropertiesType)POIXMLTypeLoader.newInstance(SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType newInstance(XmlOptions param1XmlOptions) {
      return (SignedPropertiesType)POIXMLTypeLoader.newInstance(SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static SignedPropertiesType parse(String param1String) throws XmlException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1String, SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1String, SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static SignedPropertiesType parse(File param1File) throws XmlException, IOException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1File, SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1File, SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static SignedPropertiesType parse(URL param1URL) throws XmlException, IOException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1URL, SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1URL, SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static SignedPropertiesType parse(InputStream param1InputStream) throws XmlException, IOException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1InputStream, SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1InputStream, SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static SignedPropertiesType parse(Reader param1Reader) throws XmlException, IOException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1Reader, SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1Reader, SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static SignedPropertiesType parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1XMLStreamReader, SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1XMLStreamReader, SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static SignedPropertiesType parse(Node param1Node) throws XmlException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1Node, SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1Node, SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static SignedPropertiesType parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1XMLInputStream, SignedPropertiesType.type, null);
    }
    
    public static SignedPropertiesType parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (SignedPropertiesType)POIXMLTypeLoader.parse(param1XMLInputStream, SignedPropertiesType.type, param1XmlOptions);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return POIXMLTypeLoader.newValidatingXMLInputStream(param1XMLInputStream, SignedPropertiesType.type, null);
    }
    
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return POIXMLTypeLoader.newValidatingXMLInputStream(param1XMLInputStream, SignedPropertiesType.type, param1XmlOptions);
    }
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\SignedPropertiesType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */