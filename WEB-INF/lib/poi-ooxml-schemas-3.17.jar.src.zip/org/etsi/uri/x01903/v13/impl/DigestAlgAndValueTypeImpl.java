package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.DigestAlgAndValueType;
import org.w3.x2000.x09.xmldsig.DigestMethodType;
import org.w3.x2000.x09.xmldsig.DigestValueType;

public class DigestAlgAndValueTypeImpl extends XmlComplexContentImpl implements DigestAlgAndValueType {
  private static final QName DIGESTMETHOD$0 = new QName("http://www.w3.org/2000/09/xmldsig#", "DigestMethod");
  
  private static final QName DIGESTVALUE$2 = new QName("http://www.w3.org/2000/09/xmldsig#", "DigestValue");
  
  public DigestAlgAndValueTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public DigestMethodType getDigestMethod() {
    synchronized (monitor()) {
      check_orphaned();
      DigestMethodType digestMethodType = null;
      digestMethodType = (DigestMethodType)get_store().find_element_user(DIGESTMETHOD$0, 0);
      if (digestMethodType == null)
        return null; 
      return digestMethodType;
    } 
  }
  
  public void setDigestMethod(DigestMethodType paramDigestMethodType) {
    synchronized (monitor()) {
      check_orphaned();
      DigestMethodType digestMethodType = null;
      digestMethodType = (DigestMethodType)get_store().find_element_user(DIGESTMETHOD$0, 0);
      if (digestMethodType == null)
        digestMethodType = (DigestMethodType)get_store().add_element_user(DIGESTMETHOD$0); 
      digestMethodType.set((XmlObject)paramDigestMethodType);
    } 
  }
  
  public DigestMethodType addNewDigestMethod() {
    synchronized (monitor()) {
      check_orphaned();
      DigestMethodType digestMethodType = null;
      digestMethodType = (DigestMethodType)get_store().add_element_user(DIGESTMETHOD$0);
      return digestMethodType;
    } 
  }
  
  public byte[] getDigestValue() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(DIGESTVALUE$2, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getByteArrayValue();
    } 
  }
  
  public DigestValueType xgetDigestValue() {
    synchronized (monitor()) {
      check_orphaned();
      DigestValueType digestValueType = null;
      digestValueType = (DigestValueType)get_store().find_element_user(DIGESTVALUE$2, 0);
      return digestValueType;
    } 
  }
  
  public void setDigestValue(byte[] paramArrayOfbyte) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(DIGESTVALUE$2, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(DIGESTVALUE$2); 
      simpleValue.setByteArrayValue(paramArrayOfbyte);
    } 
  }
  
  public void xsetDigestValue(DigestValueType paramDigestValueType) {
    synchronized (monitor()) {
      check_orphaned();
      DigestValueType digestValueType = null;
      digestValueType = (DigestValueType)get_store().find_element_user(DIGESTVALUE$2, 0);
      if (digestValueType == null)
        digestValueType = (DigestValueType)get_store().add_element_user(DIGESTVALUE$2); 
      digestValueType.set((XmlObject)paramDigestValueType);
    } 
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\impl\DigestAlgAndValueTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */