package org.etsi.uri.x01903.v13.impl;

import org.apache.xmlbeans.SchemaType;
import org.etsi.uri.x01903.v13.XAdESTimeStampType;

public class XAdESTimeStampTypeImpl extends GenericTimeStampTypeImpl implements XAdESTimeStampType {
  public XAdESTimeStampTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\ets\\uri\x01903\v13\impl\XAdESTimeStampTypeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */