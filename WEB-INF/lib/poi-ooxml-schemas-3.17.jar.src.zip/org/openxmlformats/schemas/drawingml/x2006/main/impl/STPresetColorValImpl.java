package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.main.STPresetColorVal;

public class STPresetColorValImpl extends JavaStringEnumerationHolderEx implements STPresetColorVal {
  public STPresetColorValImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STPresetColorValImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\STPresetColorValImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */