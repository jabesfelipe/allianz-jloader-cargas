package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlToken;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTOfficeArtExtension;

public class CTOfficeArtExtensionImpl extends XmlComplexContentImpl implements CTOfficeArtExtension {
  private static final QName URI$0 = new QName("", "uri");
  
  public CTOfficeArtExtensionImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public String getUri() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(URI$0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlToken xgetUri() {
    synchronized (monitor()) {
      check_orphaned();
      XmlToken xmlToken = null;
      xmlToken = (XmlToken)get_store().find_attribute_user(URI$0);
      return xmlToken;
    } 
  }
  
  public boolean isSetUri() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(URI$0) != null);
    } 
  }
  
  public void setUri(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(URI$0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(URI$0); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetUri(XmlToken paramXmlToken) {
    synchronized (monitor()) {
      check_orphaned();
      XmlToken xmlToken = null;
      xmlToken = (XmlToken)get_store().find_attribute_user(URI$0);
      if (xmlToken == null)
        xmlToken = (XmlToken)get_store().add_attribute_user(URI$0); 
      xmlToken.set((XmlObject)paramXmlToken);
    } 
  }
  
  public void unsetUri() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(URI$0);
    } 
  }
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\poi-ooxml-schemas-3.17.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTOfficeArtExtensionImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */