package org.apache.commons.lang.mutable;

public interface Mutable {
  Object getValue();
  
  void setValue(Object paramObject);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\commons-lang-2.6.jar!\org\apache\commons\lang\mutable\Mutable.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */