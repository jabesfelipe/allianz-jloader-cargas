/*    */ package br.com.accesstage.loader.util.dao.rowmapper;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.FileOutVO;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileOutMapper
/*    */   implements RowMapper<FileOutVO>
/*    */ {
/*    */   public FileOutVO mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 15 */     FileOutVO fileOutVO = new FileOutVO();
/* 16 */     fileOutVO.setDsc_token(rs.getString("dsc_token"));
/* 17 */     fileOutVO.setCod_arquivo(rs.getString("cod_arquivo"));
/* 18 */     fileOutVO.setSeq_arquivo(rs.getString("seq_arquivo"));
/* 19 */     fileOutVO.setTpo_registro(rs.getString("tpo_registro"));
/* 20 */     fileOutVO.setDsc_registro(rs.getString("dsc_registro"));
/* 21 */     fileOutVO.setTpo_arquivo(rs.getString("tpo_arquivo"));
/* 22 */     fileOutVO.setSender(rs.getString("sender"));
/* 23 */     fileOutVO.setReceiver(rs.getString("receiver"));
/* 24 */     fileOutVO.setDoctype(rs.getString("doctype"));
/* 25 */     fileOutVO.setNme_arquivo(rs.getString("nme_arquivo"));
/*    */     
/* 27 */     return fileOutVO;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\FileOutMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */