/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.LongDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class HeaderL043
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -7487894867845989442L;
/*     */   @LongPositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private Long codBandoHdr;
/*     */   @LongPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Long codLoteHdr;
/*     */   @LongPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Long tpoRegisHdr;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 9)
/*     */   private String tpoOperacaoHdr;
/*     */   @LongPositionalField(initialPosition = 10, finalPosition = 11)
/*     */   private Long codTpoServicoHdr;
/*     */   @LongPositionalField(initialPosition = 12, finalPosition = 13)
/*     */   private Long codFormaLancHdr;
/*     */   @LongPositionalField(initialPosition = 14, finalPosition = 16)
/*     */   private Long nroLayoutLteHdr;
/*     */   @PositionalField(initialPosition = 17, finalPosition = 17)
/*     */   private String dscReservado;
/*     */   @LongPositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private Long codTpoInsEmpHdr;
/*     */   @LongPositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private Long nroInscEmpHdr;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 52)
/*     */   private String codConvbancoHdr;
/*     */   @LongPositionalField(initialPosition = 53, finalPosition = 57)
/*     */   private Long codAgMantContaHdr;
/*     */   @LongPositionalField(initialPosition = 58, finalPosition = 58)
/*     */   private Long codDigVeriContaHdr;
/*     */   @LongPositionalField(initialPosition = 59, finalPosition = 70)
/*     */   private Long nroContaCorrenteHdr;
/*     */   @PositionalField(initialPosition = 71, finalPosition = 71)
/*     */   private String digContaHdr;
/*     */   @PositionalField(initialPosition = 72, finalPosition = 72)
/*     */   private String digAgCcHdr;
/*     */   @PositionalField(initialPosition = 73, finalPosition = 102)
/*     */   private String nmeEmpresaHdr;
/*     */   @PositionalField(initialPosition = 103, finalPosition = 142)
/*     */   private String dscMensagemHdr;
/*     */   @PositionalField(initialPosition = 143, finalPosition = 172)
/*     */   private String dscEndEmpresaHdr;
/*     */   @LongPositionalField(initialPosition = 173, finalPosition = 177)
/*     */   private Long numEndEmpHdr;
/*     */   @PositionalField(initialPosition = 178, finalPosition = 192)
/*     */   private String dscComplemnteEmpHdr;
/*     */   @PositionalField(initialPosition = 193, finalPosition = 212)
/*     */   private String dscCidadeEmpHdr;
/*     */   @PositionalField(initialPosition = 213, finalPosition = 217, decorator = LongDecorator240.class)
/*     */   private Long dscCepEmpHdr;
/*     */   @PositionalField(initialPosition = 218, finalPosition = 220)
/*     */   private String dscCompCepEmpHdr;
/*     */   @PositionalField(initialPosition = 221, finalPosition = 222)
/*     */   private String dscSlgEstEmpHdr;
/*     */   @PositionalField(initialPosition = 223, finalPosition = 230)
/*     */   private String dscReservado1Hdr;
/*     */   @PositionalField(initialPosition = 231, finalPosition = 240)
/*     */   private String dscOcorrenciasHdr;
/*     */   
/*     */   public Long getCodBandoHdr() {
/*  74 */     return this.codBandoHdr;
/*     */   }
/*     */   public void setCodBandoHdr(Long codBandoHdr) {
/*  77 */     this.codBandoHdr = codBandoHdr;
/*     */   }
/*     */   public Long getCodLoteHdr() {
/*  80 */     return this.codLoteHdr;
/*     */   }
/*     */   public void setCodLoteHdr(Long codLoteHdr) {
/*  83 */     this.codLoteHdr = codLoteHdr;
/*     */   }
/*     */   public Long getTpoRegisHdr() {
/*  86 */     return this.tpoRegisHdr;
/*     */   }
/*     */   public void setTpoRegisHdr(Long tpoRegisHdr) {
/*  89 */     this.tpoRegisHdr = tpoRegisHdr;
/*     */   }
/*     */   public String getTpoOperacaoHdr() {
/*  92 */     return this.tpoOperacaoHdr;
/*     */   }
/*     */   public void setTpoOperacaoHdr(String tpoOperacaoHdr) {
/*  95 */     this.tpoOperacaoHdr = tpoOperacaoHdr;
/*     */   }
/*     */   public Long getCodTpoServicoHdr() {
/*  98 */     return this.codTpoServicoHdr;
/*     */   }
/*     */   public void setCodTpoServicoHdr(Long codTpoServicoHdr) {
/* 101 */     this.codTpoServicoHdr = codTpoServicoHdr;
/*     */   }
/*     */   public Long getCodFormaLancHdr() {
/* 104 */     return this.codFormaLancHdr;
/*     */   }
/*     */   public void setCodFormaLancHdr(Long codFormaLancHdr) {
/* 107 */     this.codFormaLancHdr = codFormaLancHdr;
/*     */   }
/*     */   public Long getNroLayoutLteHdr() {
/* 110 */     return this.nroLayoutLteHdr;
/*     */   }
/*     */   public void setNroLayoutLteHdr(Long nroLayoutLteHdr) {
/* 113 */     this.nroLayoutLteHdr = nroLayoutLteHdr;
/*     */   }
/*     */   public String getDscReservado() {
/* 116 */     return this.dscReservado;
/*     */   }
/*     */   public void setDscReservado(String dscReservado) {
/* 119 */     this.dscReservado = dscReservado;
/*     */   }
/*     */   public Long getCodTpoInsEmpHdr() {
/* 122 */     return this.codTpoInsEmpHdr;
/*     */   }
/*     */   public void setCodTpoInsEmpHdr(Long codTpoInsEmpHdr) {
/* 125 */     this.codTpoInsEmpHdr = codTpoInsEmpHdr;
/*     */   }
/*     */   public Long getNroInscEmpHdr() {
/* 128 */     return this.nroInscEmpHdr;
/*     */   }
/*     */   public void setNroInscEmpHdr(Long nroInscEmpHdr) {
/* 131 */     this.nroInscEmpHdr = nroInscEmpHdr;
/*     */   }
/*     */   public String getCodConvbancoHdr() {
/* 134 */     return this.codConvbancoHdr;
/*     */   }
/*     */   public void setCodConvbancoHdr(String codConvbancoHdr) {
/* 137 */     this.codConvbancoHdr = codConvbancoHdr;
/*     */   }
/*     */   public Long getCodAgMantContaHdr() {
/* 140 */     return this.codAgMantContaHdr;
/*     */   }
/*     */   public void setCodAgMantContaHdr(Long codAgMantContaHdr) {
/* 143 */     this.codAgMantContaHdr = codAgMantContaHdr;
/*     */   }
/*     */   public Long getCodDigVeriContaHdr() {
/* 146 */     return this.codDigVeriContaHdr;
/*     */   }
/*     */   public void setCodDigVeriContaHdr(Long codDigVeriContaHdr) {
/* 149 */     this.codDigVeriContaHdr = codDigVeriContaHdr;
/*     */   }
/*     */   public Long getNroContaCorrenteHdr() {
/* 152 */     return this.nroContaCorrenteHdr;
/*     */   }
/*     */   public void setNroContaCorrenteHdr(Long nroContaCorrenteHdr) {
/* 155 */     this.nroContaCorrenteHdr = nroContaCorrenteHdr;
/*     */   }
/*     */   public String getDigContaHdr() {
/* 158 */     return this.digContaHdr;
/*     */   }
/*     */   public void setDigContaHdr(String digContaHdr) {
/* 161 */     this.digContaHdr = digContaHdr;
/*     */   }
/*     */   public String getDigAgCcHdr() {
/* 164 */     return this.digAgCcHdr;
/*     */   }
/*     */   public void setDigAgCcHdr(String digAgCcHdr) {
/* 167 */     this.digAgCcHdr = digAgCcHdr;
/*     */   }
/*     */   public String getNmeEmpresaHdr() {
/* 170 */     return this.nmeEmpresaHdr;
/*     */   }
/*     */   public void setNmeEmpresaHdr(String nmeEmpresaHdr) {
/* 173 */     this.nmeEmpresaHdr = nmeEmpresaHdr;
/*     */   }
/*     */   public String getDscMensagemHdr() {
/* 176 */     return this.dscMensagemHdr;
/*     */   }
/*     */   public void setDscMensagemHdr(String dscMensagemHdr) {
/* 179 */     this.dscMensagemHdr = dscMensagemHdr;
/*     */   }
/*     */   public String getDscEndEmpresaHdr() {
/* 182 */     return this.dscEndEmpresaHdr;
/*     */   }
/*     */   public void setDscEndEmpresaHdr(String dscEndEmpresaHdr) {
/* 185 */     this.dscEndEmpresaHdr = dscEndEmpresaHdr;
/*     */   }
/*     */   public Long getNumEndEmpHdr() {
/* 188 */     return this.numEndEmpHdr;
/*     */   }
/*     */   public void setNumEndEmpHdr(Long numEndEmpHdr) {
/* 191 */     this.numEndEmpHdr = numEndEmpHdr;
/*     */   }
/*     */   public String getDscComplemnteEmpHdr() {
/* 194 */     return this.dscComplemnteEmpHdr;
/*     */   }
/*     */   public void setDscComplemnteEmpHdr(String dscComplemnteEmpHdr) {
/* 197 */     this.dscComplemnteEmpHdr = dscComplemnteEmpHdr;
/*     */   }
/*     */   public String getDscCidadeEmpHdr() {
/* 200 */     return this.dscCidadeEmpHdr;
/*     */   }
/*     */   public void setDscCidadeEmpHdr(String dscCidadeEmpHdr) {
/* 203 */     this.dscCidadeEmpHdr = dscCidadeEmpHdr;
/*     */   }
/*     */   public Long getDscCepEmpHdr() {
/* 206 */     return this.dscCepEmpHdr;
/*     */   }
/*     */   public void setDscCepEmpHdr(Long dscCepEmpHdr) {
/* 209 */     this.dscCepEmpHdr = dscCepEmpHdr;
/*     */   }
/*     */   public String getDscCompCepEmpHdr() {
/* 212 */     return this.dscCompCepEmpHdr;
/*     */   }
/*     */   public void setDscCompCepEmpHdr(String dscCompCepEmpHdr) {
/* 215 */     this.dscCompCepEmpHdr = dscCompCepEmpHdr;
/*     */   }
/*     */   public String getDscSlgEstEmpHdr() {
/* 218 */     return this.dscSlgEstEmpHdr;
/*     */   }
/*     */   public void setDscSlgEstEmpHdr(String dscSlgEstEmpHdr) {
/* 221 */     this.dscSlgEstEmpHdr = dscSlgEstEmpHdr;
/*     */   }
/*     */   public String getDscReservado1Hdr() {
/* 224 */     return this.dscReservado1Hdr;
/*     */   }
/*     */   public void setDscReservado1Hdr(String dscReservado1Hdr) {
/* 227 */     this.dscReservado1Hdr = dscReservado1Hdr;
/*     */   }
/*     */   public String getDscOcorrenciasHdr() {
/* 230 */     return this.dscOcorrenciasHdr;
/*     */   }
/*     */   public void setDscOcorrenciasHdr(String dscOcorrenciasHdr) {
/* 233 */     this.dscOcorrenciasHdr = dscOcorrenciasHdr;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\HeaderL043.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */