/*    */ package br.com.accesstage.loader.util.commom.ffpojo;
/*    */ 
/*    */ public class RecordParserException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public RecordParserException(String message) {
/*  9 */     super(message);
/*    */   }
/*    */   
/*    */   public RecordParserException(Throwable cause) {
/* 13 */     super(cause);
/*    */   }
/*    */   
/*    */   public RecordParserException(String message, Throwable cause) {
/* 17 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\commom\ffpojo\RecordParserException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */