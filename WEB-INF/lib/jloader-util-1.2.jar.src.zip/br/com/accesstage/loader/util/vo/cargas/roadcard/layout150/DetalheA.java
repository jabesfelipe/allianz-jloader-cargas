package br.com.accesstage.loader.util.vo.cargas.roadcard.layout150;

import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;

@PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "A")})
public class DetalheA extends AbstractVO {
  private static final long serialVersionUID = 1L;
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout150\DetalheA.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */