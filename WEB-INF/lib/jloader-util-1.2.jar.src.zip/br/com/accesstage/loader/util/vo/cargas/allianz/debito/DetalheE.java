/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "E")})
/*     */ public class DetalheE
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private String codRegistro;
/*     */   @PositionalField(initialPosition = 2, finalPosition = 26)
/*     */   private String identClienteEmpresa;
/*     */   @PositionalField(initialPosition = 27, finalPosition = 30)
/*     */   private String agenciaDebito;
/*     */   @PositionalField(initialPosition = 31, finalPosition = 44)
/*     */   private String identClienteBanco;
/*     */   @PositionalField(initialPosition = 45, finalPosition = 52)
/*     */   private String dataVencimento;
/*     */   @PositionalField(initialPosition = 53, finalPosition = 67)
/*     */   private String valorDebito;
/*     */   @PositionalField(initialPosition = 68, finalPosition = 69)
/*     */   private String codigoMoeda;
/*     */   @PositionalField(initialPosition = 70, finalPosition = 129)
/*     */   private String usoEmpresa;
/*     */   @PositionalField(initialPosition = 130, finalPosition = 130)
/*     */   private String tipoIdentificacao;
/*     */   @PositionalField(initialPosition = 131, finalPosition = 145)
/*     */   private String identificacao;
/*     */   @PositionalField(initialPosition = 146, finalPosition = 149)
/*     */   private String usoFuturo;
/*     */   @PositionalField(initialPosition = 150, finalPosition = 150)
/*     */   private String codMovimento;
/*     */   
/*     */   public String getCodRegistro() {
/*  43 */     return this.codRegistro;
/*     */   }
/*     */   public void setCodRegistro(String codRegistro) {
/*  46 */     this.codRegistro = codRegistro;
/*     */   }
/*     */   public String getIdentClienteEmpresa() {
/*  49 */     return this.identClienteEmpresa;
/*     */   }
/*     */   public void setIdentClienteEmpresa(String identClienteEmpresa) {
/*  52 */     this.identClienteEmpresa = identClienteEmpresa;
/*     */   }
/*     */   public String getAgenciaDebito() {
/*  55 */     return this.agenciaDebito;
/*     */   }
/*     */   public void setAgenciaDebito(String agenciaDebito) {
/*  58 */     this.agenciaDebito = agenciaDebito;
/*     */   }
/*     */   public String getIdentClienteBanco() {
/*  61 */     return this.identClienteBanco;
/*     */   }
/*     */   public void setIdentClienteBanco(String identClienteBanco) {
/*  64 */     this.identClienteBanco = identClienteBanco;
/*     */   }
/*     */   public String getDataVencimento() {
/*  67 */     return this.dataVencimento;
/*     */   }
/*     */   public void setDataVencimento(String dataVencimento) {
/*  70 */     this.dataVencimento = dataVencimento;
/*     */   }
/*     */   public String getValorDebito() {
/*  73 */     return this.valorDebito;
/*     */   }
/*     */   public void setValorDebito(String valorDebito) {
/*  76 */     this.valorDebito = valorDebito;
/*     */   }
/*     */   public String getCodigoMoeda() {
/*  79 */     return this.codigoMoeda;
/*     */   }
/*     */   public void setCodigoMoeda(String codigoMoeda) {
/*  82 */     this.codigoMoeda = codigoMoeda;
/*     */   }
/*     */   public String getUsoEmpresa() {
/*  85 */     return this.usoEmpresa;
/*     */   }
/*     */   public void setUsoEmpresa(String usoEmpresa) {
/*  88 */     this.usoEmpresa = usoEmpresa;
/*     */   }
/*     */   public String getTipoIdentificacao() {
/*  91 */     return this.tipoIdentificacao;
/*     */   }
/*     */   public void setTipoIdentificacao(String tipoIdentificacao) {
/*  94 */     this.tipoIdentificacao = tipoIdentificacao;
/*     */   }
/*     */   public String getIdentificacao() {
/*  97 */     return this.identificacao;
/*     */   }
/*     */   public void setIdentificacao(String identificacao) {
/* 100 */     this.identificacao = identificacao;
/*     */   }
/*     */   public String getUsoFuturo() {
/* 103 */     return this.usoFuturo;
/*     */   }
/*     */   public void setUsoFuturo(String usoFuturo) {
/* 106 */     this.usoFuturo = usoFuturo;
/*     */   }
/*     */   public String getCodMovimento() {
/* 109 */     return this.codMovimento;
/*     */   }
/*     */   public void setCodMovimento(String codMovimento) {
/* 112 */     this.codMovimento = codMovimento;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\DetalheE.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */