/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout500;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.LongDecorator;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Header
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 5416099622544966174L;
/*     */   @IntegerPositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private int tipo;
/*     */   @LongPositionalField(initialPosition = 2, finalPosition = 9)
/*     */   private long codComunicacao;
/*     */   @LongPositionalField(initialPosition = 10, finalPosition = 10)
/*     */   private long tpInscEmpPagadora;
/*     */   @LongPositionalField(initialPosition = 11, finalPosition = 25)
/*     */   private long cnpjPagadora;
/*     */   @PositionalField(initialPosition = 26, finalPosition = 65)
/*     */   private String nomeEmpPagadora;
/*     */   @LongPositionalField(initialPosition = 66, finalPosition = 67)
/*     */   private long tpServicos;
/*     */   @LongPositionalField(initialPosition = 68, finalPosition = 68)
/*     */   private long codOrigemArquivo;
/*     */   @LongPositionalField(initialPosition = 69, finalPosition = 73)
/*     */   private long numeroRemessa;
/*     */   @LongPositionalField(initialPosition = 74, finalPosition = 78)
/*     */   private Long numeroRetorno;
/*     */   @LongPositionalField(initialPosition = 79, finalPosition = 86)
/*     */   private long dataGravacao;
/*     */   @LongPositionalField(initialPosition = 87, finalPosition = 92)
/*     */   private long horaGravacao;
/*     */   @LongPositionalField(initialPosition = 93, finalPosition = 97)
/*     */   private String densidade;
/*     */   @PositionalField(initialPosition = 98, finalPosition = 100)
/*     */   private String unidadeGravacao;
/*     */   @PositionalField(initialPosition = 101, finalPosition = 105)
/*     */   private String idenModuloMicro;
/*     */   @LongPositionalField(initialPosition = 106, finalPosition = 106)
/*     */   private long tipProcessamento;
/*     */   @PositionalField(initialPosition = 107, finalPosition = 180)
/*     */   private String reservadoEmp;
/*     */   @PositionalField(initialPosition = 181, finalPosition = 260)
/*     */   private String reservadoBanco;
/*     */   @PositionalField(initialPosition = 261, finalPosition = 477)
/*     */   private String reservadoBanco1;
/*     */   @PositionalField(decorator = LongDecorator.class, initialPosition = 478, finalPosition = 486)
/*     */   private Long nroListaDeb;
/*     */   @PositionalField(initialPosition = 487, finalPosition = 494)
/*     */   private String reservadoBanco2;
/*     */   @PositionalField(decorator = LongDecorator.class, initialPosition = 495, finalPosition = 500)
/*     */   private Long nroSequencial;
/*     */   private Long dataHoraGrv;
/*     */   
/*     */   public int getTipo() {
/*  66 */     int linha = getLinhaProcessada();
/*  67 */     setLinhaProcessada(linha++);
/*  68 */     return this.tipo;
/*     */   }
/*     */   public void setTipo(int tipo) {
/*  71 */     this.tipo = tipo;
/*     */   }
/*     */   public long getCodComunicacao() {
/*  74 */     return this.codComunicacao;
/*     */   }
/*     */   public void setCodComunicacao(long codComunicacao) {
/*  77 */     this.codComunicacao = codComunicacao;
/*     */   }
/*     */   public long getTpInscEmpPagadora() {
/*  80 */     return this.tpInscEmpPagadora;
/*     */   }
/*     */   public void setTpInscEmpPagadora(long tpInscEmpPagadora) {
/*  83 */     this.tpInscEmpPagadora = tpInscEmpPagadora;
/*     */   }
/*     */   public long getCnpjPagadora() {
/*  86 */     return this.cnpjPagadora;
/*     */   }
/*     */   public void setCnpjPagadora(long cnpjPagadora) {
/*  89 */     this.cnpjPagadora = cnpjPagadora;
/*     */   }
/*     */   public String getNomeEmpPagadora() {
/*  92 */     return this.nomeEmpPagadora;
/*     */   }
/*     */   public void setNomeEmpPagadora(String nomeEmpPagadora) {
/*  95 */     this.nomeEmpPagadora = nomeEmpPagadora;
/*     */   }
/*     */   public long getTpServicos() {
/*  98 */     return this.tpServicos;
/*     */   }
/*     */   public void setTpServicos(long tpServicos) {
/* 101 */     this.tpServicos = tpServicos;
/*     */   }
/*     */   public long getCodOrigemArquivo() {
/* 104 */     return this.codOrigemArquivo;
/*     */   }
/*     */   public void setCodOrigemArquivo(long codOrigemArquivo) {
/* 107 */     this.codOrigemArquivo = codOrigemArquivo;
/*     */   }
/*     */   public long getNumeroRemessa() {
/* 110 */     return this.numeroRemessa;
/*     */   }
/*     */   public void setNumeroRemessa(long numeroRemessa) {
/* 113 */     this.numeroRemessa = numeroRemessa;
/*     */   }
/*     */   public Long getNumeroRetorno() {
/* 116 */     return this.numeroRetorno;
/*     */   }
/*     */   public void setNumeroRetorno(Long numeroRetorno) {
/* 119 */     this.numeroRetorno = numeroRetorno;
/*     */   }
/*     */   public long getDataGravacao() {
/* 122 */     return this.dataGravacao;
/*     */   }
/*     */   public void setDataGravacao(long dataGravacao) {
/* 125 */     this.dataGravacao = dataGravacao;
/*     */   }
/*     */   public long getHoraGravacao() {
/* 128 */     return this.horaGravacao;
/*     */   }
/*     */   public void setHoraGravacao(long horaGravacao) {
/* 131 */     this.horaGravacao = horaGravacao;
/*     */   }
/*     */   public String getDensidade() {
/* 134 */     return this.densidade;
/*     */   }
/*     */   public void setDensidade(String densidade) {
/* 137 */     this.densidade = densidade;
/*     */   }
/*     */   public String getUnidadeGravacao() {
/* 140 */     return this.unidadeGravacao;
/*     */   }
/*     */   public void setUnidadeGravacao(String unidadeGravacao) {
/* 143 */     this.unidadeGravacao = unidadeGravacao;
/*     */   }
/*     */   public String getIdenModuloMicro() {
/* 146 */     return this.idenModuloMicro;
/*     */   }
/*     */   public void setIdenModuloMicro(String idenModuloMicro) {
/* 149 */     this.idenModuloMicro = idenModuloMicro;
/*     */   }
/*     */   public long getTipProcessamento() {
/* 152 */     return this.tipProcessamento;
/*     */   }
/*     */   public void setTipProcessamento(long tipProcessamento) {
/* 155 */     this.tipProcessamento = tipProcessamento;
/*     */   }
/*     */   public String getReservadoEmp() {
/* 158 */     return this.reservadoEmp;
/*     */   }
/*     */   public void setReservadoEmp(String reservadoEmp) {
/* 161 */     this.reservadoEmp = reservadoEmp;
/*     */   }
/*     */   public String getReservadoBanco() {
/* 164 */     return this.reservadoBanco;
/*     */   }
/*     */   public void setReservadoBanco(String reservadoBanco) {
/* 167 */     this.reservadoBanco = reservadoBanco;
/*     */   }
/*     */   public String getReservadoBanco1() {
/* 170 */     return this.reservadoBanco1;
/*     */   }
/*     */   public void setReservadoBanco1(String reservadoBanco1) {
/* 173 */     this.reservadoBanco1 = reservadoBanco1;
/*     */   }
/*     */   public Long getNroListaDeb() {
/* 176 */     return this.nroListaDeb;
/*     */   }
/*     */   public void setNroListaDeb(Long nroListaDeb) {
/* 179 */     this.nroListaDeb = nroListaDeb;
/*     */   }
/*     */   public String getReservadoBanco2() {
/* 182 */     return this.reservadoBanco2;
/*     */   }
/*     */   public void setReservadoBanco2(String reservadoBanco2) {
/* 185 */     this.reservadoBanco2 = reservadoBanco2;
/*     */   }
/*     */   public Long getNroSequencial() {
/* 188 */     return this.nroSequencial;
/*     */   }
/*     */   public void setNroSequencial(Long nroSequencial) {
/* 191 */     this.nroSequencial = nroSequencial;
/*     */   }
/*     */   public Long getDataHoraGrv() {
/* 194 */     return Long.valueOf(this.dataGravacao);
/*     */   }
/*     */   public void setDataHoraGrv(Long dataHoraGrv) {
/* 197 */     this.dataHoraGrv = dataHoraGrv;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout500\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */