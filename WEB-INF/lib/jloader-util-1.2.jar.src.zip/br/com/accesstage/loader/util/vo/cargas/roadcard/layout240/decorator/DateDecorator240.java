/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator;
/*    */ 
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateDecorator240
/*    */   extends DefaultFieldDecorator
/*    */ {
/*    */   public Object fromString(String str) {
/* 16 */     if (!"00000000".equals(str) && !isNullOrWhitespace(str.trim()) && StringUtils.isNotEmpty(str)) {
/*    */       try {
/* 18 */         return (new SimpleDateFormat("ddMMyyyy")).parse(str);
/* 19 */       } catch (ParseException e) {
/* 20 */         throw new FieldDecoratorException(e);
/*    */       } 
/*    */     }
/* 23 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isNullOrWhitespace(CharSequence value) {
/* 27 */     if (value == null) {
/* 28 */       return true;
/*    */     }
/* 30 */     for (int i = 0; i < value.length(); i++) {
/* 31 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 32 */         return false;
/*    */       }
/*    */     } 
/* 35 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\decorator\DateDecorator240.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */