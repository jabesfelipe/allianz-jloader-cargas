/*    */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout500.retorno;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.extra.DoublePositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord
/*    */ public class Trailler
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @IntegerPositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private Integer identRegistro;
/*    */   @IntegerPositionalField(initialPosition = 2, finalPosition = 7)
/*    */   private Integer qtdeRegistros;
/*    */   @DoublePositionalField(initialPosition = 8, finalPosition = 24, precision = 2)
/*    */   private Double totalValoresPagamentos;
/*    */   @PositionalField(initialPosition = 25, finalPosition = 494)
/*    */   private String reservadoBanco3;
/*    */   @IntegerPositionalField(initialPosition = 495, finalPosition = 500)
/*    */   private Integer numeroSequencial;
/*    */   
/*    */   public Integer getIdentRegistro() {
/* 30 */     return this.identRegistro;
/*    */   }
/*    */   public void setIdentRegistro(Integer identRegistro) {
/* 33 */     this.identRegistro = identRegistro;
/*    */   }
/*    */   public Integer getQtdeRegistros() {
/* 36 */     return this.qtdeRegistros;
/*    */   }
/*    */   public void setQtdeRegistros(Integer qtdeRegistros) {
/* 39 */     this.qtdeRegistros = qtdeRegistros;
/*    */   }
/*    */   public Double getTotalValoresPagamentos() {
/* 42 */     return this.totalValoresPagamentos;
/*    */   }
/*    */   public void setTotalValoresPagamentos(Double totalValoresPagamentos) {
/* 45 */     this.totalValoresPagamentos = totalValoresPagamentos;
/*    */   }
/*    */   public String getReservadoBanco3() {
/* 48 */     return this.reservadoBanco3;
/*    */   }
/*    */   public void setReservadoBanco3(String reservadoBanco3) {
/* 51 */     this.reservadoBanco3 = reservadoBanco3;
/*    */   }
/*    */   public Integer getNumeroSequencial() {
/* 54 */     return this.numeroSequencial;
/*    */   }
/*    */   public void setNumeroSequencial(Integer numeroSequencial) {
/* 57 */     this.numeroSequencial = numeroSequencial;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout500\retorno\Trailler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */