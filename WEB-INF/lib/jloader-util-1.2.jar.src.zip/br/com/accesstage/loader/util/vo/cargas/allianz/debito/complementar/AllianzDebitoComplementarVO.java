/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito.complementar;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllianzDebitoComplementarVO
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Header header;
/* 20 */   private List<Detalhe> listDetalhe = new ArrayList<Detalhe>();
/*    */   private Trailler trailler;
/*    */   
/*    */   public Header getHeader() {
/* 24 */     return this.header;
/*    */   }
/*    */   
/*    */   public void setHeader(Header header) {
/* 28 */     this.header = header;
/*    */   }
/*    */   
/*    */   public List<Detalhe> getListDetalhe() {
/* 32 */     return this.listDetalhe;
/*    */   }
/*    */   
/*    */   public void setListDetalhe(List<Detalhe> listDetalhe) {
/* 36 */     this.listDetalhe = listDetalhe;
/*    */   }
/*    */   
/*    */   public Trailler getTrailler() {
/* 40 */     return this.trailler;
/*    */   }
/*    */   
/*    */   public void setTrailler(Trailler trailler) {
/* 44 */     this.trailler = trailler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\complementar\AllianzDebitoComplementarVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */