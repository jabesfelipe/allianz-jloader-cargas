/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class HeaderLote
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBanco;
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private String loteServico;
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private String tipoRegistro;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 9)
/*     */   private String tipoOperacao;
/*     */   @PositionalField(initialPosition = 10, finalPosition = 11)
/*     */   private String tipoServico;
/*     */   @PositionalField(initialPosition = 12, finalPosition = 13)
/*     */   private String formaLancamento;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 16)
/*     */   private String versaoLayout;
/*     */   @PositionalField(initialPosition = 17, finalPosition = 17)
/*     */   private String filler1;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private String tipoInscricao;
/*     */   @PositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private String nroInscricao;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 52)
/*     */   private String codConvenio;
/*     */   @PositionalField(initialPosition = 53, finalPosition = 57)
/*     */   private String agenciaConta;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 58)
/*     */   private String digitoAgencia;
/*     */   @PositionalField(initialPosition = 59, finalPosition = 70)
/*     */   private String contaCorrente;
/*     */   @PositionalField(initialPosition = 71, finalPosition = 71)
/*     */   private String digitoConta;
/*     */   @PositionalField(initialPosition = 72, finalPosition = 72)
/*     */   private String digitoAgenciaConta;
/*     */   @PositionalField(initialPosition = 73, finalPosition = 102)
/*     */   private String nomeEmpresa;
/*     */   @PositionalField(initialPosition = 103, finalPosition = 142)
/*     */   private String mensagem1;
/*     */   @PositionalField(initialPosition = 143, finalPosition = 172)
/*     */   private String endereco;
/*     */   @PositionalField(initialPosition = 173, finalPosition = 177)
/*     */   private String nroEndereco;
/*     */   @PositionalField(initialPosition = 178, finalPosition = 192)
/*     */   private String complementoEndereco;
/*     */   @PositionalField(initialPosition = 193, finalPosition = 212)
/*     */   private String cidade;
/*     */   @PositionalField(initialPosition = 213, finalPosition = 217)
/*     */   private String cep;
/*     */   @PositionalField(initialPosition = 218, finalPosition = 220)
/*     */   private String complementoCep;
/*     */   @PositionalField(initialPosition = 221, finalPosition = 222)
/*     */   private String estado;
/*     */   @PositionalField(initialPosition = 223, finalPosition = 224)
/*     */   private String indFormaPagamento;
/*     */   @PositionalField(initialPosition = 225, finalPosition = 230)
/*     */   private String filler2;
/*     */   @PositionalField(initialPosition = 231, finalPosition = 240)
/*     */   private String codOcorrencia;
/*     */   
/*     */   public String getCodBanco() {
/*  74 */     return this.codBanco;
/*     */   }
/*     */   public void setCodBanco(String codBanco) {
/*  77 */     this.codBanco = codBanco;
/*     */   }
/*     */   public String getLoteServico() {
/*  80 */     return this.loteServico;
/*     */   }
/*     */   public void setLoteServico(String loteServico) {
/*  83 */     this.loteServico = loteServico;
/*     */   }
/*     */   public String getTipoRegistro() {
/*  86 */     return this.tipoRegistro;
/*     */   }
/*     */   public void setTipoRegistro(String tipoRegistro) {
/*  89 */     this.tipoRegistro = tipoRegistro;
/*     */   }
/*     */   public String getTipoOperacao() {
/*  92 */     return this.tipoOperacao;
/*     */   }
/*     */   public void setTipoOperacao(String tipoOperacao) {
/*  95 */     this.tipoOperacao = tipoOperacao;
/*     */   }
/*     */   public String getTipoServico() {
/*  98 */     return this.tipoServico;
/*     */   }
/*     */   public void setTipoServico(String tipoServico) {
/* 101 */     this.tipoServico = tipoServico;
/*     */   }
/*     */   public String getFormaLancamento() {
/* 104 */     return this.formaLancamento;
/*     */   }
/*     */   public void setFormaLancamento(String formaLancamento) {
/* 107 */     this.formaLancamento = formaLancamento;
/*     */   }
/*     */   public String getVersaoLayout() {
/* 110 */     return this.versaoLayout;
/*     */   }
/*     */   public void setVersaoLayout(String versaoLayout) {
/* 113 */     this.versaoLayout = versaoLayout;
/*     */   }
/*     */   public String getFiller1() {
/* 116 */     return this.filler1;
/*     */   }
/*     */   public void setFiller1(String filler1) {
/* 119 */     this.filler1 = filler1;
/*     */   }
/*     */   public String getTipoInscricao() {
/* 122 */     return this.tipoInscricao;
/*     */   }
/*     */   public void setTipoInscricao(String tipoInscricao) {
/* 125 */     this.tipoInscricao = tipoInscricao;
/*     */   }
/*     */   public String getNroInscricao() {
/* 128 */     return this.nroInscricao;
/*     */   }
/*     */   public void setNroInscricao(String nroInscricao) {
/* 131 */     this.nroInscricao = nroInscricao;
/*     */   }
/*     */   public String getCodConvenio() {
/* 134 */     return this.codConvenio;
/*     */   }
/*     */   public void setCodConvenio(String codConvenio) {
/* 137 */     this.codConvenio = codConvenio;
/*     */   }
/*     */   public String getAgenciaConta() {
/* 140 */     return this.agenciaConta;
/*     */   }
/*     */   public void setAgenciaConta(String agenciaConta) {
/* 143 */     this.agenciaConta = agenciaConta;
/*     */   }
/*     */   public String getDigitoAgencia() {
/* 146 */     return this.digitoAgencia;
/*     */   }
/*     */   public void setDigitoAgencia(String digitoAgencia) {
/* 149 */     this.digitoAgencia = digitoAgencia;
/*     */   }
/*     */   public String getContaCorrente() {
/* 152 */     return this.contaCorrente;
/*     */   }
/*     */   public void setContaCorrente(String contaCorrente) {
/* 155 */     this.contaCorrente = contaCorrente;
/*     */   }
/*     */   public String getDigitoConta() {
/* 158 */     return this.digitoConta;
/*     */   }
/*     */   public void setDigitoConta(String digitoConta) {
/* 161 */     this.digitoConta = digitoConta;
/*     */   }
/*     */   public String getDigitoAgenciaConta() {
/* 164 */     return this.digitoAgenciaConta;
/*     */   }
/*     */   public void setDigitoAgenciaConta(String digitoAgenciaConta) {
/* 167 */     this.digitoAgenciaConta = digitoAgenciaConta;
/*     */   }
/*     */   public String getNomeEmpresa() {
/* 170 */     return this.nomeEmpresa;
/*     */   }
/*     */   public void setNomeEmpresa(String nomeEmpresa) {
/* 173 */     this.nomeEmpresa = nomeEmpresa;
/*     */   }
/*     */   public String getMensagem1() {
/* 176 */     return this.mensagem1;
/*     */   }
/*     */   public void setMensagem1(String mensagem1) {
/* 179 */     this.mensagem1 = mensagem1;
/*     */   }
/*     */   public String getEndereco() {
/* 182 */     return this.endereco;
/*     */   }
/*     */   public void setEndereco(String endereco) {
/* 185 */     this.endereco = endereco;
/*     */   }
/*     */   public String getNroEndereco() {
/* 188 */     return this.nroEndereco;
/*     */   }
/*     */   public void setNroEndereco(String nroEndereco) {
/* 191 */     this.nroEndereco = nroEndereco;
/*     */   }
/*     */   public String getComplementoEndereco() {
/* 194 */     return this.complementoEndereco;
/*     */   }
/*     */   public void setComplementoEndereco(String complementoEndereco) {
/* 197 */     this.complementoEndereco = complementoEndereco;
/*     */   }
/*     */   public String getCidade() {
/* 200 */     return this.cidade;
/*     */   }
/*     */   public void setCidade(String cidade) {
/* 203 */     this.cidade = cidade;
/*     */   }
/*     */   public String getCep() {
/* 206 */     return this.cep;
/*     */   }
/*     */   public void setCep(String cep) {
/* 209 */     this.cep = cep;
/*     */   }
/*     */   public String getComplementoCep() {
/* 212 */     return this.complementoCep;
/*     */   }
/*     */   public void setComplementoCep(String complementoCep) {
/* 215 */     this.complementoCep = complementoCep;
/*     */   }
/*     */   public String getEstado() {
/* 218 */     return this.estado;
/*     */   }
/*     */   public void setEstado(String estado) {
/* 221 */     this.estado = estado;
/*     */   }
/*     */   public String getIndFormaPagamento() {
/* 224 */     return this.indFormaPagamento;
/*     */   }
/*     */   public void setIndFormaPagamento(String indFormaPagamento) {
/* 227 */     this.indFormaPagamento = indFormaPagamento;
/*     */   }
/*     */   public String getFiller2() {
/* 230 */     return this.filler2;
/*     */   }
/*     */   public void setFiller2(String filler2) {
/* 233 */     this.filler2 = filler2;
/*     */   }
/*     */   public String getCodOcorrencia() {
/* 236 */     return this.codOcorrencia;
/*     */   }
/*     */   public void setCodOcorrencia(String codOcorrencia) {
/* 239 */     this.codOcorrencia = codOcorrencia;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\HeaderLote.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */