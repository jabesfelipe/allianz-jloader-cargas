package br.com.accesstage.loader.util.constantes.carga;

public interface ConstantesVarejistas {
  public static final String SELECT_VAREJISTA_EXISTS = "SELECT * FROM INCOMM_VAREJISTA WHERE NME_ARQUIVO_FAT = ? AND DSC_CPF_CNPJ_VAREJISTA =  ?";
  
  public static final String SEQ_COD_INCOMM_VAREJISTA = "SEQ_COD_INCOMM_VAREJISTA";
  
  public static final String INSERT_INCOMM_VAREJISTA = "INSERT INTO INCOMM_VAREJISTA (COD_INCOMM_VAREJISTA, COD_ARQUIVO, NRO_LINHA_ARQ, EMPID, COD_MES_REF_CARGA, NME_ARQUIVO_FAT, DSC_LEGAL_NAME,DSC_TIPO_FATURA, DSC_LOCATION, DSC_TPO_COBRANCA, NRO_PRAZO_PAGAMENTO, DSC_CPF_CNPJ_VAREJISTA, DSC_RAZAO_SOCIAL_VAREJISTA, TPO_INSCRICAO_VAREJISTA, DSC_ENDERECO, DSC_BAIRRO, DSC_CEP, DSC_CIDADE,SGL_UF, DSC_EMAIL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  
  public static final String UPDATE_INCOMM_VAREJISTA = "UPDATE INCOMM_VAREJISTA SET COD_ARQUIVO = ?, NRO_LINHA_ARQ = ?, EMPID = ?, COD_MES_REF_CARGA = ?, NME_ARQUIVO_FAT = ?, DSC_LEGAL_NAME = ?, DSC_TIPO_FATURA = ?, DSC_LOCATION = ?, DSC_TPO_COBRANCA = ?, NRO_PRAZO_PAGAMENTO = ?, DSC_CPF_CNPJ_VAREJISTA = ?, DSC_RAZAO_SOCIAL_VAREJISTA = ?, TPO_INSCRICAO_VAREJISTA = ?, DSC_ENDERECO = ?, DSC_BAIRRO = ?, DSC_CEP = ?, DSC_CIDADE = ?, SGL_UF = ?, DSC_EMAIL = ?, DTA_CADASTRO = SYSDATE WHERE NME_ARQUIVO_FAT = ? AND DSC_CPF_CNPJ_VAREJISTA =  ?";
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\carga\ConstantesVarejistas.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */