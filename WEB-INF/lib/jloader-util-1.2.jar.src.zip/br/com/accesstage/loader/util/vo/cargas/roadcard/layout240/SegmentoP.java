/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoP
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 6024068582543275460L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeqLte;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegRegDtlh;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Integer codMovRmss;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 22)
/*     */   private Integer dscAge;
/*     */   @PositionalField(initialPosition = 23, finalPosition = 23)
/*     */   private String dscAgeDV;
/*     */   @LongPositionalField(initialPosition = 24, finalPosition = 35)
/*     */   private Long dscConta;
/*     */   @PositionalField(initialPosition = 36, finalPosition = 36)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 37, finalPosition = 37)
/*     */   private String dscAgeCtaDV;
/*     */   @PositionalField(initialPosition = 38, finalPosition = 57)
/*     */   private String nroIdentTitBco;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 58)
/*     */   private String codCarteira;
/*     */   @IntegerPositionalField(initialPosition = 59, finalPosition = 59)
/*     */   private Integer dscTitBco;
/*     */   @PositionalField(initialPosition = 60, finalPosition = 60)
/*     */   private String dscTpoDoc;
/*     */   @IntegerPositionalField(initialPosition = 61, finalPosition = 61)
/*     */   private Integer codEmissaoBloq;
/*     */   @PositionalField(initialPosition = 62, finalPosition = 62)
/*     */   private String dscDist;
/*     */   @PositionalField(initialPosition = 63, finalPosition = 77)
/*     */   private String nroDocCob;
/*     */   @PositionalField(initialPosition = 78, finalPosition = 85, decorator = DateDecorator240.class)
/*     */   private Date dtaVencTit;
/*     */   @PositionalField(initialPosition = 86, finalPosition = 100, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrNmlTit;
/*     */   @IntegerPositionalField(initialPosition = 101, finalPosition = 105)
/*     */   private Integer dscAgeCob;
/*     */   @PositionalField(initialPosition = 106, finalPosition = 106)
/*     */   private String dscAgeCobDV;
/*     */   @IntegerPositionalField(initialPosition = 107, finalPosition = 108)
/*     */   private Integer codEspTit;
/*     */   @PositionalField(initialPosition = 109, finalPosition = 109)
/*     */   private String dscIdentTit;
/*     */   @PositionalField(initialPosition = 110, finalPosition = 117, decorator = DateDecorator240.class)
/*     */   private Date dtaEmissaoTit;
/*     */   @IntegerPositionalField(initialPosition = 118, finalPosition = 118)
/*     */   private Integer codJuros;
/*     */   @PositionalField(initialPosition = 119, finalPosition = 126, decorator = DateDecorator240.class)
/*     */   private Date dtaJuros;
/*     */   @PositionalField(initialPosition = 127, finalPosition = 141, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrJuros;
/*     */   @IntegerPositionalField(initialPosition = 142, finalPosition = 142)
/*     */   private Integer codDesc1;
/*     */   @PositionalField(initialPosition = 143, finalPosition = 150, decorator = DateDecorator240.class)
/*     */   private Date dtaDesc1;
/*     */   @PositionalField(initialPosition = 151, finalPosition = 165, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrPrctConc;
/*     */   @PositionalField(initialPosition = 166, finalPosition = 180, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrIofRecolhido;
/*     */   @PositionalField(initialPosition = 181, finalPosition = 195, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrAbat;
/*     */   @PositionalField(initialPosition = 196, finalPosition = 220)
/*     */   private String dscIdentTitEmp;
/*     */   @IntegerPositionalField(initialPosition = 221, finalPosition = 221)
/*     */   private Integer codProtesto;
/*     */   @IntegerPositionalField(initialPosition = 222, finalPosition = 223)
/*     */   private Integer nroDiasProt;
/*     */   @IntegerPositionalField(initialPosition = 224, finalPosition = 224)
/*     */   private Integer codBaixa;
/*     */   @PositionalField(initialPosition = 225, finalPosition = 227)
/*     */   private String nroDiasBaixa;
/*     */   @IntegerPositionalField(initialPosition = 228, finalPosition = 229)
/*     */   private Integer codMoeda;
/*     */   @IntegerPositionalField(initialPosition = 230, finalPosition = 239)
/*     */   private Integer nroContratoOpCred;
/*     */   @PositionalField(initialPosition = 240, finalPosition = 240)
/*     */   private String dscUsoLivre1;
/*     */   
/*     */   public String getCodBco() {
/* 109 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/* 112 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/* 115 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/* 118 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/* 121 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/* 124 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeqLte() {
/* 127 */     return this.nroSeqLte;
/*     */   }
/*     */   public void setNroSeqLte(Integer nroSeqLte) {
/* 130 */     this.nroSeqLte = nroSeqLte;
/*     */   }
/*     */   public String getCodSegRegDtlh() {
/* 133 */     return this.codSegRegDtlh;
/*     */   }
/*     */   public void setCodSegRegDtlh(String codSegRegDtlh) {
/* 136 */     this.codSegRegDtlh = codSegRegDtlh;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 139 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 142 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMovRmss() {
/* 145 */     return this.codMovRmss;
/*     */   }
/*     */   public void setCodMovRmss(Integer codMovRmss) {
/* 148 */     this.codMovRmss = codMovRmss;
/*     */   }
/*     */   public Integer getDscAge() {
/* 151 */     return this.dscAge;
/*     */   }
/*     */   public void setDscAge(Integer dscAge) {
/* 154 */     this.dscAge = dscAge;
/*     */   }
/*     */   public String getDscAgeDV() {
/* 157 */     return this.dscAgeDV;
/*     */   }
/*     */   public void setDscAgeDV(String dscAgeDV) {
/* 160 */     this.dscAgeDV = dscAgeDV;
/*     */   }
/*     */   public Long getDscConta() {
/* 163 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(Long dscConta) {
/* 166 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 169 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 172 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgeCtaDV() {
/* 175 */     return this.dscAgeCtaDV;
/*     */   }
/*     */   public void setDscAgeCtaDV(String dscAgeCtaDV) {
/* 178 */     this.dscAgeCtaDV = dscAgeCtaDV;
/*     */   }
/*     */   public String getNroIdentTitBco() {
/* 181 */     return this.nroIdentTitBco;
/*     */   }
/*     */   public void setNroIdentTitBco(String nroIdentTitBco) {
/* 184 */     this.nroIdentTitBco = nroIdentTitBco;
/*     */   }
/*     */   public String getCodCarteira() {
/* 187 */     return this.codCarteira;
/*     */   }
/*     */   public void setCodCarteira(String codCarteira) {
/* 190 */     this.codCarteira = codCarteira;
/*     */   }
/*     */   public Integer getDscTitBco() {
/* 193 */     return this.dscTitBco;
/*     */   }
/*     */   public void setDscTitBco(Integer dscTitBco) {
/* 196 */     this.dscTitBco = dscTitBco;
/*     */   }
/*     */   public String getDscTpoDoc() {
/* 199 */     return this.dscTpoDoc;
/*     */   }
/*     */   public void setDscTpoDoc(String dscTpoDoc) {
/* 202 */     this.dscTpoDoc = dscTpoDoc;
/*     */   }
/*     */   public Integer getCodEmissaoBloq() {
/* 205 */     return this.codEmissaoBloq;
/*     */   }
/*     */   public void setCodEmissaoBloq(Integer codEmissaoBloq) {
/* 208 */     this.codEmissaoBloq = codEmissaoBloq;
/*     */   }
/*     */   public String getDscDist() {
/* 211 */     return this.dscDist;
/*     */   }
/*     */   public void setDscDist(String dscDist) {
/* 214 */     this.dscDist = dscDist;
/*     */   }
/*     */   public String getNroDocCob() {
/* 217 */     return this.nroDocCob;
/*     */   }
/*     */   public void setNroDocCob(String nroDocCob) {
/* 220 */     this.nroDocCob = nroDocCob;
/*     */   }
/*     */   public Date getDtaVencTit() {
/* 223 */     return this.dtaVencTit;
/*     */   }
/*     */   public void setDtaVencTit(Date dtaVencTit) {
/* 226 */     this.dtaVencTit = dtaVencTit;
/*     */   }
/*     */   public BigDecimal getVlrNmlTit() {
/* 229 */     return this.vlrNmlTit;
/*     */   }
/*     */   public void setVlrNmlTit(BigDecimal vlrNmlTit) {
/* 232 */     this.vlrNmlTit = vlrNmlTit;
/*     */   }
/*     */   public Integer getDscAgeCob() {
/* 235 */     return this.dscAgeCob;
/*     */   }
/*     */   public void setDscAgeCob(Integer dscAgeCob) {
/* 238 */     this.dscAgeCob = dscAgeCob;
/*     */   }
/*     */   public String getDscAgeCobDV() {
/* 241 */     return this.dscAgeCobDV;
/*     */   }
/*     */   public void setDscAgeCobDV(String dscAgeCobDV) {
/* 244 */     this.dscAgeCobDV = dscAgeCobDV;
/*     */   }
/*     */   public Integer getCodEspTit() {
/* 247 */     return this.codEspTit;
/*     */   }
/*     */   public void setCodEspTit(Integer codEspTit) {
/* 250 */     this.codEspTit = codEspTit;
/*     */   }
/*     */   public String getDscIdentTit() {
/* 253 */     return this.dscIdentTit;
/*     */   }
/*     */   public void setDscIdentTit(String dscIdentTit) {
/* 256 */     this.dscIdentTit = dscIdentTit;
/*     */   }
/*     */   public Date getDtaEmissaoTit() {
/* 259 */     return this.dtaEmissaoTit;
/*     */   }
/*     */   public void setDtaEmissaoTit(Date dtaEmissaoTit) {
/* 262 */     this.dtaEmissaoTit = dtaEmissaoTit;
/*     */   }
/*     */   public Integer getCodJuros() {
/* 265 */     return this.codJuros;
/*     */   }
/*     */   public void setCodJuros(Integer codJuros) {
/* 268 */     this.codJuros = codJuros;
/*     */   }
/*     */   public Date getDtaJuros() {
/* 271 */     return this.dtaJuros;
/*     */   }
/*     */   public void setDtaJuros(Date dtaJuros) {
/* 274 */     this.dtaJuros = dtaJuros;
/*     */   }
/*     */   public BigDecimal getVlrJuros() {
/* 277 */     return this.vlrJuros;
/*     */   }
/*     */   public void setVlrJuros(BigDecimal vlrJuros) {
/* 280 */     this.vlrJuros = vlrJuros;
/*     */   }
/*     */   public Integer getCodDesc1() {
/* 283 */     return this.codDesc1;
/*     */   }
/*     */   public void setCodDesc1(Integer codDesc1) {
/* 286 */     this.codDesc1 = codDesc1;
/*     */   }
/*     */   public Date getDtaDesc1() {
/* 289 */     return this.dtaDesc1;
/*     */   }
/*     */   public void setDtaDesc1(Date dtaDesc1) {
/* 292 */     this.dtaDesc1 = dtaDesc1;
/*     */   }
/*     */   public BigDecimal getVlrPrctConc() {
/* 295 */     return this.vlrPrctConc;
/*     */   }
/*     */   public void setVlrPrctConc(BigDecimal vlrPrctConc) {
/* 298 */     this.vlrPrctConc = vlrPrctConc;
/*     */   }
/*     */   public BigDecimal getVlrIofRecolhido() {
/* 301 */     return this.vlrIofRecolhido;
/*     */   }
/*     */   public void setVlrIofRecolhido(BigDecimal vlrIofRecolhido) {
/* 304 */     this.vlrIofRecolhido = vlrIofRecolhido;
/*     */   }
/*     */   public BigDecimal getVlrAbat() {
/* 307 */     return this.vlrAbat;
/*     */   }
/*     */   public void setVlrAbat(BigDecimal vlrAbat) {
/* 310 */     this.vlrAbat = vlrAbat;
/*     */   }
/*     */   public String getDscIdentTitEmp() {
/* 313 */     return this.dscIdentTitEmp;
/*     */   }
/*     */   public void setDscIdentTitEmp(String dscIdentTitEmp) {
/* 316 */     this.dscIdentTitEmp = dscIdentTitEmp;
/*     */   }
/*     */   public Integer getCodProtesto() {
/* 319 */     return this.codProtesto;
/*     */   }
/*     */   public void setCodProtesto(Integer codProtesto) {
/* 322 */     this.codProtesto = codProtesto;
/*     */   }
/*     */   public Integer getNroDiasProt() {
/* 325 */     return this.nroDiasProt;
/*     */   }
/*     */   public void setNroDiasProt(Integer nroDiasProt) {
/* 328 */     this.nroDiasProt = nroDiasProt;
/*     */   }
/*     */   public Integer getCodBaixa() {
/* 331 */     return this.codBaixa;
/*     */   }
/*     */   public void setCodBaixa(Integer codBaixa) {
/* 334 */     this.codBaixa = codBaixa;
/*     */   }
/*     */   public String getNroDiasBaixa() {
/* 337 */     return this.nroDiasBaixa;
/*     */   }
/*     */   public void setNroDiasBaixa(String nroDiasBaixa) {
/* 340 */     this.nroDiasBaixa = nroDiasBaixa;
/*     */   }
/*     */   public Integer getCodMoeda() {
/* 343 */     return this.codMoeda;
/*     */   }
/*     */   public void setCodMoeda(Integer codMoeda) {
/* 346 */     this.codMoeda = codMoeda;
/*     */   }
/*     */   public Integer getNroContratoOpCred() {
/* 349 */     return this.nroContratoOpCred;
/*     */   }
/*     */   public void setNroContratoOpCred(Integer nroContratoOpCred) {
/* 352 */     this.nroContratoOpCred = nroContratoOpCred;
/*     */   }
/*     */   public String getDscUsoLivre1() {
/* 355 */     return this.dscUsoLivre1;
/*     */   }
/*     */   public void setDscUsoLivre1(String dscUsoLivre1) {
/* 358 */     this.dscUsoLivre1 = dscUsoLivre1;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoP.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */