/*     */ package br.com.accesstage.loader.util.vo.cargas;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ public class ArquivoCarga
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private Long codigoArquivo;
/*     */   private String dscNomeArquivoOrigem;
/*     */   private String dscNomeArquivoDestino;
/*     */   private String dscMd5sum;
/*     */   private String nmePathIn;
/*     */   private String nmePathOut;
/*     */   private String nroRegistros;
/*     */   private Long nroTamanhoArquivo;
/*     */   private String codInstanciaBpel;
/*     */   private Date dthProcessIni;
/*     */   private Date dthProcessFim;
/*     */   private Long empId;
/*     */   private String codTpoLayout;
/*     */   private String dscOrigem;
/*     */   private String codStatus;
/*     */   private Date created;
/*     */   private boolean exists;
/*     */   
/*     */   public Long getCodigoArquivo() {
/*  30 */     return this.codigoArquivo;
/*     */   }
/*     */   public void setCodigoArquivo(Long codigoArquivo) {
/*  33 */     this.codigoArquivo = codigoArquivo;
/*     */   }
/*     */   public String getDscNomeArquivoOrigem() {
/*  36 */     return this.dscNomeArquivoOrigem;
/*     */   }
/*     */   public void setDscNomeArquivoOrigem(String dscNomeArquivoOrigem) {
/*  39 */     this.dscNomeArquivoOrigem = dscNomeArquivoOrigem;
/*     */   }
/*     */   public String getDscNomeArquivoDestino() {
/*  42 */     return this.dscNomeArquivoDestino;
/*     */   }
/*     */   public void setDscNomeArquivoDestino(String dscNomeArquivoDestino) {
/*  45 */     this.dscNomeArquivoDestino = dscNomeArquivoDestino;
/*     */   }
/*     */   public String getDscMd5sum() {
/*  48 */     return this.dscMd5sum;
/*     */   }
/*     */   public void setDscMd5sum(String dscMd5sum) {
/*  51 */     this.dscMd5sum = dscMd5sum;
/*     */   }
/*     */   public String getNmePathIn() {
/*  54 */     return this.nmePathIn;
/*     */   }
/*     */   public void setNmePathIn(String nmePathIn) {
/*  57 */     this.nmePathIn = nmePathIn;
/*     */   }
/*     */   public String getNmePathOut() {
/*  60 */     return this.nmePathOut;
/*     */   }
/*     */   public void setNmePathOut(String nmePathOut) {
/*  63 */     this.nmePathOut = nmePathOut;
/*     */   }
/*     */   public String getNroRegistros() {
/*  66 */     return this.nroRegistros;
/*     */   }
/*     */   public void setNroRegistros(String nroRegistros) {
/*  69 */     this.nroRegistros = nroRegistros;
/*     */   }
/*     */   public Long getNroTamanhoArquivo() {
/*  72 */     return this.nroTamanhoArquivo;
/*     */   }
/*     */   public void setNroTamanhoArquivo(Long nroTamanhoArquivo) {
/*  75 */     this.nroTamanhoArquivo = nroTamanhoArquivo;
/*     */   }
/*     */   public String getCodInstanciaBpel() {
/*  78 */     return this.codInstanciaBpel;
/*     */   }
/*     */   public void setCodInstanciaBpel(String codInstanciaBpel) {
/*  81 */     this.codInstanciaBpel = codInstanciaBpel;
/*     */   }
/*     */   public Date getDthProcessIni() {
/*  84 */     return this.dthProcessIni;
/*     */   }
/*     */   public void setDthProcessIni(Date dthProcessIni) {
/*  87 */     this.dthProcessIni = dthProcessIni;
/*     */   }
/*     */   public Date getDthProcessFim() {
/*  90 */     return this.dthProcessFim;
/*     */   }
/*     */   public void setDthProcessFim(Date dthProcessFim) {
/*  93 */     this.dthProcessFim = dthProcessFim;
/*     */   }
/*     */   public Long getEmpId() {
/*  96 */     return this.empId;
/*     */   }
/*     */   public void setEmpId(Long empId) {
/*  99 */     this.empId = empId;
/*     */   }
/*     */   public String getCodTpoLayout() {
/* 102 */     return this.codTpoLayout;
/*     */   }
/*     */   public void setCodTpoLayout(String codTpoLayout) {
/* 105 */     this.codTpoLayout = codTpoLayout;
/*     */   }
/*     */   public String getDscOrigem() {
/* 108 */     return this.dscOrigem;
/*     */   }
/*     */   public void setDscOrigem(String dscOrigem) {
/* 111 */     this.dscOrigem = dscOrigem;
/*     */   }
/*     */   public String getCodStatus() {
/* 114 */     return this.codStatus;
/*     */   }
/*     */   public void setCodStatus(String codStatus) {
/* 117 */     this.codStatus = codStatus;
/*     */   }
/*     */   public Date getCreated() {
/* 120 */     return this.created;
/*     */   }
/*     */   public void setCreated(Date created) {
/* 123 */     this.created = created;
/*     */   }
/*     */   public boolean isExists() {
/* 126 */     return this.exists;
/*     */   }
/*     */   public void setExists(boolean exists) {
/* 129 */     this.exists = exists;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\ArquivoCarga.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */