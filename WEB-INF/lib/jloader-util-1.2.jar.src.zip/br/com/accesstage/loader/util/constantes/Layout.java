/*    */ package br.com.accesstage.loader.util.constantes;
/*    */ 
/*    */ public enum Layout
/*    */ {
/*  5 */   FEBRABAN150("FEBRABAN150"),
/*  6 */   FEBRABAN240("FEBRABAN240"),
/*  7 */   ROADCARD500("ROADCARD500");
/*    */   
/*    */   private String layout;
/*    */   
/*    */   Layout(String layout) {
/* 12 */     this.layout = layout;
/*    */   }
/*    */   
/*    */   public String getLayout() {
/* 16 */     return this.layout;
/*    */   }
/*    */   
/*    */   public void setLayout(String layout) {
/* 20 */     this.layout = layout;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\Layout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */