/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout500;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.DateDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.LongDecorator;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Detalhe
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 2670751655452352230L;
/*     */   @IntegerPositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private int tipo;
/*     */   @LongPositionalField(initialPosition = 2, finalPosition = 2)
/*     */   private Long tpInscFornedor;
/*     */   @LongPositionalField(initialPosition = 3, finalPosition = 11)
/*     */   private Long cnpjCpfFornecedor;
/*     */   @LongPositionalField(initialPosition = 12, finalPosition = 15)
/*     */   private Long filialCnpj;
/*     */   @LongPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Long cpnjControle;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 47)
/*     */   private String nomeFornecedor;
/*     */   @PositionalField(initialPosition = 48, finalPosition = 87)
/*     */   private String enderecoFornecedor;
/*     */   @LongPositionalField(initialPosition = 88, finalPosition = 92)
/*     */   private Long cepFornecedor;
/*     */   @LongPositionalField(initialPosition = 93, finalPosition = 95)
/*     */   private Long cepComplemento;
/*     */   @LongPositionalField(initialPosition = 96, finalPosition = 98)
/*     */   private Long codBancoFornecedor;
/*     */   @LongPositionalField(initialPosition = 99, finalPosition = 103)
/*     */   private Long codAgenciaFornecedor;
/*     */   @PositionalField(initialPosition = 104, finalPosition = 104)
/*     */   private String digitoAgenciaFornecedor;
/*     */   @PositionalField(initialPosition = 105, finalPosition = 117)
/*     */   private String contaCorrenteFornecedor;
/*     */   @PositionalField(initialPosition = 118, finalPosition = 119)
/*     */   private String digitoContaCorrenteFornecedor;
/*     */   @PositionalField(initialPosition = 120, finalPosition = 135)
/*     */   private String numeroPagamento;
/*     */   @LongPositionalField(initialPosition = 136, finalPosition = 138)
/*     */   private Long carteira;
/*     */   @LongPositionalField(initialPosition = 139, finalPosition = 150)
/*     */   private Long nossoNumero;
/*     */   @PositionalField(initialPosition = 151, finalPosition = 165)
/*     */   private String seuNumero;
/*     */   @PositionalField(decorator = DateDecorator.class, initialPosition = 166, finalPosition = 173)
/*     */   private Date dtaVenc;
/*     */   @PositionalField(decorator = DateDecorator.class, initialPosition = 174, finalPosition = 181)
/*     */   private Date dtaEmissaoDoc;
/*     */   @PositionalField(decorator = DateDecorator.class, initialPosition = 182, finalPosition = 189)
/*     */   private Date dtaLimDesc;
/*     */   @LongPositionalField(initialPosition = 190, finalPosition = 190)
/*     */   private Long zeros;
/*     */   @PositionalField(initialPosition = 191, finalPosition = 194)
/*     */   private String fatorVenc;
/*     */   @LongPositionalField(initialPosition = 195, finalPosition = 204)
/*     */   private Long valorDocumento;
/*     */   @LongPositionalField(initialPosition = 205, finalPosition = 219)
/*     */   private Long valorPagamento;
/*     */   @LongPositionalField(initialPosition = 220, finalPosition = 234)
/*     */   private Long valorDesconto;
/*     */   @LongPositionalField(initialPosition = 235, finalPosition = 249)
/*     */   private Long valorAcrescimo;
/*     */   @LongPositionalField(initialPosition = 250, finalPosition = 251)
/*     */   private Long tpDocumento;
/*     */   @LongPositionalField(initialPosition = 252, finalPosition = 261)
/*     */   private Long numNotaFiscalFaturaDuplicata;
/*     */   @PositionalField(initialPosition = 262, finalPosition = 263)
/*     */   private String serieDocumento;
/*     */   @LongPositionalField(initialPosition = 264, finalPosition = 265)
/*     */   private Long modalidadePagamento;
/*     */   @PositionalField(decorator = DateDecorator.class, initialPosition = 266, finalPosition = 273)
/*     */   private Date dtaEfePgto;
/*     */   @PositionalField(initialPosition = 274, finalPosition = 276)
/*     */   private String moeda;
/*     */   @PositionalField(initialPosition = 277, finalPosition = 278)
/*     */   private String situacaoAgendamento;
/*     */   @PositionalField(initialPosition = 279, finalPosition = 280)
/*     */   private String infRetorno1;
/*     */   @PositionalField(initialPosition = 281, finalPosition = 282)
/*     */   private String infRetorno2;
/*     */   @PositionalField(initialPosition = 283, finalPosition = 284)
/*     */   private String infRetorno3;
/*     */   @PositionalField(initialPosition = 285, finalPosition = 286)
/*     */   private String infRetorno4;
/*     */   @PositionalField(initialPosition = 287, finalPosition = 288)
/*     */   private String infRetorno5;
/*     */   @LongPositionalField(initialPosition = 289, finalPosition = 289)
/*     */   private Long tpMovimento;
/*     */   @LongPositionalField(initialPosition = 290, finalPosition = 291)
/*     */   private Long codMovimento;
/*     */   @PositionalField(initialPosition = 292, finalPosition = 295)
/*     */   private String horarioConsultaSaldo;
/*     */   @PositionalField(initialPosition = 296, finalPosition = 310)
/*     */   private String saldoDispHraConsulta;
/*     */   @PositionalField(initialPosition = 311, finalPosition = 325)
/*     */   private String valorTxPreFunding;
/*     */   @PositionalField(initialPosition = 326, finalPosition = 331)
/*     */   private String reservaBanco;
/*     */   @PositionalField(initialPosition = 332, finalPosition = 371)
/*     */   private String sacadorAvalista;
/*     */   @PositionalField(initialPosition = 372, finalPosition = 372)
/*     */   private String reserva;
/*     */   @PositionalField(initialPosition = 373, finalPosition = 373)
/*     */   private String nvlInfRetorno;
/*     */   @PositionalField(initialPosition = 374, finalPosition = 413)
/*     */   private String infoComplementares;
/*     */   @PositionalField(initialPosition = 414, finalPosition = 415)
/*     */   private String codAreaEmp;
/*     */   @PositionalField(initialPosition = 416, finalPosition = 450)
/*     */   private String campoUsoEmp;
/*     */   @PositionalField(initialPosition = 451, finalPosition = 472)
/*     */   private String reserva1;
/*     */   @LongPositionalField(initialPosition = 473, finalPosition = 477)
/*     */   private Long codLancamento;
/*     */   @PositionalField(initialPosition = 478, finalPosition = 478)
/*     */   private String reserva2;
/*     */   @LongPositionalField(initialPosition = 479, finalPosition = 479)
/*     */   private Long tpContaFornecedor;
/*     */   @PositionalField(initialPosition = 480, finalPosition = 486)
/*     */   private String contaComplementar;
/*     */   @PositionalField(initialPosition = 487, finalPosition = 494)
/*     */   private String reserva3;
/*     */   @PositionalField(decorator = LongDecorator.class, initialPosition = 495, finalPosition = 500)
/*     */   private Long numSeqRegistro;
/*     */   
/*     */   public int getTipo() {
/* 139 */     return this.tipo;
/*     */   }
/*     */   public void setTipo(int tipo) {
/* 142 */     int linha = getLinhaProcessada();
/* 143 */     setLinhaProcessada(linha++);
/* 144 */     this.tipo = tipo;
/*     */   }
/*     */   public Long getTpInscFornedor() {
/* 147 */     return this.tpInscFornedor;
/*     */   }
/*     */   public void setTpInscFornedor(Long tpInscFornedor) {
/* 150 */     this.tpInscFornedor = tpInscFornedor;
/*     */   }
/*     */   public Long getCnpjCpfFornecedor() {
/* 153 */     return this.cnpjCpfFornecedor;
/*     */   }
/*     */   public void setCnpjCpfFornecedor(Long cnpjCpfFornecedor) {
/* 156 */     this.cnpjCpfFornecedor = cnpjCpfFornecedor;
/*     */   }
/*     */   public Long getFilialCnpj() {
/* 159 */     return this.filialCnpj;
/*     */   }
/*     */   public void setFilialCnpj(Long filialCnpj) {
/* 162 */     this.filialCnpj = filialCnpj;
/*     */   }
/*     */   public Long getCpnjControle() {
/* 165 */     return this.cpnjControle;
/*     */   }
/*     */   public void setCpnjControle(Long cpnjControle) {
/* 168 */     this.cpnjControle = cpnjControle;
/*     */   }
/*     */   public String getNomeFornecedor() {
/* 171 */     return this.nomeFornecedor;
/*     */   }
/*     */   public void setNomeFornecedor(String nomeFornecedor) {
/* 174 */     this.nomeFornecedor = nomeFornecedor;
/*     */   }
/*     */   public String getEnderecoFornecedor() {
/* 177 */     return this.enderecoFornecedor;
/*     */   }
/*     */   public void setEnderecoFornecedor(String enderecoFornecedor) {
/* 180 */     this.enderecoFornecedor = enderecoFornecedor;
/*     */   }
/*     */   public Long getCepFornecedor() {
/* 183 */     return this.cepFornecedor;
/*     */   }
/*     */   public void setCepFornecedor(Long cepFornecedor) {
/* 186 */     this.cepFornecedor = cepFornecedor;
/*     */   }
/*     */   public Long getCepComplemento() {
/* 189 */     return this.cepComplemento;
/*     */   }
/*     */   public void setCepComplemento(Long cepComplemento) {
/* 192 */     this.cepComplemento = cepComplemento;
/*     */   }
/*     */   public Long getCodBancoFornecedor() {
/* 195 */     return this.codBancoFornecedor;
/*     */   }
/*     */   public void setCodBancoFornecedor(Long codBancoFornecedor) {
/* 198 */     this.codBancoFornecedor = codBancoFornecedor;
/*     */   }
/*     */   public Long getCodAgenciaFornecedor() {
/* 201 */     return this.codAgenciaFornecedor;
/*     */   }
/*     */   public void setCodAgenciaFornecedor(Long codAgenciaFornecedor) {
/* 204 */     this.codAgenciaFornecedor = codAgenciaFornecedor;
/*     */   }
/*     */   public String getDigitoAgenciaFornecedor() {
/* 207 */     return this.digitoAgenciaFornecedor;
/*     */   }
/*     */   public void setDigitoAgenciaFornecedor(String digitoAgenciaFornecedor) {
/* 210 */     this.digitoAgenciaFornecedor = digitoAgenciaFornecedor;
/*     */   }
/*     */   public String getContaCorrenteFornecedor() {
/* 213 */     return this.contaCorrenteFornecedor;
/*     */   }
/*     */   public void setContaCorrenteFornecedor(String contaCorrenteFornecedor) {
/* 216 */     this.contaCorrenteFornecedor = contaCorrenteFornecedor;
/*     */   }
/*     */   public String getDigitoContaCorrenteFornecedor() {
/* 219 */     return this.digitoContaCorrenteFornecedor;
/*     */   }
/*     */   public void setDigitoContaCorrenteFornecedor(String digitoContaCorrenteFornecedor) {
/* 222 */     this.digitoContaCorrenteFornecedor = digitoContaCorrenteFornecedor;
/*     */   }
/*     */   public String getNumeroPagamento() {
/* 225 */     return this.numeroPagamento;
/*     */   }
/*     */   public void setNumeroPagamento(String numeroPagamento) {
/* 228 */     this.numeroPagamento = numeroPagamento;
/*     */   }
/*     */   public Long getCarteira() {
/* 231 */     return this.carteira;
/*     */   }
/*     */   public void setCarteira(Long carteira) {
/* 234 */     this.carteira = carteira;
/*     */   }
/*     */   public Long getNossoNumero() {
/* 237 */     return this.nossoNumero;
/*     */   }
/*     */   public void setNossoNumero(Long nossoNumero) {
/* 240 */     this.nossoNumero = nossoNumero;
/*     */   }
/*     */   public String getSeuNumero() {
/* 243 */     return this.seuNumero;
/*     */   }
/*     */   public void setSeuNumero(String seuNumero) {
/* 246 */     this.seuNumero = seuNumero;
/*     */   }
/*     */   public Date getDtaVenc() {
/* 249 */     return this.dtaVenc;
/*     */   }
/*     */   public void setDtaVenc(Date dtaVenc) {
/* 252 */     this.dtaVenc = dtaVenc;
/*     */   }
/*     */   public Date getDtaEmissaoDoc() {
/* 255 */     return this.dtaEmissaoDoc;
/*     */   }
/*     */   public void setDtaEmissaoDoc(Date dtaEmissaoDoc) {
/* 258 */     this.dtaEmissaoDoc = dtaEmissaoDoc;
/*     */   }
/*     */   public Date getDtaLimDesc() {
/* 261 */     return this.dtaLimDesc;
/*     */   }
/*     */   public void setDtaLimDesc(Date dtaLimDesc) {
/* 264 */     this.dtaLimDesc = dtaLimDesc;
/*     */   }
/*     */   public Long getZeros() {
/* 267 */     return this.zeros;
/*     */   }
/*     */   public void setZeros(Long zeros) {
/* 270 */     this.zeros = zeros;
/*     */   }
/*     */   public String getFatorVenc() {
/* 273 */     return this.fatorVenc;
/*     */   }
/*     */   public void setFatorVenc(String fatorVenc) {
/* 276 */     this.fatorVenc = fatorVenc;
/*     */   }
/*     */   public Long getValorDocumento() {
/* 279 */     return this.valorDocumento;
/*     */   }
/*     */   public void setValorDocumento(Long valorDocumento) {
/* 282 */     this.valorDocumento = valorDocumento;
/*     */   }
/*     */   public Long getValorPagamento() {
/* 285 */     return this.valorPagamento;
/*     */   }
/*     */   public void setValorPagamento(Long valorPagamento) {
/* 288 */     this.valorPagamento = valorPagamento;
/*     */   }
/*     */   public Long getValorDesconto() {
/* 291 */     return this.valorDesconto;
/*     */   }
/*     */   public void setValorDesconto(Long valorDesconto) {
/* 294 */     this.valorDesconto = valorDesconto;
/*     */   }
/*     */   public Long getValorAcrescimo() {
/* 297 */     return this.valorAcrescimo;
/*     */   }
/*     */   public void setValorAcrescimo(Long valorAcrescimo) {
/* 300 */     this.valorAcrescimo = valorAcrescimo;
/*     */   }
/*     */   public Long getTpDocumento() {
/* 303 */     return this.tpDocumento;
/*     */   }
/*     */   public void setTpDocumento(Long tpDocumento) {
/* 306 */     this.tpDocumento = tpDocumento;
/*     */   }
/*     */   public Long getNumNotaFiscalFaturaDuplicata() {
/* 309 */     return this.numNotaFiscalFaturaDuplicata;
/*     */   }
/*     */   public void setNumNotaFiscalFaturaDuplicata(Long numNotaFiscalFaturaDuplicata) {
/* 312 */     this.numNotaFiscalFaturaDuplicata = numNotaFiscalFaturaDuplicata;
/*     */   }
/*     */   public String getSerieDocumento() {
/* 315 */     return this.serieDocumento;
/*     */   }
/*     */   public void setSerieDocumento(String serieDocumento) {
/* 318 */     this.serieDocumento = serieDocumento;
/*     */   }
/*     */   public Long getModalidadePagamento() {
/* 321 */     return this.modalidadePagamento;
/*     */   }
/*     */   public void setModalidadePagamento(Long modalidadePagamento) {
/* 324 */     this.modalidadePagamento = modalidadePagamento;
/*     */   }
/*     */   public Date getDtaEfePgto() {
/* 327 */     return this.dtaEfePgto;
/*     */   }
/*     */   public void setDtaEfePgto(Date dtaEfePgto) {
/* 330 */     this.dtaEfePgto = dtaEfePgto;
/*     */   }
/*     */   public String getMoeda() {
/* 333 */     return this.moeda;
/*     */   }
/*     */   public void setMoeda(String moeda) {
/* 336 */     this.moeda = moeda;
/*     */   }
/*     */   public String getSituacaoAgendamento() {
/* 339 */     return this.situacaoAgendamento;
/*     */   }
/*     */   public void setSituacaoAgendamento(String situacaoAgendamento) {
/* 342 */     this.situacaoAgendamento = situacaoAgendamento;
/*     */   }
/*     */   public String getInfRetorno1() {
/* 345 */     return this.infRetorno1;
/*     */   }
/*     */   public void setInfRetorno1(String infRetorno1) {
/* 348 */     this.infRetorno1 = infRetorno1;
/*     */   }
/*     */   public String getInfRetorno2() {
/* 351 */     return this.infRetorno2;
/*     */   }
/*     */   public void setInfRetorno2(String infRetorno2) {
/* 354 */     this.infRetorno2 = infRetorno2;
/*     */   }
/*     */   public String getInfRetorno3() {
/* 357 */     return this.infRetorno3;
/*     */   }
/*     */   public void setInfRetorno3(String infRetorno3) {
/* 360 */     this.infRetorno3 = infRetorno3;
/*     */   }
/*     */   public String getInfRetorno4() {
/* 363 */     return this.infRetorno4;
/*     */   }
/*     */   public void setInfRetorno4(String infRetorno4) {
/* 366 */     this.infRetorno4 = infRetorno4;
/*     */   }
/*     */   public String getInfRetorno5() {
/* 369 */     return this.infRetorno5;
/*     */   }
/*     */   public void setInfRetorno5(String infRetorno5) {
/* 372 */     this.infRetorno5 = infRetorno5;
/*     */   }
/*     */   public Long getTpMovimento() {
/* 375 */     return this.tpMovimento;
/*     */   }
/*     */   public void setTpMovimento(Long tpMovimento) {
/* 378 */     this.tpMovimento = tpMovimento;
/*     */   }
/*     */   public Long getCodMovimento() {
/* 381 */     return this.codMovimento;
/*     */   }
/*     */   public void setCodMovimento(Long codMovimento) {
/* 384 */     this.codMovimento = codMovimento;
/*     */   }
/*     */   public String getHorarioConsultaSaldo() {
/* 387 */     return this.horarioConsultaSaldo;
/*     */   }
/*     */   public void setHorarioConsultaSaldo(String horarioConsultaSaldo) {
/* 390 */     this.horarioConsultaSaldo = horarioConsultaSaldo;
/*     */   }
/*     */   public String getSaldoDispHraConsulta() {
/* 393 */     return this.saldoDispHraConsulta;
/*     */   }
/*     */   public void setSaldoDispHraConsulta(String saldoDispHraConsulta) {
/* 396 */     this.saldoDispHraConsulta = saldoDispHraConsulta;
/*     */   }
/*     */   public String getValorTxPreFunding() {
/* 399 */     return this.valorTxPreFunding;
/*     */   }
/*     */   public void setValorTxPreFunding(String valorTxPreFunding) {
/* 402 */     this.valorTxPreFunding = valorTxPreFunding;
/*     */   }
/*     */   public String getReservaBanco() {
/* 405 */     return this.reservaBanco;
/*     */   }
/*     */   public void setReservaBanco(String reservaBanco) {
/* 408 */     this.reservaBanco = reservaBanco;
/*     */   }
/*     */   public String getSacadorAvalista() {
/* 411 */     return this.sacadorAvalista;
/*     */   }
/*     */   public void setSacadorAvalista(String sacadorAvalista) {
/* 414 */     this.sacadorAvalista = sacadorAvalista;
/*     */   }
/*     */   public String getReserva() {
/* 417 */     return this.reserva;
/*     */   }
/*     */   public void setReserva(String reserva) {
/* 420 */     this.reserva = reserva;
/*     */   }
/*     */   public String getNvlInfRetorno() {
/* 423 */     return this.nvlInfRetorno;
/*     */   }
/*     */   public void setNvlInfRetorno(String nvlInfRetorno) {
/* 426 */     this.nvlInfRetorno = nvlInfRetorno;
/*     */   }
/*     */   public String getInfoComplementares() {
/* 429 */     return this.infoComplementares;
/*     */   }
/*     */   public void setInfoComplementares(String infoComplementares) {
/* 432 */     this.infoComplementares = infoComplementares;
/*     */   }
/*     */   public String getCodAreaEmp() {
/* 435 */     return this.codAreaEmp;
/*     */   }
/*     */   public void setCodAreaEmp(String codAreaEmp) {
/* 438 */     this.codAreaEmp = codAreaEmp;
/*     */   }
/*     */   public String getCampoUsoEmp() {
/* 441 */     return this.campoUsoEmp;
/*     */   }
/*     */   public void setCampoUsoEmp(String campoUsoEmp) {
/* 444 */     this.campoUsoEmp = campoUsoEmp;
/*     */   }
/*     */   public String getReserva1() {
/* 447 */     return this.reserva1;
/*     */   }
/*     */   public void setReserva1(String reserva1) {
/* 450 */     this.reserva1 = reserva1;
/*     */   }
/*     */   public Long getCodLancamento() {
/* 453 */     return this.codLancamento;
/*     */   }
/*     */   public void setCodLancamento(Long codLancamento) {
/* 456 */     this.codLancamento = codLancamento;
/*     */   }
/*     */   public String getReserva2() {
/* 459 */     return this.reserva2;
/*     */   }
/*     */   public void setReserva2(String reserva2) {
/* 462 */     this.reserva2 = reserva2;
/*     */   }
/*     */   public Long getTpContaFornecedor() {
/* 465 */     return this.tpContaFornecedor;
/*     */   }
/*     */   public void setTpContaFornecedor(Long tpContaFornecedor) {
/* 468 */     this.tpContaFornecedor = tpContaFornecedor;
/*     */   }
/*     */   public String getContaComplementar() {
/* 471 */     return this.contaComplementar;
/*     */   }
/*     */   public void setContaComplementar(String contaComplementar) {
/* 474 */     this.contaComplementar = contaComplementar;
/*     */   }
/*     */   public String getReserva3() {
/* 477 */     return this.reserva3;
/*     */   }
/*     */   public void setReserva3(String reserva3) {
/* 480 */     this.reserva3 = reserva3;
/*     */   }
/*     */   public Long getNumSeqRegistro() {
/* 483 */     return this.numSeqRegistro;
/*     */   }
/*     */   public void setNumSeqRegistro(Long numSeqRegistro) {
/* 486 */     this.numSeqRegistro = numSeqRegistro;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout500\Detalhe.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */