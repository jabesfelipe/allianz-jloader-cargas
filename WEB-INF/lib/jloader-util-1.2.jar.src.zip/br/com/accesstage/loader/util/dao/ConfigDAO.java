/*    */ package br.com.accesstage.loader.util.dao;
/*    */ 
/*    */ import br.com.accesstage.loader.util.dao.rowmapper.ConfigRowMapper;
/*    */ import br.com.accesstage.loader.util.vo.Config;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ import org.springframework.jdbc.core.SqlOutParameter;
/*    */ import org.springframework.jdbc.core.SqlParameter;
/*    */ import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
/*    */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*    */ import org.springframework.jdbc.core.simple.SimpleJdbcCall;
/*    */ import org.springframework.stereotype.Repository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Repository
/*    */ public class ConfigDAO
/*    */   extends BaseDAO
/*    */ {
/*    */   @Autowired
/*    */   public ConfigDAO(DataSource dataSource) {
/* 27 */     super(dataSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Config> listConfigLayout(String layout) {
/* 32 */     List<Config> list = null;
/* 33 */     SimpleJdbcCall call = new SimpleJdbcCall(getDataSource());
/* 34 */     call.withCatalogName("PKG_CONFIG");
/* 35 */     call.withProcedureName("FIND_CONFIG_LAYOUT");
/* 36 */     call.declareParameters(new SqlParameter[] { new SqlParameter("P_LAYOUT", 12), (SqlParameter)new SqlOutParameter("P_LISTA", -10) });
/*    */ 
/*    */     
/* 39 */     call.returningResultSet("P_LISTA", (RowMapper)new ConfigRowMapper());
/* 40 */     MapSqlParameterSource mapSqlParameterSource = (new MapSqlParameterSource()).addValue("P_LAYOUT", layout);
/* 41 */     Map<String, Object> m = call.execute((SqlParameterSource)mapSqlParameterSource);
/* 42 */     list = (List<Config>)m.get("P_LISTA");
/* 43 */     return list;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> mapConfigLayout(String layout) {
/* 48 */     Map<String, String> maps = new HashMap<String, String>();
/* 49 */     List<Config> list = listConfigLayout(layout);
/* 50 */     for (Config config : list) {
/* 51 */       maps.put(config.getNomeConfig(), config.getValorConfig());
/*    */     }
/* 53 */     return maps;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\ConfigDAO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */