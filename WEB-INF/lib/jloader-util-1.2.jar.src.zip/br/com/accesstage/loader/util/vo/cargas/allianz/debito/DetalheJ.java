/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "J")})
/*    */ public class DetalheJ
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 7)
/*    */   private String nroSequencial;
/*    */   @PositionalField(initialPosition = 8, finalPosition = 15)
/*    */   private String dataGeracaoArquivo;
/*    */   @PositionalField(initialPosition = 16, finalPosition = 21)
/*    */   private String totalRegistros;
/*    */   @PositionalField(initialPosition = 22, finalPosition = 38)
/*    */   private String valorTotalArquivo;
/*    */   @PositionalField(initialPosition = 39, finalPosition = 46)
/*    */   private String dataProcessamentoArquivo;
/*    */   @PositionalField(initialPosition = 47, finalPosition = 150)
/*    */   private String usoFuturo;
/*    */   
/*    */   public String getCodRegistro() {
/* 33 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 36 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getNroSequencial() {
/* 39 */     return this.nroSequencial;
/*    */   }
/*    */   public void setNroSequencial(String nroSequencial) {
/* 42 */     this.nroSequencial = nroSequencial;
/*    */   }
/*    */   public String getDataGeracaoArquivo() {
/* 45 */     return this.dataGeracaoArquivo;
/*    */   }
/*    */   public void setDataGeracaoArquivo(String dataGeracaoArquivo) {
/* 48 */     this.dataGeracaoArquivo = dataGeracaoArquivo;
/*    */   }
/*    */   public String getTotalRegistros() {
/* 51 */     return this.totalRegistros;
/*    */   }
/*    */   public void setTotalRegistros(String totalRegistros) {
/* 54 */     this.totalRegistros = totalRegistros;
/*    */   }
/*    */   public String getValorTotalArquivo() {
/* 57 */     return this.valorTotalArquivo;
/*    */   }
/*    */   public void setValorTotalArquivo(String valorTotalArquivo) {
/* 60 */     this.valorTotalArquivo = valorTotalArquivo;
/*    */   }
/*    */   public String getDataProcessamentoArquivo() {
/* 63 */     return this.dataProcessamentoArquivo;
/*    */   }
/*    */   public void setDataProcessamentoArquivo(String dataProcessamentoArquivo) {
/* 66 */     this.dataProcessamentoArquivo = dataProcessamentoArquivo;
/*    */   }
/*    */   public String getUsoFuturo() {
/* 69 */     return this.usoFuturo;
/*    */   }
/*    */   public void setUsoFuturo(String usoFuturo) {
/* 72 */     this.usoFuturo = usoFuturo;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\DetalheJ.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */