/*    */ package br.com.accesstage.loader.util.dao.rowmapper.cargas;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.allianz.debito.complementar.Detalhe;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class ComplementDetailRowMapper
/*    */   implements RowMapper<Detalhe>
/*    */ {
/*    */   public Detalhe mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 13 */     Detalhe detalhe = new Detalhe();
/* 14 */     detalhe.setCodArquivo(rs.getInt("COD_ARQUIVO"));
/* 15 */     detalhe.setHeaderLote(rs.getInt("COD_COMPL_HEADER"));
/* 16 */     detalhe.setNroUnico(rs.getInt("NRO_UNICO"));
/* 17 */     detalhe.setLinhaProcessada(rs.getInt("NRO_LINHA_ARQ"));
/* 18 */     detalhe.setEmpid(rs.getInt("EMPID"));
/* 19 */     detalhe.setCodRegistro(rs.getString("TPREGISTRO"));
/* 20 */     detalhe.setDocumento(rs.getString("CPFCNPJ"));
/* 21 */     detalhe.setTipoPessoa(rs.getString("TPPESSOA"));
/* 22 */     detalhe.setNomeCliente(rs.getString("NMCLIENTE"));
/* 23 */     detalhe.setEndereco(rs.getString("ENDERECO"));
/* 24 */     detalhe.setBairro(rs.getString("BAIRRO"));
/* 25 */     detalhe.setCidade(rs.getString("CIDADE"));
/* 26 */     detalhe.setEstado(rs.getString("ESTADO"));
/* 27 */     detalhe.setCep(rs.getString("CEP"));
/* 28 */     detalhe.setPoliza(rs.getString("POLIZA"));
/* 29 */     detalhe.setApolice(rs.getString("APOLICE"));
/* 30 */     detalhe.setEndosso(rs.getString("ENDOSSO"));
/* 31 */     detalhe.setParcela(rs.getString("PARCELA"));
/* 32 */     detalhe.setPlano(rs.getString("PLANO"));
/* 33 */     detalhe.setRecibo(rs.getString("RECIBO"));
/* 34 */     detalhe.setDataVencimento(rs.getString("DTVENCIMENTO"));
/* 35 */     detalhe.setDsProduto(rs.getString("DSPRODUTO"));
/* 36 */     detalhe.setBancoDebito(rs.getString("BANCODEBITO"));
/* 37 */     detalhe.setAgencia(rs.getString("AGENCIA"));
/* 38 */     detalhe.setAgenciaDV(rs.getString("DVAGENCIA"));
/* 39 */     detalhe.setContaCorrente(rs.getString("CONTACORRENTE"));
/* 40 */     detalhe.setContaCorrenteDV(rs.getString("DVCONTA"));
/* 41 */     detalhe.setDataPrevCancelamento(rs.getString("DTPREVCANCELAMENTO"));
/* 42 */     detalhe.setEmailCliente(rs.getString("EMAILCLIENTE"));
/* 43 */     detalhe.setCelularCliente(rs.getString("CELULARCLIENTE"));
/* 44 */     detalhe.setEmailCorretor(rs.getString("EMAILCORRETOR"));
/* 45 */     detalhe.setCelularCorretor(rs.getString("CELULARCORRETOR"));
/* 46 */     detalhe.setCodRejeicaoDebito(rs.getString("CODREJEICAODEBITO"));
/* 47 */     detalhe.setBancoBoleto(rs.getString("BANCOBOLETO"));
/* 48 */     detalhe.setNossoNumero(rs.getString("NOSSONUMERO"));
/* 49 */     detalhe.setLinhaDigitavel(rs.getString("LINHADIGITAVEL"));
/* 50 */     detalhe.setCodigoBarras(rs.getString("CODIGOBARRAS"));
/* 51 */     detalhe.setFiller(rs.getString("FILLER"));
/* 52 */     detalhe.setAliquotaIOF(rs.getString("ALIQUOTAIOF"));
/* 53 */     detalhe.setValorBoleto(rs.getString("VALORBOLETO"));
/* 54 */     detalhe.setVencimentoBoleto(rs.getString("VENCIMENTOBOLETO"));
/* 55 */     detalhe.setTipoCobranca(rs.getString("TIPOCOBRANCA"));
/* 56 */     detalhe.setValorRetorno(rs.getString("VLR_DEBITO_RET"));
/* 57 */     detalhe.setNroUnico(rs.getInt("NRO_UNICO"));
/* 58 */     detalhe.setCodRetorno(rs.getString("COD_RETORNO"));
/* 59 */     detalhe.setVlrJuros(rs.getString("VLR_MULTA"));
/* 60 */     detalhe.setDscComplemento(rs.getString("DSC_REGISTRO_COMPLEMENTO_SAIDA"));
/*    */     
/* 62 */     detalhe.setDtaProcessamento(rs.getString("DTA_PROCESSAMENTO"));
/* 63 */     detalhe.setDtaEmissao(rs.getString("DTA_EMISSAO"));
/* 64 */     return detalhe;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\cargas\ComplementDetailRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */