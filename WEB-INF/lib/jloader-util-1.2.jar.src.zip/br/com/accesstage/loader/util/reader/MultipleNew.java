/*    */ package br.com.accesstage.loader.util.reader;
/*    */ 
/*    */ import br.com.accesstage.loader.util.commom.ffpojo.Constantes150;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout150.DetalheF;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout150.DetalheFV4;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout150.DetalheG;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout150.Febraban150VO;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout150.Header;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout150.Trailler;
/*    */ import com.github.ffpojo.FFPojoHelper;
/*    */ import com.github.ffpojo.container.HybridMetadataContainer;
/*    */ import com.github.ffpojo.metadata.RecordDescriptor;
/*    */ import com.github.ffpojo.metadata.extra.FFPojoAnnotationFieldManager;
/*    */ import com.github.ffpojo.metadata.positional.PositionalRecordDescriptor;
/*    */ import com.github.ffpojo.parser.PositionalRecordParser;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.List;
/*    */ import org.apache.commons.io.IOUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipleNew
/*    */   implements Constantes150
/*    */ {
/* 30 */   public static String FILE_INPUT = "/data/1618634@2348921@BBDARET@201804020161990";
/*    */   
/* 32 */   public static FFPojoHelper ffPojoHelper = FFPojoHelper.getInstance();
/* 33 */   public static FFPojoAnnotationFieldManager annotationFieldManager = new FFPojoAnnotationFieldManager();
/*    */   
/*    */   public static void main(String[] args) {
/* 36 */     HybridMetadataContainer hybridMetadataContainer = new HybridMetadataContainer();
/* 37 */     PositionalRecordParser parser = null;
/* 38 */     Febraban150VO febraban150vo = new Febraban150VO();
/* 39 */     File files = new File(FILE_INPUT);
/*    */     try {
/* 41 */       InputStream bis = new FileInputStream(files);
/* 42 */       List<String> lines = IOUtils.readLines(bis, "UTF-8");
/* 43 */       boolean v4 = false;
/* 44 */       for (int index = 0; index < lines.size(); index++) {
/* 45 */         String linha = lines.get(index);
/* 46 */         String codRegistro = linha.substring(0, 1);
/* 47 */         RecordDescriptor recordDescriptor = null;
/* 48 */         if ("A".equalsIgnoreCase(codRegistro)) {
/* 49 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(Header.class);
/* 50 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 51 */           Header header = (Header)parser.parseFromText(Header.class, linha);
/* 52 */           v4 = header.isV4();
/* 53 */           febraban150vo.setHeader(header);
/*    */         } 
/* 55 */         if ("F".equalsIgnoreCase(codRegistro)) {
/* 56 */           if (v4) {
/* 57 */             recordDescriptor = hybridMetadataContainer.getRecordDescriptor(DetalheFV4.class);
/* 58 */             parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 59 */             DetalheFV4 detalheFV4 = (DetalheFV4)parser.parseFromText(DetalheFV4.class, linha);
/* 60 */             febraban150vo.getListDetalheFV4().add(detalheFV4);
/*    */           } else {
/* 62 */             recordDescriptor = hybridMetadataContainer.getRecordDescriptor(DetalheF.class);
/* 63 */             parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 64 */             DetalheF detalheF = (DetalheF)parser.parseFromText(DetalheF.class, linha);
/* 65 */             febraban150vo.getListDetalheF().add(detalheF);
/*    */           } 
/*    */         }
/* 68 */         if ("G".equalsIgnoreCase(codRegistro)) {
/* 69 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(DetalheG.class);
/* 70 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 71 */           DetalheG detalheG = (DetalheG)parser.parseFromText(DetalheG.class, linha);
/* 72 */           febraban150vo.getListDetalheG().add(detalheG);
/*    */         } 
/* 74 */         if ("Z".equalsIgnoreCase(codRegistro)) {
/* 75 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(Trailler.class);
/* 76 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 77 */           Trailler trailler = (Trailler)parser.parseFromText(Trailler.class, linha);
/* 78 */           febraban150vo.setTrailler(trailler);
/*    */         } 
/*    */       } 
/* 81 */       System.out.println("AQUI");
/* 82 */     } catch (FileNotFoundException e) {
/* 83 */       e.printStackTrace();
/* 84 */     } catch (IOException e) {
/* 85 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\reader\MultipleNew.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */