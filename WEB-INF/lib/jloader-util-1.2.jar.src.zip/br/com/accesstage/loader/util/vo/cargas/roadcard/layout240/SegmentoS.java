/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoS
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -4840317574414392375L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeq;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegReg;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 15, finalPosition = 16)
/*     */   private Integer codMovRmss;
/*     */   @IntegerPositionalField(initialPosition = 17, finalPosition = 17)
/*     */   private Integer codTpoImpressao;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 19)
/*     */   private Integer nroLinhaImpressa;
/*     */   @PositionalField(initialPosition = 20, finalPosition = 159)
/*     */   private String dscMensagem1Str;
/*     */   @IntegerPositionalField(initialPosition = 160, finalPosition = 161)
/*     */   private Integer tpoCaracterImpresso;
/*     */   @PositionalField(initialPosition = 162, finalPosition = 240)
/*     */   private String dscUsoFebraban2;
/*     */   
/*     */   public String getCodBco() {
/*  43 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  46 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  49 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  52 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  55 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  58 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeq() {
/*  61 */     return this.nroSeq;
/*     */   }
/*     */   public void setNroSeq(Integer nroSeq) {
/*  64 */     this.nroSeq = nroSeq;
/*     */   }
/*     */   public String getCodSegReg() {
/*  67 */     return this.codSegReg;
/*     */   }
/*     */   public void setCodSegReg(String codSegReg) {
/*  70 */     this.codSegReg = codSegReg;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  73 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  76 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMovRmss() {
/*  79 */     return this.codMovRmss;
/*     */   }
/*     */   public void setCodMovRmss(Integer codMovRmss) {
/*  82 */     this.codMovRmss = codMovRmss;
/*     */   }
/*     */   public Integer getCodTpoImpressao() {
/*  85 */     return this.codTpoImpressao;
/*     */   }
/*     */   public void setCodTpoImpressao(Integer codTpoImpressao) {
/*  88 */     this.codTpoImpressao = codTpoImpressao;
/*     */   }
/*     */   public Integer getNroLinhaImpressa() {
/*  91 */     return this.nroLinhaImpressa;
/*     */   }
/*     */   public void setNroLinhaImpressa(Integer nroLinhaImpressa) {
/*  94 */     this.nroLinhaImpressa = nroLinhaImpressa;
/*     */   }
/*     */   public String getDscMensagem1Str() {
/*  97 */     return this.dscMensagem1Str;
/*     */   }
/*     */   public void setDscMensagem1Str(String dscMensagem1Str) {
/* 100 */     this.dscMensagem1Str = dscMensagem1Str;
/*     */   }
/*     */   public Integer getTpoCaracterImpresso() {
/* 103 */     return this.tpoCaracterImpresso;
/*     */   }
/*     */   public void setTpoCaracterImpresso(Integer tpoCaracterImpresso) {
/* 106 */     this.tpoCaracterImpresso = tpoCaracterImpresso;
/*     */   }
/*     */   public String getDscUsoFebraban2() {
/* 109 */     return this.dscUsoFebraban2;
/*     */   }
/*     */   public void setDscUsoFebraban2(String dscUsoFebraban2) {
/* 112 */     this.dscUsoFebraban2 = dscUsoFebraban2;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */