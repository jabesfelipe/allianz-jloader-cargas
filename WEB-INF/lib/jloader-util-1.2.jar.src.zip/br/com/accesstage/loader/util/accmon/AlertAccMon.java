/*    */ package br.com.accesstage.loader.util.accmon;
/*    */ 
/*    */ import br.com.accesstage.loader.util.commom.AbstractLayout;
/*    */ import br.com.accesstage.loader.util.constantes.carga.ConfigPropertiesUtils;
/*    */ import br.com.accesstage.loader.util.dao.BaseDAO;
/*    */ import br.com.accesstage.loader.util.exception.LayoutException;
/*    */ import java.io.Serializable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Component;
/*    */ 
/*    */ 
/*    */ @Component
/*    */ public class AlertAccMon
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private AbstractLayout layout;
/*    */   private static final String SELECT_ARQUIVO_CARGA = "SELECT COD_ARQUIVO, COD_INSTANCIA_BPEL, COD_STATUS_CARGA, COD_TPO_LAYOUT, DSC_MD5SUM, DSC_NOME_ARQUIVO_DESTINO, DSC_NOME_ARQUIVO_ORIGEM, DSC_ORIGEM, DTH_PROCESS_FIM, DTH_PROCESS_INI, EMPID, NME_PATH_IN, NME_PATH_OUT, NRO_REGISTROS, NRO_TAMANHO_ARQUIVO FROM ARQUIVO_CARGA WHERE COD_ARQUIVO = ?";
/* 20 */   private static Logger logger = Logger.getLogger("[ASCargasIncomm | AccMon] - ");
/*    */   
/* 22 */   private static String hostnameAccMon = ConfigPropertiesUtils.getStringValue("urlAccMon");
/*    */   
/*    */   @Autowired
/*    */   private BaseDAO baseDAO;
/*    */ 
/*    */   
/*    */   public AlertAccMon() {}
/*    */ 
/*    */   
/*    */   public AlertAccMon(AbstractLayout layout) {
/* 32 */     this.layout = layout;
/*    */   }
/*    */   
/*    */   public void alertaAccMon(String ocorrencia) throws LayoutException {}
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\accmon\AlertAccMon.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */