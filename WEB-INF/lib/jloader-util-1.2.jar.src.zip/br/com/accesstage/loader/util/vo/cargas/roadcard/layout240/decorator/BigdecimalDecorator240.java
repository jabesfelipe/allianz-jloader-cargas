package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator;

public class BigdecimalDecorator240 {}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\decorator\BigdecimalDecorator240.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */