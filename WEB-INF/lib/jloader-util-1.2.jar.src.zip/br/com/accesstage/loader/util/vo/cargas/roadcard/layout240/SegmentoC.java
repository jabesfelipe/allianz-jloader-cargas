/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoC
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -2883620513180132269L;
/*     */   @LongPositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private Long codBanco;
/*     */   @LongPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Long loteServico;
/*     */   @LongPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Long tpoRegistro;
/*     */   @LongPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Long nroSeqLote;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegRegistro;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 17)
/*     */   private String dscReservado;
/*     */   @LongPositionalField(initialPosition = 18, finalPosition = 32)
/*     */   private Long vlrIr;
/*     */   @LongPositionalField(initialPosition = 33, finalPosition = 47)
/*     */   private Long vlrIss;
/*     */   @LongPositionalField(initialPosition = 48, finalPosition = 62)
/*     */   private Long vlrIof;
/*     */   @LongPositionalField(initialPosition = 63, finalPosition = 78)
/*     */   private Long vlrDeducoes;
/*     */   @LongPositionalField(initialPosition = 79, finalPosition = 93)
/*     */   private Long vlrAcrescimos;
/*     */   @LongPositionalField(initialPosition = 94, finalPosition = 98)
/*     */   private Long codAgFavorecido;
/*     */   @PositionalField(initialPosition = 99, finalPosition = 99)
/*     */   private String digAg;
/*     */   @LongPositionalField(initialPosition = 100, finalPosition = 111)
/*     */   private Long nroCc;
/*     */   @PositionalField(initialPosition = 112, finalPosition = 112)
/*     */   private String nroDigCc;
/*     */   @PositionalField(initialPosition = 113, finalPosition = 113)
/*     */   private String nroDigAgCc;
/*     */   @LongPositionalField(initialPosition = 114, finalPosition = 128)
/*     */   private Long vlrInss;
/*     */   @PositionalField(initialPosition = 129, finalPosition = 240)
/*     */   private String dscReservado1;
/*     */   
/*     */   public Long getCodBanco() {
/*  56 */     return this.codBanco;
/*     */   }
/*     */   public void setCodBanco(Long codBanco) {
/*  59 */     this.codBanco = codBanco;
/*     */   }
/*     */   public Long getLoteServico() {
/*  62 */     return this.loteServico;
/*     */   }
/*     */   public void setLoteServico(Long loteServico) {
/*  65 */     this.loteServico = loteServico;
/*     */   }
/*     */   public Long getTpoRegistro() {
/*  68 */     return this.tpoRegistro;
/*     */   }
/*     */   public void setTpoRegistro(Long tpoRegistro) {
/*  71 */     this.tpoRegistro = tpoRegistro;
/*     */   }
/*     */   public Long getNroSeqLote() {
/*  74 */     return this.nroSeqLote;
/*     */   }
/*     */   public void setNroSeqLote(Long nroSeqLote) {
/*  77 */     this.nroSeqLote = nroSeqLote;
/*     */   }
/*     */   public String getCodSegRegistro() {
/*  80 */     return this.codSegRegistro;
/*     */   }
/*     */   public void setCodSegRegistro(String codSegRegistro) {
/*  83 */     this.codSegRegistro = codSegRegistro;
/*     */   }
/*     */   public String getDscReservado() {
/*  86 */     return this.dscReservado;
/*     */   }
/*     */   public void setDscReservado(String dscReservado) {
/*  89 */     this.dscReservado = dscReservado;
/*     */   }
/*     */   public Long getVlrIr() {
/*  92 */     return this.vlrIr;
/*     */   }
/*     */   public void setVlrIr(Long vlrIr) {
/*  95 */     this.vlrIr = vlrIr;
/*     */   }
/*     */   public Long getVlrIss() {
/*  98 */     return this.vlrIss;
/*     */   }
/*     */   public void setVlrIss(Long vlrIss) {
/* 101 */     this.vlrIss = vlrIss;
/*     */   }
/*     */   public Long getVlrIof() {
/* 104 */     return this.vlrIof;
/*     */   }
/*     */   public void setVlrIof(Long vlrIof) {
/* 107 */     this.vlrIof = vlrIof;
/*     */   }
/*     */   public Long getVlrDeducoes() {
/* 110 */     return this.vlrDeducoes;
/*     */   }
/*     */   public void setVlrDeducoes(Long vlrDeducoes) {
/* 113 */     this.vlrDeducoes = vlrDeducoes;
/*     */   }
/*     */   public Long getVlrAcrescimos() {
/* 116 */     return this.vlrAcrescimos;
/*     */   }
/*     */   public void setVlrAcrescimos(Long vlrAcrescimos) {
/* 119 */     this.vlrAcrescimos = vlrAcrescimos;
/*     */   }
/*     */   public Long getCodAgFavorecido() {
/* 122 */     return this.codAgFavorecido;
/*     */   }
/*     */   public void setCodAgFavorecido(Long codAgFavorecido) {
/* 125 */     this.codAgFavorecido = codAgFavorecido;
/*     */   }
/*     */   public String getDigAg() {
/* 128 */     return this.digAg;
/*     */   }
/*     */   public void setDigAg(String digAg) {
/* 131 */     this.digAg = digAg;
/*     */   }
/*     */   public Long getNroCc() {
/* 134 */     return this.nroCc;
/*     */   }
/*     */   public void setNroCc(Long nroCc) {
/* 137 */     this.nroCc = nroCc;
/*     */   }
/*     */   public String getNroDigCc() {
/* 140 */     return this.nroDigCc;
/*     */   }
/*     */   public void setNroDigCc(String nroDigCc) {
/* 143 */     this.nroDigCc = nroDigCc;
/*     */   }
/*     */   public String getNroDigAgCc() {
/* 146 */     return this.nroDigAgCc;
/*     */   }
/*     */   public void setNroDigAgCc(String nroDigAgCc) {
/* 149 */     this.nroDigAgCc = nroDigAgCc;
/*     */   }
/*     */   public Long getVlrInss() {
/* 152 */     return this.vlrInss;
/*     */   }
/*     */   public void setVlrInss(Long vlrInss) {
/* 155 */     this.vlrInss = vlrInss;
/*     */   }
/*     */   public String getDscReservado1() {
/* 158 */     return this.dscReservado1;
/*     */   }
/*     */   public void setDscReservado1(String dscReservado1) {
/* 161 */     this.dscReservado1 = dscReservado1;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */