/*     */ package br.com.accesstage.loader.util.vo.cargas;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VarejistaVO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7404978597981245915L;
/*     */   private String dscNomeArquivoFat;
/*     */   private String dscNomeLegal;
/*     */   private String dscTipoFatura;
/*     */   private String dscLocalizacao;
/*     */   private String dscTpoCobranca;
/*     */   private Long dscPrazoPagamento;
/*     */   private String nroInscricaoVarejista;
/*     */   private String dscRazaoSocialVarejista;
/*     */   private String tpoIncricaoVarejista;
/*     */   private String dscEndereco;
/*     */   private String dscBairro;
/*     */   private String dscCep;
/*     */   private String dscCidade;
/*     */   private String dscUnidadeFederativa;
/*     */   private String dscEmail;
/*     */   private String dtaCadastro;
/*     */   
/*     */   public void setDscNomeArquivoFat(String dscNomeArquivoFat) {
/*  31 */     this.dscNomeArquivoFat = dscNomeArquivoFat;
/*     */   }
/*     */   
/*     */   public String getDscNomeArquivoFat() {
/*  35 */     return this.dscNomeArquivoFat;
/*     */   }
/*     */   
/*     */   public void setDscNomeLegal(String dscNomeLegal) {
/*  39 */     this.dscNomeLegal = dscNomeLegal;
/*     */   }
/*     */   
/*     */   public String getDscNomeLegal() {
/*  43 */     return this.dscNomeLegal;
/*     */   }
/*     */   
/*     */   public void setDscTipoFatura(String dscTipoFatura) {
/*  47 */     this.dscTipoFatura = dscTipoFatura;
/*     */   }
/*     */   
/*     */   public String getDscTipoFatura() {
/*  51 */     return this.dscTipoFatura;
/*     */   }
/*     */   
/*     */   public void setDscLocalizacao(String dscLocalizacao) {
/*  55 */     this.dscLocalizacao = dscLocalizacao;
/*     */   }
/*     */   
/*     */   public String getDscLocalizacao() {
/*  59 */     return this.dscLocalizacao;
/*     */   }
/*     */   
/*     */   public void setDscTpoCobranca(String dscTpoCobranca) {
/*  63 */     this.dscTpoCobranca = dscTpoCobranca;
/*     */   }
/*     */   
/*     */   public String getDscTpoCobranca() {
/*  67 */     return this.dscTpoCobranca;
/*     */   }
/*     */   
/*     */   public void setDscPrazoPagamento(Long dscPrazoPagamento) {
/*  71 */     this.dscPrazoPagamento = dscPrazoPagamento;
/*     */   }
/*     */   
/*     */   public Long getDscPrazoPagamento() {
/*  75 */     return this.dscPrazoPagamento;
/*     */   }
/*     */   
/*     */   public void setNroInscricaoVarejista(String nroInscricaoVarejista) {
/*  79 */     this.nroInscricaoVarejista = nroInscricaoVarejista;
/*     */   }
/*     */   
/*     */   public String getNroInscricaoVarejista() {
/*  83 */     return this.nroInscricaoVarejista;
/*     */   }
/*     */   
/*     */   public void setDscRazaoSocialVarejista(String dscRazaoSocialVarejista) {
/*  87 */     this.dscRazaoSocialVarejista = dscRazaoSocialVarejista;
/*     */   }
/*     */   
/*     */   public String getDscRazaoSocialVarejista() {
/*  91 */     return this.dscRazaoSocialVarejista;
/*     */   }
/*     */   
/*     */   public void setDscEndereco(String dscEndereco) {
/*  95 */     this.dscEndereco = dscEndereco;
/*     */   }
/*     */   
/*     */   public String getDscEndereco() {
/*  99 */     return this.dscEndereco;
/*     */   }
/*     */   
/*     */   public void setDscBairro(String dscBairro) {
/* 103 */     this.dscBairro = dscBairro;
/*     */   }
/*     */   
/*     */   public String getDscBairro() {
/* 107 */     return this.dscBairro;
/*     */   }
/*     */   
/*     */   public void setDscCep(String dscCep) {
/* 111 */     this.dscCep = dscCep;
/*     */   }
/*     */   
/*     */   public String getDscCep() {
/* 115 */     return this.dscCep;
/*     */   }
/*     */   
/*     */   public void setDscCidade(String dscCidade) {
/* 119 */     this.dscCidade = dscCidade;
/*     */   }
/*     */   
/*     */   public String getDscCidade() {
/* 123 */     return this.dscCidade;
/*     */   }
/*     */   
/*     */   public void setDscUnidadeFederativa(String dscUnidadeFederativa) {
/* 127 */     this.dscUnidadeFederativa = dscUnidadeFederativa;
/*     */   }
/*     */   
/*     */   public String getDscUnidadeFederativa() {
/* 131 */     return this.dscUnidadeFederativa;
/*     */   }
/*     */   
/*     */   public void setDscEmail(String dscEmail) {
/* 135 */     this.dscEmail = dscEmail;
/*     */   }
/*     */   
/*     */   public String getDscEmail() {
/* 139 */     return this.dscEmail;
/*     */   }
/*     */   
/*     */   public void setDtaCadastro(String dtaCadastro) {
/* 143 */     this.dtaCadastro = dtaCadastro;
/*     */   }
/*     */   
/*     */   public String getDtaCadastro() {
/* 147 */     return this.dtaCadastro;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 153 */     return "" + this.dscNomeArquivoFat + this.dscNomeLegal + this.dscTipoFatura + this.dscLocalizacao + this.dscTpoCobranca + this.dscPrazoPagamento + this.nroInscricaoVarejista + this.dscRazaoSocialVarejista + this.tpoIncricaoVarejista + this.dscEndereco + this.dscBairro + this.dscCep + this.dscCidade + this.dscUnidadeFederativa + this.dscEmail;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTpoIncricaoVarejista(String tpoIncricaoVarejista) {
/* 159 */     this.tpoIncricaoVarejista = tpoIncricaoVarejista;
/*     */   }
/*     */   
/*     */   public String getTpoIncricaoVarejista() {
/* 163 */     return this.tpoIncricaoVarejista;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\VarejistaVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */