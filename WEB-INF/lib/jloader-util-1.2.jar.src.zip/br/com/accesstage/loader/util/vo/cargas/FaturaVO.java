/*     */ package br.com.accesstage.loader.util.vo.cargas;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FaturaVO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6858790676468973228L;
/*     */   private String dscCountry;
/*     */   private String dscLegalName;
/*     */   private String dscLocation;
/*     */   private String dscState;
/*     */   private String dscTerminal;
/*     */   private String dscProduct;
/*     */   private String dscUpc;
/*     */   private String dscSku;
/*     */   private String dscCurrency;
/*     */   private Double vlrUnitCost;
/*     */   private String dscSerialNumber;
/*     */   private String dscVan16;
/*     */   private Date dtaFatura;
/*     */   private String hraFatura;
/*     */   private String dscRefNumber;
/*     */   private String dscStan;
/*     */   private String dscTransType;
/*     */   private Long qtdTransCount;
/*     */   private Double vlrGross;
/*     */   private Double vlrComission;
/*     */   private Double vlrTransFee;
/*     */   private Double vlrVat;
/*     */   private Double vlrTotal;
/*     */   private String nroNossoNumero;
/*     */   private Long nroTrkidin;
/*     */   private String nroDocumento;
/*     */   private String nmeArqFatura;
/*     */   private Date dtaLocal;
/*     */   private String hraLocal;
/*     */   
/*     */   public void setDscCountry(String dscCountry) {
/*  47 */     this.dscCountry = dscCountry;
/*     */   }
/*     */   
/*     */   public String getDscCountry() {
/*  51 */     return this.dscCountry;
/*     */   }
/*     */   
/*     */   public void setDscLegalName(String dscLegalName) {
/*  55 */     this.dscLegalName = dscLegalName;
/*     */   }
/*     */   
/*     */   public String getDscLegalName() {
/*  59 */     return this.dscLegalName;
/*     */   }
/*     */   
/*     */   public void setDscLocation(String dscLocation) {
/*  63 */     this.dscLocation = dscLocation;
/*     */   }
/*     */   
/*     */   public String getDscLocation() {
/*  67 */     return this.dscLocation;
/*     */   }
/*     */   
/*     */   public void setDscState(String dscState) {
/*  71 */     this.dscState = dscState;
/*     */   }
/*     */   
/*     */   public String getDscState() {
/*  75 */     return this.dscState;
/*     */   }
/*     */   
/*     */   public void setDscTerminal(String dscTerminal) {
/*  79 */     this.dscTerminal = dscTerminal;
/*     */   }
/*     */   
/*     */   public String getDscTerminal() {
/*  83 */     return this.dscTerminal;
/*     */   }
/*     */   
/*     */   public void setDscProduct(String dscProduct) {
/*  87 */     this.dscProduct = dscProduct;
/*     */   }
/*     */   
/*     */   public String getDscProduct() {
/*  91 */     return this.dscProduct;
/*     */   }
/*     */   
/*     */   public void setDscUpc(String dscUpc) {
/*  95 */     this.dscUpc = dscUpc;
/*     */   }
/*     */   
/*     */   public String getDscUpc() {
/*  99 */     return this.dscUpc;
/*     */   }
/*     */   
/*     */   public void setDscSku(String dscSku) {
/* 103 */     this.dscSku = dscSku;
/*     */   }
/*     */   
/*     */   public String getDscSku() {
/* 107 */     return this.dscSku;
/*     */   }
/*     */   
/*     */   public void setDscCurrency(String dscCurrency) {
/* 111 */     this.dscCurrency = dscCurrency;
/*     */   }
/*     */   
/*     */   public String getDscCurrency() {
/* 115 */     return this.dscCurrency;
/*     */   }
/*     */   
/*     */   public void setVlrUnitCost(Double vlrUnitCost) {
/* 119 */     this.vlrUnitCost = vlrUnitCost;
/*     */   }
/*     */   
/*     */   public Double getVlrUnitCost() {
/* 123 */     return this.vlrUnitCost;
/*     */   }
/*     */   
/*     */   public void setDscSerialNumber(String dscSerialNumber) {
/* 127 */     this.dscSerialNumber = dscSerialNumber;
/*     */   }
/*     */   
/*     */   public String getDscSerialNumber() {
/* 131 */     return this.dscSerialNumber;
/*     */   }
/*     */   
/*     */   public void setDscVan16(String dscVan16) {
/* 135 */     this.dscVan16 = dscVan16;
/*     */   }
/*     */   
/*     */   public String getDscVan16() {
/* 139 */     return this.dscVan16;
/*     */   }
/*     */   
/*     */   public void setDtaFatura(Date dtaFatura) {
/* 143 */     this.dtaFatura = dtaFatura;
/*     */   }
/*     */   
/*     */   public Date getDtaFatura() {
/* 147 */     return this.dtaFatura;
/*     */   }
/*     */   
/*     */   public void setHraFatura(String hraFatura) {
/* 151 */     this.hraFatura = hraFatura;
/*     */   }
/*     */   
/*     */   public String getHraFatura() {
/* 155 */     return this.hraFatura;
/*     */   }
/*     */   
/*     */   public void setDscRefNumber(String dscRefNumber) {
/* 159 */     this.dscRefNumber = dscRefNumber;
/*     */   }
/*     */   
/*     */   public String getDscRefNumber() {
/* 163 */     return this.dscRefNumber;
/*     */   }
/*     */   
/*     */   public void setDscStan(String dscStan) {
/* 167 */     this.dscStan = dscStan;
/*     */   }
/*     */   
/*     */   public String getDscStan() {
/* 171 */     return this.dscStan;
/*     */   }
/*     */   
/*     */   public void setDscTransType(String dscTransType) {
/* 175 */     this.dscTransType = dscTransType;
/*     */   }
/*     */   
/*     */   public String getDscTransType() {
/* 179 */     return this.dscTransType;
/*     */   }
/*     */   
/*     */   public void setQtdTransCount(Long qtdTransCount) {
/* 183 */     this.qtdTransCount = qtdTransCount;
/*     */   }
/*     */   
/*     */   public Long getQtdTransCount() {
/* 187 */     return this.qtdTransCount;
/*     */   }
/*     */   
/*     */   public void setVlrGross(Double vlrGross) {
/* 191 */     this.vlrGross = vlrGross;
/*     */   }
/*     */   
/*     */   public Double getVlrGross() {
/* 195 */     return this.vlrGross;
/*     */   }
/*     */   
/*     */   public void setVlrComission(Double vlrComission) {
/* 199 */     this.vlrComission = vlrComission;
/*     */   }
/*     */   
/*     */   public Double getVlrComission() {
/* 203 */     return this.vlrComission;
/*     */   }
/*     */   
/*     */   public void setVlrTransFee(Double vlrTransFee) {
/* 207 */     this.vlrTransFee = vlrTransFee;
/*     */   }
/*     */   
/*     */   public Double getVlrTransFee() {
/* 211 */     return this.vlrTransFee;
/*     */   }
/*     */   
/*     */   public void setVlrVat(Double vlrVat) {
/* 215 */     this.vlrVat = vlrVat;
/*     */   }
/*     */   
/*     */   public Double getVlrVat() {
/* 219 */     return this.vlrVat;
/*     */   }
/*     */   
/*     */   public void setVlrTotal(Double vlrTotal) {
/* 223 */     this.vlrTotal = vlrTotal;
/*     */   }
/*     */   
/*     */   public Double getVlrTotal() {
/* 227 */     return this.vlrTotal;
/*     */   }
/*     */   
/*     */   public void setNroNossoNumero(String nroNossoNumero) {
/* 231 */     this.nroNossoNumero = nroNossoNumero;
/*     */   }
/*     */   
/*     */   public String getNroNossoNumero() {
/* 235 */     return this.nroNossoNumero;
/*     */   }
/*     */   
/*     */   public void setNroTrkidin(Long nroTrkidin) {
/* 239 */     this.nroTrkidin = nroTrkidin;
/*     */   }
/*     */   
/*     */   public Long getNroTrkidin() {
/* 243 */     return this.nroTrkidin;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 248 */     return "" + this.dscCountry + this.dscLegalName + this.dscLocation + this.dscState + this.dscTerminal + this.dscProduct + this.dscUpc + this.dscSku + this.dscCurrency + this.vlrUnitCost + this.dscSerialNumber + this.dscVan16 + this.dtaFatura + this.hraFatura + this.dscRefNumber + this.dscStan + this.dscTransType + this.qtdTransCount + this.vlrGross + this.vlrComission + this.vlrTransFee + this.vlrVat + this.vlrTotal + this.nroNossoNumero + this.nroTrkidin + this.nroDocumento + this.nmeArqFatura + this.dtaLocal + this.hraLocal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNroDocumento(String nroDocumento) {
/* 254 */     this.nroDocumento = nroDocumento;
/*     */   }
/*     */   
/*     */   public String getNroDocumento() {
/* 258 */     return this.nroDocumento;
/*     */   }
/*     */   
/*     */   public void setNmeArqFatura(String nmeArqFatura) {
/* 262 */     this.nmeArqFatura = nmeArqFatura;
/*     */   }
/*     */   
/*     */   public String getNmeArqFatura() {
/* 266 */     return this.nmeArqFatura;
/*     */   }
/*     */   
/*     */   public void setDtaLocal(Date dtaLocal) {
/* 270 */     this.dtaLocal = dtaLocal;
/*     */   }
/*     */   
/*     */   public Date getDtaLocal() {
/* 274 */     return this.dtaLocal;
/*     */   }
/*     */   
/*     */   public void setHraLocal(String hraLocal) {
/* 278 */     this.hraLocal = hraLocal;
/*     */   }
/*     */   
/*     */   public String getHraLocal() {
/* 282 */     return this.hraLocal;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\FaturaVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */