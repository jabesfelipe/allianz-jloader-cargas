/*    */ package br.com.accesstage.loader.util.vo.cargas;
/*    */ 
/*    */ public class Ancora
/*    */ {
/*    */   private String codAncora;
/*    */   
/*    */   public String getCodAncora() {
/*  8 */     return this.codAncora;
/*    */   }
/*    */   
/*    */   public void setCodAncora(String codAncora) {
/* 12 */     this.codAncora = codAncora;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\Ancora.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */