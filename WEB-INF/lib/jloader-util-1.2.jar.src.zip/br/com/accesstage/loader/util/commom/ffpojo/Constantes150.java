package br.com.accesstage.loader.util.commom.ffpojo;

public interface Constantes150 {
  public static final String REG_HEADER = "A";
  
  public static final String REG_CORPO_B = "B";
  
  public static final String REG_CORPO_F = "F";
  
  public static final String REG_CORPO_G = "G";
  
  public static final String REG_TRAILLER = "Z";
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\commom\ffpojo\Constantes150.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */