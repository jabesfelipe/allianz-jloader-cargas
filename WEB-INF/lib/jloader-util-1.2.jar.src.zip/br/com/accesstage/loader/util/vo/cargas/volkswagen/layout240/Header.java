/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Header
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBcoHdrArq;
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private String lteServicoHdrArq;
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private String tpoRegHdrArq;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*     */   private String dscUsoFbrn1;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private String tpoIncsEmp;
/*     */   @PositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private String nroInscEmp;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 52)
/*     */   private String codConvenio;
/*     */   @PositionalField(initialPosition = 53, finalPosition = 57)
/*     */   private String dscAgencia;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 58)
/*     */   private String dscAgenciaDV;
/*     */   @PositionalField(initialPosition = 59, finalPosition = 70)
/*     */   private String dscConta;
/*     */   @PositionalField(initialPosition = 71, finalPosition = 71)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 72, finalPosition = 72)
/*     */   private String dscAgCtaDV;
/*     */   @PositionalField(initialPosition = 73, finalPosition = 102)
/*     */   private String nmeEmp;
/*     */   @PositionalField(initialPosition = 103, finalPosition = 132)
/*     */   private String nmeBco;
/*     */   @PositionalField(initialPosition = 133, finalPosition = 142)
/*     */   private String dscUsoFbrn2;
/*     */   @PositionalField(initialPosition = 143, finalPosition = 143)
/*     */   private String nroRmssRtrn;
/*     */   @PositionalField(initialPosition = 144, finalPosition = 151)
/*     */   private String dtaGeracaoArq;
/*     */   @PositionalField(initialPosition = 152, finalPosition = 157)
/*     */   private String hraGeracaoArq;
/*     */   @PositionalField(initialPosition = 158, finalPosition = 163)
/*     */   private String nroNsa;
/*     */   @PositionalField(initialPosition = 164, finalPosition = 166)
/*     */   private String nroLytArq;
/*     */   @PositionalField(initialPosition = 167, finalPosition = 171)
/*     */   private String codDensidade;
/*     */   @PositionalField(initialPosition = 172, finalPosition = 191)
/*     */   private String dscResercadoBco;
/*     */   @PositionalField(initialPosition = 192, finalPosition = 211)
/*     */   private String dscResercadoEmp;
/*     */   @PositionalField(initialPosition = 212, finalPosition = 240)
/*     */   private String dscUsoFbrn3;
/*     */   
/*     */   public String getCodBcoHdrArq() {
/*  70 */     return this.codBcoHdrArq;
/*     */   }
/*     */   public void setCodBcoHdrArq(String codBcoHdrArq) {
/*  73 */     this.codBcoHdrArq = codBcoHdrArq;
/*     */   }
/*     */   public String getLteServicoHdrArq() {
/*  76 */     return this.lteServicoHdrArq;
/*     */   }
/*     */   public void setLteServicoHdrArq(String lteServicoHdrArq) {
/*  79 */     this.lteServicoHdrArq = lteServicoHdrArq;
/*     */   }
/*     */   public String getTpoRegHdrArq() {
/*  82 */     return this.tpoRegHdrArq;
/*     */   }
/*     */   public void setTpoRegHdrArq(String tpoRegHdrArq) {
/*  85 */     this.tpoRegHdrArq = tpoRegHdrArq;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  88 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  91 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public String getTpoIncsEmp() {
/*  94 */     return this.tpoIncsEmp;
/*     */   }
/*     */   public void setTpoIncsEmp(String tpoIncsEmp) {
/*  97 */     this.tpoIncsEmp = tpoIncsEmp;
/*     */   }
/*     */   public String getNroInscEmp() {
/* 100 */     return this.nroInscEmp;
/*     */   }
/*     */   public void setNroInscEmp(String nroInscEmp) {
/* 103 */     this.nroInscEmp = nroInscEmp;
/*     */   }
/*     */   public String getCodConvenio() {
/* 106 */     return this.codConvenio;
/*     */   }
/*     */   public void setCodConvenio(String codConvenio) {
/* 109 */     this.codConvenio = codConvenio;
/*     */   }
/*     */   public String getDscAgencia() {
/* 112 */     return this.dscAgencia;
/*     */   }
/*     */   public void setDscAgencia(String dscAgencia) {
/* 115 */     this.dscAgencia = dscAgencia;
/*     */   }
/*     */   public String getDscAgenciaDV() {
/* 118 */     return this.dscAgenciaDV;
/*     */   }
/*     */   public void setDscAgenciaDV(String dscAgenciaDV) {
/* 121 */     this.dscAgenciaDV = dscAgenciaDV;
/*     */   }
/*     */   public String getDscConta() {
/* 124 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(String dscConta) {
/* 127 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 130 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 133 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgCtaDV() {
/* 136 */     return this.dscAgCtaDV;
/*     */   }
/*     */   public void setDscAgCtaDV(String dscAgCtaDV) {
/* 139 */     this.dscAgCtaDV = dscAgCtaDV;
/*     */   }
/*     */   public String getNmeEmp() {
/* 142 */     return this.nmeEmp;
/*     */   }
/*     */   public void setNmeEmp(String nmeEmp) {
/* 145 */     this.nmeEmp = nmeEmp;
/*     */   }
/*     */   public String getNmeBco() {
/* 148 */     return this.nmeBco;
/*     */   }
/*     */   public void setNmeBco(String nmeBco) {
/* 151 */     this.nmeBco = nmeBco;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 154 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 157 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public String getNroRmssRtrn() {
/* 160 */     return this.nroRmssRtrn;
/*     */   }
/*     */   public void setNroRmssRtrn(String nroRmssRtrn) {
/* 163 */     this.nroRmssRtrn = nroRmssRtrn;
/*     */   }
/*     */   public String getDtaGeracaoArq() {
/* 166 */     return this.dtaGeracaoArq;
/*     */   }
/*     */   public void setDtaGeracaoArq(String dtaGeracaoArq) {
/* 169 */     this.dtaGeracaoArq = dtaGeracaoArq;
/*     */   }
/*     */   public String getHraGeracaoArq() {
/* 172 */     return this.hraGeracaoArq;
/*     */   }
/*     */   public void setHraGeracaoArq(String hraGeracaoArq) {
/* 175 */     this.hraGeracaoArq = hraGeracaoArq;
/*     */   }
/*     */   public String getNroNsa() {
/* 178 */     return this.nroNsa;
/*     */   }
/*     */   public void setNroNsa(String nroNsa) {
/* 181 */     this.nroNsa = nroNsa;
/*     */   }
/*     */   public String getNroLytArq() {
/* 184 */     return this.nroLytArq;
/*     */   }
/*     */   public void setNroLytArq(String nroLytArq) {
/* 187 */     this.nroLytArq = nroLytArq;
/*     */   }
/*     */   public String getCodDensidade() {
/* 190 */     return this.codDensidade;
/*     */   }
/*     */   public void setCodDensidade(String codDensidade) {
/* 193 */     this.codDensidade = codDensidade;
/*     */   }
/*     */   public String getDscResercadoBco() {
/* 196 */     return this.dscResercadoBco;
/*     */   }
/*     */   public void setDscResercadoBco(String dscResercadoBco) {
/* 199 */     this.dscResercadoBco = dscResercadoBco;
/*     */   }
/*     */   public String getDscResercadoEmp() {
/* 202 */     return this.dscResercadoEmp;
/*     */   }
/*     */   public void setDscResercadoEmp(String dscResercadoEmp) {
/* 205 */     this.dscResercadoEmp = dscResercadoEmp;
/*     */   }
/*     */   public String getDscUsoFbrn3() {
/* 208 */     return this.dscUsoFbrn3;
/*     */   }
/*     */   public void setDscUsoFbrn3(String dscUsoFbrn3) {
/* 211 */     this.dscUsoFbrn3 = dscUsoFbrn3;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */