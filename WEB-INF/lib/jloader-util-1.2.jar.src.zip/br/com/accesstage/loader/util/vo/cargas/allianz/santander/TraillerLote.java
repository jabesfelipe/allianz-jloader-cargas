/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.santander;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.PaddingAlign;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord
/*    */ public class TraillerLote
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 3)
/* 18 */   private String codBco = "033";
/*    */   @PositionalField(initialPosition = 4, finalPosition = 7)
/* 20 */   private String lteServico = "0001";
/*    */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/* 22 */   private Integer tpoReg = Integer.valueOf(5);
/*    */   
/*    */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*    */   private String dscUsoFbrn1;
/*    */   @PositionalField(initialPosition = 18, finalPosition = 23)
/*    */   private String qtdeRegistros;
/*    */   @PositionalField(initialPosition = 24, finalPosition = 240, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*    */   private String dscUsoFbrn2;
/*    */   
/*    */   public String getCodBco() {
/* 32 */     return this.codBco;
/*    */   }
/*    */   public void setCodBco(String codBco) {
/* 35 */     this.codBco = codBco;
/*    */   }
/*    */   public String getLteServico() {
/* 38 */     return this.lteServico;
/*    */   }
/*    */   public void setLteServico(String lteServico) {
/* 41 */     this.lteServico = lteServico;
/*    */   }
/*    */   public Integer getTpoReg() {
/* 44 */     return this.tpoReg;
/*    */   }
/*    */   public void setTpoReg(Integer tpoReg) {
/* 47 */     this.tpoReg = tpoReg;
/*    */   }
/*    */   public String getDscUsoFbrn1() {
/* 50 */     return this.dscUsoFbrn1;
/*    */   }
/*    */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 53 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*    */   }
/*    */   public String getQtdeRegistros() {
/* 56 */     return this.qtdeRegistros;
/*    */   }
/*    */   public void setQtdeRegistros(String qtdeRegistros) {
/* 59 */     this.qtdeRegistros = qtdeRegistros;
/*    */   }
/*    */   public String getDscUsoFbrn2() {
/* 62 */     return this.dscUsoFbrn2;
/*    */   }
/*    */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 65 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\santander\TraillerLote.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */