/*    */ package br.com.accesstage.loader.util.commom.ffpojo;
/*    */ 
/*    */ import com.github.ffpojo.metadata.positional.annotation.AccessorType;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ public abstract class FieldDescriptor
/*    */ {
/*    */   private Method getter;
/*    */   private Field field;
/* 12 */   private AccessorType accessorType = AccessorType.PROPERTY;
/*    */ 
/*    */ 
/*    */   
/*    */   public Method getGetter() {
/* 17 */     return this.getter;
/*    */   }
/*    */   public void setGetter(Method getter) {
/* 20 */     this.getter = getter;
/*    */   }
/*    */   public Field getField() {
/* 23 */     return this.field;
/*    */   }
/*    */   public void setField(Field field) {
/* 26 */     this.field = field;
/*    */   }
/*    */   public AccessorType getAccessorType() {
/* 29 */     return this.accessorType;
/*    */   }
/*    */   public void setAccessorType(AccessorType accessorType) {
/* 32 */     this.accessorType = accessorType;
/*    */   }
/*    */   
/*    */   public boolean isByField() {
/* 36 */     return this.accessorType.isByField();
/*    */   }
/*    */   
/*    */   public boolean isByProperty() {
/* 40 */     return this.accessorType.isByProperty();
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\commom\ffpojo\FieldDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */