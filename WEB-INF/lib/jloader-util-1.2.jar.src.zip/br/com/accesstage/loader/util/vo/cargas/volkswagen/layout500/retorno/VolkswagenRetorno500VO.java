/*    */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout500.retorno;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VolkswagenRetorno500VO
/*    */ {
/*    */   private Header header;
/* 13 */   private List<Detalhe> listaDetalhe = new ArrayList<Detalhe>();
/*    */   private Trailler trailler;
/*    */   
/*    */   public Header getHeader() {
/* 17 */     return this.header;
/*    */   }
/*    */   
/*    */   public void setHeader(Header header) {
/* 21 */     this.header = header;
/*    */   }
/*    */   
/*    */   public List<Detalhe> getListaDetalhe() {
/* 25 */     return this.listaDetalhe;
/*    */   }
/*    */   
/*    */   public void setListaDetalhe(List<Detalhe> listDetalhe) {
/* 29 */     this.listaDetalhe = listDetalhe;
/*    */   }
/*    */   
/*    */   public Trailler getTrailler() {
/* 33 */     return this.trailler;
/*    */   }
/*    */   
/*    */   public void setTrailler(Trailler trailler) {
/* 37 */     this.trailler = trailler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout500\retorno\VolkswagenRetorno500VO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */