/*     */ package br.com.accesstage.loader.util.vo;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenVO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -9124098262862828466L;
/*     */   private String token;
/*     */   private String tpoArquivo;
/*     */   private String codBanco;
/*     */   private String dtaGeracao;
/*     */   private String pathArquivoGerado;
/*     */   private String senderExport;
/*     */   private String receiverExport;
/*     */   private String doctypeExport;
/*     */   
/*     */   public String getToken() {
/*  29 */     return this.token;
/*     */   }
/*     */   
/*     */   public void setToken(String token) {
/*  33 */     this.token = token;
/*     */   }
/*     */   
/*     */   public String getTpoArquivo() {
/*  37 */     return this.tpoArquivo;
/*     */   }
/*     */   
/*     */   public void setTpoArquivo(String tpoArquivo) {
/*  41 */     this.tpoArquivo = tpoArquivo;
/*     */   }
/*     */   
/*     */   public String getCodBanco() {
/*  45 */     return this.codBanco;
/*     */   }
/*     */   
/*     */   public void setCodBanco(String codBanco) {
/*  49 */     this.codBanco = codBanco;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDtaGeracao() {
/*  55 */     return this.dtaGeracao;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDtaGeracao(String dtaGeracao) {
/*  61 */     this.dtaGeracao = dtaGeracao;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPathArquivoGerado() {
/*  67 */     return this.pathArquivoGerado;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathArquivoGerado(String pathArquivoGerado) {
/*  73 */     this.pathArquivoGerado = pathArquivoGerado;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSenderExport() {
/*  79 */     return this.senderExport;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSenderExport(String senderExport) {
/*  85 */     this.senderExport = senderExport;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getReceiverExport() {
/*  91 */     return this.receiverExport;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReceiverExport(String receiverExport) {
/*  97 */     this.receiverExport = receiverExport;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDoctypeExport() {
/* 103 */     return this.doctypeExport;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDoctypeExport(String doctypeExport) {
/* 109 */     this.doctypeExport = doctypeExport;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     StringBuffer txt = new StringBuffer();
/*     */     
/* 116 */     txt.append("TokenVO = [ ");
/* 117 */     txt.append(" | token: " + this.token);
/* 118 */     txt.append(" | tpoArquivo: " + this.tpoArquivo);
/* 119 */     txt.append(" | codBanco: " + this.codBanco);
/* 120 */     txt.append(" | dtaGeracao: " + this.dtaGeracao);
/* 121 */     txt.append(" ]");
/*     */     
/* 123 */     return txt.toString();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\TokenVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */