/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class TrllExtL033
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 518043771536823995L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private Integer tpoInscEmp;
/*     */   @LongPositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private Long nroInscEmp;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 52)
/*     */   private String codConvenio;
/*     */   @IntegerPositionalField(initialPosition = 53, finalPosition = 57)
/*     */   private Integer dscAgencia;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 58)
/*     */   private String dscAgenciaDV;
/*     */   @LongPositionalField(initialPosition = 59, finalPosition = 70)
/*     */   private Long dscConta;
/*     */   @PositionalField(initialPosition = 71, finalPosition = 71)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 72, finalPosition = 72)
/*     */   private String dscAgCtaDV;
/*     */   @PositionalField(initialPosition = 73, finalPosition = 88)
/*     */   private String dscUsoFbrn2;
/*     */   @PositionalField(initialPosition = 89, finalPosition = 106, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrSaldoBloqAcima24;
/*     */   @PositionalField(initialPosition = 107, finalPosition = 124, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrLimite;
/*     */   @PositionalField(initialPosition = 125, finalPosition = 142, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrSaldoBloqAte24;
/*     */   @PositionalField(initialPosition = 143, finalPosition = 150, decorator = DateDecorator240.class)
/*     */   private Date dtaSldFinal;
/*     */   @PositionalField(initialPosition = 151, finalPosition = 168, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrSaldoFinal;
/*     */   @PositionalField(initialPosition = 169, finalPosition = 169)
/*     */   private String dscSituacaoSldFinal;
/*     */   @PositionalField(initialPosition = 170, finalPosition = 170)
/*     */   private String dscStatusSldFinal;
/*     */   @IntegerPositionalField(initialPosition = 171, finalPosition = 176)
/*     */   private Integer qtdReg;
/*     */   @PositionalField(initialPosition = 177, finalPosition = 194, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrSomaDeb;
/*     */   @PositionalField(initialPosition = 195, finalPosition = 212, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrSomaCred;
/*     */   @PositionalField(initialPosition = 213, finalPosition = 240)
/*     */   private String dscUsoFbrn3;
/*     */   
/*     */   public String getCodBco() {
/*  73 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  76 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  79 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  82 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  85 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  88 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  91 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  94 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getTpoInscEmp() {
/*  97 */     return this.tpoInscEmp;
/*     */   }
/*     */   public void setTpoInscEmp(Integer tpoInscEmp) {
/* 100 */     this.tpoInscEmp = tpoInscEmp;
/*     */   }
/*     */   public Long getNroInscEmp() {
/* 103 */     return this.nroInscEmp;
/*     */   }
/*     */   public void setNroInscEmp(Long nroInscEmp) {
/* 106 */     this.nroInscEmp = nroInscEmp;
/*     */   }
/*     */   public String getCodConvenio() {
/* 109 */     return this.codConvenio;
/*     */   }
/*     */   public void setCodConvenio(String codConvenio) {
/* 112 */     this.codConvenio = codConvenio;
/*     */   }
/*     */   public Integer getDscAgencia() {
/* 115 */     return this.dscAgencia;
/*     */   }
/*     */   public void setDscAgencia(Integer dscAgencia) {
/* 118 */     this.dscAgencia = dscAgencia;
/*     */   }
/*     */   public String getDscAgenciaDV() {
/* 121 */     return this.dscAgenciaDV;
/*     */   }
/*     */   public void setDscAgenciaDV(String dscAgenciaDV) {
/* 124 */     this.dscAgenciaDV = dscAgenciaDV;
/*     */   }
/*     */   public Long getDscConta() {
/* 127 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(Long dscConta) {
/* 130 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 133 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 136 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgCtaDV() {
/* 139 */     return this.dscAgCtaDV;
/*     */   }
/*     */   public void setDscAgCtaDV(String dscAgCtaDV) {
/* 142 */     this.dscAgCtaDV = dscAgCtaDV;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 145 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 148 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public BigDecimal getVlrSaldoBloqAcima24() {
/* 151 */     return this.vlrSaldoBloqAcima24;
/*     */   }
/*     */   public void setVlrSaldoBloqAcima24(BigDecimal vlrSaldoBloqAcima24) {
/* 154 */     this.vlrSaldoBloqAcima24 = vlrSaldoBloqAcima24;
/*     */   }
/*     */   public BigDecimal getVlrLimite() {
/* 157 */     return this.vlrLimite;
/*     */   }
/*     */   public void setVlrLimite(BigDecimal vlrLimite) {
/* 160 */     this.vlrLimite = vlrLimite;
/*     */   }
/*     */   public BigDecimal getVlrSaldoBloqAte24() {
/* 163 */     return this.vlrSaldoBloqAte24;
/*     */   }
/*     */   public void setVlrSaldoBloqAte24(BigDecimal vlrSaldoBloqAte24) {
/* 166 */     this.vlrSaldoBloqAte24 = vlrSaldoBloqAte24;
/*     */   }
/*     */   public Date getDtaSldFinal() {
/* 169 */     return this.dtaSldFinal;
/*     */   }
/*     */   public void setDtaSldFinal(Date dtaSldFinal) {
/* 172 */     this.dtaSldFinal = dtaSldFinal;
/*     */   }
/*     */   public BigDecimal getVlrSaldoFinal() {
/* 175 */     return this.vlrSaldoFinal;
/*     */   }
/*     */   public void setVlrSaldoFinal(BigDecimal vlrSaldoFinal) {
/* 178 */     this.vlrSaldoFinal = vlrSaldoFinal;
/*     */   }
/*     */   public String getDscSituacaoSldFinal() {
/* 181 */     return this.dscSituacaoSldFinal;
/*     */   }
/*     */   public void setDscSituacaoSldFinal(String dscSituacaoSldFinal) {
/* 184 */     this.dscSituacaoSldFinal = dscSituacaoSldFinal;
/*     */   }
/*     */   public String getDscStatusSldFinal() {
/* 187 */     return this.dscStatusSldFinal;
/*     */   }
/*     */   public void setDscStatusSldFinal(String dscStatusSldFinal) {
/* 190 */     this.dscStatusSldFinal = dscStatusSldFinal;
/*     */   }
/*     */   public Integer getQtdReg() {
/* 193 */     return this.qtdReg;
/*     */   }
/*     */   public void setQtdReg(Integer qtdReg) {
/* 196 */     this.qtdReg = qtdReg;
/*     */   }
/*     */   public BigDecimal getVlrSomaDeb() {
/* 199 */     return this.vlrSomaDeb;
/*     */   }
/*     */   public void setVlrSomaDeb(BigDecimal vlrSomaDeb) {
/* 202 */     this.vlrSomaDeb = vlrSomaDeb;
/*     */   }
/*     */   public BigDecimal getVlrSomaCred() {
/* 205 */     return this.vlrSomaCred;
/*     */   }
/*     */   public void setVlrSomaCred(BigDecimal vlrSomaCred) {
/* 208 */     this.vlrSomaCred = vlrSomaCred;
/*     */   }
/*     */   public String getDscUsoFbrn3() {
/* 211 */     return this.dscUsoFbrn3;
/*     */   }
/*     */   public void setDscUsoFbrn3(String dscUsoFbrn3) {
/* 214 */     this.dscUsoFbrn3 = dscUsoFbrn3;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\TrllExtL033.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */