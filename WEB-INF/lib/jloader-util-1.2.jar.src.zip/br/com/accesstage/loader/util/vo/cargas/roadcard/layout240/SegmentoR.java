/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoR
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -4545297353111431259L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeq;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegReg;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Integer codMovRmss;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private Integer codDesconto2;
/*     */   @PositionalField(initialPosition = 19, finalPosition = 26, decorator = DateDecorator240.class)
/*     */   private Date dtaDesconto2;
/*     */   @PositionalField(initialPosition = 27, finalPosition = 41, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrPrctlConcedido2;
/*     */   @IntegerPositionalField(initialPosition = 42, finalPosition = 42)
/*     */   private Integer codDesconto3;
/*     */   @PositionalField(initialPosition = 43, finalPosition = 50, decorator = DateDecorator240.class)
/*     */   private Date dtaDesconto3;
/*     */   @PositionalField(initialPosition = 51, finalPosition = 65, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrPrctlConcedido3;
/*     */   @PositionalField(initialPosition = 66, finalPosition = 66)
/*     */   private String codMulta;
/*     */   @PositionalField(initialPosition = 67, finalPosition = 74, decorator = DateDecorator240.class)
/*     */   private Date dtaMulta;
/*     */   @PositionalField(initialPosition = 75, finalPosition = 89, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrPrctlAplicado;
/*     */   @PositionalField(initialPosition = 90, finalPosition = 99)
/*     */   private String dscInfoSacado;
/*     */   @PositionalField(initialPosition = 100, finalPosition = 139)
/*     */   private String dscMensagem3;
/*     */   @PositionalField(initialPosition = 140, finalPosition = 179)
/*     */   private String dscMensagem4;
/*     */   @PositionalField(initialPosition = 180, finalPosition = 199)
/*     */   private String dscUsoFebraban2;
/*     */   @IntegerPositionalField(initialPosition = 200, finalPosition = 207)
/*     */   private Integer codOcorrenciaSacado;
/*     */   @IntegerPositionalField(initialPosition = 208, finalPosition = 210)
/*     */   private Integer codBancoContaDebito;
/*     */   @IntegerPositionalField(initialPosition = 211, finalPosition = 215)
/*     */   private Integer dscAgenciaDebito;
/*     */   @PositionalField(initialPosition = 216, finalPosition = 216)
/*     */   private String dscAgenciaDv;
/*     */   @LongPositionalField(initialPosition = 217, finalPosition = 228)
/*     */   private Long dscContaDebito;
/*     */   @PositionalField(initialPosition = 229, finalPosition = 229)
/*     */   private String dscContaDv;
/*     */   @PositionalField(initialPosition = 230, finalPosition = 230)
/*     */   private String dscContaAgenciaDv;
/*     */   String codDebitoAutomaticoStr;
/*     */   @IntegerPositionalField(initialPosition = 231, finalPosition = 231)
/*     */   private Integer codDebitoAutomatico;
/*     */   @PositionalField(initialPosition = 232, finalPosition = 232)
/*     */   private String dscUsoFebraban3;
/*     */   @PositionalField(initialPosition = 233, finalPosition = 240)
/*     */   private String blankSpace;
/*     */   
/*     */   public String getCodBco() {
/*  86 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  89 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  92 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  95 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  98 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/* 101 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeq() {
/* 104 */     return this.nroSeq;
/*     */   }
/*     */   public void setNroSeq(Integer nroSeq) {
/* 107 */     this.nroSeq = nroSeq;
/*     */   }
/*     */   public String getCodSegReg() {
/* 110 */     return this.codSegReg;
/*     */   }
/*     */   public void setCodSegReg(String codSegReg) {
/* 113 */     this.codSegReg = codSegReg;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 116 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 119 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMovRmss() {
/* 122 */     return this.codMovRmss;
/*     */   }
/*     */   public void setCodMovRmss(Integer codMovRmss) {
/* 125 */     this.codMovRmss = codMovRmss;
/*     */   }
/*     */   public Integer getCodDesconto2() {
/* 128 */     return this.codDesconto2;
/*     */   }
/*     */   public void setCodDesconto2(Integer codDesconto2) {
/* 131 */     this.codDesconto2 = codDesconto2;
/*     */   }
/*     */   public Date getDtaDesconto2() {
/* 134 */     return this.dtaDesconto2;
/*     */   }
/*     */   public void setDtaDesconto2(Date dtaDesconto2) {
/* 137 */     this.dtaDesconto2 = dtaDesconto2;
/*     */   }
/*     */   public BigDecimal getVlrPrctlConcedido2() {
/* 140 */     return this.vlrPrctlConcedido2;
/*     */   }
/*     */   public void setVlrPrctlConcedido2(BigDecimal vlrPrctlConcedido2) {
/* 143 */     this.vlrPrctlConcedido2 = vlrPrctlConcedido2;
/*     */   }
/*     */   public Integer getCodDesconto3() {
/* 146 */     return this.codDesconto3;
/*     */   }
/*     */   public void setCodDesconto3(Integer codDesconto3) {
/* 149 */     this.codDesconto3 = codDesconto3;
/*     */   }
/*     */   public Date getDtaDesconto3() {
/* 152 */     return this.dtaDesconto3;
/*     */   }
/*     */   public void setDtaDesconto3(Date dtaDesconto3) {
/* 155 */     this.dtaDesconto3 = dtaDesconto3;
/*     */   }
/*     */   public BigDecimal getVlrPrctlConcedido3() {
/* 158 */     return this.vlrPrctlConcedido3;
/*     */   }
/*     */   public void setVlrPrctlConcedido3(BigDecimal vlrPrctlConcedido3) {
/* 161 */     this.vlrPrctlConcedido3 = vlrPrctlConcedido3;
/*     */   }
/*     */   public String getCodMulta() {
/* 164 */     return this.codMulta;
/*     */   }
/*     */   public void setCodMulta(String codMulta) {
/* 167 */     this.codMulta = codMulta;
/*     */   }
/*     */   public Date getDtaMulta() {
/* 170 */     return this.dtaMulta;
/*     */   }
/*     */   public void setDtaMulta(Date dtaMulta) {
/* 173 */     this.dtaMulta = dtaMulta;
/*     */   }
/*     */   public BigDecimal getVlrPrctlAplicado() {
/* 176 */     return this.vlrPrctlAplicado;
/*     */   }
/*     */   public void setVlrPrctlAplicado(BigDecimal vlrPrctlAplicado) {
/* 179 */     this.vlrPrctlAplicado = vlrPrctlAplicado;
/*     */   }
/*     */   public String getDscInfoSacado() {
/* 182 */     return this.dscInfoSacado;
/*     */   }
/*     */   public void setDscInfoSacado(String dscInfoSacado) {
/* 185 */     this.dscInfoSacado = dscInfoSacado;
/*     */   }
/*     */   public String getDscMensagem3() {
/* 188 */     return this.dscMensagem3;
/*     */   }
/*     */   public void setDscMensagem3(String dscMensagem3) {
/* 191 */     this.dscMensagem3 = dscMensagem3;
/*     */   }
/*     */   public String getDscMensagem4() {
/* 194 */     return this.dscMensagem4;
/*     */   }
/*     */   public void setDscMensagem4(String dscMensagem4) {
/* 197 */     this.dscMensagem4 = dscMensagem4;
/*     */   }
/*     */   public String getDscUsoFebraban2() {
/* 200 */     return this.dscUsoFebraban2;
/*     */   }
/*     */   public void setDscUsoFebraban2(String dscUsoFebraban2) {
/* 203 */     this.dscUsoFebraban2 = dscUsoFebraban2;
/*     */   }
/*     */   public Integer getCodOcorrenciaSacado() {
/* 206 */     return this.codOcorrenciaSacado;
/*     */   }
/*     */   public void setCodOcorrenciaSacado(Integer codOcorrenciaSacado) {
/* 209 */     this.codOcorrenciaSacado = codOcorrenciaSacado;
/*     */   }
/*     */   public Integer getCodBancoContaDebito() {
/* 212 */     return this.codBancoContaDebito;
/*     */   }
/*     */   public void setCodBancoContaDebito(Integer codBancoContaDebito) {
/* 215 */     this.codBancoContaDebito = codBancoContaDebito;
/*     */   }
/*     */   public Integer getDscAgenciaDebito() {
/* 218 */     return this.dscAgenciaDebito;
/*     */   }
/*     */   public void setDscAgenciaDebito(Integer dscAgenciaDebito) {
/* 221 */     this.dscAgenciaDebito = dscAgenciaDebito;
/*     */   }
/*     */   public String getDscAgenciaDv() {
/* 224 */     return this.dscAgenciaDv;
/*     */   }
/*     */   public void setDscAgenciaDv(String dscAgenciaDv) {
/* 227 */     this.dscAgenciaDv = dscAgenciaDv;
/*     */   }
/*     */   public Long getDscContaDebito() {
/* 230 */     return this.dscContaDebito;
/*     */   }
/*     */   public void setDscContaDebito(Long dscContaDebito) {
/* 233 */     this.dscContaDebito = dscContaDebito;
/*     */   }
/*     */   public String getDscContaDv() {
/* 236 */     return this.dscContaDv;
/*     */   }
/*     */   public void setDscContaDv(String dscContaDv) {
/* 239 */     this.dscContaDv = dscContaDv;
/*     */   }
/*     */   public String getDscContaAgenciaDv() {
/* 242 */     return this.dscContaAgenciaDv;
/*     */   }
/*     */   public void setDscContaAgenciaDv(String dscContaAgenciaDv) {
/* 245 */     this.dscContaAgenciaDv = dscContaAgenciaDv;
/*     */   }
/*     */   public String getCodDebitoAutomaticoStr() {
/* 248 */     return this.codDebitoAutomaticoStr;
/*     */   }
/*     */   public void setCodDebitoAutomaticoStr(String codDebitoAutomaticoStr) {
/* 251 */     this.codDebitoAutomaticoStr = codDebitoAutomaticoStr;
/*     */   }
/*     */   public Integer getCodDebitoAutomatico() {
/* 254 */     return this.codDebitoAutomatico;
/*     */   }
/*     */   public void setCodDebitoAutomatico(Integer codDebitoAutomatico) {
/* 257 */     this.codDebitoAutomatico = codDebitoAutomatico;
/*     */   }
/*     */   public String getDscUsoFebraban3() {
/* 260 */     return this.dscUsoFebraban3;
/*     */   }
/*     */   public void setDscUsoFebraban3(String dscUsoFebraban3) {
/* 263 */     this.dscUsoFebraban3 = dscUsoFebraban3;
/*     */   }
/*     */   public String getBlankSpace() {
/* 266 */     return this.blankSpace;
/*     */   }
/*     */   public void setBlankSpace(String blankSpace) {
/* 269 */     this.blankSpace = blankSpace;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoR.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */