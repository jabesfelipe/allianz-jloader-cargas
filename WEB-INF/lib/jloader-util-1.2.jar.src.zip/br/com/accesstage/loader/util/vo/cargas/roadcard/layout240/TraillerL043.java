/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord
/*    */ public class TraillerL043
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 3986860354071988653L;
/*    */   @LongPositionalField(initialPosition = 1, finalPosition = 3)
/*    */   private Long codBancoTrllr;
/*    */   @LongPositionalField(initialPosition = 4, finalPosition = 7)
/*    */   private Long codLoteTrllr;
/*    */   @LongPositionalField(initialPosition = 8, finalPosition = 8)
/*    */   private Long codTpoServTrllr;
/*    */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*    */   private String dscReservadoTrllr;
/*    */   @LongPositionalField(initialPosition = 18, finalPosition = 23)
/*    */   private Long codResgistroLteTrllr;
/*    */   @LongPositionalField(initialPosition = 24, finalPosition = 41)
/*    */   private Long dscSomaVlrTrllr;
/*    */   @LongPositionalField(initialPosition = 42, finalPosition = 59)
/*    */   private Long dscSomaQtdMoedaTrllr;
/*    */   @LongPositionalField(initialPosition = 60, finalPosition = 65)
/*    */   private Long dscNumAvisoDebTrllr;
/*    */   @PositionalField(initialPosition = 66, finalPosition = 230)
/*    */   private String dscReservado1Trllr;
/*    */   @PositionalField(initialPosition = 231, finalPosition = 240)
/*    */   private String dscOcorrenciasTrllr;
/*    */   
/*    */   public Long getCodBancoTrllr() {
/* 40 */     return this.codBancoTrllr;
/*    */   }
/*    */   public void setCodBancoTrllr(Long codBancoTrllr) {
/* 43 */     this.codBancoTrllr = codBancoTrllr;
/*    */   }
/*    */   public Long getCodLoteTrllr() {
/* 46 */     return this.codLoteTrllr;
/*    */   }
/*    */   public void setCodLoteTrllr(Long codLoteTrllr) {
/* 49 */     this.codLoteTrllr = codLoteTrllr;
/*    */   }
/*    */   public Long getCodTpoServTrllr() {
/* 52 */     return this.codTpoServTrllr;
/*    */   }
/*    */   public void setCodTpoServTrllr(Long codTpoServTrllr) {
/* 55 */     this.codTpoServTrllr = codTpoServTrllr;
/*    */   }
/*    */   public String getDscReservadoTrllr() {
/* 58 */     return this.dscReservadoTrllr;
/*    */   }
/*    */   public void setDscReservadoTrllr(String dscReservadoTrllr) {
/* 61 */     this.dscReservadoTrllr = dscReservadoTrllr;
/*    */   }
/*    */   public Long getCodResgistroLteTrllr() {
/* 64 */     return this.codResgistroLteTrllr;
/*    */   }
/*    */   public void setCodResgistroLteTrllr(Long codResgistroLteTrllr) {
/* 67 */     this.codResgistroLteTrllr = codResgistroLteTrllr;
/*    */   }
/*    */   public Long getDscSomaVlrTrllr() {
/* 70 */     return this.dscSomaVlrTrllr;
/*    */   }
/*    */   public void setDscSomaVlrTrllr(Long dscSomaVlrTrllr) {
/* 73 */     this.dscSomaVlrTrllr = dscSomaVlrTrllr;
/*    */   }
/*    */   public Long getDscSomaQtdMoedaTrllr() {
/* 76 */     return this.dscSomaQtdMoedaTrllr;
/*    */   }
/*    */   public void setDscSomaQtdMoedaTrllr(Long dscSomaQtdMoedaTrllr) {
/* 79 */     this.dscSomaQtdMoedaTrllr = dscSomaQtdMoedaTrllr;
/*    */   }
/*    */   public Long getDscNumAvisoDebTrllr() {
/* 82 */     return this.dscNumAvisoDebTrllr;
/*    */   }
/*    */   public void setDscNumAvisoDebTrllr(Long dscNumAvisoDebTrllr) {
/* 85 */     this.dscNumAvisoDebTrllr = dscNumAvisoDebTrllr;
/*    */   }
/*    */   public String getDscReservado1Trllr() {
/* 88 */     return this.dscReservado1Trllr;
/*    */   }
/*    */   public void setDscReservado1Trllr(String dscReservado1Trllr) {
/* 91 */     this.dscReservado1Trllr = dscReservado1Trllr;
/*    */   }
/*    */   public String getDscOcorrenciasTrllr() {
/* 94 */     return this.dscOcorrenciasTrllr;
/*    */   }
/*    */   public void setDscOcorrenciasTrllr(String dscOcorrenciasTrllr) {
/* 97 */     this.dscOcorrenciasTrllr = dscOcorrenciasTrllr;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\TraillerL043.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */