/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz;
/*    */ 
/*    */ public class ConfigVO
/*    */ {
/*    */   private String tpo_arquivo;
/*    */   private String dsc_fluxo;
/*    */   private String dsc_sentido;
/*    */   private String dsc_path_input;
/*    */   private String dsc_path_error;
/*    */   private String dsc_path_processed;
/*    */   private String dsc_path_temp;
/*    */   private String dsc_intercambio;
/*    */   private String sta_ativo;
/*    */   
/*    */   public String getTpo_arquivo() {
/* 16 */     return this.tpo_arquivo;
/*    */   }
/*    */   public void setTpo_arquivo(String tpo_arquivo) {
/* 19 */     this.tpo_arquivo = tpo_arquivo;
/*    */   }
/*    */   public String getDsc_fluxo() {
/* 22 */     return this.dsc_fluxo;
/*    */   }
/*    */   public void setDsc_fluxo(String dsc_fluxo) {
/* 25 */     this.dsc_fluxo = dsc_fluxo;
/*    */   }
/*    */   public String getDsc_sentido() {
/* 28 */     return this.dsc_sentido;
/*    */   }
/*    */   public void setDsc_sentido(String dsc_sentido) {
/* 31 */     this.dsc_sentido = dsc_sentido;
/*    */   }
/*    */   public String getDsc_path_input() {
/* 34 */     return this.dsc_path_input;
/*    */   }
/*    */   public void setDsc_path_input(String dsc_path_input) {
/* 37 */     this.dsc_path_input = dsc_path_input;
/*    */   }
/*    */   public String getDsc_path_error() {
/* 40 */     return this.dsc_path_error;
/*    */   }
/*    */   public void setDsc_path_error(String dsc_path_error) {
/* 43 */     this.dsc_path_error = dsc_path_error;
/*    */   }
/*    */   public String getDsc_path_processed() {
/* 46 */     return this.dsc_path_processed;
/*    */   }
/*    */   public void setDsc_path_processed(String dsc_path_processed) {
/* 49 */     this.dsc_path_processed = dsc_path_processed;
/*    */   }
/*    */   public String getDsc_path_temp() {
/* 52 */     return this.dsc_path_temp;
/*    */   }
/*    */   public void setDsc_path_temp(String dsc_path_temp) {
/* 55 */     this.dsc_path_temp = dsc_path_temp;
/*    */   }
/*    */   public String getDsc_intercambio() {
/* 58 */     return this.dsc_intercambio;
/*    */   }
/*    */   public void setDsc_intercambio(String dsc_intercambio) {
/* 61 */     this.dsc_intercambio = dsc_intercambio;
/*    */   }
/*    */   public String getSta_ativo() {
/* 64 */     return this.sta_ativo;
/*    */   }
/*    */   public void setSta_ativo(String sta_ativo) {
/* 67 */     this.sta_ativo = sta_ativo;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\ConfigVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */