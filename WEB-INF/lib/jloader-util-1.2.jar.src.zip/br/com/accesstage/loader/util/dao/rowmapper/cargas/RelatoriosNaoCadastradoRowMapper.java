/*    */ package br.com.accesstage.loader.util.dao.rowmapper.cargas;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.allianz.relatorio.RelatorioNaoCadastrado;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class RelatoriosNaoCadastradoRowMapper
/*    */   implements RowMapper<RelatorioNaoCadastrado>
/*    */ {
/* 15 */   private SimpleDateFormat sfd = new SimpleDateFormat("yyyyMMdd");
/*    */   
/*    */   public RelatorioNaoCadastrado mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 18 */     RelatorioNaoCadastrado relatorioNaoCadastrado = new RelatorioNaoCadastrado();
/* 19 */     relatorioNaoCadastrado.setAgenciaDebito(rs.getString("NRO_AGENCIA_DEBITO"));
/* 20 */     relatorioNaoCadastrado.setBanco("");
/* 21 */     relatorioNaoCadastrado.setCodigoRetorno(rs.getString("COD_RETORNO"));
/* 22 */     String dataVencimento = rs.getString("DTA_VENCIMENTO");
/*    */     try {
/* 24 */       relatorioNaoCadastrado.setDataVencimentoDebito(this.sfd.parse(dataVencimento));
/* 25 */     } catch (ParseException e) {
/*    */       
/* 27 */       e.printStackTrace();
/*    */     } 
/* 29 */     relatorioNaoCadastrado.setBanco(rs.getString("BANCO"));
/* 30 */     relatorioNaoCadastrado.setIdentificacaoClienteBanco(rs.getString("IDT_CLIENTE_BANCO"));
/* 31 */     relatorioNaoCadastrado.setIdentificacaoClienteEmpresa(rs.getString("IDT_CLIENTE_EMPRESA"));
/* 32 */     relatorioNaoCadastrado.setUsoEmpresa(rs.getString("USO_EMPRESA"));
/* 33 */     relatorioNaoCadastrado.setStatus("Não cadastrada");
/* 34 */     String valor = rs.getString("VLR_DEBITO");
/* 35 */     if (StringUtils.isNotEmpty(valor)) {
/* 36 */       double valorInt = Integer.valueOf(valor).intValue();
/* 37 */       double valorAjustado = valorInt / 100.0D;
/* 38 */       relatorioNaoCadastrado.setValorOriginalDebitado(Double.valueOf(valorAjustado));
/*    */     } 
/* 40 */     relatorioNaoCadastrado.setNroUnico(rs.getInt("NRO_UNICO"));
/*    */     
/* 42 */     return relatorioNaoCadastrado;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\cargas\RelatoriosNaoCadastradoRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */