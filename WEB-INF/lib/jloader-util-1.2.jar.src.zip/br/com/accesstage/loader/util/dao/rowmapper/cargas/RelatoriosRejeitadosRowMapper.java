/*    */ package br.com.accesstage.loader.util.dao.rowmapper.cargas;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.allianz.relatorio.RelatorioRejeitado;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class RelatoriosRejeitadosRowMapper
/*    */   implements RowMapper<RelatorioRejeitado>
/*    */ {
/* 15 */   private SimpleDateFormat sfd = new SimpleDateFormat("yyyyMMdd");
/*    */   
/*    */   public RelatorioRejeitado mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 18 */     RelatorioRejeitado rejeitado = new RelatorioRejeitado();
/*    */     
/* 20 */     rejeitado.setAgenciaDebito(rs.getString("NRO_AGENCIA_DEBITO"));
/* 21 */     rejeitado.setBanco(rs.getString("BANCO"));
/* 22 */     rejeitado.setCodigoRetorno(rs.getString("COD_RETORNO"));
/* 23 */     String dataVencimento = rs.getString("DTA_VENCIMENTO");
/* 24 */     rejeitado.setIdentificacaoClienteBanco(rs.getString("IDT_CLIENTE_BANCO"));
/*    */     try {
/* 26 */       rejeitado.setDataVencimentoDebito(this.sfd.parse(dataVencimento));
/* 27 */     } catch (ParseException e) {
/*    */       
/* 29 */       e.printStackTrace();
/*    */     } 
/* 31 */     rejeitado.setIdentificacaoClienteEmpresa(rs.getString("IDT_CLIENTE_EMPRESA"));
/* 32 */     rejeitado.setUsoEmpresa(rs.getString("USO_EMPRESA"));
/* 33 */     String valor = rs.getString("VLR_DEBITO");
/* 34 */     if (StringUtils.isNotEmpty(valor)) {
/* 35 */       double valorInt = Integer.valueOf(valor).intValue();
/* 36 */       double valorAjustado = valorInt / 100.0D;
/* 37 */       rejeitado.setValorOriginalDebitado(Double.valueOf(valorAjustado));
/*    */     } 
/* 39 */     rejeitado.setNroUnico(rs.getInt("NRO_UNICO"));
/* 40 */     return rejeitado;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\cargas\RelatoriosRejeitadosRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */