/*    */ package br.com.accesstage.loader.util.commom.ffpojo;
/*    */ 
/*    */ public abstract class BaseRecordParser
/*    */   implements RecordParser {
/*    */   protected RecordDescriptor recordDescriptor;
/*    */   
/*    */   protected BaseRecordParser(RecordDescriptor recordDescriptor) {
/*  8 */     this.recordDescriptor = recordDescriptor;
/*    */   }
/*    */   
/*    */   protected RecordDescriptor getRecordDescriptor() {
/* 12 */     return this.recordDescriptor;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\commom\ffpojo\BaseRecordParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */