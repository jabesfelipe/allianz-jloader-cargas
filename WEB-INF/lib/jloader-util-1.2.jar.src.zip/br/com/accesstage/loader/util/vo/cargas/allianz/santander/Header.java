/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.santander;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.PaddingAlign;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Header
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -6982184526372058126L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  21 */   private String codBcoHdrArq = "033";
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  23 */   private String lteServicoHdrArq = "0000";
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  25 */   private String tpoRegHdrArq = "0";
/*     */   
/*     */   @PositionalField(initialPosition = 9, finalPosition = 16, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 17, finalPosition = 17)
/*  30 */   private Integer tpoIncsEmp = Integer.valueOf(2); @PositionalField(initialPosition = 18, finalPosition = 32, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  31 */   private String nrInscricaoEmpresa = "061573796000166";
/*     */   @PositionalField(initialPosition = 33, finalPosition = 47, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  33 */   private String codigoTransmissao = "227100007932235";
/*     */   @PositionalField(initialPosition = 48, finalPosition = 72)
/*     */   private String dscUsoFbrn2;
/*     */   @PositionalField(initialPosition = 73, finalPosition = 102)
/*  37 */   private String nomeEmpresa = "ALLIANZ SEGUROS S.A.";
/*     */   @PositionalField(initialPosition = 103, finalPosition = 132)
/*  39 */   private String nomeBanco = "BANCO SANTANDER SA";
/*     */   @PositionalField(initialPosition = 133, finalPosition = 142, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn3;
/*     */   @PositionalField(initialPosition = 143, finalPosition = 143, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*  43 */   private String codigoRemessa = "1";
/*     */   @PositionalField(initialPosition = 144, finalPosition = 151)
/*     */   private String dataArquivo;
/*     */   @PositionalField(initialPosition = 152, finalPosition = 157, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn4;
/*     */   @PositionalField(initialPosition = 158, finalPosition = 163, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String nroSequencial;
/*     */   @PositionalField(initialPosition = 164, finalPosition = 166, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  51 */   private String nroVersaoLayout = "040";
/*     */   
/*     */   @PositionalField(initialPosition = 167, finalPosition = 240, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn5;
/*     */   
/*     */   public String getCodBcoHdrArq() {
/*  57 */     return this.codBcoHdrArq;
/*     */   }
/*     */   public void setCodBcoHdrArq(String codBcoHdrArq) {
/*  60 */     this.codBcoHdrArq = codBcoHdrArq;
/*     */   }
/*     */   public String getLteServicoHdrArq() {
/*  63 */     return this.lteServicoHdrArq;
/*     */   }
/*     */   public void setLteServicoHdrArq(String lteServicoHdrArq) {
/*  66 */     this.lteServicoHdrArq = lteServicoHdrArq;
/*     */   }
/*     */   public String getTpoRegHdrArq() {
/*  69 */     return this.tpoRegHdrArq;
/*     */   }
/*     */   public void setTpoRegHdrArq(String tpoRegHdrArq) {
/*  72 */     this.tpoRegHdrArq = tpoRegHdrArq;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  75 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  78 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getTpoIncsEmp() {
/*  81 */     return this.tpoIncsEmp;
/*     */   }
/*     */   public void setTpoIncsEmp(Integer tpoIncsEmp) {
/*  84 */     this.tpoIncsEmp = tpoIncsEmp;
/*     */   }
/*     */   public String getNrInscricaoEmpresa() {
/*  87 */     return this.nrInscricaoEmpresa;
/*     */   }
/*     */   public void setNrInscricaoEmpresa(String nrInscricaoEmpresa) {
/*  90 */     this.nrInscricaoEmpresa = nrInscricaoEmpresa;
/*     */   }
/*     */   public String getCodigoTransmissao() {
/*  93 */     return this.codigoTransmissao;
/*     */   }
/*     */   public void setCodigoTransmissao(String codigoTransmissao) {
/*  96 */     this.codigoTransmissao = codigoTransmissao;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/*  99 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 102 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public String getNomeEmpresa() {
/* 105 */     return this.nomeEmpresa;
/*     */   }
/*     */   public void setNomeEmpresa(String nomeEmpresa) {
/* 108 */     this.nomeEmpresa = nomeEmpresa;
/*     */   }
/*     */   public String getNomeBanco() {
/* 111 */     return this.nomeBanco;
/*     */   }
/*     */   public void setNomeBanco(String nomeBanco) {
/* 114 */     this.nomeBanco = nomeBanco;
/*     */   }
/*     */   public String getDscUsoFbrn3() {
/* 117 */     return this.dscUsoFbrn3;
/*     */   }
/*     */   public void setDscUsoFbrn3(String dscUsoFbrn3) {
/* 120 */     this.dscUsoFbrn3 = dscUsoFbrn3;
/*     */   }
/*     */   public String getCodigoRemessa() {
/* 123 */     return this.codigoRemessa;
/*     */   }
/*     */   public void setCodigoRemessa(String codigoRemessa) {
/* 126 */     this.codigoRemessa = codigoRemessa;
/*     */   }
/*     */   public String getDataArquivo() {
/* 129 */     return this.dataArquivo;
/*     */   }
/*     */   public void setDataArquivo(String dataArquivo) {
/* 132 */     this.dataArquivo = dataArquivo;
/*     */   }
/*     */   public String getDscUsoFbrn4() {
/* 135 */     return this.dscUsoFbrn4;
/*     */   }
/*     */   public void setDscUsoFbrn4(String dscUsoFbrn4) {
/* 138 */     this.dscUsoFbrn4 = dscUsoFbrn4;
/*     */   }
/*     */   public String getNroSequencial() {
/* 141 */     return this.nroSequencial;
/*     */   }
/*     */   public void setNroSequencial(String nroSequencial) {
/* 144 */     this.nroSequencial = nroSequencial;
/*     */   }
/*     */   public String getNroVersaoLayout() {
/* 147 */     return this.nroVersaoLayout;
/*     */   }
/*     */   public void setNroVersaoLayout(String nroVersaoLayout) {
/* 150 */     this.nroVersaoLayout = nroVersaoLayout;
/*     */   }
/*     */   public String getDscUsoFbrn5() {
/* 153 */     return this.dscUsoFbrn5;
/*     */   }
/*     */   public void setDscUsoFbrn5(String dscUsoFbrn5) {
/* 156 */     this.dscUsoFbrn5 = dscUsoFbrn5;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\santander\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */