/*    */ package br.com.accesstage.loader.util.dao.rowmapper.processo;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.processo.MensagemRetornoVO;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class MensagemRetornoRowMapper
/*    */   implements RowMapper<MensagemRetornoVO>
/*    */ {
/*    */   public MensagemRetornoVO mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 13 */     MensagemRetornoVO mensagem = new MensagemRetornoVO();
/* 14 */     mensagem.setCodOcorrencia(rs.getString("COD_OCORRENCIA"));
/* 15 */     mensagem.setDscOcorrencia(rs.getString("DSC_OCORRENCIA"));
/* 16 */     return mensagem;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\processo\MensagemRetornoRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */