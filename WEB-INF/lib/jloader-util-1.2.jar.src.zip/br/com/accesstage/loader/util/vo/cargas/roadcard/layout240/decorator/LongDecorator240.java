/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator;
/*    */ 
/*    */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*    */ 
/*    */ public class LongDecorator240
/*    */   extends DefaultFieldDecorator
/*    */ {
/*    */   public Object fromString(String str) {
/*  9 */     if (!"".equals(str.trim()) && !str.trim().isEmpty()) {
/* 10 */       return Long.valueOf(Long.parseLong(str));
/*    */     }
/* 12 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isNullOrWhitespace(CharSequence value) {
/* 16 */     if (value == null) {
/* 17 */       return true;
/*    */     }
/* 19 */     for (int i = 0; i < value.length(); i++) {
/* 20 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 21 */         return false;
/*    */       }
/*    */     } 
/* 24 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\decorator\LongDecorator240.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */