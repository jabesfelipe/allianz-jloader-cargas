/*    */ package br.com.accesstage.loader.util.vo;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class Config {
/*    */   private Long id;
/*    */   private String nomeConfig;
/*    */   private String valorConfig;
/*    */   private String layout;
/*    */   private Date created;
/*    */   
/*    */   public Long getId() {
/* 13 */     return this.id;
/*    */   }
/*    */   public void setId(Long id) {
/* 16 */     this.id = id;
/*    */   }
/*    */   public String getNomeConfig() {
/* 19 */     return this.nomeConfig;
/*    */   }
/*    */   public void setNomeConfig(String nomeConfig) {
/* 22 */     this.nomeConfig = nomeConfig;
/*    */   }
/*    */   public String getValorConfig() {
/* 25 */     return this.valorConfig;
/*    */   }
/*    */   public void setValorConfig(String valorConfig) {
/* 28 */     this.valorConfig = valorConfig;
/*    */   }
/*    */   public String getLayout() {
/* 31 */     return this.layout;
/*    */   }
/*    */   public void setLayout(String layout) {
/* 34 */     this.layout = layout;
/*    */   }
/*    */   public Date getCreated() {
/* 37 */     return this.created;
/*    */   }
/*    */   public void setCreated(Date created) {
/* 40 */     this.created = created;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\Config.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */