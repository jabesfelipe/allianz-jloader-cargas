/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoJ
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private String lteServico;
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private String tpoReg;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private String nroSeq;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegReg;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String tipoMovimento;
/*     */   @PositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private String codInstMovimento;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 61)
/*     */   private String codidoBarras;
/*     */   @PositionalField(initialPosition = 62, finalPosition = 91)
/*     */   private String nomeCedente;
/*     */   @PositionalField(initialPosition = 92, finalPosition = 99)
/*     */   private String dataVencNominal;
/*     */   @PositionalField(initialPosition = 100, finalPosition = 114)
/*     */   private String valorTituloNominal;
/*     */   @PositionalField(initialPosition = 115, finalPosition = 129)
/*     */   private String valorDesconto;
/*     */   @PositionalField(initialPosition = 130, finalPosition = 144)
/*     */   private String valorMoraMulta;
/*     */   @PositionalField(initialPosition = 145, finalPosition = 152)
/*     */   private String dtaPagto;
/*     */   @PositionalField(initialPosition = 153, finalPosition = 167)
/*     */   private String valorPagamento;
/*     */   @PositionalField(initialPosition = 168, finalPosition = 182)
/*     */   private String quantidadeMoeda;
/*     */   @PositionalField(initialPosition = 183, finalPosition = 202)
/*     */   private String seuNumero;
/*     */   @PositionalField(initialPosition = 203, finalPosition = 222)
/*     */   private String numDocBanco;
/*     */   @PositionalField(initialPosition = 223, finalPosition = 224)
/*     */   private String codMoeda;
/*     */   @PositionalField(initialPosition = 225, finalPosition = 230)
/*     */   private String filler1;
/*     */   @PositionalField(initialPosition = 231, finalPosition = 240)
/*     */   private String codOcorrencia;
/*     */   
/*     */   public String getCodBco() {
/*  61 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  64 */     this.codBco = codBco;
/*     */   }
/*     */   public String getLteServico() {
/*  67 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(String lteServico) {
/*  70 */     this.lteServico = lteServico;
/*     */   }
/*     */   public String getTpoReg() {
/*  73 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(String tpoReg) {
/*  76 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public String getNroSeq() {
/*  79 */     return this.nroSeq;
/*     */   }
/*     */   public void setNroSeq(String nroSeq) {
/*  82 */     this.nroSeq = nroSeq;
/*     */   }
/*     */   public String getCodSegReg() {
/*  85 */     return this.codSegReg;
/*     */   }
/*     */   public void setCodSegReg(String codSegReg) {
/*  88 */     this.codSegReg = codSegReg;
/*     */   }
/*     */   public String getTipoMovimento() {
/*  91 */     return this.tipoMovimento;
/*     */   }
/*     */   public void setTipoMovimento(String tipoMovimento) {
/*  94 */     this.tipoMovimento = tipoMovimento;
/*     */   }
/*     */   public String getCodInstMovimento() {
/*  97 */     return this.codInstMovimento;
/*     */   }
/*     */   public void setCodInstMovimento(String codInstMovimento) {
/* 100 */     this.codInstMovimento = codInstMovimento;
/*     */   }
/*     */   public String getCodidoBarras() {
/* 103 */     return this.codidoBarras;
/*     */   }
/*     */   public void setCodidoBarras(String codidoBarras) {
/* 106 */     this.codidoBarras = codidoBarras;
/*     */   }
/*     */   public String getNomeCedente() {
/* 109 */     return this.nomeCedente;
/*     */   }
/*     */   public void setNomeCedente(String nomeCedente) {
/* 112 */     this.nomeCedente = nomeCedente;
/*     */   }
/*     */   public String getDataVencNominal() {
/* 115 */     return this.dataVencNominal;
/*     */   }
/*     */   public void setDataVencNominal(String dataVencNominal) {
/* 118 */     this.dataVencNominal = dataVencNominal;
/*     */   }
/*     */   public String getValorTituloNominal() {
/* 121 */     return this.valorTituloNominal;
/*     */   }
/*     */   public void setValorTituloNominal(String valorTituloNominal) {
/* 124 */     this.valorTituloNominal = valorTituloNominal;
/*     */   }
/*     */   public String getValorDesconto() {
/* 127 */     return this.valorDesconto;
/*     */   }
/*     */   public void setValorDesconto(String valorDesconto) {
/* 130 */     this.valorDesconto = valorDesconto;
/*     */   }
/*     */   public String getValorMoraMulta() {
/* 133 */     return this.valorMoraMulta;
/*     */   }
/*     */   public void setValorMoraMulta(String valorMoraMulta) {
/* 136 */     this.valorMoraMulta = valorMoraMulta;
/*     */   }
/*     */   public String getDtaPagto() {
/* 139 */     return this.dtaPagto;
/*     */   }
/*     */   public void setDtaPagto(String dtaPagto) {
/* 142 */     this.dtaPagto = dtaPagto;
/*     */   }
/*     */   public String getValorPagamento() {
/* 145 */     return this.valorPagamento;
/*     */   }
/*     */   public void setValorPagamento(String valorPagamento) {
/* 148 */     this.valorPagamento = valorPagamento;
/*     */   }
/*     */   public String getQuantidadeMoeda() {
/* 151 */     return this.quantidadeMoeda;
/*     */   }
/*     */   public void setQuantidadeMoeda(String quantidadeMoeda) {
/* 154 */     this.quantidadeMoeda = quantidadeMoeda;
/*     */   }
/*     */   public String getSeuNumero() {
/* 157 */     return this.seuNumero;
/*     */   }
/*     */   public void setSeuNumero(String seuNumero) {
/* 160 */     this.seuNumero = seuNumero;
/*     */   }
/*     */   public String getNumDocBanco() {
/* 163 */     return this.numDocBanco;
/*     */   }
/*     */   public void setNumDocBanco(String numDocBanco) {
/* 166 */     this.numDocBanco = numDocBanco;
/*     */   }
/*     */   public String getCodMoeda() {
/* 169 */     return this.codMoeda;
/*     */   }
/*     */   public void setCodMoeda(String codMoeda) {
/* 172 */     this.codMoeda = codMoeda;
/*     */   }
/*     */   public String getFiller1() {
/* 175 */     return this.filler1;
/*     */   }
/*     */   public void setFiller1(String filler1) {
/* 178 */     this.filler1 = filler1;
/*     */   }
/*     */   public String getCodOcorrencia() {
/* 181 */     return this.codOcorrencia;
/*     */   }
/*     */   public void setCodOcorrencia(String codOcorrencia) {
/* 184 */     this.codOcorrencia = codOcorrencia;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\SegmentoJ.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */