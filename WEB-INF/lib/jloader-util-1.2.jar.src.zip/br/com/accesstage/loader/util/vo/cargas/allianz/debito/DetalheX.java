/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "X")})
/*     */ public class DetalheX
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private String codRegistro;
/*     */   @PositionalField(initialPosition = 2, finalPosition = 5)
/*     */   private String codAgencia;
/*     */   @PositionalField(initialPosition = 6, finalPosition = 35)
/*     */   private String nomeAgencia;
/*     */   @PositionalField(initialPosition = 36, finalPosition = 65)
/*     */   private String enderecoAgencia;
/*     */   @PositionalField(initialPosition = 66, finalPosition = 70)
/*     */   private String numeroAgencia;
/*     */   @PositionalField(initialPosition = 71, finalPosition = 75)
/*     */   private String codigoCep;
/*     */   @PositionalField(initialPosition = 76, finalPosition = 78)
/*     */   private String sufixoCep;
/*     */   @PositionalField(initialPosition = 79, finalPosition = 98)
/*     */   private String nomeCidade;
/*     */   @PositionalField(initialPosition = 99, finalPosition = 100)
/*     */   private String siglaEstado;
/*     */   @PositionalField(initialPosition = 101, finalPosition = 101)
/*     */   private String situacaoAgencia;
/*     */   @PositionalField(initialPosition = 102, finalPosition = 150)
/*  37 */   private String usoFuturo = null;
/*     */ 
/*     */   
/*     */   public String getCodRegistro() {
/*  41 */     return this.codRegistro;
/*     */   }
/*     */   public void setCodRegistro(String codRegistro) {
/*  44 */     this.codRegistro = codRegistro;
/*     */   }
/*     */   public String getCodAgencia() {
/*  47 */     return this.codAgencia;
/*     */   }
/*     */   public void setCodAgencia(String codAgencia) {
/*  50 */     this.codAgencia = codAgencia;
/*     */   }
/*     */   public String getNomeAgencia() {
/*  53 */     return this.nomeAgencia;
/*     */   }
/*     */   public void setNomeAgencia(String nomeAgencia) {
/*  56 */     this.nomeAgencia = nomeAgencia;
/*     */   }
/*     */   public String getEnderecoAgencia() {
/*  59 */     return this.enderecoAgencia;
/*     */   }
/*     */   public void setEnderecoAgencia(String enderecoAgencia) {
/*  62 */     this.enderecoAgencia = enderecoAgencia;
/*     */   }
/*     */   public String getNumeroAgencia() {
/*  65 */     return this.numeroAgencia;
/*     */   }
/*     */   public void setNumeroAgencia(String numeroAgencia) {
/*  68 */     this.numeroAgencia = numeroAgencia;
/*     */   }
/*     */   public String getCodigoCep() {
/*  71 */     return this.codigoCep;
/*     */   }
/*     */   public void setCodigoCep(String codigoCep) {
/*  74 */     this.codigoCep = codigoCep;
/*     */   }
/*     */   public String getSufixoCep() {
/*  77 */     return this.sufixoCep;
/*     */   }
/*     */   public void setSufixoCep(String sufixoCep) {
/*  80 */     this.sufixoCep = sufixoCep;
/*     */   }
/*     */   public String getNomeCidade() {
/*  83 */     return this.nomeCidade;
/*     */   }
/*     */   public void setNomeCidade(String nomeCidade) {
/*  86 */     this.nomeCidade = nomeCidade;
/*     */   }
/*     */   public String getSiglaEstado() {
/*  89 */     return this.siglaEstado;
/*     */   }
/*     */   public void setSiglaEstado(String siglaEstado) {
/*  92 */     this.siglaEstado = siglaEstado;
/*     */   }
/*     */   public String getSituacaoAgencia() {
/*  95 */     return this.situacaoAgencia;
/*     */   }
/*     */   public void setSituacaoAgencia(String situacaoAgencia) {
/*  98 */     this.situacaoAgencia = situacaoAgencia;
/*     */   }
/*     */   public String getUsoFuturo() {
/* 101 */     return this.usoFuturo;
/*     */   }
/*     */   public void setUsoFuturo(String usoFuturo) {
/* 104 */     this.usoFuturo = usoFuturo;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\DetalheX.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */