/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.santander;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.PaddingAlign;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class HeaderLote
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*  17 */   private String codBcoHdrArq = "033";
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*  19 */   private String lteServicoHdrArq = "0001";
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*  21 */   private String tpoRegHdrArq = "1";
/*     */   @PositionalField(initialPosition = 9, finalPosition = 9)
/*  23 */   private String tipoOperacao = "R";
/*     */   @PositionalField(initialPosition = 10, finalPosition = 11, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  25 */   private String tipoServico = "01";
/*     */   @PositionalField(initialPosition = 12, finalPosition = 13)
/*     */   private String dscUsoFbrn1;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 16, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  29 */   private String nroVersaoLayout = "030";
/*     */   @PositionalField(initialPosition = 17, finalPosition = 17, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn2;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 18, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*  33 */   private String tpoIncsEmp = "2";
/*     */   @PositionalField(initialPosition = 19, finalPosition = 33, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  35 */   private String nrInscricaoEmpresa = "061573796000166";
/*     */   @PositionalField(initialPosition = 34, finalPosition = 53, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn3;
/*     */   @PositionalField(initialPosition = 54, finalPosition = 68, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  39 */   private String codigoTransmissao = "227100007932235";
/*     */   @PositionalField(initialPosition = 69, finalPosition = 73, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn4;
/*     */   @PositionalField(initialPosition = 74, finalPosition = 103, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*  43 */   private String nomeCedente = "ALLIANZ SEGUROS S.A.";
/*     */   
/*     */   @PositionalField(initialPosition = 104, finalPosition = 143, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn5;
/*     */   @PositionalField(initialPosition = 144, finalPosition = 183, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn6;
/*     */   @PositionalField(initialPosition = 184, finalPosition = 191, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String nroRemessaRetorno;
/*     */   @PositionalField(initialPosition = 192, finalPosition = 199)
/*     */   private String dataRemessaRetorno;
/*     */   @PositionalField(initialPosition = 200, finalPosition = 240, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn7;
/*     */   
/*     */   public String getCodBcoHdrArq() {
/*  57 */     return this.codBcoHdrArq;
/*     */   }
/*     */   public void setCodBcoHdrArq(String codBcoHdrArq) {
/*  60 */     this.codBcoHdrArq = codBcoHdrArq;
/*     */   }
/*     */   public String getLteServicoHdrArq() {
/*  63 */     return this.lteServicoHdrArq;
/*     */   }
/*     */   public void setLteServicoHdrArq(String lteServicoHdrArq) {
/*  66 */     this.lteServicoHdrArq = lteServicoHdrArq;
/*     */   }
/*     */   public String getTpoRegHdrArq() {
/*  69 */     return this.tpoRegHdrArq;
/*     */   }
/*     */   public void setTpoRegHdrArq(String tpoRegHdrArq) {
/*  72 */     this.tpoRegHdrArq = tpoRegHdrArq;
/*     */   }
/*     */   public String getTipoOperacao() {
/*  75 */     return this.tipoOperacao;
/*     */   }
/*     */   public void setTipoOperacao(String tipoOperacao) {
/*  78 */     this.tipoOperacao = tipoOperacao;
/*     */   }
/*     */   public String getTipoServico() {
/*  81 */     return this.tipoServico;
/*     */   }
/*     */   public void setTipoServico(String tipoServico) {
/*  84 */     this.tipoServico = tipoServico;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  87 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  90 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public String getNroVersaoLayout() {
/*  93 */     return this.nroVersaoLayout;
/*     */   }
/*     */   public void setNroVersaoLayout(String nroVersaoLayout) {
/*  96 */     this.nroVersaoLayout = nroVersaoLayout;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/*  99 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 102 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public String getTpoIncsEmp() {
/* 105 */     return this.tpoIncsEmp;
/*     */   }
/*     */   public void setTpoIncsEmp(String tpoIncsEmp) {
/* 108 */     this.tpoIncsEmp = tpoIncsEmp;
/*     */   }
/*     */   public String getNrInscricaoEmpresa() {
/* 111 */     return this.nrInscricaoEmpresa;
/*     */   }
/*     */   public void setNrInscricaoEmpresa(String nrInscricaoEmpresa) {
/* 114 */     this.nrInscricaoEmpresa = nrInscricaoEmpresa;
/*     */   }
/*     */   public String getDscUsoFbrn3() {
/* 117 */     return this.dscUsoFbrn3;
/*     */   }
/*     */   public void setDscUsoFbrn3(String dscUsoFbrn3) {
/* 120 */     this.dscUsoFbrn3 = dscUsoFbrn3;
/*     */   }
/*     */   public String getCodigoTransmissao() {
/* 123 */     return this.codigoTransmissao;
/*     */   }
/*     */   public void setCodigoTransmissao(String codigoTransmissao) {
/* 126 */     this.codigoTransmissao = codigoTransmissao;
/*     */   }
/*     */   public String getDscUsoFbrn4() {
/* 129 */     return this.dscUsoFbrn4;
/*     */   }
/*     */   public void setDscUsoFbrn4(String dscUsoFbrn4) {
/* 132 */     this.dscUsoFbrn4 = dscUsoFbrn4;
/*     */   }
/*     */   public String getNomeCedente() {
/* 135 */     return this.nomeCedente;
/*     */   }
/*     */   public void setNomeCedente(String nomeCedente) {
/* 138 */     this.nomeCedente = nomeCedente;
/*     */   }
/*     */   public String getDscUsoFbrn5() {
/* 141 */     return this.dscUsoFbrn5;
/*     */   }
/*     */   public void setDscUsoFbrn5(String dscUsoFbrn5) {
/* 144 */     this.dscUsoFbrn5 = dscUsoFbrn5;
/*     */   }
/*     */   public String getDscUsoFbrn6() {
/* 147 */     return this.dscUsoFbrn6;
/*     */   }
/*     */   public void setDscUsoFbrn6(String dscUsoFbrn6) {
/* 150 */     this.dscUsoFbrn6 = dscUsoFbrn6;
/*     */   }
/*     */   public String getNroRemessaRetorno() {
/* 153 */     return this.nroRemessaRetorno;
/*     */   }
/*     */   public void setNroRemessaRetorno(String nroRemessaRetorno) {
/* 156 */     this.nroRemessaRetorno = nroRemessaRetorno;
/*     */   }
/*     */   public String getDataRemessaRetorno() {
/* 159 */     return this.dataRemessaRetorno;
/*     */   }
/*     */   public void setDataRemessaRetorno(String dataRemessaRetorno) {
/* 162 */     this.dataRemessaRetorno = dataRemessaRetorno;
/*     */   }
/*     */   public String getDscUsoFbrn7() {
/* 165 */     return this.dscUsoFbrn7;
/*     */   }
/*     */   public void setDscUsoFbrn7(String dscUsoFbrn7) {
/* 168 */     this.dscUsoFbrn7 = dscUsoFbrn7;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\santander\HeaderLote.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */