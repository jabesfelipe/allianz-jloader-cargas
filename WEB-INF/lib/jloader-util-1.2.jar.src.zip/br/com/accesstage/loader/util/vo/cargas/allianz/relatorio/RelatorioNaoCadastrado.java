/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.relatorio;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelatorioNaoCadastrado
/*    */   extends RelatorioRejeitado
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String status;
/*    */   
/*    */   public String getStatus() {
/* 13 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(String status) {
/* 17 */     this.status = status;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\relatorio\RelatorioNaoCadastrado.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */