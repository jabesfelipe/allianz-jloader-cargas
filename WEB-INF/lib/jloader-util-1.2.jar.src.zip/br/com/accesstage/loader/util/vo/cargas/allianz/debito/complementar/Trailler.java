/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito.complementar;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "9")})
/*    */ public class Trailler
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = -7550081582425751679L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 10)
/*    */   private String quantLinhas;
/*    */   @PositionalField(initialPosition = 11, finalPosition = 750)
/*    */   private String filler;
/*    */   
/*    */   public String getCodRegistro() {
/* 25 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 28 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getQuantLinhas() {
/* 31 */     return this.quantLinhas;
/*    */   }
/*    */   public void setQuantLinhas(String quantLinhas) {
/* 34 */     this.quantLinhas = quantLinhas;
/*    */   }
/*    */   public String getFiller() {
/* 37 */     return this.filler;
/*    */   }
/*    */   public void setFiller(String filler) {
/* 40 */     this.filler = filler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\complementar\Trailler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */