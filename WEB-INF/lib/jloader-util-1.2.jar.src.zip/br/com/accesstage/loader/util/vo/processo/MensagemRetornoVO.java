/*    */ package br.com.accesstage.loader.util.vo.processo;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ public class MensagemRetornoVO
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -562187200026765506L;
/*    */   private Long codTransacaoConfirm;
/*    */   private String codOcorrencia;
/*    */   private String dscOcorrencia;
/*    */   
/*    */   public MensagemRetornoVO(Long codTransacaoConfirm, String codOcorrencia, String dscOcorrencia) {
/* 15 */     this.codTransacaoConfirm = codTransacaoConfirm;
/* 16 */     this.codOcorrencia = codOcorrencia;
/* 17 */     this.dscOcorrencia = dscOcorrencia;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MensagemRetornoVO() {}
/*    */ 
/*    */   
/*    */   public void setCodTransacaoConfirm(Long codTransacaoConfirm) {
/* 26 */     this.codTransacaoConfirm = codTransacaoConfirm;
/*    */   }
/*    */   
/*    */   public Long getCodTransacaoConfirm() {
/* 30 */     return this.codTransacaoConfirm;
/*    */   }
/*    */   
/*    */   public void setCodOcorrencia(String codOcorrencia) {
/* 34 */     this.codOcorrencia = codOcorrencia;
/*    */   }
/*    */   
/*    */   public String getCodOcorrencia() {
/* 38 */     return this.codOcorrencia;
/*    */   }
/*    */   
/*    */   public void setDscOcorrencia(String dscOcorrencia) {
/* 42 */     this.dscOcorrencia = dscOcorrencia;
/*    */   }
/*    */   
/*    */   public String getDscOcorrencia() {
/* 46 */     return this.dscOcorrencia;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\processo\MensagemRetornoVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */