/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "K")})
/*    */ public class DetalheK
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 7)
/*    */   private String nroSequencial;
/*    */   @PositionalField(initialPosition = 27, finalPosition = 30)
/*    */   private String agenciaDebito;
/*    */   @PositionalField(initialPosition = 31, finalPosition = 44)
/*    */   private String identClienteBanco;
/*    */   @PositionalField(initialPosition = 45, finalPosition = 46)
/*    */   private String tipoTratamento;
/*    */   @PositionalField(initialPosition = 47, finalPosition = 61)
/*    */   private String valorDebitado;
/*    */   @PositionalField(initialPosition = 62, finalPosition = 65)
/*    */   private String codigoReceita;
/*    */   @PositionalField(initialPosition = 66, finalPosition = 66)
/*    */   private String tipoIdentificacao;
/*    */   @PositionalField(initialPosition = 67, finalPosition = 81)
/*    */   private String identificacao;
/*    */   @PositionalField(initialPosition = 82, finalPosition = 150)
/*    */   private String usoFuturo;
/*    */   
/*    */   public String getCodRegistro() {
/* 39 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 42 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getNroSequencial() {
/* 45 */     return this.nroSequencial;
/*    */   }
/*    */   public void setNroSequencial(String nroSequencial) {
/* 48 */     this.nroSequencial = nroSequencial;
/*    */   }
/*    */   public String getAgenciaDebito() {
/* 51 */     return this.agenciaDebito;
/*    */   }
/*    */   public void setAgenciaDebito(String agenciaDebito) {
/* 54 */     this.agenciaDebito = agenciaDebito;
/*    */   }
/*    */   public String getIdentClienteBanco() {
/* 57 */     return this.identClienteBanco;
/*    */   }
/*    */   public void setIdentClienteBanco(String identClienteBanco) {
/* 60 */     this.identClienteBanco = identClienteBanco;
/*    */   }
/*    */   public String getTipoTratamento() {
/* 63 */     return this.tipoTratamento;
/*    */   }
/*    */   public void setTipoTratamento(String tipoTratamento) {
/* 66 */     this.tipoTratamento = tipoTratamento;
/*    */   }
/*    */   public String getValorDebitado() {
/* 69 */     return this.valorDebitado;
/*    */   }
/*    */   public void setValorDebitado(String valorDebitado) {
/* 72 */     this.valorDebitado = valorDebitado;
/*    */   }
/*    */   public String getCodigoReceita() {
/* 75 */     return this.codigoReceita;
/*    */   }
/*    */   public void setCodigoReceita(String codigoReceita) {
/* 78 */     this.codigoReceita = codigoReceita;
/*    */   }
/*    */   public String getTipoIdentificacao() {
/* 81 */     return this.tipoIdentificacao;
/*    */   }
/*    */   public void setTipoIdentificacao(String tipoIdentificacao) {
/* 84 */     this.tipoIdentificacao = tipoIdentificacao;
/*    */   }
/*    */   public String getIdentificacao() {
/* 87 */     return this.identificacao;
/*    */   }
/*    */   public void setIdentificacao(String identificacao) {
/* 90 */     this.identificacao = identificacao;
/*    */   }
/*    */   public String getUsoFuturo() {
/* 93 */     return this.usoFuturo;
/*    */   }
/*    */   public void setUsoFuturo(String usoFuturo) {
/* 96 */     this.usoFuturo = usoFuturo;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\DetalheK.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */