/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "Z")})
/*    */ public class Trailler
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 7)
/*    */   private String totalRegistrosDebito;
/*    */   @PositionalField(initialPosition = 8, finalPosition = 24)
/*    */   private String valorTotalRegistrosDebito;
/*    */   @PositionalField(initialPosition = 25, finalPosition = 150)
/*    */   private String usoFuturo;
/*    */   
/*    */   public String getCodRegistro() {
/* 27 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 30 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getTotalRegistrosDebito() {
/* 33 */     return this.totalRegistrosDebito;
/*    */   }
/*    */   public void setTotalRegistrosDebito(String totalRegistrosDebito) {
/* 36 */     this.totalRegistrosDebito = totalRegistrosDebito;
/*    */   }
/*    */   public String getValorTotalRegistrosDebito() {
/* 39 */     return this.valorTotalRegistrosDebito;
/*    */   }
/*    */   public void setValorTotalRegistrosDebito(String valorTotalRegistrosDebito) {
/* 42 */     this.valorTotalRegistrosDebito = valorTotalRegistrosDebito;
/*    */   }
/*    */   public String getUsoFuturo() {
/* 45 */     return this.usoFuturo;
/*    */   }
/*    */   public void setUsoFuturo(String usoFuturo) {
/* 48 */     this.usoFuturo = usoFuturo;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\Trailler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */