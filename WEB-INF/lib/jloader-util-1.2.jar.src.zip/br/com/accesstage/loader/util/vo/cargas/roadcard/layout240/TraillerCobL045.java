/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class TraillerCobL045
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -8132252737800473697L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBcoTrllrLte;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer nroLteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoRegTrllrLte;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 23)
/*     */   private Integer qtdLteLte;
/*     */   @IntegerPositionalField(initialPosition = 24, finalPosition = 29)
/*     */   private Integer qtdTitCobSimples;
/*     */   @PositionalField(initialPosition = 30, finalPosition = 46, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrTtTitCobSimples;
/*     */   @IntegerPositionalField(initialPosition = 47, finalPosition = 52)
/*     */   private Integer qtdTitCobVincs;
/*     */   @PositionalField(initialPosition = 53, finalPosition = 69, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrTtTitCobVincs;
/*     */   @IntegerPositionalField(initialPosition = 70, finalPosition = 75)
/*     */   private Integer qtdTitCobCaucs;
/*     */   @PositionalField(initialPosition = 76, finalPosition = 92, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrTtTitCobCaucs;
/*     */   @IntegerPositionalField(initialPosition = 93, finalPosition = 98)
/*     */   private Integer qtdTitCobDescs;
/*     */   @PositionalField(initialPosition = 99, finalPosition = 115, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrTtTitCobDescs;
/*     */   @PositionalField(initialPosition = 116, finalPosition = 123)
/*     */   private String nroAvisoLanc;
/*     */   @PositionalField(initialPosition = 124, finalPosition = 240)
/*     */   private String dscUsoFbrn2;
/*     */   
/*     */   public String getCodBcoTrllrLte() {
/*  53 */     return this.codBcoTrllrLte;
/*     */   }
/*     */   public void setCodBcoTrllrLte(String codBcoTrllrLte) {
/*  56 */     this.codBcoTrllrLte = codBcoTrllrLte;
/*     */   }
/*     */   public Integer getNroLteServico() {
/*  59 */     return this.nroLteServico;
/*     */   }
/*     */   public void setNroLteServico(Integer nroLteServico) {
/*  62 */     this.nroLteServico = nroLteServico;
/*     */   }
/*     */   public Integer getTpoRegTrllrLte() {
/*  65 */     return this.tpoRegTrllrLte;
/*     */   }
/*     */   public void setTpoRegTrllrLte(Integer tpoRegTrllrLte) {
/*  68 */     this.tpoRegTrllrLte = tpoRegTrllrLte;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  71 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  74 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getQtdLteLte() {
/*  77 */     return this.qtdLteLte;
/*     */   }
/*     */   public void setQtdLteLte(Integer qtdLteLte) {
/*  80 */     this.qtdLteLte = qtdLteLte;
/*     */   }
/*     */   public Integer getQtdTitCobSimples() {
/*  83 */     return this.qtdTitCobSimples;
/*     */   }
/*     */   public void setQtdTitCobSimples(Integer qtdTitCobSimples) {
/*  86 */     this.qtdTitCobSimples = qtdTitCobSimples;
/*     */   }
/*     */   public BigDecimal getVlrTtTitCobSimples() {
/*  89 */     return this.vlrTtTitCobSimples;
/*     */   }
/*     */   public void setVlrTtTitCobSimples(BigDecimal vlrTtTitCobSimples) {
/*  92 */     this.vlrTtTitCobSimples = vlrTtTitCobSimples;
/*     */   }
/*     */   public Integer getQtdTitCobVincs() {
/*  95 */     return this.qtdTitCobVincs;
/*     */   }
/*     */   public void setQtdTitCobVincs(Integer qtdTitCobVincs) {
/*  98 */     this.qtdTitCobVincs = qtdTitCobVincs;
/*     */   }
/*     */   public BigDecimal getVlrTtTitCobVincs() {
/* 101 */     return this.vlrTtTitCobVincs;
/*     */   }
/*     */   public void setVlrTtTitCobVincs(BigDecimal vlrTtTitCobVincs) {
/* 104 */     this.vlrTtTitCobVincs = vlrTtTitCobVincs;
/*     */   }
/*     */   public Integer getQtdTitCobCaucs() {
/* 107 */     return this.qtdTitCobCaucs;
/*     */   }
/*     */   public void setQtdTitCobCaucs(Integer qtdTitCobCaucs) {
/* 110 */     this.qtdTitCobCaucs = qtdTitCobCaucs;
/*     */   }
/*     */   public BigDecimal getVlrTtTitCobCaucs() {
/* 113 */     return this.vlrTtTitCobCaucs;
/*     */   }
/*     */   public void setVlrTtTitCobCaucs(BigDecimal vlrTtTitCobCaucs) {
/* 116 */     this.vlrTtTitCobCaucs = vlrTtTitCobCaucs;
/*     */   }
/*     */   public Integer getQtdTitCobDescs() {
/* 119 */     return this.qtdTitCobDescs;
/*     */   }
/*     */   public void setQtdTitCobDescs(Integer qtdTitCobDescs) {
/* 122 */     this.qtdTitCobDescs = qtdTitCobDescs;
/*     */   }
/*     */   public BigDecimal getVlrTtTitCobDescs() {
/* 125 */     return this.vlrTtTitCobDescs;
/*     */   }
/*     */   public void setVlrTtTitCobDescs(BigDecimal vlrTtTitCobDescs) {
/* 128 */     this.vlrTtTitCobDescs = vlrTtTitCobDescs;
/*     */   }
/*     */   public String getNroAvisoLanc() {
/* 131 */     return this.nroAvisoLanc;
/*     */   }
/*     */   public void setNroAvisoLanc(String nroAvisoLanc) {
/* 134 */     this.nroAvisoLanc = nroAvisoLanc;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 137 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 140 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\TraillerCobL045.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */