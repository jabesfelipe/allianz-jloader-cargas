/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout150;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Febraban150VO
/*    */ {
/* 17 */   private List<DetalheA> listDetalheA = new ArrayList<DetalheA>();
/* 18 */   private List<DetalheB> listDetalheB = new ArrayList<DetalheB>();
/* 19 */   private List<DetalheF> listDetalheF = new ArrayList<DetalheF>();
/* 20 */   private List<DetalheG> listDetalheG = new ArrayList<DetalheG>(); private Header header;
/* 21 */   private List<DetalheFV4> listDetalheFV4 = new ArrayList<DetalheFV4>();
/*    */   private Trailler trailler;
/*    */   
/*    */   public Header getHeader() {
/* 25 */     return this.header;
/*    */   }
/*    */   public void setHeader(Header header) {
/* 28 */     this.header = header;
/*    */   }
/*    */   public List<DetalheA> getListDetalheA() {
/* 31 */     return this.listDetalheA;
/*    */   }
/*    */   public void setListDetalheA(List<DetalheA> listDetalheA) {
/* 34 */     this.listDetalheA = listDetalheA;
/*    */   }
/*    */   public List<DetalheB> getListDetalheB() {
/* 37 */     return this.listDetalheB;
/*    */   }
/*    */   public void setListDetalheB(List<DetalheB> listDetalheB) {
/* 40 */     this.listDetalheB = listDetalheB;
/*    */   }
/*    */   public List<DetalheF> getListDetalheF() {
/* 43 */     return this.listDetalheF;
/*    */   }
/*    */   public void setListDetalheF(List<DetalheF> listDetalheF) {
/* 46 */     this.listDetalheF = listDetalheF;
/*    */   }
/*    */   public List<DetalheG> getListDetalheG() {
/* 49 */     return this.listDetalheG;
/*    */   }
/*    */   public void setListDetalheG(List<DetalheG> listDetalheG) {
/* 52 */     this.listDetalheG = listDetalheG;
/*    */   }
/*    */   public List<DetalheFV4> getListDetalheFV4() {
/* 55 */     return this.listDetalheFV4;
/*    */   }
/*    */   public void setListDetalheFV4(List<DetalheFV4> listDetalheFV4) {
/* 58 */     this.listDetalheFV4 = listDetalheFV4;
/*    */   }
/*    */   public Trailler getTrailler() {
/* 61 */     return this.trailler;
/*    */   }
/*    */   public void setTrailler(Trailler trailler) {
/* 64 */     this.trailler = trailler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout150\Febraban150VO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */