/*    */ package br.com.accesstage.loader.util.constantes.processo;
/*    */ 
/*    */ import java.sql.Timestamp;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Util
/*    */ {
/*    */   public static List<String> montarCodigosOcorrencia(String codigoOcorrencia) {
/* 20 */     char[] valores = codigoOcorrencia.toCharArray();
/* 21 */     List<String> codigosMsgs = new ArrayList<String>();
/*    */ 
/*    */     
/* 24 */     for (int i = 0; i < valores.length; i += 2) {
/* 25 */       String valor = valores[i] + "" + valores[i + 1];
/* 26 */       if (valor.replaceAll("\\s+", "").length() > 0) {
/* 27 */         codigosMsgs.add(valor);
/*    */       }
/*    */     } 
/* 30 */     return codigosMsgs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String montarNomeArquivo(String nroBanco, Timestamp dtaGeracaoArquivo, String tpoOperacao, int sequencia) {
/* 43 */     if (sequencia >= 0) {
/*    */       
/* 45 */       String nroSequencia = String.format("%02d", new Object[] { Integer.valueOf(sequencia) });
/* 46 */       String ano = UtilDate.getAno(dtaGeracaoArquivo);
/* 47 */       String mes = UtilDate.getMes(dtaGeracaoArquivo);
/* 48 */       String dia = UtilDate.getDia(dtaGeracaoArquivo);
/* 49 */       String tipoOperacaoDescricao = null;
/*    */       
/* 51 */       if (tpoOperacao.equals("2")) {
/* 52 */         tipoOperacaoDescricao = "DEB";
/*    */       }
/* 54 */       else if (tpoOperacao.equals("1")) {
/* 55 */         tipoOperacaoDescricao = "PAG";
/*    */       } else {
/*    */         
/* 58 */         tipoOperacaoDescricao = "";
/*    */       } 
/*    */       
/* 61 */       StringBuilder sb = (new StringBuilder()).append(nroBanco).append("_").append("XXXXXX").append("_").append(tipoOperacaoDescricao).append(ano).append(mes).append(dia).append(nroSequencia);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 72 */       return sb.toString();
/*    */     } 
/* 74 */     return "";
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\processo\Util.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */