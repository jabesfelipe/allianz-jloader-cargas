/*    */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VolkswagenRetorno240VO
/*    */ {
/* 19 */   private List<HeaderLote> listHeaderLote = new ArrayList<HeaderLote>();
/* 20 */   private List<SegmentoA> listSegmentoA = new ArrayList<SegmentoA>();
/* 21 */   private List<SegmentoB> listSegmentoB = new ArrayList<SegmentoB>();
/* 22 */   private List<SegmentoJ> listSegmentoJ = new ArrayList<SegmentoJ>();
/* 23 */   private List<TraillerLote> listTraillerLote = new ArrayList<TraillerLote>();
/* 24 */   private List<SegmentoJ52> listSegmentoJ52 = new ArrayList<SegmentoJ52>();
/* 25 */   private List<Segmento3Z> listSegmento3Z = new ArrayList<Segmento3Z>();
/*    */   private Header header;
/*    */   
/*    */   public Header getHeader() {
/* 29 */     return this.header;
/*    */   }
/*    */   private Trailler trailler;
/*    */   public void setHeader(Header header) {
/* 33 */     this.header = header;
/*    */   }
/*    */   
/*    */   public List<HeaderLote> getListHeaderLote() {
/* 37 */     return this.listHeaderLote;
/*    */   }
/*    */   
/*    */   public void setListHeaderLote(List<HeaderLote> listHeaderLote) {
/* 41 */     this.listHeaderLote = listHeaderLote;
/*    */   }
/*    */   
/*    */   public List<SegmentoA> getListSegmentoA() {
/* 45 */     return this.listSegmentoA;
/*    */   }
/*    */   
/*    */   public void setListSegmentoA(List<SegmentoA> listSegmentoA) {
/* 49 */     this.listSegmentoA = listSegmentoA;
/*    */   }
/*    */   
/*    */   public List<SegmentoB> getListSegmentoB() {
/* 53 */     return this.listSegmentoB;
/*    */   }
/*    */   
/*    */   public void setListSegmentoB(List<SegmentoB> listSegmentoB) {
/* 57 */     this.listSegmentoB = listSegmentoB;
/*    */   }
/*    */   
/*    */   public List<SegmentoJ> getListSegmentoJ() {
/* 61 */     return this.listSegmentoJ;
/*    */   }
/*    */   
/*    */   public void setListSegmentoJ(List<SegmentoJ> listSegmentoJ) {
/* 65 */     this.listSegmentoJ = listSegmentoJ;
/*    */   }
/*    */   
/*    */   public List<SegmentoJ52> getListSegmentoJ52() {
/* 69 */     return this.listSegmentoJ52;
/*    */   }
/*    */   
/*    */   public void setListSegmentoJ52(List<SegmentoJ52> listSegmentoJ52) {
/* 73 */     this.listSegmentoJ52 = listSegmentoJ52;
/*    */   }
/*    */   
/*    */   public List<Segmento3Z> getListSegmento3Z() {
/* 77 */     return this.listSegmento3Z;
/*    */   }
/*    */   
/*    */   public void setListSegmento3Z(List<Segmento3Z> listSegmento3Z) {
/* 81 */     this.listSegmento3Z = listSegmento3Z;
/*    */   }
/*    */   
/*    */   public List<TraillerLote> getListTraillerLote() {
/* 85 */     return this.listTraillerLote;
/*    */   }
/*    */   
/*    */   public void setListTraillerLote(List<TraillerLote> listTraillerLote) {
/* 89 */     this.listTraillerLote = listTraillerLote;
/*    */   }
/*    */   
/*    */   public Trailler getTrailler() {
/* 93 */     return this.trailler;
/*    */   }
/*    */   
/*    */   public void setTrailler(Trailler trailler) {
/* 97 */     this.trailler = trailler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\VolkswagenRetorno240VO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */