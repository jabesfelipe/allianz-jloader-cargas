/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoB
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 7753388852092217693L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBanco;
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private String loteServico;
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private String tpoRegistro;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private String nroSeqLote;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSeguimentoDetalhe;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 17)
/*     */   private String usoCNAB;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private String tpoInsFavorecido;
/*     */   @PositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private String nroInsFavorecido;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 62)
/*     */   private String dscLogradouro;
/*     */   @PositionalField(initialPosition = 63, finalPosition = 67)
/*     */   private String nroLocal;
/*     */   @PositionalField(initialPosition = 68, finalPosition = 82)
/*     */   private String dscComplmento;
/*     */   @PositionalField(initialPosition = 83, finalPosition = 97)
/*     */   private String dscBairro;
/*     */   @PositionalField(initialPosition = 98, finalPosition = 117)
/*     */   private String nmeCidade;
/*     */   @PositionalField(initialPosition = 118, finalPosition = 122)
/*     */   private String nroCep;
/*     */   @PositionalField(initialPosition = 123, finalPosition = 125)
/*     */   private String nroCepComplemento;
/*     */   @PositionalField(initialPosition = 126, finalPosition = 127)
/*     */   private String slgEstado;
/*     */   @PositionalField(initialPosition = 128, finalPosition = 135)
/*     */   private String dtaVenc;
/*     */   @PositionalField(initialPosition = 136, finalPosition = 150)
/*     */   private String vlrDoc;
/*     */   @PositionalField(initialPosition = 151, finalPosition = 165)
/*     */   private String vlrAba;
/*     */   @PositionalField(initialPosition = 166, finalPosition = 180)
/*     */   private String vlrDes;
/*     */   @PositionalField(initialPosition = 181, finalPosition = 195)
/*     */   private String vlrMora;
/*     */   @PositionalField(initialPosition = 196, finalPosition = 210)
/*     */   private String vlrMulta;
/*     */   @PositionalField(initialPosition = 211, finalPosition = 225)
/*     */   private String codDocFavorecido;
/*     */   @PositionalField(initialPosition = 226, finalPosition = 226)
/*     */   private String dscAviso;
/*     */   @PositionalField(initialPosition = 227, finalPosition = 232)
/*     */   private String usoSiape;
/*     */   @PositionalField(initialPosition = 233, finalPosition = 240)
/*     */   private String usoCNAB1;
/*     */   
/*     */   public String getCodBanco() {
/*  71 */     return this.codBanco;
/*     */   }
/*     */   public void setCodBanco(String codBanco) {
/*  74 */     this.codBanco = codBanco;
/*     */   }
/*     */   public String getLoteServico() {
/*  77 */     return this.loteServico;
/*     */   }
/*     */   public void setLoteServico(String loteServico) {
/*  80 */     this.loteServico = loteServico;
/*     */   }
/*     */   public String getTpoRegistro() {
/*  83 */     return this.tpoRegistro;
/*     */   }
/*     */   public void setTpoRegistro(String tpoRegistro) {
/*  86 */     this.tpoRegistro = tpoRegistro;
/*     */   }
/*     */   public String getNroSeqLote() {
/*  89 */     return this.nroSeqLote;
/*     */   }
/*     */   public void setNroSeqLote(String nroSeqLote) {
/*  92 */     this.nroSeqLote = nroSeqLote;
/*     */   }
/*     */   public String getCodSeguimentoDetalhe() {
/*  95 */     return this.codSeguimentoDetalhe;
/*     */   }
/*     */   public void setCodSeguimentoDetalhe(String codSeguimentoDetalhe) {
/*  98 */     this.codSeguimentoDetalhe = codSeguimentoDetalhe;
/*     */   }
/*     */   public String getUsoCNAB() {
/* 101 */     return this.usoCNAB;
/*     */   }
/*     */   public void setUsoCNAB(String usoCNAB) {
/* 104 */     this.usoCNAB = usoCNAB;
/*     */   }
/*     */   public String getTpoInsFavorecido() {
/* 107 */     return this.tpoInsFavorecido;
/*     */   }
/*     */   public void setTpoInsFavorecido(String tpoInsFavorecido) {
/* 110 */     this.tpoInsFavorecido = tpoInsFavorecido;
/*     */   }
/*     */   public String getNroInsFavorecido() {
/* 113 */     return this.nroInsFavorecido;
/*     */   }
/*     */   public void setNroInsFavorecido(String nroInsFavorecido) {
/* 116 */     this.nroInsFavorecido = nroInsFavorecido;
/*     */   }
/*     */   public String getDscLogradouro() {
/* 119 */     return this.dscLogradouro;
/*     */   }
/*     */   public void setDscLogradouro(String dscLogradouro) {
/* 122 */     this.dscLogradouro = dscLogradouro;
/*     */   }
/*     */   public String getNroLocal() {
/* 125 */     return this.nroLocal;
/*     */   }
/*     */   public void setNroLocal(String nroLocal) {
/* 128 */     this.nroLocal = nroLocal;
/*     */   }
/*     */   public String getDscComplmento() {
/* 131 */     return this.dscComplmento;
/*     */   }
/*     */   public void setDscComplmento(String dscComplmento) {
/* 134 */     this.dscComplmento = dscComplmento;
/*     */   }
/*     */   public String getDscBairro() {
/* 137 */     return this.dscBairro;
/*     */   }
/*     */   public void setDscBairro(String dscBairro) {
/* 140 */     this.dscBairro = dscBairro;
/*     */   }
/*     */   public String getNmeCidade() {
/* 143 */     return this.nmeCidade;
/*     */   }
/*     */   public void setNmeCidade(String nmeCidade) {
/* 146 */     this.nmeCidade = nmeCidade;
/*     */   }
/*     */   public String getNroCep() {
/* 149 */     return this.nroCep;
/*     */   }
/*     */   public void setNroCep(String nroCep) {
/* 152 */     this.nroCep = nroCep;
/*     */   }
/*     */   public String getNroCepComplemento() {
/* 155 */     return this.nroCepComplemento;
/*     */   }
/*     */   public void setNroCepComplemento(String nroCepComplemento) {
/* 158 */     this.nroCepComplemento = nroCepComplemento;
/*     */   }
/*     */   public String getSlgEstado() {
/* 161 */     return this.slgEstado;
/*     */   }
/*     */   public void setSlgEstado(String slgEstado) {
/* 164 */     this.slgEstado = slgEstado;
/*     */   }
/*     */   public String getDtaVenc() {
/* 167 */     return this.dtaVenc;
/*     */   }
/*     */   public void setDtaVenc(String dtaVenc) {
/* 170 */     this.dtaVenc = dtaVenc;
/*     */   }
/*     */   public String getVlrDoc() {
/* 173 */     return this.vlrDoc;
/*     */   }
/*     */   public void setVlrDoc(String vlrDoc) {
/* 176 */     this.vlrDoc = vlrDoc;
/*     */   }
/*     */   public String getVlrAba() {
/* 179 */     return this.vlrAba;
/*     */   }
/*     */   public void setVlrAba(String vlrAba) {
/* 182 */     this.vlrAba = vlrAba;
/*     */   }
/*     */   public String getVlrDes() {
/* 185 */     return this.vlrDes;
/*     */   }
/*     */   public void setVlrDes(String vlrDes) {
/* 188 */     this.vlrDes = vlrDes;
/*     */   }
/*     */   public String getVlrMora() {
/* 191 */     return this.vlrMora;
/*     */   }
/*     */   public void setVlrMora(String vlrMora) {
/* 194 */     this.vlrMora = vlrMora;
/*     */   }
/*     */   public String getVlrMulta() {
/* 197 */     return this.vlrMulta;
/*     */   }
/*     */   public void setVlrMulta(String vlrMulta) {
/* 200 */     this.vlrMulta = vlrMulta;
/*     */   }
/*     */   public String getCodDocFavorecido() {
/* 203 */     return this.codDocFavorecido;
/*     */   }
/*     */   public void setCodDocFavorecido(String codDocFavorecido) {
/* 206 */     this.codDocFavorecido = codDocFavorecido;
/*     */   }
/*     */   public String getDscAviso() {
/* 209 */     return this.dscAviso;
/*     */   }
/*     */   public void setDscAviso(String dscAviso) {
/* 212 */     this.dscAviso = dscAviso;
/*     */   }
/*     */   public String getUsoSiape() {
/* 215 */     return this.usoSiape;
/*     */   }
/*     */   public void setUsoSiape(String usoSiape) {
/* 218 */     this.usoSiape = usoSiape;
/*     */   }
/*     */   public String getUsoCNAB1() {
/* 221 */     return this.usoCNAB1;
/*     */   }
/*     */   public void setUsoCNAB1(String usoCNAB1) {
/* 224 */     this.usoCNAB1 = usoCNAB1;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\SegmentoB.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */