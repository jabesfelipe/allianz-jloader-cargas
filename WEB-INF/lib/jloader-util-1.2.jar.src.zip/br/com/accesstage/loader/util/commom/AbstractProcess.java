/*     */ package br.com.accesstage.loader.util.commom;
/*     */ 
/*     */ import br.com.accesstage.loader.util.dao.BaseDAO;
/*     */ import br.com.accesstage.loader.util.exception.LayoutException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ public abstract class AbstractProcess
/*     */ {
/*  18 */   private static Logger logger = Logger.getLogger(AbstractProcess.class);
/*     */   
/*     */   protected Long codControleProc;
/*     */   
/*     */   protected Long codArquivo;
/*     */   
/*     */   protected Long qtdRegistros;
/*     */   
/*     */   protected Date dtaInicio;
/*     */   
/*     */   protected Date dtaFim;
/*     */   
/*     */   protected String dscObs;
/*     */   protected String codStatus;
/*     */   protected Long codProcArq;
/*     */   protected String codTpoLayout;
/*     */   @Autowired
/*     */   private BaseDAO baseDAO;
/*     */   
/*     */   public AbstractProcess() {}
/*     */   
/*     */   protected AbstractProcess(Long codControleProc, Long codArquivo, Long qtdRegistros, Date dtaInicio, Date dtaFim, String dscObs, String codStatus, Long codProcArq, String codTpoLayout) {
/*  40 */     this.codControleProc = codControleProc;
/*  41 */     this.codArquivo = codArquivo;
/*  42 */     this.qtdRegistros = qtdRegistros;
/*  43 */     this.dtaInicio = dtaInicio;
/*  44 */     this.dtaFim = dtaFim;
/*  45 */     this.dscObs = dscObs;
/*  46 */     this.codStatus = codStatus;
/*  47 */     this.codProcArq = codProcArq;
/*  48 */     this.codTpoLayout = codTpoLayout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void process() {
/*     */     try {
/*  57 */       updateDtaInicio(this.codControleProc);
/*  58 */       logger.info("atualizando data inicio processamento cod: " + this.codControleProc + " :::::::::::::::::::::::::::::::");
/*  59 */       processLine();
/*  60 */     } catch (SQLException sqle) {
/*     */       
/*     */       try {
/*  63 */         trataErro("ERRO", sqle, "Alguns registros não foram processados. Ocorrência por ter sido por erro de sistema ou regra de negócio, favor verificar a tabela CONTROLE_PROCESSAMENTO_ERRO para maiores informações.");
/*  64 */         insereErroControleProcessamentoErro(sqle);
/*  65 */       } catch (SQLException sqle2) {
/*  66 */         logger.error("[ASProcessaLib] - Nao foi possivel obter conexao com a base de dados", sqle2);
/*     */       } 
/*  68 */     } catch (LayoutException le) {
/*     */       
/*     */       try {
/*  71 */         trataErro("ERRO", (Exception)le, "Alguns registros não foram processados. Ocorrência por ter sido por erro de sistema ou regra de negócio, favor verificar a tabela CONTROLE_PROCESSAMENTO_ERRO para maiores informações.");
/*  72 */         insereErroControleProcessamentoErro((Exception)le);
/*  73 */       } catch (SQLException sqle) {
/*  74 */         logger.error("[ASProcessaLib] - Erro ao processar dados", (Throwable)le);
/*     */       } 
/*  76 */     } catch (Exception e) {
/*     */       try {
/*  78 */         trataErro("ERRO", e, "Alguns registros não foram processados. Ocorrência por ter sido por erro de sistema ou regra de negócio, favor verificar a tabela CONTROLE_PROCESSAMENTO_ERRO para maiores informações.");
/*  79 */         insereErroControleProcessamentoErro(e);
/*  80 */       } catch (SQLException sqle) {
/*  81 */         logger.error("[ASProcessaLib] - Erro ao processar dados", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void processLine() throws LayoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateDtaInicio(Long codControleProc) throws SQLException {
/*  98 */     logger.info("[ASProcessa] - Setando data de inicio do processamento.");
/*  99 */     this.baseDAO.merge("UPDATE CONTROLE_PROCESSAMENTO SET DTH_INICIO = SYSDATE WHERE COD_STATUS_PROCESSAMENTO = 'PROCESSANDO' AND COD_CONTROLE_PROC = ?", new Object[] { codControleProc });
/* 100 */     this.baseDAO.commit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateProcessFim(String sql, Object... param) throws SQLException, LayoutException {
/* 113 */     logger.info("[ASProcessa] - Setando fim do processamento.");
/*     */     try {
/* 115 */       this.baseDAO.merge(sql, param);
/* 116 */       logger.info("SQL Exec: " + sql + "Params informados: " + Arrays.<Object>asList(param));
/* 117 */       this.baseDAO.commit();
/* 118 */     } catch (SQLException sqle) {
/* 119 */       throw new LayoutException("Erro no update; " + sqle);
/*     */     } finally {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateStatusProcessamento(String sql, Object... param) throws SQLException, LayoutException {
/* 130 */     updateStatusProcessamentoController(sql, Boolean.TRUE, param);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateStatusProcessamentoNew(String sql, Object... param) throws SQLException, LayoutException {
/* 136 */     updateStatusProcessamentoController(sql, Boolean.FALSE, param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateStatusProcessamentoController(String sql, Boolean isCommit, Object... param) throws SQLException, LayoutException {
/* 150 */     logger.info("[ASProcessamento] - Atualizando STA_PROCESSAMENTO.");
/*     */     try {
/* 152 */       this.baseDAO.merge(sql, param);
/*     */       
/* 154 */       if (isCommit.booleanValue()) {
/* 155 */         this.baseDAO.commit();
/*     */       }
/*     */     }
/* 158 */     catch (SQLException sqle) {
/* 159 */       throw new LayoutException("Nao foi possivel efetuar o update do status do processamento. ", sqle);
/*     */     } finally {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertProcessamentoError(String sql, Object... param) throws SQLException, LayoutException {
/* 168 */     insertProcessamentoErrorController(sql, Boolean.TRUE, param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertProcessamentoErrorNew(String sql, Object... param) throws SQLException, LayoutException {
/* 175 */     insertProcessamentoErrorController(sql, Boolean.FALSE, param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insertProcessamentoErrorController(String sql, Boolean isCommit, Object... param) throws SQLException, LayoutException {
/* 189 */     logger.info("[ASProcessa] - Atualizando CONTROLE_PROCESSAMENTO_ERRO.");
/*     */     try {
/* 191 */       this.baseDAO.merge(sql, param);
/*     */       
/* 193 */       if (isCommit.booleanValue()) {
/* 194 */         this.baseDAO.commit();
/*     */       }
/*     */     }
/* 197 */     catch (SQLException sqle) {
/* 198 */       throw new LayoutException("Nao foi possivel efetuar o update do status do processamenro Erro. ", sqle);
/*     */     } finally {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getCodFornecedor(Long nroInsc) throws SQLException {
/* 211 */     logger.info("[ASProcessa] - Obtendo Codigo Fornecedor");
/* 212 */     Long codFornecedor = Long.class.cast(this.baseDAO.findCodigo("SELECT F.COD_FORNECEDOR FROM EMPRESA E JOIN FORNECEDOR F ON F.COD_EMP_FORN = E.COD_EMPRESA WHERE E.NRO_INSCRICAO = ?", Long.class, new Long[] { nroInsc }));
/* 213 */     if (codFornecedor != null) {
/* 214 */       return codFornecedor;
/*     */     }
/* 216 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCodAncora(Long nroInsc) throws SQLException {
/* 226 */     logger.info("[ASProcessa] - Obtendo Codigo Fornecedor");
/* 227 */     String codAncora = String.class.cast(this.baseDAO.findCodigo("SELECT COD_ANCORA FROM ANCORA WHERE COM_EMP_ANCORA IN (SELECT COD_EMPRESA FROM EMPRESA WHERE NRO_INSCRICAO = ?)", String.class, new Long[] { nroInsc }));
/* 228 */     if (StringUtils.isNotEmpty(codAncora)) {
/* 229 */       return codAncora;
/*     */     }
/* 231 */     return codAncora;
/*     */   }
/*     */   
/*     */   protected void trataErro(String status, Exception e, String desc) throws SQLException {
/* 235 */     logger.error("Ocorreu um erro ao processar os registros referene ao Código do Processamento: " + this.codControleProc + " e Código do Arquivo: " + this.codArquivo);
/*     */ 
/*     */     
/* 238 */     alteraStatusControleProcessamento(status, desc);
/* 239 */     insereErroControleProcessamentoErro(e);
/*     */   }
/*     */   
/*     */   protected void insereErroControleProcessamentoErro(Exception e) throws SQLException {
/* 243 */     logger.error("[ASProcessaLib] - Inserindo tabela CONTROLE_PROCESSAMENTO_ERRO para o Código de Arquivo: " + this.codArquivo);
/* 244 */     this.baseDAO.merge("INSERT INTO CONTROLE_PROCESSAMENTO_ERRO (COD_CONTROLE_PROC_ERROR, COD_CONTROLE_PROC, COD_ARQUIVO, NRO_LINHA_ARQ, DSC_MSG_ERRO) VALUES (?, ?, ?, ?, ?)", new Object[] { getCodControleErro(), getCodControleProc(), getCodArquivo(), Integer.valueOf(0), e.getMessage() });
/*     */   }
/*     */ 
/*     */   
/*     */   protected void alteraStatusControleProcessamento(String status, String desc) throws SQLException {
/* 249 */     logger.error("[ASProcessaLib] - Atualizando tabela CONTROLE_PROCESSAMENTO para o Código de Arquivo: " + this.codArquivo);
/* 250 */     this.baseDAO.merge("UPDATE CONTROLE_PROCESSAMENTO SET QTD_REGISTROS_PROCESSADOS = ?, COD_STATUS_PROCESSAMENTO = ?,  DTH_FIM = SYSDATE, DSC_OBSERVACAO = ? WHERE COD_STATUS_PROCESSAMENTO = 'PROCESSANDO' AND COD_CONTROLE_PROC = ? AND COD_ARQUIVO = ?", new Object[] { getQtdRegistros(), status, desc, getCodControleProc(), getCodArquivo() });
/*     */   }
/*     */ 
/*     */   
/*     */   protected Long getCodControleErro() throws SQLException {
/* 255 */     logger.info("[ASProcessaLib] - Obtendo o código de controle de processamento erro.");
/* 256 */     Long codProcError = this.baseDAO.getSequenceID("SEQ_COD_CONTROLE_PROC_ERROR");
/* 257 */     return codProcError;
/*     */   }
/*     */   
/*     */   public Long getCodArquivo() {
/* 261 */     return this.codArquivo;
/*     */   }
/*     */   
/*     */   public String getTpoLayout() {
/* 265 */     return this.codTpoLayout;
/*     */   }
/*     */   
/*     */   public Long getCodControleProc() {
/* 269 */     return this.codControleProc;
/*     */   }
/*     */   
/*     */   public void setQtdRegistros(Long qtdRegistros) {
/* 273 */     this.qtdRegistros = qtdRegistros;
/*     */   }
/*     */   
/*     */   public Long getQtdRegistros() {
/* 277 */     return this.qtdRegistros;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\commom\AbstractProcess.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */