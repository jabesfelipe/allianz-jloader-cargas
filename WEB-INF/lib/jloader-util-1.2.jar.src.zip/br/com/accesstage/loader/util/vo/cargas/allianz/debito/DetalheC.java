/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "C")})
/*    */ public class DetalheC
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 26)
/*    */   private String identClienteEmpresa;
/*    */   @PositionalField(initialPosition = 27, finalPosition = 30)
/*    */   private String agenciaDebito;
/*    */   @PositionalField(initialPosition = 31, finalPosition = 44)
/*    */   private String identClienteBanco;
/*    */   @PositionalField(initialPosition = 45, finalPosition = 84)
/*    */   private String ocorrencia1;
/*    */   @PositionalField(initialPosition = 85, finalPosition = 124)
/*    */   private String ocorrencia2;
/*    */   @PositionalField(initialPosition = 125, finalPosition = 149)
/*    */   private String usoFuturo;
/*    */   @PositionalField(initialPosition = 150, finalPosition = 150)
/*    */   private String codMovimento;
/*    */   
/*    */   public String getCodRegistro() {
/* 35 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 38 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getIdentClienteEmpresa() {
/* 41 */     return this.identClienteEmpresa;
/*    */   }
/*    */   public void setIdentClienteEmpresa(String identClienteEmpresa) {
/* 44 */     this.identClienteEmpresa = identClienteEmpresa;
/*    */   }
/*    */   public String getAgenciaDebito() {
/* 47 */     return this.agenciaDebito;
/*    */   }
/*    */   public void setAgenciaDebito(String agenciaDebito) {
/* 50 */     this.agenciaDebito = agenciaDebito;
/*    */   }
/*    */   public String getIdentClienteBanco() {
/* 53 */     return this.identClienteBanco;
/*    */   }
/*    */   public void setIdentClienteBanco(String identClienteBanco) {
/* 56 */     this.identClienteBanco = identClienteBanco;
/*    */   }
/*    */   public String getOcorrencia1() {
/* 59 */     return this.ocorrencia1;
/*    */   }
/*    */   public void setOcorrencia1(String ocorrencia1) {
/* 62 */     this.ocorrencia1 = ocorrencia1;
/*    */   }
/*    */   public String getOcorrencia2() {
/* 65 */     return this.ocorrencia2;
/*    */   }
/*    */   public void setOcorrencia2(String ocorrencia2) {
/* 68 */     this.ocorrencia2 = ocorrencia2;
/*    */   }
/*    */   public String getUsoFuturo() {
/* 71 */     return this.usoFuturo;
/*    */   }
/*    */   public void setUsoFuturo(String usoFuturo) {
/* 74 */     this.usoFuturo = usoFuturo;
/*    */   }
/*    */   public String getCodMovimento() {
/* 77 */     return this.codMovimento;
/*    */   }
/*    */   public void setCodMovimento(String codMovimento) {
/* 80 */     this.codMovimento = codMovimento;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\DetalheC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */