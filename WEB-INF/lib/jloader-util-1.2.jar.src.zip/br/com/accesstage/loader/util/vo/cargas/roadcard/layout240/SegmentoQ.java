/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.IntegerDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoQ
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -2259409405669711890L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeqLte;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegRegDtlh;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Integer codMovRmss;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private Integer tpoInsc;
/*     */   @LongPositionalField(initialPosition = 19, finalPosition = 33)
/*     */   private Long nroInsc;
/*     */   @PositionalField(initialPosition = 34, finalPosition = 73)
/*     */   private String nome;
/*     */   @PositionalField(initialPosition = 74, finalPosition = 113)
/*     */   private String endereco;
/*     */   @PositionalField(initialPosition = 114, finalPosition = 128)
/*     */   private String bairro;
/*     */   @IntegerPositionalField(initialPosition = 129, finalPosition = 133)
/*     */   private Integer nroCep;
/*     */   @IntegerPositionalField(initialPosition = 134, finalPosition = 136)
/*     */   private Integer nroCepSufixo;
/*     */   @PositionalField(initialPosition = 137, finalPosition = 151)
/*     */   private String nmeCidade;
/*     */   @PositionalField(initialPosition = 152, finalPosition = 153)
/*     */   private String uf;
/*     */   @IntegerPositionalField(initialPosition = 154, finalPosition = 154)
/*     */   private Integer tpoInsc2;
/*     */   @LongPositionalField(initialPosition = 155, finalPosition = 169)
/*     */   private Long nroInsc2;
/*     */   @PositionalField(initialPosition = 170, finalPosition = 209)
/*     */   private String nmeAvalista;
/*     */   @PositionalField(initialPosition = 210, finalPosition = 212, decorator = IntegerDecorator240.class)
/*     */   private Integer codCompensacao;
/*     */   @PositionalField(initialPosition = 213, finalPosition = 232)
/*     */   private String nroNosso;
/*     */   @PositionalField(initialPosition = 233, finalPosition = 240)
/*     */   private String dscUsoFbrn2;
/*     */   
/*     */   public String getCodBco() {
/*  67 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  70 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  73 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  76 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  79 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  82 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeqLte() {
/*  85 */     return this.nroSeqLte;
/*     */   }
/*     */   public void setNroSeqLte(Integer nroSeqLte) {
/*  88 */     this.nroSeqLte = nroSeqLte;
/*     */   }
/*     */   public String getCodSegRegDtlh() {
/*  91 */     return this.codSegRegDtlh;
/*     */   }
/*     */   public void setCodSegRegDtlh(String codSegRegDtlh) {
/*  94 */     this.codSegRegDtlh = codSegRegDtlh;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  97 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 100 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMovRmss() {
/* 103 */     return this.codMovRmss;
/*     */   }
/*     */   public void setCodMovRmss(Integer codMovRmss) {
/* 106 */     this.codMovRmss = codMovRmss;
/*     */   }
/*     */   public Integer getTpoInsc() {
/* 109 */     return this.tpoInsc;
/*     */   }
/*     */   public void setTpoInsc(Integer tpoInsc) {
/* 112 */     this.tpoInsc = tpoInsc;
/*     */   }
/*     */   public Long getNroInsc() {
/* 115 */     return this.nroInsc;
/*     */   }
/*     */   public void setNroInsc(Long nroInsc) {
/* 118 */     this.nroInsc = nroInsc;
/*     */   }
/*     */   public String getNome() {
/* 121 */     return this.nome;
/*     */   }
/*     */   public void setNome(String nome) {
/* 124 */     this.nome = nome;
/*     */   }
/*     */   public String getEndereco() {
/* 127 */     return this.endereco;
/*     */   }
/*     */   public void setEndereco(String endereco) {
/* 130 */     this.endereco = endereco;
/*     */   }
/*     */   public String getBairro() {
/* 133 */     return this.bairro;
/*     */   }
/*     */   public void setBairro(String bairro) {
/* 136 */     this.bairro = bairro;
/*     */   }
/*     */   public Integer getNroCep() {
/* 139 */     return this.nroCep;
/*     */   }
/*     */   public void setNroCep(Integer nroCep) {
/* 142 */     this.nroCep = nroCep;
/*     */   }
/*     */   public Integer getNroCepSufixo() {
/* 145 */     return this.nroCepSufixo;
/*     */   }
/*     */   public void setNroCepSufixo(Integer nroCepSufixo) {
/* 148 */     this.nroCepSufixo = nroCepSufixo;
/*     */   }
/*     */   public String getNmeCidade() {
/* 151 */     return this.nmeCidade;
/*     */   }
/*     */   public void setNmeCidade(String nmeCidade) {
/* 154 */     this.nmeCidade = nmeCidade;
/*     */   }
/*     */   public String getUf() {
/* 157 */     return this.uf;
/*     */   }
/*     */   public void setUf(String uf) {
/* 160 */     this.uf = uf;
/*     */   }
/*     */   public Integer getTpoInsc2() {
/* 163 */     return this.tpoInsc2;
/*     */   }
/*     */   public void setTpoInsc2(Integer tpoInsc2) {
/* 166 */     this.tpoInsc2 = tpoInsc2;
/*     */   }
/*     */   public Long getNroInsc2() {
/* 169 */     return this.nroInsc2;
/*     */   }
/*     */   public void setNroInsc2(Long nroInsc2) {
/* 172 */     this.nroInsc2 = nroInsc2;
/*     */   }
/*     */   public String getNmeAvalista() {
/* 175 */     return this.nmeAvalista;
/*     */   }
/*     */   public void setNmeAvalista(String nmeAvalista) {
/* 178 */     this.nmeAvalista = nmeAvalista;
/*     */   }
/*     */   public Integer getCodCompensacao() {
/* 181 */     return this.codCompensacao;
/*     */   }
/*     */   public void setCodCompensacao(Integer codCompensacao) {
/* 184 */     this.codCompensacao = codCompensacao;
/*     */   }
/*     */   public String getNroNosso() {
/* 187 */     return this.nroNosso;
/*     */   }
/*     */   public void setNroNosso(String nroNosso) {
/* 190 */     this.nroNosso = nroNosso;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 193 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 196 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoQ.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */