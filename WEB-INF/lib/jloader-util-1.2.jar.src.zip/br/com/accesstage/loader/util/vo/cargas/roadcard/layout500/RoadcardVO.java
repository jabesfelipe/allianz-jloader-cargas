/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout500;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoadcardVO
/*    */ {
/*    */   private Header header;
/*    */   private Trailler trailler;
/* 15 */   private List<Detalhe> listaDetalhe = new ArrayList<Detalhe>();
/*    */   
/*    */   public Header getHeader() {
/* 18 */     return this.header;
/*    */   }
/*    */   public void setHeader(Header header) {
/* 21 */     this.header = header;
/*    */   }
/*    */   public List<Detalhe> getListaDetalhe() {
/* 24 */     return this.listaDetalhe;
/*    */   }
/*    */   public void setListaDetalhe(List<Detalhe> listaDetalhe) {
/* 27 */     this.listaDetalhe = listaDetalhe;
/*    */   }
/*    */   public Trailler getTrailler() {
/* 30 */     return this.trailler;
/*    */   }
/*    */   public void setTrailler(Trailler trailler) {
/* 33 */     this.trailler = trailler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout500\RoadcardVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */