/*    */ package br.com.accesstage.loader.util.dao.rowmapper.cargas;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.allianz.ConfigVO;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigMapper
/*    */   implements RowMapper<ConfigVO>
/*    */ {
/*    */   public ConfigVO mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 14 */     ConfigVO configVO = new ConfigVO();
/* 15 */     configVO.setTpo_arquivo(rs.getString("tpo_arquivo"));
/* 16 */     configVO.setDsc_fluxo(rs.getString("dsc_fluxo"));
/* 17 */     configVO.setDsc_sentido(rs.getString("dsc_sentido"));
/* 18 */     configVO.setDsc_path_input(rs.getString("dsc_path_input"));
/* 19 */     configVO.setDsc_path_error(rs.getString("dsc_path_error"));
/* 20 */     configVO.setDsc_path_processed(rs.getString("dsc_path_processed"));
/* 21 */     configVO.setDsc_path_temp(rs.getString("dsc_path_temp"));
/* 22 */     configVO.setDsc_intercambio(rs.getString("dsc_intercambio"));
/* 23 */     configVO.setSta_ativo(rs.getString("sta_ativo"));
/* 24 */     return configVO;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\cargas\ConfigMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */