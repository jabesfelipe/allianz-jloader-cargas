/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.santander;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import com.github.ffpojo.metadata.positional.PaddingAlign;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoP
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 6024068582543275460L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*  21 */   private String codBco = "033";
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  23 */   private String lteServico = "0001";
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  25 */   private String tpoReg = "3";
/*     */   @PositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private String nroSeqLte;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*  29 */   private String codSegRegDtlh = "P";
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @PositionalField(initialPosition = 16, finalPosition = 17)
/*  33 */   private String codMovRmss = "01";
/*     */   @PositionalField(initialPosition = 18, finalPosition = 42, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  35 */   private String dadosAgencia = "2271701300097370130009737";
/*     */   @PositionalField(initialPosition = 43, finalPosition = 44, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn2;
/*     */   @PositionalField(initialPosition = 45, finalPosition = 57, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String nossoNumero;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 58, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*  41 */   private String tipoCobranca = "5";
/*     */   @PositionalField(initialPosition = 59, finalPosition = 59, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*  43 */   private String formaCadastramento = "1";
/*     */   @PositionalField(initialPosition = 60, finalPosition = 60, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*  45 */   private String dscTpoDoc = "1";
/*     */   @PositionalField(initialPosition = 61, finalPosition = 61, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn3;
/*     */   @PositionalField(initialPosition = 62, finalPosition = 62, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn4;
/*     */   @PositionalField(initialPosition = 63, finalPosition = 77, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String nroDocumento;
/*     */   @PositionalField(initialPosition = 78, finalPosition = 85)
/*     */   private String dtaVencTit;
/*     */   @PositionalField(initialPosition = 86, finalPosition = 100, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String vlrNmlTit;
/*     */   @IntegerPositionalField(initialPosition = 101, finalPosition = 104, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private Integer dscAgeCob;
/*     */   @PositionalField(initialPosition = 105, finalPosition = 105, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String dscAgeCobDV;
/*     */   @PositionalField(initialPosition = 106, finalPosition = 106, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn5;
/*     */   @PositionalField(initialPosition = 107, finalPosition = 108, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*  63 */   private String codEspTit = "20";
/*     */   @PositionalField(initialPosition = 109, finalPosition = 109, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*  65 */   private String dscIdentTit = "N";
/*     */   @PositionalField(initialPosition = 110, finalPosition = 117)
/*     */   private String dtaEmissaoTit;
/*     */   @IntegerPositionalField(initialPosition = 118, finalPosition = 118, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  69 */   private Integer codJuros = Integer.valueOf(1);
/*     */   @PositionalField(initialPosition = 119, finalPosition = 126)
/*     */   private String dtaJuros;
/*     */   @PositionalField(initialPosition = 127, finalPosition = 141)
/*     */   private String vlrJuros;
/*     */   @IntegerPositionalField(initialPosition = 142, finalPosition = 142)
/*  75 */   private Integer codDesc1 = Integer.valueOf(0);
/*     */   @PositionalField(initialPosition = 143, finalPosition = 150, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String dtaDesc1;
/*     */   @PositionalField(initialPosition = 151, finalPosition = 165, decorator = BigDecimalDecorator.class, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private BigDecimal vlrPrctConc;
/*     */   @PositionalField(initialPosition = 166, finalPosition = 180, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String vlrIofRecolhido;
/*     */   @PositionalField(initialPosition = 181, finalPosition = 195, decorator = BigDecimalDecorator.class, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private BigDecimal vlrAbat;
/*     */   @PositionalField(initialPosition = 196, finalPosition = 220)
/*     */   private String dscIdentTitEmp;
/*     */   @IntegerPositionalField(initialPosition = 221, finalPosition = 221, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private Integer codProtesto;
/*     */   @IntegerPositionalField(initialPosition = 222, finalPosition = 223, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private Integer nroDiasProt;
/*     */   @PositionalField(initialPosition = 224, finalPosition = 224)
/*  91 */   private String codBaixa = "2";
/*     */   
/*     */   @PositionalField(initialPosition = 225, finalPosition = 225, paddingAlign = PaddingAlign.LEFT, paddingCharacter = '0')
/*     */   private String dscUsoFbrn6;
/*     */   @PositionalField(initialPosition = 226, finalPosition = 227, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String nroDiasBaixa;
/*     */   @IntegerPositionalField(initialPosition = 228, finalPosition = 229, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private Integer codMoeda;
/*     */   @PositionalField(initialPosition = 230, finalPosition = 240)
/*     */   private String dscUsoLivre1;
/*     */   
/*     */   public String getCodBco() {
/* 103 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/* 106 */     this.codBco = codBco;
/*     */   }
/*     */   public String getLteServico() {
/* 109 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(String lteServico) {
/* 112 */     this.lteServico = lteServico;
/*     */   }
/*     */   public String getTpoReg() {
/* 115 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(String tpoReg) {
/* 118 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public String getNroSeqLte() {
/* 121 */     return this.nroSeqLte;
/*     */   }
/*     */   public void setNroSeqLte(String nroSeqLte) {
/* 124 */     this.nroSeqLte = nroSeqLte;
/*     */   }
/*     */   public String getCodSegRegDtlh() {
/* 127 */     return this.codSegRegDtlh;
/*     */   }
/*     */   public void setCodSegRegDtlh(String codSegRegDtlh) {
/* 130 */     this.codSegRegDtlh = codSegRegDtlh;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 133 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 136 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public String getCodMovRmss() {
/* 139 */     return this.codMovRmss;
/*     */   }
/*     */   public void setCodMovRmss(String codMovRmss) {
/* 142 */     this.codMovRmss = codMovRmss;
/*     */   }
/*     */   public String getDadosAgencia() {
/* 145 */     return this.dadosAgencia;
/*     */   }
/*     */   public void setDadosAgencia(String dadosAgencia) {
/* 148 */     this.dadosAgencia = dadosAgencia;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 151 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 154 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public String getNossoNumero() {
/* 157 */     return this.nossoNumero;
/*     */   }
/*     */   public void setNossoNumero(String nossoNumero) {
/* 160 */     this.nossoNumero = nossoNumero;
/*     */   }
/*     */   public String getFormaCadastramento() {
/* 163 */     return this.formaCadastramento;
/*     */   }
/*     */   public void setFormaCadastramento(String formaCadastramento) {
/* 166 */     this.formaCadastramento = formaCadastramento;
/*     */   }
/*     */   public String getTipoCobranca() {
/* 169 */     return this.tipoCobranca;
/*     */   }
/*     */   public void setTipoCobranca(String tipoCobranca) {
/* 172 */     this.tipoCobranca = tipoCobranca;
/*     */   }
/*     */   public String getDscTpoDoc() {
/* 175 */     return this.dscTpoDoc;
/*     */   }
/*     */   public void setDscTpoDoc(String dscTpoDoc) {
/* 178 */     this.dscTpoDoc = dscTpoDoc;
/*     */   }
/*     */   public String getDscUsoFbrn3() {
/* 181 */     return this.dscUsoFbrn3;
/*     */   }
/*     */   public void setDscUsoFbrn3(String dscUsoFbrn3) {
/* 184 */     this.dscUsoFbrn3 = dscUsoFbrn3;
/*     */   }
/*     */   public String getDscUsoFbrn4() {
/* 187 */     return this.dscUsoFbrn4;
/*     */   }
/*     */   public void setDscUsoFbrn4(String dscUsoFbrn4) {
/* 190 */     this.dscUsoFbrn4 = dscUsoFbrn4;
/*     */   }
/*     */   public String getNroDocumento() {
/* 193 */     return this.nroDocumento;
/*     */   }
/*     */   public void setNroDocumento(String nroDocumento) {
/* 196 */     this.nroDocumento = nroDocumento;
/*     */   }
/*     */   public String getDtaVencTit() {
/* 199 */     return this.dtaVencTit;
/*     */   }
/*     */   public void setDtaVencTit(String dtaVencTit) {
/* 202 */     this.dtaVencTit = dtaVencTit;
/*     */   }
/*     */   public String getVlrNmlTit() {
/* 205 */     return this.vlrNmlTit;
/*     */   }
/*     */   public void setVlrNmlTit(String vlrNmlTit) {
/* 208 */     this.vlrNmlTit = vlrNmlTit;
/*     */   }
/*     */   public Integer getDscAgeCob() {
/* 211 */     return this.dscAgeCob;
/*     */   }
/*     */   public void setDscAgeCob(Integer dscAgeCob) {
/* 214 */     this.dscAgeCob = dscAgeCob;
/*     */   }
/*     */   public String getDscAgeCobDV() {
/* 217 */     return this.dscAgeCobDV;
/*     */   }
/*     */   public void setDscAgeCobDV(String dscAgeCobDV) {
/* 220 */     this.dscAgeCobDV = dscAgeCobDV;
/*     */   }
/*     */   public String getDscUsoFbrn5() {
/* 223 */     return this.dscUsoFbrn5;
/*     */   }
/*     */   public void setDscUsoFbrn5(String dscUsoFbrn5) {
/* 226 */     this.dscUsoFbrn5 = dscUsoFbrn5;
/*     */   }
/*     */   public String getCodEspTit() {
/* 229 */     return this.codEspTit;
/*     */   }
/*     */   public void setCodEspTit(String codEspTit) {
/* 232 */     this.codEspTit = codEspTit;
/*     */   }
/*     */   public String getDscIdentTit() {
/* 235 */     return this.dscIdentTit;
/*     */   }
/*     */   public void setDscIdentTit(String dscIdentTit) {
/* 238 */     this.dscIdentTit = dscIdentTit;
/*     */   }
/*     */   public String getDtaEmissaoTit() {
/* 241 */     return this.dtaEmissaoTit;
/*     */   }
/*     */   public void setDtaEmissaoTit(String dtaEmissaoTit) {
/* 244 */     this.dtaEmissaoTit = dtaEmissaoTit;
/*     */   }
/*     */   public Integer getCodJuros() {
/* 247 */     return this.codJuros;
/*     */   }
/*     */   public void setCodJuros(Integer codJuros) {
/* 250 */     this.codJuros = codJuros;
/*     */   }
/*     */   public String getDtaJuros() {
/* 253 */     return this.dtaJuros;
/*     */   }
/*     */   public void setDtaJuros(String dtaJuros) {
/* 256 */     this.dtaJuros = dtaJuros;
/*     */   }
/*     */   public String getVlrJuros() {
/* 259 */     return this.vlrJuros;
/*     */   }
/*     */   public void setVlrJuros(String vlrJuros) {
/* 262 */     this.vlrJuros = vlrJuros;
/*     */   }
/*     */   public Integer getCodDesc1() {
/* 265 */     return this.codDesc1;
/*     */   }
/*     */   public void setCodDesc1(Integer codDesc1) {
/* 268 */     this.codDesc1 = codDesc1;
/*     */   }
/*     */   public String getDtaDesc1() {
/* 271 */     return this.dtaDesc1;
/*     */   }
/*     */   public void setDtaDesc1(String dtaDesc1) {
/* 274 */     this.dtaDesc1 = dtaDesc1;
/*     */   }
/*     */   public BigDecimal getVlrPrctConc() {
/* 277 */     return this.vlrPrctConc;
/*     */   }
/*     */   public void setVlrPrctConc(BigDecimal vlrPrctConc) {
/* 280 */     this.vlrPrctConc = vlrPrctConc;
/*     */   }
/*     */   public String getVlrIofRecolhido() {
/* 283 */     return this.vlrIofRecolhido;
/*     */   }
/*     */   public void setVlrIofRecolhido(String vlrIofRecolhido) {
/* 286 */     this.vlrIofRecolhido = vlrIofRecolhido;
/*     */   }
/*     */   public BigDecimal getVlrAbat() {
/* 289 */     return this.vlrAbat;
/*     */   }
/*     */   public void setVlrAbat(BigDecimal vlrAbat) {
/* 292 */     this.vlrAbat = vlrAbat;
/*     */   }
/*     */   public String getDscIdentTitEmp() {
/* 295 */     return this.dscIdentTitEmp;
/*     */   }
/*     */   public void setDscIdentTitEmp(String dscIdentTitEmp) {
/* 298 */     this.dscIdentTitEmp = dscIdentTitEmp;
/*     */   }
/*     */   public Integer getCodProtesto() {
/* 301 */     return this.codProtesto;
/*     */   }
/*     */   public void setCodProtesto(Integer codProtesto) {
/* 304 */     this.codProtesto = codProtesto;
/*     */   }
/*     */   public Integer getNroDiasProt() {
/* 307 */     return this.nroDiasProt;
/*     */   }
/*     */   public void setNroDiasProt(Integer nroDiasProt) {
/* 310 */     this.nroDiasProt = nroDiasProt;
/*     */   }
/*     */   public String getCodBaixa() {
/* 313 */     return this.codBaixa;
/*     */   }
/*     */   public void setCodBaixa(String codBaixa) {
/* 316 */     this.codBaixa = codBaixa;
/*     */   }
/*     */   public String getDscUsoFbrn6() {
/* 319 */     return this.dscUsoFbrn6;
/*     */   }
/*     */   public void setDscUsoFbrn6(String dscUsoFbrn6) {
/* 322 */     this.dscUsoFbrn6 = dscUsoFbrn6;
/*     */   }
/*     */   public String getNroDiasBaixa() {
/* 325 */     return this.nroDiasBaixa;
/*     */   }
/*     */   public void setNroDiasBaixa(String nroDiasBaixa) {
/* 328 */     this.nroDiasBaixa = nroDiasBaixa;
/*     */   }
/*     */   public Integer getCodMoeda() {
/* 331 */     return this.codMoeda;
/*     */   }
/*     */   public void setCodMoeda(Integer codMoeda) {
/* 334 */     this.codMoeda = codMoeda;
/*     */   }
/*     */   public String getDscUsoLivre1() {
/* 337 */     return this.dscUsoLivre1;
/*     */   }
/*     */   public void setDscUsoLivre1(String dscUsoLivre1) {
/* 340 */     this.dscUsoLivre1 = dscUsoLivre1;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\santander\SegmentoP.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */