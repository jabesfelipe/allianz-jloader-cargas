/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout150;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.DateDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.DoubleDecorator;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "F")})
/*     */ public class DetalheF
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1983395699832938946L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private String codRegistro;
/*     */   @PositionalField(initialPosition = 2, finalPosition = 26)
/*     */   private String identClienteEmpresa;
/*     */   @PositionalField(initialPosition = 27, finalPosition = 30)
/*     */   private String agenciaDebito;
/*     */   @PositionalField(initialPosition = 31, finalPosition = 44)
/*     */   private String identClienteBanco;
/*     */   @PositionalField(initialPosition = 45, finalPosition = 52, decorator = DateDecorator.class)
/*     */   private Date dtaVencimentoOuDebito;
/*     */   @PositionalField(initialPosition = 53, finalPosition = 67, decorator = DoubleDecorator.class)
/*     */   private Double vlorOriginalDebitado;
/*     */   @PositionalField(initialPosition = 68, finalPosition = 69)
/*     */   private String codRetorno;
/*     */   @PositionalField(initialPosition = 70, finalPosition = 129)
/*  36 */   private String usoEmpresa = null;
/*     */   @PositionalField(initialPosition = 130, finalPosition = 130)
/*  38 */   private String tpoIdentificacao = null;
/*     */   @PositionalField(initialPosition = 131, finalPosition = 144)
/*  40 */   private String iden = null;
/*     */   @PositionalField(initialPosition = 145, finalPosition = 149)
/*  42 */   private String usoFuturo = null;
/*     */   @PositionalField(initialPosition = 150, finalPosition = 150)
/*  44 */   private String codMovimento = null;
/*     */ 
/*     */   
/*     */   public String getCodRegistro() {
/*  48 */     return this.codRegistro;
/*     */   }
/*     */   public void setCodRegistro(String codRegistro) {
/*  51 */     this.codRegistro = codRegistro;
/*     */   }
/*     */   public String getIdentClienteEmpresa() {
/*  54 */     return this.identClienteEmpresa;
/*     */   }
/*     */   public void setIdentClienteEmpresa(String identClienteEmpresa) {
/*  57 */     this.identClienteEmpresa = identClienteEmpresa;
/*     */   }
/*     */   public String getAgenciaDebito() {
/*  60 */     return this.agenciaDebito;
/*     */   }
/*     */   public void setAgenciaDebito(String agenciaDebito) {
/*  63 */     this.agenciaDebito = agenciaDebito;
/*     */   }
/*     */   public String getIdentClienteBanco() {
/*  66 */     return this.identClienteBanco;
/*     */   }
/*     */   public void setIdentClienteBanco(String identClienteBanco) {
/*  69 */     this.identClienteBanco = identClienteBanco;
/*     */   }
/*     */   public Date getDtaVencimentoOuDebito() {
/*  72 */     return this.dtaVencimentoOuDebito;
/*     */   }
/*     */   public void setDtaVencimentoOuDebito(Date dtaVencimentoOuDebito) {
/*  75 */     this.dtaVencimentoOuDebito = dtaVencimentoOuDebito;
/*     */   }
/*     */   public Double getVlorOriginalDebitado() {
/*  78 */     return this.vlorOriginalDebitado;
/*     */   }
/*     */   public void setVlorOriginalDebitado(Double vlorOriginalDebitado) {
/*  81 */     this.vlorOriginalDebitado = vlorOriginalDebitado;
/*     */   }
/*     */   public String getCodRetorno() {
/*  84 */     return this.codRetorno;
/*     */   }
/*     */   public void setCodRetorno(String codRetorno) {
/*  87 */     this.codRetorno = codRetorno;
/*     */   }
/*     */   public String getUsoEmpresa() {
/*  90 */     return this.usoEmpresa;
/*     */   }
/*     */   public void setUsoEmpresa(String usoEmpresa) {
/*  93 */     this.usoEmpresa = usoEmpresa;
/*     */   }
/*     */   public String getUsoFuturo() {
/*  96 */     return this.usoFuturo;
/*     */   }
/*     */   public void setUsoFuturo(String usoFuturo) {
/*  99 */     this.usoFuturo = usoFuturo;
/*     */   }
/*     */   public String getTpoIdentificacao() {
/* 102 */     return this.tpoIdentificacao;
/*     */   }
/*     */   public void setTpoIdentificacao(String tpoIdentificacao) {
/* 105 */     this.tpoIdentificacao = tpoIdentificacao;
/*     */   }
/*     */   public String getIden() {
/* 108 */     return this.iden;
/*     */   }
/*     */   public void setIden(String iden) {
/* 111 */     this.iden = iden;
/*     */   }
/*     */   public String getCodMovimento() {
/* 114 */     return this.codMovimento;
/*     */   }
/*     */   public void setCodMovimento(String codMovimento) {
/* 117 */     this.codMovimento = codMovimento;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout150\DetalheF.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */