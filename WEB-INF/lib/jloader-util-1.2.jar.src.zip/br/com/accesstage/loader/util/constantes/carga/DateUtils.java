/*     */ package br.com.accesstage.loader.util.constantes.carga;
/*     */ 
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateUtils
/*     */ {
/*  17 */   private static DateFormat formatterSql = new SimpleDateFormat("yyyy-MM-dd");
/*     */   
/*  19 */   private static DateFormat formatterSql2 = new SimpleDateFormat("yyyyMMdd");
/*     */   
/*  21 */   private static DateFormat formatterDateJsp = new SimpleDateFormat("dd/MM/yyyy");
/*     */   
/*  23 */   private static DateFormat formatterHourJsp = new SimpleDateFormat("HH:mm");
/*     */   
/*  25 */   private static DateFormat formatterDateHourJsp = new SimpleDateFormat("dd/MM/yyyy HH:mm");
/*     */   
/*  27 */   private static DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
/*     */   
/*  29 */   private static DateFormat formatterComplete = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
/*     */   
/*  31 */   private static DateFormat formatterDateHour = new SimpleDateFormat("dd/MM/yyyy HH:mm");
/*     */   
/*  33 */   private static DateFormat formatterDateHourFile = new SimpleDateFormat("yyyyMMddHHmmss");
/*     */   
/*  35 */   private static DateFormat formatterDateHourFile3 = new SimpleDateFormat("yyyyMMddHHmm");
/*     */   
/*  37 */   private static DateFormat formatterDateHourFile2 = new SimpleDateFormat("ddMMyyyyHHmmss");
/*     */   
/*  39 */   private static DateFormat formatterDateFile = new SimpleDateFormat("ddMMyyyy");
/*     */   
/*  41 */   private static DateFormat formatterDateFile2 = new SimpleDateFormat("MMddyyyy");
/*     */   
/*  43 */   private static DateFormat formatterDateFileInverso = new SimpleDateFormat("yyyyMMdd");
/*     */   
/*  45 */   private static DateFormat formatterDateFile6DigInverso = new SimpleDateFormat("yyMMdd");
/*     */   
/*  47 */   private static DateFormat formatterDateFile6Dig = new SimpleDateFormat("ddMMyy");
/*     */   
/*  49 */   private static DateFormat formatterDateMMYYYY = new SimpleDateFormat("MMyyyy");
/*     */   
/*  51 */   private static DateFormat formatterDateYYYYMM = new SimpleDateFormat("yyyyMM");
/*     */   
/*     */   public static Date parseDateHourFile2(String dateHourStr) throws ParseException {
/*  54 */     synchronized (formatterDateHourFile2) {
/*  55 */       formatterDateHourFile2.setLenient(false);
/*  56 */       return (dateHourStr == null) ? null : formatterDateHourFile2.parse(dateHourStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFile(String dateStr) throws ParseException {
/*  61 */     synchronized (formatterDateFile) {
/*  62 */       formatterDateFile.setLenient(false);
/*  63 */       return (dateStr == null) ? null : formatterDateFile.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFile2(String dateStr) throws ParseException {
/*  68 */     synchronized (formatterDateFile2) {
/*  69 */       formatterDateFile2.setLenient(false);
/*  70 */       return (dateStr == null) ? null : formatterDateFile2.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFileInverso(String dateStr) throws ParseException {
/*  75 */     synchronized (formatterDateFileInverso) {
/*  76 */       formatterDateFileInverso.setLenient(false);
/*  77 */       return (dateStr == null) ? null : formatterDateFileInverso.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFileInversoCompleto(String dateStr) throws ParseException {
/*  82 */     synchronized (formatterDateHourFile) {
/*  83 */       formatterDateHourFile.setLenient(false);
/*  84 */       return (dateStr == null) ? null : formatterDateHourFile.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFileInversoCompleto2(String dateStr) throws ParseException {
/*  89 */     synchronized (formatterDateHourFile3) {
/*  90 */       formatterDateHourFile3.setLenient(false);
/*  91 */       return (dateStr == null) ? null : formatterDateHourFile3.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFile6DigInverso(String dateStr) throws ParseException {
/*  96 */     synchronized (formatterDateFile6DigInverso) {
/*  97 */       formatterDateFile6DigInverso.setLenient(false);
/*  98 */       return (dateStr == null) ? null : formatterDateFile6DigInverso.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFile6Dig(String dateStr) throws ParseException {
/* 103 */     synchronized (formatterDateFile6Dig) {
/* 104 */       formatterDateFile6Dig.setLenient(false);
/* 105 */       return (dateStr == null) ? null : formatterDateFile6Dig.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFileYYYYMM(String dateStr) throws ParseException {
/* 110 */     synchronized (formatterDateYYYYMM) {
/* 111 */       formatterDateYYYYMM.setLenient(false);
/* 112 */       return (dateStr == null) ? null : formatterDateYYYYMM.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateFileMMYYYY(String dateStr) throws ParseException {
/* 117 */     synchronized (formatterDateMMYYYY) {
/* 118 */       formatterDateMMYYYY.setLenient(false);
/* 119 */       return (dateStr == null) ? null : formatterDateMMYYYY.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDate(String dateStr) throws ParseException {
/* 124 */     synchronized (formatter) {
/* 125 */       return (dateStr == null) ? null : formatter.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateJsp(String dateStr) throws ParseException {
/* 130 */     synchronized (formatterDateJsp) {
/* 131 */       return (dateStr == null) ? null : formatterDateJsp.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseHourJsp(String dateStr) throws ParseException {
/* 136 */     synchronized (formatterHourJsp) {
/* 137 */       return (dateStr == null) ? null : formatterHourJsp.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateHourJsp(String dateStr) throws ParseException {
/* 142 */     synchronized (formatterDateHourJsp) {
/* 143 */       return (dateStr == null) ? null : formatterDateHourJsp.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateSql(String dateStr) throws ParseException {
/* 148 */     synchronized (formatterSql) {
/* 149 */       return (dateStr == null) ? null : formatterSql.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date formatDateSql2(String dateStr) throws ParseException {
/* 154 */     synchronized (formatterSql2) {
/* 155 */       return (dateStr == null) ? null : formatterSql2.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date parseDateHour(String dateStr) throws ParseException {
/* 160 */     synchronized (formatterDateHour) {
/* 161 */       return (dateStr == null) ? null : formatterDateHour.parse(dateStr);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDateFile(Date date) {
/* 166 */     synchronized (formatterDateFile) {
/* 167 */       return (date == null) ? null : formatterDateFile.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDateHourFile2(Date date) {
/* 172 */     synchronized (formatterDateHourFile2) {
/* 173 */       return (date == null) ? null : formatterDateHourFile2.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDate(Date date) {
/* 178 */     synchronized (formatterComplete) {
/* 179 */       return (date == null) ? null : formatterComplete.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDateJsp(Date date) {
/* 184 */     synchronized (formatterDateJsp) {
/* 185 */       return (date == null) ? null : formatterDateJsp.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatHourJsp(Date date) {
/* 190 */     synchronized (formatterHourJsp) {
/* 191 */       return (date == null) ? null : formatterHourJsp.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDateHourJsp(Date date) {
/* 196 */     synchronized (formatterDateHourJsp) {
/* 197 */       return (date == null) ? null : formatterDateHourJsp.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDateSql(Date date) {
/* 202 */     synchronized (formatterSql) {
/* 203 */       return (date == null) ? null : formatterSql.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDateSql2(Date date) {
/* 208 */     synchronized (formatterSql2) {
/* 209 */       return (date == null) ? null : formatterSql2.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDateSimple(Date date) {
/* 214 */     synchronized (formatter) {
/* 215 */       return (date == null) ? null : formatter.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatDateHourFile(Date date) {
/* 220 */     synchronized (formatterDateHourFile) {
/* 221 */       return (date == null) ? null : formatterDateHourFile.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Date getDate(Timestamp date) {
/* 226 */     return (date == null) ? null : new Date(date.getTime());
/*     */   }
/*     */   
/*     */   public static Date getDate(Date date) {
/* 230 */     return (date == null) ? null : new Date(date.getTime());
/*     */   }
/*     */   
/*     */   public static Date getSQLDate(Date date) {
/* 234 */     return (date == null) ? null : new Date(date.getTime());
/*     */   }
/*     */   
/*     */   public static Timestamp getSQLTimestamp(Date date) {
/* 238 */     return (date == null) ? null : new Timestamp(date.getTime());
/*     */   }
/*     */   
/*     */   public static String formatDateHour(Date date) {
/* 242 */     synchronized (formatterDateHour) {
/* 243 */       return (date == null) ? null : formatterDateHour.format(date);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String codMesRefCarga() {
/* 248 */     String codMesRefCarga = (new SimpleDateFormat("yyyyMM")).format(new Date());
/* 249 */     return codMesRefCarga;
/*     */   }
/*     */   
/*     */   public static boolean validaData8Digitos(String data) {
/* 253 */     return (data != null && !"".equals(data.trim()) && !"00000000".equals(data.trim()));
/*     */   }
/*     */   
/*     */   public static boolean validaData6Digitos(String data) {
/* 257 */     return (data != null && !"".equals(data.trim()) && !"000000".equals(data.trim()));
/*     */   }
/*     */   
/*     */   public static boolean validaData14Digitos(String data) {
/* 261 */     return (data != null && !"".equals(data.trim()) && !"00000000000000".equals(data.trim()));
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\carga\DateUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */