/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoA
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -489927538271121376L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBanco;
/*     */   @LongPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Long loteServico;
/*     */   @LongPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Long tpoRegistro;
/*     */   @LongPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Long nroSeqLote;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSeguimentoDetalhe;
/*     */   @LongPositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private Long tpoMovimento;
/*     */   @LongPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Long codInstMov;
/*     */   @LongPositionalField(initialPosition = 18, finalPosition = 20)
/*     */   private Long codCamaraCent;
/*     */   @LongPositionalField(initialPosition = 21, finalPosition = 23)
/*     */   private Long codBancoFavorecido;
/*     */   @LongPositionalField(initialPosition = 24, finalPosition = 28)
/*     */   private Long agMantenedora;
/*     */   @PositionalField(initialPosition = 29, finalPosition = 29)
/*     */   private String digAg;
/*     */   @PositionalField(initialPosition = 30, finalPosition = 41)
/*     */   private String nroCcStr;
/*     */   @PositionalField(initialPosition = 42, finalPosition = 42)
/*     */   private String nroDigCc;
/*     */   @PositionalField(initialPosition = 43, finalPosition = 43)
/*     */   private String nroDigAgCc;
/*     */   @PositionalField(initialPosition = 44, finalPosition = 73)
/*     */   private String nmeFavorecido;
/*     */   @PositionalField(initialPosition = 74, finalPosition = 93)
/*     */   private String nroDocEmpresa;
/*     */   @PositionalField(initialPosition = 94, finalPosition = 101)
/*     */   private String dtaPgtoStr;
/*     */   @PositionalField(initialPosition = 102, finalPosition = 104)
/*     */   private String tpoMoeda;
/*     */   @LongPositionalField(initialPosition = 105, finalPosition = 119)
/*     */   private Long qtdMoeda;
/*     */   @LongPositionalField(initialPosition = 120, finalPosition = 134)
/*     */   private Long vlrPgto;
/*     */   @PositionalField(initialPosition = 135, finalPosition = 154)
/*     */   private String nroDocBanco;
/*     */   @PositionalField(initialPosition = 155, finalPosition = 162)
/*     */   private String dtaEfetivacaoStr;
/*     */   @LongPositionalField(initialPosition = 163, finalPosition = 177)
/*     */   private Long vlrEfetivacao;
/*     */   @PositionalField(initialPosition = 178, finalPosition = 217)
/*     */   private String dscInfo;
/*     */   @PositionalField(initialPosition = 218, finalPosition = 219)
/*     */   private String codFinalidadeDoc;
/*     */   @PositionalField(initialPosition = 220, finalPosition = 224)
/*     */   private String codFinalidadeTed;
/*     */   @PositionalField(initialPosition = 225, finalPosition = 226)
/*     */   private String codFinalidadePgto;
/*     */   @PositionalField(initialPosition = 227, finalPosition = 229)
/*     */   private String dscCnab;
/*     */   @LongPositionalField(initialPosition = 230, finalPosition = 230)
/*     */   private Long dscAviso;
/*     */   @PositionalField(initialPosition = 231, finalPosition = 240)
/*     */   private String dscOcorrencia;
/*     */   
/*     */   public String getCodBanco() {
/*  80 */     return this.codBanco;
/*     */   }
/*     */   public void setCodBanco(String codBanco) {
/*  83 */     this.codBanco = codBanco;
/*     */   }
/*     */   public Long getLoteServico() {
/*  86 */     return this.loteServico;
/*     */   }
/*     */   public void setLoteServico(Long loteServico) {
/*  89 */     this.loteServico = loteServico;
/*     */   }
/*     */   public Long getTpoRegistro() {
/*  92 */     return this.tpoRegistro;
/*     */   }
/*     */   public void setTpoRegistro(Long tpoRegistro) {
/*  95 */     this.tpoRegistro = tpoRegistro;
/*     */   }
/*     */   public Long getNroSeqLote() {
/*  98 */     return this.nroSeqLote;
/*     */   }
/*     */   public void setNroSeqLote(Long nroSeqLote) {
/* 101 */     this.nroSeqLote = nroSeqLote;
/*     */   }
/*     */   public String getCodSeguimentoDetalhe() {
/* 104 */     return this.codSeguimentoDetalhe;
/*     */   }
/*     */   public void setCodSeguimentoDetalhe(String codSeguimentoDetalhe) {
/* 107 */     this.codSeguimentoDetalhe = codSeguimentoDetalhe;
/*     */   }
/*     */   public Long getTpoMovimento() {
/* 110 */     return this.tpoMovimento;
/*     */   }
/*     */   public void setTpoMovimento(Long tpoMovimento) {
/* 113 */     this.tpoMovimento = tpoMovimento;
/*     */   }
/*     */   public Long getCodInstMov() {
/* 116 */     return this.codInstMov;
/*     */   }
/*     */   public void setCodInstMov(Long codInstMov) {
/* 119 */     this.codInstMov = codInstMov;
/*     */   }
/*     */   public Long getCodCamaraCent() {
/* 122 */     return this.codCamaraCent;
/*     */   }
/*     */   public void setCodCamaraCent(Long codCamaraCent) {
/* 125 */     this.codCamaraCent = codCamaraCent;
/*     */   }
/*     */   public Long getCodBancoFavorecido() {
/* 128 */     return this.codBancoFavorecido;
/*     */   }
/*     */   public void setCodBancoFavorecido(Long codBancoFavorecido) {
/* 131 */     this.codBancoFavorecido = codBancoFavorecido;
/*     */   }
/*     */   public Long getAgMantenedora() {
/* 134 */     return this.agMantenedora;
/*     */   }
/*     */   public void setAgMantenedora(Long agMantenedora) {
/* 137 */     this.agMantenedora = agMantenedora;
/*     */   }
/*     */   public String getDigAg() {
/* 140 */     return this.digAg;
/*     */   }
/*     */   public void setDigAg(String digAg) {
/* 143 */     this.digAg = digAg;
/*     */   }
/*     */   public String getNroCcStr() {
/* 146 */     return this.nroCcStr;
/*     */   }
/*     */   public void setNroCcStr(String nroCcStr) {
/* 149 */     this.nroCcStr = nroCcStr;
/*     */   }
/*     */   public String getNroDigCc() {
/* 152 */     return this.nroDigCc;
/*     */   }
/*     */   public void setNroDigCc(String nroDigCc) {
/* 155 */     this.nroDigCc = nroDigCc;
/*     */   }
/*     */   public String getNroDigAgCc() {
/* 158 */     return this.nroDigAgCc;
/*     */   }
/*     */   public void setNroDigAgCc(String nroDigAgCc) {
/* 161 */     this.nroDigAgCc = nroDigAgCc;
/*     */   }
/*     */   public String getNmeFavorecido() {
/* 164 */     return this.nmeFavorecido;
/*     */   }
/*     */   public void setNmeFavorecido(String nmeFavorecido) {
/* 167 */     this.nmeFavorecido = nmeFavorecido;
/*     */   }
/*     */   public String getNroDocEmpresa() {
/* 170 */     return this.nroDocEmpresa;
/*     */   }
/*     */   public void setNroDocEmpresa(String nroDocEmpresa) {
/* 173 */     this.nroDocEmpresa = nroDocEmpresa;
/*     */   }
/*     */   public String getDtaPgtoStr() {
/* 176 */     return this.dtaPgtoStr;
/*     */   }
/*     */   public void setDtaPgtoStr(String dtaPgtoStr) {
/* 179 */     this.dtaPgtoStr = dtaPgtoStr;
/*     */   }
/*     */   public String getTpoMoeda() {
/* 182 */     return this.tpoMoeda;
/*     */   }
/*     */   public void setTpoMoeda(String tpoMoeda) {
/* 185 */     this.tpoMoeda = tpoMoeda;
/*     */   }
/*     */   public Long getQtdMoeda() {
/* 188 */     return this.qtdMoeda;
/*     */   }
/*     */   public void setQtdMoeda(Long qtdMoeda) {
/* 191 */     this.qtdMoeda = qtdMoeda;
/*     */   }
/*     */   public Long getVlrPgto() {
/* 194 */     return this.vlrPgto;
/*     */   }
/*     */   public void setVlrPgto(Long vlrPgto) {
/* 197 */     this.vlrPgto = vlrPgto;
/*     */   }
/*     */   public String getNroDocBanco() {
/* 200 */     return this.nroDocBanco;
/*     */   }
/*     */   public void setNroDocBanco(String nroDocBanco) {
/* 203 */     this.nroDocBanco = nroDocBanco;
/*     */   }
/*     */   public String getDtaEfetivacaoStr() {
/* 206 */     return this.dtaEfetivacaoStr;
/*     */   }
/*     */   public void setDtaEfetivacaoStr(String dtaEfetivacaoStr) {
/* 209 */     this.dtaEfetivacaoStr = dtaEfetivacaoStr;
/*     */   }
/*     */   public Long getVlrEfetivacao() {
/* 212 */     return this.vlrEfetivacao;
/*     */   }
/*     */   public void setVlrEfetivacao(Long vlrEfetivacao) {
/* 215 */     this.vlrEfetivacao = vlrEfetivacao;
/*     */   }
/*     */   public String getDscInfo() {
/* 218 */     return this.dscInfo;
/*     */   }
/*     */   public void setDscInfo(String dscInfo) {
/* 221 */     this.dscInfo = dscInfo;
/*     */   }
/*     */   public String getCodFinalidadeDoc() {
/* 224 */     return this.codFinalidadeDoc;
/*     */   }
/*     */   public void setCodFinalidadeDoc(String codFinalidadeDoc) {
/* 227 */     this.codFinalidadeDoc = codFinalidadeDoc;
/*     */   }
/*     */   public String getCodFinalidadeTed() {
/* 230 */     return this.codFinalidadeTed;
/*     */   }
/*     */   public void setCodFinalidadeTed(String codFinalidadeTed) {
/* 233 */     this.codFinalidadeTed = codFinalidadeTed;
/*     */   }
/*     */   public String getCodFinalidadePgto() {
/* 236 */     return this.codFinalidadePgto;
/*     */   }
/*     */   public void setCodFinalidadePgto(String codFinalidadePgto) {
/* 239 */     this.codFinalidadePgto = codFinalidadePgto;
/*     */   }
/*     */   public String getDscCnab() {
/* 242 */     return this.dscCnab;
/*     */   }
/*     */   public void setDscCnab(String dscCnab) {
/* 245 */     this.dscCnab = dscCnab;
/*     */   }
/*     */   public Long getDscAviso() {
/* 248 */     return this.dscAviso;
/*     */   }
/*     */   public void setDscAviso(Long dscAviso) {
/* 251 */     this.dscAviso = dscAviso;
/*     */   }
/*     */   public String getDscOcorrencia() {
/* 254 */     return this.dscOcorrencia;
/*     */   }
/*     */   public void setDscOcorrencia(String dscOcorrencia) {
/* 257 */     this.dscOcorrencia = dscOcorrencia;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoA.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */