/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout500.retorno;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.volkswagen.decorator.DateDecorator_YYYYMMDD;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.DatePositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Detalhe
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @IntegerPositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private Integer identRegistro;
/*     */   @IntegerPositionalField(initialPosition = 2, finalPosition = 2)
/*     */   private Integer tipoInscricao;
/*     */   @PositionalField(initialPosition = 3, finalPosition = 17)
/*     */   private String nroDocumento;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 47)
/*     */   private String nomeFornecedor;
/*     */   @PositionalField(initialPosition = 48, finalPosition = 87)
/*     */   private String enderecoFornecedor;
/*     */   @PositionalField(initialPosition = 88, finalPosition = 95)
/*     */   private String cepFornecedor;
/*     */   @IntegerPositionalField(initialPosition = 96, finalPosition = 98)
/*     */   private Integer codigoBancoFornecedor;
/*     */   @IntegerPositionalField(initialPosition = 99, finalPosition = 103)
/*     */   private Integer agenciaFornecedor;
/*     */   @PositionalField(initialPosition = 104, finalPosition = 104)
/*     */   private String digitoFornecedor;
/*     */   @IntegerPositionalField(initialPosition = 105, finalPosition = 117)
/*     */   private Integer contaCorrenteFornecedor;
/*     */   @PositionalField(initialPosition = 118, finalPosition = 119)
/*     */   private String digitoContaCorrenteFornecedor;
/*     */   @PositionalField(initialPosition = 120, finalPosition = 135)
/*     */   private String numeroPagamento;
/*     */   @IntegerPositionalField(initialPosition = 136, finalPosition = 138)
/*     */   private Integer carteira;
/*     */   @IntegerPositionalField(initialPosition = 139, finalPosition = 150)
/*     */   private Integer nossoNumero;
/*     */   @IntegerPositionalField(initialPosition = 151, finalPosition = 165)
/*     */   private Integer seuNumero;
/*     */   @DatePositionalField(dateFormat = "yyyyMMdd", initialPosition = 166, finalPosition = 173)
/*     */   private Date dataVencimento;
/*     */   @DatePositionalField(dateFormat = "yyyyMMdd", initialPosition = 174, finalPosition = 181)
/*     */   private Date dataEmissaoDocumento;
/*     */   @PositionalField(initialPosition = 182, finalPosition = 189, decorator = DateDecorator_YYYYMMDD.class)
/*     */   private Date dataLimiteDesconto;
/*     */   @IntegerPositionalField(initialPosition = 190, finalPosition = 190)
/*     */   private Integer zero;
/*     */   @IntegerPositionalField(initialPosition = 191, finalPosition = 194)
/*     */   private Integer fatorVencimento;
/*     */   @LongPositionalField(initialPosition = 195, finalPosition = 204)
/*     */   private Long valorDocumento;
/*     */   @LongPositionalField(initialPosition = 205, finalPosition = 219)
/*     */   private Long valorPagamento;
/*     */   @LongPositionalField(initialPosition = 220, finalPosition = 234)
/*     */   private Long valorDesconto;
/*     */   @LongPositionalField(initialPosition = 235, finalPosition = 249)
/*     */   private Long valorAcrescimo;
/*     */   @IntegerPositionalField(initialPosition = 250, finalPosition = 251)
/*     */   private Integer tipoDocumento;
/*     */   @PositionalField(initialPosition = 252, finalPosition = 261)
/*     */   private String numeroNotaFiscal;
/*     */   @PositionalField(initialPosition = 262, finalPosition = 263)
/*     */   private String serieDocumento;
/*     */   @PositionalField(initialPosition = 264, finalPosition = 265)
/*     */   private String modalidadePagamento;
/*     */   @DatePositionalField(dateFormat = "yyyyMMdd", initialPosition = 266, finalPosition = 273)
/*     */   private Date dataEfetivacao;
/*     */   @PositionalField(initialPosition = 274, finalPosition = 276)
/*     */   private String moeda;
/*     */   @PositionalField(initialPosition = 277, finalPosition = 278)
/*     */   private String situacaoAgendamento;
/*     */   @PositionalField(initialPosition = 279, finalPosition = 280)
/*     */   private String informacaoRetorno1;
/*     */   @PositionalField(initialPosition = 281, finalPosition = 282)
/*     */   private String informacaoRetorno2;
/*     */   @PositionalField(initialPosition = 283, finalPosition = 284)
/*     */   private String informacaoRetorno3;
/*     */   @PositionalField(initialPosition = 285, finalPosition = 286)
/*     */   private String informacaoRetorno4;
/*     */   @PositionalField(initialPosition = 287, finalPosition = 288)
/*     */   private String informacaoRetorno5;
/*     */   @IntegerPositionalField(initialPosition = 289, finalPosition = 289)
/*     */   private Integer tipoMovimento;
/*     */   @IntegerPositionalField(initialPosition = 290, finalPosition = 291)
/*     */   private Integer codigoMovimento;
/*     */   @IntegerPositionalField(initialPosition = 292, finalPosition = 295)
/*     */   private Integer horarioConsultaSaldo;
/*     */   @LongPositionalField(initialPosition = 296, finalPosition = 310)
/*     */   private Long saldoDisponivelSaldo;
/*     */   @LongPositionalField(initialPosition = 311, finalPosition = 325)
/*     */   private Long valorTaxaPreFunding;
/*     */   @PositionalField(initialPosition = 326, finalPosition = 331)
/*     */   private String reserva;
/*     */   @PositionalField(initialPosition = 332, finalPosition = 371)
/*     */   private String sacadorAvalista;
/*     */   @PositionalField(initialPosition = 372, finalPosition = 372)
/*     */   private String reserva2;
/*     */   @PositionalField(initialPosition = 373, finalPosition = 373)
/*     */   private String nivelInfoRetorno;
/*     */   @PositionalField(initialPosition = 374, finalPosition = 413)
/*     */   private String informacoesComplementares;
/*     */   @IntegerPositionalField(initialPosition = 414, finalPosition = 415)
/*     */   private Integer codigoAreaEmpresa;
/*     */   @PositionalField(initialPosition = 416, finalPosition = 450)
/*     */   private String campoUsoEmpresa;
/*     */   @PositionalField(initialPosition = 451, finalPosition = 472)
/*     */   private String reserva3;
/*     */   @IntegerPositionalField(initialPosition = 473, finalPosition = 477)
/*     */   private Integer codigoLancamento;
/*     */   @PositionalField(initialPosition = 478, finalPosition = 478)
/*     */   private String reserva4;
/*     */   @IntegerPositionalField(initialPosition = 479, finalPosition = 479)
/*     */   private Integer tipoContaFornecedor;
/*     */   @PositionalField(initialPosition = 480, finalPosition = 486)
/*     */   private String contaComplementar;
/*     */   @PositionalField(initialPosition = 487, finalPosition = 494)
/*     */   private String reserva5;
/*     */   @IntegerPositionalField(initialPosition = 495, finalPosition = 500)
/*     */   private Integer numeroSequencial;
/*     */   
/*     */   public Integer getIdentRegistro() {
/* 134 */     return this.identRegistro;
/*     */   }
/*     */   public void setIdentRegistro(Integer identRegistro) {
/* 137 */     this.identRegistro = identRegistro;
/*     */   }
/*     */   public Integer getTipoInscricao() {
/* 140 */     return this.tipoInscricao;
/*     */   }
/*     */   public void setTipoInscricao(Integer tipoInscricao) {
/* 143 */     this.tipoInscricao = tipoInscricao;
/*     */   }
/*     */   public String getNroDocumento() {
/* 146 */     return this.nroDocumento;
/*     */   }
/*     */   public void setNroDocumento(String nroDocumento) {
/* 149 */     this.nroDocumento = nroDocumento;
/*     */   }
/*     */   public String getNomeFornecedor() {
/* 152 */     return this.nomeFornecedor;
/*     */   }
/*     */   public void setNomeFornecedor(String nomeFornecedor) {
/* 155 */     this.nomeFornecedor = nomeFornecedor;
/*     */   }
/*     */   public String getEnderecoFornecedor() {
/* 158 */     return this.enderecoFornecedor;
/*     */   }
/*     */   public void setEnderecoFornecedor(String enderecoFornecedor) {
/* 161 */     this.enderecoFornecedor = enderecoFornecedor;
/*     */   }
/*     */   public String getCepFornecedor() {
/* 164 */     return this.cepFornecedor;
/*     */   }
/*     */   public void setCepFornecedor(String cepFornecedor) {
/* 167 */     this.cepFornecedor = cepFornecedor;
/*     */   }
/*     */   public Integer getCodigoBancoFornecedor() {
/* 170 */     return this.codigoBancoFornecedor;
/*     */   }
/*     */   public void setCodigoBancoFornecedor(Integer codigoBancoFornecedor) {
/* 173 */     this.codigoBancoFornecedor = codigoBancoFornecedor;
/*     */   }
/*     */   public Integer getAgenciaFornecedor() {
/* 176 */     return this.agenciaFornecedor;
/*     */   }
/*     */   public void setAgenciaFornecedor(Integer agenciaFornecedor) {
/* 179 */     this.agenciaFornecedor = agenciaFornecedor;
/*     */   }
/*     */   public String getDigitoFornecedor() {
/* 182 */     return this.digitoFornecedor;
/*     */   }
/*     */   public void setDigitoFornecedor(String digitoFornecedor) {
/* 185 */     this.digitoFornecedor = digitoFornecedor;
/*     */   }
/*     */   public Integer getContaCorrenteFornecedor() {
/* 188 */     return this.contaCorrenteFornecedor;
/*     */   }
/*     */   public void setContaCorrenteFornecedor(Integer contaCorrenteFornecedor) {
/* 191 */     this.contaCorrenteFornecedor = contaCorrenteFornecedor;
/*     */   }
/*     */   public String getDigitoContaCorrenteFornecedor() {
/* 194 */     return this.digitoContaCorrenteFornecedor;
/*     */   }
/*     */   public void setDigitoContaCorrenteFornecedor(String digitoContaCorrenteFornecedor) {
/* 197 */     this.digitoContaCorrenteFornecedor = digitoContaCorrenteFornecedor;
/*     */   }
/*     */   public String getNumeroPagamento() {
/* 200 */     return this.numeroPagamento;
/*     */   }
/*     */   public void setNumeroPagamento(String numeroPagamento) {
/* 203 */     this.numeroPagamento = numeroPagamento;
/*     */   }
/*     */   public Integer getCarteira() {
/* 206 */     return this.carteira;
/*     */   }
/*     */   public void setCarteira(Integer carteira) {
/* 209 */     this.carteira = carteira;
/*     */   }
/*     */   public Integer getNossoNumero() {
/* 212 */     return this.nossoNumero;
/*     */   }
/*     */   public void setNossoNumero(Integer nossoNumero) {
/* 215 */     this.nossoNumero = nossoNumero;
/*     */   }
/*     */   public Integer getSeuNumero() {
/* 218 */     return this.seuNumero;
/*     */   }
/*     */   public void setSeuNumero(Integer seuNumero) {
/* 221 */     this.seuNumero = seuNumero;
/*     */   }
/*     */   public Date getDataVencimento() {
/* 224 */     return this.dataVencimento;
/*     */   }
/*     */   public void setDataVencimento(Date dataVencimento) {
/* 227 */     this.dataVencimento = dataVencimento;
/*     */   }
/*     */   public Date getDataEmissaoDocumento() {
/* 230 */     return this.dataEmissaoDocumento;
/*     */   }
/*     */   public void setDataEmissaoDocumento(Date dataEmissaoDocumento) {
/* 233 */     this.dataEmissaoDocumento = dataEmissaoDocumento;
/*     */   }
/*     */   public Date getDataLimiteDesconto() {
/* 236 */     return this.dataLimiteDesconto;
/*     */   }
/*     */   public void setDataLimiteDesconto(Date dataLimiteDesconto) {
/* 239 */     this.dataLimiteDesconto = dataLimiteDesconto;
/*     */   }
/*     */   public Integer getZero() {
/* 242 */     return this.zero;
/*     */   }
/*     */   public void setZero(Integer zero) {
/* 245 */     this.zero = zero;
/*     */   }
/*     */   public Integer getFatorVencimento() {
/* 248 */     return this.fatorVencimento;
/*     */   }
/*     */   public void setFatorVencimento(Integer fatorVencimento) {
/* 251 */     this.fatorVencimento = fatorVencimento;
/*     */   }
/*     */   public Long getValorDocumento() {
/* 254 */     return this.valorDocumento;
/*     */   }
/*     */   public void setValorDocumento(Long valorDocumento) {
/* 257 */     this.valorDocumento = valorDocumento;
/*     */   }
/*     */   public Long getValorPagamento() {
/* 260 */     return this.valorPagamento;
/*     */   }
/*     */   public void setValorPagamento(Long valorPagamento) {
/* 263 */     this.valorPagamento = valorPagamento;
/*     */   }
/*     */   public Long getValorDesconto() {
/* 266 */     return this.valorDesconto;
/*     */   }
/*     */   public void setValorDesconto(Long valorDesconto) {
/* 269 */     this.valorDesconto = valorDesconto;
/*     */   }
/*     */   public Long getValorAcrescimo() {
/* 272 */     return this.valorAcrescimo;
/*     */   }
/*     */   public void setValorAcrescimo(Long valorAcrescimo) {
/* 275 */     this.valorAcrescimo = valorAcrescimo;
/*     */   }
/*     */   public Integer getTipoDocumento() {
/* 278 */     return this.tipoDocumento;
/*     */   }
/*     */   public void setTipoDocumento(Integer tipoDocumento) {
/* 281 */     this.tipoDocumento = tipoDocumento;
/*     */   }
/*     */   public String getNumeroNotaFiscal() {
/* 284 */     return this.numeroNotaFiscal;
/*     */   }
/*     */   public void setNumeroNotaFiscal(String numeroNotaFiscal) {
/* 287 */     this.numeroNotaFiscal = numeroNotaFiscal;
/*     */   }
/*     */   public String getSerieDocumento() {
/* 290 */     return this.serieDocumento;
/*     */   }
/*     */   public void setSerieDocumento(String serieDocumento) {
/* 293 */     this.serieDocumento = serieDocumento;
/*     */   }
/*     */   public String getModalidadePagamento() {
/* 296 */     return this.modalidadePagamento;
/*     */   }
/*     */   public void setModalidadePagamento(String modalidadePagamento) {
/* 299 */     this.modalidadePagamento = modalidadePagamento;
/*     */   }
/*     */   public Date getDataEfetivacao() {
/* 302 */     return this.dataEfetivacao;
/*     */   }
/*     */   public void setDataEfetivacao(Date dataEfetivacao) {
/* 305 */     this.dataEfetivacao = dataEfetivacao;
/*     */   }
/*     */   public String getMoeda() {
/* 308 */     return this.moeda;
/*     */   }
/*     */   public void setMoeda(String moeda) {
/* 311 */     this.moeda = moeda;
/*     */   }
/*     */   public String getSituacaoAgendamento() {
/* 314 */     return this.situacaoAgendamento;
/*     */   }
/*     */   public void setSituacaoAgendamento(String situacaoAgendamento) {
/* 317 */     this.situacaoAgendamento = situacaoAgendamento;
/*     */   }
/*     */   public String getInformacaoRetorno1() {
/* 320 */     return this.informacaoRetorno1;
/*     */   }
/*     */   public void setInformacaoRetorno1(String informacaoRetorno1) {
/* 323 */     this.informacaoRetorno1 = informacaoRetorno1;
/*     */   }
/*     */   public String getInformacaoRetorno2() {
/* 326 */     return this.informacaoRetorno2;
/*     */   }
/*     */   public void setInformacaoRetorno2(String informacaoRetorno2) {
/* 329 */     this.informacaoRetorno2 = informacaoRetorno2;
/*     */   }
/*     */   public String getInformacaoRetorno3() {
/* 332 */     return this.informacaoRetorno3;
/*     */   }
/*     */   public void setInformacaoRetorno3(String informacaoRetorno3) {
/* 335 */     this.informacaoRetorno3 = informacaoRetorno3;
/*     */   }
/*     */   public String getInformacaoRetorno4() {
/* 338 */     return this.informacaoRetorno4;
/*     */   }
/*     */   public void setInformacaoRetorno4(String informacaoRetorno4) {
/* 341 */     this.informacaoRetorno4 = informacaoRetorno4;
/*     */   }
/*     */   public String getInformacaoRetorno5() {
/* 344 */     return this.informacaoRetorno5;
/*     */   }
/*     */   public void setInformacaoRetorno5(String informacaoRetorno5) {
/* 347 */     this.informacaoRetorno5 = informacaoRetorno5;
/*     */   }
/*     */   public Integer getTipoMovimento() {
/* 350 */     return this.tipoMovimento;
/*     */   }
/*     */   public void setTipoMovimento(Integer tipoMovimento) {
/* 353 */     this.tipoMovimento = tipoMovimento;
/*     */   }
/*     */   public Integer getCodigoMovimento() {
/* 356 */     return this.codigoMovimento;
/*     */   }
/*     */   public void setCodigoMovimento(Integer codigoMovimento) {
/* 359 */     this.codigoMovimento = codigoMovimento;
/*     */   }
/*     */   public Integer getHorarioConsultaSaldo() {
/* 362 */     return this.horarioConsultaSaldo;
/*     */   }
/*     */   public void setHorarioConsultaSaldo(Integer horarioConsultaSaldo) {
/* 365 */     this.horarioConsultaSaldo = horarioConsultaSaldo;
/*     */   }
/*     */   public Long getSaldoDisponivelSaldo() {
/* 368 */     return this.saldoDisponivelSaldo;
/*     */   }
/*     */   public void setSaldoDisponivelSaldo(Long saldoDisponivelSaldo) {
/* 371 */     this.saldoDisponivelSaldo = saldoDisponivelSaldo;
/*     */   }
/*     */   public Long getValorTaxaPreFunding() {
/* 374 */     return this.valorTaxaPreFunding;
/*     */   }
/*     */   public void setValorTaxaPreFunding(Long valorTaxaPreFunding) {
/* 377 */     this.valorTaxaPreFunding = valorTaxaPreFunding;
/*     */   }
/*     */   public String getReserva() {
/* 380 */     return this.reserva;
/*     */   }
/*     */   public void setReserva(String reserva) {
/* 383 */     this.reserva = reserva;
/*     */   }
/*     */   public String getSacadorAvalista() {
/* 386 */     return this.sacadorAvalista;
/*     */   }
/*     */   public void setSacadorAvalista(String sacadorAvalista) {
/* 389 */     this.sacadorAvalista = sacadorAvalista;
/*     */   }
/*     */   public String getReserva2() {
/* 392 */     return this.reserva2;
/*     */   }
/*     */   public void setReserva2(String reserva2) {
/* 395 */     this.reserva2 = reserva2;
/*     */   }
/*     */   public String getNivelInfoRetorno() {
/* 398 */     return this.nivelInfoRetorno;
/*     */   }
/*     */   public void setNivelInfoRetorno(String nivelInfoRetorno) {
/* 401 */     this.nivelInfoRetorno = nivelInfoRetorno;
/*     */   }
/*     */   public String getInformacoesComplementares() {
/* 404 */     return this.informacoesComplementares;
/*     */   }
/*     */   public void setInformacoesComplementares(String informacoesComplementares) {
/* 407 */     this.informacoesComplementares = informacoesComplementares;
/*     */   }
/*     */   public Integer getCodigoAreaEmpresa() {
/* 410 */     return this.codigoAreaEmpresa;
/*     */   }
/*     */   public void setCodigoAreaEmpresa(Integer codigoAreaEmpresa) {
/* 413 */     this.codigoAreaEmpresa = codigoAreaEmpresa;
/*     */   }
/*     */   public String getCampoUsoEmpresa() {
/* 416 */     return this.campoUsoEmpresa;
/*     */   }
/*     */   public void setCampoUsoEmpresa(String campoUsoEmpresa) {
/* 419 */     this.campoUsoEmpresa = campoUsoEmpresa;
/*     */   }
/*     */   public String getReserva3() {
/* 422 */     return this.reserva3;
/*     */   }
/*     */   public void setReserva3(String reserva3) {
/* 425 */     this.reserva3 = reserva3;
/*     */   }
/*     */   public Integer getCodigoLancamento() {
/* 428 */     return this.codigoLancamento;
/*     */   }
/*     */   public void setCodigoLancamento(Integer codigoLancamento) {
/* 431 */     this.codigoLancamento = codigoLancamento;
/*     */   }
/*     */   public String getReserva4() {
/* 434 */     return this.reserva4;
/*     */   }
/*     */   public void setReserva4(String reserva4) {
/* 437 */     this.reserva4 = reserva4;
/*     */   }
/*     */   public Integer getTipoContaFornecedor() {
/* 440 */     return this.tipoContaFornecedor;
/*     */   }
/*     */   public void setTipoContaFornecedor(Integer tipoContaFornecedor) {
/* 443 */     this.tipoContaFornecedor = tipoContaFornecedor;
/*     */   }
/*     */   public String getContaComplementar() {
/* 446 */     return this.contaComplementar;
/*     */   }
/*     */   public void setContaComplementar(String contaComplementar) {
/* 449 */     this.contaComplementar = contaComplementar;
/*     */   }
/*     */   public String getReserva5() {
/* 452 */     return this.reserva5;
/*     */   }
/*     */   public void setReserva5(String reserva5) {
/* 455 */     this.reserva5 = reserva5;
/*     */   }
/*     */   public Integer getNumeroSequencial() {
/* 458 */     return this.numeroSequencial;
/*     */   }
/*     */   public void setNumeroSequencial(Integer numeroSequencial) {
/* 461 */     this.numeroSequencial = numeroSequencial;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout500\retorno\Detalhe.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */