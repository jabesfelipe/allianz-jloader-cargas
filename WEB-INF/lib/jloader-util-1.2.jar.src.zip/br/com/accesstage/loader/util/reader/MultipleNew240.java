/*     */ package br.com.accesstage.loader.util.reader;
/*     */ 
/*     */ import br.com.accesstage.loader.util.commom.ffpojo.Constantes240;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.Febraban240VO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.HdrExtL033;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.HdrLteCobL045;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.Header;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.HeaderL043;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentY50;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoA;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoB;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoC;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoE;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoP;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoQ;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoR;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoS;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoSImpressao3;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoT;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoU;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.SegmentoY04;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.Trailler;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.TraillerCobL045;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.TraillerL043;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.TrllExtL033;
/*     */ import com.github.ffpojo.FFPojoHelper;
/*     */ import com.github.ffpojo.container.HybridMetadataContainer;
/*     */ import com.github.ffpojo.metadata.RecordDescriptor;
/*     */ import com.github.ffpojo.metadata.extra.FFPojoAnnotationFieldManager;
/*     */ import com.github.ffpojo.metadata.positional.PositionalRecordDescriptor;
/*     */ import com.github.ffpojo.parser.PositionalRecordParser;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleNew240
/*     */   implements Constantes240
/*     */ {
/*  46 */   public static String FILE_INPUT = "/data/1618634@2348921@BBPAGRET@201804051001068";
/*     */   
/*  48 */   public static FFPojoHelper ffPojoHelper = FFPojoHelper.getInstance();
/*  49 */   public static FFPojoAnnotationFieldManager annotationFieldManager = new FFPojoAnnotationFieldManager();
/*     */   
/*     */   public static void main(String[] args) {
/*  52 */     HybridMetadataContainer hybridMetadataContainer = new HybridMetadataContainer();
/*  53 */     Febraban240VO febraban240vo = new Febraban240VO();
/*  54 */     PositionalRecordParser parser = null;
/*  55 */     int hdrL045 = 0;
/*  56 */     int hdrL043 = 0;
/*  57 */     int hdrL033 = 0;
/*  58 */     String tpoImpressao = null;
/*     */     try {
/*  60 */       File files = new File(FILE_INPUT);
/*  61 */       InputStream bis = new FileInputStream(files);
/*  62 */       List<String> lines = IOUtils.readLines(bis, "UTF-8");
/*  63 */       for (int index = 0; index < lines.size(); index++) {
/*  64 */         String linha = lines.get(index);
/*  65 */         String codRegistro = linha.substring(7, 8);
/*  66 */         String codOperacao = linha.substring(8, 9);
/*  67 */         String tpoServico = linha.substring(9, 11);
/*  68 */         String codSegmento = linha.substring(13, 14);
/*  69 */         String identRegOpcional = linha.substring(17, 19);
/*  70 */         tpoImpressao = linha.substring(17, 18);
/*  71 */         RecordDescriptor recordDescriptor = null;
/*  72 */         if ("0".equalsIgnoreCase(codRegistro)) {
/*  73 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(Header.class);
/*  74 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/*  75 */           Header header = (Header)parser.parseFromText(Header.class, linha);
/*  76 */           febraban240vo.setHeader(header);
/*  77 */         } else if ("9".equalsIgnoreCase(codRegistro)) {
/*  78 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(Trailler.class);
/*  79 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/*  80 */           Trailler trailler = (Trailler)parser.parseFromText(Trailler.class, linha);
/*  81 */           febraban240vo.setTrailler(trailler);
/*  82 */         } else if ("1".equalsIgnoreCase(codRegistro) && "01".equals(tpoServico)) {
/*  83 */           hdrL045++;
/*  84 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(HdrLteCobL045.class);
/*  85 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/*  86 */           HdrLteCobL045 cobL045 = (HdrLteCobL045)parser.parseFromText(HdrLteCobL045.class, linha);
/*  87 */           febraban240vo.getListHdrLteCobL045().add(cobL045);
/*  88 */         } else if ("1".equalsIgnoreCase(codRegistro) && "C".equals(codOperacao)) {
/*  89 */           hdrL043++;
/*  90 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(HeaderL043.class);
/*  91 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/*  92 */           HeaderL043 headerL043 = (HeaderL043)parser.parseFromText(HeaderL043.class, linha);
/*  93 */           febraban240vo.getListHeaderL043().add(headerL043);
/*  94 */         } else if ("5".equalsIgnoreCase(codRegistro) && hdrL043 > 0) {
/*  95 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(TraillerL043.class);
/*  96 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/*  97 */           TraillerL043 traillerL043 = (TraillerL043)parser.parseFromText(TraillerL043.class, linha);
/*  98 */           febraban240vo.getListTraillerL043().add(traillerL043);
/*  99 */         } else if ("5".equalsIgnoreCase(codRegistro) && hdrL045 > 0) {
/* 100 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(TraillerCobL045.class);
/* 101 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 102 */           TraillerCobL045 traillerCobL045 = (TraillerCobL045)parser.parseFromText(TraillerCobL045.class, linha);
/* 103 */           febraban240vo.getListTraillerCobL045().add(traillerCobL045);
/* 104 */         } else if ("1".equalsIgnoreCase(codRegistro) && "E".equals(codOperacao) && "04".equals(tpoServico)) {
/* 105 */           hdrL033++;
/* 106 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(HdrExtL033.class);
/* 107 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 108 */           HdrExtL033 hdrExtL033 = (HdrExtL033)parser.parseFromText(HdrExtL033.class, linha);
/* 109 */           febraban240vo.getListHdrExtL033().add(hdrExtL033);
/* 110 */         } else if ("5".equalsIgnoreCase(codRegistro) && hdrL033 > 0) {
/* 111 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(TrllExtL033.class);
/* 112 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 113 */           TrllExtL033 trllExtL033 = (TrllExtL033)parser.parseFromText(TrllExtL033.class, linha);
/* 114 */           febraban240vo.getListTrllExtL033().add(trllExtL033);
/* 115 */         } else if ("3".equalsIgnoreCase(codRegistro) && "U".equals(codSegmento)) {
/* 116 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoU.class);
/* 117 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 118 */           SegmentoU segmentoU = (SegmentoU)parser.parseFromText(SegmentoU.class, linha);
/* 119 */           febraban240vo.getListSegmentoU().add(segmentoU);
/* 120 */         } else if ("3".equalsIgnoreCase(codRegistro) && "T".equals(codSegmento)) {
/* 121 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoT.class);
/* 122 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 123 */           SegmentoT segmentoT = (SegmentoT)parser.parseFromText(SegmentoT.class, linha);
/* 124 */           febraban240vo.getListSegmentoT().add(segmentoT);
/* 125 */         } else if ("3".equalsIgnoreCase(codRegistro) && "Y".equals(codSegmento) && "50".equals(identRegOpcional)) {
/* 126 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentY50.class);
/* 127 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 128 */           SegmentY50 segmentY50 = (SegmentY50)parser.parseFromText(SegmentY50.class, linha);
/* 129 */           febraban240vo.getListSegmentY50().add(segmentY50);
/* 130 */         } else if ("3".equalsIgnoreCase(codRegistro) && "Y".equals(codSegmento) && "03".equals(identRegOpcional)) {
/* 131 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoY04.class);
/* 132 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 133 */           SegmentoY04 segmentoY04 = (SegmentoY04)parser.parseFromText(SegmentoY04.class, linha);
/* 134 */           febraban240vo.getListSegmentoY04().add(segmentoY04);
/* 135 */         } else if ("3".equalsIgnoreCase(codRegistro) && "P".equals(codSegmento)) {
/* 136 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoP.class);
/* 137 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 138 */           SegmentoP segmentoP = (SegmentoP)parser.parseFromText(SegmentoP.class, linha);
/* 139 */           febraban240vo.getListSegmentoP().add(segmentoP);
/* 140 */         } else if ("3".equalsIgnoreCase(codRegistro) && "Q".equals(codSegmento)) {
/* 141 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoQ.class);
/* 142 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 143 */           SegmentoQ segmentoQ = (SegmentoQ)parser.parseFromText(SegmentoQ.class, linha);
/* 144 */           febraban240vo.getListSegmentoQ().add(segmentoQ);
/* 145 */         } else if ("3".equalsIgnoreCase(codRegistro) && "R".equals(codSegmento)) {
/* 146 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoR.class);
/* 147 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 148 */           SegmentoR segmentoR = (SegmentoR)parser.parseFromText(SegmentoR.class, linha);
/* 149 */           febraban240vo.getListSegmentoR().add(segmentoR);
/* 150 */         } else if ("3".equalsIgnoreCase(codRegistro) && "S".equals(codSegmento)) {
/* 151 */           if (tpoImpressao.equals("1") || tpoImpressao.equals("2")) {
/* 152 */             recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoS.class);
/* 153 */             parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 154 */             SegmentoS segmentoS = (SegmentoS)parser.parseFromText(SegmentoS.class, linha);
/* 155 */             febraban240vo.getListSegmentoS().add(segmentoS);
/*     */           } 
/* 157 */           if (tpoImpressao.equalsIgnoreCase("3")) {
/* 158 */             recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoSImpressao3.class);
/* 159 */             parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 160 */             SegmentoSImpressao3 segmentoSImpressao3 = (SegmentoSImpressao3)parser.parseFromText(SegmentoSImpressao3.class, linha);
/* 161 */             febraban240vo.getListSegmentSImpressao3().add(segmentoSImpressao3);
/*     */           } 
/* 163 */         } else if ("3".equalsIgnoreCase(codRegistro) && "E".equals(codSegmento)) {
/* 164 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoE.class);
/* 165 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 166 */           SegmentoE segmentoE = (SegmentoE)parser.parseFromText(SegmentoE.class, linha);
/* 167 */           febraban240vo.getListSegmentoE().add(segmentoE);
/* 168 */         } else if ("3".equalsIgnoreCase(codRegistro) && "A".equals(codSegmento)) {
/* 169 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoA.class);
/* 170 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 171 */           SegmentoA segmentoA = (SegmentoA)parser.parseFromText(SegmentoA.class, linha);
/* 172 */           febraban240vo.getListSegmentoA().add(segmentoA);
/* 173 */         } else if ("3".equalsIgnoreCase(codRegistro) && "B".equals(codSegmento)) {
/* 174 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoB.class);
/* 175 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 176 */           SegmentoB segmentoB = (SegmentoB)parser.parseFromText(SegmentoB.class, linha);
/* 177 */           febraban240vo.getListSegmentoB().add(segmentoB);
/* 178 */         } else if ("3".equalsIgnoreCase(codRegistro) && "C".equals(codSegmento)) {
/* 179 */           recordDescriptor = hybridMetadataContainer.getRecordDescriptor(SegmentoC.class);
/* 180 */           parser = new PositionalRecordParser((PositionalRecordDescriptor)recordDescriptor);
/* 181 */           SegmentoC segmentoC = (SegmentoC)parser.parseFromText(SegmentoC.class, linha);
/* 182 */           febraban240vo.getListSegmentoC().add(segmentoC);
/*     */         } 
/*     */       } 
/* 185 */       System.out.println("AQUI");
/* 186 */     } catch (FileNotFoundException e) {
/* 187 */       e.printStackTrace();
/* 188 */     } catch (IOException e) {
/* 189 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\reader\MultipleNew240.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */