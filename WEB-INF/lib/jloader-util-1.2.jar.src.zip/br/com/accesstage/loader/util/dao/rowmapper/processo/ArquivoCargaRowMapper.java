/*    */ package br.com.accesstage.loader.util.dao.rowmapper.processo;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.ArquivoCarga;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class ArquivoCargaRowMapper
/*    */   implements RowMapper<ArquivoCarga>
/*    */ {
/*    */   public ArquivoCarga mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 13 */     ArquivoCarga arquivoCarga = new ArquivoCarga();
/* 14 */     arquivoCarga.setCodigoArquivo(Long.valueOf(rs.getLong("COD_ARQUIVO")));
/* 15 */     arquivoCarga.setDscNomeArquivoOrigem(rs.getString("DSC_NOME_ARQUIVO_ORIGEM"));
/* 16 */     arquivoCarga.setDscNomeArquivoDestino(rs.getString("DSC_NOME_ARQUIVO_DESTINO"));
/* 17 */     arquivoCarga.setDscMd5sum(rs.getString("DSC_MD5SUM"));
/* 18 */     arquivoCarga.setNmePathIn(rs.getString("NME_PATH_IN"));
/* 19 */     arquivoCarga.setNmePathOut(rs.getString("NME_PATH_OUT"));
/* 20 */     arquivoCarga.setNroRegistros(rs.getString("NRO_REGISTROS"));
/* 21 */     arquivoCarga.setNroTamanhoArquivo(Long.valueOf(rs.getLong("NRO_TAMANHO_ARQUIVO")));
/* 22 */     arquivoCarga.setCodInstanciaBpel(rs.getString("COD_INSTANCIA_BPEL"));
/* 23 */     arquivoCarga.setDthProcessIni(rs.getDate("DTH_PROCESS_INI"));
/* 24 */     arquivoCarga.setDthProcessFim(rs.getDate("DTH_PROCESS_FIM"));
/* 25 */     arquivoCarga.setEmpId(Long.valueOf(rs.getLong("EMPID")));
/* 26 */     arquivoCarga.setCodTpoLayout(rs.getString("COD_TPO_LAYOUT"));
/* 27 */     arquivoCarga.setDscOrigem(rs.getString("COD_STATUS_CARGA"));
/* 28 */     arquivoCarga.setCreated(rs.getDate("CREATED"));
/* 29 */     return arquivoCarga;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\processo\ArquivoCargaRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */