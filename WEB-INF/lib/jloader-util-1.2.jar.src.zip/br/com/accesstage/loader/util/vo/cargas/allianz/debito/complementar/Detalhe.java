/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito.complementar;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "5")})
/*     */ public class Detalhe
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 3302946708260122312L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private String codRegistro;
/*     */   @PositionalField(initialPosition = 2, finalPosition = 16)
/*     */   private String documento;
/*     */   @PositionalField(initialPosition = 17, finalPosition = 17)
/*     */   private String tipoPessoa;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 57)
/*     */   private String nomeCliente;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 97)
/*     */   private String endereco;
/*     */   @PositionalField(initialPosition = 98, finalPosition = 112)
/*     */   private String bairro;
/*     */   @PositionalField(initialPosition = 113, finalPosition = 120)
/*     */   private String cep;
/*     */   @PositionalField(initialPosition = 121, finalPosition = 135)
/*     */   private String cidade;
/*     */   @PositionalField(initialPosition = 136, finalPosition = 137)
/*     */   private String estado;
/*     */   @PositionalField(initialPosition = 138, finalPosition = 147)
/*     */   private String poliza;
/*     */   @PositionalField(initialPosition = 148, finalPosition = 173)
/*     */   private String apolice;
/*     */   @PositionalField(initialPosition = 174, finalPosition = 179)
/*     */   private String endosso;
/*     */   @PositionalField(initialPosition = 180, finalPosition = 181)
/*     */   private String parcela;
/*     */   @PositionalField(initialPosition = 182, finalPosition = 183)
/*     */   private String plano;
/*     */   @PositionalField(initialPosition = 184, finalPosition = 193)
/*     */   private String recibo;
/*     */   @PositionalField(initialPosition = 194, finalPosition = 201)
/*     */   private String dataVencimento;
/*     */   @PositionalField(initialPosition = 202, finalPosition = 241)
/*     */   private String dsProduto;
/*     */   @PositionalField(initialPosition = 242, finalPosition = 244)
/*     */   private String bancoDebito;
/*     */   @PositionalField(initialPosition = 245, finalPosition = 250)
/*     */   private String agencia;
/*     */   @PositionalField(initialPosition = 251, finalPosition = 252)
/*     */   private String agenciaDV;
/*     */   @PositionalField(initialPosition = 253, finalPosition = 272)
/*     */   private String contaCorrente;
/*     */   @PositionalField(initialPosition = 273, finalPosition = 274)
/*     */   private String contaCorrenteDV;
/*     */   @PositionalField(initialPosition = 275, finalPosition = 282)
/*     */   private String dataPrevCancelamento;
/*     */   @PositionalField(initialPosition = 283, finalPosition = 362)
/*     */   private String emailCliente;
/*     */   @PositionalField(initialPosition = 363, finalPosition = 382)
/*     */   private String celularCliente;
/*     */   @PositionalField(initialPosition = 383, finalPosition = 462)
/*     */   private String emailCorretor;
/*     */   @PositionalField(initialPosition = 463, finalPosition = 482)
/*     */   private String celularCorretor;
/*     */   @PositionalField(initialPosition = 483, finalPosition = 490)
/*     */   private String aliquotaIOF;
/*     */   @PositionalField(initialPosition = 491, finalPosition = 500)
/*     */   private String codRejeicaoDebito;
/*     */   @PositionalField(initialPosition = 501, finalPosition = 503)
/*     */   private String bancoBoleto;
/*     */   @PositionalField(initialPosition = 504, finalPosition = 519)
/*     */   private String nossoNumero;
/*     */   @PositionalField(initialPosition = 520, finalPosition = 574)
/*     */   private String linhaDigitavel;
/*     */   @PositionalField(initialPosition = 575, finalPosition = 629)
/*     */   private String codigoBarras;
/*     */   @PositionalField(initialPosition = 630, finalPosition = 639)
/*     */   private String valorBoleto;
/*     */   @PositionalField(initialPosition = 640, finalPosition = 647)
/*     */   private String tipoCobranca;
/*     */   @PositionalField(initialPosition = 648, finalPosition = 648)
/*     */   private String vencimentoBoleto;
/*     */   @PositionalField(initialPosition = 649, finalPosition = 750)
/*     */   private String filler;
/*     */   private String vlrJuros;
/*     */   private String codRetorno;
/*     */   private String dscComplemento;
/*     */   private String valorRetorno;
/*     */   private String dtaProcessamento;
/*     */   private String dtaEmissao;
/*     */   
/*     */   public String getCodRegistro() {
/* 104 */     return this.codRegistro;
/*     */   }
/*     */   public void setCodRegistro(String codRegistro) {
/* 107 */     this.codRegistro = codRegistro;
/*     */   }
/*     */   public String getDocumento() {
/* 110 */     return this.documento;
/*     */   }
/*     */   public void setDocumento(String documento) {
/* 113 */     this.documento = documento;
/*     */   }
/*     */   public String getTipoPessoa() {
/* 116 */     return this.tipoPessoa;
/*     */   }
/*     */   public void setTipoPessoa(String tipoPessoa) {
/* 119 */     this.tipoPessoa = tipoPessoa;
/*     */   }
/*     */   public String getNomeCliente() {
/* 122 */     return this.nomeCliente;
/*     */   }
/*     */   public void setNomeCliente(String nomeCliente) {
/* 125 */     this.nomeCliente = nomeCliente;
/*     */   }
/*     */   public String getEndereco() {
/* 128 */     return this.endereco;
/*     */   }
/*     */   public void setEndereco(String endereco) {
/* 131 */     this.endereco = endereco;
/*     */   }
/*     */   public String getBairro() {
/* 134 */     return this.bairro;
/*     */   }
/*     */   public void setBairro(String bairro) {
/* 137 */     this.bairro = bairro;
/*     */   }
/*     */   public String getCep() {
/* 140 */     return this.cep;
/*     */   }
/*     */   public void setCep(String cep) {
/* 143 */     this.cep = cep;
/*     */   }
/*     */   public String getCidade() {
/* 146 */     return this.cidade;
/*     */   }
/*     */   public void setCidade(String cidade) {
/* 149 */     this.cidade = cidade;
/*     */   }
/*     */   public String getEstado() {
/* 152 */     return this.estado;
/*     */   }
/*     */   public void setEstado(String estado) {
/* 155 */     this.estado = estado;
/*     */   }
/*     */   public String getPoliza() {
/* 158 */     return this.poliza;
/*     */   }
/*     */   public void setPoliza(String poliza) {
/* 161 */     this.poliza = poliza;
/*     */   }
/*     */   public String getApolice() {
/* 164 */     return this.apolice;
/*     */   }
/*     */   public void setApolice(String apolice) {
/* 167 */     this.apolice = apolice;
/*     */   }
/*     */   public String getEndosso() {
/* 170 */     return this.endosso;
/*     */   }
/*     */   public void setEndosso(String endosso) {
/* 173 */     this.endosso = endosso;
/*     */   }
/*     */   public String getParcela() {
/* 176 */     return this.parcela;
/*     */   }
/*     */   public void setParcela(String parcela) {
/* 179 */     this.parcela = parcela;
/*     */   }
/*     */   public String getPlano() {
/* 182 */     return this.plano;
/*     */   }
/*     */   public void setPlano(String plano) {
/* 185 */     this.plano = plano;
/*     */   }
/*     */   public String getRecibo() {
/* 188 */     return this.recibo;
/*     */   }
/*     */   public void setRecibo(String recibo) {
/* 191 */     this.recibo = recibo;
/*     */   }
/*     */   public String getDataVencimento() {
/* 194 */     return this.dataVencimento;
/*     */   }
/*     */   public void setDataVencimento(String dataVencimento) {
/* 197 */     this.dataVencimento = dataVencimento;
/*     */   }
/*     */   public String getDsProduto() {
/* 200 */     return this.dsProduto;
/*     */   }
/*     */   public void setDsProduto(String dsProduto) {
/* 203 */     this.dsProduto = dsProduto;
/*     */   }
/*     */   public String getBancoDebito() {
/* 206 */     return this.bancoDebito;
/*     */   }
/*     */   public void setBancoDebito(String bancoDebito) {
/* 209 */     this.bancoDebito = bancoDebito;
/*     */   }
/*     */   public String getAgencia() {
/* 212 */     return this.agencia;
/*     */   }
/*     */   public void setAgencia(String agencia) {
/* 215 */     this.agencia = agencia;
/*     */   }
/*     */   public String getAgenciaDV() {
/* 218 */     return this.agenciaDV;
/*     */   }
/*     */   public void setAgenciaDV(String agenciaDV) {
/* 221 */     this.agenciaDV = agenciaDV;
/*     */   }
/*     */   public String getContaCorrente() {
/* 224 */     return this.contaCorrente;
/*     */   }
/*     */   public void setContaCorrente(String contaCorrente) {
/* 227 */     this.contaCorrente = contaCorrente;
/*     */   }
/*     */   public String getContaCorrenteDV() {
/* 230 */     return this.contaCorrenteDV;
/*     */   }
/*     */   public void setContaCorrenteDV(String contaCorrenteDV) {
/* 233 */     this.contaCorrenteDV = contaCorrenteDV;
/*     */   }
/*     */   public String getDataPrevCancelamento() {
/* 236 */     return this.dataPrevCancelamento;
/*     */   }
/*     */   public void setDataPrevCancelamento(String dataPrevCancelamento) {
/* 239 */     this.dataPrevCancelamento = dataPrevCancelamento;
/*     */   }
/*     */   public String getEmailCliente() {
/* 242 */     return this.emailCliente;
/*     */   }
/*     */   public void setEmailCliente(String emailCliente) {
/* 245 */     this.emailCliente = emailCliente;
/*     */   }
/*     */   public String getCelularCliente() {
/* 248 */     return this.celularCliente;
/*     */   }
/*     */   public void setCelularCliente(String celularCliente) {
/* 251 */     this.celularCliente = celularCliente;
/*     */   }
/*     */   public String getEmailCorretor() {
/* 254 */     return this.emailCorretor;
/*     */   }
/*     */   public void setEmailCorretor(String emailCorretor) {
/* 257 */     this.emailCorretor = emailCorretor;
/*     */   }
/*     */   public String getCelularCorretor() {
/* 260 */     return this.celularCorretor;
/*     */   }
/*     */   public void setCelularCorretor(String celularCorretor) {
/* 263 */     this.celularCorretor = celularCorretor;
/*     */   }
/*     */   public String getAliquotaIOF() {
/* 266 */     return this.aliquotaIOF;
/*     */   }
/*     */   public void setAliquotaIOF(String aliquotaIOF) {
/* 269 */     this.aliquotaIOF = aliquotaIOF;
/*     */   }
/*     */   public String getCodRejeicaoDebito() {
/* 272 */     return this.codRejeicaoDebito;
/*     */   }
/*     */   public void setCodRejeicaoDebito(String codRejeicaoDebito) {
/* 275 */     this.codRejeicaoDebito = codRejeicaoDebito;
/*     */   }
/*     */   public String getBancoBoleto() {
/* 278 */     return this.bancoBoleto;
/*     */   }
/*     */   public void setBancoBoleto(String bancoBoleto) {
/* 281 */     this.bancoBoleto = bancoBoleto;
/*     */   }
/*     */   public String getNossoNumero() {
/* 284 */     return this.nossoNumero;
/*     */   }
/*     */   public void setNossoNumero(String nossoNumero) {
/* 287 */     this.nossoNumero = nossoNumero;
/*     */   }
/*     */   public String getLinhaDigitavel() {
/* 290 */     return this.linhaDigitavel;
/*     */   }
/*     */   public void setLinhaDigitavel(String linhaDigitavel) {
/* 293 */     this.linhaDigitavel = linhaDigitavel;
/*     */   }
/*     */   public String getCodigoBarras() {
/* 296 */     return this.codigoBarras;
/*     */   }
/*     */   public void setCodigoBarras(String codigoBarras) {
/* 299 */     this.codigoBarras = codigoBarras;
/*     */   }
/*     */   public String getValorBoleto() {
/* 302 */     return this.valorBoleto;
/*     */   }
/*     */   public void setValorBoleto(String valorBoleto) {
/* 305 */     this.valorBoleto = valorBoleto;
/*     */   }
/*     */   public String getTipoCobranca() {
/* 308 */     return this.tipoCobranca;
/*     */   }
/*     */   public void setTipoCobranca(String tipoCobranca) {
/* 311 */     this.tipoCobranca = tipoCobranca;
/*     */   }
/*     */   public String getVencimentoBoleto() {
/* 314 */     return this.vencimentoBoleto;
/*     */   }
/*     */   public void setVencimentoBoleto(String vencimentoBoleto) {
/* 317 */     this.vencimentoBoleto = vencimentoBoleto;
/*     */   }
/*     */   public String getFiller() {
/* 320 */     return this.filler;
/*     */   }
/*     */   public void setFiller(String filler) {
/* 323 */     this.filler = filler;
/*     */   }
/*     */   public String getValorRetorno() {
/* 326 */     return this.valorRetorno;
/*     */   }
/*     */   public void setValorRetorno(String valorRetorno) {
/* 329 */     this.valorRetorno = valorRetorno;
/*     */   }
/*     */   public String getDscComplemento() {
/* 332 */     return this.dscComplemento;
/*     */   }
/*     */   public void setDscComplemento(String dscComplemento) {
/* 335 */     this.dscComplemento = dscComplemento;
/*     */   }
/*     */   public String getCodRetorno() {
/* 338 */     return this.codRetorno;
/*     */   }
/*     */   public void setCodRetorno(String codRetorno) {
/* 341 */     this.codRetorno = codRetorno;
/*     */   }
/*     */   public String getVlrJuros() {
/* 344 */     return this.vlrJuros;
/*     */   }
/*     */   public void setVlrJuros(String vlrJuros) {
/* 347 */     this.vlrJuros = vlrJuros;
/*     */   }
/*     */   public String getDtaProcessamento() {
/* 350 */     return this.dtaProcessamento;
/*     */   }
/*     */   public void setDtaProcessamento(String dtaProcessamento) {
/* 353 */     this.dtaProcessamento = dtaProcessamento;
/*     */   }
/*     */   public String getDtaEmissao() {
/* 356 */     return this.dtaEmissao;
/*     */   }
/*     */   public void setDtaEmissao(String dtaEmissao) {
/* 359 */     this.dtaEmissao = dtaEmissao;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 363 */     return "Detalhe [codRegistro=" + this.codRegistro + ", documento=" + this.documento + ", tipoPessoa=" + this.tipoPessoa + ", nomeCliente=" + this.nomeCliente + ", endereco=" + this.endereco + ", bairro=" + this.bairro + ", cep=" + this.cep + ", cidade=" + this.cidade + ", estado=" + this.estado + ", poliza=" + this.poliza + ", apolice=" + this.apolice + ", endosso=" + this.endosso + ", parcela=" + this.parcela + ", plano=" + this.plano + ", recibo=" + this.recibo + ", dataVencimento=" + this.dataVencimento + ", dsProduto=" + this.dsProduto + ", bancoDebito=" + this.bancoDebito + ", agencia=" + this.agencia + ", agenciaDV=" + this.agenciaDV + ", contaCorrente=" + this.contaCorrente + ", contaCorrenteDV=" + this.contaCorrenteDV + ", dataPrevCancelamento=" + this.dataPrevCancelamento + ", emailCliente=" + this.emailCliente + ", celularCliente=" + this.celularCliente + ", emailCorretor=" + this.emailCorretor + ", celularCorretor=" + this.celularCorretor + ", aliquotaIOF=" + this.aliquotaIOF + ", codRejeicaoDebito=" + this.codRejeicaoDebito + ", bancoBoleto=" + this.bancoBoleto + ", nossoNumero=" + this.nossoNumero + ", linhaDigitavel=" + this.linhaDigitavel + ", codigoBarras=" + this.codigoBarras + ", valorBoleto=" + this.valorBoleto + ", tipoCobranca=" + this.tipoCobranca + ", vencimentoBoleto=" + this.vencimentoBoleto + ", filler=" + this.filler + ", dscComplemento=" + this.dscComplemento + ", valorRetorno=" + this.valorRetorno + "]";
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\complementar\Detalhe.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */