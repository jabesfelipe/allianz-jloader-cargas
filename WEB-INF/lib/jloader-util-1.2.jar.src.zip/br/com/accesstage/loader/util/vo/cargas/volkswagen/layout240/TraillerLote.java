/*    */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord
/*    */ public class TraillerLote
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*    */   private String codBancoTrllr;
/*    */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*    */   private String codLoteTrllr;
/*    */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*    */   private String codTpoServTrllr;
/*    */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*    */   private String dscReservadoTrllr;
/*    */   @PositionalField(initialPosition = 18, finalPosition = 23)
/*    */   private String qtdeRegistrosLotes;
/*    */   @PositionalField(initialPosition = 24, finalPosition = 41)
/*    */   private String dscSomaVlrTrllr;
/*    */   @PositionalField(initialPosition = 42, finalPosition = 59)
/*    */   private String dscSomaQtdMoedaTrllr;
/*    */   @PositionalField(initialPosition = 60, finalPosition = 65)
/*    */   private String dscNumAvisoDebTrllr;
/*    */   @PositionalField(initialPosition = 66, finalPosition = 230)
/*    */   private String dscReservado1Trllr;
/*    */   @PositionalField(initialPosition = 231, finalPosition = 240)
/*    */   private String dscOcorrenciasTrllr;
/*    */   
/*    */   public String getCodBancoTrllr() {
/* 38 */     return this.codBancoTrllr;
/*    */   }
/*    */   public void setCodBancoTrllr(String codBancoTrllr) {
/* 41 */     this.codBancoTrllr = codBancoTrllr;
/*    */   }
/*    */   public String getCodLoteTrllr() {
/* 44 */     return this.codLoteTrllr;
/*    */   }
/*    */   public void setCodLoteTrllr(String codLoteTrllr) {
/* 47 */     this.codLoteTrllr = codLoteTrllr;
/*    */   }
/*    */   public String getCodTpoServTrllr() {
/* 50 */     return this.codTpoServTrllr;
/*    */   }
/*    */   public void setCodTpoServTrllr(String codTpoServTrllr) {
/* 53 */     this.codTpoServTrllr = codTpoServTrllr;
/*    */   }
/*    */   public String getDscReservadoTrllr() {
/* 56 */     return this.dscReservadoTrllr;
/*    */   }
/*    */   public void setDscReservadoTrllr(String dscReservadoTrllr) {
/* 59 */     this.dscReservadoTrllr = dscReservadoTrllr;
/*    */   }
/*    */   public String getQtdeRegistrosLotes() {
/* 62 */     return this.qtdeRegistrosLotes;
/*    */   }
/*    */   public void setQtdeRegistrosLotes(String codResgistroLteTrllr) {
/* 65 */     this.qtdeRegistrosLotes = codResgistroLteTrllr;
/*    */   }
/*    */   public String getDscSomaVlrTrllr() {
/* 68 */     return this.dscSomaVlrTrllr;
/*    */   }
/*    */   public void setDscSomaVlrTrllr(String dscSomaVlrTrllr) {
/* 71 */     this.dscSomaVlrTrllr = dscSomaVlrTrllr;
/*    */   }
/*    */   public String getDscSomaQtdMoedaTrllr() {
/* 74 */     return this.dscSomaQtdMoedaTrllr;
/*    */   }
/*    */   public void setDscSomaQtdMoedaTrllr(String dscSomaQtdMoedaTrllr) {
/* 77 */     this.dscSomaQtdMoedaTrllr = dscSomaQtdMoedaTrllr;
/*    */   }
/*    */   public String getDscNumAvisoDebTrllr() {
/* 80 */     return this.dscNumAvisoDebTrllr;
/*    */   }
/*    */   public void setDscNumAvisoDebTrllr(String dscNumAvisoDebTrllr) {
/* 83 */     this.dscNumAvisoDebTrllr = dscNumAvisoDebTrllr;
/*    */   }
/*    */   public String getDscReservado1Trllr() {
/* 86 */     return this.dscReservado1Trllr;
/*    */   }
/*    */   public void setDscReservado1Trllr(String dscReservado1Trllr) {
/* 89 */     this.dscReservado1Trllr = dscReservado1Trllr;
/*    */   }
/*    */   public String getDscOcorrenciasTrllr() {
/* 92 */     return this.dscOcorrenciasTrllr;
/*    */   }
/*    */   public void setDscOcorrenciasTrllr(String dscOcorrenciasTrllr) {
/* 95 */     this.dscOcorrenciasTrllr = dscOcorrenciasTrllr;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\TraillerLote.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */