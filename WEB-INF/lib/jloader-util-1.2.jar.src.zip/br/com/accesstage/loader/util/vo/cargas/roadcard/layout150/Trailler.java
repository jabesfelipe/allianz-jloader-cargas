/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout150;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "Z")})
/*    */ public class Trailler
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 8482517584916496560L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 7)
/*    */   private String totalRegistroArq;
/*    */   @PositionalField(initialPosition = 8, finalPosition = 24, decorator = BigDecimalDecorator.class)
/*    */   private BigDecimal vlorTotalRegistroArq;
/*    */   @PositionalField(initialPosition = 25, finalPosition = 150)
/*    */   private String usoFuturo;
/*    */   
/*    */   public String getCodRegistro() {
/* 30 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 33 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getTotalRegistroArq() {
/* 36 */     return this.totalRegistroArq;
/*    */   }
/*    */   public void setTotalRegistroArq(String totalRegistroArq) {
/* 39 */     this.totalRegistroArq = totalRegistroArq;
/*    */   }
/*    */   public BigDecimal getVlorTotalRegistroArq() {
/* 42 */     return this.vlorTotalRegistroArq;
/*    */   }
/*    */   public void setVlorTotalRegistroArq(BigDecimal vlorTotalRegistroArq) {
/* 45 */     this.vlorTotalRegistroArq = vlorTotalRegistroArq;
/*    */   }
/*    */   public String getUsoFuturo() {
/* 48 */     return this.usoFuturo;
/*    */   }
/*    */   public void setUsoFuturo(String usoFuturo) {
/* 51 */     this.usoFuturo = usoFuturo;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout150\Trailler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */