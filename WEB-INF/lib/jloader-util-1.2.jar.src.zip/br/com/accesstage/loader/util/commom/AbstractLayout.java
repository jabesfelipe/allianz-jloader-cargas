/*     */ package br.com.accesstage.loader.util.commom;
/*     */ 
/*     */ import br.com.accesstage.loader.util.constantes.processo.StatusCarga;
/*     */ import br.com.accesstage.loader.util.dao.BaseDAO;
/*     */ import br.com.accesstage.loader.util.exception.LayoutException;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.sql.SQLException;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.web.context.support.SpringBeanAutowiringSupport;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Component
/*     */ public abstract class AbstractLayout
/*     */   extends SpringBeanAutowiringSupport
/*     */ {
/*     */   @Autowired
/*     */   private BaseDAO baseDAO;
/*  37 */   private static Logger logger = Logger.getLogger(AbstractLayout.class);
/*     */   
/*     */   private static final int BATCH_SIZE = 100;
/*     */   
/*     */   private static final String DSC_ERRO_SISTEMA = "erroSistema";
/*     */   
/*     */   private static final String DSC_ERRO_LAYOUT = "erroLayout";
/*     */   
/*     */   private static final String UPDATE_ARQUIVO_CARGA = "UPDATE ARQUIVO_CARGA SET COD_STATUS_CARGA = ?, DSC_NOME_ARQUIVO_DESTINO = ?, NME_PATH_OUT = ?, DTH_PROCESS_FIM = CURRENT_TIMESTAMP WHERE COD_ARQUIVO = ?";
/*     */   
/*     */   private static final String INSERT_CONTROLE_CARGA = "INSERT INTO CONTROLE_CARGA (COD_CONTROLE,COD_ARQUIVO,DTH_EVENTO,DSC_OBSERVACAO, COD_STATUS_CARGA) VALUES (SEQ_CONTROLE_CARGA.NEXTVAL, ?, CURRENT_TIMESTAMP, ?, ?)";
/*     */   
/*     */   protected String dataFileName;
/*     */   
/*     */   protected String dataFilePath;
/*     */   
/*     */   protected int codArquivo;
/*     */   private int colunaProcessada;
/*     */   private int linhaProcessada;
/*     */   private File fileToProcess;
/*     */   private File workFile;
/*     */   private int empid;
/*     */   
/*     */   protected AbstractLayout(String fileName, String fileDir, int codArquivo, int empid) {
/*  61 */     this.dataFileName = fileName;
/*  62 */     this.dataFilePath = fileDir;
/*  63 */     this.empid = empid;
/*  64 */     this.codArquivo = codArquivo;
/*  65 */     this.workFile = new File(this.dataFilePath, this.dataFileName + ".work");
/*     */   }
/*     */   
/*     */   public int getLinhaProcessada() {
/*  69 */     return this.linhaProcessada;
/*     */   }
/*     */ 
/*     */   
/*     */   public int incr(int incr) {
/*  74 */     return this.colunaProcessada += incr;
/*     */   }
/*     */   
/*     */   public int col() {
/*  78 */     return this.colunaProcessada;
/*     */   }
/*     */   
/*     */   public int getEmpid() {
/*  82 */     return this.empid;
/*     */   }
/*     */   
/*     */   public int getCodArquivo() {
/*  86 */     return this.codArquivo;
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  90 */     return this.dataFileName;
/*     */   }
/*     */   
/*     */   public String getFilePath() {
/*  94 */     return this.dataFilePath;
/*     */   }
/*     */   
/*     */   public File getFileToProcessAbsolute() {
/*  98 */     return this.fileToProcess.getAbsoluteFile();
/*     */   }
/*     */ 
/*     */   
/*     */   private Document documentXML() throws IOException, SAXException, ParserConfigurationException {
/* 103 */     logger.info("AbsolutePath para Parse do XML: " + this.fileToProcess.getAbsolutePath());
/* 104 */     Document document = PositionalXMLReader.readXML(this.fileToProcess);
/* 105 */     logger.info("Element Root Lib: " + document.getDocumentElement().getNodeName());
/* 106 */     document.getDocumentElement().normalize();
/* 107 */     return document;
/*     */   }
/*     */   
/*     */   public Node getNode(Node node) {
/* 111 */     if (node != null) {
/* 112 */       String lineNumber = (String)node.getUserData("lineNumber");
/* 113 */       if (lineNumber != null) {
/* 114 */         this.linhaProcessada = Integer.parseInt(lineNumber);
/*     */       }
/*     */     } 
/* 117 */     return node;
/*     */   }
/*     */   
/*     */   public void processXml() {
/* 121 */     this.fileToProcess = new File(this.dataFilePath, this.dataFileName);
/*     */     try {
/* 123 */       logger.info("[JLoader] - iniciando processamento: " + this.fileToProcess.getAbsolutePath());
/* 124 */       alteraStatus(this.codArquivo, StatusCarga.STATUS_PROCESSANDO.getCodStatusCarga().intValue(), null, null, null);
/* 125 */       logger.info("[JLoader] - Iniciou Altera Status para PROCESSANDO: ");
/* 126 */       if (this.fileToProcess.exists() && this.fileToProcess != null) {
/* 127 */         processFileXml();
/*     */       } else {
/* 129 */         logger.error("[JLoader] - Arquivo nao existe: " + this.fileToProcess.getAbsolutePath());
/* 130 */         throw new IOException("[JLoader] - Arquivo nao existe: " + this.fileToProcess.getAbsolutePath());
/*     */       } 
/* 132 */       String newPath = moveArquivo(null, true);
/* 133 */       if (newPath != null && !newPath.isEmpty()) {
/* 134 */         alteraStatus(this.codArquivo, StatusCarga.STATUS_OK.getCodStatusCarga().intValue(), null, this.dataFileName, newPath);
/* 135 */         this.baseDAO.commit();
/* 136 */         logger.info("[JLoader] - Iniciou Altera Status para OK");
/*     */       } 
/* 138 */     } catch (FileNotFoundException e) {
/* 139 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), e, "erroSistema");
/* 140 */     } catch (IOException e) {
/* 141 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), e, "erroSistema");
/* 142 */     } catch (SQLException e) {
/* 143 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), e, "erroSistema");
/* 144 */     } catch (LayoutException e) {
/* 145 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), (Exception)e, "erroLayout");
/* 146 */     } catch (Exception e) {
/* 147 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), e, "erroSistema");
/*     */     } finally {
/*     */       try {
/* 150 */         this.baseDAO.commit();
/* 151 */         this.baseDAO.close();
/* 152 */       } catch (Exception e) {
/* 153 */         logger.warn("[JLoader] - Erro ao fechar conexão!", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void process() {
/* 163 */     this.fileToProcess = new File(this.dataFilePath, this.dataFileName);
/*     */     try {
/* 165 */       logger.info("[JLoader] - iniciando processamento: " + this.fileToProcess.getAbsolutePath());
/* 166 */       alteraStatus(this.codArquivo, StatusCarga.STATUS_PROCESSANDO.getCodStatusCarga().intValue(), null, null, null);
/* 167 */       logger.info("[JLoader] - Iniciou Altera Status para PROCESSANDO: ");
/*     */       
/* 169 */       if (this.fileToProcess.exists() && this.fileToProcess != null) {
/* 170 */         processFile();
/*     */       } else {
/* 172 */         logger.error("[JLoader] - Arquivo nao existe: " + this.fileToProcess.getAbsolutePath());
/* 173 */         throw new IOException("[JLoader] - Arquivo nao existe: " + this.fileToProcess.getAbsolutePath());
/*     */       } 
/*     */       
/* 176 */       String newPath = moveArquivo(null, true);
/*     */       
/* 178 */       if (newPath != null && !newPath.isEmpty()) {
/* 179 */         alteraStatus(this.codArquivo, StatusCarga.STATUS_OK.getCodStatusCarga().intValue(), null, this.dataFileName, newPath);
/* 180 */         this.baseDAO.commit();
/* 181 */         logger.info("[JLoader] - Iniciou Altera Status para OK");
/*     */       } 
/* 183 */     } catch (FileNotFoundException e) {
/* 184 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), e, "erroSistema");
/* 185 */     } catch (IOException e) {
/* 186 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), e, "erroSistema");
/* 187 */     } catch (SQLException e) {
/* 188 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), e, "erroSistema");
/* 189 */     } catch (LayoutException e) {
/* 190 */       trataErro(StatusCarga.STATUS_ERRO_LAYOUT.getCodStatusCarga().intValue(), (Exception)e, "erroLayout");
/* 191 */     } catch (Exception e) {
/* 192 */       trataErro(StatusCarga.STATUS_ERRO_SISTEMA.getCodStatusCarga().intValue(), e, "erroSistema");
/*     */     } finally {
/*     */       try {
/* 195 */         this.baseDAO.commit();
/* 196 */         this.baseDAO.close();
/* 197 */       } catch (Exception e) {
/* 198 */         logger.warn("[JLoader] - Erro ao fechar conexão!", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void alteraStatus(int codArquivo, int status, String obs, String nmeArquivoDest, String nmePathOut) throws SQLException {
/* 205 */     this.baseDAO.merge("UPDATE ARQUIVO_CARGA SET COD_STATUS_CARGA = ?, DSC_NOME_ARQUIVO_DESTINO = ?, NME_PATH_OUT = ?, DTH_PROCESS_FIM = CURRENT_TIMESTAMP WHERE COD_ARQUIVO = ?", new Object[] { Integer.valueOf(status), nmeArquivoDest, nmePathOut, Integer.valueOf(codArquivo) });
/* 206 */     logger.info("[JLoader] - Atualizando a ARQUIVO_CARGA, alterando status final.");
/* 207 */     this.baseDAO.merge("INSERT INTO CONTROLE_CARGA (COD_CONTROLE,COD_ARQUIVO,DTH_EVENTO,DSC_OBSERVACAO, COD_STATUS_CARGA) VALUES (SEQ_CONTROLE_CARGA.NEXTVAL, ?, CURRENT_TIMESTAMP, ?, ?)", new Object[] { Integer.valueOf(codArquivo), obs, Integer.valueOf(status) });
/* 208 */     logger.info("[JLoader] - Atualizando a CONTROLE_CARGA, alterando status final.");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processFileXml() throws FileNotFoundException, IOException, SQLException, LayoutException, SAXException, ParserConfigurationException {
/* 213 */     Document doc = documentXML();
/* 214 */     if (doc.hasChildNodes()) {
/*     */       try {
/* 216 */         processLineXml(doc);
/* 217 */       } catch (ParseException pe) {
/* 218 */         throw new LayoutException("[JLoader] - Erro ao realizar parse. Col: " + col() + ", Document: " + doc + ", Arquivo: " + this.fileToProcess
/* 219 */             .getAbsolutePath(), pe);
/*     */       } 
/*     */     }
/* 222 */     this.linhaProcessada++;
/* 223 */     if (this.linhaProcessada % 100 == 0) {
/* 224 */       this.baseDAO.commit();
/*     */     }
/* 226 */     this.baseDAO.commit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processFile() throws FileNotFoundException, IOException, SQLException, LayoutException {
/* 236 */     String file = this.dataFilePath + this.dataFileName;
/* 237 */     Path path = Paths.get(file, new String[0]);
/* 238 */     BufferedReader reader = Files.newBufferedReader(path, Charset.forName("UTF-8"));
/* 239 */     String linha = null;
/* 240 */     while ((linha = reader.readLine()) != null) {
/* 241 */       this.colunaProcessada = 0;
/* 242 */       if (!linha.isEmpty()) {
/*     */         try {
/* 244 */           linha = linha.replaceAll(" ", " ");
/* 245 */           processLine(linha);
/* 246 */         } catch (ArrayIndexOutOfBoundsException aoe) {
/* 247 */           throw new LayoutException("[JLoader] - Coluna inválida " + 
/* 248 */               col() + ", Linha: " + linha + ", Arquivo: " + this.fileToProcess
/*     */               
/* 250 */               .getAbsolutePath(), aoe);
/*     */         }
/* 252 */         catch (NumberFormatException nfe) {
/* 253 */           throw new LayoutException("[JLoader] - Formato numérico inválido. Col: " + 
/* 254 */               col() + ", Linha: " + linha + ", Arquivo: " + this.fileToProcess
/*     */               
/* 256 */               .getAbsolutePath(), nfe);
/*     */         }
/* 258 */         catch (ParseException pe) {
/* 259 */           throw new LayoutException("[JLoader] - Erro ao realizar parse. Col: " + 
/* 260 */               col() + ", Linha: " + linha + ", Arquivo: " + this.fileToProcess
/*     */               
/* 262 */               .getAbsolutePath(), pe);
/*     */         } 
/*     */       }
/*     */       
/* 266 */       this.linhaProcessada++;
/*     */       
/* 268 */       if (this.linhaProcessada % 100 == 0) {
/* 269 */         this.baseDAO.commit();
/* 270 */         writeLinhaProcessada();
/*     */       } 
/*     */     } 
/* 273 */     this.baseDAO.commit();
/* 274 */     writeLinhaProcessada();
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract void processLineXml(Document paramDocument) throws LayoutException, SQLException, ParseException;
/*     */ 
/*     */   
/*     */   protected abstract void processLine(String paramString) throws LayoutException, SQLException, ParseException;
/*     */   
/*     */   protected String moveArquivo(String dsc, boolean out) throws IOException {
/* 284 */     String dateStr = (new SimpleDateFormat("yyyy'-'MM'/'dd")).format(new Date());
/* 285 */     String fullFile = this.dataFilePath + "/" + this.dataFileName;
/* 286 */     String diretorioProcessed = this.dataFilePath.replaceAll("/in", "/processed/" + dateStr + "/");
/* 287 */     File processedDir = new File(diretorioProcessed);
/* 288 */     if (!processedDir.exists()) {
/* 289 */       processedDir.mkdirs();
/*     */     }
/* 291 */     Files.move(Paths.get(fullFile, new String[0]), Paths.get(diretorioProcessed + "-" + this.dataFileName, new String[0]), new java.nio.file.CopyOption[0]);
/* 292 */     return "created";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void trataErro(int status, Exception e, String desc) {
/*     */     try {
/* 299 */       logger.error("Ocorreu um erro ao processar arquivo: " + this.fileToProcess.getAbsolutePath() + " (" + this.linhaProcessada + "," + this.colunaProcessada + ")", e);
/* 300 */       String newPath = moveArquivo(desc, false);
/* 301 */       alteraStatus(this.codArquivo, status, "(" + this.linhaProcessada + "," + this.colunaProcessada + ")" + e.getMessage(), this.dataFileName, newPath);
/* 302 */     } catch (Exception ex) {
/* 303 */       logger.error("Erro ao alterar status!", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isWhiteSpaces(String s) {
/* 308 */     return (s != null && s.matches("\\s+"));
/*     */   }
/*     */   
/*     */   public boolean isNullOrWhitespace(CharSequence value) {
/* 312 */     if (value == null) {
/* 313 */       return true;
/*     */     }
/* 315 */     for (int i = 0; i < value.length(); i++) {
/* 316 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 317 */         return false;
/*     */       }
/*     */     } 
/* 320 */     return true;
/*     */   }
/*     */   
/*     */   protected void writeLinhaProcessada() throws IOException {}
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\commom\AbstractLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */