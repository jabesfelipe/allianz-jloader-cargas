/*    */ package br.com.accesstage.loader.util.constantes.processo;
/*    */ 
/*    */ import java.sql.Timestamp;
/*    */ import java.text.SimpleDateFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UtilDate
/*    */ {
/*    */   private static final String FORMATO_ANO = "yyyy";
/*    */   private static final String FORMATO_MES = "MM";
/*    */   private static final String FORMATO_DIA = "dd";
/*    */   
/*    */   public static String getAno(Timestamp dtaGeracaoArquivo) {
/* 22 */     return (new SimpleDateFormat("yyyy")).format(Long.valueOf(dtaGeracaoArquivo.getTime()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getMes(Timestamp dtaGeracaoArquivo) {
/* 31 */     return (new SimpleDateFormat("MM")).format(Long.valueOf(dtaGeracaoArquivo.getTime()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getDia(Timestamp dtaGeracaoArquivo) {
/* 40 */     return (new SimpleDateFormat("dd")).format(Long.valueOf(dtaGeracaoArquivo.getTime()));
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\processo\UtilDate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */