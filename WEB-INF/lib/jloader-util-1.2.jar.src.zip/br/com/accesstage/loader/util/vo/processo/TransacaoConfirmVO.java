/*     */ package br.com.accesstage.loader.util.vo.processo;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransacaoConfirmVO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1814254583047980243L;
/*     */   private Long codTransacaoConfirm;
/*     */   private String codAutorizacao;
/*     */   private Long codRetorno;
/*     */   private Timestamp dtaArquivoRetorno;
/*     */   private Timestamp dtaAutorizacao;
/*     */   private String dscIdentArqRet;
/*     */   private String tpoOperacao;
/*     */   private String dscRetorno;
/*     */   private int staCallback;
/*     */   private String nroNsu;
/*     */   private String dscOcorrencia;
/*     */   private List<MensagemRetornoVO> mensagensRetorno;
/*     */   private Integer hraArquivoRetorno;
/*     */   private String codArquivo;
/*     */   private Long nroLinhaArq;
/*     */   private String dataArquivoRetorno;
/*     */   private String dataAutorizacao;
/*     */   private String nroBanco;
/*     */   
/*     */   public void setCodTransacaoConfirm(Long codTransacaoConfirm) {
/*  35 */     this.codTransacaoConfirm = codTransacaoConfirm;
/*     */   }
/*     */   
/*     */   public Long getCodTransacaoConfirm() {
/*  39 */     return this.codTransacaoConfirm;
/*     */   }
/*     */   
/*     */   public void setCodAutorizacao(String codAutorizacao) {
/*  43 */     this.codAutorizacao = codAutorizacao;
/*     */   }
/*     */   
/*     */   public String getCodAutorizacao() {
/*  47 */     return this.codAutorizacao;
/*     */   }
/*     */   
/*     */   public void setCodRetorno(Long codRetorno) {
/*  51 */     this.codRetorno = codRetorno;
/*     */   }
/*     */   
/*     */   public Long getCodRetorno() {
/*  55 */     return this.codRetorno;
/*     */   }
/*     */   
/*     */   public void setDtaArquivoRetorno(Timestamp dtaArquivoRetorno) {
/*  59 */     this.dtaArquivoRetorno = dtaArquivoRetorno;
/*     */   }
/*     */   
/*     */   public Timestamp getDtaArquivoRetorno() {
/*  63 */     return this.dtaArquivoRetorno;
/*     */   }
/*     */   
/*     */   public void setDtaAutorizacao(Timestamp dtaAutorizacao) {
/*  67 */     this.dtaAutorizacao = dtaAutorizacao;
/*     */   }
/*     */   
/*     */   public Timestamp getDtaAutorizacao() {
/*  71 */     return this.dtaAutorizacao;
/*     */   }
/*     */   
/*     */   public void setDscIdentArqRet(String dscIdentArqRet) {
/*  75 */     this.dscIdentArqRet = dscIdentArqRet;
/*     */   }
/*     */   
/*     */   public String getDscIdentArqRet() {
/*  79 */     return this.dscIdentArqRet;
/*     */   }
/*     */   
/*     */   public void setTpoOperacao(String tpoOperacao) {
/*  83 */     this.tpoOperacao = tpoOperacao;
/*     */   }
/*     */   
/*     */   public String getTpoOperacao() {
/*  87 */     return this.tpoOperacao;
/*     */   }
/*     */   
/*     */   public void setDscRetorno(String dscRetorno) {
/*  91 */     this.dscRetorno = dscRetorno;
/*     */   }
/*     */   
/*     */   public String getDscRetorno() {
/*  95 */     return this.dscRetorno;
/*     */   }
/*     */   
/*     */   public void setStaCallback(int staCallback) {
/*  99 */     this.staCallback = staCallback;
/*     */   }
/*     */   
/*     */   public int getStaCallback() {
/* 103 */     return this.staCallback;
/*     */   }
/*     */   
/*     */   public void setNroNsu(String nroNsu) {
/* 107 */     this.nroNsu = nroNsu;
/*     */   }
/*     */   
/*     */   public String getNroNsu() {
/* 111 */     return this.nroNsu;
/*     */   }
/*     */   
/*     */   public void setMensagensRetorno(List<MensagemRetornoVO> mensagensRetorno) {
/* 115 */     this.mensagensRetorno = mensagensRetorno;
/*     */   }
/*     */   
/*     */   public List<MensagemRetornoVO> getMensagensRetorno() {
/* 119 */     return this.mensagensRetorno;
/*     */   }
/*     */   
/*     */   public String getDscOcorrencia() {
/* 123 */     return this.dscOcorrencia;
/*     */   }
/*     */   
/*     */   public void setDscOcorrencia(String dscOcorrencia) {
/* 127 */     this.dscOcorrencia = dscOcorrencia;
/*     */   }
/*     */   
/*     */   public Integer getHraArquivoRetorno() {
/* 131 */     return this.hraArquivoRetorno;
/*     */   }
/*     */   
/*     */   public void setHraArquivoRetorno(Integer hraArquivoRetorno) {
/* 135 */     this.hraArquivoRetorno = hraArquivoRetorno;
/*     */   }
/*     */   
/*     */   public String getCodArquivo() {
/* 139 */     return this.codArquivo;
/*     */   }
/*     */   
/*     */   public void setCodArquivo(String codArquivo) {
/* 143 */     this.codArquivo = codArquivo;
/*     */   }
/*     */   
/*     */   public Long getNroLinhaArq() {
/* 147 */     return this.nroLinhaArq;
/*     */   }
/*     */   
/*     */   public void setNroLinhaArq(Long nroLinhaArq) {
/* 151 */     this.nroLinhaArq = nroLinhaArq;
/*     */   }
/*     */   
/*     */   public String getDataArquivoRetorno() {
/* 155 */     return this.dataArquivoRetorno;
/*     */   }
/*     */   
/*     */   public void setDataArquivoRetorno(String dataArquivoRetorno) {
/* 159 */     this.dataArquivoRetorno = dataArquivoRetorno;
/*     */   }
/*     */   
/*     */   public String getDataAutorizacao() {
/* 163 */     return this.dataAutorizacao;
/*     */   }
/*     */   
/*     */   public void setDataAutorizacao(String dataAutorizacao) {
/* 167 */     this.dataAutorizacao = dataAutorizacao;
/*     */   }
/*     */   
/*     */   public String getNroBanco() {
/* 171 */     return this.nroBanco;
/*     */   }
/*     */   
/*     */   public void setNroBanco(String nroBanco) {
/* 175 */     this.nroBanco = nroBanco;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     return "TransacaoConfirmVO{codTransacaoConfirm= " + this.codTransacaoConfirm + ", codAutorizacao= " + this.codAutorizacao + ", codRetorno= " + this.codRetorno + ", dtaArquivoRetorno= " + this.dtaArquivoRetorno + ", dtaAutorizacao= " + this.dtaAutorizacao + ", dscIdentArqRet= " + this.dscIdentArqRet + ", tpoOperacao= " + this.tpoOperacao + ", dscRetorno= " + this.dscRetorno + ", staCallback= " + this.staCallback + ", nroNsu= " + this.nroNsu + '}';
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\processo\TransacaoConfirmVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */