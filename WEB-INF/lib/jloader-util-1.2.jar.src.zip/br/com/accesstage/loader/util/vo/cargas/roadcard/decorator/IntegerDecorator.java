/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.decorator;
/*    */ 
/*    */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerDecorator
/*    */   extends DefaultFieldDecorator
/*    */ {
/*    */   public Object fromString(String str) {
/* 12 */     if (!"000000".equals(str) && !isNullOrWhitespace(str.trim()) && StringUtils.isNotEmpty(str)) {
/* 13 */       return Integer.valueOf(str);
/*    */     }
/* 15 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isNullOrWhitespace(CharSequence value) {
/* 19 */     if (value == null) {
/* 20 */       return true;
/*    */     }
/* 22 */     for (int i = 0; i < value.length(); i++) {
/* 23 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 24 */         return false;
/*    */       }
/*    */     } 
/* 27 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\decorator\IntegerDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */