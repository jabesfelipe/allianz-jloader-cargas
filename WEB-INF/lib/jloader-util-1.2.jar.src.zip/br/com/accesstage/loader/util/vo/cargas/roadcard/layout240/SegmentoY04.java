/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoY04
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 4227253602151231550L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeq;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegReg;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Integer codMov;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 19)
/*     */   private Integer codRegOpe;
/*     */   @PositionalField(initialPosition = 20, finalPosition = 68)
/*     */   private String dscEmail;
/*     */   @IntegerPositionalField(initialPosition = 69, finalPosition = 70)
/*     */   private Integer codDdd;
/*     */   String nroCelularSrt;
/*     */   @IntegerPositionalField(initialPosition = 71, finalPosition = 78)
/*     */   private Integer nroCelular;
/*     */   @PositionalField(initialPosition = 79, finalPosition = 240)
/*     */   private String dscUsoFbrn2;
/*     */   
/*     */   public String getCodBco() {
/*  45 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  48 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  51 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  54 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  57 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  60 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeq() {
/*  63 */     return this.nroSeq;
/*     */   }
/*     */   public void setNroSeq(Integer nroSeq) {
/*  66 */     this.nroSeq = nroSeq;
/*     */   }
/*     */   public String getCodSegReg() {
/*  69 */     return this.codSegReg;
/*     */   }
/*     */   public void setCodSegReg(String codSegReg) {
/*  72 */     this.codSegReg = codSegReg;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  75 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  78 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMov() {
/*  81 */     return this.codMov;
/*     */   }
/*     */   public void setCodMov(Integer codMov) {
/*  84 */     this.codMov = codMov;
/*     */   }
/*     */   public Integer getCodRegOpe() {
/*  87 */     return this.codRegOpe;
/*     */   }
/*     */   public void setCodRegOpe(Integer codRegOpe) {
/*  90 */     this.codRegOpe = codRegOpe;
/*     */   }
/*     */   public String getDscEmail() {
/*  93 */     return this.dscEmail;
/*     */   }
/*     */   public void setDscEmail(String dscEmail) {
/*  96 */     this.dscEmail = dscEmail;
/*     */   }
/*     */   public Integer getCodDdd() {
/*  99 */     return this.codDdd;
/*     */   }
/*     */   public void setCodDdd(Integer codDdd) {
/* 102 */     this.codDdd = codDdd;
/*     */   }
/*     */   public String getNroCelularSrt() {
/* 105 */     return this.nroCelularSrt;
/*     */   }
/*     */   public void setNroCelularSrt(String nroCelularSrt) {
/* 108 */     this.nroCelularSrt = nroCelularSrt;
/*     */   }
/*     */   public Integer getNroCelular() {
/* 111 */     return this.nroCelular;
/*     */   }
/*     */   public void setNroCelular(Integer nroCelular) {
/* 114 */     this.nroCelular = nroCelular;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 117 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 120 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoY04.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */