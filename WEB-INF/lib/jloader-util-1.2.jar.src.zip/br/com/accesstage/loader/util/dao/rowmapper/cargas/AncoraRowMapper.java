/*    */ package br.com.accesstage.loader.util.dao.rowmapper.cargas;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.Ancora;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class AncoraRowMapper
/*    */   implements RowMapper<Ancora>
/*    */ {
/*    */   public Ancora mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 13 */     Ancora ancora = new Ancora();
/* 14 */     ancora.setCodAncora(rs.getString("COD_ANCORA"));
/* 15 */     return ancora;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\cargas\AncoraRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */