/*    */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.decorator;
/*    */ 
/*    */ import com.github.ffpojo.exception.FieldDecoratorException;
/*    */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateDecorator_YYYYMMDD
/*    */   extends DefaultFieldDecorator
/*    */ {
/*    */   public Object fromString(String str) {
/* 16 */     if (!isNullOrWhitespace(str.trim()) && StringUtils.isNotEmpty(str)) {
/*    */       try {
/* 18 */         if (Integer.valueOf(str).intValue() != 0) {
/* 19 */           return (new SimpleDateFormat("yyyyMMdd")).parse(str);
/*    */         }
/* 21 */         return null;
/*    */       }
/* 23 */       catch (ParseException e) {
/* 24 */         throw new FieldDecoratorException(e);
/*    */       } 
/*    */     }
/* 27 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isNullOrWhitespace(CharSequence value) {
/* 31 */     if (value == null) {
/* 32 */       return true;
/*    */     }
/* 34 */     for (int i = 0; i < value.length(); i++) {
/* 35 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 36 */         return false;
/*    */       }
/*    */     } 
/* 39 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\decorator\DateDecorator_YYYYMMDD.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */