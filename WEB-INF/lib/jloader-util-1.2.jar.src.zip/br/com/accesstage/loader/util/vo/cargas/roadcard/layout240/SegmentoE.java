/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoE
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1240856907743966929L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeq;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegReg;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 17)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private Integer tpoInscEmp;
/*     */   @LongPositionalField(initialPosition = 19, finalPosition = 32)
/*     */   private Long nroInscEmp;
/*     */   @PositionalField(initialPosition = 33, finalPosition = 52)
/*     */   private String codConvenio;
/*     */   @IntegerPositionalField(initialPosition = 53, finalPosition = 57)
/*     */   private Integer dscAgencia;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 58)
/*     */   private String dscAgenciaDV;
/*     */   @LongPositionalField(initialPosition = 59, finalPosition = 70)
/*     */   private Long dscConta;
/*     */   @PositionalField(initialPosition = 71, finalPosition = 71)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 72, finalPosition = 72)
/*     */   private String dscAgCtaDV;
/*     */   @PositionalField(initialPosition = 73, finalPosition = 102)
/*     */   private String nmeEmp;
/*     */   @PositionalField(initialPosition = 103, finalPosition = 108)
/*     */   private String dscUsoFbrn2;
/*     */   @PositionalField(initialPosition = 109, finalPosition = 111)
/*     */   private String dscNatureza;
/*     */   @IntegerPositionalField(initialPosition = 112, finalPosition = 113)
/*     */   private Integer tpoComplLan;
/*     */   @PositionalField(initialPosition = 114, finalPosition = 133)
/*     */   private String dscComplLan;
/*     */   @PositionalField(initialPosition = 134, finalPosition = 134)
/*     */   private String dscIsencaoCPMF;
/*     */   @PositionalField(initialPosition = 135, finalPosition = 142, decorator = DateDecorator240.class)
/*     */   private Date dtaContabil;
/*     */   @PositionalField(initialPosition = 143, finalPosition = 150, decorator = DateDecorator240.class)
/*     */   private Date dtaLancamento;
/*     */   @PositionalField(initialPosition = 151, finalPosition = 168, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrLancamento;
/*     */   @PositionalField(initialPosition = 169, finalPosition = 169)
/*     */   private String tpoLancamento;
/*     */   @IntegerPositionalField(initialPosition = 170, finalPosition = 172)
/*     */   private Integer dscCategoria;
/*     */   @PositionalField(initialPosition = 173, finalPosition = 176)
/*     */   private String codHistBco;
/*     */   @PositionalField(initialPosition = 177, finalPosition = 201)
/*     */   private String dscHistBco;
/*     */   @PositionalField(initialPosition = 202, finalPosition = 240)
/*     */   private String nroDocumento;
/*     */   
/*     */   public String getCodBco() {
/*  81 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  84 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  87 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  90 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  93 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  96 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeq() {
/*  99 */     return this.nroSeq;
/*     */   }
/*     */   public void setNroSeq(Integer nroSeq) {
/* 102 */     this.nroSeq = nroSeq;
/*     */   }
/*     */   public String getCodSegReg() {
/* 105 */     return this.codSegReg;
/*     */   }
/*     */   public void setCodSegReg(String codSegReg) {
/* 108 */     this.codSegReg = codSegReg;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 111 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 114 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getTpoInscEmp() {
/* 117 */     return this.tpoInscEmp;
/*     */   }
/*     */   public void setTpoInscEmp(Integer tpoInscEmp) {
/* 120 */     this.tpoInscEmp = tpoInscEmp;
/*     */   }
/*     */   public Long getNroInscEmp() {
/* 123 */     return this.nroInscEmp;
/*     */   }
/*     */   public void setNroInscEmp(Long nroInscEmp) {
/* 126 */     this.nroInscEmp = nroInscEmp;
/*     */   }
/*     */   public String getCodConvenio() {
/* 129 */     return this.codConvenio;
/*     */   }
/*     */   public void setCodConvenio(String codConvenio) {
/* 132 */     this.codConvenio = codConvenio;
/*     */   }
/*     */   public Integer getDscAgencia() {
/* 135 */     return this.dscAgencia;
/*     */   }
/*     */   public void setDscAgencia(Integer dscAgencia) {
/* 138 */     this.dscAgencia = dscAgencia;
/*     */   }
/*     */   public String getDscAgenciaDV() {
/* 141 */     return this.dscAgenciaDV;
/*     */   }
/*     */   public void setDscAgenciaDV(String dscAgenciaDV) {
/* 144 */     this.dscAgenciaDV = dscAgenciaDV;
/*     */   }
/*     */   public Long getDscConta() {
/* 147 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(Long dscConta) {
/* 150 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 153 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 156 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgCtaDV() {
/* 159 */     return this.dscAgCtaDV;
/*     */   }
/*     */   public void setDscAgCtaDV(String dscAgCtaDV) {
/* 162 */     this.dscAgCtaDV = dscAgCtaDV;
/*     */   }
/*     */   public String getNmeEmp() {
/* 165 */     return this.nmeEmp;
/*     */   }
/*     */   public void setNmeEmp(String nmeEmp) {
/* 168 */     this.nmeEmp = nmeEmp;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 171 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 174 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public String getDscNatureza() {
/* 177 */     return this.dscNatureza;
/*     */   }
/*     */   public void setDscNatureza(String dscNatureza) {
/* 180 */     this.dscNatureza = dscNatureza;
/*     */   }
/*     */   public Integer getTpoComplLan() {
/* 183 */     return this.tpoComplLan;
/*     */   }
/*     */   public void setTpoComplLan(Integer tpoComplLan) {
/* 186 */     this.tpoComplLan = tpoComplLan;
/*     */   }
/*     */   public String getDscComplLan() {
/* 189 */     return this.dscComplLan;
/*     */   }
/*     */   public void setDscComplLan(String dscComplLan) {
/* 192 */     this.dscComplLan = dscComplLan;
/*     */   }
/*     */   public String getDscIsencaoCPMF() {
/* 195 */     return this.dscIsencaoCPMF;
/*     */   }
/*     */   public void setDscIsencaoCPMF(String dscIsencaoCPMF) {
/* 198 */     this.dscIsencaoCPMF = dscIsencaoCPMF;
/*     */   }
/*     */   public Date getDtaContabil() {
/* 201 */     return this.dtaContabil;
/*     */   }
/*     */   public void setDtaContabil(Date dtaContabil) {
/* 204 */     this.dtaContabil = dtaContabil;
/*     */   }
/*     */   public Date getDtaLancamento() {
/* 207 */     return this.dtaLancamento;
/*     */   }
/*     */   public void setDtaLancamento(Date dtaLancamento) {
/* 210 */     this.dtaLancamento = dtaLancamento;
/*     */   }
/*     */   public BigDecimal getVlrLancamento() {
/* 213 */     return this.vlrLancamento;
/*     */   }
/*     */   public void setVlrLancamento(BigDecimal vlrLancamento) {
/* 216 */     this.vlrLancamento = vlrLancamento;
/*     */   }
/*     */   public String getTpoLancamento() {
/* 219 */     return this.tpoLancamento;
/*     */   }
/*     */   public void setTpoLancamento(String tpoLancamento) {
/* 222 */     this.tpoLancamento = tpoLancamento;
/*     */   }
/*     */   public Integer getDscCategoria() {
/* 225 */     return this.dscCategoria;
/*     */   }
/*     */   public void setDscCategoria(Integer dscCategoria) {
/* 228 */     this.dscCategoria = dscCategoria;
/*     */   }
/*     */   public String getCodHistBco() {
/* 231 */     return this.codHistBco;
/*     */   }
/*     */   public void setCodHistBco(String codHistBco) {
/* 234 */     this.codHistBco = codHistBco;
/*     */   }
/*     */   public String getDscHistBco() {
/* 237 */     return this.dscHistBco;
/*     */   }
/*     */   public void setDscHistBco(String dscHistBco) {
/* 240 */     this.dscHistBco = dscHistBco;
/*     */   }
/*     */   public String getNroDocumento() {
/* 243 */     return this.nroDocumento;
/*     */   }
/*     */   public void setNroDocumento(String nroDocumento) {
/* 246 */     this.nroDocumento = nroDocumento;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoE.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */