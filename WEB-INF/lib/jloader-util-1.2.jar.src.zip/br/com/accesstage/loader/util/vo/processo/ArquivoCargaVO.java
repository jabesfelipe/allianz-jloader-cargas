/*     */ package br.com.accesstage.loader.util.vo.processo;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class ArquivoCargaVO
/*     */ {
/*     */   private Long codigoArquivo;
/*     */   private String dscNomeArquivoOrigem;
/*     */   private String dscNomeArquivoDestino;
/*     */   private String dscMd5sum;
/*     */   private String nmePathIn;
/*     */   private String nmePathOut;
/*     */   private String nroRegistros;
/*     */   private Long nroTamanhoArquivo;
/*     */   private String codInstanciaBpel;
/*     */   private Date dthProcessIni;
/*     */   private Date dthProcessFim;
/*     */   private Long empId;
/*     */   private String codTpoLayout;
/*     */   private String dscOrigem;
/*     */   private String codStatus;
/*     */   private Date created;
/*     */   
/*     */   public Long getCodigoArquivo() {
/*  25 */     return this.codigoArquivo;
/*     */   }
/*     */   public void setCodigoArquivo(Long codigoArquivo) {
/*  28 */     this.codigoArquivo = codigoArquivo;
/*     */   }
/*     */   public String getDscNomeArquivoOrigem() {
/*  31 */     return this.dscNomeArquivoOrigem;
/*     */   }
/*     */   public void setDscNomeArquivoOrigem(String dscNomeArquivoOrigem) {
/*  34 */     this.dscNomeArquivoOrigem = dscNomeArquivoOrigem;
/*     */   }
/*     */   public String getDscNomeArquivoDestino() {
/*  37 */     return this.dscNomeArquivoDestino;
/*     */   }
/*     */   public void setDscNomeArquivoDestino(String dscNomeArquivoDestino) {
/*  40 */     this.dscNomeArquivoDestino = dscNomeArquivoDestino;
/*     */   }
/*     */   public String getDscMd5sum() {
/*  43 */     return this.dscMd5sum;
/*     */   }
/*     */   public void setDscMd5sum(String dscMd5sum) {
/*  46 */     this.dscMd5sum = dscMd5sum;
/*     */   }
/*     */   public String getNmePathIn() {
/*  49 */     return this.nmePathIn;
/*     */   }
/*     */   public void setNmePathIn(String nmePathIn) {
/*  52 */     this.nmePathIn = nmePathIn;
/*     */   }
/*     */   public String getNmePathOut() {
/*  55 */     return this.nmePathOut;
/*     */   }
/*     */   public void setNmePathOut(String nmePathOut) {
/*  58 */     this.nmePathOut = nmePathOut;
/*     */   }
/*     */   public String getNroRegistros() {
/*  61 */     return this.nroRegistros;
/*     */   }
/*     */   public void setNroRegistros(String nroRegistros) {
/*  64 */     this.nroRegistros = nroRegistros;
/*     */   }
/*     */   public Long getNroTamanhoArquivo() {
/*  67 */     return this.nroTamanhoArquivo;
/*     */   }
/*     */   public void setNroTamanhoArquivo(Long nroTamanhoArquivo) {
/*  70 */     this.nroTamanhoArquivo = nroTamanhoArquivo;
/*     */   }
/*     */   public String getCodInstanciaBpel() {
/*  73 */     return this.codInstanciaBpel;
/*     */   }
/*     */   public void setCodInstanciaBpel(String codInstanciaBpel) {
/*  76 */     this.codInstanciaBpel = codInstanciaBpel;
/*     */   }
/*     */   public Date getDthProcessIni() {
/*  79 */     return this.dthProcessIni;
/*     */   }
/*     */   public void setDthProcessIni(Date dthProcessIni) {
/*  82 */     this.dthProcessIni = dthProcessIni;
/*     */   }
/*     */   public Date getDthProcessFim() {
/*  85 */     return this.dthProcessFim;
/*     */   }
/*     */   public void setDthProcessFim(Date dthProcessFim) {
/*  88 */     this.dthProcessFim = dthProcessFim;
/*     */   }
/*     */   public Long getEmpId() {
/*  91 */     return this.empId;
/*     */   }
/*     */   public void setEmpId(Long empId) {
/*  94 */     this.empId = empId;
/*     */   }
/*     */   public String getCodTpoLayout() {
/*  97 */     return this.codTpoLayout;
/*     */   }
/*     */   public void setCodTpoLayout(String codTpoLayout) {
/* 100 */     this.codTpoLayout = codTpoLayout;
/*     */   }
/*     */   public String getDscOrigem() {
/* 103 */     return this.dscOrigem;
/*     */   }
/*     */   public void setDscOrigem(String dscOrigem) {
/* 106 */     this.dscOrigem = dscOrigem;
/*     */   }
/*     */   public String getCodStatus() {
/* 109 */     return this.codStatus;
/*     */   }
/*     */   public void setCodStatus(String codStatus) {
/* 112 */     this.codStatus = codStatus;
/*     */   }
/*     */   public Date getCreated() {
/* 115 */     return this.created;
/*     */   }
/*     */   public void setCreated(Date created) {
/* 118 */     this.created = created;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\processo\ArquivoCargaVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */