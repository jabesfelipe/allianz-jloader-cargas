/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.IntegerDecoratorTrailler;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord
/*    */ public class Trailler
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = -7001069781696031420L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*    */   private String codBcoTrllrArq;
/*    */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*    */   private Integer nroLteServico;
/*    */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*    */   private Integer tpoRegTrllrArq;
/*    */   @PositionalField(initialPosition = 9, finalPosition = 17)
/*    */   private String dscUsoFbrn1;
/*    */   @IntegerPositionalField(initialPosition = 18, finalPosition = 23)
/*    */   private Integer qtdLteArq;
/*    */   @IntegerPositionalField(initialPosition = 24, finalPosition = 29)
/*    */   private Integer qtdRegArq;
/*    */   @PositionalField(initialPosition = 30, finalPosition = 35, decorator = IntegerDecoratorTrailler.class)
/*    */   private Integer qtdContaConcArq;
/*    */   @PositionalField(initialPosition = 36, finalPosition = 240)
/*    */   private String dscUsoFbrn2;
/*    */   
/*    */   public String getCodBcoTrllrArq() {
/* 36 */     return this.codBcoTrllrArq;
/*    */   }
/*    */   public void setCodBcoTrllrArq(String codBcoTrllrArq) {
/* 39 */     this.codBcoTrllrArq = codBcoTrllrArq;
/*    */   }
/*    */   public Integer getNroLteServico() {
/* 42 */     return this.nroLteServico;
/*    */   }
/*    */   public void setNroLteServico(Integer nroLteServico) {
/* 45 */     this.nroLteServico = nroLteServico;
/*    */   }
/*    */   public Integer getTpoRegTrllrArq() {
/* 48 */     return this.tpoRegTrllrArq;
/*    */   }
/*    */   public void setTpoRegTrllrArq(Integer tpoRegTrllrArq) {
/* 51 */     this.tpoRegTrllrArq = tpoRegTrllrArq;
/*    */   }
/*    */   public String getDscUsoFbrn1() {
/* 54 */     return this.dscUsoFbrn1;
/*    */   }
/*    */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 57 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*    */   }
/*    */   public Integer getQtdLteArq() {
/* 60 */     return this.qtdLteArq;
/*    */   }
/*    */   public void setQtdLteArq(Integer qtdLteArq) {
/* 63 */     this.qtdLteArq = qtdLteArq;
/*    */   }
/*    */   public Integer getQtdRegArq() {
/* 66 */     return this.qtdRegArq;
/*    */   }
/*    */   public void setQtdRegArq(Integer qtdRegArq) {
/* 69 */     this.qtdRegArq = qtdRegArq;
/*    */   }
/*    */   public Integer getQtdContaConcArq() {
/* 72 */     return this.qtdContaConcArq;
/*    */   }
/*    */   public void setQtdContaConcArq(Integer qtdContaConcArq) {
/* 75 */     this.qtdContaConcArq = qtdContaConcArq;
/*    */   }
/*    */   public String getDscUsoFbrn2() {
/* 78 */     return this.dscUsoFbrn2;
/*    */   }
/*    */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 81 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\Trailler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */