/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator;
/*    */ 
/*    */ import br.com.accesstage.loader.util.constantes.carga.Format;
/*    */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerDecorator240
/*    */   extends DefaultFieldDecorator
/*    */ {
/*    */   public Object fromString(String str) {
/* 12 */     if (!"".equalsIgnoreCase(str) && !str.trim().isEmpty()) {
/* 13 */       return Integer.valueOf(str);
/*    */     }
/* 15 */     return Integer.valueOf(Format.insereZerosEsquerda(str, 3));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNullOrWhitespace(CharSequence value) {
/* 20 */     if (value == null) {
/* 21 */       return true;
/*    */     }
/* 23 */     for (int i = 0; i < value.length(); i++) {
/* 24 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 25 */         return false;
/*    */       }
/*    */     } 
/* 28 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\decorator\IntegerDecorator240.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */