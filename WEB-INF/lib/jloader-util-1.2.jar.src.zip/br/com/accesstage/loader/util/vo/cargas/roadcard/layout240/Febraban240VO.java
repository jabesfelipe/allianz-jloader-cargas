/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Febraban240VO
/*     */ {
/*     */   private Header header;
/*     */   private Trailler trailler;
/*  31 */   private List<HdrLteCobL045> listHdrLteCobL045 = new ArrayList<HdrLteCobL045>();
/*  32 */   private List<HeaderL043> listHeaderL043 = new ArrayList<HeaderL043>();
/*  33 */   private List<TraillerL043> listTraillerL043 = new ArrayList<TraillerL043>();
/*  34 */   private List<TraillerCobL045> listTraillerCobL045 = new ArrayList<TraillerCobL045>();
/*  35 */   private List<HdrExtL033> listHdrExtL033 = new ArrayList<HdrExtL033>();
/*  36 */   private List<TrllExtL033> listTrllExtL033 = new ArrayList<TrllExtL033>();
/*  37 */   private List<SegmentoU> listSegmentoU = new ArrayList<SegmentoU>();
/*  38 */   private List<SegmentoT> listSegmentoT = new ArrayList<SegmentoT>();
/*  39 */   private List<SegmentY50> listSegmentY50 = new ArrayList<SegmentY50>();
/*  40 */   private List<SegmentoY04> listSegmentoY04 = new ArrayList<SegmentoY04>();
/*  41 */   private List<SegmentoP> listSegmentoP = new ArrayList<SegmentoP>();
/*  42 */   private List<SegmentoQ> listSegmentoQ = new ArrayList<SegmentoQ>();
/*  43 */   private List<SegmentoR> listSegmentoR = new ArrayList<SegmentoR>();
/*  44 */   private List<SegmentoSImpressao3> listSegmentoSImpressao3 = new ArrayList<SegmentoSImpressao3>();
/*  45 */   private List<SegmentoS> listSegmentoS = new ArrayList<SegmentoS>();
/*  46 */   private List<SegmentoE> listSegmentoE = new ArrayList<SegmentoE>();
/*  47 */   private List<SegmentoA> listSegmentoA = new ArrayList<SegmentoA>();
/*  48 */   private List<SegmentoB> listSegmentoB = new ArrayList<SegmentoB>();
/*  49 */   private List<SegmentoC> listSegmentoC = new ArrayList<SegmentoC>();
/*     */ 
/*     */   
/*     */   public Header getHeader() {
/*  53 */     return this.header;
/*     */   }
/*     */   public void setHeader(Header header) {
/*  56 */     this.header = header;
/*     */   }
/*     */   public Trailler getTrailler() {
/*  59 */     return this.trailler;
/*     */   }
/*     */   public void setTrailler(Trailler trailler) {
/*  62 */     this.trailler = trailler;
/*     */   }
/*     */   public List<HdrLteCobL045> getListHdrLteCobL045() {
/*  65 */     return this.listHdrLteCobL045;
/*     */   }
/*     */   public void setListHdrLteCobL045(List<HdrLteCobL045> listHdrLteCobL045) {
/*  68 */     this.listHdrLteCobL045 = listHdrLteCobL045;
/*     */   }
/*     */   public List<HeaderL043> getListHeaderL043() {
/*  71 */     return this.listHeaderL043;
/*     */   }
/*     */   public void setListHeaderL043(List<HeaderL043> listHeaderL043) {
/*  74 */     this.listHeaderL043 = listHeaderL043;
/*     */   }
/*     */   public List<TraillerL043> getListTraillerL043() {
/*  77 */     return this.listTraillerL043;
/*     */   }
/*     */   public void setListTraillerL043(List<TraillerL043> listTraillerL043) {
/*  80 */     this.listTraillerL043 = listTraillerL043;
/*     */   }
/*     */   public List<TraillerCobL045> getListTraillerCobL045() {
/*  83 */     return this.listTraillerCobL045;
/*     */   }
/*     */   public void setListTraillerCobL045(List<TraillerCobL045> listTraillerCobL045) {
/*  86 */     this.listTraillerCobL045 = listTraillerCobL045;
/*     */   }
/*     */   public List<HdrExtL033> getListHdrExtL033() {
/*  89 */     return this.listHdrExtL033;
/*     */   }
/*     */   public void setListHdrExtL033(List<HdrExtL033> listHdrExtL033) {
/*  92 */     this.listHdrExtL033 = listHdrExtL033;
/*     */   }
/*     */   public List<TrllExtL033> getListTrllExtL033() {
/*  95 */     return this.listTrllExtL033;
/*     */   }
/*     */   public void setListTrllExtL033(List<TrllExtL033> listTrllExtL033) {
/*  98 */     this.listTrllExtL033 = listTrllExtL033;
/*     */   }
/*     */   public List<SegmentoU> getListSegmentoU() {
/* 101 */     return this.listSegmentoU;
/*     */   }
/*     */   public void setListSegmentoU(List<SegmentoU> listSegmentoU) {
/* 104 */     this.listSegmentoU = listSegmentoU;
/*     */   }
/*     */   public List<SegmentoT> getListSegmentoT() {
/* 107 */     return this.listSegmentoT;
/*     */   }
/*     */   public void setListSegmentoT(List<SegmentoT> listSegmentoT) {
/* 110 */     this.listSegmentoT = listSegmentoT;
/*     */   }
/*     */   public List<SegmentY50> getListSegmentY50() {
/* 113 */     return this.listSegmentY50;
/*     */   }
/*     */   public void setListSegmentY50(List<SegmentY50> listSegmentY50) {
/* 116 */     this.listSegmentY50 = listSegmentY50;
/*     */   }
/*     */   public List<SegmentoY04> getListSegmentoY04() {
/* 119 */     return this.listSegmentoY04;
/*     */   }
/*     */   public void setListSegmentoY04(List<SegmentoY04> listSegmentoY04) {
/* 122 */     this.listSegmentoY04 = listSegmentoY04;
/*     */   }
/*     */   public List<SegmentoP> getListSegmentoP() {
/* 125 */     return this.listSegmentoP;
/*     */   }
/*     */   public void setListSegmentoP(List<SegmentoP> listSegmentoP) {
/* 128 */     this.listSegmentoP = listSegmentoP;
/*     */   }
/*     */   public List<SegmentoQ> getListSegmentoQ() {
/* 131 */     return this.listSegmentoQ;
/*     */   }
/*     */   public void setListSegmentoQ(List<SegmentoQ> listSegmentoQ) {
/* 134 */     this.listSegmentoQ = listSegmentoQ;
/*     */   }
/*     */   public List<SegmentoR> getListSegmentoR() {
/* 137 */     return this.listSegmentoR;
/*     */   }
/*     */   public void setListSegmentoR(List<SegmentoR> listSegmentoR) {
/* 140 */     this.listSegmentoR = listSegmentoR;
/*     */   }
/*     */   public List<SegmentoSImpressao3> getListSegmentSImpressao3() {
/* 143 */     return this.listSegmentoSImpressao3;
/*     */   }
/*     */   public void setListSegmentSImpressao3(List<SegmentoSImpressao3> listSegmentSImpressao3) {
/* 146 */     this.listSegmentoSImpressao3 = listSegmentSImpressao3;
/*     */   }
/*     */   public List<SegmentoS> getListSegmentoS() {
/* 149 */     return this.listSegmentoS;
/*     */   }
/*     */   public void setListSegmentoS(List<SegmentoS> listSegmentoS) {
/* 152 */     this.listSegmentoS = listSegmentoS;
/*     */   }
/*     */   public List<SegmentoSImpressao3> getListSegmentoSImpressao3() {
/* 155 */     return this.listSegmentoSImpressao3;
/*     */   }
/*     */   public void setListSegmentoSImpressao3(List<SegmentoSImpressao3> listSegmentoSImpressao3) {
/* 158 */     this.listSegmentoSImpressao3 = listSegmentoSImpressao3;
/*     */   }
/*     */   public List<SegmentoE> getListSegmentoE() {
/* 161 */     return this.listSegmentoE;
/*     */   }
/*     */   public void setListSegmentoE(List<SegmentoE> listSegmentoE) {
/* 164 */     this.listSegmentoE = listSegmentoE;
/*     */   }
/*     */   public List<SegmentoA> getListSegmentoA() {
/* 167 */     return this.listSegmentoA;
/*     */   }
/*     */   public void setListSegmentoA(List<SegmentoA> listSegmentoA) {
/* 170 */     this.listSegmentoA = listSegmentoA;
/*     */   }
/*     */   public List<SegmentoB> getListSegmentoB() {
/* 173 */     return this.listSegmentoB;
/*     */   }
/*     */   public void setListSegmentoB(List<SegmentoB> listSegmentoB) {
/* 176 */     this.listSegmentoB = listSegmentoB;
/*     */   }
/*     */   public List<SegmentoC> getListSegmentoC() {
/* 179 */     return this.listSegmentoC;
/*     */   }
/*     */   public void setListSegmentoC(List<SegmentoC> listSegmentoC) {
/* 182 */     this.listSegmentoC = listSegmentoC;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\Febraban240VO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */