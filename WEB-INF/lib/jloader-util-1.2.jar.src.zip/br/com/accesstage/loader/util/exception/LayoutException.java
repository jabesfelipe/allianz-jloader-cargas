/*    */ package br.com.accesstage.loader.util.exception;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class LayoutException
/*    */   extends Exception {
/*    */   private static final long serialVersionUID = 8354902898829431936L;
/*  8 */   private static Logger logger = Logger.getLogger(LayoutException.class.getName());
/*    */   
/*    */   public LayoutException(String message, Throwable cause) {
/* 11 */     super(message, cause);
/* 12 */     logger.error(message, cause);
/*    */   }
/*    */   
/*    */   public LayoutException(String message) {
/* 16 */     super(message);
/* 17 */     logger.error(message);
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\exception\LayoutException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */