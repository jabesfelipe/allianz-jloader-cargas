/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoSImpressao3
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -4891901373318847948L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeq;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegReg;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 15, finalPosition = 16)
/*     */   private Integer codMovRmss;
/*     */   @IntegerPositionalField(initialPosition = 17, finalPosition = 17)
/*     */   private Integer codTpoImpressao;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 57)
/*     */   private String dscInformacao5;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 97)
/*     */   private String dscInformacao6;
/*     */   @PositionalField(initialPosition = 98, finalPosition = 137)
/*     */   private String dscInformacao7;
/*     */   @PositionalField(initialPosition = 138, finalPosition = 177)
/*     */   private String dscInformacao8;
/*     */   @PositionalField(initialPosition = 178, finalPosition = 217)
/*     */   private String dscInformacao9;
/*     */   @PositionalField(initialPosition = 218, finalPosition = 240)
/*     */   private String dscUsoFebraban3;
/*     */   
/*     */   public String getCodBco() {
/*  47 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  50 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  53 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  56 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  59 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  62 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeq() {
/*  65 */     return this.nroSeq;
/*     */   }
/*     */   public void setNroSeq(Integer nroSeq) {
/*  68 */     this.nroSeq = nroSeq;
/*     */   }
/*     */   public String getCodSegReg() {
/*  71 */     return this.codSegReg;
/*     */   }
/*     */   public void setCodSegReg(String codSegReg) {
/*  74 */     this.codSegReg = codSegReg;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/*  77 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/*  80 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMovRmss() {
/*  83 */     return this.codMovRmss;
/*     */   }
/*     */   public void setCodMovRmss(Integer codMovRmss) {
/*  86 */     this.codMovRmss = codMovRmss;
/*     */   }
/*     */   public Integer getCodTpoImpressao() {
/*  89 */     return this.codTpoImpressao;
/*     */   }
/*     */   public void setCodTpoImpressao(Integer codTpoImpressao) {
/*  92 */     this.codTpoImpressao = codTpoImpressao;
/*     */   }
/*     */   public String getDscInformacao5() {
/*  95 */     return this.dscInformacao5;
/*     */   }
/*     */   public void setDscInformacao5(String dscInformacao5) {
/*  98 */     this.dscInformacao5 = dscInformacao5;
/*     */   }
/*     */   public String getDscInformacao6() {
/* 101 */     return this.dscInformacao6;
/*     */   }
/*     */   public void setDscInformacao6(String dscInformacao6) {
/* 104 */     this.dscInformacao6 = dscInformacao6;
/*     */   }
/*     */   public String getDscInformacao7() {
/* 107 */     return this.dscInformacao7;
/*     */   }
/*     */   public void setDscInformacao7(String dscInformacao7) {
/* 110 */     this.dscInformacao7 = dscInformacao7;
/*     */   }
/*     */   public String getDscInformacao8() {
/* 113 */     return this.dscInformacao8;
/*     */   }
/*     */   public void setDscInformacao8(String dscInformacao8) {
/* 116 */     this.dscInformacao8 = dscInformacao8;
/*     */   }
/*     */   public String getDscInformacao9() {
/* 119 */     return this.dscInformacao9;
/*     */   }
/*     */   public void setDscInformacao9(String dscInformacao9) {
/* 122 */     this.dscInformacao9 = dscInformacao9;
/*     */   }
/*     */   public String getDscUsoFebraban3() {
/* 125 */     return this.dscUsoFebraban3;
/*     */   }
/*     */   public void setDscUsoFebraban3(String dscUsoFebraban3) {
/* 128 */     this.dscUsoFebraban3 = dscUsoFebraban3;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoSImpressao3.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */