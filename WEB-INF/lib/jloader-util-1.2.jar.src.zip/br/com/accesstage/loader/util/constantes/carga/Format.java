/*     */ package br.com.accesstage.loader.util.constantes.carga;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Format
/*     */ {
/*     */   public static final String FIM_LINHA = "\r\n";
/*  17 */   private static String acentuado = "";
/*  18 */   private static String semAcento = "cCaeiouyAEIOUYaeiouAEIOUaonaeiouyAEIOUAONaeiouAEIOU";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  23 */   private static char[] tabela = new char[256]; static {
/*     */     int i;
/*  25 */     for (i = 0; i < tabela.length; i++)
/*     */     {
/*  27 */       tabela[i] = (char)i;
/*     */     }
/*  29 */     for (i = 0; i < acentuado.length(); i++) {
/*  30 */       tabela[acentuado.charAt(i)] = semAcento.charAt(i);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String numerico(long value, int numZeros) {
/*  35 */     return insereZerosEsquerda(String.valueOf(value), numZeros);
/*     */   }
/*     */   
/*     */   public static String alfa(String value, int numEspacos) {
/*  39 */     return insereEspacosDireita(value, numEspacos);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String numericoDecimal(double value, int tamanho, int tamanhoDecimal) {
/*  44 */     return formatDecimal(value, tamanho, tamanhoDecimal);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String formatDecimal(double value, int intLength, int decimalLength) {
/*  49 */     String s = arredondaDecimalString(value, decimalLength);
/*     */     
/*  51 */     String intPart = insereZerosEsquerda(s.substring(0, s.lastIndexOf('.')), intLength);
/*     */     
/*  53 */     String decPart = insereZerosDireita(s.substring(s.lastIndexOf('.') + 1), decimalLength);
/*     */     
/*  55 */     return intPart + decPart;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String arredondaDecimalString(double valor, int casasDecimais) {
/*  60 */     return (new BigDecimal(valor)).setScale(casasDecimais, 4)
/*  61 */       .toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String insereEspacosEsquerda(String pValue, int pLength) {
/*  66 */     String value = pValue;
/*     */     
/*  68 */     if (value == null) {
/*  69 */       value = "";
/*     */     }
/*     */     
/*  72 */     StringBuffer sb = new StringBuffer();
/*  73 */     int size = pLength - value.length();
/*     */     
/*  75 */     for (int i = 0; i < size; i++) {
/*  76 */       sb.append(" ");
/*     */     }
/*  78 */     sb.append(value);
/*     */     
/*  80 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String repeteString(String carac, int length) {
/*  84 */     StringBuffer sb = new StringBuffer();
/*  85 */     for (int i = 0; i < length; i++) {
/*  86 */       sb.append(carac);
/*     */     }
/*  88 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String insereEspacosDireita(String pValue, int pLength) {
/*  93 */     String value = pValue;
/*     */     
/*  95 */     if (value == null) {
/*  96 */       value = "";
/*     */     }
/*     */     
/*  99 */     if (value.length() > pLength) {
/* 100 */       return value.substring(0, pLength);
/*     */     }
/*     */     
/* 103 */     StringBuffer sb = new StringBuffer();
/* 104 */     int size = pLength - value.length();
/*     */     
/* 106 */     sb.append(value);
/* 107 */     for (int i = 0; i < size; i++) {
/* 108 */       sb.append(" ");
/*     */     }
/*     */     
/* 111 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String insereZerosEsquerda(String pValue, int pLength) {
/* 116 */     String value = pValue;
/*     */     
/* 118 */     if (value == null) {
/* 119 */       value = "";
/*     */     }
/*     */     
/* 122 */     value = value.trim();
/*     */     
/* 124 */     StringBuffer sb = new StringBuffer();
/* 125 */     int size = pLength - value.length();
/*     */     
/* 127 */     for (int i = 0; i < size; i++) {
/* 128 */       sb.append("0");
/*     */     }
/* 130 */     sb.append(value);
/*     */     
/* 132 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String insereZerosDireita(String pValue, int pLength) {
/* 137 */     String value = pValue;
/*     */     
/* 139 */     if (value == null) {
/* 140 */       value = "";
/*     */     }
/* 142 */     value = pValue.trim();
/*     */     
/* 144 */     StringBuffer sb = new StringBuffer();
/* 145 */     int size = pLength - value.length();
/*     */     
/* 147 */     sb.append(value);
/* 148 */     for (int i = 0; i < size; i++) {
/* 149 */       sb.append("0");
/*     */     }
/*     */     
/* 152 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String removerAcentos(String s) {
/* 157 */     StringBuffer sb = null;
/*     */     
/* 159 */     if (s != null) {
/*     */       
/* 161 */       sb = new StringBuffer();
/*     */       
/* 163 */       for (int i = 0; i < s.length(); i++) {
/*     */         
/* 165 */         char ch = s.charAt(i);
/*     */         
/* 167 */         if (ch < 'Ā') {
/* 168 */           sb.append(tabela[ch]);
/*     */         } else {
/* 170 */           sb.append(ch);
/*     */         } 
/*     */       } 
/*     */       
/* 174 */       return sb.toString();
/*     */     } 
/*     */     
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isNumber(Object object) {
/*     */     try {
/* 183 */       new BigInteger(object.toString());
/* 184 */     } catch (Exception e) {
/* 185 */       return false;
/*     */     } 
/*     */     
/* 188 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String removerZerosAEsquerda(String value) {
/* 194 */     String value2 = value;
/*     */     
/* 196 */     if (value2 != null)
/*     */     {
/* 198 */       while (value2.charAt(0) == '0') {
/* 199 */         value2 = value2.substring(1, value2.length());
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 204 */     return value2;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String dateAsString(Date date) {
/* 209 */     SimpleDateFormat dateToString = new SimpleDateFormat("yyyyMMdd");
/* 210 */     String result = "00000000";
/*     */     
/*     */     try {
/* 213 */       if (date != null) {
/* 214 */         result = dateToString.format(date);
/*     */       }
/*     */     }
/* 217 */     catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 221 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static BigDecimal formataValorString(String vlrStr) {
/* 226 */     String vlrTemp = null;
/*     */     
/* 228 */     if (vlrStr != null && !"".equals(vlrStr) && vlrStr.length() >= 2) {
/*     */       
/* 230 */       vlrTemp = vlrStr.substring(0, insereZerosEsquerda(vlrStr, vlrStr.length()).length() - 2) + "." + vlrStr.substring(vlrStr.length() - 2, vlrStr.length());
/*     */     } else {
/* 232 */       vlrTemp = "0";
/*     */     } 
/* 234 */     return new BigDecimal(vlrTemp);
/*     */   }
/*     */   
/*     */   public static BigDecimal formataValorStr6CasasDec(String vlrStr) {
/* 238 */     String vlrTemp = null;
/*     */     
/* 240 */     BigDecimal vlrFormatado = BigDecimal.ZERO;
/*     */     
/* 242 */     if (vlrStr != null && !"".equals(vlrStr)) {
/*     */       
/* 244 */       vlrTemp = vlrStr.substring(0, insereZerosEsquerda(vlrStr, 7).length() - 6) + "." + vlrStr.substring(vlrStr.length() - 6, vlrStr.length());
/*     */     } else {
/* 246 */       vlrTemp = "0";
/*     */     } 
/*     */     
/* 249 */     vlrFormatado = new BigDecimal(vlrTemp);
/* 250 */     return vlrFormatado;
/*     */   }
/*     */   
/*     */   public static BigDecimal formataValorStr4CasasDec(String vlrStr) {
/* 254 */     String vlrTemp = null;
/*     */     
/* 256 */     BigDecimal vlrFormatado = BigDecimal.ZERO;
/*     */     
/* 258 */     if (vlrStr != null && !"".equals(vlrStr)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 263 */       vlrTemp = vlrStr.substring(0, insereZerosEsquerda(vlrStr, 7).length() - 4) + "." + vlrStr.substring(vlrStr.length() - 4, vlrStr.length());
/*     */     } else {
/* 265 */       vlrTemp = "0";
/*     */     } 
/*     */     
/* 268 */     vlrFormatado = new BigDecimal(vlrTemp);
/* 269 */     return vlrFormatado;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal formataValorString7CasasDec(String vlrStr) {
/* 281 */     String vlrTemp = null;
/*     */     
/* 283 */     if (vlrStr != null && !"".equals(vlrStr) && vlrStr.length() >= 7) {
/*     */ 
/*     */ 
/*     */       
/* 287 */       vlrTemp = vlrStr.substring(0, insereZerosEsquerda(vlrStr, vlrStr.length()).length() - 7) + "." + vlrStr.substring(vlrStr.length() - 7, vlrStr.length());
/*     */     } else {
/* 289 */       vlrTemp = "0";
/*     */     } 
/* 291 */     return new BigDecimal(vlrTemp);
/*     */   }
/*     */   
/*     */   public static int strToInteger(String valueStr) {
/* 295 */     return Integer.parseInt(valueStr);
/*     */   }
/*     */   
/*     */   public static long strToLong(String valueStr) {
/* 299 */     return Long.parseLong(valueStr);
/*     */   }
/*     */   
/*     */   public static double strToDouble(String valueStr) {
/* 303 */     return Double.valueOf(valueStr).doubleValue() / 100.0D;
/*     */   }
/*     */   
/*     */   public static BigDecimal strToBigDecimal(String valueStr) {
/* 307 */     return BigDecimal.valueOf(strToLong(valueStr)).divide(BigDecimal.valueOf(100L));
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\carga\Format.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */