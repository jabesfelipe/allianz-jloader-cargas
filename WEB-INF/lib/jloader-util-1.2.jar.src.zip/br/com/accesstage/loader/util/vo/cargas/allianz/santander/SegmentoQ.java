/*     */ package br.com.accesstage.loader.util.vo.cargas.allianz.santander;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.IntegerDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.PaddingAlign;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoQ
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -2259409405669711890L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*  22 */   private String codBco = "033";
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*  24 */   private String lteServico = "0001";
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*  26 */   private String tpoReg = "3";
/*     */   @PositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private String nroSeqLte;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*  30 */   private String codSegRegDtlh = "Q";
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*  32 */   private String dscUsoFbrn1 = " ";
/*     */   @PositionalField(initialPosition = 16, finalPosition = 17, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*  34 */   private String codMovRmss = "01";
/*     */   
/*     */   @PositionalField(initialPosition = 18, finalPosition = 18, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String tpoInsc;
/*     */   @PositionalField(initialPosition = 19, finalPosition = 33, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String nroInsc;
/*     */   @PositionalField(initialPosition = 34, finalPosition = 73, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String nome;
/*     */   @PositionalField(initialPosition = 74, finalPosition = 113, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String endereco;
/*     */   @PositionalField(initialPosition = 114, finalPosition = 128, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String bairro;
/*     */   @PositionalField(initialPosition = 129, finalPosition = 133, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String nroCep;
/*     */   @PositionalField(initialPosition = 134, finalPosition = 136, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String nroCepSufixo;
/*     */   @PositionalField(initialPosition = 137, finalPosition = 151, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String nmeCidade;
/*     */   @PositionalField(initialPosition = 152, finalPosition = 153, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String uf;
/*     */   @PositionalField(initialPosition = 154, finalPosition = 154, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String tpoInsc2;
/*     */   @LongPositionalField(initialPosition = 155, finalPosition = 169, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private Long nroInsc2;
/*     */   @PositionalField(initialPosition = 170, finalPosition = 209, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String nmeAvalista;
/*     */   @PositionalField(initialPosition = 210, finalPosition = 212, decorator = IntegerDecorator240.class, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private Integer codCompensacao;
/*     */   @PositionalField(initialPosition = 213, finalPosition = 215, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String nroNosso;
/*     */   @PositionalField(initialPosition = 216, finalPosition = 218, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String qtdeParcelas;
/*     */   @PositionalField(initialPosition = 219, finalPosition = 221, paddingAlign = PaddingAlign.RIGHT, paddingCharacter = '0')
/*     */   private String numeroPlano;
/*     */   @PositionalField(initialPosition = 222, finalPosition = 240, paddingAlign = PaddingAlign.LEFT, paddingCharacter = ' ')
/*     */   private String dscUsoFbrn2;
/*     */   
/*     */   public String getCodBco() {
/*  72 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  75 */     this.codBco = codBco;
/*     */   }
/*     */   public String getLteServico() {
/*  78 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(String lteServico) {
/*  81 */     this.lteServico = lteServico;
/*     */   }
/*     */   public String getTpoReg() {
/*  84 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(String tpoReg) {
/*  87 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public String getNroSeqLte() {
/*  90 */     return this.nroSeqLte;
/*     */   }
/*     */   public void setNroSeqLte(String nroSeqLte) {
/*  93 */     this.nroSeqLte = nroSeqLte;
/*     */   }
/*     */   public String getCodSegRegDtlh() {
/*  96 */     return this.codSegRegDtlh;
/*     */   }
/*     */   public void setCodSegRegDtlh(String codSegRegDtlh) {
/*  99 */     this.codSegRegDtlh = codSegRegDtlh;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 102 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 105 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public String getCodMovRmss() {
/* 108 */     return this.codMovRmss;
/*     */   }
/*     */   public void setCodMovRmss(String codMovRmss) {
/* 111 */     this.codMovRmss = codMovRmss;
/*     */   }
/*     */   public String getTpoInsc() {
/* 114 */     return this.tpoInsc;
/*     */   }
/*     */   public void setTpoInsc(String tpoInsc) {
/* 117 */     this.tpoInsc = tpoInsc;
/*     */   }
/*     */   public String getNroInsc() {
/* 120 */     return this.nroInsc;
/*     */   }
/*     */   public void setNroInsc(String nroInsc) {
/* 123 */     this.nroInsc = nroInsc;
/*     */   }
/*     */   public String getNome() {
/* 126 */     return this.nome;
/*     */   }
/*     */   public void setNome(String nome) {
/* 129 */     this.nome = nome;
/*     */   }
/*     */   public String getEndereco() {
/* 132 */     return this.endereco;
/*     */   }
/*     */   public void setEndereco(String endereco) {
/* 135 */     this.endereco = endereco;
/*     */   }
/*     */   public String getBairro() {
/* 138 */     return this.bairro;
/*     */   }
/*     */   public void setBairro(String bairro) {
/* 141 */     this.bairro = bairro;
/*     */   }
/*     */   public String getNroCep() {
/* 144 */     return this.nroCep;
/*     */   }
/*     */   public void setNroCep(String nroCep) {
/* 147 */     this.nroCep = nroCep;
/*     */   }
/*     */   public String getNroCepSufixo() {
/* 150 */     return this.nroCepSufixo;
/*     */   }
/*     */   public void setNroCepSufixo(String nroCepSufixo) {
/* 153 */     this.nroCepSufixo = nroCepSufixo;
/*     */   }
/*     */   public String getNmeCidade() {
/* 156 */     return this.nmeCidade;
/*     */   }
/*     */   public void setNmeCidade(String nmeCidade) {
/* 159 */     this.nmeCidade = nmeCidade;
/*     */   }
/*     */   public String getUf() {
/* 162 */     return this.uf;
/*     */   }
/*     */   public void setUf(String uf) {
/* 165 */     this.uf = uf;
/*     */   }
/*     */   public String getTpoInsc2() {
/* 168 */     return this.tpoInsc2;
/*     */   }
/*     */   public void setTpoInsc2(String tpoInsc2) {
/* 171 */     this.tpoInsc2 = tpoInsc2;
/*     */   }
/*     */   public Long getNroInsc2() {
/* 174 */     return this.nroInsc2;
/*     */   }
/*     */   public void setNroInsc2(Long nroInsc2) {
/* 177 */     this.nroInsc2 = nroInsc2;
/*     */   }
/*     */   public String getNmeAvalista() {
/* 180 */     return this.nmeAvalista;
/*     */   }
/*     */   public void setNmeAvalista(String nmeAvalista) {
/* 183 */     this.nmeAvalista = nmeAvalista;
/*     */   }
/*     */   public Integer getCodCompensacao() {
/* 186 */     return this.codCompensacao;
/*     */   }
/*     */   public void setCodCompensacao(Integer codCompensacao) {
/* 189 */     this.codCompensacao = codCompensacao;
/*     */   }
/*     */   public String getNroNosso() {
/* 192 */     return this.nroNosso;
/*     */   }
/*     */   public void setNroNosso(String nroNosso) {
/* 195 */     this.nroNosso = nroNosso;
/*     */   }
/*     */   public String getQtdeParcelas() {
/* 198 */     return this.qtdeParcelas;
/*     */   }
/*     */   public void setQtdeParcelas(String qtdeParcelas) {
/* 201 */     this.qtdeParcelas = qtdeParcelas;
/*     */   }
/*     */   public String getNumeroPlano() {
/* 204 */     return this.numeroPlano;
/*     */   }
/*     */   public void setNumeroPlano(String numeroPlano) {
/* 207 */     this.numeroPlano = numeroPlano;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 210 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 213 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\santander\SegmentoQ.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */