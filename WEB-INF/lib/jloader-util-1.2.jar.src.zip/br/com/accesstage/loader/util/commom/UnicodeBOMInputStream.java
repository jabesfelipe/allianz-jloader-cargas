/*     */ package br.com.accesstage.loader.util.commom;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnicodeBOMInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private final PushbackInputStream in;
/*     */   private final BOM bom;
/*     */   private boolean skipped;
/*     */   
/*     */   public static final class BOM
/*     */   {
/*  40 */     public static final BOM NONE = new BOM(new byte[0], "NONE");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  45 */     public static final BOM UTF_8 = new BOM(new byte[] { -17, -69, -65 }, "UTF-8");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     public static final BOM UTF_16_LE = new BOM(new byte[] { -1, -2 }, "UTF-16 little-endian");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     public static final BOM UTF_16_BE = new BOM(new byte[] { -2, -1 }, "UTF-16 big-endian");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     public static final BOM UTF_32_LE = new BOM(new byte[] { -1, -2, 0, 0 }, "UTF-32 little-endian");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public static final BOM UTF_32_BE = new BOM(new byte[] { 0, 0, -2, -1 }, "UTF-32 big-endian");
/*     */ 
/*     */ 
/*     */     
/*     */     final byte[] bytes;
/*     */ 
/*     */     
/*     */     private final String description;
/*     */ 
/*     */ 
/*     */     
/*     */     public final String toString() {
/*  88 */       return this.description;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final byte[] getBytes() {
/*  96 */       int length = this.bytes.length;
/*  97 */       byte[] result = new byte[length];
/*     */ 
/*     */       
/* 100 */       System.arraycopy(this.bytes, 0, result, 0, length);
/*     */       
/* 102 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     private BOM(byte[] bom, String description) {
/* 107 */       assert bom != null : "invalid BOM: null is not allowed";
/* 108 */       assert description != null : "invalid description: null is not allowed";
/* 109 */       assert description.length() != 0 : "invalid description: empty string is not allowed";
/*     */       
/* 111 */       this.bytes = bom;
/* 112 */       this.description = description;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeBOMInputStream(InputStream inputStream) throws NullPointerException, IOException {
/* 307 */     this.skipped = false;
/*     */     if (inputStream == null)
/*     */       throw new NullPointerException("invalid input stream: null is not allowed"); 
/*     */     this.in = new PushbackInputStream(inputStream, 4);
/*     */     byte[] bom = new byte[4];
/*     */     int read = this.in.read(bom);
/*     */     switch (read) {
/*     */       case 4:
/*     */         if (bom[0] == -1 && bom[1] == -2 && bom[2] == 0 && bom[3] == 0) {
/*     */           this.bom = BOM.UTF_32_LE;
/*     */           break;
/*     */         } 
/*     */         if (bom[0] == 0 && bom[1] == 0 && bom[2] == -2 && bom[3] == -1) {
/*     */           this.bom = BOM.UTF_32_BE;
/*     */           break;
/*     */         } 
/*     */       case 3:
/*     */         if (bom[0] == -17 && bom[1] == -69 && bom[2] == -65) {
/*     */           this.bom = BOM.UTF_8;
/*     */           break;
/*     */         } 
/*     */       case 2:
/*     */         if (bom[0] == -1 && bom[1] == -2) {
/*     */           this.bom = BOM.UTF_16_LE;
/*     */           break;
/*     */         } 
/*     */         if (bom[0] == -2 && bom[1] == -1) {
/*     */           this.bom = BOM.UTF_16_BE;
/*     */           break;
/*     */         } 
/*     */       default:
/*     */         this.bom = BOM.NONE;
/*     */         break;
/*     */     } 
/*     */     if (read > 0)
/*     */       this.in.unread(bom, 0, read); 
/*     */   }
/*     */   
/*     */   public final BOM getBOM() {
/*     */     return this.bom;
/*     */   }
/*     */   
/*     */   public final synchronized UnicodeBOMInputStream skipBOM() throws IOException {
/*     */     if (!this.skipped) {
/*     */       this.in.skip(this.bom.bytes.length);
/*     */       this.skipped = true;
/*     */     } 
/*     */     return this;
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/*     */     return this.in.read();
/*     */   }
/*     */   
/*     */   public int read(byte[] b) throws IOException, NullPointerException {
/*     */     return this.in.read(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException, NullPointerException {
/*     */     return this.in.read(b, off, len);
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException {
/*     */     return this.in.skip(n);
/*     */   }
/*     */   
/*     */   public int available() throws IOException {
/*     */     return this.in.available();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*     */     this.in.close();
/*     */   }
/*     */   
/*     */   public synchronized void mark(int readlimit) {
/*     */     this.in.mark(readlimit);
/*     */   }
/*     */   
/*     */   public synchronized void reset() throws IOException {
/*     */     this.in.reset();
/*     */   }
/*     */   
/*     */   public boolean markSupported() {
/*     */     return this.in.markSupported();
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\commom\UnicodeBOMInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */