/*    */ package br.com.accesstage.loader.util.constantes.processo;
/*    */ 
/*    */ public enum TipoLayout
/*    */ {
/*  5 */   FB150("FEBRABAN150", "Roadcard - Febraban 150 posicoes"),
/*  6 */   FB240("FEBRABAN240", "Roadcard - Febraban 240 posicoes"),
/*  7 */   RC500("ROADCARD500", "Roadcard - Febraban 500 posicoes");
/*    */   
/*    */   private String tipoLayout;
/*    */   private String dscLayout;
/*    */   
/*    */   TipoLayout(String tipoLayout, String dscLayout) {
/* 13 */     this.tipoLayout = tipoLayout;
/* 14 */     this.dscLayout = dscLayout;
/*    */   }
/*    */   
/*    */   public String getTipoLayout() {
/* 18 */     return this.tipoLayout;
/*    */   }
/*    */   
/*    */   public String getDscLayout() {
/* 22 */     return this.dscLayout;
/*    */   }
/*    */   
/*    */   public static TipoLayout getTipoLayoutByTpo(String tipoLayout) {
/* 26 */     TipoLayout[] values = values();
/* 27 */     for (TipoLayout tpoLayout : values) {
/* 28 */       if (tpoLayout.getTipoLayout().equalsIgnoreCase(tipoLayout)) {
/* 29 */         return tpoLayout;
/*    */       }
/*    */     } 
/* 32 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\processo\TipoLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */