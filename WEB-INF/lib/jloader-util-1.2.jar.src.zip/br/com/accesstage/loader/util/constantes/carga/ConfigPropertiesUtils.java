/*     */ package br.com.accesstage.loader.util.constantes.carga;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigPropertiesUtils
/*     */ {
/*  25 */   private static Logger logger = Logger.getLogger(ConfigPropertiesUtils.class.getName());
/*     */   private static final int CACHE_MAX_ENTRIES = 100;
/*  27 */   private static long lastModifiedDate = -1L;
/*  28 */   private static Properties properties = new Properties();
/*     */   
/*  30 */   private static final File CONFIG_FILE = new File("/data/ascargas/config/config.properties");
/*     */   
/*  32 */   private static final Map<String, Pattern> PATTERN_CACHE = new LinkedHashMap<String, Pattern>()
/*     */     {
/*     */       private static final long serialVersionUID = 6863399121257892762L;
/*     */ 
/*     */ 
/*     */       
/*     */       protected boolean removeEldestEntry(Map.Entry<String, Pattern> eldest) {
/*  39 */         return (size() > 100);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Properties getProperties() throws IOException {
/*  52 */     if (!CONFIG_FILE.exists()) {
/*  53 */       logger.error("Arquivo :" + CONFIG_FILE.getAbsolutePath() + " nao existe!");
/*  54 */     } else if (CONFIG_FILE.lastModified() > lastModifiedDate) {
/*  55 */       properties.clear();
/*  56 */       properties.load(new FileInputStream(CONFIG_FILE));
/*  57 */       PATTERN_CACHE.clear();
/*  58 */       lastModifiedDate = CONFIG_FILE.lastModified();
/*     */     } 
/*  60 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getStringValue(String key) {
/*     */     try {
/*  72 */       return getProperties().getProperty(key);
/*  73 */     } catch (FileNotFoundException e) {
/*  74 */       logger.error("Arquivo :" + CONFIG_FILE.getAbsolutePath() + " nao existe!", e);
/*     */     }
/*  76 */     catch (IOException e) {
/*  77 */       logger.error("Erro de leitura do arquivo :" + CONFIG_FILE.getAbsolutePath(), e);
/*     */     } 
/*     */     
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer getIntValue(String key) {
/*     */     try {
/*  92 */       return Integer.valueOf(getProperties().getProperty(key));
/*  93 */     } catch (FileNotFoundException e) {
/*  94 */       logger.error("Arquivo :" + CONFIG_FILE.getAbsolutePath() + " nao existe!", e);
/*     */     }
/*  96 */     catch (IOException e) {
/*  97 */       logger.error("Erro de leitura do arquivo :" + CONFIG_FILE.getAbsolutePath(), e);
/*     */     } 
/*     */     
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pattern getPatternValue(String key) {
/* 112 */     Pattern pattern = PATTERN_CACHE.get(key);
/* 113 */     if (pattern == null) {
/* 114 */       String strValue = getStringValue(key);
/* 115 */       if (strValue == null) {
/* 116 */         return null;
/*     */       }
/* 118 */       pattern = Pattern.compile(strValue);
/* 119 */       PATTERN_CACHE.put(key, pattern);
/*     */     } 
/* 121 */     return pattern;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\carga\ConfigPropertiesUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */