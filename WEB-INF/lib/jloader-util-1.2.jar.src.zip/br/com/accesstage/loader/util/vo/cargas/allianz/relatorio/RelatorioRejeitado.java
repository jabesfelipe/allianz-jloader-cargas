/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.relatorio;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelatorioRejeitado
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String banco;
/*    */   private String identificacaoClienteEmpresa;
/*    */   private String agenciaDebito;
/*    */   private String identificacaoClienteBanco;
/*    */   private Date dataVencimentoDebito;
/*    */   private Double valorOriginalDebitado;
/*    */   private String codigoRetorno;
/*    */   private String usoEmpresa;
/*    */   
/*    */   public String getBanco() {
/* 24 */     return this.banco;
/*    */   }
/*    */   public void setBanco(String banco) {
/* 27 */     this.banco = banco;
/*    */   }
/*    */   public String getIdentificacaoClienteEmpresa() {
/* 30 */     return this.identificacaoClienteEmpresa;
/*    */   }
/*    */   public void setIdentificacaoClienteEmpresa(String identificacaoClienteEmpresa) {
/* 33 */     this.identificacaoClienteEmpresa = identificacaoClienteEmpresa;
/*    */   }
/*    */   public String getAgenciaDebito() {
/* 36 */     return this.agenciaDebito;
/*    */   }
/*    */   public void setAgenciaDebito(String agenciaDebito) {
/* 39 */     this.agenciaDebito = agenciaDebito;
/*    */   }
/*    */   public String getIdentificacaoClienteBanco() {
/* 42 */     return this.identificacaoClienteBanco;
/*    */   }
/*    */   public void setIdentificacaoClienteBanco(String identificacaoClienteBanco) {
/* 45 */     this.identificacaoClienteBanco = identificacaoClienteBanco;
/*    */   }
/*    */   public Date getDataVencimentoDebito() {
/* 48 */     return this.dataVencimentoDebito;
/*    */   }
/*    */   public void setDataVencimentoDebito(Date dataVencimentoDebito) {
/* 51 */     this.dataVencimentoDebito = dataVencimentoDebito;
/*    */   }
/*    */   public Double getValorOriginalDebitado() {
/* 54 */     return this.valorOriginalDebitado;
/*    */   }
/*    */   public void setValorOriginalDebitado(Double valorOriginalDebitado) {
/* 57 */     this.valorOriginalDebitado = valorOriginalDebitado;
/*    */   }
/*    */   public String getCodigoRetorno() {
/* 60 */     return this.codigoRetorno;
/*    */   }
/*    */   public void setCodigoRetorno(String codigoRetorno) {
/* 63 */     this.codigoRetorno = codigoRetorno;
/*    */   }
/*    */   public String getUsoEmpresa() {
/* 66 */     return this.usoEmpresa;
/*    */   }
/*    */   public void setUsoEmpresa(String usoEmpresa) {
/* 69 */     this.usoEmpresa = usoEmpresa;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\relatorio\RelatorioRejeitado.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */