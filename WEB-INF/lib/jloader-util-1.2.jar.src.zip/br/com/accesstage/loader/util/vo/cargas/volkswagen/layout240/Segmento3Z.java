/*    */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord
/*    */ public class Segmento3Z
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1889593852989608503L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*    */   private String codBanco;
/*    */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*    */   private String loteServico;
/*    */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*    */   private String tpoRegistro;
/*    */   @PositionalField(initialPosition = 9, finalPosition = 13)
/*    */   private String nroSeqLote;
/*    */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*    */   private String codSeguimentoDetalhe;
/*    */   @PositionalField(initialPosition = 15, finalPosition = 78)
/*    */   private String autenticacaoLegislacao;
/*    */   @PositionalField(initialPosition = 79, finalPosition = 103)
/*    */   private String autenticacaoMecanica;
/*    */   @PositionalField(initialPosition = 104, finalPosition = 230)
/*    */   private String usoFebraban;
/*    */   @PositionalField(initialPosition = 231, finalPosition = 240)
/*    */   private String codOcorrencia;
/*    */   
/*    */   public String getCodBanco() {
/* 36 */     return this.codBanco;
/*    */   }
/*    */   public void setCodBanco(String codBanco) {
/* 39 */     this.codBanco = codBanco;
/*    */   }
/*    */   public String getLoteServico() {
/* 42 */     return this.loteServico;
/*    */   }
/*    */   public void setLoteServico(String loteServico) {
/* 45 */     this.loteServico = loteServico;
/*    */   }
/*    */   public String getTpoRegistro() {
/* 48 */     return this.tpoRegistro;
/*    */   }
/*    */   public void setTpoRegistro(String tpoRegistro) {
/* 51 */     this.tpoRegistro = tpoRegistro;
/*    */   }
/*    */   public String getNroSeqLote() {
/* 54 */     return this.nroSeqLote;
/*    */   }
/*    */   public void setNroSeqLote(String nroSeqLote) {
/* 57 */     this.nroSeqLote = nroSeqLote;
/*    */   }
/*    */   public String getCodSeguimentoDetalhe() {
/* 60 */     return this.codSeguimentoDetalhe;
/*    */   }
/*    */   public void setCodSeguimentoDetalhe(String codSeguimentoDetalhe) {
/* 63 */     this.codSeguimentoDetalhe = codSeguimentoDetalhe;
/*    */   }
/*    */   public String getAutenticacaoLegislacao() {
/* 66 */     return this.autenticacaoLegislacao;
/*    */   }
/*    */   public void setAutenticacaoLegislacao(String autenticacaoLegislacao) {
/* 69 */     this.autenticacaoLegislacao = autenticacaoLegislacao;
/*    */   }
/*    */   public String getAutenticacaoMecanica() {
/* 72 */     return this.autenticacaoMecanica;
/*    */   }
/*    */   public void setAutenticacaoMecanica(String autenticacaoMecanica) {
/* 75 */     this.autenticacaoMecanica = autenticacaoMecanica;
/*    */   }
/*    */   public String getUsoFebraban() {
/* 78 */     return this.usoFebraban;
/*    */   }
/*    */   public void setUsoFebraban(String usoFebraban) {
/* 81 */     this.usoFebraban = usoFebraban;
/*    */   }
/*    */   public String getCodOcorrencia() {
/* 84 */     return this.codOcorrencia;
/*    */   }
/*    */   public void setCodOcorrencia(String codOcorrencia) {
/* 87 */     this.codOcorrencia = codOcorrencia;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\Segmento3Z.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */