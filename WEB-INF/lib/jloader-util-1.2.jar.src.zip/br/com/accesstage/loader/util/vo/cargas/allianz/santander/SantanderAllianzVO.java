/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.santander;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SantanderAllianzVO
/*    */ {
/*    */   private Header header;
/*    */   private HeaderLote headerLote;
/* 15 */   private Map<SegmentoP, SegmentoQ> mapSeqmentos = new HashMap<SegmentoP, SegmentoQ>();
/*    */   private TraillerLote traillerLote;
/*    */   
/*    */   public Header getHeader() {
/* 19 */     return this.header;
/*    */   }
/*    */   private Trailler trailler;
/*    */   public void setHeader(Header header) {
/* 23 */     this.header = header;
/*    */   }
/*    */   
/*    */   public HeaderLote getHeaderLote() {
/* 27 */     return this.headerLote;
/*    */   }
/*    */   
/*    */   public void setHeaderLote(HeaderLote headerLote) {
/* 31 */     this.headerLote = headerLote;
/*    */   }
/*    */   
/*    */   public Map<SegmentoP, SegmentoQ> getMapSeqmentos() {
/* 35 */     return this.mapSeqmentos;
/*    */   }
/*    */   
/*    */   public void setMapSeqmentos(Map<SegmentoP, SegmentoQ> mapSeqmentos) {
/* 39 */     this.mapSeqmentos = mapSeqmentos;
/*    */   }
/*    */   
/*    */   public TraillerLote getTraillerLote() {
/* 43 */     return this.traillerLote;
/*    */   }
/*    */   
/*    */   public void setTraillerLote(TraillerLote traillerLote) {
/* 47 */     this.traillerLote = traillerLote;
/*    */   }
/*    */   
/*    */   public Trailler getTrailler() {
/* 51 */     return this.trailler;
/*    */   }
/*    */   
/*    */   public void setTrailler(Trailler trailler) {
/* 55 */     this.trailler = trailler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\santander\SantanderAllianzVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */