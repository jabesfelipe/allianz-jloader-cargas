package br.com.accesstage.loader.util.constantes.carga;

public interface Contants {
  public static final String CARGA_REALIZADA = "CR";
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\constantes\carga\Contants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */