/*    */ package br.com.accesstage.loader.util.dao.rowmapper.cargas;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.allianz.debito.complementar.Trailler;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class ComplementTraillerRowMapper
/*    */   implements RowMapper<Trailler>
/*    */ {
/*    */   public Trailler mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 13 */     Trailler trailler = new Trailler();
/* 14 */     trailler.setCodArquivo(rs.getInt("COD_ARQUIVO"));
/* 15 */     trailler.setId(rs.getInt("COD_COMPL_HEADER"));
/* 16 */     trailler.setNroUnico(rs.getInt("NRO_UNICO"));
/* 17 */     trailler.setLinhaProcessada(rs.getInt("NRO_LINHA_ARQ"));
/* 18 */     trailler.setEmpid(rs.getInt("EMPID"));
/* 19 */     trailler.setCodRegistro(rs.getString("TPREGISTRO"));
/* 20 */     trailler.setQuantLinhas(rs.getString("QTDTOTLINHAS"));
/*    */     
/* 22 */     return trailler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\cargas\ComplementTraillerRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */