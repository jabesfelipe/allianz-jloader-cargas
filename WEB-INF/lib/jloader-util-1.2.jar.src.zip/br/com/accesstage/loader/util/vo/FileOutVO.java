/*    */ package br.com.accesstage.loader.util.vo;
/*    */ 
/*    */ public class FileOutVO
/*    */ {
/*    */   private String dsc_token;
/*    */   private String cod_arquivo;
/*    */   private String seq_arquivo;
/*    */   private String tpo_registro;
/*    */   private String dsc_registro;
/*    */   private String tpo_arquivo;
/*    */   private String sender;
/*    */   private String receiver;
/*    */   private String doctype;
/*    */   private String nme_arquivo;
/*    */   
/*    */   public String getDsc_token() {
/* 17 */     return this.dsc_token;
/*    */   }
/*    */   public void setDsc_token(String dsc_token) {
/* 20 */     this.dsc_token = dsc_token;
/*    */   }
/*    */   public String getCod_arquivo() {
/* 23 */     return this.cod_arquivo;
/*    */   }
/*    */   public void setCod_arquivo(String cod_arquivo) {
/* 26 */     this.cod_arquivo = cod_arquivo;
/*    */   }
/*    */   public String getSeq_arquivo() {
/* 29 */     return this.seq_arquivo;
/*    */   }
/*    */   public void setSeq_arquivo(String seq_arquivo) {
/* 32 */     this.seq_arquivo = seq_arquivo;
/*    */   }
/*    */   public String getTpo_registro() {
/* 35 */     return this.tpo_registro;
/*    */   }
/*    */   public void setTpo_registro(String tpo_registro) {
/* 38 */     this.tpo_registro = tpo_registro;
/*    */   }
/*    */   public String getDsc_registro() {
/* 41 */     return this.dsc_registro;
/*    */   }
/*    */   public void setDsc_registro(String dsc_registro) {
/* 44 */     this.dsc_registro = dsc_registro;
/*    */   }
/*    */   public String getTpo_arquivo() {
/* 47 */     return this.tpo_arquivo;
/*    */   }
/*    */   public void setTpo_arquivo(String tpo_arquivo) {
/* 50 */     this.tpo_arquivo = tpo_arquivo;
/*    */   }
/*    */   public String getSender() {
/* 53 */     return this.sender;
/*    */   }
/*    */   public void setSender(String sender) {
/* 56 */     this.sender = sender;
/*    */   }
/*    */   public String getReceiver() {
/* 59 */     return this.receiver;
/*    */   }
/*    */   public void setReceiver(String receiver) {
/* 62 */     this.receiver = receiver;
/*    */   }
/*    */   public String getDoctype() {
/* 65 */     return this.doctype;
/*    */   }
/*    */   public void setDoctype(String doctype) {
/* 68 */     this.doctype = doctype;
/*    */   }
/*    */   public String getNme_arquivo() {
/* 71 */     return this.nme_arquivo;
/*    */   }
/*    */   public void setNme_arquivo(String nme_arquivo) {
/* 74 */     this.nme_arquivo = nme_arquivo;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\FileOutVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */