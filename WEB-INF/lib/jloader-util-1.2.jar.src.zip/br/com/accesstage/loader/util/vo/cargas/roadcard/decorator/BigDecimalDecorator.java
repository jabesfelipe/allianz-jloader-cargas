/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.decorator;
/*    */ 
/*    */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ public class BigDecimalDecorator
/*    */   extends DefaultFieldDecorator
/*    */ {
/*    */   public Object fromString(String str) {
/* 11 */     if (!isNullOrWhitespace(str.trim())) {
/* 12 */       return BigDecimal.valueOf(Double.valueOf(str).doubleValue()).divide(BigDecimal.valueOf(100L));
/*    */     }
/* 14 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isNullOrWhitespace(CharSequence value) {
/* 18 */     if (value == null) {
/* 19 */       return true;
/*    */     }
/* 21 */     for (int i = 0; i < value.length(); i++) {
/* 22 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 23 */         return false;
/*    */       }
/*    */     } 
/* 26 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\decorator\BigDecimalDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */