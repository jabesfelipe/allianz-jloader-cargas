/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito.complementar;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "1")})
/*    */ public class Header
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 4)
/*    */   private String empresaAllianz;
/*    */   @PositionalField(initialPosition = 5, finalPosition = 12)
/*    */   private String dataEnvio;
/*    */   @PositionalField(initialPosition = 13, finalPosition = 18)
/*    */   private String horaEnvio;
/*    */   @PositionalField(initialPosition = 19, finalPosition = 23)
/*    */   private String nsa;
/*    */   @PositionalField(initialPosition = 24, finalPosition = 750)
/*    */   private String filler;
/*    */   
/*    */   public String getCodRegistro() {
/* 31 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 34 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getEmpresaAllianz() {
/* 37 */     return this.empresaAllianz;
/*    */   }
/*    */   public void setEmpresaAllianz(String empresaAllianz) {
/* 40 */     this.empresaAllianz = empresaAllianz;
/*    */   }
/*    */   public String getDataEnvio() {
/* 43 */     return this.dataEnvio;
/*    */   }
/*    */   public void setDataEnvio(String dataEnvio) {
/* 46 */     this.dataEnvio = dataEnvio;
/*    */   }
/*    */   public String getHoraEnvio() {
/* 49 */     return this.horaEnvio;
/*    */   }
/*    */   public void setHoraEnvio(String horaEnvio) {
/* 52 */     this.horaEnvio = horaEnvio;
/*    */   }
/*    */   public String getNsa() {
/* 55 */     return this.nsa;
/*    */   }
/*    */   public void setNsa(String nsa) {
/* 58 */     this.nsa = nsa;
/*    */   }
/*    */   public String getFiller() {
/* 61 */     return this.filler;
/*    */   }
/*    */   public void setFiller(String filler) {
/* 64 */     this.filler = filler;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\complementar\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */