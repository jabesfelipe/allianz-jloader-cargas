/*    */ package br.com.accesstage.loader.util.core;
/*    */ 
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.Connection;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrackingHandler
/*    */ {
/* 13 */   private static Logger logger = Logger.getLogger(TrackingHandler.class.getName());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final String DS_FORNAX = "java:jboss/datasources/fornaxDS";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void regEvento(String trackingID, String staSeveridade, String dscEvento, String dscProcesso) throws Exception {
/* 30 */     InitialContext ctx = new InitialContext();
/* 31 */     DataSource ds = (DataSource)ctx.lookup("java:jboss/datasources/fornaxDS");
/* 32 */     Connection conn = ds.getConnection();
/* 33 */     CallableStatement cs = null;
/*    */     
/*    */     try {
/* 36 */       logger.warn("TrackingHandler.regEvento() - TrackingID" + trackingID + " Severidade:" + staSeveridade + " Evento: " + dscEvento + " Processo:" + dscProcesso);
/* 37 */       cs = conn.prepareCall("{CALL bea_gx_eventoprocesso.pi_EventoProcesso(?,?,?,?)}");
/* 38 */       cs.setString(1, trackingID);
/* 39 */       cs.setString(2, staSeveridade);
/* 40 */       cs.setString(3, dscProcesso);
/* 41 */       cs.setString(4, dscEvento);
/* 42 */       cs.execute();
/* 43 */     } catch (Exception exc) {
/* 44 */       throw new Exception("TrackingHandler.regEvento() - Impossivel registrar dados na EVENTOPROCESSO", exc);
/*    */     } finally {
/*    */       
/* 47 */       if (conn != null)
/* 48 */         conn.close(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\core\TrackingHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */