/*    */ package br.com.accesstage.loader.util.dao.rowmapper.processo;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.processo.TransacaoConfirmVO;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransacaoConfirm240RowMapper
/*    */   implements RowMapper<TransacaoConfirmVO>
/*    */ {
/*    */   public TransacaoConfirmVO mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 14 */     TransacaoConfirmVO transConfirm = new TransacaoConfirmVO();
/* 15 */     transConfirm.setNroNsu(rs.getString("NSU_PARCEIRO"));
/* 16 */     transConfirm.setDataArquivoRetorno(rs.getString("DTA_ARQUIVO_RETORNO"));
/* 17 */     transConfirm.setDataAutorizacao(rs.getString("DTA_AUTORIZACAO"));
/* 18 */     transConfirm.setCodArquivo(rs.getString("COD_ARQUIVO"));
/* 19 */     transConfirm.setNroBanco(rs.getString("NRO_BANCO"));
/* 20 */     transConfirm.setNroLinhaArq(Long.valueOf(rs.getLong("NRO_LINHA_ARQ")));
/* 21 */     transConfirm.setDscOcorrencia(rs.getString("DSC_OCORRENCIA"));
/* 22 */     transConfirm.setStaCallback(0);
/* 23 */     transConfirm.setTpoOperacao("2");
/* 24 */     return transConfirm;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\processo\TransacaoConfirm240RowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */