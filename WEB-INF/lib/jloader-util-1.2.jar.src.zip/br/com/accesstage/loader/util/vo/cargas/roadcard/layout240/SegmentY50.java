/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentY50
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 2884510853497266998L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeqLte;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegRegDtlh;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Integer codMovRmss;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 19)
/*     */   private Integer codRegOpe;
/*     */   @IntegerPositionalField(initialPosition = 20, finalPosition = 24)
/*     */   private Integer dscAgencia;
/*     */   @PositionalField(initialPosition = 25, finalPosition = 25)
/*     */   private String dscAgenciaDV;
/*     */   @LongPositionalField(initialPosition = 26, finalPosition = 37)
/*     */   private Long dscConta;
/*     */   @PositionalField(initialPosition = 38, finalPosition = 38)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 39, finalPosition = 39)
/*     */   private String dscAgeCta;
/*     */   @PositionalField(initialPosition = 40, finalPosition = 59)
/*     */   private String nroIdentTitBco;
/*     */   @IntegerPositionalField(initialPosition = 60, finalPosition = 60)
/*     */   private Integer codCalcRateioBenef;
/*     */   @IntegerPositionalField(initialPosition = 61, finalPosition = 61)
/*     */   private Integer codTpoVlrInfo;
/*     */   @PositionalField(initialPosition = 62, finalPosition = 76, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrPrctl;
/*     */   @PositionalField(initialPosition = 77, finalPosition = 79)
/*     */   private String codBcoCreBenef;
/*     */   @IntegerPositionalField(initialPosition = 80, finalPosition = 84)
/*     */   private Integer dscAgeCredBenef;
/*     */   @PositionalField(initialPosition = 85, finalPosition = 85)
/*     */   private String codDigVerifCredBenef;
/*     */   @LongPositionalField(initialPosition = 86, finalPosition = 97)
/*     */   private Long dscContaCredBenef;
/*     */   @PositionalField(initialPosition = 98, finalPosition = 98)
/*     */   private String dscContaCredBenefDV;
/*     */   @PositionalField(initialPosition = 99, finalPosition = 99)
/*     */   private String dscAgeCtaDVBenef;
/*     */   @PositionalField(initialPosition = 100, finalPosition = 139)
/*     */   private String nmeBenef;
/*     */   @PositionalField(initialPosition = 140, finalPosition = 145)
/*     */   private String dscParcelaRateio;
/*     */   @PositionalField(initialPosition = 146, finalPosition = 148)
/*     */   private String qtdCredBenef;
/*     */   @PositionalField(initialPosition = 149, finalPosition = 155, decorator = DateDecorator240.class)
/*     */   private Date dtaCredBenef;
/*     */   @LongPositionalField(initialPosition = 156, finalPosition = 165)
/*     */   private Long codRejeicoes;
/*     */   @PositionalField(initialPosition = 166, finalPosition = 240)
/*     */   private String dscUsoFbrn2;
/*     */   
/*     */   public String getCodBco() {
/*  83 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  86 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  89 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  92 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  95 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  98 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeqLte() {
/* 101 */     return this.nroSeqLte;
/*     */   }
/*     */   public void setNroSeqLte(Integer nroSeqLte) {
/* 104 */     this.nroSeqLte = nroSeqLte;
/*     */   }
/*     */   public String getCodSegRegDtlh() {
/* 107 */     return this.codSegRegDtlh;
/*     */   }
/*     */   public void setCodSegRegDtlh(String codSegRegDtlh) {
/* 110 */     this.codSegRegDtlh = codSegRegDtlh;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 113 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 116 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMovRmss() {
/* 119 */     return this.codMovRmss;
/*     */   }
/*     */   public void setCodMovRmss(Integer codMovRmss) {
/* 122 */     this.codMovRmss = codMovRmss;
/*     */   }
/*     */   public Integer getCodRegOpe() {
/* 125 */     return this.codRegOpe;
/*     */   }
/*     */   public void setCodRegOpe(Integer codRegOpe) {
/* 128 */     this.codRegOpe = codRegOpe;
/*     */   }
/*     */   public Integer getDscAgencia() {
/* 131 */     return this.dscAgencia;
/*     */   }
/*     */   public void setDscAgencia(Integer dscAgencia) {
/* 134 */     this.dscAgencia = dscAgencia;
/*     */   }
/*     */   public String getDscAgenciaDV() {
/* 137 */     return this.dscAgenciaDV;
/*     */   }
/*     */   public void setDscAgenciaDV(String dscAgenciaDV) {
/* 140 */     this.dscAgenciaDV = dscAgenciaDV;
/*     */   }
/*     */   public Long getDscConta() {
/* 143 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(Long dscConta) {
/* 146 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 149 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 152 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgeCta() {
/* 155 */     return this.dscAgeCta;
/*     */   }
/*     */   public void setDscAgeCta(String dscAgeCta) {
/* 158 */     this.dscAgeCta = dscAgeCta;
/*     */   }
/*     */   public String getNroIdentTitBco() {
/* 161 */     return this.nroIdentTitBco;
/*     */   }
/*     */   public void setNroIdentTitBco(String nroIdentTitBco) {
/* 164 */     this.nroIdentTitBco = nroIdentTitBco;
/*     */   }
/*     */   public Integer getCodCalcRateioBenef() {
/* 167 */     return this.codCalcRateioBenef;
/*     */   }
/*     */   public void setCodCalcRateioBenef(Integer codCalcRateioBenef) {
/* 170 */     this.codCalcRateioBenef = codCalcRateioBenef;
/*     */   }
/*     */   public Integer getCodTpoVlrInfo() {
/* 173 */     return this.codTpoVlrInfo;
/*     */   }
/*     */   public void setCodTpoVlrInfo(Integer codTpoVlrInfo) {
/* 176 */     this.codTpoVlrInfo = codTpoVlrInfo;
/*     */   }
/*     */   public BigDecimal getVlrPrctl() {
/* 179 */     return this.vlrPrctl;
/*     */   }
/*     */   public void setVlrPrctl(BigDecimal vlrPrctl) {
/* 182 */     this.vlrPrctl = vlrPrctl;
/*     */   }
/*     */   public String getCodBcoCreBenef() {
/* 185 */     return this.codBcoCreBenef;
/*     */   }
/*     */   public void setCodBcoCreBenef(String codBcoCreBenef) {
/* 188 */     this.codBcoCreBenef = codBcoCreBenef;
/*     */   }
/*     */   public Integer getDscAgeCredBenef() {
/* 191 */     return this.dscAgeCredBenef;
/*     */   }
/*     */   public void setDscAgeCredBenef(Integer dscAgeCredBenef) {
/* 194 */     this.dscAgeCredBenef = dscAgeCredBenef;
/*     */   }
/*     */   public String getCodDigVerifCredBenef() {
/* 197 */     return this.codDigVerifCredBenef;
/*     */   }
/*     */   public void setCodDigVerifCredBenef(String codDigVerifCredBenef) {
/* 200 */     this.codDigVerifCredBenef = codDigVerifCredBenef;
/*     */   }
/*     */   public Long getDscContaCredBenef() {
/* 203 */     return this.dscContaCredBenef;
/*     */   }
/*     */   public void setDscContaCredBenef(Long dscContaCredBenef) {
/* 206 */     this.dscContaCredBenef = dscContaCredBenef;
/*     */   }
/*     */   public String getDscContaCredBenefDV() {
/* 209 */     return this.dscContaCredBenefDV;
/*     */   }
/*     */   public void setDscContaCredBenefDV(String dscContaCredBenefDV) {
/* 212 */     this.dscContaCredBenefDV = dscContaCredBenefDV;
/*     */   }
/*     */   public String getDscAgeCtaDVBenef() {
/* 215 */     return this.dscAgeCtaDVBenef;
/*     */   }
/*     */   public void setDscAgeCtaDVBenef(String dscAgeCtaDVBenef) {
/* 218 */     this.dscAgeCtaDVBenef = dscAgeCtaDVBenef;
/*     */   }
/*     */   public String getNmeBenef() {
/* 221 */     return this.nmeBenef;
/*     */   }
/*     */   public void setNmeBenef(String nmeBenef) {
/* 224 */     this.nmeBenef = nmeBenef;
/*     */   }
/*     */   public String getDscParcelaRateio() {
/* 227 */     return this.dscParcelaRateio;
/*     */   }
/*     */   public void setDscParcelaRateio(String dscParcelaRateio) {
/* 230 */     this.dscParcelaRateio = dscParcelaRateio;
/*     */   }
/*     */   public String getQtdCredBenef() {
/* 233 */     return this.qtdCredBenef;
/*     */   }
/*     */   public void setQtdCredBenef(String qtdCredBenef) {
/* 236 */     this.qtdCredBenef = qtdCredBenef;
/*     */   }
/*     */   public Date getDtaCredBenef() {
/* 239 */     return this.dtaCredBenef;
/*     */   }
/*     */   public void setDtaCredBenef(Date dtaCredBenef) {
/* 242 */     this.dtaCredBenef = dtaCredBenef;
/*     */   }
/*     */   public Long getCodRejeicoes() {
/* 245 */     return this.codRejeicoes;
/*     */   }
/*     */   public void setCodRejeicoes(Long codRejeicoes) {
/* 248 */     this.codRejeicoes = codRejeicoes;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 251 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 254 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentY50.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */