/*    */ package br.com.accesstage.loader.util.dao.rowmapper;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.TokenVO;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class TokenMapper
/*    */   implements RowMapper<TokenVO>
/*    */ {
/*    */   public TokenVO mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 13 */     TokenVO tokenVO = new TokenVO();
/* 14 */     tokenVO.setToken(rs.getString("dsc_token"));
/* 15 */     tokenVO.setTpoArquivo(rs.getString("tpo_arquivo"));
/* 16 */     return tokenVO;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\TokenMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */