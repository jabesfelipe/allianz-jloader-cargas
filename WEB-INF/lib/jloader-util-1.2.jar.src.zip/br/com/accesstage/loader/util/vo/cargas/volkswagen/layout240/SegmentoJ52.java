/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoJ52
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @PositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private String lteServico;
/*     */   @PositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private String tpoReg;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private String nroSeq;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegReg;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String usoExclusivoFebraban;
/*     */   @PositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private String codInstMovimento;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 19)
/*     */   private String codRegOpcional;
/*     */   @PositionalField(initialPosition = 20, finalPosition = 20)
/*     */   private String tipoInscricaoSacado;
/*     */   @PositionalField(initialPosition = 21, finalPosition = 35)
/*     */   private String numInscricaoSacado;
/*     */   @PositionalField(initialPosition = 36, finalPosition = 75)
/*     */   private String nomeSacado;
/*     */   @PositionalField(initialPosition = 76, finalPosition = 76)
/*     */   private String tipoInscricaoCedente;
/*     */   @PositionalField(initialPosition = 77, finalPosition = 91)
/*     */   private String numInscricaoCedente;
/*     */   @PositionalField(initialPosition = 92, finalPosition = 131)
/*     */   private String nomeCedente;
/*     */   @PositionalField(initialPosition = 132, finalPosition = 132)
/*     */   private String tipoInscricaoSacador;
/*     */   @PositionalField(initialPosition = 133, finalPosition = 147)
/*     */   private String numInscricaoSacador;
/*     */   @PositionalField(initialPosition = 148, finalPosition = 187)
/*     */   private String nomeSacador;
/*     */   @PositionalField(initialPosition = 188, finalPosition = 240)
/*     */   private String filler1;
/*     */   
/*     */   public String getCodBco() {
/*  54 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  57 */     this.codBco = codBco;
/*     */   }
/*     */   public String getLteServico() {
/*  60 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(String lteServico) {
/*  63 */     this.lteServico = lteServico;
/*     */   }
/*     */   public String getTpoReg() {
/*  66 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(String tpoReg) {
/*  69 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public String getNroSeq() {
/*  72 */     return this.nroSeq;
/*     */   }
/*     */   public void setNroSeq(String nroSeq) {
/*  75 */     this.nroSeq = nroSeq;
/*     */   }
/*     */   public String getCodSegReg() {
/*  78 */     return this.codSegReg;
/*     */   }
/*     */   public void setCodSegReg(String codSegReg) {
/*  81 */     this.codSegReg = codSegReg;
/*     */   }
/*     */   public String getUsoExclusivoFebraban() {
/*  84 */     return this.usoExclusivoFebraban;
/*     */   }
/*     */   public void setUsoExclusivoFebraban(String tipoMovimento) {
/*  87 */     this.usoExclusivoFebraban = tipoMovimento;
/*     */   }
/*     */   public String getCodInstMovimento() {
/*  90 */     return this.codInstMovimento;
/*     */   }
/*     */   public void setCodInstMovimento(String codInstMovimento) {
/*  93 */     this.codInstMovimento = codInstMovimento;
/*     */   }
/*     */   public String getCodRegOpcional() {
/*  96 */     return this.codRegOpcional;
/*     */   }
/*     */   public void setCodRegOpcional(String codRegOpcional) {
/*  99 */     this.codRegOpcional = codRegOpcional;
/*     */   }
/*     */   public String getTipoInscricaoSacado() {
/* 102 */     return this.tipoInscricaoSacado;
/*     */   }
/*     */   public void setTipoInscricaoSacado(String tipoInscricaoSacado) {
/* 105 */     this.tipoInscricaoSacado = tipoInscricaoSacado;
/*     */   }
/*     */   public String getNumInscricaoSacado() {
/* 108 */     return this.numInscricaoSacado;
/*     */   }
/*     */   public void setNumInscricaoSacado(String numInscricaoSacado) {
/* 111 */     this.numInscricaoSacado = numInscricaoSacado;
/*     */   }
/*     */   public String getNomeSacado() {
/* 114 */     return this.nomeSacado;
/*     */   }
/*     */   public void setNomeSacado(String nomeSacado) {
/* 117 */     this.nomeSacado = nomeSacado;
/*     */   }
/*     */   public String getTipoInscricaoCedente() {
/* 120 */     return this.tipoInscricaoCedente;
/*     */   }
/*     */   public void setTipoInscricaoCedente(String tipoInscricaoCedente) {
/* 123 */     this.tipoInscricaoCedente = tipoInscricaoCedente;
/*     */   }
/*     */   public String getNumInscricaoCedente() {
/* 126 */     return this.numInscricaoCedente;
/*     */   }
/*     */   public void setNumInscricaoCedente(String numInscricaoCedente) {
/* 129 */     this.numInscricaoCedente = numInscricaoCedente;
/*     */   }
/*     */   public String getNomeCedente() {
/* 132 */     return this.nomeCedente;
/*     */   }
/*     */   public void setNomeCedente(String nomeCedente) {
/* 135 */     this.nomeCedente = nomeCedente;
/*     */   }
/*     */   public String getTipoInscricaoSacador() {
/* 138 */     return this.tipoInscricaoSacador;
/*     */   }
/*     */   public void setTipoInscricaoSacador(String tipoInscricaoSacador) {
/* 141 */     this.tipoInscricaoSacador = tipoInscricaoSacador;
/*     */   }
/*     */   public String getNumInscricaoSacador() {
/* 144 */     return this.numInscricaoSacador;
/*     */   }
/*     */   public void setNumInscricaoSacador(String numInscricaoSacador) {
/* 147 */     this.numInscricaoSacador = numInscricaoSacador;
/*     */   }
/*     */   public String getNomeSacador() {
/* 150 */     return this.nomeSacador;
/*     */   }
/*     */   public void setNomeSacador(String nomeSacador) {
/* 153 */     this.nomeSacador = nomeSacador;
/*     */   }
/*     */   public String getFiller1() {
/* 156 */     return this.filler1;
/*     */   }
/*     */   public void setFiller1(String filler1) {
/* 159 */     this.filler1 = filler1;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout240\SegmentoJ52.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */