/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout150;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.DateDecorator;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "B")})
/*    */ public class DetalheB
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 2265304163828979403L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 26)
/*    */   private String identClienteEmpresa;
/*    */   @PositionalField(initialPosition = 27, finalPosition = 30)
/*    */   private String agenciaDebito;
/*    */   @PositionalField(initialPosition = 31, finalPosition = 44)
/*    */   private String identClienteBanco;
/*    */   @PositionalField(initialPosition = 45, finalPosition = 52, decorator = DateDecorator.class)
/*    */   private Date dtaOpcaoOuExclusao;
/*    */   @PositionalField(initialPosition = 53, finalPosition = 149)
/*    */   private String usoFuturo;
/*    */   @PositionalField(initialPosition = 150, finalPosition = 150)
/*    */   private String codMovimento;
/*    */   
/*    */   public String getCodRegistro() {
/* 36 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 39 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getIdentClienteEmpresa() {
/* 42 */     return this.identClienteEmpresa;
/*    */   }
/*    */   public void setIdentClienteEmpresa(String identClienteEmpresa) {
/* 45 */     this.identClienteEmpresa = identClienteEmpresa;
/*    */   }
/*    */   public String getAgenciaDebito() {
/* 48 */     return this.agenciaDebito;
/*    */   }
/*    */   public void setAgenciaDebito(String agenciaDebito) {
/* 51 */     this.agenciaDebito = agenciaDebito;
/*    */   }
/*    */   public String getIdentClienteBanco() {
/* 54 */     return this.identClienteBanco;
/*    */   }
/*    */   public void setIdentClienteBanco(String identClienteBanco) {
/* 57 */     this.identClienteBanco = identClienteBanco;
/*    */   }
/*    */   public Date getDtaOpcaoOuExclusao() {
/* 60 */     return this.dtaOpcaoOuExclusao;
/*    */   }
/*    */   public void setDtaOpcaoOuExclusao(Date dtaOpcaoOuExclusao) {
/* 63 */     this.dtaOpcaoOuExclusao = dtaOpcaoOuExclusao;
/*    */   }
/*    */   public String getUsoFuturo() {
/* 66 */     return this.usoFuturo;
/*    */   }
/*    */   public void setUsoFuturo(String usoFuturo) {
/* 69 */     this.usoFuturo = usoFuturo;
/*    */   }
/*    */   public String getCodMovimento() {
/* 72 */     return this.codMovimento;
/*    */   }
/*    */   public void setCodMovimento(String codMovimento) {
/* 75 */     this.codMovimento = codMovimento;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout150\DetalheB.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */