/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.BigDecimalDecorator;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class SegmentoT
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -6858413875887457107L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBco;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServico;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoReg;
/*     */   @IntegerPositionalField(initialPosition = 9, finalPosition = 13)
/*     */   private Integer nroSeqLte;
/*     */   @PositionalField(initialPosition = 14, finalPosition = 14)
/*     */   private String codSegRegDtlh;
/*     */   @PositionalField(initialPosition = 15, finalPosition = 15)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 16, finalPosition = 17)
/*     */   private Integer codMovRtrn;
/*     */   @IntegerPositionalField(initialPosition = 18, finalPosition = 22)
/*     */   private Integer dscAgencia;
/*     */   @PositionalField(initialPosition = 23, finalPosition = 23)
/*     */   private String dscAgenciaDV;
/*     */   @LongPositionalField(initialPosition = 24, finalPosition = 35)
/*     */   private Long dscConta;
/*     */   @PositionalField(initialPosition = 36, finalPosition = 36)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 37, finalPosition = 37)
/*     */   private String dscAgeCta;
/*     */   @PositionalField(initialPosition = 38, finalPosition = 57)
/*     */   private String nroIdentTitBco;
/*     */   @PositionalField(initialPosition = 58, finalPosition = 58)
/*     */   private String codCarteira;
/*     */   @PositionalField(initialPosition = 59, finalPosition = 73)
/*     */   private String nroDocCob;
/*     */   @PositionalField(initialPosition = 74, finalPosition = 81, decorator = DateDecorator240.class)
/*     */   private Date dtaVencTit;
/*     */   @PositionalField(initialPosition = 82, finalPosition = 96, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrNmlTit;
/*     */   @PositionalField(initialPosition = 97, finalPosition = 99)
/*     */   private String codBcoComp;
/*     */   @IntegerPositionalField(initialPosition = 100, finalPosition = 104)
/*     */   private Integer dscAgenciaCobRec;
/*     */   @PositionalField(initialPosition = 105, finalPosition = 105)
/*     */   private String dscAgenciaCobRecDV;
/*     */   @PositionalField(initialPosition = 106, finalPosition = 130)
/*     */   private String dscTitEmp;
/*     */   @IntegerPositionalField(initialPosition = 131, finalPosition = 132)
/*     */   private Integer codMoeda;
/*     */   @IntegerPositionalField(initialPosition = 133, finalPosition = 133)
/*     */   private Integer tpoInscEmp;
/*     */   @LongPositionalField(initialPosition = 134, finalPosition = 148)
/*     */   private Long nroInscEmp;
/*     */   @PositionalField(initialPosition = 149, finalPosition = 188)
/*     */   private String nmeEmp;
/*     */   @IntegerPositionalField(initialPosition = 189, finalPosition = 198)
/*     */   private Integer nroContratoOpCred;
/*     */   @PositionalField(initialPosition = 199, finalPosition = 213, decorator = BigDecimalDecorator.class)
/*     */   private BigDecimal vlrTrfCustas;
/*     */   @PositionalField(initialPosition = 214, finalPosition = 223)
/*     */   private String dscRejeicaoTrf;
/*     */   @PositionalField(initialPosition = 224, finalPosition = 240)
/*     */   private String dscUsoFbrn2;
/*     */   
/*     */   public String getCodBco() {
/*  84 */     return this.codBco;
/*     */   }
/*     */   public void setCodBco(String codBco) {
/*  87 */     this.codBco = codBco;
/*     */   }
/*     */   public Integer getLteServico() {
/*  90 */     return this.lteServico;
/*     */   }
/*     */   public void setLteServico(Integer lteServico) {
/*  93 */     this.lteServico = lteServico;
/*     */   }
/*     */   public Integer getTpoReg() {
/*  96 */     return this.tpoReg;
/*     */   }
/*     */   public void setTpoReg(Integer tpoReg) {
/*  99 */     this.tpoReg = tpoReg;
/*     */   }
/*     */   public Integer getNroSeqLte() {
/* 102 */     return this.nroSeqLte;
/*     */   }
/*     */   public void setNroSeqLte(Integer nroSeqLte) {
/* 105 */     this.nroSeqLte = nroSeqLte;
/*     */   }
/*     */   public String getCodSegRegDtlh() {
/* 108 */     return this.codSegRegDtlh;
/*     */   }
/*     */   public void setCodSegRegDtlh(String codSegRegDtlh) {
/* 111 */     this.codSegRegDtlh = codSegRegDtlh;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 114 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 117 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getCodMovRtrn() {
/* 120 */     return this.codMovRtrn;
/*     */   }
/*     */   public void setCodMovRtrn(Integer codMovRtrn) {
/* 123 */     this.codMovRtrn = codMovRtrn;
/*     */   }
/*     */   public Integer getDscAgencia() {
/* 126 */     return this.dscAgencia;
/*     */   }
/*     */   public void setDscAgencia(Integer dscAgencia) {
/* 129 */     this.dscAgencia = dscAgencia;
/*     */   }
/*     */   public String getDscAgenciaDV() {
/* 132 */     return this.dscAgenciaDV;
/*     */   }
/*     */   public void setDscAgenciaDV(String dscAgenciaDV) {
/* 135 */     this.dscAgenciaDV = dscAgenciaDV;
/*     */   }
/*     */   public Long getDscConta() {
/* 138 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(Long dscConta) {
/* 141 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 144 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 147 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgeCta() {
/* 150 */     return this.dscAgeCta;
/*     */   }
/*     */   public void setDscAgeCta(String dscAgeCta) {
/* 153 */     this.dscAgeCta = dscAgeCta;
/*     */   }
/*     */   public String getNroIdentTitBco() {
/* 156 */     return this.nroIdentTitBco;
/*     */   }
/*     */   public void setNroIdentTitBco(String nroIdentTitBco) {
/* 159 */     this.nroIdentTitBco = nroIdentTitBco;
/*     */   }
/*     */   public String getCodCarteira() {
/* 162 */     return this.codCarteira;
/*     */   }
/*     */   public void setCodCarteira(String codCarteira) {
/* 165 */     this.codCarteira = codCarteira;
/*     */   }
/*     */   public String getNroDocCob() {
/* 168 */     return this.nroDocCob;
/*     */   }
/*     */   public void setNroDocCob(String nroDocCob) {
/* 171 */     this.nroDocCob = nroDocCob;
/*     */   }
/*     */   public Date getDtaVencTit() {
/* 174 */     return this.dtaVencTit;
/*     */   }
/*     */   public void setDtaVencTit(Date dtaVencTit) {
/* 177 */     this.dtaVencTit = dtaVencTit;
/*     */   }
/*     */   public BigDecimal getVlrNmlTit() {
/* 180 */     return this.vlrNmlTit;
/*     */   }
/*     */   public void setVlrNmlTit(BigDecimal vlrNmlTit) {
/* 183 */     this.vlrNmlTit = vlrNmlTit;
/*     */   }
/*     */   public String getCodBcoComp() {
/* 186 */     return this.codBcoComp;
/*     */   }
/*     */   public void setCodBcoComp(String codBcoComp) {
/* 189 */     this.codBcoComp = codBcoComp;
/*     */   }
/*     */   public Integer getDscAgenciaCobRec() {
/* 192 */     return this.dscAgenciaCobRec;
/*     */   }
/*     */   public void setDscAgenciaCobRec(Integer dscAgenciaCobRec) {
/* 195 */     this.dscAgenciaCobRec = dscAgenciaCobRec;
/*     */   }
/*     */   public String getDscAgenciaCobRecDV() {
/* 198 */     return this.dscAgenciaCobRecDV;
/*     */   }
/*     */   public void setDscAgenciaCobRecDV(String dscAgenciaCobRecDV) {
/* 201 */     this.dscAgenciaCobRecDV = dscAgenciaCobRecDV;
/*     */   }
/*     */   public String getDscTitEmp() {
/* 204 */     return this.dscTitEmp;
/*     */   }
/*     */   public void setDscTitEmp(String dscTitEmp) {
/* 207 */     this.dscTitEmp = dscTitEmp;
/*     */   }
/*     */   public Integer getCodMoeda() {
/* 210 */     return this.codMoeda;
/*     */   }
/*     */   public void setCodMoeda(Integer codMoeda) {
/* 213 */     this.codMoeda = codMoeda;
/*     */   }
/*     */   public Integer getTpoInscEmp() {
/* 216 */     return this.tpoInscEmp;
/*     */   }
/*     */   public void setTpoInscEmp(Integer tpoInscEmp) {
/* 219 */     this.tpoInscEmp = tpoInscEmp;
/*     */   }
/*     */   public Long getNroInscEmp() {
/* 222 */     return this.nroInscEmp;
/*     */   }
/*     */   public void setNroInscEmp(Long nroInscEmp) {
/* 225 */     this.nroInscEmp = nroInscEmp;
/*     */   }
/*     */   public String getNmeEmp() {
/* 228 */     return this.nmeEmp;
/*     */   }
/*     */   public void setNmeEmp(String nmeEmp) {
/* 231 */     this.nmeEmp = nmeEmp;
/*     */   }
/*     */   public Integer getNroContratoOpCred() {
/* 234 */     return this.nroContratoOpCred;
/*     */   }
/*     */   public void setNroContratoOpCred(Integer nroContratoOpCred) {
/* 237 */     this.nroContratoOpCred = nroContratoOpCred;
/*     */   }
/*     */   public BigDecimal getVlrTrfCustas() {
/* 240 */     return this.vlrTrfCustas;
/*     */   }
/*     */   public void setVlrTrfCustas(BigDecimal vlrTrfCustas) {
/* 243 */     this.vlrTrfCustas = vlrTrfCustas;
/*     */   }
/*     */   public String getDscRejeicaoTrf() {
/* 246 */     return this.dscRejeicaoTrf;
/*     */   }
/*     */   public void setDscRejeicaoTrf(String dscRejeicaoTrf) {
/* 249 */     this.dscRejeicaoTrf = dscRejeicaoTrf;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 252 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 255 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\SegmentoT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */