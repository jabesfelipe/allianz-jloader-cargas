/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout500;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.StringDecorator;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord
/*    */ public class Trailler
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1410054618230853071L;
/*    */   @IntegerPositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private int tipo;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 7)
/*    */   private String qtdRegistros;
/*    */   @PositionalField(initialPosition = 8, finalPosition = 24)
/*    */   private String totalValoresPagamento;
/*    */   @PositionalField(initialPosition = 25, finalPosition = 494)
/*    */   private String brancos;
/*    */   @PositionalField(decorator = StringDecorator.class, initialPosition = 495, finalPosition = 500)
/*    */   private String numeroSequencialTrailer;
/*    */   
/*    */   public int getTipo() {
/* 30 */     int linha = getLinhaProcessada();
/* 31 */     setLinhaProcessada(linha++);
/* 32 */     return this.tipo;
/*    */   }
/*    */   public void setTipo(int tipo) {
/* 35 */     this.tipo = tipo;
/*    */   }
/*    */   public String getQtdRegistros() {
/* 38 */     return this.qtdRegistros;
/*    */   }
/*    */   public void setQtdRegistros(String qtdRegistros) {
/* 41 */     this.qtdRegistros = qtdRegistros;
/*    */   }
/*    */   public String getTotalValoresPagamento() {
/* 44 */     return this.totalValoresPagamento;
/*    */   }
/*    */   public void setTotalValoresPagamento(String totalValoresPagamento) {
/* 47 */     this.totalValoresPagamento = totalValoresPagamento;
/*    */   }
/*    */   public String getBrancos() {
/* 50 */     return this.brancos;
/*    */   }
/*    */   public void setBrancos(String brancos) {
/* 53 */     this.brancos = brancos;
/*    */   }
/*    */   public String getNumeroSequencialTrailer() {
/* 56 */     return this.numeroSequencialTrailer;
/*    */   }
/*    */   public void setNumeroSequencialTrailer(String numeroSequencialTrailer) {
/* 59 */     this.numeroSequencialTrailer = numeroSequencialTrailer;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout500\Trailler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */