/*    */ package br.com.accesstage.loader.util.vo.cargas.roadcard.decorator;
/*    */ 
/*    */ import com.github.ffpojo.metadata.DefaultFieldDecorator;
/*    */ 
/*    */ public class StringDecorator
/*    */   extends DefaultFieldDecorator {
/*    */   public Object fromString(String str) {
/*  8 */     if (!isNullOrWhitespace(str.trim())) {
/*  9 */       return String.valueOf(str);
/*    */     }
/* 11 */     return "";
/*    */   }
/*    */   
/*    */   public boolean isNullOrWhitespace(CharSequence value) {
/* 15 */     if (value == null) {
/* 16 */       return true;
/*    */     }
/* 18 */     for (int i = 0; i < value.length(); i++) {
/* 19 */       if (!Character.isWhitespace(value.charAt(i))) {
/* 20 */         return false;
/*    */       }
/*    */     } 
/* 23 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\decorator\StringDecorator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */