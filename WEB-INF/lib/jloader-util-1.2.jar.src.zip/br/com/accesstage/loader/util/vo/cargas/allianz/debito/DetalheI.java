/*    */ package br.com.accesstage.loader.util.vo.cargas.allianz.debito;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*    */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "I")})
/*    */ public class DetalheI
/*    */   extends AbstractVO
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*    */   private String codRegistro;
/*    */   @PositionalField(initialPosition = 2, finalPosition = 26)
/*    */   private String identClienteEmpresa;
/*    */   @PositionalField(initialPosition = 27, finalPosition = 27)
/*    */   private String identificao;
/*    */   @PositionalField(initialPosition = 28, finalPosition = 41)
/*    */   private String documento;
/*    */   @PositionalField(initialPosition = 42, finalPosition = 81)
/*    */   private String nomeConsumidor;
/*    */   @PositionalField(initialPosition = 82, finalPosition = 111)
/*    */   private String cidadeConsumidor;
/*    */   @PositionalField(initialPosition = 112, finalPosition = 113)
/*    */   private String estadoConsumidor;
/*    */   @PositionalField(initialPosition = 114, finalPosition = 150)
/*    */   private String usoFuturo;
/*    */   
/*    */   public String getCodRegistro() {
/* 35 */     return this.codRegistro;
/*    */   }
/*    */   public void setCodRegistro(String codRegistro) {
/* 38 */     this.codRegistro = codRegistro;
/*    */   }
/*    */   public String getIdentClienteEmpresa() {
/* 41 */     return this.identClienteEmpresa;
/*    */   }
/*    */   public void setIdentClienteEmpresa(String identClienteEmpresa) {
/* 44 */     this.identClienteEmpresa = identClienteEmpresa;
/*    */   }
/*    */   public String getIdentificao() {
/* 47 */     return this.identificao;
/*    */   }
/*    */   public void setIdentificao(String identificao) {
/* 50 */     this.identificao = identificao;
/*    */   }
/*    */   public String getDocumento() {
/* 53 */     return this.documento;
/*    */   }
/*    */   public void setDocumento(String documento) {
/* 56 */     this.documento = documento;
/*    */   }
/*    */   public String getNomeConsumidor() {
/* 59 */     return this.nomeConsumidor;
/*    */   }
/*    */   public void setNomeConsumidor(String nomeConsumidor) {
/* 62 */     this.nomeConsumidor = nomeConsumidor;
/*    */   }
/*    */   public String getCidadeConsumidor() {
/* 65 */     return this.cidadeConsumidor;
/*    */   }
/*    */   public void setCidadeConsumidor(String cidadeConsumidor) {
/* 68 */     this.cidadeConsumidor = cidadeConsumidor;
/*    */   }
/*    */   public String getEstadoConsumidor() {
/* 71 */     return this.estadoConsumidor;
/*    */   }
/*    */   public void setEstadoConsumidor(String estadoConsumidor) {
/* 74 */     this.estadoConsumidor = estadoConsumidor;
/*    */   }
/*    */   public String getUsoFuturo() {
/* 77 */     return this.usoFuturo;
/*    */   }
/*    */   public void setUsoFuturo(String usoFuturo) {
/* 80 */     this.usoFuturo = usoFuturo;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\allianz\debito\DetalheI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */