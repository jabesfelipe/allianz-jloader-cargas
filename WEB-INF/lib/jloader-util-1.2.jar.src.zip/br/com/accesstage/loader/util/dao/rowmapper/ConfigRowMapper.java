/*    */ package br.com.accesstage.loader.util.dao.rowmapper;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.Config;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class ConfigRowMapper
/*    */   implements RowMapper<Config>
/*    */ {
/*    */   public Config mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 13 */     Config config = new Config();
/* 14 */     config.setId(Long.valueOf(rs.getLong("ID")));
/* 15 */     config.setCreated(rs.getDate("CREATED"));
/* 16 */     config.setLayout(rs.getString("LAYOUT"));
/* 17 */     config.setNomeConfig(rs.getString("NME_CONFIG"));
/* 18 */     config.setValorConfig(rs.getString("VLR_CONFIG"));
/* 19 */     return config;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\ConfigRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */