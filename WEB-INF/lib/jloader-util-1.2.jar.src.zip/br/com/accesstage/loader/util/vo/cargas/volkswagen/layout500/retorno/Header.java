/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout500.retorno;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.DatePositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Header
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @IntegerPositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private Integer identRegistro;
/*     */   @IntegerPositionalField(initialPosition = 2, finalPosition = 9)
/*     */   private Integer codigoComunicacao;
/*     */   @IntegerPositionalField(initialPosition = 10, finalPosition = 10)
/*     */   private Integer tipoInscricao;
/*     */   @PositionalField(initialPosition = 11, finalPosition = 25)
/*     */   private String nroDocumento;
/*     */   @PositionalField(initialPosition = 26, finalPosition = 65)
/*     */   private String nmeEmpresa;
/*     */   @IntegerPositionalField(initialPosition = 66, finalPosition = 67)
/*     */   private Integer tipoServico;
/*     */   @IntegerPositionalField(initialPosition = 68, finalPosition = 68)
/*     */   private Integer codigoOrigemArquivo;
/*     */   @IntegerPositionalField(initialPosition = 69, finalPosition = 73)
/*     */   private Integer numeroRemessa;
/*     */   @IntegerPositionalField(initialPosition = 74, finalPosition = 78)
/*     */   private Integer numeroRetorno;
/*     */   @DatePositionalField(dateFormat = "yyyyMMddHHmmss", initialPosition = 79, finalPosition = 92)
/*     */   private Date dataHoraArquivo;
/*     */   @PositionalField(initialPosition = 93, finalPosition = 97)
/*     */   private String densidadeGravacao;
/*     */   @PositionalField(initialPosition = 98, finalPosition = 100)
/*     */   private String unidadeDensidadeGravacao;
/*     */   @PositionalField(initialPosition = 101, finalPosition = 105)
/*     */   private String identModuloMicro;
/*     */   @PositionalField(initialPosition = 106, finalPosition = 106)
/*     */   private String tipoProcessamento;
/*     */   @PositionalField(initialPosition = 107, finalPosition = 180)
/*     */   private String reservadoEmpresa;
/*     */   @PositionalField(initialPosition = 181, finalPosition = 260)
/*     */   private String reservadoBanco;
/*     */   @PositionalField(initialPosition = 261, finalPosition = 477)
/*     */   private String reservadoBanco2;
/*     */   @IntegerPositionalField(initialPosition = 478, finalPosition = 486)
/*     */   private Integer numeroListaDebito;
/*     */   @PositionalField(initialPosition = 487, finalPosition = 494)
/*     */   private String reservadoBanco3;
/*     */   @IntegerPositionalField(initialPosition = 495, finalPosition = 500)
/*     */   private Integer numeroSequencial;
/*     */   
/*     */   public Integer getIdentRegistro() {
/*  63 */     return this.identRegistro;
/*     */   }
/*     */   public void setIdentRegistro(Integer identRegistro) {
/*  66 */     this.identRegistro = identRegistro;
/*     */   }
/*     */   public Integer getCodigoComunicacao() {
/*  69 */     return this.codigoComunicacao;
/*     */   }
/*     */   public void setCodigoComunicacao(Integer codigoComunicacao) {
/*  72 */     this.codigoComunicacao = codigoComunicacao;
/*     */   }
/*     */   public Integer getTipoInscricao() {
/*  75 */     return this.tipoInscricao;
/*     */   }
/*     */   public void setTipoInscricao(Integer tipoInscricao) {
/*  78 */     this.tipoInscricao = tipoInscricao;
/*     */   }
/*     */   public String getNroDocumento() {
/*  81 */     return this.nroDocumento;
/*     */   }
/*     */   public void setNroDocumento(String nroDocumento) {
/*  84 */     this.nroDocumento = nroDocumento;
/*     */   }
/*     */   public String getNmeEmpresa() {
/*  87 */     return this.nmeEmpresa;
/*     */   }
/*     */   public void setNmeEmpresa(String nmeEmpresa) {
/*  90 */     this.nmeEmpresa = nmeEmpresa;
/*     */   }
/*     */   public Integer getTipoServico() {
/*  93 */     return this.tipoServico;
/*     */   }
/*     */   public void setTipoServico(Integer tipoServico) {
/*  96 */     this.tipoServico = tipoServico;
/*     */   }
/*     */   public Integer getCodigoOrigemArquivo() {
/*  99 */     return this.codigoOrigemArquivo;
/*     */   }
/*     */   public void setCodigoOrigemArquivo(Integer codigoOrigemArquivo) {
/* 102 */     this.codigoOrigemArquivo = codigoOrigemArquivo;
/*     */   }
/*     */   public Integer getNumeroRemessa() {
/* 105 */     return this.numeroRemessa;
/*     */   }
/*     */   public void setNumeroRemessa(Integer numeroRemessa) {
/* 108 */     this.numeroRemessa = numeroRemessa;
/*     */   }
/*     */   public Integer getNumeroRetorno() {
/* 111 */     return this.numeroRetorno;
/*     */   }
/*     */   public void setNumeroRetorno(Integer numeroRetorno) {
/* 114 */     this.numeroRetorno = numeroRetorno;
/*     */   }
/*     */   public Date getDataHoraArquivo() {
/* 117 */     return this.dataHoraArquivo;
/*     */   }
/*     */   public void setDataHoraArquivo(Date dataHoraArquivo) {
/* 120 */     this.dataHoraArquivo = dataHoraArquivo;
/*     */   }
/*     */   public String getDensidadeGravacao() {
/* 123 */     return this.densidadeGravacao;
/*     */   }
/*     */   public void setDensidadeGravacao(String densidadeGravacao) {
/* 126 */     this.densidadeGravacao = densidadeGravacao;
/*     */   }
/*     */   public String getUnidadeDensidadeGravacao() {
/* 129 */     return this.unidadeDensidadeGravacao;
/*     */   }
/*     */   public void setUnidadeDensidadeGravacao(String unidadeDensidadeGravacao) {
/* 132 */     this.unidadeDensidadeGravacao = unidadeDensidadeGravacao;
/*     */   }
/*     */   public String getIdentModuloMicro() {
/* 135 */     return this.identModuloMicro;
/*     */   }
/*     */   public void setIdentModuloMicro(String identModuloMicro) {
/* 138 */     this.identModuloMicro = identModuloMicro;
/*     */   }
/*     */   public String getTipoProcessamento() {
/* 141 */     return this.tipoProcessamento;
/*     */   }
/*     */   public void setTipoProcessamento(String tipoProcessamento) {
/* 144 */     this.tipoProcessamento = tipoProcessamento;
/*     */   }
/*     */   public String getReservadoEmpresa() {
/* 147 */     return this.reservadoEmpresa;
/*     */   }
/*     */   public void setReservadoEmpresa(String reservadoEmpresa) {
/* 150 */     this.reservadoEmpresa = reservadoEmpresa;
/*     */   }
/*     */   public String getReservadoBanco() {
/* 153 */     return this.reservadoBanco;
/*     */   }
/*     */   public void setReservadoBanco(String reservadoBanco) {
/* 156 */     this.reservadoBanco = reservadoBanco;
/*     */   }
/*     */   public String getReservadoBanco2() {
/* 159 */     return this.reservadoBanco2;
/*     */   }
/*     */   public void setReservadoBanco2(String reservadoBanco2) {
/* 162 */     this.reservadoBanco2 = reservadoBanco2;
/*     */   }
/*     */   public Integer getNumeroListaDebito() {
/* 165 */     return this.numeroListaDebito;
/*     */   }
/*     */   public void setNumeroListaDebito(Integer numeroListaDebito) {
/* 168 */     this.numeroListaDebito = numeroListaDebito;
/*     */   }
/*     */   public String getReservadoBanco3() {
/* 171 */     return this.reservadoBanco3;
/*     */   }
/*     */   public void setReservadoBanco3(String reservadoBanco3) {
/* 174 */     this.reservadoBanco3 = reservadoBanco3;
/*     */   }
/*     */   public Integer getNumeroSequencial() {
/* 177 */     return this.numeroSequencial;
/*     */   }
/*     */   public void setNumeroSequencial(Integer numeroSequencial) {
/* 180 */     this.numeroSequencial = numeroSequencial;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout500\retorno\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */