/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout500.remessa;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.DatePositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Header
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @IntegerPositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private Integer identRegistro;
/*     */   @IntegerPositionalField(initialPosition = 2, finalPosition = 9)
/*     */   private Integer codigoComunicacao;
/*     */   @IntegerPositionalField(initialPosition = 10, finalPosition = 10)
/*     */   private Integer tipoInscricao;
/*     */   @PositionalField(initialPosition = 11, finalPosition = 25)
/*     */   private String nroDocumento;
/*     */   @PositionalField(initialPosition = 26, finalPosition = 65)
/*     */   private String nmeEmpresa;
/*     */   @IntegerPositionalField(initialPosition = 66, finalPosition = 67)
/*     */   private Integer tipoServico;
/*     */   @IntegerPositionalField(initialPosition = 68, finalPosition = 68)
/*     */   private Integer codigoOrigemArquivo;
/*     */   @IntegerPositionalField(initialPosition = 69, finalPosition = 73)
/*     */   private Integer numeroRemessa;
/*     */   @IntegerPositionalField(initialPosition = 74, finalPosition = 78)
/*     */   private Integer numeroRetorno;
/*     */   @DatePositionalField(dateFormat = "yyyyMMddHHmmss", initialPosition = 79, finalPosition = 92)
/*     */   private Date dataHoraArquivo;
/*     */   @PositionalField(initialPosition = 93, finalPosition = 97)
/*     */   private String densidadeGravacao;
/*     */   @PositionalField(initialPosition = 98, finalPosition = 100)
/*     */   private String unidadeDensidadeGravacao;
/*     */   @PositionalField(initialPosition = 101, finalPosition = 105)
/*     */   private String identModuloMicro;
/*     */   @PositionalField(initialPosition = 106, finalPosition = 106)
/*     */   private String tipoProcessamento;
/*     */   @PositionalField(initialPosition = 107, finalPosition = 180)
/*     */   private String reservadoEmpresa;
/*     */   @PositionalField(initialPosition = 181, finalPosition = 260)
/*     */   private String reservadoBanco;
/*     */   @PositionalField(initialPosition = 261, finalPosition = 477)
/*     */   private String reservadoBanco2;
/*     */   @IntegerPositionalField(initialPosition = 478, finalPosition = 486)
/*     */   private Integer numeroListaDebito;
/*     */   @PositionalField(initialPosition = 487, finalPosition = 494)
/*     */   private String reservadoBanco3;
/*     */   @IntegerPositionalField(initialPosition = 495, finalPosition = 500)
/*     */   private Integer numeroSequencial;
/*     */   
/*     */   public Integer getIdentRegistro() {
/*  62 */     return this.identRegistro;
/*     */   }
/*     */   public void setIdentRegistro(Integer identRegistro) {
/*  65 */     this.identRegistro = identRegistro;
/*     */   }
/*     */   public Integer getCodigoComunicacao() {
/*  68 */     return this.codigoComunicacao;
/*     */   }
/*     */   public void setCodigoComunicacao(Integer codigoComunicacao) {
/*  71 */     this.codigoComunicacao = codigoComunicacao;
/*     */   }
/*     */   public Integer getTipoInscricao() {
/*  74 */     return this.tipoInscricao;
/*     */   }
/*     */   public void setTipoInscricao(Integer tipoInscricao) {
/*  77 */     this.tipoInscricao = tipoInscricao;
/*     */   }
/*     */   public String getNroDocumento() {
/*  80 */     return this.nroDocumento;
/*     */   }
/*     */   public void setNroDocumento(String nroDocumento) {
/*  83 */     this.nroDocumento = nroDocumento;
/*     */   }
/*     */   public String getNmeEmpresa() {
/*  86 */     return this.nmeEmpresa;
/*     */   }
/*     */   public void setNmeEmpresa(String nmeEmpresa) {
/*  89 */     this.nmeEmpresa = nmeEmpresa;
/*     */   }
/*     */   public Integer getTipoServico() {
/*  92 */     return this.tipoServico;
/*     */   }
/*     */   public void setTipoServico(Integer tipoServico) {
/*  95 */     this.tipoServico = tipoServico;
/*     */   }
/*     */   public Integer getCodigoOrigemArquivo() {
/*  98 */     return this.codigoOrigemArquivo;
/*     */   }
/*     */   public void setCodigoOrigemArquivo(Integer codigoOrigemArquivo) {
/* 101 */     this.codigoOrigemArquivo = codigoOrigemArquivo;
/*     */   }
/*     */   public Integer getNumeroRemessa() {
/* 104 */     return this.numeroRemessa;
/*     */   }
/*     */   public void setNumeroRemessa(Integer numeroRemessa) {
/* 107 */     this.numeroRemessa = numeroRemessa;
/*     */   }
/*     */   public Integer getNumeroRetorno() {
/* 110 */     return this.numeroRetorno;
/*     */   }
/*     */   public void setNumeroRetorno(Integer numeroRetorno) {
/* 113 */     this.numeroRetorno = numeroRetorno;
/*     */   }
/*     */   public Date getDataHoraArquivo() {
/* 116 */     return this.dataHoraArquivo;
/*     */   }
/*     */   public void setDataHoraArquivo(Date dataHoraArquivo) {
/* 119 */     this.dataHoraArquivo = dataHoraArquivo;
/*     */   }
/*     */   public String getDensidadeGravacao() {
/* 122 */     return this.densidadeGravacao;
/*     */   }
/*     */   public void setDensidadeGravacao(String densidadeGravacao) {
/* 125 */     this.densidadeGravacao = densidadeGravacao;
/*     */   }
/*     */   public String getUnidadeDensidadeGravacao() {
/* 128 */     return this.unidadeDensidadeGravacao;
/*     */   }
/*     */   public void setUnidadeDensidadeGravacao(String unidadeDensidadeGravacao) {
/* 131 */     this.unidadeDensidadeGravacao = unidadeDensidadeGravacao;
/*     */   }
/*     */   public String getIdentModuloMicro() {
/* 134 */     return this.identModuloMicro;
/*     */   }
/*     */   public void setIdentModuloMicro(String identModuloMicro) {
/* 137 */     this.identModuloMicro = identModuloMicro;
/*     */   }
/*     */   public String getTipoProcessamento() {
/* 140 */     return this.tipoProcessamento;
/*     */   }
/*     */   public void setTipoProcessamento(String tipoProcessamento) {
/* 143 */     this.tipoProcessamento = tipoProcessamento;
/*     */   }
/*     */   public String getReservadoEmpresa() {
/* 146 */     return this.reservadoEmpresa;
/*     */   }
/*     */   public void setReservadoEmpresa(String reservadoEmpresa) {
/* 149 */     this.reservadoEmpresa = reservadoEmpresa;
/*     */   }
/*     */   public String getReservadoBanco() {
/* 152 */     return this.reservadoBanco;
/*     */   }
/*     */   public void setReservadoBanco(String reservadoBanco) {
/* 155 */     this.reservadoBanco = reservadoBanco;
/*     */   }
/*     */   public String getReservadoBanco2() {
/* 158 */     return this.reservadoBanco2;
/*     */   }
/*     */   public void setReservadoBanco2(String reservadoBanco2) {
/* 161 */     this.reservadoBanco2 = reservadoBanco2;
/*     */   }
/*     */   public Integer getNumeroListaDebito() {
/* 164 */     return this.numeroListaDebito;
/*     */   }
/*     */   public void setNumeroListaDebito(Integer numeroListaDebito) {
/* 167 */     this.numeroListaDebito = numeroListaDebito;
/*     */   }
/*     */   public String getReservadoBanco3() {
/* 170 */     return this.reservadoBanco3;
/*     */   }
/*     */   public void setReservadoBanco3(String reservadoBanco3) {
/* 173 */     this.reservadoBanco3 = reservadoBanco3;
/*     */   }
/*     */   public Integer getNumeroSequencial() {
/* 176 */     return this.numeroSequencial;
/*     */   }
/*     */   public void setNumeroSequencial(Integer numeroSequencial) {
/* 179 */     this.numeroSequencial = numeroSequencial;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout500\remessa\Header.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */