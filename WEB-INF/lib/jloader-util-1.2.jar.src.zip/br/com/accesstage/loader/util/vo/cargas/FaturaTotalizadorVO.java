/*     */ package br.com.accesstage.loader.util.vo.cargas;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FaturaTotalizadorVO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -4827403289249652826L;
/*     */   private Long qtdTransCountSubtotal;
/*     */   private Long qtdTransCountTotal;
/*     */   private Double vlrGrossSubtotal;
/*     */   private Double vlrGrossTotal;
/*     */   private Double vlrComissionSubtotal;
/*     */   private Double vlrComissionTotal;
/*     */   private Double vlrTransfeeSubtotal;
/*     */   private Double vlrTransfeeTotal;
/*     */   private Double vlrVatSubtotal;
/*     */   private Double vlrVatTotal;
/*     */   private Double vlrSubtotalFatura;
/*     */   private Double vlrTotalFatura;
/*     */   
/*     */   public void setQtdTransCountSubtotal(Long qtdTransCountSubtotal) {
/*  28 */     this.qtdTransCountSubtotal = qtdTransCountSubtotal;
/*     */   }
/*     */   
/*     */   public Long getQtdTransCountSubtotal() {
/*  32 */     return this.qtdTransCountSubtotal;
/*     */   }
/*     */   
/*     */   public void setQtdTransCountTotal(Long qtdTransCountTotal) {
/*  36 */     this.qtdTransCountTotal = qtdTransCountTotal;
/*     */   }
/*     */   
/*     */   public Long getQtdTransCountTotal() {
/*  40 */     return this.qtdTransCountTotal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  47 */     return "" + this.qtdTransCountSubtotal + this.qtdTransCountTotal + this.vlrGrossSubtotal + this.vlrGrossTotal + this.vlrComissionSubtotal + this.vlrComissionTotal + this.vlrTransfeeSubtotal + this.vlrTransfeeTotal + this.vlrVatSubtotal + this.vlrVatTotal + this.vlrSubtotalFatura + this.vlrTotalFatura;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVlrGrossSubtotal(Double vlrGrossSubtotal) {
/*  52 */     this.vlrGrossSubtotal = vlrGrossSubtotal;
/*     */   }
/*     */   
/*     */   public Double getVlrGrossSubtotal() {
/*  56 */     return this.vlrGrossSubtotal;
/*     */   }
/*     */   
/*     */   public void setVlrGrossTotal(Double vlrGrossTotal) {
/*  60 */     this.vlrGrossTotal = vlrGrossTotal;
/*     */   }
/*     */   
/*     */   public Double getVlrGrossTotal() {
/*  64 */     return this.vlrGrossTotal;
/*     */   }
/*     */   
/*     */   public void setVlrComissionSubtotal(Double vlrComissionSubtotal) {
/*  68 */     this.vlrComissionSubtotal = vlrComissionSubtotal;
/*     */   }
/*     */   
/*     */   public Double getVlrComissionSubtotal() {
/*  72 */     return this.vlrComissionSubtotal;
/*     */   }
/*     */   
/*     */   public void setVlrComissionTotal(Double vlrComissionTotal) {
/*  76 */     this.vlrComissionTotal = vlrComissionTotal;
/*     */   }
/*     */   
/*     */   public Double getVlrComissionTotal() {
/*  80 */     return this.vlrComissionTotal;
/*     */   }
/*     */   
/*     */   public void setVlrTransfeeSubtotal(Double vlrTransfeeSubtotal) {
/*  84 */     this.vlrTransfeeSubtotal = vlrTransfeeSubtotal;
/*     */   }
/*     */   
/*     */   public Double getVlrTransfeeSubtotal() {
/*  88 */     return this.vlrTransfeeSubtotal;
/*     */   }
/*     */   
/*     */   public void setVlrTransfeeTotal(Double vlrTransfeeTotal) {
/*  92 */     this.vlrTransfeeTotal = vlrTransfeeTotal;
/*     */   }
/*     */   
/*     */   public Double getVlrTransfeeTotal() {
/*  96 */     return this.vlrTransfeeTotal;
/*     */   }
/*     */   
/*     */   public void setVlrVatSubtotal(Double vlrVatSubtotal) {
/* 100 */     this.vlrVatSubtotal = vlrVatSubtotal;
/*     */   }
/*     */   
/*     */   public Double getVlrVatSubtotal() {
/* 104 */     return this.vlrVatSubtotal;
/*     */   }
/*     */   
/*     */   public void setVlrVatTotal(Double vlrVatTotal) {
/* 108 */     this.vlrVatTotal = vlrVatTotal;
/*     */   }
/*     */   
/*     */   public Double getVlrVatTotal() {
/* 112 */     return this.vlrVatTotal;
/*     */   }
/*     */   
/*     */   public void setVlrSubtotalFatura(Double vlrSubtotalFatura) {
/* 116 */     this.vlrSubtotalFatura = vlrSubtotalFatura;
/*     */   }
/*     */   
/*     */   public Double getVlrSubtotalFatura() {
/* 120 */     return this.vlrSubtotalFatura;
/*     */   }
/*     */   
/*     */   public void setVlrTotalFatura(Double vlrTotalFatura) {
/* 124 */     this.vlrTotalFatura = vlrTotalFatura;
/*     */   }
/*     */   
/*     */   public Double getVlrTotalFatura() {
/* 128 */     return this.vlrTotalFatura;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\FaturaTotalizadorVO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */