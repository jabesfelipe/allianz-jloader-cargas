/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout150;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.decorator.DateDecorator;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecordLineIdentifier;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.DoublePositionalField;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord(lineIdentifiers = {@PositionalRecordLineIdentifier(startPosition = 1, textIdentifier = "F")})
/*     */ public class DetalheFV4
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = -8547806592198397193L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private String codRegistro;
/*     */   @PositionalField(initialPosition = 2, finalPosition = 26)
/*     */   private String identClienteEmpresa;
/*     */   @PositionalField(initialPosition = 27, finalPosition = 30)
/*     */   private String agenciaDebito;
/*     */   @PositionalField(initialPosition = 31, finalPosition = 44)
/*     */   private String identClienteBanco;
/*     */   @PositionalField(initialPosition = 45, finalPosition = 52, decorator = DateDecorator.class)
/*     */   private Date dtaVencimentoOuDebito;
/*     */   @DoublePositionalField(initialPosition = 53, finalPosition = 67)
/*     */   private Double vlorOriginalDebitado;
/*     */   @PositionalField(initialPosition = 68, finalPosition = 69)
/*     */   private String codRetorno;
/*     */   @PositionalField(initialPosition = 70, finalPosition = 139)
/*  35 */   private String usoEmpresa = null;
/*     */   @PositionalField(initialPosition = 140, finalPosition = 149)
/*  37 */   private String usoFuturo = null;
/*     */   @PositionalField(initialPosition = 150, finalPosition = 150)
/*  39 */   private String codMovimento = null;
/*     */ 
/*     */   
/*     */   public String getCodRegistro() {
/*  43 */     return this.codRegistro;
/*     */   }
/*     */   public void setCodRegistro(String codRegistro) {
/*  46 */     this.codRegistro = codRegistro;
/*     */   }
/*     */   public String getIdentClienteEmpresa() {
/*  49 */     return this.identClienteEmpresa;
/*     */   }
/*     */   public void setIdentClienteEmpresa(String identClienteEmpresa) {
/*  52 */     this.identClienteEmpresa = identClienteEmpresa;
/*     */   }
/*     */   public String getAgenciaDebito() {
/*  55 */     return this.agenciaDebito;
/*     */   }
/*     */   public void setAgenciaDebito(String agenciaDebito) {
/*  58 */     this.agenciaDebito = agenciaDebito;
/*     */   }
/*     */   public String getIdentClienteBanco() {
/*  61 */     return this.identClienteBanco;
/*     */   }
/*     */   public void setIdentClienteBanco(String identClienteBanco) {
/*  64 */     this.identClienteBanco = identClienteBanco;
/*     */   }
/*     */   public Date getDtaVencimentoOuDebito() {
/*  67 */     return this.dtaVencimentoOuDebito;
/*     */   }
/*     */   public void setDtaVencimentoOuDebito(Date dtaVencimentoOuDebito) {
/*  70 */     this.dtaVencimentoOuDebito = dtaVencimentoOuDebito;
/*     */   }
/*     */   public Double getVlorOriginalDebitado() {
/*  73 */     return Double.valueOf(this.vlorOriginalDebitado.doubleValue() / 100.0D);
/*     */   }
/*     */   public void setVlorOriginalDebitado(Double vlorOriginalDebitado) {
/*  76 */     this.vlorOriginalDebitado = vlorOriginalDebitado;
/*     */   }
/*     */   public String getCodRetorno() {
/*  79 */     return this.codRetorno;
/*     */   }
/*     */   public void setCodRetorno(String codRetorno) {
/*  82 */     this.codRetorno = codRetorno;
/*     */   }
/*     */   public String getUsoEmpresa() {
/*  85 */     return this.usoEmpresa;
/*     */   }
/*     */   public void setUsoEmpresa(String usoEmpresa) {
/*  88 */     this.usoEmpresa = usoEmpresa;
/*     */   }
/*     */   public String getUsoFuturo() {
/*  91 */     return this.usoFuturo;
/*     */   }
/*     */   public void setUsoFuturo(String usoFuturo) {
/*  94 */     this.usoFuturo = usoFuturo;
/*     */   }
/*     */   public String getCodMovimento() {
/*  97 */     return this.codMovimento;
/*     */   }
/*     */   public void setCodMovimento(String codMovimento) {
/* 100 */     this.codMovimento = codMovimento;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout150\DetalheFV4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */