/*     */ package br.com.accesstage.loader.util.vo.cargas.roadcard.layout240;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.layout240.decorator.DateDecorator240;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class HdrLteCobL045
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 466544247717479140L;
/*     */   @PositionalField(initialPosition = 1, finalPosition = 3)
/*     */   private String codBcoHdrLte;
/*     */   @IntegerPositionalField(initialPosition = 4, finalPosition = 7)
/*     */   private Integer lteServicoHdrLte;
/*     */   @IntegerPositionalField(initialPosition = 8, finalPosition = 8)
/*     */   private Integer tpoRegHdrLte;
/*     */   @PositionalField(initialPosition = 9, finalPosition = 9)
/*     */   private String codTpoOpLte;
/*     */   @IntegerPositionalField(initialPosition = 10, finalPosition = 11)
/*     */   private Integer codTpoServico;
/*     */   @PositionalField(initialPosition = 12, finalPosition = 14)
/*     */   private String dscUsoFbrn1;
/*     */   @IntegerPositionalField(initialPosition = 15, finalPosition = 17)
/*     */   private Integer nroLyt;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 18)
/*     */   private String dscUsoFbrn2;
/*     */   @IntegerPositionalField(initialPosition = 19, finalPosition = 19)
/*     */   private Integer tpoInsEmp;
/*     */   @LongPositionalField(initialPosition = 20, finalPosition = 34)
/*     */   private Long nroInsEmp;
/*     */   @PositionalField(initialPosition = 35, finalPosition = 54)
/*     */   private String codConvenio;
/*     */   @IntegerPositionalField(initialPosition = 55, finalPosition = 59)
/*     */   private Integer dscAgencia;
/*     */   @PositionalField(initialPosition = 60, finalPosition = 60)
/*     */   private String dscAgenciaDV;
/*     */   @LongPositionalField(initialPosition = 61, finalPosition = 72)
/*     */   private Long dscConta;
/*     */   @PositionalField(initialPosition = 73, finalPosition = 73)
/*     */   private String dscContaDV;
/*     */   @PositionalField(initialPosition = 74, finalPosition = 74)
/*     */   private String dscAgeCta;
/*     */   @PositionalField(initialPosition = 75, finalPosition = 104)
/*     */   private String nmeEmp;
/*     */   @PositionalField(initialPosition = 105, finalPosition = 144)
/*     */   private String dscMsg1;
/*     */   @PositionalField(initialPosition = 145, finalPosition = 184)
/*     */   private String dscMsg2;
/*     */   @PositionalField(initialPosition = 185, finalPosition = 193)
/*     */   private String nrmRmssRtrn;
/*     */   @PositionalField(initialPosition = 194, finalPosition = 203, decorator = DateDecorator240.class)
/*     */   private Date dtaGeracaoRmssRtrn;
/*     */   @PositionalField(initialPosition = 204, finalPosition = 211, decorator = DateDecorator240.class)
/*     */   private Date dtaCredito;
/*     */   @PositionalField(initialPosition = 212, finalPosition = 240)
/*     */   private String dscUsoFbrn3;
/*     */   
/*     */   public String getCodBcoHdrLte() {
/*  71 */     return this.codBcoHdrLte;
/*     */   }
/*     */   public void setCodBcoHdrLte(String codBcoHdrLte) {
/*  74 */     this.codBcoHdrLte = codBcoHdrLte;
/*     */   }
/*     */   public Integer getLteServicoHdrLte() {
/*  77 */     return this.lteServicoHdrLte;
/*     */   }
/*     */   public void setLteServicoHdrLte(Integer lteServicoHdrLte) {
/*  80 */     this.lteServicoHdrLte = lteServicoHdrLte;
/*     */   }
/*     */   public Integer getTpoRegHdrLte() {
/*  83 */     return this.tpoRegHdrLte;
/*     */   }
/*     */   public void setTpoRegHdrLte(Integer tpoRegHdrLte) {
/*  86 */     this.tpoRegHdrLte = tpoRegHdrLte;
/*     */   }
/*     */   public String getCodTpoOpLte() {
/*  89 */     return this.codTpoOpLte;
/*     */   }
/*     */   public void setCodTpoOpLte(String codTpoOpLte) {
/*  92 */     this.codTpoOpLte = codTpoOpLte;
/*     */   }
/*     */   public Integer getCodTpoServico() {
/*  95 */     return this.codTpoServico;
/*     */   }
/*     */   public void setCodTpoServico(Integer codTpoServico) {
/*  98 */     this.codTpoServico = codTpoServico;
/*     */   }
/*     */   public String getDscUsoFbrn1() {
/* 101 */     return this.dscUsoFbrn1;
/*     */   }
/*     */   public void setDscUsoFbrn1(String dscUsoFbrn1) {
/* 104 */     this.dscUsoFbrn1 = dscUsoFbrn1;
/*     */   }
/*     */   public Integer getNroLyt() {
/* 107 */     return this.nroLyt;
/*     */   }
/*     */   public void setNroLyt(Integer nroLyt) {
/* 110 */     this.nroLyt = nroLyt;
/*     */   }
/*     */   public String getDscUsoFbrn2() {
/* 113 */     return this.dscUsoFbrn2;
/*     */   }
/*     */   public void setDscUsoFbrn2(String dscUsoFbrn2) {
/* 116 */     this.dscUsoFbrn2 = dscUsoFbrn2;
/*     */   }
/*     */   public Integer getTpoInsEmp() {
/* 119 */     return this.tpoInsEmp;
/*     */   }
/*     */   public void setTpoInsEmp(Integer tpoInsEmp) {
/* 122 */     this.tpoInsEmp = tpoInsEmp;
/*     */   }
/*     */   public Long getNroInsEmp() {
/* 125 */     return this.nroInsEmp;
/*     */   }
/*     */   public void setNroInsEmp(Long nroInsEmp) {
/* 128 */     this.nroInsEmp = nroInsEmp;
/*     */   }
/*     */   public String getCodConvenio() {
/* 131 */     return this.codConvenio;
/*     */   }
/*     */   public void setCodConvenio(String codConvenio) {
/* 134 */     this.codConvenio = codConvenio;
/*     */   }
/*     */   public Integer getDscAgencia() {
/* 137 */     return this.dscAgencia;
/*     */   }
/*     */   public void setDscAgencia(Integer dscAgencia) {
/* 140 */     this.dscAgencia = dscAgencia;
/*     */   }
/*     */   public String getDscAgenciaDV() {
/* 143 */     return this.dscAgenciaDV;
/*     */   }
/*     */   public void setDscAgenciaDV(String dscAgenciaDV) {
/* 146 */     this.dscAgenciaDV = dscAgenciaDV;
/*     */   }
/*     */   public Long getDscConta() {
/* 149 */     return this.dscConta;
/*     */   }
/*     */   public void setDscConta(Long dscConta) {
/* 152 */     this.dscConta = dscConta;
/*     */   }
/*     */   public String getDscContaDV() {
/* 155 */     return this.dscContaDV;
/*     */   }
/*     */   public void setDscContaDV(String dscContaDV) {
/* 158 */     this.dscContaDV = dscContaDV;
/*     */   }
/*     */   public String getDscAgeCta() {
/* 161 */     return this.dscAgeCta;
/*     */   }
/*     */   public void setDscAgeCta(String dscAgeCta) {
/* 164 */     this.dscAgeCta = dscAgeCta;
/*     */   }
/*     */   public String getNmeEmp() {
/* 167 */     return this.nmeEmp;
/*     */   }
/*     */   public void setNmeEmp(String nmeEmp) {
/* 170 */     this.nmeEmp = nmeEmp;
/*     */   }
/*     */   public String getDscMsg1() {
/* 173 */     return this.dscMsg1;
/*     */   }
/*     */   public void setDscMsg1(String dscMsg1) {
/* 176 */     this.dscMsg1 = dscMsg1;
/*     */   }
/*     */   public String getDscMsg2() {
/* 179 */     return this.dscMsg2;
/*     */   }
/*     */   public void setDscMsg2(String dscMsg2) {
/* 182 */     this.dscMsg2 = dscMsg2;
/*     */   }
/*     */   public String getNrmRmssRtrn() {
/* 185 */     return this.nrmRmssRtrn;
/*     */   }
/*     */   public void setNrmRmssRtrn(String nrmRmssRtrn) {
/* 188 */     this.nrmRmssRtrn = nrmRmssRtrn;
/*     */   }
/*     */   public Date getDtaGeracaoRmssRtrn() {
/* 191 */     return this.dtaGeracaoRmssRtrn;
/*     */   }
/*     */   public void setDtaGeracaoRmssRtrn(Date dtaGeracaoRmssRtrn) {
/* 194 */     this.dtaGeracaoRmssRtrn = dtaGeracaoRmssRtrn;
/*     */   }
/*     */   public Date getDtaCredito() {
/* 197 */     return this.dtaCredito;
/*     */   }
/*     */   public void setDtaCredito(Date dtaCredito) {
/* 200 */     this.dtaCredito = dtaCredito;
/*     */   }
/*     */   public String getDscUsoFbrn3() {
/* 203 */     return this.dscUsoFbrn3;
/*     */   }
/*     */   public void setDscUsoFbrn3(String dscUsoFbrn3) {
/* 206 */     this.dscUsoFbrn3 = dscUsoFbrn3;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto_20200225_RMS_01.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\roadcard\layout240\HdrLteCobL045.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */