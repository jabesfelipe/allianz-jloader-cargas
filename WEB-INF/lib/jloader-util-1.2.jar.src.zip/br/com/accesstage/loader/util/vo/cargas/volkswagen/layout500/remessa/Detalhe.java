/*     */ package br.com.accesstage.loader.util.vo.cargas.volkswagen.layout500.remessa;
/*     */ 
/*     */ import br.com.accesstage.loader.util.vo.cargas.roadcard.AbstractVO;
/*     */ import br.com.accesstage.loader.util.vo.cargas.volkswagen.decorator.DateDecorator_YYYYMMDD;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.PositionalRecord;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.DatePositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.IntegerPositionalField;
/*     */ import com.github.ffpojo.metadata.positional.annotation.extra.LongPositionalField;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PositionalRecord
/*     */ public class Detalhe
/*     */   extends AbstractVO
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @IntegerPositionalField(initialPosition = 1, finalPosition = 1)
/*     */   private Integer identRegistro;
/*     */   @IntegerPositionalField(initialPosition = 2, finalPosition = 2)
/*     */   private Integer tipoInscricao;
/*     */   @PositionalField(initialPosition = 3, finalPosition = 17)
/*     */   private String nroDocumento;
/*     */   @PositionalField(initialPosition = 18, finalPosition = 47)
/*     */   private String nomeFornecedor;
/*     */   @PositionalField(initialPosition = 48, finalPosition = 87)
/*     */   private String enderecoFornecedor;
/*     */   @PositionalField(initialPosition = 88, finalPosition = 95)
/*     */   private String cepFornecedor;
/*     */   @IntegerPositionalField(initialPosition = 96, finalPosition = 98)
/*     */   private Integer codigoBancoFornecedor;
/*     */   @IntegerPositionalField(initialPosition = 99, finalPosition = 103)
/*     */   private Integer agenciaFornecedor;
/*     */   @PositionalField(initialPosition = 104, finalPosition = 104)
/*     */   private String digitoFornecedor;
/*     */   @IntegerPositionalField(initialPosition = 105, finalPosition = 117)
/*     */   private Integer contaCorrenteFornecedor;
/*     */   @PositionalField(initialPosition = 118, finalPosition = 119)
/*     */   private String digitoContaCorrenteFornecedor;
/*     */   @PositionalField(initialPosition = 120, finalPosition = 135)
/*     */   private String numeroPagamento;
/*     */   @IntegerPositionalField(initialPosition = 136, finalPosition = 138)
/*     */   private Integer carteira;
/*     */   @IntegerPositionalField(initialPosition = 139, finalPosition = 150)
/*     */   private Integer nossoNumero;
/*     */   @IntegerPositionalField(initialPosition = 151, finalPosition = 165)
/*     */   private Integer seuNumero;
/*     */   @DatePositionalField(dateFormat = "yyyyMMdd", initialPosition = 166, finalPosition = 173)
/*     */   private Date dataVencimento;
/*     */   @DatePositionalField(dateFormat = "yyyyMMdd", initialPosition = 174, finalPosition = 181)
/*     */   private Date dataEmissaoDocumento;
/*     */   @PositionalField(initialPosition = 182, finalPosition = 189, decorator = DateDecorator_YYYYMMDD.class)
/*     */   private Date dataLimiteDesconto;
/*     */   @IntegerPositionalField(initialPosition = 190, finalPosition = 190)
/*     */   private Integer zero;
/*     */   @IntegerPositionalField(initialPosition = 191, finalPosition = 194)
/*     */   private Integer fatorVencimento;
/*     */   @LongPositionalField(initialPosition = 195, finalPosition = 204)
/*     */   private Long valorDocumento;
/*     */   @LongPositionalField(initialPosition = 205, finalPosition = 219)
/*     */   private Long valorPagamento;
/*     */   @LongPositionalField(initialPosition = 220, finalPosition = 234)
/*     */   private Long valorDesconto;
/*     */   @LongPositionalField(initialPosition = 235, finalPosition = 249)
/*     */   private Long valorAcrescimo;
/*     */   @IntegerPositionalField(initialPosition = 250, finalPosition = 251)
/*     */   private Integer tipoDocumento;
/*     */   @PositionalField(initialPosition = 252, finalPosition = 261)
/*     */   private String numeroNotaFiscal;
/*     */   @IntegerPositionalField(initialPosition = 262, finalPosition = 263)
/*     */   private Integer serieDocumento;
/*     */   @PositionalField(initialPosition = 264, finalPosition = 265)
/*     */   private String modalidadePagamento;
/*     */   @DatePositionalField(dateFormat = "yyyyMMdd", initialPosition = 266, finalPosition = 273)
/*     */   private Date dataEfetivacao;
/*     */   @PositionalField(initialPosition = 274, finalPosition = 276)
/*     */   private String moeda;
/*     */   @PositionalField(initialPosition = 277, finalPosition = 278)
/*     */   private String situacaoAgendamento;
/*     */   @PositionalField(initialPosition = 279, finalPosition = 280)
/*     */   private String informacaoRetorno1;
/*     */   @PositionalField(initialPosition = 281, finalPosition = 282)
/*     */   private String informacaoRetorno2;
/*     */   @PositionalField(initialPosition = 283, finalPosition = 284)
/*     */   private String informacaoRetorno3;
/*     */   @PositionalField(initialPosition = 285, finalPosition = 286)
/*     */   private String informacaoRetorno4;
/*     */   @PositionalField(initialPosition = 287, finalPosition = 288)
/*     */   private String informacaoRetorno5;
/*     */   @IntegerPositionalField(initialPosition = 289, finalPosition = 289)
/*     */   private Integer tipoMovimento;
/*     */   @IntegerPositionalField(initialPosition = 290, finalPosition = 291)
/*     */   private Integer codigoMovimento;
/*     */   @IntegerPositionalField(initialPosition = 292, finalPosition = 295)
/*     */   private Integer horarioConsultaSaldo;
/*     */   @LongPositionalField(initialPosition = 296, finalPosition = 310)
/*     */   private Long saldoDisponivelSaldo;
/*     */   @LongPositionalField(initialPosition = 311, finalPosition = 325)
/*     */   private Long valorTaxaPreFunding;
/*     */   @PositionalField(initialPosition = 326, finalPosition = 331)
/*     */   private String reserva;
/*     */   @PositionalField(initialPosition = 332, finalPosition = 371)
/*     */   private String sacadorAvalista;
/*     */   @PositionalField(initialPosition = 372, finalPosition = 372)
/*     */   private String reserva2;
/*     */   @PositionalField(initialPosition = 373, finalPosition = 373)
/*     */   private String nivelInfoRetorno;
/*     */   @PositionalField(initialPosition = 374, finalPosition = 413)
/*     */   private String informacoesComplementares;
/*     */   @IntegerPositionalField(initialPosition = 414, finalPosition = 415)
/*     */   private Integer codigoAreaEmpresa;
/*     */   @PositionalField(initialPosition = 416, finalPosition = 450)
/*     */   private String campoUsoEmpresa;
/*     */   @PositionalField(initialPosition = 451, finalPosition = 472)
/*     */   private String reserva3;
/*     */   @IntegerPositionalField(initialPosition = 473, finalPosition = 477)
/*     */   private Integer codigoLancamento;
/*     */   @PositionalField(initialPosition = 478, finalPosition = 478)
/*     */   private String reserva4;
/*     */   @IntegerPositionalField(initialPosition = 479, finalPosition = 479)
/*     */   private Integer tipoContaFornecedor;
/*     */   @PositionalField(initialPosition = 480, finalPosition = 486)
/*     */   private String contaComplementar;
/*     */   @PositionalField(initialPosition = 487, finalPosition = 494)
/*     */   private String reserva5;
/*     */   @IntegerPositionalField(initialPosition = 495, finalPosition = 500)
/*     */   private Integer numeroSequencial;
/*     */   
/*     */   public Integer getIdentRegistro() {
/* 136 */     return this.identRegistro;
/*     */   }
/*     */   public void setIdentRegistro(Integer identRegistro) {
/* 139 */     this.identRegistro = identRegistro;
/*     */   }
/*     */   public Integer getTipoInscricao() {
/* 142 */     return this.tipoInscricao;
/*     */   }
/*     */   public void setTipoInscricao(Integer tipoInscricao) {
/* 145 */     this.tipoInscricao = tipoInscricao;
/*     */   }
/*     */   public String getNroDocumento() {
/* 148 */     return this.nroDocumento;
/*     */   }
/*     */   public void setNroDocumento(String nroDocumento) {
/* 151 */     this.nroDocumento = nroDocumento;
/*     */   }
/*     */   public String getNomeFornecedor() {
/* 154 */     return this.nomeFornecedor;
/*     */   }
/*     */   public void setNomeFornecedor(String nomeFornecedor) {
/* 157 */     this.nomeFornecedor = nomeFornecedor;
/*     */   }
/*     */   public String getEnderecoFornecedor() {
/* 160 */     return this.enderecoFornecedor;
/*     */   }
/*     */   public void setEnderecoFornecedor(String enderecoFornecedor) {
/* 163 */     this.enderecoFornecedor = enderecoFornecedor;
/*     */   }
/*     */   public String getCepFornecedor() {
/* 166 */     return this.cepFornecedor;
/*     */   }
/*     */   public void setCepFornecedor(String cepFornecedor) {
/* 169 */     this.cepFornecedor = cepFornecedor;
/*     */   }
/*     */   public Integer getCodigoBancoFornecedor() {
/* 172 */     return this.codigoBancoFornecedor;
/*     */   }
/*     */   public void setCodigoBancoFornecedor(Integer codigoBancoFornecedor) {
/* 175 */     this.codigoBancoFornecedor = codigoBancoFornecedor;
/*     */   }
/*     */   public Integer getAgenciaFornecedor() {
/* 178 */     return this.agenciaFornecedor;
/*     */   }
/*     */   public void setAgenciaFornecedor(Integer agenciaFornecedor) {
/* 181 */     this.agenciaFornecedor = agenciaFornecedor;
/*     */   }
/*     */   public String getDigitoFornecedor() {
/* 184 */     return this.digitoFornecedor;
/*     */   }
/*     */   public void setDigitoFornecedor(String digitoFornecedor) {
/* 187 */     this.digitoFornecedor = digitoFornecedor;
/*     */   }
/*     */   public Integer getContaCorrenteFornecedor() {
/* 190 */     return this.contaCorrenteFornecedor;
/*     */   }
/*     */   public void setContaCorrenteFornecedor(Integer contaCorrenteFornecedor) {
/* 193 */     this.contaCorrenteFornecedor = contaCorrenteFornecedor;
/*     */   }
/*     */   public String getDigitoContaCorrenteFornecedor() {
/* 196 */     return this.digitoContaCorrenteFornecedor;
/*     */   }
/*     */   public void setDigitoContaCorrenteFornecedor(String digitoContaCorrenteFornecedor) {
/* 199 */     this.digitoContaCorrenteFornecedor = digitoContaCorrenteFornecedor;
/*     */   }
/*     */   public String getNumeroPagamento() {
/* 202 */     return this.numeroPagamento;
/*     */   }
/*     */   public void setNumeroPagamento(String numeroPagamento) {
/* 205 */     this.numeroPagamento = numeroPagamento;
/*     */   }
/*     */   public Integer getCarteira() {
/* 208 */     return this.carteira;
/*     */   }
/*     */   public void setCarteira(Integer carteira) {
/* 211 */     this.carteira = carteira;
/*     */   }
/*     */   public Integer getNossoNumero() {
/* 214 */     return this.nossoNumero;
/*     */   }
/*     */   public void setNossoNumero(Integer nossoNumero) {
/* 217 */     this.nossoNumero = nossoNumero;
/*     */   }
/*     */   public Integer getSeuNumero() {
/* 220 */     return this.seuNumero;
/*     */   }
/*     */   public void setSeuNumero(Integer seuNumero) {
/* 223 */     this.seuNumero = seuNumero;
/*     */   }
/*     */   public Date getDataVencimento() {
/* 226 */     return this.dataVencimento;
/*     */   }
/*     */   public void setDataVencimento(Date dataVencimento) {
/* 229 */     this.dataVencimento = dataVencimento;
/*     */   }
/*     */   public Date getDataEmissaoDocumento() {
/* 232 */     return this.dataEmissaoDocumento;
/*     */   }
/*     */   public void setDataEmissaoDocumento(Date dataEmissaoDocumento) {
/* 235 */     this.dataEmissaoDocumento = dataEmissaoDocumento;
/*     */   }
/*     */   public Date getDataLimiteDesconto() {
/* 238 */     return this.dataLimiteDesconto;
/*     */   }
/*     */   public void setDataLimiteDesconto(Date dataLimiteDesconto) {
/* 241 */     this.dataLimiteDesconto = dataLimiteDesconto;
/*     */   }
/*     */   public Integer getZero() {
/* 244 */     return this.zero;
/*     */   }
/*     */   public void setZero(Integer zero) {
/* 247 */     this.zero = zero;
/*     */   }
/*     */   public Integer getFatorVencimento() {
/* 250 */     return this.fatorVencimento;
/*     */   }
/*     */   public void setFatorVencimento(Integer fatorVencimento) {
/* 253 */     this.fatorVencimento = fatorVencimento;
/*     */   }
/*     */   public Long getValorDocumento() {
/* 256 */     return this.valorDocumento;
/*     */   }
/*     */   public void setValorDocumento(Long valorDocumento) {
/* 259 */     this.valorDocumento = valorDocumento;
/*     */   }
/*     */   public Long getValorPagamento() {
/* 262 */     return this.valorPagamento;
/*     */   }
/*     */   public void setValorPagamento(Long valorPagamento) {
/* 265 */     this.valorPagamento = valorPagamento;
/*     */   }
/*     */   public Long getValorDesconto() {
/* 268 */     return this.valorDesconto;
/*     */   }
/*     */   public void setValorDesconto(Long valorDesconto) {
/* 271 */     this.valorDesconto = valorDesconto;
/*     */   }
/*     */   public Long getValorAcrescimo() {
/* 274 */     return this.valorAcrescimo;
/*     */   }
/*     */   public void setValorAcrescimo(Long valorAcrescimo) {
/* 277 */     this.valorAcrescimo = valorAcrescimo;
/*     */   }
/*     */   public Integer getTipoDocumento() {
/* 280 */     return this.tipoDocumento;
/*     */   }
/*     */   public void setTipoDocumento(Integer tipoDocumento) {
/* 283 */     this.tipoDocumento = tipoDocumento;
/*     */   }
/*     */   public String getNumeroNotaFiscal() {
/* 286 */     return this.numeroNotaFiscal;
/*     */   }
/*     */   public void setNumeroNotaFiscal(String numeroNotaFiscal) {
/* 289 */     this.numeroNotaFiscal = numeroNotaFiscal;
/*     */   }
/*     */   public Integer getSerieDocumento() {
/* 292 */     return this.serieDocumento;
/*     */   }
/*     */   public void setSerieDocumento(Integer serieDocumento) {
/* 295 */     this.serieDocumento = serieDocumento;
/*     */   }
/*     */   public String getModalidadePagamento() {
/* 298 */     return this.modalidadePagamento;
/*     */   }
/*     */   public void setModalidadePagamento(String modalidadePagamento) {
/* 301 */     this.modalidadePagamento = modalidadePagamento;
/*     */   }
/*     */   public Date getDataEfetivacao() {
/* 304 */     return this.dataEfetivacao;
/*     */   }
/*     */   public void setDataEfetivacao(Date dataEfetivacao) {
/* 307 */     this.dataEfetivacao = dataEfetivacao;
/*     */   }
/*     */   public String getMoeda() {
/* 310 */     return this.moeda;
/*     */   }
/*     */   public void setMoeda(String moeda) {
/* 313 */     this.moeda = moeda;
/*     */   }
/*     */   public String getSituacaoAgendamento() {
/* 316 */     return this.situacaoAgendamento;
/*     */   }
/*     */   public void setSituacaoAgendamento(String situacaoAgendamento) {
/* 319 */     this.situacaoAgendamento = situacaoAgendamento;
/*     */   }
/*     */   public String getInformacaoRetorno1() {
/* 322 */     return this.informacaoRetorno1;
/*     */   }
/*     */   public void setInformacaoRetorno1(String informacaoRetorno1) {
/* 325 */     this.informacaoRetorno1 = informacaoRetorno1;
/*     */   }
/*     */   public String getInformacaoRetorno2() {
/* 328 */     return this.informacaoRetorno2;
/*     */   }
/*     */   public void setInformacaoRetorno2(String informacaoRetorno2) {
/* 331 */     this.informacaoRetorno2 = informacaoRetorno2;
/*     */   }
/*     */   public String getInformacaoRetorno3() {
/* 334 */     return this.informacaoRetorno3;
/*     */   }
/*     */   public void setInformacaoRetorno3(String informacaoRetorno3) {
/* 337 */     this.informacaoRetorno3 = informacaoRetorno3;
/*     */   }
/*     */   public String getInformacaoRetorno4() {
/* 340 */     return this.informacaoRetorno4;
/*     */   }
/*     */   public void setInformacaoRetorno4(String informacaoRetorno4) {
/* 343 */     this.informacaoRetorno4 = informacaoRetorno4;
/*     */   }
/*     */   public String getInformacaoRetorno5() {
/* 346 */     return this.informacaoRetorno5;
/*     */   }
/*     */   public void setInformacaoRetorno5(String informacaoRetorno5) {
/* 349 */     this.informacaoRetorno5 = informacaoRetorno5;
/*     */   }
/*     */   public Integer getTipoMovimento() {
/* 352 */     return this.tipoMovimento;
/*     */   }
/*     */   public void setTipoMovimento(Integer tipoMovimento) {
/* 355 */     this.tipoMovimento = tipoMovimento;
/*     */   }
/*     */   public Integer getCodigoMovimento() {
/* 358 */     return this.codigoMovimento;
/*     */   }
/*     */   public void setCodigoMovimento(Integer codigoMovimento) {
/* 361 */     this.codigoMovimento = codigoMovimento;
/*     */   }
/*     */   public Integer getHorarioConsultaSaldo() {
/* 364 */     return this.horarioConsultaSaldo;
/*     */   }
/*     */   public void setHorarioConsultaSaldo(Integer horarioConsultaSaldo) {
/* 367 */     this.horarioConsultaSaldo = horarioConsultaSaldo;
/*     */   }
/*     */   public Long getSaldoDisponivelSaldo() {
/* 370 */     return this.saldoDisponivelSaldo;
/*     */   }
/*     */   public void setSaldoDisponivelSaldo(Long saldoDisponivelSaldo) {
/* 373 */     this.saldoDisponivelSaldo = saldoDisponivelSaldo;
/*     */   }
/*     */   public Long getValorTaxaPreFunding() {
/* 376 */     return this.valorTaxaPreFunding;
/*     */   }
/*     */   public void setValorTaxaPreFunding(Long valorTaxaPreFunding) {
/* 379 */     this.valorTaxaPreFunding = valorTaxaPreFunding;
/*     */   }
/*     */   public String getReserva() {
/* 382 */     return this.reserva;
/*     */   }
/*     */   public void setReserva(String reserva) {
/* 385 */     this.reserva = reserva;
/*     */   }
/*     */   public String getSacadorAvalista() {
/* 388 */     return this.sacadorAvalista;
/*     */   }
/*     */   public void setSacadorAvalista(String sacadorAvalista) {
/* 391 */     this.sacadorAvalista = sacadorAvalista;
/*     */   }
/*     */   public String getReserva2() {
/* 394 */     return this.reserva2;
/*     */   }
/*     */   public void setReserva2(String reserva2) {
/* 397 */     this.reserva2 = reserva2;
/*     */   }
/*     */   public String getNivelInfoRetorno() {
/* 400 */     return this.nivelInfoRetorno;
/*     */   }
/*     */   public void setNivelInfoRetorno(String nivelInfoRetorno) {
/* 403 */     this.nivelInfoRetorno = nivelInfoRetorno;
/*     */   }
/*     */   public String getInformacoesComplementares() {
/* 406 */     return this.informacoesComplementares;
/*     */   }
/*     */   public void setInformacoesComplementares(String informacoesComplementares) {
/* 409 */     this.informacoesComplementares = informacoesComplementares;
/*     */   }
/*     */   public Integer getCodigoAreaEmpresa() {
/* 412 */     return this.codigoAreaEmpresa;
/*     */   }
/*     */   public void setCodigoAreaEmpresa(Integer codigoAreaEmpresa) {
/* 415 */     this.codigoAreaEmpresa = codigoAreaEmpresa;
/*     */   }
/*     */   public String getCampoUsoEmpresa() {
/* 418 */     return this.campoUsoEmpresa;
/*     */   }
/*     */   public void setCampoUsoEmpresa(String campoUsoEmpresa) {
/* 421 */     this.campoUsoEmpresa = campoUsoEmpresa;
/*     */   }
/*     */   public String getReserva3() {
/* 424 */     return this.reserva3;
/*     */   }
/*     */   public void setReserva3(String reserva3) {
/* 427 */     this.reserva3 = reserva3;
/*     */   }
/*     */   public Integer getCodigoLancamento() {
/* 430 */     return this.codigoLancamento;
/*     */   }
/*     */   public void setCodigoLancamento(Integer codigoLancamento) {
/* 433 */     this.codigoLancamento = codigoLancamento;
/*     */   }
/*     */   public String getReserva4() {
/* 436 */     return this.reserva4;
/*     */   }
/*     */   public void setReserva4(String reserva4) {
/* 439 */     this.reserva4 = reserva4;
/*     */   }
/*     */   public Integer getTipoContaFornecedor() {
/* 442 */     return this.tipoContaFornecedor;
/*     */   }
/*     */   public void setTipoContaFornecedor(Integer tipoContaFornecedor) {
/* 445 */     this.tipoContaFornecedor = tipoContaFornecedor;
/*     */   }
/*     */   public String getContaComplementar() {
/* 448 */     return this.contaComplementar;
/*     */   }
/*     */   public void setContaComplementar(String contaComplementar) {
/* 451 */     this.contaComplementar = contaComplementar;
/*     */   }
/*     */   public String getReserva5() {
/* 454 */     return this.reserva5;
/*     */   }
/*     */   public void setReserva5(String reserva5) {
/* 457 */     this.reserva5 = reserva5;
/*     */   }
/*     */   public Integer getNumeroSequencial() {
/* 460 */     return this.numeroSequencial;
/*     */   }
/*     */   public void setNumeroSequencial(Integer numeroSequencial) {
/* 463 */     this.numeroSequencial = numeroSequencial;
/*     */   }
/*     */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\vo\cargas\volkswagen\layout500\remessa\Detalhe.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */