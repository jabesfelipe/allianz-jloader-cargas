package br.com.accesstage.loader.util.commom;

public interface ASCargasLayout {
  void load(String paramString1, String paramString2, int paramInt1, int paramInt2);
}


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\jloader-cargas-20200729.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\commom\ASCargasLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */