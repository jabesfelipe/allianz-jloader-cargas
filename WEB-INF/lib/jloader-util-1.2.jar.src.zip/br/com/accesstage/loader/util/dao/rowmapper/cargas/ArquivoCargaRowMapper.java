/*    */ package br.com.accesstage.loader.util.dao.rowmapper.cargas;
/*    */ 
/*    */ import br.com.accesstage.loader.util.vo.cargas.ArquivoCarga;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ 
/*    */ 
/*    */ public class ArquivoCargaRowMapper
/*    */   implements RowMapper<ArquivoCarga>
/*    */ {
/*    */   public ArquivoCarga mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 14 */     ArquivoCarga arquivoCarga = new ArquivoCarga();
/* 15 */     arquivoCarga.setCodigoArquivo(Long.valueOf(rs.getLong("COD_ARQUIVO")));
/* 16 */     arquivoCarga.setDscNomeArquivoOrigem(rs.getString("DSC_NOME_ARQUIVO_ORIGEM"));
/* 17 */     arquivoCarga.setDscNomeArquivoOrigem(rs.getString("DSC_NOME_ARQUIVO_DESTINO"));
/* 18 */     arquivoCarga.setNmePathIn(rs.getString("NME_PATH_IN"));
/* 19 */     arquivoCarga.setNmePathOut(rs.getString("NME_PATH_OUT"));
/* 20 */     arquivoCarga.setNroRegistros(rs.getString("NRO_REGISTROS"));
/* 21 */     arquivoCarga.setCodInstanciaBpel(rs.getString("COD_INSTANCIA_BPEL"));
/* 22 */     arquivoCarga.setDthProcessIni(rs.getDate("DTH_PROCESS_INI"));
/* 23 */     arquivoCarga.setDthProcessFim(rs.getDate("DTH_PROCESS_FIM"));
/* 24 */     arquivoCarga.setEmpId(Long.valueOf(rs.getLong("EMPID")));
/* 25 */     arquivoCarga.setCodTpoLayout(rs.getString("COD_TPO_LAYOUT"));
/* 26 */     arquivoCarga.setDscOrigem(rs.getString("DSC_ORIGEM"));
/* 27 */     arquivoCarga.setCodStatus(rs.getString("COD_STATUS_CARGA"));
/* 28 */     arquivoCarga.setCreated(rs.getDate("CREATED"));
/* 29 */     String exists = rs.getString("EXIST");
/* 30 */     if (StringUtils.isNotEmpty(exists))
/* 31 */       if (exists.equalsIgnoreCase("S")) {
/* 32 */         arquivoCarga.setExists(true);
/*    */       } else {
/* 34 */         arquivoCarga.setExists(false);
/*    */       }  
/* 36 */     return arquivoCarga;
/*    */   }
/*    */ }


/* Location:              D:\accesstage\projetos\allianz\arquivos\war\prod\decompile\emissor-boleto-local.war!\WEB-INF\lib\jloader-util-1.2.jar!\br\com\accesstage\loade\\util\dao\rowmapper\cargas\ArquivoCargaRowMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */